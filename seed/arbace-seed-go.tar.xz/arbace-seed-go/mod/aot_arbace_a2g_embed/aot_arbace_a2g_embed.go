//line aot_arbace_a2g_embed.ae:1
package aot_arbace_a2g_embed

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_New() *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_embed_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_embed_A_const_2); lang.IFn_Cast(A_arbace_a2g_embed_A_const_1.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_embed_A_const_3, A_arbace_a2g_embed_A_const_4, A_arbace_a2g_embed_A_const_5, A_arbace_a2g_embed_A_const_6); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_12)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_13)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_14)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_15)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp8 != nil { panic(tmp8) }; return tmp3 }
//line :1:1
func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_New() *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_eval1520000008_fn__1520000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_embed_A_const_11), A_arbace_a2g_embed_A_const_9.GetRawRoot__O(), A_arbace_a2g_embed_A_const_10) }






































func A_arbace_a2g_embed_sources_A_New() *A_arbace_a2g_embed_sources_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_a2g_embed_sources_A) Ctor() {}
//line :40:1
func (t *A_arbace_a2g_embed_sources_A) Invoke_O_O__O(self, root__0 any) any { var base__2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O__O(root__0, Lit_40); var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_New_O(base__2); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_fn_class; if



	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_31.GetRawRoot__O()).Invoke_O__O(base__2)); var vdir__4 any = /*line :40:1*/lang.IFn_Cast(A_arbace_a2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O__O(root__0, A_arbace_a2g_embed_A_const_32.GetRawRoot__O()); var variants__5 any; if









	jrt.NN(jrt.File_Cast(vdir__4)).IsDirectory__Z() { var iter__1927001039__auto____5 any; var tmp3 any = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_New_O(vdir__4); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_fn_class
		if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); variants__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_31.GetRawRoot__O()).Invoke_O__O(vdir__4)) } else {
//line :50:1
			variants__5 = nil }; var tmp5 lang.IFn =



	lang.IFn_Cast(A_arbace_a2g_embed_A_const_30.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_embed_sources_fn__1520000038_A_New(); var tmp7 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_embed_sources_fn__1520000038_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_a2g_embed_sources_fn__1520000038_A_fn_class = fncls__11d; tmp7 = fncls__11d } else { tmp7 = fncls__11 }; return tmp5.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_a2g_embed_A_const_45.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_47.GetRawRoot__O()).Invoke__O(), files__3), lang.IFn_Cast(A_arbace_a2g_embed_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_25.GetRawRoot__O(), variants__5)) }
//line :44:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) Invoke_O_O__O(self, s__1520000014__1 any) any { var tmp1 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_New_O_O_O(t.F_base, s__1520000014__1, self); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :44:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) Ctor_O_O_O(c__base, c__s__1520000014, c__iter__1520000013 any) { t.F_base = c__base; t.F_s__1520000014 = c__s__1520000014; t.F_iter__1520000013 = c__iter__1520000013 }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) Invoke_O__O(self any) any { { var s__1520000014__1 any; var t_ any = t.F_s__1520000014; t.F_s__1520000014 = nil; s__1520000014__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000014__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000014__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000014__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000014__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000016__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_New_O_O_I_O(b__1520000016__6, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000013); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000016__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000014__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000016__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000014__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_28) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :44:1
	if jrt.A2g_Truth(tmp4) { var rel__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())))).Ref(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_19.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_New_O(rel__5); var tmp7 *jrt.Class
		var fncls__3 /*line :44:1*/*jrt.Class = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_fn_class


		if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_fn_class = fncls__3d; tmp7 = fncls__3d } else { tmp7 = fncls__3 }
//line :44:1
		if jrt.A2g_Truth(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), A_arbace_a2g_embed_A_const_21.GetRawRoot__O())) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1520000013); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(A_arbace_a2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000014__3))) } else { s__1520000014__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000014__3); continue L1 } } else { s__1520000014__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000014__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :44:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) Ctor_O_O_I_O(c__b__1520000016, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000016 = c__b__1520000016; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) Invoke_O__O(self any) any { { var i__1520000015__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000015__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_28) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :44:1
	if jrt.A2g_Truth(tmp2) { var rel__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())))).Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_19.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_New_O(rel__3); var tmp5 *jrt.Class
		var fncls__1 /*line :44:1*/*jrt.Class = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_fn_class


		if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }
//line :44:1
		if jrt.A2g_Truth(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_a2g_embed_A_const_21.GetRawRoot__O())) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp7 any = t.F_b__1520000016; tmp6.Invoke_O_O__O(tmp7, lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(A_arbace_a2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2))); i__1520000015__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000015__1); continue L1 } else { i__1520000015__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000015__1); continue L1 } } else { i__1520000015__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000015__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A{}; t.Ctor_O(p0); return t }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) Invoke_O_O__O(self, p1__1520000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_20.GetRawRoot__O()).Invoke_O_O__O(t.F_rel, p1__1520000012_SHARP___1) }
//line :47:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A{}; t.Ctor_O(p0); return t }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) Invoke_O_O__O(self, p1__1520000012_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_20.GetRawRoot__O()).Invoke_O_O__O(t.F_rel, p1__1520000012_SHARP___1) }



func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A{}; t.Ctor_O(p0); return t }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) Invoke_O_O__O(self, s__1520000028__1 any) any { var tmp1 any = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_New_O_O_O(t.F_vdir, s__1520000028__1, self); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) Ctor_O_O_O(c__vdir, c__s__1520000028, c__iter__1520000027 any) { t.F_vdir = c__vdir; t.F_s__1520000028 = c__s__1520000028; t.F_iter__1520000027 = c__iter__1520000027 }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) Invoke_O__O(self any) any { { var s__1520000028__1 any; var t_ any = t.F_s__1520000028; t.F_s__1520000028 = nil; s__1520000028__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000028__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000028__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000028__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000028__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000030__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_New_O_O_I_O(t.F_vdir, b__1520000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000027); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000030__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000028__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000030__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000028__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { tmp4 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_28) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :51:1
	if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1520000027); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())), lang.IFn_Cast(A_arbace_a2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000028__3))) } else { s__1520000028__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000028__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :51:1
func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) Ctor_O_O_I_O(c__vdir, c__b__1520000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_vdir = c__vdir; t.F_b__1520000030 = c__b__1520000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) Invoke_O__O(self any) any { { var i__1520000029__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000029__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { tmp2 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_28) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :51:1
	if jrt.A2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp4 any = t.F_b__1520000030; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())), lang.IFn_Cast(A_arbace_a2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__2))); i__1520000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000029__1); continue L1 } else { i__1520000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000029__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_embed_sources_fn__1520000038_A_New() *A_arbace_a2g_embed_sources_fn__1520000038_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_fn__1520000038_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) Invoke_O_O_O__O(self, m__1, p__1520000037__2 any) any { var vec__1520000039__3 any = p__1520000037__2; var rel__4 any = lang.RT_Nth_O_I_O__O(vec__1520000039__3, lang.RT_IntCast_J__I(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__1520000039__3, lang.RT_IntCast_J__I(1), nil); if
														jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(rel__4, Lit_44)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_embed_A_const_38; var p__6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, nil, tmp1.Invoke_O_O_O__O(rel__4, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(rel__4)), int64(lang.RT_Count_O__I(Lit_44)))).Ref()), nil)).Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_34.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_embed_A_const_39; var pairs__7 any = tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_a2g_embed_A_const_40.GetRawRoot__O()).Invoke_O__O(text__5))




		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_41.GetRawRoot__O()).Invoke_O_O__O(m__1, p__6)) { } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_42.GetRawRoot__O()); var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp5.Invoke_O_O__O(tmp6, tmp7.Ref()))))
		}
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_35.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp10 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_fn_class = fncls__10d; tmp10 = fncls__10d } else { tmp10 = fncls__10 }; return tmp8.Invoke_O_O_O__O(m__1, p__6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) } else {
//line :55:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(rel__4, Lit_49)) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_33.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_embed_A_const_38; var p__6_2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, nil, tmp11.Invoke_O_O_O__O(rel__4, tmp12, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(rel__4)), int64(lang.RT_Count_O__I(Lit_49)))).Ref()), nil)).Ref()
















				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_41.GetRawRoot__O()).Invoke_O_O__O(m__1, p__6_2)) { } else { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_42.GetRawRoot__O()); var tmp14 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(); var tmp15 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp15 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp13.Invoke_O_O__O(tmp14, tmp15.Ref()))))
				}
				return lang.IFn_Cast(A_arbace_a2g_embed_A_const_35.GetRawRoot__O()).Invoke_O_O_O_O__O(m__1, p__6_2, A_arbace_a2g_embed_A_const_18.GetRawRoot__O(), text__5) } else {
//line :55:1
					if A_arbace_a2g_embed_A_const_36 != nil {



















						return lang.IFn_Cast(A_arbace_a2g_embed_A_const_37.GetRawRoot__O()).Invoke_O_O_O__O(m__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(), text__5) } else {
//line :55:1
							return nil } } } }






func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :62:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :62:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) Invoke_O_O__O(self, src__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_30.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_New_O_O(t.F_p, t.F_rel); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), src__1, t.F_pairs) }
//line :63:1
func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :63:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) Invoke_O_O_O__O(self, src__1, p__1520000043__2 any) any { var vec__1520000045__3 any = p__1520000043__2; var old__4 any = lang.RT_Nth_O_I_O__O(vec__1520000045__3, lang.RT_IntCast_J__I(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O(vec__1520000045__3, lang.RT_IntCast_J__I(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_43.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(i__6).Ref(), jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref()) }; if jrt.A2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_42.GetRawRoot__O()); var tmp3 any = t.F_rel; var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_51, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, lang.IFn_Cast(A_arbace_a2g_embed_A_const_44.GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp2.Invoke_O_O__O(tmp4, tmp5.Ref())))) }; var tmp6 lang.IFn =


	lang.IFn_Cast(A_arbace_a2g_embed_A_const_33.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_embed_A_const_38; return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, nil), jrt.RefArrayOf(jrt.Object_class, tmp6.Invoke_O_O_O__O(src__1, tmp7, jrt.Integer_ValueOf_I__Integer(i__6).Ref()), new__5, lang.IFn_Cast(A_arbace_a2g_embed_A_const_33.GetRawRoot__O()).Invoke_O_O__O(src__1, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(int64(i__6), int64(lang.RT_Count_O__I(old__4)))).Ref()))).Ref() }















func A_arbace_a2g_embed_reify__1520000052_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_a2g_embed_reify__1520000052_A { t := &A_arbace_a2g_embed_reify__1520000052_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_48; return lang.Symbol_Cast(tmp1) }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_a2g_embed_reify__1520000052_A_New_IPersistentMap(m) }





func A_arbace_a2g_embed_read_all_A_New() *A_arbace_a2g_embed_read_all_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_read_all_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_a2g_embed_read_all_A) Ctor() {}
//line :90:1
func (t *A_arbace_a2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_52.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_53.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_embed_A_const_54; var tmp4 *jrt.Boolean;

	jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; var tmp5 any = tmp4.Ref(); var tmp6 any = A_arbace_a2g_embed_A_const_55; var tmp7 any = A_arbace_a2g_embed_A_const_56.GetRawRoot__O(); var tmp8 any = A_arbace_a2g_embed_A_const_57; var tmp9 any = A_arbace_a2g_embed_read_all_fn__1520000054_A_New(); var tmp10 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_embed_read_all_fn__1520000054_A_fn_class; if

	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_a2g_embed_read_all_fn__1520000054_A_fn_class = fncls__12d; tmp10 = fncls__12d } else { tmp10 = fncls__12 }; /*line :92:1*/tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O__O(tmp3, tmp5, tmp6, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil))); var tmp11 any; tmp12 := /*line :90:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any; lang.PersistentVector_Init(); acc__5 = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_58, r__2)






		if lang.Util_Equiv_O_O__Z(f__6, A_arbace_a2g_embed_A_const_50) { tmp11 = acc__5 } else { acc__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_9.GetRawRoot__O()).Invoke_O_O__O(acc__5, f__6); continue L1 }
//line :90:1
		break L1 } }; return nil }();

	lang.IFn_Cast(A_arbace_a2g_embed_A_const_51.GetRawRoot__O()).Invoke__O(); if /*line :90:1*/ tmp12 != nil { panic(tmp12) }; return tmp11 }



func A_arbace_a2g_embed_read_all_fn__1520000054_A_New() *A_arbace_a2g_embed_read_all_fn__1520000054_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_read_all_fn__1520000054_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) Ctor() {}
//line :94:1
func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_a2g_embed_class_like_QMARK__A_New() *A_arbace_a2g_embed_class_like_QMARK__A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_a2g_embed_class_like_QMARK__A) Ctor() {}
//line :99:1
func (t *A_arbace_a2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_1); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z(lang.Numbers_Inc_J__J(int64(i__2)), int64(lang.RT_Count_O__I(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsUpperCase_C__Z(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }

func A_arbace_a2g_embed_package_like_QMARK__A_New() *A_arbace_a2g_embed_package_like_QMARK__A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_a2g_embed_package_like_QMARK__A) Ctor() {}
//line :103:1
func (t *A_arbace_a2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_1))); if and__1927000168__auto____2 {
											return lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_60.GetRawRoot__O()).Invoke_O__O(s__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }

func A_arbace_a2g_embed_names_A_New() *A_arbace_a2g_embed_names_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_names_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_a2g_embed_names_A) Ctor() {}
//line :106:1
func (t *A_arbace_a2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_61.GetRawRoot__O()); var tmp2 *lang.PersistentHashSet;



	lang.PersistentHashSet_Init(); tmp2 = lang.PersistentHashSet_EMPTY; acc__2 = tmp1.Invoke_O__O(tmp2.Ref()); var walk__3 any; var tmp3 any = /*line :106:1*/A_arbace_a2g_embed_names_walk__1520000059_A_New_O(acc__2); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_embed_names_walk__1520000059_A_fn_class; if




	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_a2g_embed_names_walk__1520000059_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var seq_1520000083__4 any = /*line :106:1*/lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_74.GetRawRoot__O()).Invoke_O__O(text__0)); var chunk_1520000084__5 any; var count_1520000085__6 int64 = 0; var i_1520000086__7 int64 = 0; L1: for {




















		if lang.Numbers_Lt_J_J__Z(i_1520000086__7, count_1520000085__6) { var f__8 any = lang.Indexed_Cast(chunk_1520000084__5).Nth_I__O(lang.RT_IntCast_J__I(i_1520000086__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, i_1520000086__7 = seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, lang.Numbers_Unchecked_inc_J__J(i_1520000086__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1520000083__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1520000083__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1520000083__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1520000083__9); seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, i_1520000086__7 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1520000083__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__10 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1520000083__9); lang.IFn_Cast(walk__3).Invoke_O__O(f__10); seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, i_1520000086__7 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1520000083__9), nil, 0, 0; continue L1 } } }
//line :106:1
		break L1 }; return /*line :128:1*/ lang.IFn_Cast(A_arbace_a2g_embed_A_const_73.GetRawRoot__O()).Invoke_O__O(acc__2) }
//line :111:1
func A_arbace_a2g_embed_names_walk__1520000059_A_New_O(p0 any) *A_arbace_a2g_embed_names_walk__1520000059_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_names_walk__1520000059_A{}; t.Ctor_O(p0); return t }
//line :111:1
func (t *A_arbace_a2g_embed_names_walk__1520000059_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :111:1
func (t *A_arbace_a2g_embed_names_walk__1520000059_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap(x__1)
											if jrt.A2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_62.GetRawRoot__O()).Invoke_O__O(x__1)) {

		var tmp1 any; var and__1927000168__auto____2 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_a2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1), nil); if and__1927000168__auto____2 { tmp1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_69.GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.A2g_Truth(tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_64.GetRawRoot__O()); var tmp3 any = t.F_acc; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_a2g_embed_A_const_69.GetRawRoot__O()).Invoke_O__O(x__1)) }
		var tmp4 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____2_2) { tmp4 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp4 = and__1927000168__auto____2_2 }; if jrt.A2g_Truth(tmp4) {
			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_64.GetRawRoot__O()); var tmp6 any = t.F_acc; return tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_a2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :117:1
				return nil } } else {
//line :113:1
					var tmp7 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_65.GetRawRoot__O()).Invoke_O__O(x__1)





					if jrt.A2g_Truth(or__1927000174__auto____2) { tmp7 = or__1927000174__auto____2 } else { tmp7 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_66.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :113:1
					if jrt.A2g_Truth(tmp7) {






						var tmp8 any; var and__1927000168__auto____2_3 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_62.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1)); if jrt.A2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_a2g_embed_A_const_63.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1)), nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_70.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1))); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(x__1)); if jrt.A2g_Truth(and__1927000168__auto____5) {

							tmp8 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_71.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_62.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :120:1
								tmp8 = and__1927000168__auto____5 } } else { tmp8 = and__1927000168__auto____4 } } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { tmp8 = and__1927000168__auto____2_3 }; if jrt.A2g_Truth(tmp8) { var seq_1520000060__2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(x__1)); var chunk_1520000061__3 any; var count_1520000062__4 int64 = 0; var i_1520000063__5 int64 = 0; L1: for {


									if lang.Numbers_Lt_J_J__Z(i_1520000063__5, count_1520000062__4) { var c__6 any = lang.Indexed_Cast(chunk_1520000061__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000063__5)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_64.GetRawRoot__O()); var tmp10 any = t.F_acc; tmp9.Invoke_O_O__O(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1), nil, c__6)).Ref()); seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, i_1520000063__5 = seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, lang.Numbers_Unchecked_inc_J__J(i_1520000063__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1520000060__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1520000060__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1520000060__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1520000060__7); seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, i_1520000063__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1520000060__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1520000060__7); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_64.GetRawRoot__O()); var tmp12 any = t.F_acc; tmp11.Invoke_O_O__O(tmp12, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1), nil, c__8)).Ref()); seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, i_1520000063__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1520000060__7), nil, 0, 0; continue L1 } } }
//line :120:1
									break L1 } }
//line :113:1
						var seq_1520000064__2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1); var chunk_1520000065__3 any; var count_1520000066__4 int64 = 0; var i_1520000067__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z(i_1520000067__5, count_1520000066__4) { var y__6 any = lang.Indexed_Cast(chunk_1520000065__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000067__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, i_1520000067__5 = seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, lang.Numbers_Unchecked_inc_J__J(i_1520000067__5); continue L2 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1520000064__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_1520000064__7 any = temp__1927000414__auto____6_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1520000064__7)) { var c__1927000678__auto____8_2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1520000064__7); seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, i_1520000067__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1520000064__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var y__8 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1520000064__7); lang.IFn_Cast(self).Invoke_O__O(y__8); seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, i_1520000067__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1520000064__7), nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :113:1
								if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_67.GetRawRoot__O()).Invoke_O__O(x__1)) { var seq_1520000068__2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1); var chunk_1520000069__3 any; var count_1520000070__4 int64 = 0; var i_1520000071__5 int64 = 0; L3: for {











									if lang.Numbers_Lt_J_J__Z(i_1520000071__5, count_1520000070__4) { var vec__1520000072__6 any = lang.Indexed_Cast(chunk_1520000069__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000071__5)); var k__7 any = lang.RT_Nth_O_I_O__O(vec__1520000072__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__1520000072__6, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, i_1520000071__5 = seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, lang.Numbers_Unchecked_inc_J__J(i_1520000071__5); continue L3 } else { var temp__1927000414__auto____6_3 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1520000068__2); if jrt.A2g_Truth(temp__1927000414__auto____6_3) { var seq_1520000068__7 any = temp__1927000414__auto____6_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1520000068__7)) { var c__1927000678__auto____8_3 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1520000068__7); seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, i_1520000071__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1520000068__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__1520000075__8 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1520000068__7); var k__9 any = lang.RT_Nth_O_I_O__O(vec__1520000075__8, lang.RT_IntCast_J__I(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__1520000075__8, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, i_1520000071__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1520000068__7), nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :113:1
										if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_68.GetRawRoot__O()).Invoke_O__O(x__1)) { var seq_1520000078__2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1); var chunk_1520000079__3 any; var count_1520000080__4 int64 = 0; var i_1520000081__5 int64 = 0; L4: for {












											if lang.Numbers_Lt_J_J__Z(i_1520000081__5, count_1520000080__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1520000079__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000081__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, i_1520000081__5 = seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, lang.Numbers_Unchecked_inc_J__J(i_1520000081__5); continue L4 } else { var temp__1927000414__auto____6_4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1520000078__2); if jrt.A2g_Truth(temp__1927000414__auto____6_4) { var seq_1520000078__7 any = temp__1927000414__auto____6_4; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1520000078__7)) { var c__1927000678__auto____8_4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_1520000078__7); seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, i_1520000081__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1520000078__7), c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var y__8_2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_1520000078__7); lang.IFn_Cast(self).Invoke_O__O(y__8_2); seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, i_1520000081__5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_72.GetRawRoot__O()).Invoke_O__O(seq_1520000078__7), nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :113:1
												return nil } } } } }; /*line :111:1*/panic("a2g: unreachable") }





























func A_arbace_a2g_embed_cut_candidates_A_New() *A_arbace_a2g_embed_cut_candidates_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_a2g_embed_cut_candidates_A) Ctor() {}
//line :141:1
func (t *A_arbace_a2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_75.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_82.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_83.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_embed_A_const_82.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_85.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_86.GetRawRoot__O()).Invoke__O(); var tmp11 any = A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_New(); var tmp12 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_fn_class = fncls__19d; tmp12 = fncls__19d } else { tmp12 = fncls__19 }; tmp2 = tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O_O__O(tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), srcs__0)), A_arbace_a2g_embed_A_const_84.GetRawRoot__O())); return tmp1.Invoke_O__O(tmp2) }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_New() *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_fn__1520000103_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) Ctor() {}
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) Invoke_O_O__O(self, p__1520000102__1 any) any { var vec__1520000104__2 any = p__1520000102__1; var ___3 any = lang.RT_Nth_O_I_O__O(vec__1520000104__2, lang.RT_IntCast_J__I(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O(vec__1520000104__2, lang.RT_IntCast_J__I(1), nil); _ = ___3; return lang.IFn_Cast(A_arbace_a2g_embed_A_const_87.GetRawRoot__O()).Invoke_O__O(text__4) }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_New() *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) Ctor() {}
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) Invoke_O_O__O(self, s__1520000089__1 any) any { var tmp1 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_New_O_O(s__1520000089__1, self); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) Ctor_O_O(c__s__1520000089, c__iter__1520000088 any) { t.F_s__1520000089 = c__s__1520000089; t.F_iter__1520000088 = c__iter__1520000088 }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) Invoke_O__O(self any) any { { var s__1520000089__1 any; var t_ any = t.F_s__1520000089; t.F_s__1520000089 = nil; s__1520000089__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000089__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000089__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000089__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000091__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_New_O_I_O(b__1520000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000088); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000091__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000089__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000091__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000089__3); var tmp4 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_78, n__4)
															if jrt.A2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
																and__1927000168__auto____5 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_79, n__4) }
//line :147:1
	if jrt.A2g_Truth(and__1927000168__auto____5) {


		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_77.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_embed_A_const_80; var tmp7 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_New_O(n__4); var tmp8 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_fn_class = fncls__16d; tmp8 = fncls__16d } else { tmp8 = fncls__16 }; tmp4 = tmp5.Invoke_O_O_O__O(tmp6, n__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)) } else {
//line :147:1
			tmp4 = and__1927000168__auto____5 }
//line :146:1
	if jrt.A2g_Truth(tmp4) { var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1520000088); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(n__4, Lit_1, Lit_7), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000089__3))) } else { s__1520000089__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000089__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) Ctor_O_I_O(c__b__1520000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000091 = c__b__1520000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) Invoke_O__O(self any) any { { var i__1520000090__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000090__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_78, n__2)
																	if jrt.A2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
																		and__1927000168__auto____3 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_79, n__2) }
//line :147:1
	if jrt.A2g_Truth(and__1927000168__auto____3) {


		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_77.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_embed_A_const_80; var tmp5 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_New_O(n__2); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; tmp2 = tmp3.Invoke_O_O_O__O(tmp4, n__2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) } else {
//line :147:1
			tmp2 = and__1927000168__auto____3 }
//line :146:1
	if jrt.A2g_Truth(tmp2) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp8 any = t.F_b__1520000091; tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_a2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(n__2, Lit_1, Lit_7)); i__1520000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000090__1); continue L1 } else { i__1520000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000090__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_New_O(p0 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(tmp3).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :150:1
		jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :150:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_New_O(p0 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(tmp3).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :150:1
		jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_a2g_embed_with_member_types_A_New() *A_arbace_a2g_embed_with_member_types_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_a2g_embed_with_member_types_A) Ctor() {}
//line :155:1
func (t *A_arbace_a2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var tmp1 any = A_arbace_a2g_embed_with_member_types_types__1520000109_A_New(); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_embed_with_member_types_types__1520000109_A_fn_class; if




	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_a2g_embed_with_member_types_types__1520000109_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var elem__4 any; var tmp3 any = /*line :155:1*/A_arbace_a2g_embed_with_member_types_elem__1520000117_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_a2g_embed_with_member_types_elem__1520000117_A_fn_class; if








	fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_a2g_embed_with_member_types_elem__1520000117_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var member_types__5 any; var tmp5 any = /*line :155:1*/A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_New_O_O(elem__4, types__3); var tmp6 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_fn_class; if










	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_fn_class = fncls__29d; tmp6 = fncls__29d } else { tmp6 = fncls__29 }; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var more__6 any; var iter__1927001039__auto____6 any; var tmp7 any = /*line :155:1*/A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp8 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_fn_class; if




















	fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_fn_class = fncls__35d; tmp8 = fncls__35d } else { tmp8 = fncls__35 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); return /*line :181:1*/ lang.IFn_Cast(A_arbace_a2g_embed_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_82.GetRawRoot__O()).Invoke_O_O__O(cands__0, more__6))) }
//line :160:1
func A_arbace_a2g_embed_with_member_types_types__1520000109_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) Ctor() {}
//line :160:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_82.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_88.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_New(); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; var tmp5 any = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_89.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_New(); var tmp8 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_fn_class
	if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_fn_class = fncls__21d; tmp8 = fncls__21d } else { tmp8 = fncls__21 }
//line :161:1
	var tmp9 any = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_88.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_New(); var tmp12 *jrt.Class
	var fncls__22 /*line :161:1*/*jrt.Class = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_fn_class

	if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_fn_class = fncls__22d; tmp12 = fncls__22d } else { tmp12 = fncls__22 }
//line :161:1
	return tmp1.Invoke_O_O_O__O(tmp5, tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :161:1
func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) Ctor() {}
//line :161:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) Invoke_O_O__O(self, m__1 any) any { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(), jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref()) }
func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) Ctor() {}
//line :162:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) Ctor() {}
//line :163:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_New() *A_arbace_a2g_embed_with_member_types_elem__1520000117_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_elem__1520000117_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) Ctor() {}
//line :164:1
func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("a2g: unreachable") }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_A{}; t.Ctor_O_O(p0, p1); return t }
//line :166:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :166:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_New_O(n__1); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_fn_class; if
														fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; temp__1927000414__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); if jrt.A2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_90.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_91.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_92.GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____4 any; var tmp7 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_New(); var tmp8 *jrt.Class
															var fncls__28 /*line :167:1*/*jrt.Class = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_fn_class


		if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_fn_class = fncls__28d; tmp8 = fncls__28d } else { tmp8 = fncls__28 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_89.GetRawRoot__O()); var tmp10 any = t.F_elem; tmp6 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(t.F_types).Invoke_O__O(c__3)))
//line :169:1
		return tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))) } else {
//line :167:1
			return nil } }
//line :167:1
func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_New_O(p0 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :167:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_81.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; var tmp4 *jrt.String = jrt.String_Cast(tmp2.Invoke_O_O_O__O(tmp3, Lit_7, Lit_1)); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(tmp4, jrt.NN(tmp5).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp6 != nil { if true { var ___3 jrt.Throwable_I = tmp6; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_New() *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) Ctor() {}
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) Invoke_O_O__O(self, s__1520000123__1 any) any { var tmp1 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_New_O_O(s__1520000123__1, self); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :170:1
func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) Ctor_O_O(c__s__1520000123, c__iter__1520000122 any) { t.F_s__1520000123 = c__s__1520000123; t.F_iter__1520000122 = c__iter__1520000122 }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) Invoke_O__O(self any) any { { var s__1520000123__1 any; var t_ any = t.F_s__1520000123; t.F_s__1520000123 = nil; s__1520000123__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000123__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000123__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000123__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000123__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000125__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_New_O_I_O(b__1520000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000122); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000125__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000123__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000125__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000123__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref())) { var tn__5 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(), Lit_1, Lit_7); var tmp4 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_93, tn__5)


	if jrt.A2g_Truth(and__1927000168__auto____6) {
		tmp4 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :173:1
			tmp4 = and__1927000168__auto____6 }
//line :170:1
	if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1520000122); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tn__5, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000123__3))) } else { s__1520000123__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000123__3); continue L1 } } else { s__1520000123__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000123__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :170:1
func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) Ctor_O_I_O(c__b__1520000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000125 = c__b__1520000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) Invoke_O__O(self any) any { { var i__1520000124__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000124__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref())) { var tn__3 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_81.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(), Lit_1, Lit_7); var tmp2 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_76.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_93, tn__3)


	if jrt.A2g_Truth(and__1927000168__auto____4) {
		tmp2 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :173:1
			tmp2 = and__1927000168__auto____4 }
//line :170:1
	if jrt.A2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1520000125, tn__3); i__1520000124__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000124__1); continue L1 } else { i__1520000124__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000124__1); continue L1 } } else { i__1520000124__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000124__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) Invoke_O_O__O(self, s__1520000134__1 any) any { var tmp1 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1520000134__1, self); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1520000134, c__iter__1520000133 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1520000134 = c__s__1520000134; t.F_iter__1520000133 = c__iter__1520000133 }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) Invoke_O__O(self any) any { { var s__1520000134__1 any; var t_ any = t.F_s__1520000134; t.F_s__1520000134 = nil; s__1520000134__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000134__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4))) { var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_New_O(t.F_in_world_QMARK_); var tmp2 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_fn_class = fncls__32d; tmp2 = fncls__32d } else { tmp2 = fncls__32 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_94.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_embed_A_const_95; var tmp7 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_New_O_O(n__4, t.F_member_types); var tmp8 *jrt.Class
															var fncls__33 /*line :176:1*/*jrt.Class = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_fn_class

	if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_fn_class = fncls__33d; tmp8 = fncls__33d } else { tmp8 = fncls__33 }
//line :176:1
	fs__1927001036__auto____6 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp6, n__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1520000133); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_82.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000134__1))) } else { s__1520000134__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000134__1); continue L1 } } else { s__1520000134__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000134__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_New_O(p0 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) Invoke_O_O__O(self, s__1520000136__1 any) any { var tmp1 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_New_O_O_O(t.F_in_world_QMARK_, s__1520000136__1, self); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1520000136, c__iter__1520000135 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1520000136 = c__s__1520000136; t.F_iter__1520000135 = c__iter__1520000135 }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) Invoke_O__O(self any) any { { var s__1520000136__1 any; var t_ any = t.F_s__1520000136; t.F_s__1520000136 = nil; s__1520000136__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000136__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000136__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000136__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000136__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000138__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_New_O_O_I_O(b__1520000138__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000135); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000138__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000136__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000138__6), nil) } } else { var tn__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000136__3); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1520000135); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tn__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000136__3))) } else { s__1520000136__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000136__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) Ctor_O_O_I_O(c__b__1520000138, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000138 = c__b__1520000138; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) Invoke_O__O(self any) any { { var i__1520000137__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000137__1)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2))) { lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1520000138, tn__2); i__1520000137__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000137__1); continue L1 } else { i__1520000137__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000137__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :178:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_a2g_embed_data_A_New() *A_arbace_a2g_embed_data_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_data_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_a2g_embed_data_A) Ctor() {}
//line :186:1
func (t *A_arbace_a2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_12.GetRawRoot__O()).Invoke_O__O(dir__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_45.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_47.GetRawRoot__O()).Invoke__O(); var tmp3 any; if






	jrt.NN(jrt.File_Cast(base__2)).IsDirectory__Z() { var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_New_O(base__2); var tmp5 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_fn_class
		if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_fn_class = fncls__38d; tmp5 = fncls__38d } else { tmp5 = fncls__38 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_31.GetRawRoot__O()).Invoke_O__O(base__2)) } else {
//line :193:1
			tmp3 = nil }; return /*line :192:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_New_O(p0 any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_data_iter__1520000152__1520000156_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) Invoke_O_O__O(self, s__1520000153__1 any) any { var tmp1 any = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_New_O_O_O(t.F_base, s__1520000153__1, self); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :194:1
func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) Ctor_O_O_O(c__base, c__s__1520000153, c__iter__1520000152 any) { t.F_base = c__base; t.F_s__1520000153 = c__s__1520000153; t.F_iter__1520000152 = c__iter__1520000152 }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) Invoke_O__O(self any) any { { var s__1520000153__1 any; var t_ any = t.F_s__1520000153; t.F_s__1520000153 = nil; s__1520000153__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000153__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000153__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000153__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000153__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000155__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_New_O_I_O_O(t.F_base, size__1927001038__auto____5, c__1927001037__auto____4, b__1520000155__6); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000152); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000155__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000153__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000155__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000153__3); if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_81.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())); var tmp7 *jrt.String; jrt.File_Init(); tmp7 = jrt.File_separator; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1520000152); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp5.Invoke_O_O_O__O(tmp6, tmp7.Ref(), Lit_7), f__4), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000153__3))) } else { s__1520000153__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000153__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :194:1
func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) Ctor_O_I_O_O(c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1520000155 any) { t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1520000155 = c__b__1520000155 }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) Invoke_O__O(self any) any { { var i__1520000154__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000154__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1520000155; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_81.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())); var tmp6 *jrt.String; jrt.File_Init(); tmp6 = jrt.File_separator; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(tmp4.Invoke_O_O_O__O(tmp5, tmp6.Ref(), Lit_7), f__2)); i__1520000154__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000154__1); continue L1 } else { i__1520000154__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000154__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

















func A_arbace_a2g_embed_image_type_forms_A_New() *A_arbace_a2g_embed_image_type_forms_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_a2g_embed_image_type_forms_A) Ctor() {}
//line :212:1
func (t *A_arbace_a2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any = A_arbace_a2g_embed_A_const_96; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_New_O(prog_dir__0); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_fn_class; if





	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); files__3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_a2g_embed_A_const_97); var types__4 any; var tmp3 lang.IFn = /*line :212:1*/lang.IFn_Cast(A_arbace_a2g_embed_A_const_83.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_embed_A_const_82.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_85.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_86.GetRawRoot__O()).Invoke__O(); var tmp7 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_New_O(re__2); var tmp8 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_fn_class; if












	fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_fn_class = fncls__47d; tmp8 = fncls__47d } else { tmp8 = fncls__47 }; types__4 = tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O_O__O(tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), files__3)); var tmp9 lang.IFn =



	lang.IFn_Cast(A_arbace_a2g_embed_A_const_45.GetRawRoot__O()); var tmp10 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_embed_A_const_108, Lit_18, A_arbace_a2g_embed_A_const_109, A_arbace_a2g_embed_A_const_110)); var tmp11 any; var iter__1927001039__auto____5 any; var tmp12 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_New(); var tmp13 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_fn_class; if
	fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_fn_class = fncls__56d; tmp13 = fncls__56d } else { tmp13 = fncls__56 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_111.GetRawRoot__O()); var tmp15 any = A_arbace_a2g_embed_A_const_112; tmp11 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_a2g_embed_A_const_46.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_18.GetRawRoot__O(), lang.IFn_Cast(A_arbace_a2g_embed_A_const_92.GetRawRoot__O()).Invoke_O__O(types__4)))); return /*line :229:1*/ tmp9.Invoke_O_O__O(tmp10, tmp11) }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A{}; t.Ctor_O(p0); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) Invoke_O_O__O(self, s__1520000164__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_New_O_O_O(t.F_prog_dir, s__1520000164__1, self); var tmp2 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_fn_class = fncls__42d; tmp2 = fncls__42d } else { tmp2 = fncls__42 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) Ctor_O_O_O(c__prog_dir, c__s__1520000164, c__iter__1520000163 any) { t.F_prog_dir = c__prog_dir; t.F_s__1520000164 = c__s__1520000164; t.F_iter__1520000163 = c__iter__1520000163 }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) Invoke_O__O(self any) any { { var s__1520000164__1 any; var t_ any = t.F_s__1520000164; t.F_s__1520000164 = nil; s__1520000164__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000164__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1520000171__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var pkg__5 any = lang.RT_Nth_O_I_O__O(vec__1520000171__4, lang.RT_IntCast_J__I(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O(vec__1520000171__4, lang.RT_IntCast_J__I(1), nil); var dir__7 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_24, pkg__5); var iterys__1927001035__auto____8 any; var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_New_O(alias__6); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____9 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_91.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(dir__7)).ListFiles__File1().Ref()))); if jrt.A2g_Truth(fs__1927001036__auto____9) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000163); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_82.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____9, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000164__1))) } else { s__1520000164__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000164__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A{}; t.Ctor_O(p0); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) Invoke_O_O__O(self, s__1520000166__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_New_O_O_O(t.F_alias, s__1520000166__1, self); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) Ctor_O_O_O(c__alias, c__s__1520000166, c__iter__1520000165 any) { t.F_alias = c__alias; t.F_s__1520000166 = c__s__1520000166; t.F_iter__1520000165 = c__iter__1520000165 }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) Invoke_O__O(self any) any { { var s__1520000166__1 any; var t_ any = t.F_s__1520000166; t.F_s__1520000166 = nil; s__1520000166__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000166__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000166__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000166__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000166__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000168__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_New_O_O_I_O(b__1520000168__6, t.F_alias, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_fn_class = fncls__39d; tmp2 = fncls__39d } else { tmp2 = fncls__39 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000165); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000168__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000166__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000168__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000166__3); var tmp4 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_28); if jrt.A2g_Truth(and__1927000168__auto____6) {
		tmp4 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_29)) } else {
//line :221:1
			tmp4 = and__1927000168__auto____6 } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :218:1
	if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1520000165); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000166__3))) } else { s__1520000166__1 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000166__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) Ctor_O_O_I_O(c__b__1520000168, c__alias any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000168 = c__b__1520000168; t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) Invoke_O__O(self any) any { { var i__1520000167__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000167__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_28); if jrt.A2g_Truth(and__1927000168__auto____4) {
		tmp2 = lang.IFn_Cast(A_arbace_a2g_embed_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_17.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_29)) } else {
//line :221:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :218:1
	if jrt.A2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp4 any = t.F_b__1520000168; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2)); i__1520000167__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000167__1); continue L1 } else { i__1520000167__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000167__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) Invoke_O_O__O(self, p__1520000182__1 any) any { var vec__1520000184__2 any = p__1520000182__1; var alias__3 any = lang.RT_Nth_O_I_O__O(vec__1520000184__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__1520000184__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_90.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____5 any; var tmp3 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_New_O(alias__3); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_99.GetRawRoot__O()); var tmp6 any = t.F_re; tmp2 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_a2g_embed_A_const_23.GetRawRoot__O()).Invoke_O__O(f__4))); return tmp1.Invoke_O__O(tmp2) }
//line :225:1
func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) Invoke_O_O__O(self, s__1520000188__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_New_O_O_O(t.F_alias, s__1520000188__1, self); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :225:1
func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) Ctor_O_O_O(c__alias, c__s__1520000188, c__iter__1520000187 any) { t.F_alias = c__alias; t.F_s__1520000188 = c__s__1520000188; t.F_iter__1520000187 = c__iter__1520000187 }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) Invoke_O__O(self any) any { { var s__1520000188__1 any; var t_ any = t.F_s__1520000188; t.F_s__1520000188 = nil; s__1520000188__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000188__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000188__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000188__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000188__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000190__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_New_O_O_I_O(t.F_alias, b__1520000190__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000187); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000190__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000188__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000190__6), nil) } } else { var vec__1520000198__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000188__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1520000198__4, lang.RT_IntCast_J__I(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O(vec__1520000198__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1520000187); _ = ___5; return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_98.GetRawRoot__O()).Invoke_O_O__O(t.F_alias, n__6), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000188__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :225:1
func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) Ctor_O_O_I_O(c__alias, c__b__1520000190 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_b__1520000190 = c__b__1520000190; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) Invoke_O__O(self any) any { { var i__1520000189__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000189__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1520000194__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000189__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__1520000194__2, lang.RT_IntCast_J__I(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O(vec__1520000194__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1520000190; _ = ___3; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_a2g_embed_A_const_98.GetRawRoot__O()).Invoke_O_O__O(t.F_alias, n__4)); i__1520000189__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000189__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_New() *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) Ctor() {}
//line :230:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) Invoke_O_O__O(self, s__1520000205__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_New_O_O(self, s__1520000205__1); var tmp2 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_fn_class = fncls__55d; tmp2 = fncls__55d } else { tmp2 = fncls__55 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :230:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) Ctor_O_O(c__iter__1520000204, c__s__1520000205 any) { t.F_iter__1520000204 = c__iter__1520000204; t.F_s__1520000205 = c__s__1520000205 }
//line :230:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) Invoke_O__O(self any) any { { var s__1520000205__1 any; var t_ any = t.F_s__1520000205; t.F_s__1520000205 = nil; s__1520000205__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000205__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000205__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000205__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000205__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000207__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_New_O_I_O(b__1520000207__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_fn_class = fncls__51d; tmp2 = fncls__51d } else { tmp2 = fncls__51 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000204); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000207__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000205__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000207__6), nil) } } else { var part__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000205__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_embed_A_const_101; var tmp7 any = A_arbace_a2g_embed_A_const_102; var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; var tmp9 any = tmp8.Ref(); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_embed_A_const_103; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_83.GetRawRoot__O()); var tmp13 any = A_arbace_a2g_embed_A_const_100.GetRawRoot__O(); var tmp14 any = A_arbace_a2g_embed_A_const_104; var tmp15 any = A_arbace_a2g_embed_A_const_105; var tmp16 any; var iter__1927001039__auto____5 any; var tmp17 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A_New(); var tmp18 *jrt.Class
															var fncls__54 /*line :230:1*/*jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A_fn_class



	if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A_fn_class = fncls__54d; tmp18 = fncls__54d } else { tmp18 = fncls__54 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(part__4)
//line :230:1
	var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__1520000204); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O_O_O__O(tmp13, tmp14, tmp15, tmp16))), tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000205__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :230:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) Ctor_O_I_O(c__b__1520000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000207 = c__b__1520000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :230:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) Invoke_O__O(self any) any { { var i__1520000206__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var part__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000206__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1520000207; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_embed_A_const_101; var tmp6 any = A_arbace_a2g_embed_A_const_102; var tmp7 *lang.PersistentVector; lang.PersistentVector_Init(); tmp7 = lang.PersistentVector_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp10 any = A_arbace_a2g_embed_A_const_103; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_83.GetRawRoot__O()); var tmp12 any = A_arbace_a2g_embed_A_const_100.GetRawRoot__O(); var tmp13 any = A_arbace_a2g_embed_A_const_104; var tmp14 any = A_arbace_a2g_embed_A_const_105; var tmp15 any; var iter__1927001039__auto____3 any; var tmp16 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A_New(); var tmp17 *jrt.Class
																	var fncls__50 /*line :230:1*/*jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A_fn_class



	if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A_fn_class = fncls__50d; tmp17 = fncls__50d } else { tmp17 = fncls__50 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); tmp15 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(part__2)
//line :230:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, tmp15)))); i__1520000206__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000206__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A_New() *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A) Ctor() {}
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A) Invoke_O_O__O(self, s__1520000212__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A_New_O_O(s__1520000212__1, self); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :234:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A{}; t.Ctor_O_O(p0, p1); return t }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A) Ctor_O_O(c__s__1520000212, c__iter__1520000211 any) { t.F_s__1520000212 = c__s__1520000212; t.F_iter__1520000211 = c__iter__1520000211 }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A) Invoke_O__O(self any) any { { var s__1520000212__1 any; var t_ any = t.F_s__1520000212; t.F_s__1520000212 = nil; s__1520000212__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000212__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000212__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000212__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000212__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000214__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A_New_O_I_O(b__1520000214__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000211); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000214__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000212__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000214__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000212__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_embed_A_const_106; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1520000211); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_107, t__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000212__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :234:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A) Ctor_O_I_O(c__b__1520000214 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000214 = c__b__1520000214; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A) Invoke_O__O(self any) any { { var i__1520000213__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000213__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000213__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1520000214; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_embed_A_const_106; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_107, t__2))); i__1520000213__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000213__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }
//line :234:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A_New() *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A) Ctor() {}
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A) Invoke_O_O__O(self, s__1520000223__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A_New_O_O(s__1520000223__1, self); var tmp2 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A_fn_class = fncls__53d; tmp2 = fncls__53d } else { tmp2 = fncls__53 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :234:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A{}; t.Ctor_O_O(p0, p1); return t }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A) Ctor_O_O(c__s__1520000223, c__iter__1520000222 any) { t.F_s__1520000223 = c__s__1520000223; t.F_iter__1520000222 = c__iter__1520000222 }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A) Invoke_O__O(self any) any { { var s__1520000223__1 any; var t_ any = t.F_s__1520000223; t.F_s__1520000223 = nil; s__1520000223__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_13.GetRawRoot__O()).Invoke_O__O(s__1520000223__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000223__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_embed_A_const_14.GetRawRoot__O()).Invoke_O__O(s__1520000223__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_15.GetRawRoot__O()).Invoke_O__O(s__1520000223__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000225__6 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_16.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A_New_O_I_O(b__1520000225__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1520000222); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000225__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1520000223__3))) } else { return lang.IFn_Cast(A_arbace_a2g_embed_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_27.GetRawRoot__O()).Invoke_O__O(b__1520000225__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_a2g_embed_A_const_25.GetRawRoot__O()).Invoke_O__O(s__1520000223__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_embed_A_const_106; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1520000222); return lang.IFn_Cast(A_arbace_a2g_embed_A_const_26.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_107, t__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_embed_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1520000223__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :234:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A) Ctor_O_I_O(c__b__1520000225 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000225 = c__b__1520000225; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :234:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A) Invoke_O__O(self any) any { { var i__1520000224__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000224__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000224__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_22.GetRawRoot__O()); var tmp3 any = t.F_b__1520000225; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_embed_A_const_106; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_a2g_embed_A_const_100.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_embed_A_const_107, t__2))); i__1520000224__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000224__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





















































































































































































































type A_arbace_a2g_embed_A struct{ jrt.Object }

var A_arbace_a2g_embed_A_const_pool *jrt.RefArray

var A_arbace_a2g_embed_A_const_0 *lang.Var

var A_arbace_a2g_embed_A_const_1 *lang.Var

var A_arbace_a2g_embed_A_const_2 any

var A_arbace_a2g_embed_A_const_3 any

var A_arbace_a2g_embed_A_const_4 any

var A_arbace_a2g_embed_A_const_5 any

var A_arbace_a2g_embed_A_const_6 any

var A_arbace_a2g_embed_A_const_7 *lang.Var

var A_arbace_a2g_embed_A_const_8 *lang.Var

var A_arbace_a2g_embed_A_const_9 *lang.Var

var A_arbace_a2g_embed_A_const_10 any

var A_arbace_a2g_embed_A_const_11 *lang.Var

var A_arbace_a2g_embed_A_const_12 *lang.Var

var A_arbace_a2g_embed_A_const_13 *lang.Var

var A_arbace_a2g_embed_A_const_14 *lang.Var

var A_arbace_a2g_embed_A_const_15 *lang.Var

var A_arbace_a2g_embed_A_const_16 *lang.Var

var A_arbace_a2g_embed_A_const_17 *lang.Var

var A_arbace_a2g_embed_A_const_18 *lang.Var

var A_arbace_a2g_embed_A_const_19 *lang.Var

var A_arbace_a2g_embed_A_const_20 *lang.Var

var A_arbace_a2g_embed_A_const_21 *lang.Var

var A_arbace_a2g_embed_A_const_22 *lang.Var

var A_arbace_a2g_embed_A_const_23 *lang.Var

var A_arbace_a2g_embed_A_const_24 *lang.Var

var A_arbace_a2g_embed_A_const_25 *lang.Var

var A_arbace_a2g_embed_A_const_26 *lang.Var

var A_arbace_a2g_embed_A_const_27 *lang.Var

var A_arbace_a2g_embed_A_const_28 *lang.Var

var A_arbace_a2g_embed_A_const_29 *lang.Var

var A_arbace_a2g_embed_A_const_30 *lang.Var

var A_arbace_a2g_embed_A_const_31 *lang.Var

var A_arbace_a2g_embed_A_const_32 *lang.Var

var A_arbace_a2g_embed_A_const_33 *lang.Var

var A_arbace_a2g_embed_A_const_34 *lang.Var

var A_arbace_a2g_embed_A_const_35 *lang.Var

var A_arbace_a2g_embed_A_const_36 *lang.Keyword

var A_arbace_a2g_embed_A_const_37 *lang.Var

var A_arbace_a2g_embed_A_const_38 any

var A_arbace_a2g_embed_A_const_39 any

var A_arbace_a2g_embed_A_const_40 *lang.Var

var A_arbace_a2g_embed_A_const_41 *lang.Var

var A_arbace_a2g_embed_A_const_42 *lang.Var

var A_arbace_a2g_embed_A_const_43 *lang.Var

var A_arbace_a2g_embed_A_const_44 *lang.Var

var A_arbace_a2g_embed_A_const_45 *lang.Var

var A_arbace_a2g_embed_A_const_46 *lang.Var

var A_arbace_a2g_embed_A_const_47 *lang.Var

var A_arbace_a2g_embed_A_const_48 any

var A_arbace_a2g_embed_A_const_49 *lang.Var

var A_arbace_a2g_embed_A_const_50 *lang.Keyword

var A_arbace_a2g_embed_A_const_51 *lang.Var

var A_arbace_a2g_embed_A_const_52 *lang.Var

var A_arbace_a2g_embed_A_const_53 *lang.Var

var A_arbace_a2g_embed_A_const_54 *lang.Var

var A_arbace_a2g_embed_A_const_55 *lang.Var

var A_arbace_a2g_embed_A_const_56 *lang.Var

var A_arbace_a2g_embed_A_const_57 *lang.Var

var A_arbace_a2g_embed_A_const_58 any

var A_arbace_a2g_embed_A_const_59 *lang.Var

var A_arbace_a2g_embed_A_const_60 *lang.Var

var A_arbace_a2g_embed_A_const_61 *lang.Var

var A_arbace_a2g_embed_A_const_62 *lang.Var

var A_arbace_a2g_embed_A_const_63 *lang.Var

var A_arbace_a2g_embed_A_const_64 *lang.Var

var A_arbace_a2g_embed_A_const_65 *lang.Var

var A_arbace_a2g_embed_A_const_66 *lang.Var

var A_arbace_a2g_embed_A_const_67 *lang.Var

var A_arbace_a2g_embed_A_const_68 *lang.Var

var A_arbace_a2g_embed_A_const_69 *lang.Var

var A_arbace_a2g_embed_A_const_70 *lang.Var

var A_arbace_a2g_embed_A_const_71 *lang.Var

var A_arbace_a2g_embed_A_const_72 *lang.Var

var A_arbace_a2g_embed_A_const_73 *lang.Var

var A_arbace_a2g_embed_A_const_74 *lang.Var

var A_arbace_a2g_embed_A_const_75 *lang.Var

var A_arbace_a2g_embed_A_const_76 *lang.Var

var A_arbace_a2g_embed_A_const_77 *lang.Var

var A_arbace_a2g_embed_A_const_78 any

var A_arbace_a2g_embed_A_const_79 any

var A_arbace_a2g_embed_A_const_80 *lang.Keyword

var A_arbace_a2g_embed_A_const_81 *lang.Var

var A_arbace_a2g_embed_A_const_82 *lang.Var

var A_arbace_a2g_embed_A_const_83 *lang.Var

var A_arbace_a2g_embed_A_const_84 *lang.Var

var A_arbace_a2g_embed_A_const_85 *lang.Var

var A_arbace_a2g_embed_A_const_86 *lang.Var

var A_arbace_a2g_embed_A_const_87 *lang.Var

var A_arbace_a2g_embed_A_const_88 *lang.Var

var A_arbace_a2g_embed_A_const_89 *lang.Var

var A_arbace_a2g_embed_A_const_90 *lang.Var

var A_arbace_a2g_embed_A_const_91 *lang.Var

var A_arbace_a2g_embed_A_const_92 *lang.Var

var A_arbace_a2g_embed_A_const_93 any

var A_arbace_a2g_embed_A_const_94 *lang.Var

var A_arbace_a2g_embed_A_const_95 *lang.Keyword

var A_arbace_a2g_embed_A_const_96 any

var A_arbace_a2g_embed_A_const_97 any

var A_arbace_a2g_embed_A_const_98 *lang.Var

var A_arbace_a2g_embed_A_const_99 *lang.Var

var A_arbace_a2g_embed_A_const_100 *lang.Var

var A_arbace_a2g_embed_A_const_101 any

var A_arbace_a2g_embed_A_const_102 any

var A_arbace_a2g_embed_A_const_103 any

var A_arbace_a2g_embed_A_const_104 any

var A_arbace_a2g_embed_A_const_105 any

var A_arbace_a2g_embed_A_const_106 any

var A_arbace_a2g_embed_A_const_107 any

var A_arbace_a2g_embed_A_const_108 any

var A_arbace_a2g_embed_A_const_109 *lang.Keyword

var A_arbace_a2g_embed_A_const_110 any

var A_arbace_a2g_embed_A_const_111 *lang.Var

var A_arbace_a2g_embed_A_const_112 any

var A_arbace_a2g_embed_A_init jrt.ClassInit

func A_arbace_a2g_embed_A_Init() { if !A_arbace_a2g_embed_A_init.Done() { A_arbace_a2g_embed_A_init.Run(A_arbace_a2g_embed_A_clinit) } }

func A_arbace_a2g_embed_A_clinit() { A_arbace_a2g_embed_A_clinit_p0(); A_arbace_a2g_embed_A_clinit_p1(); A_arbace_a2g_embed_A_clinit_p2(); A_arbace_a2g_embed_A_clinit_p3(); A_arbace_a2g_embed_A_clinit_p4(); A_arbace_a2g_embed_A_clinit_p5(); A_arbace_a2g_embed_A_clinit_p6(); A_arbace_a2g_embed_A_clinit_p7(); A_arbace_a2g_embed_A_clinit_p8(); A_arbace_a2g_embed_A_clinit_p9() }

func A_arbace_a2g_embed_A_clinit_p0() { A_arbace_a2g_embed_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 146); A_arbace_a2g_embed_A_const_0 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[33]); A_arbace_a2g_embed_A_const_1 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[34]); A_arbace_a2g_embed_A_const_2 = A_arbace_a2g_embed_A_const_pool.A[35]; A_arbace_a2g_embed_A_const_3 = A_arbace_a2g_embed_A_const_pool.A[36]; A_arbace_a2g_embed_A_const_4 = A_arbace_a2g_embed_A_const_pool.A[37]; A_arbace_a2g_embed_A_const_5 = A_arbace_a2g_embed_A_const_pool.A[38]; A_arbace_a2g_embed_A_const_6 = A_arbace_a2g_embed_A_const_pool.A[39]; A_arbace_a2g_embed_A_const_7 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[40]); A_arbace_a2g_embed_A_const_8 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[41]); A_arbace_a2g_embed_A_const_9 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[42]); A_arbace_a2g_embed_A_const_10 = A_arbace_a2g_embed_A_const_pool.A[43]; A_arbace_a2g_embed_A_const_11 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[44]); A_arbace_a2g_embed_A_const_12 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[45]) }

func A_arbace_a2g_embed_A_clinit_p1() { A_arbace_a2g_embed_A_const_13 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[46]); A_arbace_a2g_embed_A_const_14 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[47]); A_arbace_a2g_embed_A_const_15 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[48]); A_arbace_a2g_embed_A_const_16 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[49]); A_arbace_a2g_embed_A_const_17 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[50]); A_arbace_a2g_embed_A_const_18 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[51]); A_arbace_a2g_embed_A_const_19 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[52]); A_arbace_a2g_embed_A_const_20 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[53]); A_arbace_a2g_embed_A_const_21 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[54]); A_arbace_a2g_embed_A_const_22 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[55]); A_arbace_a2g_embed_A_const_23 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[56]); A_arbace_a2g_embed_A_const_24 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[57]) }

func A_arbace_a2g_embed_A_clinit_p2() { A_arbace_a2g_embed_A_const_25 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[58]); A_arbace_a2g_embed_A_const_26 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[59]); A_arbace_a2g_embed_A_const_27 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[60]); A_arbace_a2g_embed_A_const_28 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[61]); A_arbace_a2g_embed_A_const_29 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[62]); A_arbace_a2g_embed_A_const_30 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[63]); A_arbace_a2g_embed_A_const_31 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[64]); A_arbace_a2g_embed_A_const_32 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[65]); A_arbace_a2g_embed_A_const_33 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[66]); A_arbace_a2g_embed_A_const_34 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[67]); A_arbace_a2g_embed_A_const_35 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[68]); A_arbace_a2g_embed_A_const_36 = lang.Keyword_Cast(A_arbace_a2g_embed_A_const_pool.A[69]) }

func A_arbace_a2g_embed_A_clinit_p3() { A_arbace_a2g_embed_A_const_37 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[70]); A_arbace_a2g_embed_A_const_38 = A_arbace_a2g_embed_A_const_pool.A[71]; A_arbace_a2g_embed_A_const_39 = A_arbace_a2g_embed_A_const_pool.A[72]; A_arbace_a2g_embed_A_const_40 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[73]); A_arbace_a2g_embed_A_const_41 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[74]); A_arbace_a2g_embed_A_const_42 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[75]); A_arbace_a2g_embed_A_const_43 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[76]); A_arbace_a2g_embed_A_const_44 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[77]); A_arbace_a2g_embed_A_const_45 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[78]); A_arbace_a2g_embed_A_const_46 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[79]); A_arbace_a2g_embed_A_const_47 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[80]); A_arbace_a2g_embed_A_const_48 = A_arbace_a2g_embed_A_const_pool.A[81] }

func A_arbace_a2g_embed_A_clinit_p4() { A_arbace_a2g_embed_A_const_49 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[82]); A_arbace_a2g_embed_A_const_50 = lang.Keyword_Cast(A_arbace_a2g_embed_A_const_pool.A[83]); A_arbace_a2g_embed_A_const_51 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[84]); A_arbace_a2g_embed_A_const_52 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[85]); A_arbace_a2g_embed_A_const_53 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[86]); A_arbace_a2g_embed_A_const_54 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[87]); A_arbace_a2g_embed_A_const_55 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[88]); A_arbace_a2g_embed_A_const_56 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[89]); A_arbace_a2g_embed_A_const_57 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[90]); A_arbace_a2g_embed_A_const_58 = A_arbace_a2g_embed_A_const_pool.A[91]; A_arbace_a2g_embed_A_const_59 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[92]); A_arbace_a2g_embed_A_const_60 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[93]) }

func A_arbace_a2g_embed_A_clinit_p5() { A_arbace_a2g_embed_A_const_61 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[94]); A_arbace_a2g_embed_A_const_62 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[95]); A_arbace_a2g_embed_A_const_63 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[96]); A_arbace_a2g_embed_A_const_64 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[97]); A_arbace_a2g_embed_A_const_65 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[98]); A_arbace_a2g_embed_A_const_66 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[99]); A_arbace_a2g_embed_A_const_67 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[100]); A_arbace_a2g_embed_A_const_68 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[101]); A_arbace_a2g_embed_A_const_69 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[102]); A_arbace_a2g_embed_A_const_70 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[103]); A_arbace_a2g_embed_A_const_71 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[104]); A_arbace_a2g_embed_A_const_72 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[105]) }

func A_arbace_a2g_embed_A_clinit_p6() { A_arbace_a2g_embed_A_const_73 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[106]); A_arbace_a2g_embed_A_const_74 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[107]); A_arbace_a2g_embed_A_const_75 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[108]); A_arbace_a2g_embed_A_const_76 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[109]); A_arbace_a2g_embed_A_const_77 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[110]); A_arbace_a2g_embed_A_const_78 = A_arbace_a2g_embed_A_const_pool.A[111]; A_arbace_a2g_embed_A_const_79 = A_arbace_a2g_embed_A_const_pool.A[112]; A_arbace_a2g_embed_A_const_80 = lang.Keyword_Cast(A_arbace_a2g_embed_A_const_pool.A[113]); A_arbace_a2g_embed_A_const_81 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[114]); A_arbace_a2g_embed_A_const_82 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[115]); A_arbace_a2g_embed_A_const_83 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[116]); A_arbace_a2g_embed_A_const_84 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[117]) }

func A_arbace_a2g_embed_A_clinit_p7() { A_arbace_a2g_embed_A_const_85 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[118]); A_arbace_a2g_embed_A_const_86 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[119]); A_arbace_a2g_embed_A_const_87 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[120]); A_arbace_a2g_embed_A_const_88 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[121]); A_arbace_a2g_embed_A_const_89 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[122]); A_arbace_a2g_embed_A_const_90 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[123]); A_arbace_a2g_embed_A_const_91 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[124]); A_arbace_a2g_embed_A_const_92 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[125]); A_arbace_a2g_embed_A_const_93 = A_arbace_a2g_embed_A_const_pool.A[126]; A_arbace_a2g_embed_A_const_94 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[127]); A_arbace_a2g_embed_A_const_95 = lang.Keyword_Cast(A_arbace_a2g_embed_A_const_pool.A[128]); A_arbace_a2g_embed_A_const_96 = A_arbace_a2g_embed_A_const_pool.A[129] }

func A_arbace_a2g_embed_A_clinit_p8() { A_arbace_a2g_embed_A_const_97 = A_arbace_a2g_embed_A_const_pool.A[130]; A_arbace_a2g_embed_A_const_98 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[131]); A_arbace_a2g_embed_A_const_99 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[132]); A_arbace_a2g_embed_A_const_100 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[133]); A_arbace_a2g_embed_A_const_101 = A_arbace_a2g_embed_A_const_pool.A[134]; A_arbace_a2g_embed_A_const_102 = A_arbace_a2g_embed_A_const_pool.A[135]; A_arbace_a2g_embed_A_const_103 = A_arbace_a2g_embed_A_const_pool.A[136]; A_arbace_a2g_embed_A_const_104 = A_arbace_a2g_embed_A_const_pool.A[137]; A_arbace_a2g_embed_A_const_105 = A_arbace_a2g_embed_A_const_pool.A[138]; A_arbace_a2g_embed_A_const_106 = A_arbace_a2g_embed_A_const_pool.A[139]; A_arbace_a2g_embed_A_const_107 = A_arbace_a2g_embed_A_const_pool.A[140]; A_arbace_a2g_embed_A_const_108 = A_arbace_a2g_embed_A_const_pool.A[141]; A_arbace_a2g_embed_A_const_109 = lang.Keyword_Cast(A_arbace_a2g_embed_A_const_pool.A[142]); A_arbace_a2g_embed_A_const_110 = A_arbace_a2g_embed_A_const_pool.A[143] }

func A_arbace_a2g_embed_A_clinit_p9() { A_arbace_a2g_embed_A_const_111 = lang.Var_Cast(A_arbace_a2g_embed_A_const_pool.A[144]); A_arbace_a2g_embed_A_const_112 = A_arbace_a2g_embed_A_const_pool.A[145] }

func A_arbace_a2g_embed_A_New() *A_arbace_a2g_embed_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_embed_A) Ctor() {}

func (t *A_arbace_a2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_A_class }

func (t *A_arbace_a2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_A); return ok }

func A_arbace_a2g_embed_A_Cast(x any) *A_arbace_a2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_A_class)) }; return v }



type A_arbace_a2g_embed_class_like_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_class_like_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_embed_cut_candidates_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_cut_candidates_A_fn_class *jrt.Class



type A_arbace_a2g_embed_cut_candidates_fn__1520000103_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_fn_class *jrt.Class



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_fn_class *jrt.Class



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A struct{ a2g_header uint64; F_s__1520000089, F_iter__1520000088 any }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_fn_class *jrt.Class



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A struct{ a2g_header uint64; F_b__1520000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_fn_class *jrt.Class



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_fn_class *jrt.Class



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_fn_class *jrt.Class



type A_arbace_a2g_embed_data_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_data_A_fn_class *jrt.Class



type A_arbace_a2g_embed_data_iter__1520000152__1520000156_A struct{ a2g_header uint64; F_base any }

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_fn_class *jrt.Class



type A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A struct{ a2g_header uint64; F_base, F_s__1520000153, F_iter__1520000152 any }

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_fn_class *jrt.Class



type A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A struct{ a2g_header uint64; F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1520000155 any }

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_fn_class *jrt.Class



type A_arbace_a2g_embed_eval1520000004_A struct{ jrt.Object }

func A_arbace_a2g_embed_eval1520000004_A_New() *A_arbace_a2g_embed_eval1520000004_A { t := &A_arbace_a2g_embed_eval1520000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_embed_eval1520000004_A) Ctor() {}

func (t *A_arbace_a2g_embed_eval1520000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_eval1520000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_eval1520000004_A_class }

func (t *A_arbace_a2g_embed_eval1520000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_eval1520000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_eval1520000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_eval1520000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_eval1520000004_A); return ok }

func A_arbace_a2g_embed_eval1520000004_A_Cast(x any) *A_arbace_a2g_embed_eval1520000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_eval1520000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_eval1520000004_A_class)) }; return v }



type A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_fn_class *jrt.Class



type A_arbace_a2g_embed_eval1520000008_A struct{ jrt.Object }

func A_arbace_a2g_embed_eval1520000008_A_New() *A_arbace_a2g_embed_eval1520000008_A { t := &A_arbace_a2g_embed_eval1520000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_embed_eval1520000008_A) Ctor() {}

func (t *A_arbace_a2g_embed_eval1520000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_eval1520000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_eval1520000008_A_class }

func (t *A_arbace_a2g_embed_eval1520000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_eval1520000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_eval1520000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_eval1520000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_eval1520000008_A); return ok }

func A_arbace_a2g_embed_eval1520000008_A_Cast(x any) *A_arbace_a2g_embed_eval1520000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_eval1520000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_eval1520000008_A_class)) }; return v }



type A_arbace_a2g_embed_eval1520000008_fn__1520000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_image_type_forms_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_A struct{ a2g_header uint64; F_re any }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A struct{ a2g_header uint64; F_alias any }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A struct{ a2g_header uint64; F_alias, F_s__1520000188, F_iter__1520000187 any }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A struct{ a2g_header uint64; F_alias, F_b__1520000190 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A struct{ a2g_header uint64; F_prog_dir any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A struct{ a2g_header uint64; F_prog_dir, F_s__1520000164, F_iter__1520000163 any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A struct{ a2g_header uint64; F_alias any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A struct{ a2g_header uint64; F_alias, F_s__1520000166, F_iter__1520000165 any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A struct{ a2g_header uint64; F_b__1520000168, F_alias any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A struct{ a2g_header uint64; F_iter__1520000204, F_s__1520000205 any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A struct{ a2g_header uint64; F_b__1520000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A struct{ a2g_header uint64; F_s__1520000212, F_iter__1520000211 any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A struct{ a2g_header uint64; F_b__1520000214 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_iter__1520000211__1520000215_fn__1520000216_fn__1520000217_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A struct{ a2g_header uint64; F_s__1520000223, F_iter__1520000222 any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_A_fn_class *jrt.Class



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A struct{ a2g_header uint64; F_b__1520000225 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_iter__1520000222__1520000226_fn__1520000227_fn__1520000228_A_fn_class *jrt.Class



type A_arbace_a2g_embed_names_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_names_A_fn_class *jrt.Class



type A_arbace_a2g_embed_names_walk__1520000059_A struct{ a2g_header uint64; F_acc any }

var A_arbace_a2g_embed_names_walk__1520000059_A_fn_class *jrt.Class



type A_arbace_a2g_embed_package_like_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_package_like_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_embed_read_all_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_read_all_A_fn_class *jrt.Class



type A_arbace_a2g_embed_read_all_fn__1520000054_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_read_all_fn__1520000054_A_fn_class *jrt.Class



type A_arbace_a2g_embed_reify__1520000052_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_a2g_embed_reify__1520000052_A) Is_LispReader_Resolver() {}

func (t *A_arbace_a2g_embed_reify__1520000052_A) Is_IObj() {}

func (t *A_arbace_a2g_embed_reify__1520000052_A) Is_IMeta() {}

func (t *A_arbace_a2g_embed_reify__1520000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_reify__1520000052_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_reify__1520000052_A_class }

func (t *A_arbace_a2g_embed_reify__1520000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_reify__1520000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_reify__1520000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_reify__1520000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_reify__1520000052_A); return ok }

func A_arbace_a2g_embed_reify__1520000052_A_Cast(x any) *A_arbace_a2g_embed_reify__1520000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_reify__1520000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_reify__1520000052_A_class)) }; return v }



type A_arbace_a2g_embed_sources_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_sources_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_fn__1520000038_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_sources_fn__1520000038_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A struct{ a2g_header uint64; F_p, F_pairs, F_rel any }

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A struct{ a2g_header uint64; F_p, F_rel any }

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A struct{ a2g_header uint64; F_base any }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A struct{ a2g_header uint64; F_base, F_s__1520000014, F_iter__1520000013 any }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A struct{ a2g_header uint64; F_b__1520000016, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A struct{ a2g_header uint64; F_rel any }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A struct{ a2g_header uint64; F_rel any }

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A struct{ a2g_header uint64; F_vdir any }

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A struct{ a2g_header uint64; F_vdir, F_s__1520000028, F_iter__1520000027 any }

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_fn_class *jrt.Class



type A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A struct{ a2g_header uint64; F_vdir, F_b__1520000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_with_member_types_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_elem__1520000117_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_with_member_types_elem__1520000117_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A struct{ a2g_header uint64; F_in_world_QMARK_, F_member_types any }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A struct{ a2g_header uint64; F_in_world_QMARK_, F_member_types, F_s__1520000134, F_iter__1520000133 any }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A struct{ a2g_header uint64; F_n, F_member_types any }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A struct{ a2g_header uint64; F_in_world_QMARK_ any }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A struct{ a2g_header uint64; F_in_world_QMARK_, F_s__1520000136, F_iter__1520000135 any }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A struct{ a2g_header uint64; F_b__1520000138, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_A struct{ a2g_header uint64; F_elem, F_types any }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A struct{ a2g_header uint64; F_n any }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A struct{ a2g_header uint64; F_s__1520000123, F_iter__1520000122 any }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A struct{ a2g_header uint64; F_b__1520000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_types__1520000109_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_with_member_types_types__1520000109_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_fn_class *jrt.Class



type A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A struct{ a2g_header uint64 }

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_fn_class *jrt.Class
