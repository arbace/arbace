//line aot_arbace_a2g_embed.ae:1
package aot_arbace_a2g_embed

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_New() *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A { A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_Init(); t := &A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp20 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_6; tmp8.Invoke_O_O_O_O__O(tmp10, tmp12, tmp14, tmp15); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_136)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_137)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_138)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_139)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp20 != nil { panic(tmp20) }; return tmp3 }
//line :1:1
func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_New() *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A { A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_Init(); t := &A_arbace_a2g_embed_eval1520000008_fn__1520000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }






































func A_arbace_a2g_embed_sources_A_New() *A_arbace_a2g_embed_sources_A { A_arbace_a2g_embed_sources_A_Init(); t := &A_arbace_a2g_embed_sources_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_a2g_embed_sources_A) Ctor() {}
//line :40:1
func (t *A_arbace_a2g_embed_sources_A) Invoke_O_O__O(self, root__0 any) any { var base__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_12; base__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(root__0, Lit_164); var files__3 any; var iter__1927001039__auto____3 any; var tmp2 any = /*line :40:1*/A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_New_O(base__2); var tmp3 *jrt.Class;



	A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_Init(); tmp3 = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_31; files__3 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(base__2)); var vdir__4 any; var tmp6 /*line :40:1*/*lang.Var;








	A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_12; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp8 = A_arbace_a2g_embed_A_const_32; vdir__4 = tmp7.Invoke_O_O__O(root__0, jrt.NN(tmp8).GetRawRoot__O()); var variants__5 any; if
	jrt.NN(jrt.File_Cast(vdir__4)).IsDirectory__Z() { var iter__1927001039__auto____5 any; var tmp9 any = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_New_O(vdir__4); var tmp10 *jrt.Class
		A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_Init(); tmp10 = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_fn_class; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_31; variants__5 = tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(vdir__4)) } else {
//line :50:1
			variants__5 = nil }; var tmp13 /*line :54:1*/*lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_30; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = A_arbace_a2g_embed_sources_fn__1520000038_A_New(); var tmp16 *jrt.Class; A_arbace_a2g_embed_sources_fn__1520000038_A_Init(); tmp16 = A_arbace_a2g_embed_sources_fn__1520000038_A_fn_class; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_45; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp20 = A_arbace_a2g_embed_A_const_47; var tmp21 any = tmp19.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke__O(), files__3); var tmp22 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp22 = A_arbace_a2g_embed_A_const_46; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp24 = A_arbace_a2g_embed_A_const_25; return tmp14.Invoke_O_O_O__O(tmp17, tmp21, tmp23.Invoke_O_O__O(jrt.NN(tmp24).GetRawRoot__O(), variants__5)) }
//line :44:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) Invoke_O_O__O(self, s__1520000014__1 any) any { var tmp1 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_New_O_O_O(t.F_base, s__1520000014__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_Init(); tmp2 = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :44:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) Ctor_O_O_O(c__base, c__s__1520000014, c__iter__1520000013 any) { t.F_base = c__base; t.F_s__1520000014 = c__s__1520000014; t.F_iter__1520000013 = c__iter__1520000013 }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) Invoke_O__O(self any) any { { var s__1520000014__1 any; var t_ any = t.F_s__1520000014; t.F_s__1520000014 = nil; s__1520000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000014__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000014__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000014__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000014__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000016__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000016__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_New_O_O_I_O(b__1520000016__6, t.F_base, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_Init(); tmp6 = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000016__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000013); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000014__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000016__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000014__3); var tmp17 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var tmp18 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_17; tmp17 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_152) } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :44:1
	if jrt.A2g_Truth(tmp17) { var rel__5 any; var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_167, nil); var tmp20 *lang.Var

		A_arbace_a2g_embed_A_Init(); tmp20 = A_arbace_a2g_embed_A_const_18; rel__5 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())))).Ref()
//line :44:1
		var tmp21 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_19; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_New_O(rel__5); var tmp24 *jrt.Class; A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_Init(); tmp24 = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_fn_class; var tmp25 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp26 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp26 = A_arbace_a2g_embed_A_const_21; if jrt.A2g_Truth(tmp22.Invoke_O_O__O(tmp25, jrt.NN(tmp26).GetRawRoot__O())) { var tmp27 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_26; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp29 = A_arbace_a2g_embed_A_const_23; var tmp30 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(f__4)); var tmp31 lang.IFn = lang.IFn_Cast(t.F_iter__1520000013); var tmp32 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp32 = A_arbace_a2g_embed_A_const_29; return tmp28.Invoke_O_O__O(tmp30, tmp31.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(s__1520000014__3))) } else { var tmp33 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp33 = A_arbace_a2g_embed_A_const_29; s__1520000014__1 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(s__1520000014__3); continue L1 } } else { var tmp34 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp34 = A_arbace_a2g_embed_A_const_29; s__1520000014__1 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(s__1520000014__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :44:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) Ctor_O_O_I_O(c__b__1520000016, c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000016 = c__b__1520000016; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :44:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) Invoke_O__O(self any) any { { var i__1520000015__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000015__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_17; tmp2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_152) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :44:1
	if jrt.A2g_Truth(tmp2) { var rel__3 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_167, nil); var tmp5 *lang.Var

		A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_18; rel__3 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())))).Ref()
//line :44:1
		var tmp6 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_19; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_New_O(rel__3); var tmp9 *jrt.Class; A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_Init(); tmp9 = A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_fn_class; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_21; if jrt.A2g_Truth(tmp7.Invoke_O_O__O(tmp10, jrt.NN(tmp11).GetRawRoot__O())) { var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_22; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = t.F_b__1520000016; var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_23; tmp13.Invoke_O_O__O(tmp14, lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(f__2))); i__1520000015__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000015__1); continue L1 } else { i__1520000015__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000015__1); continue L1 } } else { i__1520000015__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000015__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A{}; t.Ctor_O(p0); return t }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) Invoke_O_O__O(self, p1__1520000012_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_20; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_rel, p1__1520000012_SHARP___1) }
//line :47:1
func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A{}; t.Ctor_O(p0); return t }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :47:1
func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) Invoke_O_O__O(self, p1__1520000012_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_20; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_rel, p1__1520000012_SHARP___1) }



func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_New_O(p0 any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A{}; t.Ctor_O(p0); return t }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) Ctor_O(c__vdir any) { t.F_vdir = c__vdir }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) Invoke_O_O__O(self, s__1520000028__1 any) any { var tmp1 any = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_New_O_O_O(t.F_vdir, s__1520000028__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_Init(); tmp2 = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) Ctor_O_O_O(c__vdir, c__s__1520000028, c__iter__1520000027 any) { t.F_vdir = c__vdir; t.F_s__1520000028 = c__s__1520000028; t.F_iter__1520000027 = c__iter__1520000027 }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) Invoke_O__O(self any) any { { var s__1520000028__1 any; var t_ any = t.F_s__1520000028; t.F_s__1520000028 = nil; s__1520000028__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000028__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000028__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000028__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000028__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000030__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000030__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_New_O_O_I_O(t.F_vdir, b__1520000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_Init(); tmp6 = A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000030__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000027); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000028__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000030__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000028__3); var tmp17 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()
														if and__1927000168__auto____5 { var tmp18 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_17; tmp17 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_152) } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :51:1
	if jrt.A2g_Truth(tmp17) { var tmp19 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_26; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_18; var tmp22 any = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())); var tmp23 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp23 = A_arbace_a2g_embed_A_const_23; var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(f__4)); var tmp25 lang.IFn = lang.IFn_Cast(t.F_iter__1520000027); var tmp26 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp26 = A_arbace_a2g_embed_A_const_29; return tmp20.Invoke_O_O__O(tmp24, tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(s__1520000028__3))) } else { var tmp27 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_29; s__1520000028__1 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__1520000028__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :51:1
func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_Init(); t := &A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) Ctor_O_O_I_O(c__vdir, c__b__1520000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_vdir = c__vdir; t.F_b__1520000030 = c__b__1520000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :51:1
func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) Invoke_O__O(self any) any { { var i__1520000029__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000029__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()
																if and__1927000168__auto____3 { var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_17; tmp2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_152) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :51:1
	if jrt.A2g_Truth(tmp2) { var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_22; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_b__1520000030; var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_18; var tmp8 any = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_vdir)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_23; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(f__2))); i__1520000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000029__1); continue L1 } else { i__1520000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000029__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_a2g_embed_sources_fn__1520000038_A_New() *A_arbace_a2g_embed_sources_fn__1520000038_A { A_arbace_a2g_embed_sources_fn__1520000038_A_Init(); t := &A_arbace_a2g_embed_sources_fn__1520000038_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) Invoke_O_O_O__O(self, m__1, p__1520000037__2 any) any { var vec__1520000039__3 any = p__1520000037__2; var rel__4 any = lang.RT_Nth_O_I_O__O(vec__1520000039__3, lang.RT_IntCast_J__I(0), nil); var text__5 any = lang.RT_Nth_O_I_O__O(vec__1520000039__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var;
														A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(rel__4, Lit_166)) { var p__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_167, nil, Lit_152); var tmp3 *lang.Var


		A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_33; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_38; var tmp6 any = tmp5; p__6 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O_O_O__O(rel__4, tmp6, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(rel__4)), int64(lang.RT_Count_O__I(Lit_166)))).Ref()), nil)).Ref()
//line :55:1
		var pairs__7 any; var tmp7 *lang.Var



		A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_34; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_39; var tmp10 any = tmp9; var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_40; pairs__7 = tmp8.Invoke_O_O__O(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(text__5))
		var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(m__1, p__6)) { } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_42; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_168, nil, Lit_169, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6)).Ref(); var tmp16 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp16 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp14.Invoke_O_O__O(tmp15, tmp16.Ref()))))
		}
		var tmp17 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp17 = A_arbace_a2g_embed_A_const_35; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_New_O_O_O(p__6, pairs__7, rel__4); var tmp20 *jrt.Class; A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_Init(); tmp20 = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_fn_class; return tmp18.Invoke_O_O_O__O(m__1, p__6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil)) } else {
//line :55:1
			var tmp21 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(rel__4, Lit_170)) { var p__6_2 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_167, nil, Lit_152); var tmp23 *lang.Var















				A_arbace_a2g_embed_A_Init(); tmp23 = A_arbace_a2g_embed_A_const_33; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_a2g_embed_A_Init(); tmp25 = A_arbace_a2g_embed_A_const_38; var tmp26 any = tmp25; p__6_2 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp24.Invoke_O_O_O__O(rel__4, tmp26, jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(int64(lang.RT_Count_O__I(rel__4)), int64(lang.RT_Count_O__I(Lit_170)))).Ref()), nil)).Ref()
				var tmp27 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O__O(m__1, p__6_2)) { } else { var tmp28 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp28 = A_arbace_a2g_embed_A_const_42; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_168, nil, Lit_169, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4, nil, p__6_2)).Ref(); var tmp31 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp31 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp29.Invoke_O_O__O(tmp30, tmp31.Ref()))))
				}
				var tmp32 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp32 = A_arbace_a2g_embed_A_const_35; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp34 = A_arbace_a2g_embed_A_const_18; return tmp33.Invoke_O_O_O_O__O(m__1, p__6_2, jrt.NN(tmp34).GetRawRoot__O(), text__5) } else {
//line :55:1
					var tmp35 *lang.Keyword; A_arbace_a2g_embed_A_Init(); tmp35 = A_arbace_a2g_embed_A_const_36; if tmp35 != nil {



















						var tmp36 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp36 = A_arbace_a2g_embed_A_const_37; return lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O_O_O__O(m__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_167, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__4)).Ref(), text__5) } else {
//line :55:1
							return nil } } } }






func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A { A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_Init(); t := &A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :62:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) Ctor_O_O_O(c__p, c__pairs, c__rel any) { t.F_p = c__p; t.F_pairs = c__pairs; t.F_rel = c__rel }
//line :62:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) Invoke_O_O__O(self, src__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_30; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_New_O_O(t.F_p, t.F_rel); var tmp4 *jrt.Class; A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_Init(); tmp4 = A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_fn_class; return tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), src__1, t.F_pairs) }
//line :63:1
func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A { A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_Init(); t := &A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) Ctor_O_O(c__p, c__rel any) { t.F_p = c__p; t.F_rel = c__rel }
//line :63:1
func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) Invoke_O_O_O__O(self, src__1, p__1520000043__2 any) any { var vec__1520000045__3 any = p__1520000043__2; var old__4 any = lang.RT_Nth_O_I_O__O(vec__1520000045__3, lang.RT_IntCast_J__I(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O(vec__1520000045__3, lang.RT_IntCast_J__I(1), nil); var i__6 int32 = jrt.NN(jrt.String_Cast(src__1)).IndexOf_String__I(jrt.String_Cast(old__4)); var tmp1 any; var or__1927000174__auto____7 bool = lang.Numbers_IsNeg_J__Z(int64(i__6)); if or__1927000174__auto____7 {

	tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_43; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(i__6).Ref(), jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.String_Cast(src__1)).LastIndexOf_String__I(jrt.String_Cast(old__4))).Ref()) }; if jrt.A2g_Truth(tmp1) { var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_42; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_168, nil, Lit_173, nil, Lit_174, nil); var tmp6 any = t.F_rel; var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_44; var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6, nil, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(old__4), nil, t.F_p)).Ref(); var tmp9 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp9 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp4.Invoke_O_O__O(tmp8, tmp9.Ref())))) }; var tmp10 /*line :68:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_33; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_38; var tmp14 any = tmp13; var tmp15 any = tmp12.Invoke_O_O_O__O(src__1, tmp14, jrt.Integer_ValueOf_I__Integer(i__6).Ref()); var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_33; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp15, new__5, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O__O(src__1, jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(int64(i__6), int64(lang.RT_Count_O__I(old__4)))).Ref()))).Ref() }















func A_arbace_a2g_embed_reify__1520000052_A_New_IPersistentMap(p0 lang.IPersistentMap) *A_arbace_a2g_embed_reify__1520000052_A { t := &A_arbace_a2g_embed_reify__1520000052_A{}; t.Ctor_IPersistentMap(p0); return t }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) Ctor_IPersistentMap(meta__ lang.IPersistentMap) { t.F___meta = meta__ }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) ResolveVar_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) ResolveAlias_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) ResolveClass_Symbol__Symbol(s__1 *lang.Symbol) *lang.Symbol { return s__1 }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) CurrentNS__Symbol() *lang.Symbol { var tmp1 any; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_48; return lang.Symbol_Cast(tmp1) }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :84:1
func (t *A_arbace_a2g_embed_reify__1520000052_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_a2g_embed_reify__1520000052_A_New_IPersistentMap(m) }





func A_arbace_a2g_embed_read_all_A_New() *A_arbace_a2g_embed_read_all_A { A_arbace_a2g_embed_read_all_A_Init(); t := &A_arbace_a2g_embed_read_all_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_a2g_embed_read_all_A) Ctor() {}
//line :90:1
func (t *A_arbace_a2g_embed_read_all_A) Invoke_O_O__O(self, text__0 any) any { var r__2 any = jrt.PushbackReader_New_Reader(jrt.StringReader_New_String(jrt.String_Cast(text__0))); var tmp1 *lang.Var;

	A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_52; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_53; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_54; var tmp6 any = tmp5.Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_55; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_56; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_57; var tmp14 any = tmp13.Ref(); var tmp15 any = A_arbace_a2g_embed_read_all_fn__1520000054_A_New(); var tmp16 *jrt.Class; A_arbace_a2g_embed_read_all_fn__1520000054_A_Init(); tmp16 = A_arbace_a2g_embed_read_all_fn__1520000054_A_fn_class; tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O_O_O__O(tmp6, tmp8, tmp10, tmp12, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))); var tmp17 any; tmp23 := /*line :90:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var acc__5 any; lang.PersistentVector_Init(); acc__5 = lang.PersistentVector_EMPTY.Ref(); L1: for { var f__6 any; var tmp18 *lang.Var





		A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_49; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_a2g_embed_A_Init(); tmp20 = A_arbace_a2g_embed_A_const_58; f__6 = tmp19.Invoke_O_O__O(tmp20, r__2)
		var tmp21 *lang.Keyword; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_50; if lang.Util_Equiv_O_O__Z(f__6, tmp21.Ref()) { tmp17 = acc__5 } else { var tmp22 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp22 = A_arbace_a2g_embed_A_const_9; acc__5 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O__O(acc__5, f__6); continue L1 }
//line :90:1
		break L1 } }; return nil }(); var tmp24 *lang.Var;

	A_arbace_a2g_embed_A_Init(); tmp24 = A_arbace_a2g_embed_A_const_51; lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke__O(); if /*line :90:1*/ tmp23 != nil { panic(tmp23) }; return tmp17 }



func A_arbace_a2g_embed_read_all_fn__1520000054_A_New() *A_arbace_a2g_embed_read_all_fn__1520000054_A { A_arbace_a2g_embed_read_all_fn__1520000054_A_Init(); t := &A_arbace_a2g_embed_read_all_fn__1520000054_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) Ctor() {}
//line :94:1
func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) Invoke_O_O_O__O(self, ___1, v__2 any) any { return v__2 }




func A_arbace_a2g_embed_class_like_QMARK__A_New() *A_arbace_a2g_embed_class_like_QMARK__A { A_arbace_a2g_embed_class_like_QMARK__A_Init(); t := &A_arbace_a2g_embed_class_like_QMARK__A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_a2g_embed_class_like_QMARK__A) Ctor() {}
//line :99:1
func (t *A_arbace_a2g_embed_class_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(s__0)).LastIndexOf_String__I(Lit_122); var and__1927000168__auto____3 bool = lang.Numbers_IsPos_J__Z(int64(i__2)); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lt_J_J__Z(lang.Numbers_Inc_J__J(int64(i__2)), int64(lang.RT_Count_O__I(s__0))); if and__1927000168__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsUpperCase_C__Z(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(lang.Numbers_Inc_J__J(int64(i__2)))))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }

func A_arbace_a2g_embed_package_like_QMARK__A_New() *A_arbace_a2g_embed_package_like_QMARK__A { A_arbace_a2g_embed_package_like_QMARK__A_Init(); t := &A_arbace_a2g_embed_package_like_QMARK__A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_a2g_embed_package_like_QMARK__A) Ctor() {}
//line :103:1
func (t *A_arbace_a2g_embed_package_like_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.String_Cast(s__0)).IndexOf_String__I(Lit_122))); if and__1927000168__auto____2 {
											var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_59; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_60; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }

func A_arbace_a2g_embed_names_A_New() *A_arbace_a2g_embed_names_A { A_arbace_a2g_embed_names_A_Init(); t := &A_arbace_a2g_embed_names_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_a2g_embed_names_A) Ctor() {}
//line :106:1
func (t *A_arbace_a2g_embed_names_A) Invoke_O_O__O(self, text__0 any) any { var acc__2 any; var tmp1 *lang.Var;



	A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_61; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp3 = lang.PersistentHashSet_EMPTY; acc__2 = tmp2.Invoke_O__O(tmp3.Ref()); var walk__3 any; var tmp4 any = /*line :106:1*/A_arbace_a2g_embed_names_walk__1520000059_A_New_O(acc__2); var tmp5 *jrt.Class;




	A_arbace_a2g_embed_names_walk__1520000059_A_Init(); tmp5 = A_arbace_a2g_embed_names_walk__1520000059_A_fn_class; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var seq_1520000083__4 any; var tmp6 /*line :106:1*/*lang.Var;




















	A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_13; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp8 = A_arbace_a2g_embed_A_const_74; seq_1520000083__4 = tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(text__0)); var chunk_1520000084__5 any; var count_1520000085__6 int64 = 0; var i_1520000086__7 int64 = 0; L1:
//line :106:1
	for {




















		if lang.Numbers_Lt_J_J__Z(i_1520000086__7, count_1520000085__6) { var f__8 any = lang.Indexed_Cast(chunk_1520000084__5).Nth_I__O(lang.RT_IntCast_J__I(i_1520000086__7)); lang.IFn_Cast(walk__3).Invoke_O__O(f__8); seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, i_1520000086__7 = seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, lang.Numbers_Unchecked_inc_J__J(i_1520000086__7); continue L1 } else { var temp__1927000414__auto____8 any; var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_1520000083__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1520000083__9 any = temp__1927000414__auto____8; var tmp10 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp10 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_1520000083__9)) { var c__1927000678__auto____10 any; var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_15; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_1520000083__9); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, i_1520000086__7 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_1520000083__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__10 any; var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_25; f__10 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_1520000083__9); lang.IFn_Cast(walk__3).Invoke_O__O(f__10); var tmp14 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp14 = A_arbace_a2g_embed_A_const_72; seq_1520000083__4, chunk_1520000084__5, count_1520000085__6, i_1520000086__7 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_1520000083__9), nil, 0, 0; continue L1 } } }
//line :106:1
		break L1 }; var tmp15 /*line :128:1*/*lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_73; return lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(acc__2) }
//line :111:1
func A_arbace_a2g_embed_names_walk__1520000059_A_New_O(p0 any) *A_arbace_a2g_embed_names_walk__1520000059_A { A_arbace_a2g_embed_names_walk__1520000059_A_Init(); t := &A_arbace_a2g_embed_names_walk__1520000059_A{}; t.Ctor_O(p0); return t }
//line :111:1
func (t *A_arbace_a2g_embed_names_walk__1520000059_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :111:1
func (t *A_arbace_a2g_embed_names_walk__1520000059_A) Invoke_O_O__O(self, x__1 any) any { { var temp__1927000414__auto____2 any = lang.RT_Meta_O__IPersistentMap(x__1)
											if jrt.A2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; lang.IFn_Cast(self).Invoke_O__O(m__3) }
											var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_62; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__1)) {

		var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_63; and__1927000168__auto____2 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__1), nil); if and__1927000168__auto____2 { var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_60; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_69; tmp2 = tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.A2g_Truth(tmp2) {
			var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_64; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_acc; var tmp10 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp10 = A_arbace_a2g_embed_A_const_69; tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(x__1)) }
		var tmp11 any; var and__1927000168__auto____2_2 any; var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_63; and__1927000168__auto____2_2 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____2_2) { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_60; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_63; tmp11 = tmp14.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp11 = and__1927000168__auto____2_2 }; if jrt.A2g_Truth(tmp11) {
			var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_64; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = t.F_acc; var tmp19 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_63; return tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :117:1
				return nil } } else {
//line :113:1
					var tmp20 any; var or__1927000174__auto____2 any; var tmp21 *lang.Var





					A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_65; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp20 = or__1927000174__auto____2 } else { var tmp22 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp22 = A_arbace_a2g_embed_A_const_66; tmp20 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(x__1) }
//line :113:1
					if jrt.A2g_Truth(tmp20) {






						var tmp23 any; var and__1927000168__auto____2_3 any; var tmp24 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp24 = A_arbace_a2g_embed_A_const_62; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp26 = A_arbace_a2g_embed_A_const_25; and__1927000168__auto____2_3 = tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(x__1)); if jrt.A2g_Truth(and__1927000168__auto____2_3) { var and__1927000168__auto____3 bool; var tmp27 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_63; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp29 = A_arbace_a2g_embed_A_const_25; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z(tmp28.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(x__1)), nil); if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var tmp30 *lang.Var
							A_arbace_a2g_embed_A_Init(); tmp30 = A_arbace_a2g_embed_A_const_70; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp32 = A_arbace_a2g_embed_A_const_69; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp34 = A_arbace_a2g_embed_A_const_25; and__1927000168__auto____4 = tmp31.Invoke_O__O(tmp33.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(x__1)))
//line :120:1
							if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp35 *lang.Var
								A_arbace_a2g_embed_A_Init(); tmp35 = A_arbace_a2g_embed_A_const_13; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp37 = A_arbace_a2g_embed_A_const_29; and__1927000168__auto____5 = tmp36.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(x__1))
//line :120:1
								if jrt.A2g_Truth(and__1927000168__auto____5) {

									var tmp38 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp38 = A_arbace_a2g_embed_A_const_71; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp40 = A_arbace_a2g_embed_A_const_62; var tmp41 any = jrt.NN(tmp40).GetRawRoot__O(); var tmp42 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp42 = A_arbace_a2g_embed_A_const_29; tmp23 = tmp39.Invoke_O_O__O(tmp41, lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :120:1
										tmp23 = and__1927000168__auto____5 } } else { tmp23 = and__1927000168__auto____4 } } else { tmp23 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { tmp23 = and__1927000168__auto____2_3 }; if jrt.A2g_Truth(tmp23) { var seq_1520000060__2 any; var tmp43 *lang.Var


											A_arbace_a2g_embed_A_Init(); tmp43 = A_arbace_a2g_embed_A_const_13; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp45 = A_arbace_a2g_embed_A_const_29; seq_1520000060__2 = tmp44.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(x__1))
//line :120:1
											var chunk_1520000061__3 any; var count_1520000062__4 int64 = 0; var i_1520000063__5 int64 = 0; L1: for {


												if lang.Numbers_Lt_J_J__Z(i_1520000063__5, count_1520000062__4) { var c__6 any = lang.Indexed_Cast(chunk_1520000061__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000063__5)); var tmp46 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp46 = A_arbace_a2g_embed_A_const_64; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any = t.F_acc; var tmp49 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_122, nil); var tmp50 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp50 = A_arbace_a2g_embed_A_const_25; tmp47.Invoke_O_O__O(tmp48, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp49, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(x__1), nil, c__6)).Ref()); seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, i_1520000063__5 = seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, lang.Numbers_Unchecked_inc_J__J(i_1520000063__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp51 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp51 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(seq_1520000060__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1520000060__7 any = temp__1927000414__auto____6; var tmp52 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp52 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(seq_1520000060__7)) { var c__1927000678__auto____8 any; var tmp53 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp53 = A_arbace_a2g_embed_A_const_15; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq_1520000060__7); var tmp54 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp54 = A_arbace_a2g_embed_A_const_28; seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, i_1520000063__5 = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(seq_1520000060__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any; var tmp55 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp55 = A_arbace_a2g_embed_A_const_25; c__8 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(seq_1520000060__7); var tmp56 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp56 = A_arbace_a2g_embed_A_const_64; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 any = t.F_acc; var tmp59 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_122, nil); var tmp60 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp60 = A_arbace_a2g_embed_A_const_25; tmp57.Invoke_O_O__O(tmp58, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp59, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(x__1), nil, c__8)).Ref()); var tmp61 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp61 = A_arbace_a2g_embed_A_const_72; seq_1520000060__2, chunk_1520000061__3, count_1520000062__4, i_1520000063__5 = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(seq_1520000060__7), nil, 0, 0; continue L1 } } }
//line :120:1
												break L1 } }
//line :113:1
						var seq_1520000064__2 any; var tmp62 *lang.Var










						A_arbace_a2g_embed_A_Init(); tmp62 = A_arbace_a2g_embed_A_const_13; seq_1520000064__2 = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(x__1)
//line :113:1
						var chunk_1520000065__3 any; var count_1520000066__4 int64 = 0; var i_1520000067__5 int64 = 0; L2: for {










							if lang.Numbers_Lt_J_J__Z(i_1520000067__5, count_1520000066__4) { var y__6 any = lang.Indexed_Cast(chunk_1520000065__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000067__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, i_1520000067__5 = seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, lang.Numbers_Unchecked_inc_J__J(i_1520000067__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var tmp63 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp63 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____6_2 = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_1520000064__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_1520000064__7 any = temp__1927000414__auto____6_2; var tmp64 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp64 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(seq_1520000064__7)) { var c__1927000678__auto____8_2 any; var tmp65 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp65 = A_arbace_a2g_embed_A_const_15; c__1927000678__auto____8_2 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(seq_1520000064__7); var tmp66 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp66 = A_arbace_a2g_embed_A_const_28; seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, i_1520000067__5 = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(seq_1520000064__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var y__8 any; var tmp67 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp67 = A_arbace_a2g_embed_A_const_25; y__8 = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(seq_1520000064__7); lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp68 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp68 = A_arbace_a2g_embed_A_const_72; seq_1520000064__2, chunk_1520000065__3, count_1520000066__4, i_1520000067__5 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(seq_1520000064__7), nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :113:1
								var tmp69 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp69 = A_arbace_a2g_embed_A_const_67; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(x__1)) { var seq_1520000068__2 any; var tmp70 *lang.Var











									A_arbace_a2g_embed_A_Init(); tmp70 = A_arbace_a2g_embed_A_const_13; seq_1520000068__2 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(x__1)
//line :113:1
									var chunk_1520000069__3 any; var count_1520000070__4 int64 = 0; var i_1520000071__5 int64 = 0; L3: for {











										if lang.Numbers_Lt_J_J__Z(i_1520000071__5, count_1520000070__4) { var vec__1520000072__6 any = lang.Indexed_Cast(chunk_1520000069__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000071__5)); var k__7 any = lang.RT_Nth_O_I_O__O(vec__1520000072__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__1520000072__6, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__7); lang.IFn_Cast(self).Invoke_O__O(v__8); seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, i_1520000071__5 = seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, lang.Numbers_Unchecked_inc_J__J(i_1520000071__5); continue L3 } else { var temp__1927000414__auto____6_3 any; var tmp71 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp71 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____6_3 = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(seq_1520000068__2); if jrt.A2g_Truth(temp__1927000414__auto____6_3) { var seq_1520000068__7 any = temp__1927000414__auto____6_3; var tmp72 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp72 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(seq_1520000068__7)) { var c__1927000678__auto____8_3 any; var tmp73 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp73 = A_arbace_a2g_embed_A_const_15; c__1927000678__auto____8_3 = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(seq_1520000068__7); var tmp74 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp74 = A_arbace_a2g_embed_A_const_28; seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, i_1520000071__5 = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()).Invoke_O__O(seq_1520000068__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__1520000075__8 any; var tmp75 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp75 = A_arbace_a2g_embed_A_const_25; vec__1520000075__8 = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(seq_1520000068__7); var k__9 any = lang.RT_Nth_O_I_O__O(vec__1520000075__8, lang.RT_IntCast_J__I(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__1520000075__8, lang.RT_IntCast_J__I(1), nil); lang.IFn_Cast(self).Invoke_O__O(k__9); lang.IFn_Cast(self).Invoke_O__O(v__10); var tmp76 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp76 = A_arbace_a2g_embed_A_const_72; seq_1520000068__2, chunk_1520000069__3, count_1520000070__4, i_1520000071__5 = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(seq_1520000068__7), nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :113:1
											var tmp77 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp77 = A_arbace_a2g_embed_A_const_68; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke_O__O(x__1)) { var seq_1520000078__2 any; var tmp78 *lang.Var












												A_arbace_a2g_embed_A_Init(); tmp78 = A_arbace_a2g_embed_A_const_13; seq_1520000078__2 = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()).Invoke_O__O(x__1)
//line :113:1
												var chunk_1520000079__3 any; var count_1520000080__4 int64 = 0; var i_1520000081__5 int64 = 0; L4: for {












													if lang.Numbers_Lt_J_J__Z(i_1520000081__5, count_1520000080__4) { var y__6_2 any = lang.Indexed_Cast(chunk_1520000079__3).Nth_I__O(lang.RT_IntCast_J__I(i_1520000081__5)); lang.IFn_Cast(self).Invoke_O__O(y__6_2); seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, i_1520000081__5 = seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, lang.Numbers_Unchecked_inc_J__J(i_1520000081__5); continue L4 } else { var temp__1927000414__auto____6_4 any; var tmp79 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp79 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____6_4 = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(seq_1520000078__2); if jrt.A2g_Truth(temp__1927000414__auto____6_4) { var seq_1520000078__7 any = temp__1927000414__auto____6_4; var tmp80 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp80 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(seq_1520000078__7)) { var c__1927000678__auto____8_4 any; var tmp81 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp81 = A_arbace_a2g_embed_A_const_15; c__1927000678__auto____8_4 = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O__O(seq_1520000078__7); var tmp82 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp82 = A_arbace_a2g_embed_A_const_28; seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, i_1520000081__5 = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(seq_1520000078__7), c__1927000678__auto____8_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_4))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var y__8_2 any; var tmp83 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp83 = A_arbace_a2g_embed_A_const_25; y__8_2 = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()).Invoke_O__O(seq_1520000078__7); lang.IFn_Cast(self).Invoke_O__O(y__8_2); var tmp84 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp84 = A_arbace_a2g_embed_A_const_72; seq_1520000078__2, chunk_1520000079__3, count_1520000080__4, i_1520000081__5 = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke_O__O(seq_1520000078__7), nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :113:1
														return nil } } } } }; /*line :111:1*/panic("a2g: unreachable") }





























func A_arbace_a2g_embed_cut_candidates_A_New() *A_arbace_a2g_embed_cut_candidates_A { A_arbace_a2g_embed_cut_candidates_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_a2g_embed_cut_candidates_A) Ctor() {}
//line :141:1
func (t *A_arbace_a2g_embed_cut_candidates_A) Invoke_O_O__O(self, srcs__0 any) any {




	var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_75; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var iter__1927001039__auto____2 any; var tmp4 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_New(); var tmp5 *jrt.Class; A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_Init(); tmp5 = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_82; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_83; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_82; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_85; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_86; var tmp16 any = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O(); var tmp17 any = A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_New(); var tmp18 *jrt.Class; A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_Init(); tmp18 = A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_fn_class; var tmp19 any = tmp10.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O_O__O(tmp16, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), srcs__0)); var tmp20 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp20 = A_arbace_a2g_embed_A_const_84; tmp3 = tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(tmp19, jrt.NN(tmp20).GetRawRoot__O())); return tmp2.Invoke_O__O(tmp3) }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_New() *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A { A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_fn__1520000103_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) Ctor() {}
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) Invoke_O_O__O(self, p__1520000102__1 any) any { var vec__1520000104__2 any = p__1520000102__1; var ___3 any = lang.RT_Nth_O_I_O__O(vec__1520000104__2, lang.RT_IntCast_J__I(0), nil); var text__4 any = lang.RT_Nth_O_I_O__O(vec__1520000104__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; _ = ___3; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_87; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(text__4) }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_New() *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) Ctor() {}
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) Invoke_O_O__O(self, s__1520000089__1 any) any { var tmp1 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_New_O_O(s__1520000089__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_Init(); tmp2 = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) Ctor_O_O(c__s__1520000089, c__iter__1520000088 any) { t.F_s__1520000089 = c__s__1520000089; t.F_iter__1520000088 = c__iter__1520000088 }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) Invoke_O__O(self any) any { { var s__1520000089__1 any; var t_ any = t.F_s__1520000089; t.F_s__1520000089 = nil; s__1520000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000089__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000089__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000089__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000091__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000091__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_New_O_I_O(b__1520000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_Init(); tmp6 = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000091__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000088); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000089__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000091__6), nil) } } else { var n__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; n__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000089__3); var tmp17 any; var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var tmp18 *lang.Var
															A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_76; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_a2g_embed_A_Init(); tmp20 = A_arbace_a2g_embed_A_const_78; or__1927000174__auto____5 = tmp19.Invoke_O_O__O(tmp20, n__4); if jrt.A2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else {
																var tmp21 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_76; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_a2g_embed_A_Init(); tmp23 = A_arbace_a2g_embed_A_const_79; and__1927000168__auto____5 = tmp22.Invoke_O_O__O(tmp23, n__4) }
//line :147:1
	if jrt.A2g_Truth(and__1927000168__auto____5) {


		var tmp24 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp24 = A_arbace_a2g_embed_A_const_77; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_a2g_embed_A_Init(); tmp26 = A_arbace_a2g_embed_A_const_80; var tmp27 any = tmp26.Ref(); var tmp28 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_New_O(n__4); var tmp29 *jrt.Class; A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_Init(); tmp29 = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_fn_class; tmp17 = tmp25.Invoke_O_O_O__O(tmp27, n__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil)) } else {
//line :147:1
			tmp17 = and__1927000168__auto____5 }
//line :146:1
	if jrt.A2g_Truth(tmp17) { var tmp30 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp30 = A_arbace_a2g_embed_A_const_26; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp32 = A_arbace_a2g_embed_A_const_81; var tmp33 any = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O_O_O__O(n__4, Lit_122, Lit_127); var tmp34 lang.IFn = lang.IFn_Cast(t.F_iter__1520000088); var tmp35 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp35 = A_arbace_a2g_embed_A_const_29; return tmp31.Invoke_O_O__O(tmp33, tmp34.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(s__1520000089__3))) } else { var tmp36 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp36 = A_arbace_a2g_embed_A_const_29; s__1520000089__1 = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(s__1520000089__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :146:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) Ctor_O_I_O(c__b__1520000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000091 = c__b__1520000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :146:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) Invoke_O__O(self any) any { { var i__1520000090__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000090__1)); var tmp2 any; var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var tmp3 *lang.Var
																	A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_76; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_78; or__1927000174__auto____3 = tmp4.Invoke_O_O__O(tmp5, n__2); if jrt.A2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else {
																		var tmp6 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_76; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_a2g_embed_A_Init(); tmp8 = A_arbace_a2g_embed_A_const_79; and__1927000168__auto____3 = tmp7.Invoke_O_O__O(tmp8, n__2) }
//line :147:1
	if jrt.A2g_Truth(and__1927000168__auto____3) {


		var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_77; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_80; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_New_O(n__2); var tmp14 *jrt.Class; A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_Init(); tmp14 = A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_fn_class; tmp2 = tmp10.Invoke_O_O_O__O(tmp12, n__2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)) } else {
//line :147:1
			tmp2 = and__1927000168__auto____3 }
//line :146:1
	if jrt.A2g_Truth(tmp2) { var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_22; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any = t.F_b__1520000091; var tmp18 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_81; tmp16.Invoke_O_O__O(tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O_O__O(n__2, Lit_122, Lit_127)); i__1520000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000090__1); continue L1 } else { i__1520000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000090__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_New_O(p0 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																			{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(tmp3).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :150:1
		jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :150:1
func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_New_O(p0 any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_Init(); t := &A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :150:1
func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																	{ var tmp2 *jrt.String = jrt.String_Cast(t.F_n); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; jrt.Class_ForName_String_Z_ClassLoader__Class(tmp2, jrt.NN(tmp3).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader())
//line :150:1
		jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() }; return nil }(); if tmp4 != nil { if true { var ___3 jrt.Throwable_I = tmp4; _ = ___3; jrt.Boolean_Init(); tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }




func A_arbace_a2g_embed_with_member_types_A_New() *A_arbace_a2g_embed_with_member_types_A { A_arbace_a2g_embed_with_member_types_A_Init(); t := &A_arbace_a2g_embed_with_member_types_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_a2g_embed_with_member_types_A) Ctor() {}
//line :155:1
func (t *A_arbace_a2g_embed_with_member_types_A) Invoke_O_O_O__O(self, cands__0, in_world_QMARK___1 any) any { var types__3 any; var tmp1 any = A_arbace_a2g_embed_with_member_types_types__1520000109_A_New(); var tmp2 *jrt.Class;




	A_arbace_a2g_embed_with_member_types_types__1520000109_A_Init(); tmp2 = A_arbace_a2g_embed_with_member_types_types__1520000109_A_fn_class; types__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var elem__4 any; var tmp3 any = /*line :155:1*/A_arbace_a2g_embed_with_member_types_elem__1520000117_A_New(); var tmp4 *jrt.Class;








	A_arbace_a2g_embed_with_member_types_elem__1520000117_A_Init(); tmp4 = A_arbace_a2g_embed_with_member_types_elem__1520000117_A_fn_class; elem__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var member_types__5 any; var tmp5 any = /*line :155:1*/A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_New_O_O(elem__4, types__3); var tmp6 *jrt.Class;










	A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_Init(); tmp6 = A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_fn_class; member_types__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var more__6 any; var iter__1927001039__auto____6 any; var tmp7 any = /*line :155:1*/A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_New_O_O(in_world_QMARK___1, member_types__5); var tmp8 *jrt.Class;




















	A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_Init(); tmp8 = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_fn_class; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); more__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(cands__0); var tmp9 /*line :181:1*/*lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_91; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_92; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_82; return tmp10.Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(cands__0, more__6))) }
//line :160:1
func A_arbace_a2g_embed_with_member_types_types__1520000109_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_A { A_arbace_a2g_embed_with_member_types_types__1520000109_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) Ctor() {}
//line :160:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_82; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_88; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_New(); var tmp6 *jrt.Class; A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_Init(); tmp6 = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_fn_class; var tmp7 any = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), jrt.NN(jrt.Class_Cast(c__1)).GetMethods__Method1().Ref()); var tmp8 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp8 = A_arbace_a2g_embed_A_const_89; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_New(); var tmp11 *jrt.Class; A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_Init(); tmp11 = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_fn_class; var tmp12 any = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), jrt.NN(jrt.Class_Cast(c__1)).GetFields__Field1().Ref()); var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_88; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_New(); var tmp16 *jrt.Class; A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_Init(); tmp16 = A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_fn_class; return tmp2.Invoke_O_O_O__O(tmp7, tmp12, tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), jrt.NN(jrt.Class_Cast(c__1)).GetConstructors__Constructor1().Ref())) }
//line :161:1
func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) Ctor() {}
//line :161:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) Invoke_O_O__O(self, m__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_26; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__1)).GetReturnType__Class().Ref(), jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref()) }
func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) Ctor() {}
//line :162:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.Field_Cast(f__1)).GetType__Class().Ref() }
func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_New() *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_Init(); t := &A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) Ctor() {}
//line :163:1
func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) Invoke_O_O__O(self, k__1 any) any { return jrt.NN(jrt.Constructor_Cast(k__1)).GetParameterTypes__Class1().Ref() }
func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_New() *A_arbace_a2g_embed_with_member_types_elem__1520000117_A { A_arbace_a2g_embed_with_member_types_elem__1520000117_A_Init(); t := &A_arbace_a2g_embed_with_member_types_elem__1520000117_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) Ctor() {}
//line :164:1
func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) Invoke_O_O__O(self, c__1 any) any { { var c__1_2 any = c__1; L1: for { if jrt.NN(jrt.Class_Cast(c__1_2)).IsArray__Z() { c__1_2 = jrt.NN(jrt.Class_Cast(c__1_2)).GetComponentType__Class().Ref(); continue L1 } else { return c__1_2 } } }; panic("a2g: unreachable") }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A { A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_A{}; t.Ctor_O_O(p0, p1); return t }
//line :166:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) Ctor_O_O(c__elem, c__types any) { t.F_elem = c__elem; t.F_types = c__types }
//line :166:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) Invoke_O_O__O(self, n__1 any) any { var temp__1927000414__auto____2 any; var tmp1 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_New_O(n__1); var tmp2 *jrt.Class;
														A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_Init(); tmp2 = A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_fn_class; temp__1927000414__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); if jrt.A2g_Truth(temp__1927000414__auto____2) { var c__3 any = temp__1927000414__auto____2; var tmp3 *lang.Var

		A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_91; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_92; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____4 any; var tmp10 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_New(); var tmp11 *jrt.Class
		A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_Init(); tmp11 = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_fn_class; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp12 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_89; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_elem; tmp9 = tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(t.F_types).Invoke_O__O(c__3)))
//line :169:1
		return tmp4.Invoke_O__O(tmp6.Invoke_O__O(tmp8.Invoke_O__O(tmp9))) } else {
//line :167:1
			return nil } }
//line :167:1
func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_New_O(p0 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A { A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :167:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_81; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_n; t.F_n = nil; tmp4 = t_; var tmp5 *jrt.String = jrt.String_Cast(tmp3.Invoke_O_O_O__O(tmp4, Lit_127, Lit_122)); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; tmp1 = jrt.Class_ForName_String_Z_ClassLoader__Class(tmp5, jrt.NN(tmp6).BooleanValue__Z(), jrt.ClassLoader_GetSystemClassLoader__ClassLoader()).Ref() }; return nil }(); if tmp7 != nil { if true { var ___3 jrt.Throwable_I = tmp7; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_New() *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) Ctor() {}
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) Invoke_O_O__O(self, s__1520000123__1 any) any { var tmp1 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_New_O_O(s__1520000123__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_Init(); tmp2 = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :170:1
func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A{}; t.Ctor_O_O(p0, p1); return t }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) Ctor_O_O(c__s__1520000123, c__iter__1520000122 any) { t.F_s__1520000123 = c__s__1520000123; t.F_iter__1520000122 = c__iter__1520000122 }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) Invoke_O__O(self any) any { { var s__1520000123__1 any; var t_ any = t.F_s__1520000123; t.F_s__1520000123 = nil; s__1520000123__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000123__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000123__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000123__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000123__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000125__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000125__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_New_O_I_O(b__1520000125__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_Init(); tmp6 = A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000125__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000122); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000123__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000125__6), nil) } } else { var t__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; t__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000123__3); var tmp17 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp17 = A_arbace_a2g_embed_A_const_59; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(t__4)).IsPrimitive__Z()).Ref())) { var tn__5 any; var tmp18 *lang.Var

	A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_81; tn__5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(t__4)).GetName__String().Ref(), Lit_122, Lit_127)
//line :170:1
	var tmp19 any; var and__1927000168__auto____6 any; var tmp20 *lang.Var


	A_arbace_a2g_embed_A_Init(); tmp20 = A_arbace_a2g_embed_A_const_76; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any; A_arbace_a2g_embed_A_Init(); tmp22 = A_arbace_a2g_embed_A_const_93; and__1927000168__auto____6 = tmp21.Invoke_O_O__O(tmp22, tn__5); if jrt.A2g_Truth(and__1927000168__auto____6) {
		tmp19 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__4)).GetModifiers__I())).Ref() } else {
//line :173:1
			tmp19 = and__1927000168__auto____6 }
//line :170:1
	if jrt.A2g_Truth(tmp19) { var tmp23 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp23 = A_arbace_a2g_embed_A_const_26; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 lang.IFn = lang.IFn_Cast(t.F_iter__1520000122); var tmp26 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp26 = A_arbace_a2g_embed_A_const_29; return tmp24.Invoke_O_O__O(tn__5, tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(s__1520000123__3))) } else { var tmp27 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_29; s__1520000123__1 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__1520000123__3); continue L1 } } else { var tmp28 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp28 = A_arbace_a2g_embed_A_const_29; s__1520000123__1 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(s__1520000123__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :170:1
func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_Init(); t := &A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) Ctor_O_I_O(c__b__1520000125 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000125 = c__b__1520000125; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :170:1
func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) Invoke_O__O(self any) any { { var i__1520000124__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000124__1)); var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_59; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(t__2)).IsPrimitive__Z()).Ref())) { var tn__3 any; var tmp3 *lang.Var

	A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_81; tn__3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(t__2)).GetName__String().Ref(), Lit_122, Lit_127)
//line :170:1
	var tmp4 any; var and__1927000168__auto____4 any; var tmp5 *lang.Var


	A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_76; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_93; and__1927000168__auto____4 = tmp6.Invoke_O_O__O(tmp7, tn__3); if jrt.A2g_Truth(and__1927000168__auto____4) {
		tmp4 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(t__2)).GetModifiers__I())).Ref() } else {
//line :173:1
			tmp4 = and__1927000168__auto____4 }
//line :170:1
	if jrt.A2g_Truth(tmp4) { var tmp8 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp8 = A_arbace_a2g_embed_A_const_22; lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(t.F_b__1520000125, tn__3); i__1520000124__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000124__1); continue L1 } else { i__1520000124__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000124__1); continue L1 } } else { i__1520000124__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000124__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) Ctor_O_O(c__in_world_QMARK_, c__member_types any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) Invoke_O_O__O(self, s__1520000134__1 any) any { var tmp1 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_New_O_O_O_O(t.F_in_world_QMARK_, t.F_member_types, s__1520000134__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_Init(); tmp2 = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) Ctor_O_O_O_O(c__in_world_QMARK_, c__member_types, c__s__1520000134, c__iter__1520000133 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_member_types = c__member_types; t.F_s__1520000134 = c__s__1520000134; t.F_iter__1520000133 = c__iter__1520000133 }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) Invoke_O__O(self any) any { { var s__1520000134__1 any; var t_ any = t.F_s__1520000134; t.F_s__1520000134 = nil; s__1520000134__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000134__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_25; n__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_59; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(n__4))) { var iterys__1927001035__auto____5 any; var tmp4 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_New_O(t.F_in_world_QMARK_); var tmp5 *jrt.Class; A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_Init(); tmp5 = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_fn_class; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____6 any; var tmp6 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_13; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_94; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_95; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_New_O_O(n__4, t.F_member_types); var tmp14 *jrt.Class; A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_Init(); tmp14 = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_fn_class; fs__1927001036__auto____6 = tmp7.Invoke_O__O(tmp8.Invoke_O__O(tmp10.Invoke_O_O_O__O(tmp12, n__4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_82; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__1520000133); var tmp18 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_29; return tmp16.Invoke_O_O__O(fs__1927001036__auto____6, tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(s__1520000134__1))) } else { var tmp19 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_29; s__1520000134__1 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(s__1520000134__1); continue L1 } } else { var tmp20 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp20 = A_arbace_a2g_embed_A_const_29; s__1520000134__1 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(s__1520000134__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_New_O(p0 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A{}; t.Ctor_O(p0); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) Ctor_O(c__in_world_QMARK_ any) { t.F_in_world_QMARK_ = c__in_world_QMARK_ }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) Invoke_O_O__O(self, s__1520000136__1 any) any { var tmp1 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_New_O_O_O(t.F_in_world_QMARK_, s__1520000136__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_Init(); tmp2 = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) Ctor_O_O_O(c__in_world_QMARK_, c__s__1520000136, c__iter__1520000135 any) { t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_s__1520000136 = c__s__1520000136; t.F_iter__1520000135 = c__iter__1520000135 }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) Invoke_O__O(self any) any { { var s__1520000136__1 any; var t_ any = t.F_s__1520000136; t.F_s__1520000136 = nil; s__1520000136__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000136__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000136__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000136__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000136__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000138__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000138__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_New_O_O_I_O(b__1520000138__6, t.F_in_world_QMARK_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_Init(); tmp6 = A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000138__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000135); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000136__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000138__6), nil) } } else { var tn__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; tn__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000136__3); var tmp17 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp17 = A_arbace_a2g_embed_A_const_59; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__4))) { var tmp18 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_26; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__1520000135); var tmp21 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_29; return tmp19.Invoke_O_O__O(tn__4, tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(s__1520000136__3))) } else { var tmp22 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp22 = A_arbace_a2g_embed_A_const_29; s__1520000136__1 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1520000136__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :176:1
func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) Ctor_O_O_I_O(c__b__1520000138, c__in_world_QMARK_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000138 = c__b__1520000138; t.F_in_world_QMARK_ = c__in_world_QMARK_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) Invoke_O__O(self any) any { { var i__1520000137__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var tn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000137__1)); var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_59; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_world_QMARK_).Invoke_O__O(tn__2))) { var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_22; lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(t.F_b__1520000138, tn__2); i__1520000137__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000137__1); continue L1 } else { i__1520000137__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000137__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_Init(); t := &A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) Ctor_O_O(c__n, c__member_types any) { t.F_n = c__n; t.F_member_types = c__member_types }
//line :178:1
func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) Invoke_O__O(self any) any { return lang.IFn_Cast(t.F_member_types).Invoke_O__O(t.F_n) }







func A_arbace_a2g_embed_data_A_New() *A_arbace_a2g_embed_data_A { A_arbace_a2g_embed_data_A_Init(); t := &A_arbace_a2g_embed_data_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_a2g_embed_data_A) Ctor() {}
//line :186:1
func (t *A_arbace_a2g_embed_data_A) Invoke_O_O__O(self, dir__0 any) any { var base__2 any; var tmp1 *lang.Var;




	A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_12; base__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(dir__0); var tmp2 /*line :192:1*/*lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_45; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_47; var tmp5 any = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke__O(); var tmp6 any; if
	jrt.NN(jrt.File_Cast(base__2)).IsDirectory__Z() { var iter__1927001039__auto____3 any; var tmp7 any = A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_New_O(base__2); var tmp8 *jrt.Class
		A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_Init(); tmp8 = A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp10 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp10 = A_arbace_a2g_embed_A_const_31; tmp6 = tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(base__2)) } else {
//line :193:1
			tmp6 = nil }; return /*line :192:1*/ tmp3.Invoke_O_O__O(tmp5, tmp6) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_New_O(p0 any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A { A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_Init(); t := &A_arbace_a2g_embed_data_iter__1520000152__1520000156_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) Ctor_O(c__base any) { t.F_base = c__base }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) Invoke_O_O__O(self, s__1520000153__1 any) any { var tmp1 any = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_New_O_O_O(t.F_base, s__1520000153__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_Init(); tmp2 = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :194:1
func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A { A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_Init(); t := &A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) Ctor_O_O_O(c__base, c__s__1520000153, c__iter__1520000152 any) { t.F_base = c__base; t.F_s__1520000153 = c__s__1520000153; t.F_iter__1520000152 = c__iter__1520000152 }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) Invoke_O__O(self any) any { { var s__1520000153__1 any; var t_ any = t.F_s__1520000153; t.F_s__1520000153 = nil; s__1520000153__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000153__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000153__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000153__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000153__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000155__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000155__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_New_O_I_O_O(t.F_base, size__1927001038__auto____5, c__1927001037__auto____4, b__1520000155__6); var tmp6 *jrt.Class; A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_Init(); tmp6 = A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000155__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000152); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000153__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000155__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000153__3); if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var tmp17 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp17 = A_arbace_a2g_embed_A_const_26; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_81; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_18; var tmp22 any = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path())); var tmp23 *jrt.String; jrt.File_Init(); tmp23 = jrt.File_separator; var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(tmp20.Invoke_O_O_O__O(tmp22, tmp23.Ref(), Lit_127), f__4); var tmp25 lang.IFn = lang.IFn_Cast(t.F_iter__1520000152); var tmp26 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp26 = A_arbace_a2g_embed_A_const_29; return tmp18.Invoke_O_O__O(tmp24, tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(s__1520000153__3))) } else { var tmp27 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_29; s__1520000153__1 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__1520000153__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :194:1
func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A { A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_Init(); t := &A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) Ctor_O_I_O_O(c__base any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1520000155 any) { t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1520000155 = c__b__1520000155 }
//line :194:1
func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) Invoke_O__O(self any) any { { var i__1520000154__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000154__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1520000155; var tmp5 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_81; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_18; var tmp8 any = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(t.F_base)).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())); var tmp9 *jrt.String; jrt.File_Init(); tmp9 = jrt.File_separator; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(tmp6.Invoke_O_O_O__O(tmp8, tmp9.Ref(), Lit_127), f__2)); i__1520000154__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000154__1); continue L1 } else { i__1520000154__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000154__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

















func A_arbace_a2g_embed_image_type_forms_A_New() *A_arbace_a2g_embed_image_type_forms_A { A_arbace_a2g_embed_image_type_forms_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_a2g_embed_image_type_forms_A) Ctor() {}
//line :212:1
func (t *A_arbace_a2g_embed_image_type_forms_A) Invoke_O_O__O(self, prog_dir__0 any) any { var re__2 any; A_arbace_a2g_embed_A_Init(); re__2 = A_arbace_a2g_embed_A_const_96; var files__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_New_O(prog_dir__0); var tmp2 *jrt.Class;





	A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_Init(); tmp2 = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_97; files__3 = tmp3.Invoke_O__O(tmp4); var types__4 any; var tmp5 /*line :212:1*/*lang.Var;












	A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_83; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_82; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_85; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_86; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O(); var tmp13 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_New_O(re__2); var tmp14 *jrt.Class; A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_Init(); tmp14 = A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_fn_class; types__4 = tmp6.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O_O__O(tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), files__3)); var tmp15 /*line :212:1*/*lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_100; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_a2g_embed_A_Init(); tmp17 = A_arbace_a2g_embed_A_const_101; var tmp18 any = tmp17; var tmp19 *lang.Keyword; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_102; var tmp20 any = tmp19.Ref(); var tmp21 any; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_103; var tmp22 any = tmp16.Invoke_O_O_O_O__O(tmp18, Lit_142, tmp20, tmp21); var tmp23 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp23 = A_arbace_a2g_embed_A_const_100; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_a2g_embed_A_Init(); tmp25 = A_arbace_a2g_embed_A_const_104; var tmp26 any = tmp25; var tmp27 any; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_105; var tmp28 any = tmp27; var tmp29 *lang.PersistentVector; lang.PersistentVector_Init(); tmp29 = lang.PersistentVector_EMPTY; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp31 = A_arbace_a2g_embed_A_const_100; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_a2g_embed_A_Init(); tmp33 = A_arbace_a2g_embed_A_const_106; var tmp34 any = tmp33; var tmp35 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp35 = A_arbace_a2g_embed_A_const_83; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp37 = A_arbace_a2g_embed_A_const_100; var tmp38 any = jrt.NN(tmp37).GetRawRoot__O(); var tmp39 any; A_arbace_a2g_embed_A_Init(); tmp39 = A_arbace_a2g_embed_A_const_107; var tmp40 any = tmp39; var tmp41 any; A_arbace_a2g_embed_A_Init(); tmp41 = A_arbace_a2g_embed_A_const_108; var tmp42 any = tmp41; var tmp43 any; var iter__1927001039__auto____5 any; var tmp44 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_New(); var tmp45 *jrt.Class;


















	A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_Init(); tmp45 = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_fn_class; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil); var tmp46 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp47 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp47 = A_arbace_a2g_embed_A_const_46; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp49 = A_arbace_a2g_embed_A_const_18; var tmp50 any = jrt.NN(tmp49).GetRawRoot__O(); var tmp51 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp51 = A_arbace_a2g_embed_A_const_92; tmp43 = tmp46.Invoke_O__O(tmp48.Invoke_O_O__O(tmp50, lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(types__4))); return /*line :212:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp22, tmp24.Invoke_O_O_O_O__O(tmp26, tmp28, tmp30, tmp32.Invoke_O_O__O(tmp34, tmp36.Invoke_O_O_O_O__O(tmp38, tmp40, tmp42, tmp43)))) }





func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A{}; t.Ctor_O(p0); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) Ctor_O(c__prog_dir any) { t.F_prog_dir = c__prog_dir }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) Invoke_O_O__O(self, s__1520000164__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_New_O_O_O(t.F_prog_dir, s__1520000164__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_Init(); tmp2 = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) Ctor_O_O_O(c__prog_dir, c__s__1520000164, c__iter__1520000163 any) { t.F_prog_dir = c__prog_dir; t.F_s__1520000164 = c__s__1520000164; t.F_iter__1520000163 = c__iter__1520000163 }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) Invoke_O__O(self any) any { { var s__1520000164__1 any; var t_ any = t.F_s__1520000164; t.F_s__1520000164 = nil; s__1520000164__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000164__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1520000171__4 any; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_25; vec__1520000171__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var pkg__5 any = lang.RT_Nth_O_I_O__O(vec__1520000171__4, lang.RT_IntCast_J__I(0), nil); var alias__6 any = lang.RT_Nth_O_I_O__O(vec__1520000171__4, lang.RT_IntCast_J__I(1), nil); var dir__7 any; var tmp3 *lang.Var
															A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_12; dir__7 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(t.F_prog_dir, Lit_149, pkg__5)
//line :218:1
	var iterys__1927001035__auto____8 any; var tmp4 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_New_O(alias__6); var tmp5 *jrt.Class; A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_Init(); tmp5 = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_fn_class; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____9 any; var tmp6 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_13; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____8); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_91; fs__1927001036__auto____9 = tmp7.Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(dir__7)).ListFiles__File1().Ref()))); if jrt.A2g_Truth(fs__1927001036__auto____9) { var tmp10 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp10 = A_arbace_a2g_embed_A_const_82; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1520000163); var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_29; return tmp11.Invoke_O_O__O(fs__1927001036__auto____9, tmp12.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(s__1520000164__1))) } else { var tmp14 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp14 = A_arbace_a2g_embed_A_const_29; s__1520000164__1 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(s__1520000164__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A{}; t.Ctor_O(p0); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) Invoke_O_O__O(self, s__1520000166__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_New_O_O_O(t.F_alias, s__1520000166__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_Init(); tmp2 = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) Ctor_O_O_O(c__alias, c__s__1520000166, c__iter__1520000165 any) { t.F_alias = c__alias; t.F_s__1520000166 = c__s__1520000166; t.F_iter__1520000165 = c__iter__1520000165 }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) Invoke_O__O(self any) any { { var s__1520000166__1 any; var t_ any = t.F_s__1520000166; t.F_s__1520000166 = nil; s__1520000166__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000166__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000166__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000166__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000166__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000168__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000168__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_New_O_O_I_O(b__1520000168__6, t.F_alias, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_Init(); tmp6 = A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000168__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000165); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000166__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000168__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000166__3); var tmp17 any; var and__1927000168__auto____5 bool = jrt.NN(jrt.File_Cast(f__4)).IsFile__Z()


	if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var tmp18 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp18 = A_arbace_a2g_embed_A_const_17; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_152); if jrt.A2g_Truth(and__1927000168__auto____6) {
		var tmp19 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_59; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_17; tmp17 = tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(), Lit_153)) } else {
//line :221:1
			tmp17 = and__1927000168__auto____6 } } else { tmp17 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }
//line :218:1
	if jrt.A2g_Truth(tmp17) { var tmp22 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp22 = A_arbace_a2g_embed_A_const_26; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any = lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__4); var tmp25 lang.IFn = lang.IFn_Cast(t.F_iter__1520000165); var tmp26 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp26 = A_arbace_a2g_embed_A_const_29; return tmp23.Invoke_O_O__O(tmp24, tmp25.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(s__1520000166__3))) } else { var tmp27 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp27 = A_arbace_a2g_embed_A_const_29; s__1520000166__1 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(s__1520000166__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :218:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) Ctor_O_O_I_O(c__b__1520000168, c__alias any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000168 = c__b__1520000168; t.F_alias = c__alias; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :218:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) Invoke_O__O(self any) any { { var i__1520000167__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000167__1)); var tmp2 any; var and__1927000168__auto____3 bool = jrt.NN(jrt.File_Cast(f__2)).IsFile__Z()


	if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_17; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_152); if jrt.A2g_Truth(and__1927000168__auto____4) {
		var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_59; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp6 = A_arbace_a2g_embed_A_const_17; tmp2 = tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(), Lit_153)) } else {
//line :221:1
			tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }
//line :218:1
	if jrt.A2g_Truth(tmp2) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_22; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_b__1520000168; tmp8.Invoke_O_O__O(tmp9, lang.Tuple_Create_O_O__IPersistentVector(t.F_alias, f__2)); i__1520000167__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000167__1); continue L1 } else { i__1520000167__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000167__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A { A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) Ctor_O(c__re any) { t.F_re = c__re }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) Invoke_O_O__O(self, p__1520000182__1 any) any { var vec__1520000184__2 any = p__1520000182__1; var alias__3 any = lang.RT_Nth_O_I_O__O(vec__1520000184__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__1520000184__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_90; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var iter__1927001039__auto____5 any; var tmp4 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_New_O(alias__3); var tmp5 *jrt.Class; A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_Init(); tmp5 = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_fn_class; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_99; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_re; var tmp10 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp10 = A_arbace_a2g_embed_A_const_23; tmp3 = tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(f__4))); return tmp2.Invoke_O__O(tmp3) }
//line :225:1
func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_New_O(p0 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) Ctor_O(c__alias any) { t.F_alias = c__alias }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) Invoke_O_O__O(self, s__1520000188__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_New_O_O_O(t.F_alias, s__1520000188__1, self); var tmp2 *jrt.Class; A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_Init(); tmp2 = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :225:1
func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) Ctor_O_O_O(c__alias, c__s__1520000188, c__iter__1520000187 any) { t.F_alias = c__alias; t.F_s__1520000188 = c__s__1520000188; t.F_iter__1520000187 = c__iter__1520000187 }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) Invoke_O__O(self any) any { { var s__1520000188__1 any; var t_ any = t.F_s__1520000188; t.F_s__1520000188 = nil; s__1520000188__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000188__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000188__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000188__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000188__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000190__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000190__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_New_O_O_I_O(t.F_alias, b__1520000190__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_Init(); tmp6 = A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000190__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000187); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000188__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000190__6), nil) } } else { var vec__1520000198__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; vec__1520000198__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000188__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1520000198__4, lang.RT_IntCast_J__I(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O(vec__1520000198__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; _ = ___5; A_arbace_a2g_embed_A_Init(); tmp17 = A_arbace_a2g_embed_A_const_26; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_98; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O_O__O(t.F_alias, n__6); var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__1520000187); var tmp22 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp22 = A_arbace_a2g_embed_A_const_29; return tmp18.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(s__1520000188__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :225:1
func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) Ctor_O_O_I_O(c__alias, c__b__1520000190 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_alias = c__alias; t.F_b__1520000190 = c__b__1520000190; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :225:1
func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) Invoke_O__O(self any) any { { var i__1520000189__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000189__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1520000194__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000189__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__1520000194__2, lang.RT_IntCast_J__I(0), nil); var n__4 any = lang.RT_Nth_O_I_O__O(vec__1520000194__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; _ = ___3; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1520000190; var tmp5 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_98; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(t.F_alias, n__4)); i__1520000189__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000189__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_New() *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) Ctor() {}
//line :231:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) Invoke_O_O__O(self, s__1520000205__1 any) any { var tmp1 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_New_O_O(self, s__1520000205__1); var tmp2 *jrt.Class; A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_Init(); tmp2 = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :231:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_New_O_O(p0, p1 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A{}; t.Ctor_O_O(p0, p1); return t }
//line :231:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) Ctor_O_O(c__iter__1520000204, c__s__1520000205 any) { t.F_iter__1520000204 = c__iter__1520000204; t.F_s__1520000205 = c__s__1520000205 }
//line :231:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) Invoke_O__O(self any) any { { var s__1520000205__1 any; var t_ any = t.F_s__1520000205; t.F_s__1520000205 = nil; s__1520000205__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp1 = A_arbace_a2g_embed_A_const_13; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1520000205__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1520000205__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_14; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1520000205__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp3 = A_arbace_a2g_embed_A_const_15; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1520000205__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1520000207__6 any; var tmp4 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp4 = A_arbace_a2g_embed_A_const_16; b__1520000207__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_New_O_I_O(b__1520000207__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_Init(); tmp6 = A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_27; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1520000207__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1520000204); var tmp12 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp12 = A_arbace_a2g_embed_A_const_28; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1520000205__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp13 = A_arbace_a2g_embed_A_const_24; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp15 = A_arbace_a2g_embed_A_const_27; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1520000207__6), nil) } } else { var t__4 any; var tmp16 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp16 = A_arbace_a2g_embed_A_const_25; t__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1520000205__3); var tmp17 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp17 = A_arbace_a2g_embed_A_const_26; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp19 = A_arbace_a2g_embed_A_const_100; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_a2g_embed_A_Init(); tmp21 = A_arbace_a2g_embed_A_const_109; var tmp22 any = tmp21; var tmp23 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp23 = A_arbace_a2g_embed_A_const_100; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_a2g_embed_A_Init(); tmp25 = A_arbace_a2g_embed_A_const_110; var tmp26 any = tmp20.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp25, t__4)); var tmp27 lang.IFn = lang.IFn_Cast(t.F_iter__1520000204); var tmp28 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp28 = A_arbace_a2g_embed_A_const_29; return tmp18.Invoke_O_O__O(tmp26, tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(s__1520000205__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :231:1
func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_Init(); t := &A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :231:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) Ctor_O_I_O(c__b__1520000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1520000207 = c__b__1520000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :231:1
func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) Invoke_O__O(self any) any { { var i__1520000206__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1520000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1520000206__1)); var tmp2 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp2 = A_arbace_a2g_embed_A_const_22; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1520000207; var tmp5 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp5 = A_arbace_a2g_embed_A_const_100; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_a2g_embed_A_Init(); tmp7 = A_arbace_a2g_embed_A_const_109; var tmp8 any = tmp7; var tmp9 *lang.Var; A_arbace_a2g_embed_A_Init(); tmp9 = A_arbace_a2g_embed_A_const_100; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_a2g_embed_A_Init(); tmp11 = A_arbace_a2g_embed_A_const_110; tmp3.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(tmp11, t__2))); i__1520000206__1 = lang.Numbers_Unchecked_inc_J__J(i__1520000206__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




















































































































































































type A_arbace_a2g_embed_A struct{ jrt.Object }

var A_arbace_a2g_embed_A_const_0 *lang.Var

var A_arbace_a2g_embed_A_const_1 *lang.Var

var A_arbace_a2g_embed_A_const_2 any

var A_arbace_a2g_embed_A_const_3 any

var A_arbace_a2g_embed_A_const_4 any

var A_arbace_a2g_embed_A_const_5 any

var A_arbace_a2g_embed_A_const_6 any

var A_arbace_a2g_embed_A_const_7 *lang.Var

var A_arbace_a2g_embed_A_const_8 *lang.Var

var A_arbace_a2g_embed_A_const_9 *lang.Var

var A_arbace_a2g_embed_A_const_10 any

var A_arbace_a2g_embed_A_const_11 *lang.Var

var A_arbace_a2g_embed_A_const_12 *lang.Var

var A_arbace_a2g_embed_A_const_13 *lang.Var

var A_arbace_a2g_embed_A_const_14 *lang.Var

var A_arbace_a2g_embed_A_const_15 *lang.Var

var A_arbace_a2g_embed_A_const_16 *lang.Var

var A_arbace_a2g_embed_A_const_17 *lang.Var

var A_arbace_a2g_embed_A_const_18 *lang.Var

var A_arbace_a2g_embed_A_const_19 *lang.Var

var A_arbace_a2g_embed_A_const_20 *lang.Var

var A_arbace_a2g_embed_A_const_21 *lang.Var

var A_arbace_a2g_embed_A_const_22 *lang.Var

var A_arbace_a2g_embed_A_const_23 *lang.Var

var A_arbace_a2g_embed_A_const_24 *lang.Var

var A_arbace_a2g_embed_A_const_25 *lang.Var

var A_arbace_a2g_embed_A_const_26 *lang.Var

var A_arbace_a2g_embed_A_const_27 *lang.Var

var A_arbace_a2g_embed_A_const_28 *lang.Var

var A_arbace_a2g_embed_A_const_29 *lang.Var

var A_arbace_a2g_embed_A_const_30 *lang.Var

var A_arbace_a2g_embed_A_const_31 *lang.Var

var A_arbace_a2g_embed_A_const_32 *lang.Var

var A_arbace_a2g_embed_A_const_33 *lang.Var

var A_arbace_a2g_embed_A_const_34 *lang.Var

var A_arbace_a2g_embed_A_const_35 *lang.Var

var A_arbace_a2g_embed_A_const_36 *lang.Keyword

var A_arbace_a2g_embed_A_const_37 *lang.Var

var A_arbace_a2g_embed_A_const_38 any

var A_arbace_a2g_embed_A_const_39 any

var A_arbace_a2g_embed_A_const_40 *lang.Var

var A_arbace_a2g_embed_A_const_41 *lang.Var

var A_arbace_a2g_embed_A_const_42 *lang.Var

var A_arbace_a2g_embed_A_const_43 *lang.Var

var A_arbace_a2g_embed_A_const_44 *lang.Var

var A_arbace_a2g_embed_A_const_45 *lang.Var

var A_arbace_a2g_embed_A_const_46 *lang.Var

var A_arbace_a2g_embed_A_const_47 *lang.Var

var A_arbace_a2g_embed_A_const_48 any

var A_arbace_a2g_embed_A_const_49 *lang.Var

var A_arbace_a2g_embed_A_const_50 *lang.Keyword

var A_arbace_a2g_embed_A_const_51 *lang.Var

var A_arbace_a2g_embed_A_const_52 *lang.Var

var A_arbace_a2g_embed_A_const_53 *lang.Var

var A_arbace_a2g_embed_A_const_54 *lang.Var

var A_arbace_a2g_embed_A_const_55 *lang.Var

var A_arbace_a2g_embed_A_const_56 *lang.Var

var A_arbace_a2g_embed_A_const_57 *lang.Var

var A_arbace_a2g_embed_A_const_58 any

var A_arbace_a2g_embed_A_const_59 *lang.Var

var A_arbace_a2g_embed_A_const_60 *lang.Var

var A_arbace_a2g_embed_A_const_61 *lang.Var

var A_arbace_a2g_embed_A_const_62 *lang.Var

var A_arbace_a2g_embed_A_const_63 *lang.Var

var A_arbace_a2g_embed_A_const_64 *lang.Var

var A_arbace_a2g_embed_A_const_65 *lang.Var

var A_arbace_a2g_embed_A_const_66 *lang.Var

var A_arbace_a2g_embed_A_const_67 *lang.Var

var A_arbace_a2g_embed_A_const_68 *lang.Var

var A_arbace_a2g_embed_A_const_69 *lang.Var

var A_arbace_a2g_embed_A_const_70 *lang.Var

var A_arbace_a2g_embed_A_const_71 *lang.Var

var A_arbace_a2g_embed_A_const_72 *lang.Var

var A_arbace_a2g_embed_A_const_73 *lang.Var

var A_arbace_a2g_embed_A_const_74 *lang.Var

var A_arbace_a2g_embed_A_const_75 *lang.Var

var A_arbace_a2g_embed_A_const_76 *lang.Var

var A_arbace_a2g_embed_A_const_77 *lang.Var

var A_arbace_a2g_embed_A_const_78 any

var A_arbace_a2g_embed_A_const_79 any

var A_arbace_a2g_embed_A_const_80 *lang.Keyword

var A_arbace_a2g_embed_A_const_81 *lang.Var

var A_arbace_a2g_embed_A_const_82 *lang.Var

var A_arbace_a2g_embed_A_const_83 *lang.Var

var A_arbace_a2g_embed_A_const_84 *lang.Var

var A_arbace_a2g_embed_A_const_85 *lang.Var

var A_arbace_a2g_embed_A_const_86 *lang.Var

var A_arbace_a2g_embed_A_const_87 *lang.Var

var A_arbace_a2g_embed_A_const_88 *lang.Var

var A_arbace_a2g_embed_A_const_89 *lang.Var

var A_arbace_a2g_embed_A_const_90 *lang.Var

var A_arbace_a2g_embed_A_const_91 *lang.Var

var A_arbace_a2g_embed_A_const_92 *lang.Var

var A_arbace_a2g_embed_A_const_93 any

var A_arbace_a2g_embed_A_const_94 *lang.Var

var A_arbace_a2g_embed_A_const_95 *lang.Keyword

var A_arbace_a2g_embed_A_const_96 any

var A_arbace_a2g_embed_A_const_97 any

var A_arbace_a2g_embed_A_const_98 *lang.Var

var A_arbace_a2g_embed_A_const_99 *lang.Var

var A_arbace_a2g_embed_A_const_100 *lang.Var

var A_arbace_a2g_embed_A_const_101 any

var A_arbace_a2g_embed_A_const_102 *lang.Keyword

var A_arbace_a2g_embed_A_const_103 any

var A_arbace_a2g_embed_A_const_104 any

var A_arbace_a2g_embed_A_const_105 any

var A_arbace_a2g_embed_A_const_106 any

var A_arbace_a2g_embed_A_const_107 any

var A_arbace_a2g_embed_A_const_108 any

var A_arbace_a2g_embed_A_const_109 any

var A_arbace_a2g_embed_A_const_110 any

var A_arbace_a2g_embed_A_init jrt.ClassInit

func A_arbace_a2g_embed_A_Init() { if !A_arbace_a2g_embed_A_init.Done() { A_arbace_a2g_embed_A_init.Run(A_arbace_a2g_embed_A_clinit) } }

func A_arbace_a2g_embed_A_clinit() { A_arbace_a2g_embed_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_embed_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_embed_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_embed_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_embed_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_embed_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_embed_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_embed_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_a2g_embed_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_a2g_embed_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_a2g_embed_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_a2g_embed_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_a2g_embed_A_const_12 = lang.RT_Var_String_String__Var(Lit_6, Lit_19); A_arbace_a2g_embed_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_embed_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_a2g_embed_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_a2g_embed_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_a2g_embed_A_const_17 = lang.RT_Var_String_String__Var(Lit_3, Lit_24); A_arbace_a2g_embed_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_a2g_embed_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_a2g_embed_A_const_20 = lang.RT_Var_String_String__Var(Lit_3, Lit_26); A_arbace_a2g_embed_A_const_21 = lang.RT_Var_String_String__Var(Lit_15, Lit_27); A_arbace_a2g_embed_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_embed_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_a2g_embed_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_embed_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_a2g_embed_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_embed_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_a2g_embed_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_embed_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_a2g_embed_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_a2g_embed_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_a2g_embed_A_const_32 = lang.RT_Var_String_String__Var(Lit_15, Lit_38); A_arbace_a2g_embed_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_a2g_embed_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_a2g_embed_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_a2g_embed_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_a2g_embed_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_a2g_embed_A_const_38 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_a2g_embed_A_const_39 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_a2g_embed_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_a2g_embed_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_a2g_embed_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_a2g_embed_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_a2g_embed_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_a2g_embed_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_a2g_embed_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_a2g_embed_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_a2g_embed_A_const_48 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref(); A_arbace_a2g_embed_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_a2g_embed_A_const_50 = lang.RT_Keyword_String_String__Keyword(Lit_15, Lit_54); A_arbace_a2g_embed_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_a2g_embed_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_a2g_embed_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_a2g_embed_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_a2g_embed_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_a2g_embed_A_const_56 = lang.RT_Var_String_String__Var(Lit_15, Lit_60); A_arbace_a2g_embed_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_a2g_embed_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_15, Lit_54).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref())); A_arbace_a2g_embed_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_a2g_embed_A_const_60 = lang.RT_Var_String_String__Var(Lit_15, Lit_65); A_arbace_a2g_embed_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_a2g_embed_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_a2g_embed_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_a2g_embed_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_a2g_embed_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_a2g_embed_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_a2g_embed_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_a2g_embed_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_a2g_embed_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_a2g_embed_A_const_70 = lang.RT_Var_String_String__Var(Lit_15, Lit_75); A_arbace_a2g_embed_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_a2g_embed_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_a2g_embed_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_a2g_embed_A_const_74 = lang.RT_Var_String_String__Var(Lit_15, Lit_79); A_arbace_a2g_embed_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_a2g_embed_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_a2g_embed_A_const_77 = lang.RT_Var_String_String__Var(Lit_8, Lit_82); A_arbace_a2g_embed_A_const_78 = jrt.Pattern_Compile_String__Pattern(Lit_83).Ref(); A_arbace_a2g_embed_A_const_79 = jrt.Pattern_Compile_String__Pattern(Lit_84).Ref(); A_arbace_a2g_embed_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_a2g_embed_A_const_81 = lang.RT_Var_String_String__Var(Lit_3, Lit_86); A_arbace_a2g_embed_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_a2g_embed_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_a2g_embed_A_const_84 = lang.RT_Var_String_String__Var(Lit_15, Lit_89); A_arbace_a2g_embed_A_const_85 = lang.RT_Var_String_String__Var(Lit_10, Lit_90); A_arbace_a2g_embed_A_const_86 = lang.RT_Var_String_String__Var(Lit_10, Lit_91); A_arbace_a2g_embed_A_const_87 = lang.RT_Var_String_String__Var(Lit_15, Lit_92); A_arbace_a2g_embed_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_93); A_arbace_a2g_embed_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_a2g_embed_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_a2g_embed_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_a2g_embed_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_a2g_embed_A_const_93 = jrt.Pattern_Compile_String__Pattern(Lit_98).Ref(); A_arbace_a2g_embed_A_const_94 = lang.RT_Var_String_String__Var(Lit_8, Lit_99); A_arbace_a2g_embed_A_const_95 = lang.RT_Keyword_String_String__Keyword(nil, Lit_100); A_arbace_a2g_embed_A_const_96 = jrt.Pattern_Compile_String__Pattern(Lit_101).Ref(); A_arbace_a2g_embed_A_const_97 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_102, Lit_102), lang.Tuple_Create_O_O__IPersistentVector(Lit_103, Lit_103)); A_arbace_a2g_embed_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_a2g_embed_A_const_99 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_a2g_embed_A_const_100 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_a2g_embed_A_const_101 = lang.Symbol_Intern_String_String__Symbol(Lit_107, Lit_19).Ref(); A_arbace_a2g_embed_A_const_102 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_a2g_embed_A_const_103 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_109).Ref(), Lit_109), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(), Lit_110), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref(), Lit_111)); A_arbace_a2g_embed_A_const_104 = lang.Symbol_Intern_String_String__Symbol(Lit_107, Lit_112).Ref(); A_arbace_a2g_embed_A_const_105 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_113).Ref(); A_arbace_a2g_embed_A_const_106 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(); A_arbace_a2g_embed_A_const_107 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(); A_arbace_a2g_embed_A_const_108 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_116).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_109, Lit_117).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(230).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref()))); A_arbace_a2g_embed_A_const_109 = lang.Symbol_Intern_String_String__Symbol(Lit_109, Lit_120).Ref(); A_arbace_a2g_embed_A_const_110 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref() }

func A_arbace_a2g_embed_A_New() *A_arbace_a2g_embed_A { A_arbace_a2g_embed_A_Init(); t := &A_arbace_a2g_embed_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_embed_A) Ctor() {}

func (t *A_arbace_a2g_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_A_class }

func (t *A_arbace_a2g_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_A); return ok }

func A_arbace_a2g_embed_A_Cast(x any) *A_arbace_a2g_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_A_class)) }; return v }



type A_arbace_a2g_embed_class_like_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_class_like_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_class_like_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_embed_class_like_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_embed_class_like_QMARK__A_Init() { if !A_arbace_a2g_embed_class_like_QMARK__A_init.Done() { A_arbace_a2g_embed_class_like_QMARK__A_init.Run(A_arbace_a2g_embed_class_like_QMARK__A_clinit) } }

func A_arbace_a2g_embed_class_like_QMARK__A_clinit() { A_arbace_a2g_embed_class_like_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_class_like_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_class_like_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_class_like_QMARK__A_class }

func (t *A_arbace_a2g_embed_class_like_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_class_like_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_class_like_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_class_like_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_class_like_QMARK__A); return ok }

func A_arbace_a2g_embed_class_like_QMARK__A_Cast(x any) *A_arbace_a2g_embed_class_like_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_class_like_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_class_like_QMARK__A_class)) }; return v }



type A_arbace_a2g_embed_cut_candidates_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_cut_candidates_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_cut_candidates_A_fn_class *jrt.Class

var A_arbace_a2g_embed_cut_candidates_A_init jrt.ClassInit

func A_arbace_a2g_embed_cut_candidates_A_Init() { if !A_arbace_a2g_embed_cut_candidates_A_init.Done() { A_arbace_a2g_embed_cut_candidates_A_init.Run(A_arbace_a2g_embed_cut_candidates_A_clinit) } }

func A_arbace_a2g_embed_cut_candidates_A_clinit() { A_arbace_a2g_embed_cut_candidates_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_cut_candidates_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_cut_candidates_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_cut_candidates_A_class }

func (t *A_arbace_a2g_embed_cut_candidates_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_cut_candidates_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_cut_candidates_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_cut_candidates_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_cut_candidates_A); return ok }

func A_arbace_a2g_embed_cut_candidates_A_Cast(x any) *A_arbace_a2g_embed_cut_candidates_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_cut_candidates_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_cut_candidates_A_class)) }; return v }



type A_arbace_a2g_embed_cut_candidates_fn__1520000103_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_fn_class *jrt.Class

var A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_init jrt.ClassInit

func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_Init() { if !A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_init.Done() { A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_init.Run(A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_clinit) } }

func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_clinit() { A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_class }

func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_cut_candidates_fn__1520000103_A); return ok }

func A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_Cast(x any) *A_arbace_a2g_embed_cut_candidates_fn__1520000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_cut_candidates_fn__1520000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_cut_candidates_fn__1520000103_A_class)) }; return v }



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_fn_class *jrt.Class

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_init jrt.ClassInit

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_Init() { if !A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_init.Done() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_init.Run(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_clinit) } }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_clinit() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_class }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A); return ok }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_Cast(x any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_A_class)) }; return v }



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A struct{ jrt.Object; F_s__1520000089, F_iter__1520000088 any }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_fn_class *jrt.Class

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_init jrt.ClassInit

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_Init() { if !A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_init.Done() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_init.Run(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_clinit) } }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_clinit() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_class }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A); return ok }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_Cast(x any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_A_class)) }; return v }



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A struct{ jrt.Object; F_b__1520000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_fn_class *jrt.Class

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_init jrt.ClassInit

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_Init() { if !A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_init.Done() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_init.Run(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_clinit) } }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_clinit() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_class }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A); return ok }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_Cast(x any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_A_class)) }; return v }



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_fn_class *jrt.Class

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_init jrt.ClassInit

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_Init() { if !A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_init.Done() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_init.Run(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_clinit) } }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_clinit() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_class }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A); return ok }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_Cast(x any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000094_fn__1520000095_A_class)) }; return v }



type A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_fn_class *jrt.Class

var A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_init jrt.ClassInit

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_Init() { if !A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_init.Done() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_init.Run(A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_clinit) } }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_clinit() { A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_class }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A); return ok }

func A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_Cast(x any) *A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_cut_candidates_iter__1520000088__1520000092_fn__1520000093_fn__1520000098_A_class)) }; return v }



type A_arbace_a2g_embed_data_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_data_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_data_A_fn_class *jrt.Class

var A_arbace_a2g_embed_data_A_init jrt.ClassInit

func A_arbace_a2g_embed_data_A_Init() { if !A_arbace_a2g_embed_data_A_init.Done() { A_arbace_a2g_embed_data_A_init.Run(A_arbace_a2g_embed_data_A_clinit) } }

func A_arbace_a2g_embed_data_A_clinit() { A_arbace_a2g_embed_data_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_data_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_data_A_class }

func (t *A_arbace_a2g_embed_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_data_A); return ok }

func A_arbace_a2g_embed_data_A_Cast(x any) *A_arbace_a2g_embed_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_data_A_class)) }; return v }



type A_arbace_a2g_embed_data_iter__1520000152__1520000156_A struct{ jrt.Object; F_base any }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_fn_class *jrt.Class

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_init jrt.ClassInit

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_Init() { if !A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_init.Done() { A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_init.Run(A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_clinit) } }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_clinit() { A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_class }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_A); return ok }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_Cast(x any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_data_iter__1520000152__1520000156_A_class)) }; return v }



type A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A struct{ jrt.Object; F_base, F_s__1520000153, F_iter__1520000152 any }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_fn_class *jrt.Class

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_init jrt.ClassInit

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_Init() { if !A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_init.Done() { A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_init.Run(A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_clinit) } }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_clinit() { A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_class }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A); return ok }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_Cast(x any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_A_class)) }; return v }



type A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A struct{ jrt.Object; F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1520000155 any }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_fn_class *jrt.Class

var A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_init jrt.ClassInit

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_Init() { if !A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_init.Done() { A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_init.Run(A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_clinit) } }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_clinit() { A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_class }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A); return ok }

func A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_Cast(x any) *A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_data_iter__1520000152__1520000156_fn__1520000157_fn__1520000158_A_class)) }; return v }



type A_arbace_a2g_embed_eval1520000004_A struct{ jrt.Object }

func A_arbace_a2g_embed_eval1520000004_A_New() *A_arbace_a2g_embed_eval1520000004_A { t := &A_arbace_a2g_embed_eval1520000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_embed_eval1520000004_A) Ctor() {}

func (t *A_arbace_a2g_embed_eval1520000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_eval1520000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_eval1520000004_A_class }

func (t *A_arbace_a2g_embed_eval1520000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_eval1520000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_eval1520000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_eval1520000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_eval1520000004_A); return ok }

func A_arbace_a2g_embed_eval1520000004_A_Cast(x any) *A_arbace_a2g_embed_eval1520000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_eval1520000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_eval1520000004_A_class)) }; return v }



type A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_fn_class *jrt.Class

var A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_init jrt.ClassInit

func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_Init() { if !A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_init.Done() { A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_init.Run(A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_clinit) } }

func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_clinit() { A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_class }

func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A); return ok }

func A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_Cast(x any) *A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_class)) }; return v }



type A_arbace_a2g_embed_eval1520000008_A struct{ jrt.Object }

func A_arbace_a2g_embed_eval1520000008_A_New() *A_arbace_a2g_embed_eval1520000008_A { t := &A_arbace_a2g_embed_eval1520000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_embed_eval1520000008_A) Ctor() {}

func (t *A_arbace_a2g_embed_eval1520000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_eval1520000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_eval1520000008_A_class }

func (t *A_arbace_a2g_embed_eval1520000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_eval1520000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_eval1520000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_eval1520000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_eval1520000008_A); return ok }

func A_arbace_a2g_embed_eval1520000008_A_Cast(x any) *A_arbace_a2g_embed_eval1520000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_eval1520000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_eval1520000008_A_class)) }; return v }



type A_arbace_a2g_embed_eval1520000008_fn__1520000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_fn_class *jrt.Class

var A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_init jrt.ClassInit

func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_Init() { if !A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_init.Done() { A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_init.Run(A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_clinit) } }

func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_clinit() { A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_class }

func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_eval1520000008_fn__1520000009_A); return ok }

func A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_Cast(x any) *A_arbace_a2g_embed_eval1520000008_fn__1520000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_eval1520000008_fn__1520000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_image_type_forms_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_image_type_forms_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_A_Init() { if !A_arbace_a2g_embed_image_type_forms_A_init.Done() { A_arbace_a2g_embed_image_type_forms_A_init.Run(A_arbace_a2g_embed_image_type_forms_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_A_clinit() { A_arbace_a2g_embed_image_type_forms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_A); return ok }

func A_arbace_a2g_embed_image_type_forms_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_A struct{ jrt.Object; F_re any }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_Init() { if !A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_init.Done() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_init.Run(A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_clinit() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_A); return ok }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_fn__1520000183_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A struct{ jrt.Object; F_alias any }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_Init() { if !A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_init.Done() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_init.Run(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_clinit() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A); return ok }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A struct{ jrt.Object; F_alias, F_s__1520000188, F_iter__1520000187 any }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_Init() { if !A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_init.Done() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_init.Run(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_clinit() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A); return ok }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A struct{ jrt.Object; F_alias, F_b__1520000190 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_Init() { if !A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_init.Done() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_init.Run(A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_clinit() { A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_146, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A); return ok }

func A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_fn__1520000183_iter__1520000187__1520000191_fn__1520000192_fn__1520000193_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A struct{ jrt.Object; F_prog_dir any }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A struct{ jrt.Object; F_prog_dir, F_s__1520000164, F_iter__1520000163 any }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A struct{ jrt.Object; F_alias any }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_150, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A struct{ jrt.Object; F_alias, F_s__1520000166, F_iter__1520000165 any }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_151, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A struct{ jrt.Object; F_b__1520000168, F_alias any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_154, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000163__1520000169_fn__1520000170_iter__1520000165__1520000174_fn__1520000175_fn__1520000176_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A struct{ jrt.Object; F_iter__1520000204, F_s__1520000205 any }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_A_class)) }; return v }



type A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A struct{ jrt.Object; F_b__1520000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_fn_class *jrt.Class

var A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_init jrt.ClassInit

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_Init() { if !A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_init.Done() { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_init.Run(A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_clinit) } }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_clinit() { A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_class }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A); return ok }

func A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_Cast(x any) *A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_image_type_forms_iter__1520000204__1520000208_fn__1520000209_fn__1520000210_A_class)) }; return v }



type A_arbace_a2g_embed_names_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_names_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_names_A_fn_class *jrt.Class

var A_arbace_a2g_embed_names_A_init jrt.ClassInit

func A_arbace_a2g_embed_names_A_Init() { if !A_arbace_a2g_embed_names_A_init.Done() { A_arbace_a2g_embed_names_A_init.Run(A_arbace_a2g_embed_names_A_clinit) } }

func A_arbace_a2g_embed_names_A_clinit() { A_arbace_a2g_embed_names_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_names_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_names_A_class }

func (t *A_arbace_a2g_embed_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_names_A); return ok }

func A_arbace_a2g_embed_names_A_Cast(x any) *A_arbace_a2g_embed_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_names_A_class)) }; return v }



type A_arbace_a2g_embed_names_walk__1520000059_A struct{ jrt.Object; F_acc any }

func (t *A_arbace_a2g_embed_names_walk__1520000059_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_names_walk__1520000059_A_fn_class *jrt.Class

var A_arbace_a2g_embed_names_walk__1520000059_A_init jrt.ClassInit

func A_arbace_a2g_embed_names_walk__1520000059_A_Init() { if !A_arbace_a2g_embed_names_walk__1520000059_A_init.Done() { A_arbace_a2g_embed_names_walk__1520000059_A_init.Run(A_arbace_a2g_embed_names_walk__1520000059_A_clinit) } }

func A_arbace_a2g_embed_names_walk__1520000059_A_clinit() { A_arbace_a2g_embed_names_walk__1520000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_159, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_names_walk__1520000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_names_walk__1520000059_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_names_walk__1520000059_A_class }

func (t *A_arbace_a2g_embed_names_walk__1520000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_names_walk__1520000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_names_walk__1520000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_names_walk__1520000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_names_walk__1520000059_A); return ok }

func A_arbace_a2g_embed_names_walk__1520000059_A_Cast(x any) *A_arbace_a2g_embed_names_walk__1520000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_names_walk__1520000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_names_walk__1520000059_A_class)) }; return v }



type A_arbace_a2g_embed_package_like_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_package_like_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_package_like_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_embed_package_like_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_embed_package_like_QMARK__A_Init() { if !A_arbace_a2g_embed_package_like_QMARK__A_init.Done() { A_arbace_a2g_embed_package_like_QMARK__A_init.Run(A_arbace_a2g_embed_package_like_QMARK__A_clinit) } }

func A_arbace_a2g_embed_package_like_QMARK__A_clinit() { A_arbace_a2g_embed_package_like_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_package_like_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_package_like_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_package_like_QMARK__A_class }

func (t *A_arbace_a2g_embed_package_like_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_package_like_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_package_like_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_package_like_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_package_like_QMARK__A); return ok }

func A_arbace_a2g_embed_package_like_QMARK__A_Cast(x any) *A_arbace_a2g_embed_package_like_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_package_like_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_package_like_QMARK__A_class)) }; return v }



type A_arbace_a2g_embed_read_all_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_read_all_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_read_all_A_fn_class *jrt.Class

var A_arbace_a2g_embed_read_all_A_init jrt.ClassInit

func A_arbace_a2g_embed_read_all_A_Init() { if !A_arbace_a2g_embed_read_all_A_init.Done() { A_arbace_a2g_embed_read_all_A_init.Run(A_arbace_a2g_embed_read_all_A_clinit) } }

func A_arbace_a2g_embed_read_all_A_clinit() { A_arbace_a2g_embed_read_all_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_read_all_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_read_all_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_read_all_A_class }

func (t *A_arbace_a2g_embed_read_all_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_read_all_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_read_all_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_read_all_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_read_all_A); return ok }

func A_arbace_a2g_embed_read_all_A_Cast(x any) *A_arbace_a2g_embed_read_all_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_read_all_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_read_all_A_class)) }; return v }



type A_arbace_a2g_embed_read_all_fn__1520000054_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_embed_read_all_fn__1520000054_A_fn_class *jrt.Class

var A_arbace_a2g_embed_read_all_fn__1520000054_A_init jrt.ClassInit

func A_arbace_a2g_embed_read_all_fn__1520000054_A_Init() { if !A_arbace_a2g_embed_read_all_fn__1520000054_A_init.Done() { A_arbace_a2g_embed_read_all_fn__1520000054_A_init.Run(A_arbace_a2g_embed_read_all_fn__1520000054_A_clinit) } }

func A_arbace_a2g_embed_read_all_fn__1520000054_A_clinit() { A_arbace_a2g_embed_read_all_fn__1520000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_read_all_fn__1520000054_A_class }

func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_read_all_fn__1520000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_read_all_fn__1520000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_read_all_fn__1520000054_A); return ok }

func A_arbace_a2g_embed_read_all_fn__1520000054_A_Cast(x any) *A_arbace_a2g_embed_read_all_fn__1520000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_read_all_fn__1520000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_read_all_fn__1520000054_A_class)) }; return v }



type A_arbace_a2g_embed_reify__1520000052_A struct{ jrt.Object; F___meta lang.IPersistentMap }

func (t *A_arbace_a2g_embed_reify__1520000052_A) Is_LispReader_Resolver() {}

func (t *A_arbace_a2g_embed_reify__1520000052_A) Is_IObj() {}

func (t *A_arbace_a2g_embed_reify__1520000052_A) Is_IMeta() {}

func (t *A_arbace_a2g_embed_reify__1520000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_reify__1520000052_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_reify__1520000052_A_class }

func (t *A_arbace_a2g_embed_reify__1520000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_reify__1520000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_reify__1520000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_reify__1520000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_reify__1520000052_A); return ok }

func A_arbace_a2g_embed_reify__1520000052_A_Cast(x any) *A_arbace_a2g_embed_reify__1520000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_reify__1520000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_reify__1520000052_A_class)) }; return v }



type A_arbace_a2g_embed_sources_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_sources_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_sources_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_A_Init() { if !A_arbace_a2g_embed_sources_A_init.Done() { A_arbace_a2g_embed_sources_A_init.Run(A_arbace_a2g_embed_sources_A_clinit) } }

func A_arbace_a2g_embed_sources_A_clinit() { A_arbace_a2g_embed_sources_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_A_class }

func (t *A_arbace_a2g_embed_sources_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_A); return ok }

func A_arbace_a2g_embed_sources_A_Cast(x any) *A_arbace_a2g_embed_sources_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_A_class)) }; return v }



type A_arbace_a2g_embed_sources_fn__1520000038_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_embed_sources_fn__1520000038_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_fn__1520000038_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_fn__1520000038_A_Init() { if !A_arbace_a2g_embed_sources_fn__1520000038_A_init.Done() { A_arbace_a2g_embed_sources_fn__1520000038_A_init.Run(A_arbace_a2g_embed_sources_fn__1520000038_A_clinit) } }

func A_arbace_a2g_embed_sources_fn__1520000038_A_clinit() { A_arbace_a2g_embed_sources_fn__1520000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_fn__1520000038_A_class }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_fn__1520000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_fn__1520000038_A); return ok }

func A_arbace_a2g_embed_sources_fn__1520000038_A_Cast(x any) *A_arbace_a2g_embed_sources_fn__1520000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_fn__1520000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_fn__1520000038_A_class)) }; return v }



type A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A struct{ jrt.Object; F_p, F_pairs, F_rel any }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_Init() { if !A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_init.Done() { A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_init.Run(A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_clinit) } }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_clinit() { A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_class }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A); return ok }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_Cast(x any) *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_A_class)) }; return v }



type A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A struct{ jrt.Object; F_p, F_rel any }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_Init() { if !A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_init.Done() { A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_init.Run(A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_clinit) } }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_clinit() { A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_class }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A); return ok }

func A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_Cast(x any) *A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_fn__1520000038_fn__1520000042_fn__1520000044_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A struct{ jrt.Object; F_base any }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_175, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000013__1520000017_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A struct{ jrt.Object; F_base, F_s__1520000014, F_iter__1520000013 any }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_176, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A struct{ jrt.Object; F_b__1520000016, F_base any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_177, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A struct{ jrt.Object; F_rel any }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_178, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000019_fn__1520000020_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A struct{ jrt.Object; F_rel any }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_179, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000013__1520000017_fn__1520000018_fn__1520000023_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A struct{ jrt.Object; F_vdir any }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000027__1520000031_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A struct{ jrt.Object; F_vdir, F_s__1520000028, F_iter__1520000027 any }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_A_class)) }; return v }



type A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A struct{ jrt.Object; F_vdir, F_b__1520000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_fn_class *jrt.Class

var A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_init jrt.ClassInit

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_Init() { if !A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_init.Done() { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_init.Run(A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_clinit) } }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_clinit() { A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_class }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A); return ok }

func A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_Cast(x any) *A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_sources_iter__1520000027__1520000031_fn__1520000032_fn__1520000033_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_with_member_types_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_embed_with_member_types_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_A_Init() { if !A_arbace_a2g_embed_with_member_types_A_init.Done() { A_arbace_a2g_embed_with_member_types_A_init.Run(A_arbace_a2g_embed_with_member_types_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_A_clinit() { A_arbace_a2g_embed_with_member_types_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_183, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_A_class }

func (t *A_arbace_a2g_embed_with_member_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_A); return ok }

func A_arbace_a2g_embed_with_member_types_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_elem__1520000117_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_elem__1520000117_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_elem__1520000117_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_Init() { if !A_arbace_a2g_embed_with_member_types_elem__1520000117_A_init.Done() { A_arbace_a2g_embed_with_member_types_elem__1520000117_A_init.Run(A_arbace_a2g_embed_with_member_types_elem__1520000117_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_clinit() { A_arbace_a2g_embed_with_member_types_elem__1520000117_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_184, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_elem__1520000117_A_class }

func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_elem__1520000117_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_elem__1520000117_A); return ok }

func A_arbace_a2g_embed_with_member_types_elem__1520000117_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_elem__1520000117_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_elem__1520000117_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_elem__1520000117_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A struct{ jrt.Object; F_in_world_QMARK_, F_member_types any }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_Init() { if !A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_init.Done() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_init.Run(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_clinit() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_185, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_class }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A); return ok }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A struct{ jrt.Object; F_in_world_QMARK_, F_member_types, F_s__1520000134, F_iter__1520000133 any }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_Init() { if !A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_init.Done() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_init.Run(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_clinit() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_186, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_class }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A); return ok }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A struct{ jrt.Object; F_n, F_member_types any }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_Init() { if !A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_init.Done() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_init.Run(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_clinit() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_187, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_class }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A); return ok }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_fn__1520000147_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A struct{ jrt.Object; F_in_world_QMARK_ any }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_Init() { if !A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_init.Done() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_init.Run(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_clinit() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_188, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_class }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A); return ok }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A struct{ jrt.Object; F_in_world_QMARK_, F_s__1520000136, F_iter__1520000135 any }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_Init() { if !A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_init.Done() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_init.Run(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_clinit() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_189, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_class }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A); return ok }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A struct{ jrt.Object; F_b__1520000138, F_in_world_QMARK_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_Init() { if !A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_init.Done() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_init.Run(A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_clinit() { A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_190, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_class }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A); return ok }

func A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_iter__1520000133__1520000139_fn__1520000140_iter__1520000135__1520000141_fn__1520000142_fn__1520000143_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_A struct{ jrt.Object; F_elem, F_types any }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_Init() { if !A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_init.Done() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_init.Run(A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_clinit() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_191, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_class }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_A); return ok }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_member_types__1520000119_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A struct{ jrt.Object; F_n any }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_Init() { if !A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_init.Done() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_init.Run(A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_clinit() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_192, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_class }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A); return ok }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_member_types__1520000119_fn__1520000120_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_Init() { if !A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_init.Done() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_init.Run(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_clinit() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_193, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_class }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A); return ok }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A struct{ jrt.Object; F_s__1520000123, F_iter__1520000122 any }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_Init() { if !A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_init.Done() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_init.Run(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_clinit() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_class }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A); return ok }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A struct{ jrt.Object; F_b__1520000125 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_Init() { if !A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_init.Done() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_init.Run(A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_clinit() { A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_195, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_class }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A); return ok }

func A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_member_types__1520000119_iter__1520000122__1520000126_fn__1520000127_fn__1520000128_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_types__1520000109_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_types__1520000109_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_types__1520000109_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_types__1520000109_A_Init() { if !A_arbace_a2g_embed_with_member_types_types__1520000109_A_init.Done() { A_arbace_a2g_embed_with_member_types_types__1520000109_A_init.Run(A_arbace_a2g_embed_with_member_types_types__1520000109_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_types__1520000109_A_clinit() { A_arbace_a2g_embed_with_member_types_types__1520000109_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_types__1520000109_A_class }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_A); return ok }

func A_arbace_a2g_embed_with_member_types_types__1520000109_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_types__1520000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_types__1520000109_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_Init() { if !A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_init.Done() { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_init.Run(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_clinit() { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_class }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A); return ok }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000110_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_Init() { if !A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_init.Done() { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_init.Run(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_clinit() { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_class }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A); return ok }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000112_A_class)) }; return v }



type A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A struct{ jrt.Object }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_fn_class *jrt.Class

var A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_init jrt.ClassInit

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_Init() { if !A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_init.Done() { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_init.Run(A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_clinit) } }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_clinit() { A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_class }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A); return ok }

func A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_Cast(x any) *A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed_with_member_types_types__1520000109_fn__1520000114_A_class)) }; return v }
