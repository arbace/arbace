//line aot_arbace_a2g_embed__init.ae:1
package aot_arbace_a2g_embed

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_embed__init_A_Unit0__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_embed__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_embed__init_A_const_1) }
//line :1:1
func A_arbace_a2g_embed__init_A_Unit1__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_embed__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_embed__init_A_Unit2__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_Init(); tmp2 = A_arbace_a2g_embed_eval1520000004_loading__1927001464__auto____1520000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_embed__init_A_Unit3__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_embed__init_A_const_1)).Equals_O__Z(A_arbace_a2g_embed__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_Init(); tmp2 = A_arbace_a2g_embed_eval1520000008_fn__1520000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_embed__init_A_Load__O() any { A_arbace_a2g_embed__init_A_Init(); A_arbace_a2g_embed__init_A_Unit0__O(); A_arbace_a2g_embed__init_A_Unit1__O(); A_arbace_a2g_embed__init_A_Unit2__O(); A_arbace_a2g_embed__init_A_Unit3__O(); A_arbace_a2g_embed__init_A_Unit4__O(); A_arbace_a2g_embed__init_A_Unit5__O(); A_arbace_a2g_embed__init_A_Unit6__O(); A_arbace_a2g_embed__init_A_Unit7__O(); A_arbace_a2g_embed__init_A_Unit8__O(); A_arbace_a2g_embed__init_A_Unit9__O(); A_arbace_a2g_embed__init_A_Unit10__O(); A_arbace_a2g_embed__init_A_Unit11__O(); A_arbace_a2g_embed__init_A_Unit12__O(); A_arbace_a2g_embed__init_A_Unit13__O(); A_arbace_a2g_embed__init_A_Unit14__O(); A_arbace_a2g_embed__init_A_Unit15__O(); A_arbace_a2g_embed__init_A_Unit16__O(); A_arbace_a2g_embed__init_A_Unit17__O(); A_arbace_a2g_embed__init_A_Unit18__O(); return nil }













func A_arbace_a2g_embed__init_A_Unit4__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); jrt.NN(A_arbace_a2g_embed__init_A_const_4).BindRoot_O__V(A_arbace_a2g_embed__init_A_const_5); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_6)); return A_arbace_a2g_embed__init_A_const_4.Ref() }


















func A_arbace_a2g_embed__init_A_Unit5__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); jrt.NN(A_arbace_a2g_embed__init_A_const_7).BindRoot_O__V(Lit_238); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_7; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_8)); return A_arbace_a2g_embed__init_A_const_7.Ref() }

func A_arbace_a2g_embed__init_A_Unit6__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(40, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_9; var tmp2 any = A_arbace_a2g_embed_sources_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_sources_A_Init(); tmp3 = A_arbace_a2g_embed_sources_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_10)); return A_arbace_a2g_embed__init_A_const_9.Ref() }









































func A_arbace_a2g_embed__init_A_Unit7__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_11; jrt.NN(tmp1).BindRoot_O__V(A_arbace_a2g_embed_reify__1520000052_A_New_IPersistentMap(nil)); var tmp2 *lang.Var = A_arbace_a2g_embed__init_A_const_11; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_12)); return A_arbace_a2g_embed__init_A_const_11.Ref() }







func A_arbace_a2g_embed__init_A_Unit8__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(90, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_13; var tmp2 any = A_arbace_a2g_embed_read_all_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_read_all_A_Init(); tmp3 = A_arbace_a2g_embed_read_all_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_14)); return A_arbace_a2g_embed__init_A_const_13.Ref() }








func A_arbace_a2g_embed__init_A_Unit9__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_15; var tmp2 any = A_arbace_a2g_embed_class_like_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_class_like_QMARK__A_Init(); tmp3 = A_arbace_a2g_embed_class_like_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_16)); return A_arbace_a2g_embed__init_A_const_15.Ref() }



func A_arbace_a2g_embed__init_A_Unit10__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(103, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_17; var tmp2 any = A_arbace_a2g_embed_package_like_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_package_like_QMARK__A_Init(); tmp3 = A_arbace_a2g_embed_package_like_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_18)); return A_arbace_a2g_embed__init_A_const_17.Ref() }


func A_arbace_a2g_embed__init_A_Unit11__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_19; var tmp2 any = A_arbace_a2g_embed_names_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_names_A_Init(); tmp3 = A_arbace_a2g_embed_names_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_20)); return A_arbace_a2g_embed__init_A_const_19.Ref() }























func A_arbace_a2g_embed__init_A_Unit12__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); jrt.NN(A_arbace_a2g_embed__init_A_const_21).BindRoot_O__V(A_arbace_a2g_embed__init_A_const_22); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_21; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_23)); return A_arbace_a2g_embed__init_A_const_21.Ref() }










func A_arbace_a2g_embed__init_A_Unit13__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(141, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_24; var tmp2 any = A_arbace_a2g_embed_cut_candidates_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_cut_candidates_A_Init(); tmp3 = A_arbace_a2g_embed_cut_candidates_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_25)); return A_arbace_a2g_embed__init_A_const_24.Ref() }













func A_arbace_a2g_embed__init_A_Unit14__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_26; var tmp2 any = A_arbace_a2g_embed_with_member_types_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_with_member_types_A_Init(); tmp3 = A_arbace_a2g_embed_with_member_types_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_27)); return A_arbace_a2g_embed__init_A_const_26.Ref() }






























func A_arbace_a2g_embed__init_A_Unit15__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(186, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_28; var tmp2 any = A_arbace_a2g_embed_data_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_data_A_Init(); tmp3 = A_arbace_a2g_embed_data_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_29)); return A_arbace_a2g_embed__init_A_const_28.Ref() }
















func A_arbace_a2g_embed__init_A_Unit16__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(203, 1); jrt.NN(A_arbace_a2g_embed__init_A_const_30).BindRoot_O__V(Lit_239); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_31)); return A_arbace_a2g_embed__init_A_const_30.Ref() }



func A_arbace_a2g_embed__init_A_Unit17__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(207, 1); jrt.NN(A_arbace_a2g_embed__init_A_const_32).BindRoot_O__V(A_arbace_a2g_embed__init_A_const_33); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_32; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_34)); return A_arbace_a2g_embed__init_A_const_32.Ref() }




func A_arbace_a2g_embed__init_A_Unit18__O() any { A_arbace_a2g_embed__init_A_Init(); lang.Compiler_AOT_At_I_I__V(212, 1); var tmp1 *lang.Var = A_arbace_a2g_embed__init_A_const_35; var tmp2 any = A_arbace_a2g_embed_image_type_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_embed_image_type_forms_A_Init(); tmp3 = A_arbace_a2g_embed_image_type_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_embed__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_embed__init_A_const_36)); return A_arbace_a2g_embed__init_A_const_35.Ref() }



type A_arbace_a2g_embed__init_A struct{ jrt.Object }

var A_arbace_a2g_embed__init_A_const_0 *lang.Var

var A_arbace_a2g_embed__init_A_const_1 any

var A_arbace_a2g_embed__init_A_const_2 any

var A_arbace_a2g_embed__init_A_const_3 any

var A_arbace_a2g_embed__init_A_const_4 *lang.Var

var A_arbace_a2g_embed__init_A_const_5 any

var A_arbace_a2g_embed__init_A_const_6 any

var A_arbace_a2g_embed__init_A_const_7 *lang.Var

var A_arbace_a2g_embed__init_A_const_8 any

var A_arbace_a2g_embed__init_A_const_9 *lang.Var

var A_arbace_a2g_embed__init_A_const_10 any

var A_arbace_a2g_embed__init_A_const_11 *lang.Var

var A_arbace_a2g_embed__init_A_const_12 any

var A_arbace_a2g_embed__init_A_const_13 *lang.Var

var A_arbace_a2g_embed__init_A_const_14 any

var A_arbace_a2g_embed__init_A_const_15 *lang.Var

var A_arbace_a2g_embed__init_A_const_16 any

var A_arbace_a2g_embed__init_A_const_17 *lang.Var

var A_arbace_a2g_embed__init_A_const_18 any

var A_arbace_a2g_embed__init_A_const_19 *lang.Var

var A_arbace_a2g_embed__init_A_const_20 any

var A_arbace_a2g_embed__init_A_const_21 *lang.Var

var A_arbace_a2g_embed__init_A_const_22 any

var A_arbace_a2g_embed__init_A_const_23 any

var A_arbace_a2g_embed__init_A_const_24 *lang.Var

var A_arbace_a2g_embed__init_A_const_25 any

var A_arbace_a2g_embed__init_A_const_26 *lang.Var

var A_arbace_a2g_embed__init_A_const_27 any

var A_arbace_a2g_embed__init_A_const_28 *lang.Var

var A_arbace_a2g_embed__init_A_const_29 any

var A_arbace_a2g_embed__init_A_const_30 *lang.Var

var A_arbace_a2g_embed__init_A_const_31 any

var A_arbace_a2g_embed__init_A_const_32 *lang.Var

var A_arbace_a2g_embed__init_A_const_33 any

var A_arbace_a2g_embed__init_A_const_34 any

var A_arbace_a2g_embed__init_A_const_35 *lang.Var

var A_arbace_a2g_embed__init_A_const_36 any

var A_arbace_a2g_embed__init_A_init jrt.ClassInit

func A_arbace_a2g_embed__init_A_Init() { if !A_arbace_a2g_embed__init_A_init.Done() { A_arbace_a2g_embed__init_A_init.Run(A_arbace_a2g_embed__init_A_clinit) } }

func A_arbace_a2g_embed__init_A_clinit() { A_arbace_a2g_embed__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_200); A_arbace_a2g_embed__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_a2g_embed__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_a2g_embed__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_embed__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_15, Lit_27); A_arbace_a2g_embed__init_A_const_5 = lang.RT_Vector_O1__IPersistentVector(jrt.ConstRefArray("[0,14,s21:arbace/classes/jvm.aes11:arbace/j2a/s17:arbace/a2g/jvm.aes12:arbace/lang/s14:arbace/lang.aes15:arbace/java/apis19:arbace/repl/deps.aes17:arbace/java/basiss18:arbace/tools/deps/s18:arbace/java/browses22:arbace/java/javadoc.aes19:arbace/inspector.aes13:arbace/xml.aes27:arbace/instant_timestamp.ae", []*jrt.Class{jrt.Object_class})); A_arbace_a2g_embed__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_202)); A_arbace_a2g_embed__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_15, Lit_38); A_arbace_a2g_embed__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_15, Lit_203); A_arbace_a2g_embed__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_205).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_206, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_15, Lit_60); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_embed__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_208)); A_arbace_a2g_embed__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_15, Lit_79); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_embed__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_209).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(90).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_15, Lit_65); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_embed__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_210)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_211).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_212).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_15, Lit_75); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_207).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_embed__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_210)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_211).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_212).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(103).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_15, Lit_92); A_arbace_a2g_embed__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_209).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_213, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(106).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_15, Lit_89); A_arbace_a2g_embed__init_A_const_22 = lang.Tuple_Create_O_O_O_O__IPersistentVector(Lit_214, Lit_215, Lit_216, Lit_217); A_arbace_a2g_embed__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_218)); A_arbace_a2g_embed__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_15, Lit_219); A_arbace_a2g_embed__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_220).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_221, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_15, Lit_222); A_arbace_a2g_embed__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_223).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_224).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_225, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(155).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_15, Lit_226); A_arbace_a2g_embed__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_227).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_228, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(186).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)); A_arbace_a2g_embed__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_15, Lit_229); A_arbace_a2g_embed__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(203).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_230)); A_arbace_a2g_embed__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_15, Lit_231); A_arbace_a2g_embed__init_A_const_33 = lang.Tuple_Create_O_O__IPersistentVector(Lit_232, Lit_233); A_arbace_a2g_embed__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(207).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_234)); A_arbace_a2g_embed__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_15, Lit_235); A_arbace_a2g_embed__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_204).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_237, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), jrt.Integer_ValueOf_I__Integer(212).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_119).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), Lit_201)) }

func A_arbace_a2g_embed__init_A_New() *A_arbace_a2g_embed__init_A { A_arbace_a2g_embed__init_A_Init(); t := &A_arbace_a2g_embed__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_embed__init_A) Ctor() {}

func (t *A_arbace_a2g_embed__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_embed__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_embed__init_A_class }

func (t *A_arbace_a2g_embed__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_embed__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_embed__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_embed__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_embed__init_A); return ok }

func A_arbace_a2g_embed__init_A_Cast(x any) *A_arbace_a2g_embed__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_embed__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_embed__init_A_class)) }; return v }
