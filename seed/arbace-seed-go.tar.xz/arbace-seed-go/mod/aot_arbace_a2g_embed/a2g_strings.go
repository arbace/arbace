//line a2g_strings.ae:1
package aot_arbace_a2g_embed

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_7 *jrt.String = jrt.Intern("io")

var Lit_8 *jrt.String = jrt.Intern("arbace.a2g.edge")

var Lit_9 *jrt.String = jrt.Intern("edge")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_11 *jrt.String = jrt.Intern("m")

var Lit_12 *jrt.String = jrt.Intern("commute")

var Lit_13 *jrt.String = jrt.Intern("deref")

var Lit_14 *jrt.String = jrt.Intern("conj")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.embed")

var Lit_16 *jrt.String = jrt.Intern("doc")

var Lit_17 *jrt.String = jrt.Intern("bin/a2g --program: the namespaces' sources the executable embeds (A2G-SPEC §10.3, §10.6;\n  doc/go/EVAL-NOTES.md, \"Loading\"), and the classes they name that are outside the closed\n  world (registered as cut classes, so that imports and hints resolve).\n\n  The embedded tree is arbace/**/*.ae less the tools (j2a, g2a, a2g, the class forms' JVM-only\n  class file reader), the runtime's class forms (arbace/lang, compiled into the program), and\n  the namespaces the Go build leaves out (JAVA-SURFACE.md decision 6, B1-PLAN.md D6). The Go build's namespace\n  variants, arbace/lang/go/ns/P.ae, replace arbace/P.ae; arbace/lang/go/ns/P.after.ae is\n  appended to it; arbace/lang/go/ns/P.subst.ae, a vector [old new ...] of strings, replaces\n  each old (found exactly once) in it.")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("file")

var Lit_20 *jrt.String = jrt.Intern("seq")

var Lit_21 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_22 *jrt.String = jrt.Intern("chunk-first")

var Lit_23 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_24 *jrt.String = jrt.Intern("ends-with?")

var Lit_25 *jrt.String = jrt.Intern("not-any?")

var Lit_26 *jrt.String = jrt.Intern("starts-with?")

var Lit_27 *jrt.String = jrt.Intern("excluded")

var Lit_28 *jrt.String = jrt.Intern("chunk-append")

var Lit_29 *jrt.String = jrt.Intern("slurp")

var Lit_30 *jrt.String = jrt.Intern("chunk-cons")

var Lit_31 *jrt.String = jrt.Intern("first")

var Lit_32 *jrt.String = jrt.Intern("cons")

var Lit_33 *jrt.String = jrt.Intern("chunk")

var Lit_34 *jrt.String = jrt.Intern("chunk-rest")

var Lit_35 *jrt.String = jrt.Intern("rest")

var Lit_36 *jrt.String = jrt.Intern("reduce")

var Lit_37 *jrt.String = jrt.Intern("file-seq")

var Lit_38 *jrt.String = jrt.Intern("variants-dir")

var Lit_39 *jrt.String = jrt.Intern("subs")

var Lit_40 *jrt.String = jrt.Intern("partition")

var Lit_41 *jrt.String = jrt.Intern("update")

var Lit_42 *jrt.String = jrt.Intern("else")

var Lit_43 *jrt.String = jrt.Intern("assoc")

var Lit_44 *jrt.String = jrt.Intern("read-string")

var Lit_45 *jrt.String = jrt.Intern("contains?")

var Lit_46 *jrt.String = jrt.Intern("ex-info")

var Lit_47 *jrt.String = jrt.Intern("not=")

var Lit_48 *jrt.String = jrt.Intern("pr-str")

var Lit_49 *jrt.String = jrt.Intern("into")

var Lit_50 *jrt.String = jrt.Intern("sort-by")

var Lit_51 *jrt.String = jrt.Intern("sorted-map")

var Lit_52 *jrt.String = jrt.Intern("user")

var Lit_53 *jrt.String = jrt.Intern("read")

var Lit_54 *jrt.String = jrt.Intern("eof")

var Lit_55 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_56 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_57 *jrt.String = jrt.Intern("hash-map")

var Lit_58 *jrt.String = jrt.Intern("*read-eval*")

var Lit_59 *jrt.String = jrt.Intern("*reader-resolver*")

var Lit_60 *jrt.String = jrt.Intern("resolver")

var Lit_61 *jrt.String = jrt.Intern("*default-data-reader-fn*")

var Lit_62 *jrt.String = jrt.Intern("read-cond")

var Lit_63 *jrt.String = jrt.Intern("allow")

var Lit_64 *jrt.String = jrt.Intern("not")

var Lit_65 *jrt.String = jrt.Intern("class-like?")

var Lit_66 *jrt.String = jrt.Intern("transient")

var Lit_67 *jrt.String = jrt.Intern("symbol?")

var Lit_68 *jrt.String = jrt.Intern("namespace")

var Lit_69 *jrt.String = jrt.Intern("conj!")

var Lit_70 *jrt.String = jrt.Intern("seq?")

var Lit_71 *jrt.String = jrt.Intern("vector?")

var Lit_72 *jrt.String = jrt.Intern("map?")

var Lit_73 *jrt.String = jrt.Intern("set?")

var Lit_74 *jrt.String = jrt.Intern("name")

var Lit_75 *jrt.String = jrt.Intern("package-like?")

var Lit_76 *jrt.String = jrt.Intern("every?")

var Lit_77 *jrt.String = jrt.Intern("next")

var Lit_78 *jrt.String = jrt.Intern("persistent!")

var Lit_79 *jrt.String = jrt.Intern("read-all")

var Lit_80 *jrt.String = jrt.Intern("set")

var Lit_81 *jrt.String = jrt.Intern("re-find")

var Lit_82 *jrt.String = jrt.Intern("jvm?")

var Lit_83 *jrt.String = jrt.Intern("^(java|javax|jdk|sun)\\.")

var Lit_84 *jrt.String = jrt.Intern("^arbace\\.lang\\.")

var Lit_85 *jrt.String = jrt.Intern("exists")

var Lit_86 *jrt.String = jrt.Intern("replace")

var Lit_87 *jrt.String = jrt.Intern("concat")

var Lit_88 *jrt.String = jrt.Intern("apply")

var Lit_89 *jrt.String = jrt.Intern("library-cuts")

var Lit_90 *jrt.String = jrt.Intern("par-mapv")

var Lit_91 *jrt.String = jrt.Intern("jobs")

var Lit_92 *jrt.String = jrt.Intern("names")

var Lit_93 *jrt.String = jrt.Intern("mapcat")

var Lit_94 *jrt.String = jrt.Intern("map")

var Lit_95 *jrt.String = jrt.Intern("vec")

var Lit_96 *jrt.String = jrt.Intern("sort")

var Lit_97 *jrt.String = jrt.Intern("distinct")

var Lit_98 *jrt.String = jrt.Intern("^(java|javax|jdk|sun)/")

var Lit_99 *jrt.String = jrt.Intern("jvm")

var Lit_100 *jrt.String = jrt.Intern("member-types")

var Lit_101 *jrt.String = jrt.Intern("\\(go/type ([A-Z][A-Za-z0-9_]*)\\s+(?:\\\"(?:[^\\\"\\\\]|\\\\.)*\\\"\\s+)?\\(struct[ )]")

var Lit_102 *jrt.String = jrt.Intern("lang")

var Lit_103 *jrt.String = jrt.Intern("jrt")

var Lit_104 *jrt.String = jrt.Intern("symbol")

var Lit_105 *jrt.String = jrt.Intern("re-seq")

var Lit_106 *jrt.String = jrt.Intern("list")

var Lit_107 *jrt.String = jrt.Intern("go")

var Lit_108 *jrt.String = jrt.Intern("imports")

var Lit_109 *jrt.String = jrt.Intern("reflect")

var Lit_110 *jrt.String = jrt.Intern("arbace/jrt")

var Lit_111 *jrt.String = jrt.Intern("arbace/lang")

var Lit_112 *jrt.String = jrt.Intern("func")

var Lit_113 *jrt.String = jrt.Intern("init")

var Lit_114 *jrt.String = jrt.Intern("registerImageTypes")

var Lit_115 *jrt.String = jrt.Intern("lit")

var Lit_116 *jrt.String = jrt.Intern("slice")

var Lit_117 *jrt.String = jrt.Intern("Type")

var Lit_118 *jrt.String = jrt.Intern("line")

var Lit_119 *jrt.String = jrt.Intern("column")

var Lit_120 *jrt.String = jrt.Intern("TypeOf")

var Lit_121 *jrt.String = jrt.Intern("arbace.a2g.embed$class_like_QMARK_")

var Lit_122 *jrt.String = jrt.Intern(".")

var Lit_123 *jrt.String = jrt.Intern("arbace.a2g.embed$cut_candidates")

var Lit_124 *jrt.String = jrt.Intern("arbace.a2g.embed$cut_candidates$fn__1520000103")

var Lit_125 *jrt.String = jrt.Intern("arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092")

var Lit_126 *jrt.String = jrt.Intern("arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093")

var Lit_127 *jrt.String = jrt.Intern("/")

var Lit_128 *jrt.String = jrt.Intern("arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093$fn__1520000094")

var Lit_129 *jrt.String = jrt.Intern("arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093$fn__1520000094$fn__1520000095")

var Lit_130 *jrt.String = jrt.Intern("arbace.a2g.embed$cut_candidates$iter__1520000088__1520000092$fn__1520000093$fn__1520000098")

var Lit_131 *jrt.String = jrt.Intern("arbace.a2g.embed$data")

var Lit_132 *jrt.String = jrt.Intern("arbace.a2g.embed$data$iter__1520000152__1520000156")

var Lit_133 *jrt.String = jrt.Intern("arbace.a2g.embed$data$iter__1520000152__1520000156$fn__1520000157")

var Lit_134 *jrt.String = jrt.Intern("arbace.a2g.embed$data$iter__1520000152__1520000156$fn__1520000157$fn__1520000158")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.embed$eval1520000004$loading__1927001464__auto____1520000005")

var Lit_136 *jrt.String = jrt.Intern("java.io.File")

var Lit_137 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_138 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_139 *jrt.String = jrt.Intern("arbace.lang.LispReader$Resolver")

var Lit_140 *jrt.String = jrt.Intern("arbace.a2g.embed$eval1520000008$fn__1520000009")

var Lit_141 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms")

var Lit_142 *jrt.String = jrt.Intern("image_types.go")

var Lit_143 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$fn__1520000183")

var Lit_144 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$fn__1520000183$iter__1520000187__1520000191")

var Lit_145 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$fn__1520000183$iter__1520000187__1520000191$fn__1520000192")

var Lit_146 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$fn__1520000183$iter__1520000187__1520000191$fn__1520000192$fn__1520000193")

var Lit_147 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169")

var Lit_148 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170")

var Lit_149 *jrt.String = jrt.Intern("go/arbace")

var Lit_150 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170$iter__1520000165__1520000174")

var Lit_151 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170$iter__1520000165__1520000174$fn__1520000175")

var Lit_152 *jrt.String = jrt.Intern(".ae")

var Lit_153 *jrt.String = jrt.Intern("_test.ae")

var Lit_154 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000163__1520000169$fn__1520000170$iter__1520000165__1520000174$fn__1520000175$fn__1520000176")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000204__1520000208")

var Lit_156 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000204__1520000208$fn__1520000209")

var Lit_157 *jrt.String = jrt.Intern("arbace.a2g.embed$image_type_forms$iter__1520000204__1520000208$fn__1520000209$fn__1520000210")

var Lit_158 *jrt.String = jrt.Intern("arbace.a2g.embed$names")

var Lit_159 *jrt.String = jrt.Intern("arbace.a2g.embed$names$walk__1520000059")

var Lit_160 *jrt.String = jrt.Intern("arbace.a2g.embed$package_like_QMARK_")

var Lit_161 *jrt.String = jrt.Intern("arbace.a2g.embed$read_all")

var Lit_162 *jrt.String = jrt.Intern("arbace.a2g.embed$read_all$fn__1520000054")

var Lit_163 *jrt.String = jrt.Intern("arbace.a2g.embed$sources")

var Lit_164 *jrt.String = jrt.Intern("arbace")

var Lit_165 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$fn__1520000038")

var Lit_166 *jrt.String = jrt.Intern(".subst.ae")

var Lit_167 *jrt.String = jrt.Intern("arbace/")

var Lit_168 *jrt.String = jrt.Intern("a2g: namespace variant ")

var Lit_169 *jrt.String = jrt.Intern(": no ")

var Lit_170 *jrt.String = jrt.Intern(".after.ae")

var Lit_171 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$fn__1520000038$fn__1520000042")

var Lit_172 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$fn__1520000038$fn__1520000042$fn__1520000044")

var Lit_173 *jrt.String = jrt.Intern(": ")

var Lit_174 *jrt.String = jrt.Intern(" not found exactly once in ")

var Lit_175 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000013__1520000017")

var Lit_176 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018")

var Lit_177 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018$fn__1520000019")

var Lit_178 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018$fn__1520000019$fn__1520000020")

var Lit_179 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000013__1520000017$fn__1520000018$fn__1520000023")

var Lit_180 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000027__1520000031")

var Lit_181 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000027__1520000031$fn__1520000032")

var Lit_182 *jrt.String = jrt.Intern("arbace.a2g.embed$sources$iter__1520000027__1520000031$fn__1520000032$fn__1520000033")

var Lit_183 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types")

var Lit_184 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$elem__1520000117")

var Lit_185 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$iter__1520000133__1520000139")

var Lit_186 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140")

var Lit_187 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$fn__1520000147")

var Lit_188 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$iter__1520000135__1520000141")

var Lit_189 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$iter__1520000135__1520000141$fn__1520000142")

var Lit_190 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$iter__1520000133__1520000139$fn__1520000140$iter__1520000135__1520000141$fn__1520000142$fn__1520000143")

var Lit_191 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$member_types__1520000119")

var Lit_192 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$member_types__1520000119$fn__1520000120")

var Lit_193 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$member_types__1520000119$iter__1520000122__1520000126")

var Lit_194 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$member_types__1520000119$iter__1520000122__1520000126$fn__1520000127")

var Lit_195 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$member_types__1520000119$iter__1520000122__1520000126$fn__1520000127$fn__1520000128")

var Lit_196 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$types__1520000109")

var Lit_197 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$types__1520000109$fn__1520000110")

var Lit_198 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$types__1520000109$fn__1520000112")

var Lit_199 *jrt.String = jrt.Intern("arbace.a2g.embed$with_member_types$types__1520000109$fn__1520000114")

var Lit_200 *jrt.String = jrt.Intern("in-ns")

var Lit_201 *jrt.String = jrt.Intern("arbace/a2g/embed.ae")

var Lit_202 *jrt.String = jrt.Intern("Resource paths (prefixes) not embedded.")

var Lit_203 *jrt.String = jrt.Intern("sources")

var Lit_204 *jrt.String = jrt.Intern("arglists")

var Lit_205 *jrt.String = jrt.Intern("root")

var Lit_206 *jrt.String = jrt.Intern("The embedded sources: {resource-path text}, from the checkout at root.")

var Lit_207 *jrt.String = jrt.Intern("private")

var Lit_208 *jrt.String = jrt.Intern("Reads ::kw and `sym without the namespaces' aliases (only class names are wanted).")

var Lit_209 *jrt.String = jrt.Intern("text")

var Lit_210 *jrt.String = jrt.Intern("s")

var Lit_211 *jrt.String = jrt.Intern("tag")

var Lit_212 *jrt.String = jrt.Intern("String")

var Lit_213 *jrt.String = jrt.Intern("The class names (binary, dotted) the forms of text mention: qualified symbols, the\n  namespace of a qualified symbol, and import lists (pkg Name ...).")

var Lit_214 *jrt.String = jrt.Intern("java.util.jar.JarFile")

var Lit_215 *jrt.String = jrt.Intern("java.util.jar.JarEntry")

var Lit_216 *jrt.String = jrt.Intern("java.io.FileReader")

var Lit_217 *jrt.String = jrt.Intern("java.text.SimpleDateFormat")

var Lit_218 *jrt.String = jrt.Intern("Classes outside the world that libraries loaded from ARBACE_PATH import, cut as those the\n  embedded sources name are: Clojure's suite's test.generative runner requires\n  clojure.tools.namespace.find and clojure.java.classpath, which import java.util.jar's JarFile\n  and JarEntry and java.io.FileReader (the runner then lists no jars, and reads no files through\n  them); clojure.tools.reader names java.text.SimpleDateFormat (its #inst reader's formatter).\n  (java.net.URLClassLoader, which clojure.java.classpath extends, is in the world since\n  JRT-NOTES.md's \"Resources by URL\".)")

var Lit_219 *jrt.String = jrt.Intern("cut-candidates")

var Lit_220 *jrt.String = jrt.Intern("srcs")

var Lit_221 *jrt.String = jrt.Intern("The classes the sources name that exist on this JVM (the edge's :exists), from the JDK or arbace.lang\n  (not the classes the namespaces define themselves: deftype, defrecord, definterface), as\n  internal names; and library-cuts.")

var Lit_222 *jrt.String = jrt.Intern("with-member-types")

var Lit_223 *jrt.String = jrt.Intern("cands")

var Lit_224 *jrt.String = jrt.Intern("in-world?")

var Lit_225 *jrt.String = jrt.Intern("The cut candidates (internal names) and the JDK classes their public members name that are\n  outside the world (in-world?), one level deep: the cut classes' member tables then name them\n  (Files/createTempFile returns a Path).")

var Lit_226 *jrt.String = jrt.Intern("data")

var Lit_227 *jrt.String = jrt.Intern("dir")

var Lit_228 *jrt.String = jrt.Intern("The resource data the executable embeds besides the sources (JRT-NOTES.md, \"The JDK's\n  resource data\"): the files under dir (bin/jrt-convert's .tmp/jrt/data: uniName.dat, ICU's\n  normalization data), {resource-path File}, sorted; empty when dir does not exist.")

var Lit_229 *jrt.String = jrt.Intern("image-forms")

var Lit_230 *jrt.String = jrt.Intern("The image's encoding: Go forms of the main package, copied into the program.")

var Lit_231 *jrt.String = jrt.Intern("rlwrap-forms")

var Lit_232 *jrt.String = jrt.Intern("go/arbace/cmd/arbace/rlwrap_linux.ae")

var Lit_233 *jrt.String = jrt.Intern("go/arbace/cmd/arbace/rlwrap_other.ae")

var Lit_234 *jrt.String = jrt.Intern("The interactive REPL under rlwrap (EXEC-NOTES.md, \"Line editing: rlwrap\"): Go forms of the\n  main package, copied into the program, Linux's and the other systems' (an empty execRlwrap).")

var Lit_235 *jrt.String = jrt.Intern("image-type-forms")

var Lit_236 *jrt.String = jrt.Intern("prog-dir")

var Lit_237 *jrt.String = jrt.Intern("The main package's table of the program's struct types (image_types.go): every exported,\n  non-generic struct type of arbace/lang and arbace/jrt, as declared by the forms under\n  prog-dir, registered by name for the image's decoder.")

var Lit_238 *jrt.String = jrt.Intern("arbace/lang/go/ns")

var Lit_239 *jrt.String = jrt.Intern("go/arbace/cmd/arbace/image.ae")
