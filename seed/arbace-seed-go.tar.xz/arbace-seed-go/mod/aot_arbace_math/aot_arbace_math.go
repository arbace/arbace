//line aot_arbace_math.ae:1
package aot_arbace_math

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New() *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A { A_arbace_math_A_Init(); t := &A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_math_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_math_eval446000008_fn__446000009_A_New() *A_arbace_math_eval446000008_fn__446000009_A { A_arbace_math_A_Init(); t := &A_arbace_math_eval446000008_fn__446000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_math_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_math_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_math_A_const_5.GetRawRoot__O(), A_arbace_math_A_const_6) }
































func A_arbace_math_sin_A_New() *A_arbace_math_sin_A { A_arbace_math_A_Init(); t := &A_arbace_math_sin_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {








	return jrt.Math_Sin_D__D(a__0) }
//line :42:1
func (t *A_arbace_math_sin_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :42:1
func A_arbace_math_sin__inliner__446000014_A_New() *A_arbace_math_sin__inliner__446000014_A { A_arbace_math_A_Init(); t := &A_arbace_math_sin__inliner__446000014_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Invoke_O_O__O(self, a__0 any) any { var root_15 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var root_19 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_10); var arg_23 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_24 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_28 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_11); var arg_32 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_29 == nil { arg_27 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { arg_27 = linked_29.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_24, arg_27) }; arg_23 = tmp1.Invoke_O__O(tmp2); if linked_20 == nil { arg_18 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { arg_18 = linked_20.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_15, arg_18) } }










func A_arbace_math_cos_A_New() *A_arbace_math_cos_A { A_arbace_math_A_Init(); t := &A_arbace_math_cos_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {







	return jrt.Math_Cos_D__D(a__0) }
//line :53:1
func (t *A_arbace_math_cos_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :53:1
func A_arbace_math_cos__inliner__446000017_A_New() *A_arbace_math_cos__inliner__446000017_A { A_arbace_math_A_Init(); t := &A_arbace_math_cos__inliner__446000017_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Invoke_O_O__O(self, a__0 any) any { var root_33 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any; var root_37 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_12); var arg_41 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_42 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any; var root_46 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_13); var arg_50 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_47 == nil { arg_45 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { arg_45 = linked_47.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; if linked_43 == nil { tmp2 = ifn_44.Invoke_O__O(arg_45) } else { tmp2 = linked_43.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_42, arg_45) }; arg_41 = tmp1.Invoke_O__O(tmp2); if linked_38 == nil { arg_36 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { arg_36 = linked_38.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) }; if linked_34 == nil { return ifn_35.Invoke_O__O(arg_36) } else { return linked_34.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_33, arg_36) } }









func A_arbace_math_tan_A_New() *A_arbace_math_tan_A { A_arbace_math_A_Init(); t := &A_arbace_math_tan_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {








	return jrt.Math_Tan_D__D(a__0) }
//line :63:1
func (t *A_arbace_math_tan_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :63:1
func A_arbace_math_tan__inliner__446000020_A_New() *A_arbace_math_tan__inliner__446000020_A { A_arbace_math_A_Init(); t := &A_arbace_math_tan__inliner__446000020_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Invoke_O_O__O(self, a__0 any) any { var root_51 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var root_55 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_14); var arg_59 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_60 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_64 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_15); var arg_68 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_65 == nil { arg_63 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { arg_63 = linked_65.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if linked_61 == nil { tmp2 = ifn_62.Invoke_O__O(arg_63) } else { tmp2 = linked_61.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_60, arg_63) }; arg_59 = tmp1.Invoke_O__O(tmp2); if linked_56 == nil { arg_54 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { arg_54 = linked_56.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }; if linked_52 == nil { return ifn_53.Invoke_O__O(arg_54) } else { return linked_52.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_51, arg_54) } }










func A_arbace_math_asin_A_New() *A_arbace_math_asin_A { A_arbace_math_A_Init(); t := &A_arbace_math_asin_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {








	return jrt.Math_Asin_D__D(a__0) }
//line :74:1
func (t *A_arbace_math_asin_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :74:1
func A_arbace_math_asin__inliner__446000023_A_New() *A_arbace_math_asin__inliner__446000023_A { A_arbace_math_A_Init(); t := &A_arbace_math_asin__inliner__446000023_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Invoke_O_O__O(self, a__0 any) any { var root_69 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_16); var arg_77 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_78 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var root_82 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_17); var arg_86 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_83 == nil { arg_81 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { arg_81 = linked_83.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; if linked_79 == nil { tmp2 = ifn_80.Invoke_O__O(arg_81) } else { tmp2 = linked_79.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_78, arg_81) }; arg_77 = tmp1.Invoke_O__O(tmp2); if linked_74 == nil { arg_72 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { arg_72 = linked_74.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_69, arg_72) } }










func A_arbace_math_acos_A_New() *A_arbace_math_acos_A { A_arbace_math_A_Init(); t := &A_arbace_math_acos_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {







	return jrt.Math_Acos_D__D(a__0) }
//line :85:1
func (t *A_arbace_math_acos_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :85:1
func A_arbace_math_acos__inliner__446000026_A_New() *A_arbace_math_acos__inliner__446000026_A { A_arbace_math_A_Init(); t := &A_arbace_math_acos__inliner__446000026_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Invoke_O_O__O(self, a__0 any) any { var root_87 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var root_91 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_18); var arg_95 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_96 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var root_100 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_19); var arg_104 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_101 == nil { arg_99 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { arg_99 = linked_101.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; if linked_97 == nil { tmp2 = ifn_98.Invoke_O__O(arg_99) } else { tmp2 = linked_97.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_96, arg_99) }; arg_95 = tmp1.Invoke_O__O(tmp2); if linked_92 == nil { arg_90 = ifn_93.Invoke_O_O__O(arg_94, arg_95) } else { arg_90 = linked_92.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_91, arg_94, arg_95) }; if linked_88 == nil { return ifn_89.Invoke_O__O(arg_90) } else { return linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90) } }









func A_arbace_math_atan_A_New() *A_arbace_math_atan_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {








	return jrt.Math_Atan_D__D(a__0) }
//line :95:1
func (t *A_arbace_math_atan_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :95:1
func A_arbace_math_atan__inliner__446000029_A_New() *A_arbace_math_atan__inliner__446000029_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan__inliner__446000029_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Invoke_O_O__O(self, a__0 any) any { var root_105 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_20); var arg_113 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_114 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any; var root_118 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_21); var arg_122 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_119 == nil { arg_117 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { arg_117 = linked_119.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_118, arg_121, arg_122) }; if linked_115 == nil { tmp2 = ifn_116.Invoke_O__O(arg_117) } else { tmp2 = linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) }; arg_113 = tmp1.Invoke_O__O(tmp2); if linked_110 == nil { arg_108 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; if linked_106 == nil { return ifn_107.Invoke_O__O(arg_108) } else { return linked_106.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_105, arg_108) } }










func A_arbace_math_to_radians_A_New() *A_arbace_math_to_radians_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_radians_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians_A) InvokePrim_O_D__D(self any, deg__0 float64) float64 {






	return jrt.Math_ToRadians_D__D(deg__0) }
//line :106:1
func (t *A_arbace_math_to_radians_A) Invoke_O_O__O(self, p_deg__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_deg__0))).Ref() }
//line :106:1
func A_arbace_math_to_radians__inliner__446000032_A_New() *A_arbace_math_to_radians__inliner__446000032_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_radians__inliner__446000032_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Invoke_O_O__O(self, deg__0 any) any { var root_123 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_127 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_22); var arg_131 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_132 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var root_136 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_23); var arg_140 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(deg__0); if linked_137 == nil { arg_135 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { arg_135 = linked_137.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_132, arg_135) }; arg_131 = tmp1.Invoke_O__O(tmp2); if linked_128 == nil { arg_126 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { arg_126 = linked_128.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if linked_124 == nil { return ifn_125.Invoke_O__O(arg_126) } else { return linked_124.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_123, arg_126) } }








func A_arbace_math_to_degrees_A_New() *A_arbace_math_to_degrees_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_degrees_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees_A) InvokePrim_O_D__D(self any, r__0 float64) float64 {






	return jrt.Math_ToDegrees_D__D(r__0) }
//line :115:1
func (t *A_arbace_math_to_degrees_A) Invoke_O_O__O(self, p_r__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_r__0))).Ref() }
//line :115:1
func A_arbace_math_to_degrees__inliner__446000035_A_New() *A_arbace_math_to_degrees__inliner__446000035_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_degrees__inliner__446000035_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Invoke_O_O__O(self, r__0 any) any { var root_141 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var root_145 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_24); var arg_149 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_150 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_154 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_25); var arg_158 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(r__0); if linked_155 == nil { arg_153 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { arg_153 = linked_155.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }; if linked_151 == nil { tmp2 = ifn_152.Invoke_O__O(arg_153) } else { tmp2 = linked_151.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_150, arg_153) }; arg_149 = tmp1.Invoke_O__O(tmp2); if linked_146 == nil { arg_144 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { arg_144 = linked_146.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }; if linked_142 == nil { return ifn_143.Invoke_O__O(arg_144) } else { return linked_142.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_141, arg_144) } }








func A_arbace_math_exp_A_New() *A_arbace_math_exp_A { A_arbace_math_A_Init(); t := &A_arbace_math_exp_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {









	return jrt.Math_Exp_D__D(a__0) }
//line :124:1
func (t *A_arbace_math_exp_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :124:1
func A_arbace_math_exp__inliner__446000038_A_New() *A_arbace_math_exp__inliner__446000038_A { A_arbace_math_A_Init(); t := &A_arbace_math_exp__inliner__446000038_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Invoke_O_O__O(self, a__0 any) any { var root_159 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_163 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_26); var arg_167 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_168 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any; var root_172 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_27); var arg_176 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_173 == nil { arg_171 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { arg_171 = linked_173.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; if linked_169 == nil { tmp2 = ifn_170.Invoke_O__O(arg_171) } else { tmp2 = linked_169.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_168, arg_171) }; arg_167 = tmp1.Invoke_O__O(tmp2); if linked_164 == nil { arg_162 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { arg_162 = linked_164.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; if linked_160 == nil { return ifn_161.Invoke_O__O(arg_162) } else { return linked_160.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_159, arg_162) } }











func A_arbace_math_log_A_New() *A_arbace_math_log_A { A_arbace_math_A_Init(); t := &A_arbace_math_log_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {









	return jrt.Math_Log_D__D(a__0) }
//line :136:1
func (t *A_arbace_math_log_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :136:1
func A_arbace_math_log__inliner__446000041_A_New() *A_arbace_math_log__inliner__446000041_A { A_arbace_math_A_Init(); t := &A_arbace_math_log__inliner__446000041_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Invoke_O_O__O(self, a__0 any) any { var root_177 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var root_181 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_28); var arg_185 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_186 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var root_190 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_29); var arg_194 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_191 == nil { arg_189 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { arg_189 = linked_191.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; if linked_187 == nil { tmp2 = ifn_188.Invoke_O__O(arg_189) } else { tmp2 = linked_187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_186, arg_189) }; arg_185 = tmp1.Invoke_O__O(tmp2); if linked_182 == nil { arg_180 = ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { arg_180 = linked_182.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) }; if linked_178 == nil { return ifn_179.Invoke_O__O(arg_180) } else { return linked_178.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_177, arg_180) } }











func A_arbace_math_log10_A_New() *A_arbace_math_log10_A { A_arbace_math_A_Init(); t := &A_arbace_math_log10_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {









	return jrt.Math_Log10_D__D(a__0) }
//line :148:1
func (t *A_arbace_math_log10_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :148:1
func A_arbace_math_log10__inliner__446000044_A_New() *A_arbace_math_log10__inliner__446000044_A { A_arbace_math_A_Init(); t := &A_arbace_math_log10__inliner__446000044_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Invoke_O_O__O(self, a__0 any) any { var root_195 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_199 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_30); var arg_203 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_204 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var root_208 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_31); var arg_212 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_209 == nil { arg_207 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { arg_207 = linked_209.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) }; if linked_205 == nil { tmp2 = ifn_206.Invoke_O__O(arg_207) } else { tmp2 = linked_205.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_204, arg_207) }; arg_203 = tmp1.Invoke_O__O(tmp2); if linked_200 == nil { arg_198 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { arg_198 = linked_200.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; if linked_196 == nil { return ifn_197.Invoke_O__O(arg_198) } else { return linked_196.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_195, arg_198) } }











func A_arbace_math_sqrt_A_New() *A_arbace_math_sqrt_A { A_arbace_math_A_Init(); t := &A_arbace_math_sqrt_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {









	return jrt.Math_Sqrt_D__D(a__0) }
//line :160:1
func (t *A_arbace_math_sqrt_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :160:1
func A_arbace_math_sqrt__inliner__446000047_A_New() *A_arbace_math_sqrt__inliner__446000047_A { A_arbace_math_A_Init(); t := &A_arbace_math_sqrt__inliner__446000047_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Invoke_O_O__O(self, a__0 any) any { var root_213 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any; var root_217 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_32); var arg_221 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_222 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any; var root_226 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_33); var arg_230 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_227 == nil { arg_225 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { arg_225 = linked_227.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_226, arg_229, arg_230) }; if linked_223 == nil { tmp2 = ifn_224.Invoke_O__O(arg_225) } else { tmp2 = linked_223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_222, arg_225) }; arg_221 = tmp1.Invoke_O__O(tmp2); if linked_218 == nil { arg_216 = ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { arg_216 = linked_218.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) }; if linked_214 == nil { return ifn_215.Invoke_O__O(arg_216) } else { return linked_214.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_213, arg_216) } }











func A_arbace_math_cbrt_A_New() *A_arbace_math_cbrt_A { A_arbace_math_A_Init(); t := &A_arbace_math_cbrt_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {









	return jrt.Math_Cbrt_D__D(a__0) }
//line :172:1
func (t *A_arbace_math_cbrt_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :172:1
func A_arbace_math_cbrt__inliner__446000050_A_New() *A_arbace_math_cbrt__inliner__446000050_A { A_arbace_math_A_Init(); t := &A_arbace_math_cbrt__inliner__446000050_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Invoke_O_O__O(self, a__0 any) any { var root_231 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var root_235 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_34); var arg_239 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_240 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var root_244 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_35); var arg_248 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_245 == nil { arg_243 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { arg_243 = linked_245.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; if linked_241 == nil { tmp2 = ifn_242.Invoke_O__O(arg_243) } else { tmp2 = linked_241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_240, arg_243) }; arg_239 = tmp1.Invoke_O__O(tmp2); if linked_236 == nil { arg_234 = ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { arg_234 = linked_236.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_235, arg_238, arg_239) }; if linked_232 == nil { return ifn_233.Invoke_O__O(arg_234) } else { return linked_232.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_231, arg_234) } }











func A_arbace_math_IEEE_remainder_A_New() *A_arbace_math_IEEE_remainder_A { A_arbace_math_A_Init(); t := &A_arbace_math_IEEE_remainder_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) InvokePrim_O_D_D__D(self any, dividend__0, divisor__1 float64) float64 {












	return jrt.Math_IEEEremainder_D_D__D(dividend__0, divisor__1) }
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Invoke_O_O_O__O(self, p_dividend__0, p_divisor__1 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_dividend__0), lang.RT_DoubleCast_O__D_NoInit(p_divisor__1))).Ref() }
//line :184:1
func A_arbace_math_IEEE_remainder__inliner__446000053_A_New() *A_arbace_math_IEEE_remainder__inliner__446000053_A { A_arbace_math_A_Init(); t := &A_arbace_math_IEEE_remainder__inliner__446000053_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Invoke_O_O_O__O(self, dividend__0, divisor__1 any) any { var root_249 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_36); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_259 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any; var root_263 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_37); var arg_267 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(dividend__0); if linked_264 == nil { arg_262 = ifn_265.Invoke_O_O__O(arg_266, arg_267) } else { arg_262 = linked_264.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_263, arg_266, arg_267) }; if linked_260 == nil { tmp4 = ifn_261.Invoke_O__O(arg_262) } else { tmp4 = linked_260.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_259, arg_262) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_268 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any; var root_272 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_38); var arg_276 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(divisor__1); if linked_273 == nil { arg_271 = ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { arg_271 = linked_273.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_272, arg_275, arg_276) }; if linked_269 == nil { tmp7 = ifn_270.Invoke_O__O(arg_271) } else { tmp7 = linked_269.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_268, arg_271) }; arg_252 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_250 == nil { return ifn_251.Invoke_O__O(arg_252) } else { return linked_250.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_249, arg_252) } }














func A_arbace_math_ceil_A_New() *A_arbace_math_ceil_A { A_arbace_math_A_Init(); t := &A_arbace_math_ceil_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {









	return jrt.Math_Ceil_D__D(a__0) }
//line :199:1
func (t *A_arbace_math_ceil_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :199:1
func A_arbace_math_ceil__inliner__446000056_A_New() *A_arbace_math_ceil__inliner__446000056_A { A_arbace_math_A_Init(); t := &A_arbace_math_ceil__inliner__446000056_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Invoke_O_O__O(self, a__0 any) any { var root_277 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any; var root_281 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_39); var arg_285 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_286 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any; var root_290 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_40); var arg_294 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_291 == nil { arg_289 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { arg_289 = linked_291.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }; if linked_287 == nil { tmp2 = ifn_288.Invoke_O__O(arg_289) } else { tmp2 = linked_287.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_286, arg_289) }; arg_285 = tmp1.Invoke_O__O(tmp2); if linked_282 == nil { arg_280 = ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { arg_280 = linked_282.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) }; if linked_278 == nil { return ifn_279.Invoke_O__O(arg_280) } else { return linked_278.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_277, arg_280) } }











func A_arbace_math_floor_A_New() *A_arbace_math_floor_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {








	return jrt.Math_Floor_D__D(a__0) }
//line :211:1
func (t *A_arbace_math_floor_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :211:1
func A_arbace_math_floor__inliner__446000059_A_New() *A_arbace_math_floor__inliner__446000059_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor__inliner__446000059_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Invoke_O_O__O(self, a__0 any) any { var root_295 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any; var root_299 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_41); var arg_303 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_304 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any; var root_308 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_42); var arg_312 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_309 == nil { arg_307 = ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { arg_307 = linked_309.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) }; if linked_305 == nil { tmp2 = ifn_306.Invoke_O__O(arg_307) } else { tmp2 = linked_305.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_304, arg_307) }; arg_303 = tmp1.Invoke_O__O(tmp2); if linked_300 == nil { arg_298 = ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { arg_298 = linked_300.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_299, arg_302, arg_303) }; if linked_296 == nil { return ifn_297.Invoke_O__O(arg_298) } else { return linked_296.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_295, arg_298) } }










func A_arbace_math_rint_A_New() *A_arbace_math_rint_A { A_arbace_math_A_Init(); t := &A_arbace_math_rint_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint_A) InvokePrim_O_D__D(self any, a__0 float64) float64 {








	return jrt.Math_Rint_D__D(a__0) }
//line :222:1
func (t *A_arbace_math_rint_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :222:1
func A_arbace_math_rint__inliner__446000062_A_New() *A_arbace_math_rint__inliner__446000062_A { A_arbace_math_A_Init(); t := &A_arbace_math_rint__inliner__446000062_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Invoke_O_O__O(self, a__0 any) any { var root_313 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any; var root_317 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_43); var arg_321 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_322 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any; var root_326 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_44); var arg_330 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_327 == nil { arg_325 = ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { arg_325 = linked_327.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) }; if linked_323 == nil { tmp2 = ifn_324.Invoke_O__O(arg_325) } else { tmp2 = linked_323.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_322, arg_325) }; arg_321 = tmp1.Invoke_O__O(tmp2); if linked_318 == nil { arg_316 = ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { arg_316 = linked_318.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_317, arg_320, arg_321) }; if linked_314 == nil { return ifn_315.Invoke_O__O(arg_316) } else { return linked_314.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_313, arg_316) } }










func A_arbace_math_atan2_A_New() *A_arbace_math_atan2_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan2_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2_A) InvokePrim_O_D_D__D(self any, y__0, x__1 float64) float64 {








	return jrt.Math_Atan2_D_D__D(y__0, x__1) }
//line :233:1
func (t *A_arbace_math_atan2_A) Invoke_O_O_O__O(self, p_y__0, p_x__1 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_y__0), lang.RT_DoubleCast_O__D_NoInit(p_x__1))).Ref() }
//line :233:1
func A_arbace_math_atan2__inliner__446000065_A_New() *A_arbace_math_atan2__inliner__446000065_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan2__inliner__446000065_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Invoke_O_O_O__O(self, y__0, x__1 any) any { var root_331 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_45); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_341 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any; var root_345 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_46); var arg_349 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__0); if linked_346 == nil { arg_344 = ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { arg_344 = linked_346.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) }; if linked_342 == nil { tmp4 = ifn_343.Invoke_O__O(arg_344) } else { tmp4 = linked_342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_341, arg_344) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_350 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var root_354 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_47); var arg_358 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__1); if linked_355 == nil { arg_353 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { arg_353 = linked_355.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }; if linked_351 == nil { tmp7 = ifn_352.Invoke_O__O(arg_353) } else { tmp7 = linked_351.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_350, arg_353) }; arg_334 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_332 == nil { return ifn_333.Invoke_O__O(arg_334) } else { return linked_332.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_331, arg_334) } }










func A_arbace_math_pow_A_New() *A_arbace_math_pow_A { A_arbace_math_A_Init(); t := &A_arbace_math_pow_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow_A) InvokePrim_O_D_D__D(self any, a__0, b__1 float64) float64 {







	return jrt.Math_Pow_D_D__D(a__0, b__1) }
//line :244:1
func (t *A_arbace_math_pow_A) Invoke_O_O_O__O(self, p_a__0, p_b__1 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0), lang.RT_DoubleCast_O__D_NoInit(p_b__1))).Ref() }
//line :244:1
func A_arbace_math_pow__inliner__446000068_A_New() *A_arbace_math_pow__inliner__446000068_A { A_arbace_math_A_Init(); t := &A_arbace_math_pow__inliner__446000068_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var root_359 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_48); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_369 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any; var root_373 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_49); var arg_377 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_374 == nil { arg_372 = ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { arg_372 = linked_374.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) }; if linked_370 == nil { tmp4 = ifn_371.Invoke_O__O(arg_372) } else { tmp4 = linked_370.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_369, arg_372) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_378 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any; var root_382 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_50); var arg_386 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(b__1); if linked_383 == nil { arg_381 = ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { arg_381 = linked_383.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_382, arg_385, arg_386) }; if linked_379 == nil { tmp7 = ifn_380.Invoke_O__O(arg_381) } else { tmp7 = linked_379.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_378, arg_381) }; arg_362 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_360 == nil { return ifn_361.Invoke_O__O(arg_362) } else { return linked_360.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_359, arg_362) } }









func A_arbace_math_round_A_New() *A_arbace_math_round_A { A_arbace_math_A_Init(); t := &A_arbace_math_round_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round_A) InvokePrim_O_D__J(self any, a__0 float64) int64 {










	return jrt.Math_Round_D__J(a__0) }
//line :254:1
func (t *A_arbace_math_round_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_D__J(self, lang.RT_DoubleCast_O__D_NoInit(p_a__0))).Ref() }
//line :254:1
func A_arbace_math_round__inliner__446000071_A_New() *A_arbace_math_round__inliner__446000071_A { A_arbace_math_A_Init(); t := &A_arbace_math_round__inliner__446000071_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Invoke_O_O__O(self, a__0 any) any { var root_387 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var root_391 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_51); var arg_395 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_396 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any; var root_400 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_52); var arg_404 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_401 == nil { arg_399 = ifn_402.Invoke_O_O__O(arg_403, arg_404) } else { arg_399 = linked_401.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_400, arg_403, arg_404) }; if linked_397 == nil { tmp2 = ifn_398.Invoke_O__O(arg_399) } else { tmp2 = linked_397.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_396, arg_399) }; arg_395 = tmp1.Invoke_O__O(tmp2); if linked_392 == nil { arg_390 = ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { arg_390 = linked_392.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) }; if linked_388 == nil { return ifn_389.Invoke_O__O(arg_390) } else { return linked_388.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_387, arg_390) } }












func A_arbace_math_random_A_New() *A_arbace_math_random_A { A_arbace_math_A_Init(); t := &A_arbace_math_random_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random_A) InvokePrim_O__D(self any) float64 {







	return jrt.Math_Random__D() }
//line :267:1
func (t *A_arbace_math_random_A) Invoke_O__O(self any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O__D(self)).Ref() }
//line :267:1
func A_arbace_math_random__inliner__446000074_A_New() *A_arbace_math_random__inliner__446000074_A { A_arbace_math_A_Init(); t := &A_arbace_math_random__inliner__446000074_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Invoke_O__O(self any) any { var root_405 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any; var root_409 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_53); if linked_410 == nil { arg_408 = ifn_411.Invoke_O__O(arg_412) } else { arg_408 = linked_410.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_409, arg_412) }; if linked_406 == nil { return ifn_407.Invoke_O__O(arg_408) } else { return linked_406.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_405, arg_408) } }









func A_arbace_math_add_exact_A_New() *A_arbace_math_add_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_add_exact_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact_A) InvokePrim_O_J_J__J(self any, x__0, y__1 int64) int64 {






	return jrt.Math_AddExact_J_J__J(x__0, y__1) }
//line :277:1
func (t *A_arbace_math_add_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_y__1))).Ref() }
//line :277:1
func A_arbace_math_add_exact__inliner__446000077_A_New() *A_arbace_math_add_exact__inliner__446000077_A { A_arbace_math_A_Init(); t := &A_arbace_math_add_exact__inliner__446000077_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_413 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_54); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_423 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any; var root_427 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_55); var arg_431 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_428 == nil { arg_426 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { arg_426 = linked_428.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }; if linked_424 == nil { tmp4 = ifn_425.Invoke_O__O(arg_426) } else { tmp4 = linked_424.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_423, arg_426) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_432 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any; var root_436 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_56); var arg_440 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_437 == nil { arg_435 = ifn_438.Invoke_O_O__O(arg_439, arg_440) } else { arg_435 = linked_437.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_436, arg_439, arg_440) }; if linked_433 == nil { tmp7 = ifn_434.Invoke_O__O(arg_435) } else { tmp7 = linked_433.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_432, arg_435) }; arg_416 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_414 == nil { return ifn_415.Invoke_O__O(arg_416) } else { return linked_414.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_413, arg_416) } }








func A_arbace_math_subtract_exact_A_New() *A_arbace_math_subtract_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_subtract_exact_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact_A) InvokePrim_O_J_J__J(self any, x__0, y__1 int64) int64 {






	return jrt.Math_SubtractExact_J_J__J(x__0, y__1) }
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_y__1))).Ref() }
//line :286:1
func A_arbace_math_subtract_exact__inliner__446000080_A_New() *A_arbace_math_subtract_exact__inliner__446000080_A { A_arbace_math_A_Init(); t := &A_arbace_math_subtract_exact__inliner__446000080_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_441 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_57); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_451 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any; var root_455 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_58); var arg_459 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_456 == nil { arg_454 = ifn_457.Invoke_O_O__O(arg_458, arg_459) } else { arg_454 = linked_456.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_455, arg_458, arg_459) }; if linked_452 == nil { tmp4 = ifn_453.Invoke_O__O(arg_454) } else { tmp4 = linked_452.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_451, arg_454) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_460 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any; var root_464 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_59); var arg_468 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_465 == nil { arg_463 = ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { arg_463 = linked_465.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_464, arg_467, arg_468) }; if linked_461 == nil { tmp7 = ifn_462.Invoke_O__O(arg_463) } else { tmp7 = linked_461.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_460, arg_463) }; arg_444 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_442 == nil { return ifn_443.Invoke_O__O(arg_444) } else { return linked_442.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_441, arg_444) } }








func A_arbace_math_multiply_exact_A_New() *A_arbace_math_multiply_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_multiply_exact_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact_A) InvokePrim_O_J_J__J(self any, x__0, y__1 int64) int64 {






	return jrt.Math_MultiplyExact_J_J__J(x__0, y__1) }
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_y__1))).Ref() }
//line :295:1
func A_arbace_math_multiply_exact__inliner__446000083_A_New() *A_arbace_math_multiply_exact__inliner__446000083_A { A_arbace_math_A_Init(); t := &A_arbace_math_multiply_exact__inliner__446000083_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_469 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_60); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_479 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any; var root_483 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_61); var arg_487 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_484 == nil { arg_482 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { arg_482 = linked_484.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_483, arg_486, arg_487) }; if linked_480 == nil { tmp4 = ifn_481.Invoke_O__O(arg_482) } else { tmp4 = linked_480.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_479, arg_482) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_488 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any; var root_492 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_62); var arg_496 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_493 == nil { arg_491 = ifn_494.Invoke_O_O__O(arg_495, arg_496) } else { arg_491 = linked_493.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_492, arg_495, arg_496) }; if linked_489 == nil { tmp7 = ifn_490.Invoke_O__O(arg_491) } else { tmp7 = linked_489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_488, arg_491) }; arg_472 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_470 == nil { return ifn_471.Invoke_O__O(arg_472) } else { return linked_470.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_469, arg_472) } }








func A_arbace_math_increment_exact_A_New() *A_arbace_math_increment_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_increment_exact_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact_A) InvokePrim_O_J__J(self any, a__0 int64) int64 {






	return jrt.Math_IncrementExact_J__J(a__0) }
//line :304:1
func (t *A_arbace_math_increment_exact_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J__J(self, lang.RT_LongCast_O__J_NoInit(p_a__0))).Ref() }
//line :304:1
func A_arbace_math_increment_exact__inliner__446000086_A_New() *A_arbace_math_increment_exact__inliner__446000086_A { A_arbace_math_A_Init(); t := &A_arbace_math_increment_exact__inliner__446000086_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Invoke_O_O__O(self, a__0 any) any { var root_497 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any; var root_501 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_63); var arg_505 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_506 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any; var root_510 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_64); var arg_514 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_511 == nil { arg_509 = ifn_512.Invoke_O_O__O(arg_513, arg_514) } else { arg_509 = linked_511.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_510, arg_513, arg_514) }; if linked_507 == nil { tmp2 = ifn_508.Invoke_O__O(arg_509) } else { tmp2 = linked_507.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_506, arg_509) }; arg_505 = tmp1.Invoke_O__O(tmp2); if linked_502 == nil { arg_500 = ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { arg_500 = linked_502.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) }; if linked_498 == nil { return ifn_499.Invoke_O__O(arg_500) } else { return linked_498.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_497, arg_500) } }








func A_arbace_math_decrement_exact_A_New() *A_arbace_math_decrement_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_decrement_exact_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact_A) InvokePrim_O_J__J(self any, a__0 int64) int64 {






	return jrt.Math_DecrementExact_J__J(a__0) }
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J__J(self, lang.RT_LongCast_O__J_NoInit(p_a__0))).Ref() }
//line :313:1
func A_arbace_math_decrement_exact__inliner__446000089_A_New() *A_arbace_math_decrement_exact__inliner__446000089_A { A_arbace_math_A_Init(); t := &A_arbace_math_decrement_exact__inliner__446000089_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Invoke_O_O__O(self, a__0 any) any { var root_515 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any; var root_519 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_65); var arg_523 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_524 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var root_528 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_66); var arg_532 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_529 == nil { arg_527 = ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { arg_527 = linked_529.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_528, arg_531, arg_532) }; if linked_525 == nil { tmp2 = ifn_526.Invoke_O__O(arg_527) } else { tmp2 = linked_525.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_524, arg_527) }; arg_523 = tmp1.Invoke_O__O(tmp2); if linked_520 == nil { arg_518 = ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { arg_518 = linked_520.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_519, arg_522, arg_523) }; if linked_516 == nil { return ifn_517.Invoke_O__O(arg_518) } else { return linked_516.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_515, arg_518) } }








func A_arbace_math_negate_exact_A_New() *A_arbace_math_negate_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_negate_exact_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact_A) InvokePrim_O_J__J(self any, a__0 int64) int64 {






	return jrt.Math_NegateExact_J__J(a__0) }
//line :322:1
func (t *A_arbace_math_negate_exact_A) Invoke_O_O__O(self, p_a__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J__J(self, lang.RT_LongCast_O__J_NoInit(p_a__0))).Ref() }
//line :322:1
func A_arbace_math_negate_exact__inliner__446000092_A_New() *A_arbace_math_negate_exact__inliner__446000092_A { A_arbace_math_A_Init(); t := &A_arbace_math_negate_exact__inliner__446000092_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Invoke_O_O__O(self, a__0 any) any { var root_533 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any; var root_537 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_67); var arg_541 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_542 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any; var root_546 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_68); var arg_550 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_547 == nil { arg_545 = ifn_548.Invoke_O_O__O(arg_549, arg_550) } else { arg_545 = linked_547.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_546, arg_549, arg_550) }; if linked_543 == nil { tmp2 = ifn_544.Invoke_O__O(arg_545) } else { tmp2 = linked_543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_542, arg_545) }; arg_541 = tmp1.Invoke_O__O(tmp2); if linked_538 == nil { arg_536 = ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { arg_536 = linked_538.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) }; if linked_534 == nil { return ifn_535.Invoke_O__O(arg_536) } else { return linked_534.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_533, arg_536) } }








func A_arbace_math_floor_div_A_New() *A_arbace_math_floor_div_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_div_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div_A) InvokePrim_O_J_J__J(self any, x__0, y__1 int64) int64 {







	return jrt.Math_FloorDiv_J_J__J(x__0, y__1) }
//line :331:1
func (t *A_arbace_math_floor_div_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_y__1))).Ref() }
//line :331:1
func A_arbace_math_floor_div__inliner__446000095_A_New() *A_arbace_math_floor_div__inliner__446000095_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_div__inliner__446000095_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_551 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_69); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_561 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any; var root_565 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_70); var arg_569 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_566 == nil { arg_564 = ifn_567.Invoke_O_O__O(arg_568, arg_569) } else { arg_564 = linked_566.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_565, arg_568, arg_569) }; if linked_562 == nil { tmp4 = ifn_563.Invoke_O__O(arg_564) } else { tmp4 = linked_562.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_561, arg_564) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_570 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any; var root_574 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_71); var arg_578 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_575 == nil { arg_573 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { arg_573 = linked_575.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }; if linked_571 == nil { tmp7 = ifn_572.Invoke_O__O(arg_573) } else { tmp7 = linked_571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_570, arg_573) }; arg_554 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_552 == nil { return ifn_553.Invoke_O__O(arg_554) } else { return linked_552.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_551, arg_554) } }









func A_arbace_math_floor_mod_A_New() *A_arbace_math_floor_mod_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_mod_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod_A) InvokePrim_O_J_J__J(self any, x__0, y__1 int64) int64 {







	return jrt.Math_FloorMod_J_J__J(x__0, y__1) }
//line :341:1
func (t *A_arbace_math_floor_mod_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_x__0), lang.RT_LongCast_O__J_NoInit(p_y__1))).Ref() }
//line :341:1
func A_arbace_math_floor_mod__inliner__446000098_A_New() *A_arbace_math_floor_mod__inliner__446000098_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_mod__inliner__446000098_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_579 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_72); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_589 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any; var root_593 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_73); var arg_597 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_594 == nil { arg_592 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { arg_592 = linked_594.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; if linked_590 == nil { tmp4 = ifn_591.Invoke_O__O(arg_592) } else { tmp4 = linked_590.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_589, arg_592) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_598 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any; var root_602 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_74); var arg_606 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_603 == nil { arg_601 = ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { arg_601 = linked_603.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) }; if linked_599 == nil { tmp7 = ifn_600.Invoke_O__O(arg_601) } else { tmp7 = linked_599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_598, arg_601) }; arg_582 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_580 == nil { return ifn_581.Invoke_O__O(arg_582) } else { return linked_580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_579, arg_582) } }









func A_arbace_math_ulp_A_New() *A_arbace_math_ulp_A { A_arbace_math_A_Init(); t := &A_arbace_math_ulp_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp_A) InvokePrim_O_D__D(self any, d__0 float64) float64 {










	return jrt.Math_Ulp_D__D(d__0) }
//line :351:1
func (t *A_arbace_math_ulp_A) Invoke_O_O__O(self, p_d__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0))).Ref() }
//line :351:1
func A_arbace_math_ulp__inliner__446000101_A_New() *A_arbace_math_ulp__inliner__446000101_A { A_arbace_math_A_Init(); t := &A_arbace_math_ulp__inliner__446000101_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Invoke_O_O__O(self, d__0 any) any { var root_607 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any; var root_611 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_75); var arg_615 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_616 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var root_620 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_76); var arg_624 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_621 == nil { arg_619 = ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { arg_619 = linked_621.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }; if linked_617 == nil { tmp2 = ifn_618.Invoke_O__O(arg_619) } else { tmp2 = linked_617.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_616, arg_619) }; arg_615 = tmp1.Invoke_O__O(tmp2); if linked_612 == nil { arg_610 = ifn_613.Invoke_O_O__O(arg_614, arg_615) } else { arg_610 = linked_612.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_611, arg_614, arg_615) }; if linked_608 == nil { return ifn_609.Invoke_O__O(arg_610) } else { return linked_608.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_607, arg_610) } }












func A_arbace_math_signum_A_New() *A_arbace_math_signum_A { A_arbace_math_A_Init(); t := &A_arbace_math_signum_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum_A) InvokePrim_O_D__D(self any, d__0 float64) float64 {







	return jrt.Math_Signum_D__D(d__0) }
//line :364:1
func (t *A_arbace_math_signum_A) Invoke_O_O__O(self, p_d__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0))).Ref() }
//line :364:1
func A_arbace_math_signum__inliner__446000104_A_New() *A_arbace_math_signum__inliner__446000104_A { A_arbace_math_A_Init(); t := &A_arbace_math_signum__inliner__446000104_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Invoke_O_O__O(self, d__0 any) any { var root_625 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var root_629 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_77); var arg_633 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_634 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any; var root_638 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_78); var arg_642 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_639 == nil { arg_637 = ifn_640.Invoke_O_O__O(arg_641, arg_642) } else { arg_637 = linked_639.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_638, arg_641, arg_642) }; if linked_635 == nil { tmp2 = ifn_636.Invoke_O__O(arg_637) } else { tmp2 = linked_635.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_634, arg_637) }; arg_633 = tmp1.Invoke_O__O(tmp2); if linked_630 == nil { arg_628 = ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { arg_628 = linked_630.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_629, arg_632, arg_633) }; if linked_626 == nil { return ifn_627.Invoke_O__O(arg_628) } else { return linked_626.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_625, arg_628) } }









func A_arbace_math_sinh_A_New() *A_arbace_math_sinh_A { A_arbace_math_A_Init(); t := &A_arbace_math_sinh_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh_A) InvokePrim_O_D__D(self any, x__0 float64) float64 {








	return jrt.Math_Sinh_D__D(x__0) }
//line :374:1
func (t *A_arbace_math_sinh_A) Invoke_O_O__O(self, p_x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_x__0))).Ref() }
//line :374:1
func A_arbace_math_sinh__inliner__446000107_A_New() *A_arbace_math_sinh__inliner__446000107_A { A_arbace_math_A_Init(); t := &A_arbace_math_sinh__inliner__446000107_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Invoke_O_O__O(self, x__0 any) any { var root_643 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any; var root_647 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_79); var arg_651 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_652 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any; var root_656 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_80); var arg_660 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_657 == nil { arg_655 = ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { arg_655 = linked_657.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_656, arg_659, arg_660) }; if linked_653 == nil { tmp2 = ifn_654.Invoke_O__O(arg_655) } else { tmp2 = linked_653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_652, arg_655) }; arg_651 = tmp1.Invoke_O__O(tmp2); if linked_648 == nil { arg_646 = ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { arg_646 = linked_648.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_647, arg_650, arg_651) }; if linked_644 == nil { return ifn_645.Invoke_O__O(arg_646) } else { return linked_644.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_643, arg_646) } }










func A_arbace_math_cosh_A_New() *A_arbace_math_cosh_A { A_arbace_math_A_Init(); t := &A_arbace_math_cosh_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh_A) InvokePrim_O_D__D(self any, x__0 float64) float64 {









	return jrt.Math_Cosh_D__D(x__0) }
//line :385:1
func (t *A_arbace_math_cosh_A) Invoke_O_O__O(self, p_x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_x__0))).Ref() }
//line :385:1
func A_arbace_math_cosh__inliner__446000110_A_New() *A_arbace_math_cosh__inliner__446000110_A { A_arbace_math_A_Init(); t := &A_arbace_math_cosh__inliner__446000110_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Invoke_O_O__O(self, x__0 any) any { var root_661 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any; var root_665 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_81); var arg_669 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_670 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var root_674 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_82); var arg_678 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_675 == nil { arg_673 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { arg_673 = linked_675.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; if linked_671 == nil { tmp2 = ifn_672.Invoke_O__O(arg_673) } else { tmp2 = linked_671.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_670, arg_673) }; arg_669 = tmp1.Invoke_O__O(tmp2); if linked_666 == nil { arg_664 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { arg_664 = linked_666.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }; if linked_662 == nil { return ifn_663.Invoke_O__O(arg_664) } else { return linked_662.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_661, arg_664) } }











func A_arbace_math_tanh_A_New() *A_arbace_math_tanh_A { A_arbace_math_A_Init(); t := &A_arbace_math_tanh_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh_A) InvokePrim_O_D__D(self any, x__0 float64) float64 {










	return jrt.Math_Tanh_D__D(x__0) }
//line :397:1
func (t *A_arbace_math_tanh_A) Invoke_O_O__O(self, p_x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_x__0))).Ref() }
//line :397:1
func A_arbace_math_tanh__inliner__446000113_A_New() *A_arbace_math_tanh__inliner__446000113_A { A_arbace_math_A_Init(); t := &A_arbace_math_tanh__inliner__446000113_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Invoke_O_O__O(self, x__0 any) any { var root_679 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any; var root_683 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_83); var arg_687 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_688 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var root_692 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_84); var arg_696 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_693 == nil { arg_691 = ifn_694.Invoke_O_O__O(arg_695, arg_696) } else { arg_691 = linked_693.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_692, arg_695, arg_696) }; if linked_689 == nil { tmp2 = ifn_690.Invoke_O__O(arg_691) } else { tmp2 = linked_689.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_688, arg_691) }; arg_687 = tmp1.Invoke_O__O(tmp2); if linked_684 == nil { arg_682 = ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { arg_682 = linked_684.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; if linked_680 == nil { return ifn_681.Invoke_O__O(arg_682) } else { return linked_680.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_679, arg_682) } }












func A_arbace_math_hypot_A_New() *A_arbace_math_hypot_A { A_arbace_math_A_Init(); t := &A_arbace_math_hypot_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot_A) InvokePrim_O_D_D__D(self any, x__0, y__1 float64) float64 {








	return jrt.Math_Hypot_D_D__D(x__0, y__1) }
//line :410:1
func (t *A_arbace_math_hypot_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_x__0), lang.RT_DoubleCast_O__D_NoInit(p_y__1))).Ref() }
//line :410:1
func A_arbace_math_hypot__inliner__446000116_A_New() *A_arbace_math_hypot__inliner__446000116_A { A_arbace_math_A_Init(); t := &A_arbace_math_hypot__inliner__446000116_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_697 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_85); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_707 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var root_711 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_86); var arg_715 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_712 == nil { arg_710 = ifn_713.Invoke_O_O__O(arg_714, arg_715) } else { arg_710 = linked_712.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_711, arg_714, arg_715) }; if linked_708 == nil { tmp4 = ifn_709.Invoke_O__O(arg_710) } else { tmp4 = linked_708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_707, arg_710) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_716 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any; var root_720 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_87); var arg_724 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_721 == nil { arg_719 = ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { arg_719 = linked_721.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_720, arg_723, arg_724) }; if linked_717 == nil { tmp7 = ifn_718.Invoke_O__O(arg_719) } else { tmp7 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }; arg_700 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_698 == nil { return ifn_699.Invoke_O__O(arg_700) } else { return linked_698.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_697, arg_700) } }










func A_arbace_math_expm1_A_New() *A_arbace_math_expm1_A { A_arbace_math_A_Init(); t := &A_arbace_math_expm1_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1_A) InvokePrim_O_D__D(self any, x__0 float64) float64 {










	return jrt.Math_Expm1_D__D(x__0) }
//line :421:1
func (t *A_arbace_math_expm1_A) Invoke_O_O__O(self, p_x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_x__0))).Ref() }
//line :421:1
func A_arbace_math_expm1__inliner__446000119_A_New() *A_arbace_math_expm1__inliner__446000119_A { A_arbace_math_A_Init(); t := &A_arbace_math_expm1__inliner__446000119_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Invoke_O_O__O(self, x__0 any) any { var root_725 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var root_729 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_88); var arg_733 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_734 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var root_738 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_89); var arg_742 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_739 == nil { arg_737 = ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { arg_737 = linked_739.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_738, arg_741, arg_742) }; if linked_735 == nil { tmp2 = ifn_736.Invoke_O__O(arg_737) } else { tmp2 = linked_735.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_734, arg_737) }; arg_733 = tmp1.Invoke_O__O(tmp2); if linked_730 == nil { arg_728 = ifn_731.Invoke_O_O__O(arg_732, arg_733) } else { arg_728 = linked_730.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_729, arg_732, arg_733) }; if linked_726 == nil { return ifn_727.Invoke_O__O(arg_728) } else { return linked_726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_725, arg_728) } }












func A_arbace_math_log1p_A_New() *A_arbace_math_log1p_A { A_arbace_math_A_Init(); t := &A_arbace_math_log1p_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p_A) InvokePrim_O_D__D(self any, x__0 float64) float64 {











	return jrt.Math_Log1p_D__D(x__0) }
//line :434:1
func (t *A_arbace_math_log1p_A) Invoke_O_O__O(self, p_x__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_x__0))).Ref() }
//line :434:1
func A_arbace_math_log1p__inliner__446000122_A_New() *A_arbace_math_log1p__inliner__446000122_A { A_arbace_math_A_Init(); t := &A_arbace_math_log1p__inliner__446000122_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Invoke_O_O__O(self, x__0 any) any { var root_743 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any; var root_747 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_90); var arg_751 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_752 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_756 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_91); var arg_760 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_757 == nil { arg_755 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { arg_755 = linked_757.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; if linked_753 == nil { tmp2 = ifn_754.Invoke_O__O(arg_755) } else { tmp2 = linked_753.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_752, arg_755) }; arg_751 = tmp1.Invoke_O__O(tmp2); if linked_748 == nil { arg_746 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { arg_746 = linked_748.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; if linked_744 == nil { return ifn_745.Invoke_O__O(arg_746) } else { return linked_744.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_743, arg_746) } }













func A_arbace_math_copy_sign_A_New() *A_arbace_math_copy_sign_A { A_arbace_math_A_Init(); t := &A_arbace_math_copy_sign_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign_A) InvokePrim_O_D_D__D(self any, magnitude__0, sign__1 float64) float64 {







	return jrt.Math_CopySign_D_D__D(magnitude__0, sign__1) }
//line :448:1
func (t *A_arbace_math_copy_sign_A) Invoke_O_O_O__O(self, p_magnitude__0, p_sign__1 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_magnitude__0), lang.RT_DoubleCast_O__D_NoInit(p_sign__1))).Ref() }
//line :448:1
func A_arbace_math_copy_sign__inliner__446000125_A_New() *A_arbace_math_copy_sign__inliner__446000125_A { A_arbace_math_A_Init(); t := &A_arbace_math_copy_sign__inliner__446000125_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Invoke_O_O_O__O(self, magnitude__0, sign__1 any) any { var root_761 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_92); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_771 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any; var root_775 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_93); var arg_779 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(magnitude__0); if linked_776 == nil { arg_774 = ifn_777.Invoke_O_O__O(arg_778, arg_779) } else { arg_774 = linked_776.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_775, arg_778, arg_779) }; if linked_772 == nil { tmp4 = ifn_773.Invoke_O__O(arg_774) } else { tmp4 = linked_772.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_771, arg_774) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_780 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any; var root_784 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_94); var arg_788 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(sign__1); if linked_785 == nil { arg_783 = ifn_786.Invoke_O_O__O(arg_787, arg_788) } else { arg_783 = linked_785.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_784, arg_787, arg_788) }; if linked_781 == nil { tmp7 = ifn_782.Invoke_O__O(arg_783) } else { tmp7 = linked_781.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_780, arg_783) }; arg_764 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_762 == nil { return ifn_763.Invoke_O__O(arg_764) } else { return linked_762.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_761, arg_764) } }









func A_arbace_math_get_exponent_A_New() *A_arbace_math_get_exponent_A { A_arbace_math_A_Init(); t := &A_arbace_math_get_exponent_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent_A) InvokePrim_O_D__O(self any, d__0 float64) any {








	return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Math_GetExponent_D__I(d__0)).Ref() }
//line :458:1
func (t *A_arbace_math_get_exponent_A) Invoke_O_O__O(self, p_d__0 any) any { return t.InvokePrim_O_D__O(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0)) }
//line :458:1
func A_arbace_math_get_exponent__inliner__446000128_A_New() *A_arbace_math_get_exponent__inliner__446000128_A { A_arbace_math_A_Init(); t := &A_arbace_math_get_exponent__inliner__446000128_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Invoke_O_O__O(self, d__0 any) any { var root_789 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var root_793 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_95); var arg_797 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_798 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var root_802 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_96); var arg_806 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_803 == nil { arg_801 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { arg_801 = linked_803.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; if linked_799 == nil { tmp2 = ifn_800.Invoke_O__O(arg_801) } else { tmp2 = linked_799.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_798, arg_801) }; arg_797 = tmp1.Invoke_O__O(tmp2); if linked_794 == nil { arg_792 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { arg_792 = linked_794.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }; if linked_790 == nil { return ifn_791.Invoke_O__O(arg_792) } else { return linked_790.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_789, arg_792) } }










func A_arbace_math_next_after_A_New() *A_arbace_math_next_after_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_after_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after_A) InvokePrim_O_D_D__D(self any, start__0, direction__1 float64) float64 {















	return jrt.Math_NextAfter_D_D__D(start__0, direction__1) }
//line :469:1
func (t *A_arbace_math_next_after_A) Invoke_O_O_O__O(self, p_start__0, p_direction__1 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_start__0), lang.RT_DoubleCast_O__D_NoInit(p_direction__1))).Ref() }
//line :469:1
func A_arbace_math_next_after__inliner__446000131_A_New() *A_arbace_math_next_after__inliner__446000131_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_after__inliner__446000131_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Invoke_O_O_O__O(self, start__0, direction__1 any) any { var root_807 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_97); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_817 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any; var root_821 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_98); var arg_825 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(start__0); if linked_822 == nil { arg_820 = ifn_823.Invoke_O_O__O(arg_824, arg_825) } else { arg_820 = linked_822.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_821, arg_824, arg_825) }; if linked_818 == nil { tmp4 = ifn_819.Invoke_O__O(arg_820) } else { tmp4 = linked_818.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_817, arg_820) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_826 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any; var root_830 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_99); var arg_834 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(direction__1); if linked_831 == nil { arg_829 = ifn_832.Invoke_O_O__O(arg_833, arg_834) } else { arg_829 = linked_831.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_830, arg_833, arg_834) }; if linked_827 == nil { tmp7 = ifn_828.Invoke_O__O(arg_829) } else { tmp7 = linked_827.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_826, arg_829) }; arg_810 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_808 == nil { return ifn_809.Invoke_O__O(arg_810) } else { return linked_808.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_807, arg_810) } }

















func A_arbace_math_next_up_A_New() *A_arbace_math_next_up_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_up_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up_A) InvokePrim_O_D__D(self any, d__0 float64) float64 {









	return jrt.Math_NextUp_D__D(d__0) }
//line :487:1
func (t *A_arbace_math_next_up_A) Invoke_O_O__O(self, p_d__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0))).Ref() }
//line :487:1
func A_arbace_math_next_up__inliner__446000134_A_New() *A_arbace_math_next_up__inliner__446000134_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_up__inliner__446000134_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Invoke_O_O__O(self, d__0 any) any { var root_835 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any; var root_839 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_100); var arg_843 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_844 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any; var root_848 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_101); var arg_852 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_849 == nil { arg_847 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { arg_847 = linked_849.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) }; if linked_845 == nil { tmp2 = ifn_846.Invoke_O__O(arg_847) } else { tmp2 = linked_845.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_844, arg_847) }; arg_843 = tmp1.Invoke_O__O(tmp2); if linked_840 == nil { arg_838 = ifn_841.Invoke_O_O__O(arg_842, arg_843) } else { arg_838 = linked_840.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_839, arg_842, arg_843) }; if linked_836 == nil { return ifn_837.Invoke_O__O(arg_838) } else { return linked_836.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_835, arg_838) } }











func A_arbace_math_next_down_A_New() *A_arbace_math_next_down_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_down_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down_A) InvokePrim_O_D__D(self any, d__0 float64) float64 {









	return jrt.Math_NextDown_D__D(d__0) }
//line :499:1
func (t *A_arbace_math_next_down_A) Invoke_O_O__O(self, p_d__0 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D__D(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0))).Ref() }
//line :499:1
func A_arbace_math_next_down__inliner__446000137_A_New() *A_arbace_math_next_down__inliner__446000137_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_down__inliner__446000137_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Invoke_O_O__O(self, d__0 any) any { var root_853 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any; var root_857 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_102); var arg_861 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_862 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any; var root_866 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_103); var arg_870 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_867 == nil { arg_865 = ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { arg_865 = linked_867.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) }; if linked_863 == nil { tmp2 = ifn_864.Invoke_O__O(arg_865) } else { tmp2 = linked_863.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_862, arg_865) }; arg_861 = tmp1.Invoke_O__O(tmp2); if linked_858 == nil { arg_856 = ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { arg_856 = linked_858.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_857, arg_860, arg_861) }; if linked_854 == nil { return ifn_855.Invoke_O__O(arg_856) } else { return linked_854.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_853, arg_856) } }











func A_arbace_math_scalb_A_New() *A_arbace_math_scalb_A { A_arbace_math_A_Init(); t := &A_arbace_math_scalb_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb_A) InvokePrim_O_D_O__D(self any, d__0 float64, scaleFactor__1 any) float64 {










	return jrt.Math_Scalb_D_I__D(d__0, lang.RT_IntCast_O__I_NoInit(scaleFactor__1)) }
//line :511:1
func (t *A_arbace_math_scalb_A) Invoke_O_O_O__O(self, p_d__0, scaleFactor__1 any) any { return jrt.Double_ValueOf_D__Double_NoInit(t.InvokePrim_O_D_O__D(self, lang.RT_DoubleCast_O__D_NoInit(p_d__0), scaleFactor__1)).Ref() }
//line :511:1
func A_arbace_math_scalb__inliner__446000140_A_New() *A_arbace_math_scalb__inliner__446000140_A { A_arbace_math_A_Init(); t := &A_arbace_math_scalb__inliner__446000140_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Invoke_O_O_O__O(self, d__0, scaleFactor__1 any) any { var root_871 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_104); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_881 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_885 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_105); var arg_889 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_886 == nil { arg_884 = ifn_887.Invoke_O_O__O(arg_888, arg_889) } else { arg_884 = linked_886.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_885, arg_888, arg_889) }; if linked_882 == nil { tmp4 = ifn_883.Invoke_O__O(arg_884) } else { tmp4 = linked_882.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_881, arg_884) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_890 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any; var root_894 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_106); var arg_898 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(scaleFactor__1); if linked_895 == nil { arg_893 = ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { arg_893 = linked_895.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) }; if linked_891 == nil { tmp7 = ifn_892.Invoke_O__O(arg_893) } else { tmp7 = linked_891.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_890, arg_893) }; arg_874 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_872 == nil { return ifn_873.Invoke_O__O(arg_874) } else { return linked_872.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_871, arg_874) } }






































































































































type A_arbace_math_A struct{ jrt.Object }

var A_arbace_math_A_const_pool *jrt.RefArray

var A_arbace_math_A_const_0 *lang.Var

var A_arbace_math_A_const_1 any

var A_arbace_math_A_const_2 *lang.Var

var A_arbace_math_A_const_3 *lang.Var

var A_arbace_math_A_const_4 *lang.Var

var A_arbace_math_A_const_5 *lang.Var

var A_arbace_math_A_const_6 any

var A_arbace_math_A_const_7 *lang.Var

var A_arbace_math_A_const_8 *lang.Var

var A_arbace_math_A_const_9 *lang.Var

var A_arbace_math_A_const_10 any

var A_arbace_math_A_const_11 any

var A_arbace_math_A_const_12 any

var A_arbace_math_A_const_13 any

var A_arbace_math_A_const_14 any

var A_arbace_math_A_const_15 any

var A_arbace_math_A_const_16 any

var A_arbace_math_A_const_17 any

var A_arbace_math_A_const_18 any

var A_arbace_math_A_const_19 any

var A_arbace_math_A_const_20 any

var A_arbace_math_A_const_21 any

var A_arbace_math_A_const_22 any

var A_arbace_math_A_const_23 any

var A_arbace_math_A_const_24 any

var A_arbace_math_A_const_25 any

var A_arbace_math_A_const_26 any

var A_arbace_math_A_const_27 any

var A_arbace_math_A_const_28 any

var A_arbace_math_A_const_29 any

var A_arbace_math_A_const_30 any

var A_arbace_math_A_const_31 any

var A_arbace_math_A_const_32 any

var A_arbace_math_A_const_33 any

var A_arbace_math_A_const_34 any

var A_arbace_math_A_const_35 any

var A_arbace_math_A_const_36 any

var A_arbace_math_A_const_37 any

var A_arbace_math_A_const_38 any

var A_arbace_math_A_const_39 any

var A_arbace_math_A_const_40 any

var A_arbace_math_A_const_41 any

var A_arbace_math_A_const_42 any

var A_arbace_math_A_const_43 any

var A_arbace_math_A_const_44 any

var A_arbace_math_A_const_45 any

var A_arbace_math_A_const_46 any

var A_arbace_math_A_const_47 any

var A_arbace_math_A_const_48 any

var A_arbace_math_A_const_49 any

var A_arbace_math_A_const_50 any

var A_arbace_math_A_const_51 any

var A_arbace_math_A_const_52 any

var A_arbace_math_A_const_53 any

var A_arbace_math_A_const_54 any

var A_arbace_math_A_const_55 any

var A_arbace_math_A_const_56 any

var A_arbace_math_A_const_57 any

var A_arbace_math_A_const_58 any

var A_arbace_math_A_const_59 any

var A_arbace_math_A_const_60 any

var A_arbace_math_A_const_61 any

var A_arbace_math_A_const_62 any

var A_arbace_math_A_const_63 any

var A_arbace_math_A_const_64 any

var A_arbace_math_A_const_65 any

var A_arbace_math_A_const_66 any

var A_arbace_math_A_const_67 any

var A_arbace_math_A_const_68 any

var A_arbace_math_A_const_69 any

var A_arbace_math_A_const_70 any

var A_arbace_math_A_const_71 any

var A_arbace_math_A_const_72 any

var A_arbace_math_A_const_73 any

var A_arbace_math_A_const_74 any

var A_arbace_math_A_const_75 any

var A_arbace_math_A_const_76 any

var A_arbace_math_A_const_77 any

var A_arbace_math_A_const_78 any

var A_arbace_math_A_const_79 any

var A_arbace_math_A_const_80 any

var A_arbace_math_A_const_81 any

var A_arbace_math_A_const_82 any

var A_arbace_math_A_const_83 any

var A_arbace_math_A_const_84 any

var A_arbace_math_A_const_85 any

var A_arbace_math_A_const_86 any

var A_arbace_math_A_const_87 any

var A_arbace_math_A_const_88 any

var A_arbace_math_A_const_89 any

var A_arbace_math_A_const_90 any

var A_arbace_math_A_const_91 any

var A_arbace_math_A_const_92 any

var A_arbace_math_A_const_93 any

var A_arbace_math_A_const_94 any

var A_arbace_math_A_const_95 any

var A_arbace_math_A_const_96 any

var A_arbace_math_A_const_97 any

var A_arbace_math_A_const_98 any

var A_arbace_math_A_const_99 any

var A_arbace_math_A_const_100 any

var A_arbace_math_A_const_101 any

var A_arbace_math_A_const_102 any

var A_arbace_math_A_const_103 any

var A_arbace_math_A_const_104 any

var A_arbace_math_A_const_105 any

var A_arbace_math_A_const_106 any

var A_arbace_math_A_init jrt.ClassInit

func A_arbace_math_A_Init() { if !A_arbace_math_A_init.Done() { A_arbace_math_A_init.Run(A_arbace_math_A_clinit) } }

func A_arbace_math_A_clinit() { A_arbace_math_A_clinit_p0(); A_arbace_math_A_clinit_p1(); A_arbace_math_A_clinit_p2(); A_arbace_math_A_clinit_p3(); A_arbace_math_A_clinit_p4(); A_arbace_math_A_clinit_p5(); A_arbace_math_A_clinit_p6() }

func A_arbace_math_A_clinit_p0() { jrt.StartCheck(); A_arbace_math_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 156); A_arbace_math_A_const_0 = lang.Var_Cast(A_arbace_math_A_const_pool.A[49]); A_arbace_math_A_const_1 = A_arbace_math_A_const_pool.A[50]; A_arbace_math_A_const_2 = lang.Var_Cast(A_arbace_math_A_const_pool.A[51]); A_arbace_math_A_const_3 = lang.Var_Cast(A_arbace_math_A_const_pool.A[52]); A_arbace_math_A_const_4 = lang.Var_Cast(A_arbace_math_A_const_pool.A[53]); A_arbace_math_A_const_5 = lang.Var_Cast(A_arbace_math_A_const_pool.A[54]); A_arbace_math_A_const_6 = A_arbace_math_A_const_pool.A[55]; A_arbace_math_A_const_7 = lang.Var_Cast(A_arbace_math_A_const_pool.A[56]); A_arbace_math_A_const_8 = lang.Var_Cast(A_arbace_math_A_const_pool.A[57]); A_arbace_math_A_const_9 = lang.Var_Cast(A_arbace_math_A_const_pool.A[58]); A_arbace_math_A_const_10 = A_arbace_math_A_const_pool.A[59]; A_arbace_math_A_const_11 = A_arbace_math_A_const_pool.A[60] }

func A_arbace_math_A_clinit_p1() { A_arbace_math_A_const_12 = A_arbace_math_A_const_pool.A[61]; A_arbace_math_A_const_13 = A_arbace_math_A_const_pool.A[62]; A_arbace_math_A_const_14 = A_arbace_math_A_const_pool.A[63]; A_arbace_math_A_const_15 = A_arbace_math_A_const_pool.A[64]; A_arbace_math_A_const_16 = A_arbace_math_A_const_pool.A[65]; A_arbace_math_A_const_17 = A_arbace_math_A_const_pool.A[66]; A_arbace_math_A_const_18 = A_arbace_math_A_const_pool.A[67]; A_arbace_math_A_const_19 = A_arbace_math_A_const_pool.A[68]; A_arbace_math_A_const_20 = A_arbace_math_A_const_pool.A[69]; A_arbace_math_A_const_21 = A_arbace_math_A_const_pool.A[70]; A_arbace_math_A_const_22 = A_arbace_math_A_const_pool.A[71]; A_arbace_math_A_const_23 = A_arbace_math_A_const_pool.A[72]; A_arbace_math_A_const_24 = A_arbace_math_A_const_pool.A[73]; A_arbace_math_A_const_25 = A_arbace_math_A_const_pool.A[74]; A_arbace_math_A_const_26 = A_arbace_math_A_const_pool.A[75]; A_arbace_math_A_const_27 = A_arbace_math_A_const_pool.A[76] }

func A_arbace_math_A_clinit_p2() { A_arbace_math_A_const_28 = A_arbace_math_A_const_pool.A[77]; A_arbace_math_A_const_29 = A_arbace_math_A_const_pool.A[78]; A_arbace_math_A_const_30 = A_arbace_math_A_const_pool.A[79]; A_arbace_math_A_const_31 = A_arbace_math_A_const_pool.A[80]; A_arbace_math_A_const_32 = A_arbace_math_A_const_pool.A[81]; A_arbace_math_A_const_33 = A_arbace_math_A_const_pool.A[82]; A_arbace_math_A_const_34 = A_arbace_math_A_const_pool.A[83]; A_arbace_math_A_const_35 = A_arbace_math_A_const_pool.A[84]; A_arbace_math_A_const_36 = A_arbace_math_A_const_pool.A[85]; A_arbace_math_A_const_37 = A_arbace_math_A_const_pool.A[86]; A_arbace_math_A_const_38 = A_arbace_math_A_const_pool.A[87]; A_arbace_math_A_const_39 = A_arbace_math_A_const_pool.A[88]; A_arbace_math_A_const_40 = A_arbace_math_A_const_pool.A[89]; A_arbace_math_A_const_41 = A_arbace_math_A_const_pool.A[90]; A_arbace_math_A_const_42 = A_arbace_math_A_const_pool.A[91]; A_arbace_math_A_const_43 = A_arbace_math_A_const_pool.A[92] }

func A_arbace_math_A_clinit_p3() { A_arbace_math_A_const_44 = A_arbace_math_A_const_pool.A[93]; A_arbace_math_A_const_45 = A_arbace_math_A_const_pool.A[94]; A_arbace_math_A_const_46 = A_arbace_math_A_const_pool.A[95]; A_arbace_math_A_const_47 = A_arbace_math_A_const_pool.A[96]; A_arbace_math_A_const_48 = A_arbace_math_A_const_pool.A[97]; A_arbace_math_A_const_49 = A_arbace_math_A_const_pool.A[98]; A_arbace_math_A_const_50 = A_arbace_math_A_const_pool.A[99]; A_arbace_math_A_const_51 = A_arbace_math_A_const_pool.A[100]; A_arbace_math_A_const_52 = A_arbace_math_A_const_pool.A[101]; A_arbace_math_A_const_53 = A_arbace_math_A_const_pool.A[102]; A_arbace_math_A_const_54 = A_arbace_math_A_const_pool.A[103]; A_arbace_math_A_const_55 = A_arbace_math_A_const_pool.A[104]; A_arbace_math_A_const_56 = A_arbace_math_A_const_pool.A[105]; A_arbace_math_A_const_57 = A_arbace_math_A_const_pool.A[106]; A_arbace_math_A_const_58 = A_arbace_math_A_const_pool.A[107]; A_arbace_math_A_const_59 = A_arbace_math_A_const_pool.A[108] }

func A_arbace_math_A_clinit_p4() { A_arbace_math_A_const_60 = A_arbace_math_A_const_pool.A[109]; A_arbace_math_A_const_61 = A_arbace_math_A_const_pool.A[110]; A_arbace_math_A_const_62 = A_arbace_math_A_const_pool.A[111]; A_arbace_math_A_const_63 = A_arbace_math_A_const_pool.A[112]; A_arbace_math_A_const_64 = A_arbace_math_A_const_pool.A[113]; A_arbace_math_A_const_65 = A_arbace_math_A_const_pool.A[114]; A_arbace_math_A_const_66 = A_arbace_math_A_const_pool.A[115]; A_arbace_math_A_const_67 = A_arbace_math_A_const_pool.A[116]; A_arbace_math_A_const_68 = A_arbace_math_A_const_pool.A[117]; A_arbace_math_A_const_69 = A_arbace_math_A_const_pool.A[118]; A_arbace_math_A_const_70 = A_arbace_math_A_const_pool.A[119]; A_arbace_math_A_const_71 = A_arbace_math_A_const_pool.A[120]; A_arbace_math_A_const_72 = A_arbace_math_A_const_pool.A[121]; A_arbace_math_A_const_73 = A_arbace_math_A_const_pool.A[122]; A_arbace_math_A_const_74 = A_arbace_math_A_const_pool.A[123]; A_arbace_math_A_const_75 = A_arbace_math_A_const_pool.A[124] }

func A_arbace_math_A_clinit_p5() { A_arbace_math_A_const_76 = A_arbace_math_A_const_pool.A[125]; A_arbace_math_A_const_77 = A_arbace_math_A_const_pool.A[126]; A_arbace_math_A_const_78 = A_arbace_math_A_const_pool.A[127]; A_arbace_math_A_const_79 = A_arbace_math_A_const_pool.A[128]; A_arbace_math_A_const_80 = A_arbace_math_A_const_pool.A[129]; A_arbace_math_A_const_81 = A_arbace_math_A_const_pool.A[130]; A_arbace_math_A_const_82 = A_arbace_math_A_const_pool.A[131]; A_arbace_math_A_const_83 = A_arbace_math_A_const_pool.A[132]; A_arbace_math_A_const_84 = A_arbace_math_A_const_pool.A[133]; A_arbace_math_A_const_85 = A_arbace_math_A_const_pool.A[134]; A_arbace_math_A_const_86 = A_arbace_math_A_const_pool.A[135]; A_arbace_math_A_const_87 = A_arbace_math_A_const_pool.A[136]; A_arbace_math_A_const_88 = A_arbace_math_A_const_pool.A[137]; A_arbace_math_A_const_89 = A_arbace_math_A_const_pool.A[138]; A_arbace_math_A_const_90 = A_arbace_math_A_const_pool.A[139]; A_arbace_math_A_const_91 = A_arbace_math_A_const_pool.A[140] }

func A_arbace_math_A_clinit_p6() { A_arbace_math_A_const_92 = A_arbace_math_A_const_pool.A[141]; A_arbace_math_A_const_93 = A_arbace_math_A_const_pool.A[142]; A_arbace_math_A_const_94 = A_arbace_math_A_const_pool.A[143]; A_arbace_math_A_const_95 = A_arbace_math_A_const_pool.A[144]; A_arbace_math_A_const_96 = A_arbace_math_A_const_pool.A[145]; A_arbace_math_A_const_97 = A_arbace_math_A_const_pool.A[146]; A_arbace_math_A_const_98 = A_arbace_math_A_const_pool.A[147]; A_arbace_math_A_const_99 = A_arbace_math_A_const_pool.A[148]; A_arbace_math_A_const_100 = A_arbace_math_A_const_pool.A[149]; A_arbace_math_A_const_101 = A_arbace_math_A_const_pool.A[150]; A_arbace_math_A_const_102 = A_arbace_math_A_const_pool.A[151]; A_arbace_math_A_const_103 = A_arbace_math_A_const_pool.A[152]; A_arbace_math_A_const_104 = A_arbace_math_A_const_pool.A[153]; A_arbace_math_A_const_105 = A_arbace_math_A_const_pool.A[154]; A_arbace_math_A_const_106 = A_arbace_math_A_const_pool.A[155] }

func A_arbace_math_A_New() *A_arbace_math_A { A_arbace_math_A_Init(); t := &A_arbace_math_A{}; t.Ctor(); return t }

func (t *A_arbace_math_A) Ctor() {}

func (t *A_arbace_math_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_A) GetClass__Class() *jrt.Class { return A_arbace_math_A_class }

func (t *A_arbace_math_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_A); return ok }

func A_arbace_math_A_Cast(x any) *A_arbace_math_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_A_class)) }; return v }



type A_arbace_math_IEEE_remainder_A struct{ j2g_header uint64 }

var A_arbace_math_IEEE_remainder_A_fn_class *jrt.Class



type A_arbace_math_IEEE_remainder__inliner__446000053_A struct{ j2g_header uint64 }

var A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class *jrt.Class



type A_arbace_math_acos_A struct{ j2g_header uint64 }

var A_arbace_math_acos_A_fn_class *jrt.Class



type A_arbace_math_acos__inliner__446000026_A struct{ j2g_header uint64 }

var A_arbace_math_acos__inliner__446000026_A_fn_class *jrt.Class



type A_arbace_math_add_exact_A struct{ j2g_header uint64 }

var A_arbace_math_add_exact_A_fn_class *jrt.Class



type A_arbace_math_add_exact__inliner__446000077_A struct{ j2g_header uint64 }

var A_arbace_math_add_exact__inliner__446000077_A_fn_class *jrt.Class



type A_arbace_math_asin_A struct{ j2g_header uint64 }

var A_arbace_math_asin_A_fn_class *jrt.Class



type A_arbace_math_asin__inliner__446000023_A struct{ j2g_header uint64 }

var A_arbace_math_asin__inliner__446000023_A_fn_class *jrt.Class



type A_arbace_math_atan_A struct{ j2g_header uint64 }

var A_arbace_math_atan_A_fn_class *jrt.Class



type A_arbace_math_atan2_A struct{ j2g_header uint64 }

var A_arbace_math_atan2_A_fn_class *jrt.Class



type A_arbace_math_atan2__inliner__446000065_A struct{ j2g_header uint64 }

var A_arbace_math_atan2__inliner__446000065_A_fn_class *jrt.Class



type A_arbace_math_atan__inliner__446000029_A struct{ j2g_header uint64 }

var A_arbace_math_atan__inliner__446000029_A_fn_class *jrt.Class



type A_arbace_math_cbrt_A struct{ j2g_header uint64 }

var A_arbace_math_cbrt_A_fn_class *jrt.Class



type A_arbace_math_cbrt__inliner__446000050_A struct{ j2g_header uint64 }

var A_arbace_math_cbrt__inliner__446000050_A_fn_class *jrt.Class



type A_arbace_math_ceil_A struct{ j2g_header uint64 }

var A_arbace_math_ceil_A_fn_class *jrt.Class



type A_arbace_math_ceil__inliner__446000056_A struct{ j2g_header uint64 }

var A_arbace_math_ceil__inliner__446000056_A_fn_class *jrt.Class



type A_arbace_math_copy_sign_A struct{ j2g_header uint64 }

var A_arbace_math_copy_sign_A_fn_class *jrt.Class



type A_arbace_math_copy_sign__inliner__446000125_A struct{ j2g_header uint64 }

var A_arbace_math_copy_sign__inliner__446000125_A_fn_class *jrt.Class



type A_arbace_math_cos_A struct{ j2g_header uint64 }

var A_arbace_math_cos_A_fn_class *jrt.Class



type A_arbace_math_cos__inliner__446000017_A struct{ j2g_header uint64 }

var A_arbace_math_cos__inliner__446000017_A_fn_class *jrt.Class



type A_arbace_math_cosh_A struct{ j2g_header uint64 }

var A_arbace_math_cosh_A_fn_class *jrt.Class



type A_arbace_math_cosh__inliner__446000110_A struct{ j2g_header uint64 }

var A_arbace_math_cosh__inliner__446000110_A_fn_class *jrt.Class



type A_arbace_math_decrement_exact_A struct{ j2g_header uint64 }

var A_arbace_math_decrement_exact_A_fn_class *jrt.Class



type A_arbace_math_decrement_exact__inliner__446000089_A struct{ j2g_header uint64 }

var A_arbace_math_decrement_exact__inliner__446000089_A_fn_class *jrt.Class



type A_arbace_math_eval446000004_A struct{ jrt.Object }

func A_arbace_math_eval446000004_A_New() *A_arbace_math_eval446000004_A { t := &A_arbace_math_eval446000004_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000004_A) Ctor() {}

func (t *A_arbace_math_eval446000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000004_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000004_A_class }

func (t *A_arbace_math_eval446000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000004_A); return ok }

func A_arbace_math_eval446000004_A_Cast(x any) *A_arbace_math_eval446000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000004_A_class)) }; return v }



type A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A struct{ j2g_header uint64 }

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class *jrt.Class



type A_arbace_math_eval446000008_A struct{ jrt.Object }

func A_arbace_math_eval446000008_A_New() *A_arbace_math_eval446000008_A { t := &A_arbace_math_eval446000008_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000008_A) Ctor() {}

func (t *A_arbace_math_eval446000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000008_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000008_A_class }

func (t *A_arbace_math_eval446000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000008_A); return ok }

func A_arbace_math_eval446000008_A_Cast(x any) *A_arbace_math_eval446000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000008_A_class)) }; return v }



type A_arbace_math_eval446000008_fn__446000009_A struct{ j2g_header uint64 }

var A_arbace_math_eval446000008_fn__446000009_A_fn_class *jrt.Class



type A_arbace_math_exp_A struct{ j2g_header uint64 }

var A_arbace_math_exp_A_fn_class *jrt.Class



type A_arbace_math_exp__inliner__446000038_A struct{ j2g_header uint64 }

var A_arbace_math_exp__inliner__446000038_A_fn_class *jrt.Class



type A_arbace_math_expm1_A struct{ j2g_header uint64 }

var A_arbace_math_expm1_A_fn_class *jrt.Class



type A_arbace_math_expm1__inliner__446000119_A struct{ j2g_header uint64 }

var A_arbace_math_expm1__inliner__446000119_A_fn_class *jrt.Class



type A_arbace_math_floor_A struct{ j2g_header uint64 }

var A_arbace_math_floor_A_fn_class *jrt.Class



type A_arbace_math_floor__inliner__446000059_A struct{ j2g_header uint64 }

var A_arbace_math_floor__inliner__446000059_A_fn_class *jrt.Class



type A_arbace_math_floor_div_A struct{ j2g_header uint64 }

var A_arbace_math_floor_div_A_fn_class *jrt.Class



type A_arbace_math_floor_div__inliner__446000095_A struct{ j2g_header uint64 }

var A_arbace_math_floor_div__inliner__446000095_A_fn_class *jrt.Class



type A_arbace_math_floor_mod_A struct{ j2g_header uint64 }

var A_arbace_math_floor_mod_A_fn_class *jrt.Class



type A_arbace_math_floor_mod__inliner__446000098_A struct{ j2g_header uint64 }

var A_arbace_math_floor_mod__inliner__446000098_A_fn_class *jrt.Class



type A_arbace_math_get_exponent_A struct{ j2g_header uint64 }

var A_arbace_math_get_exponent_A_fn_class *jrt.Class



type A_arbace_math_get_exponent__inliner__446000128_A struct{ j2g_header uint64 }

var A_arbace_math_get_exponent__inliner__446000128_A_fn_class *jrt.Class



type A_arbace_math_hypot_A struct{ j2g_header uint64 }

var A_arbace_math_hypot_A_fn_class *jrt.Class



type A_arbace_math_hypot__inliner__446000116_A struct{ j2g_header uint64 }

var A_arbace_math_hypot__inliner__446000116_A_fn_class *jrt.Class



type A_arbace_math_increment_exact_A struct{ j2g_header uint64 }

var A_arbace_math_increment_exact_A_fn_class *jrt.Class



type A_arbace_math_increment_exact__inliner__446000086_A struct{ j2g_header uint64 }

var A_arbace_math_increment_exact__inliner__446000086_A_fn_class *jrt.Class



type A_arbace_math_log_A struct{ j2g_header uint64 }

var A_arbace_math_log_A_fn_class *jrt.Class



type A_arbace_math_log10_A struct{ j2g_header uint64 }

var A_arbace_math_log10_A_fn_class *jrt.Class



type A_arbace_math_log10__inliner__446000044_A struct{ j2g_header uint64 }

var A_arbace_math_log10__inliner__446000044_A_fn_class *jrt.Class



type A_arbace_math_log1p_A struct{ j2g_header uint64 }

var A_arbace_math_log1p_A_fn_class *jrt.Class



type A_arbace_math_log1p__inliner__446000122_A struct{ j2g_header uint64 }

var A_arbace_math_log1p__inliner__446000122_A_fn_class *jrt.Class



type A_arbace_math_log__inliner__446000041_A struct{ j2g_header uint64 }

var A_arbace_math_log__inliner__446000041_A_fn_class *jrt.Class



type A_arbace_math_multiply_exact_A struct{ j2g_header uint64 }

var A_arbace_math_multiply_exact_A_fn_class *jrt.Class



type A_arbace_math_multiply_exact__inliner__446000083_A struct{ j2g_header uint64 }

var A_arbace_math_multiply_exact__inliner__446000083_A_fn_class *jrt.Class



type A_arbace_math_negate_exact_A struct{ j2g_header uint64 }

var A_arbace_math_negate_exact_A_fn_class *jrt.Class



type A_arbace_math_negate_exact__inliner__446000092_A struct{ j2g_header uint64 }

var A_arbace_math_negate_exact__inliner__446000092_A_fn_class *jrt.Class



type A_arbace_math_next_after_A struct{ j2g_header uint64 }

var A_arbace_math_next_after_A_fn_class *jrt.Class



type A_arbace_math_next_after__inliner__446000131_A struct{ j2g_header uint64 }

var A_arbace_math_next_after__inliner__446000131_A_fn_class *jrt.Class



type A_arbace_math_next_down_A struct{ j2g_header uint64 }

var A_arbace_math_next_down_A_fn_class *jrt.Class



type A_arbace_math_next_down__inliner__446000137_A struct{ j2g_header uint64 }

var A_arbace_math_next_down__inliner__446000137_A_fn_class *jrt.Class



type A_arbace_math_next_up_A struct{ j2g_header uint64 }

var A_arbace_math_next_up_A_fn_class *jrt.Class



type A_arbace_math_next_up__inliner__446000134_A struct{ j2g_header uint64 }

var A_arbace_math_next_up__inliner__446000134_A_fn_class *jrt.Class



type A_arbace_math_pow_A struct{ j2g_header uint64 }

var A_arbace_math_pow_A_fn_class *jrt.Class



type A_arbace_math_pow__inliner__446000068_A struct{ j2g_header uint64 }

var A_arbace_math_pow__inliner__446000068_A_fn_class *jrt.Class



type A_arbace_math_random_A struct{ j2g_header uint64 }

var A_arbace_math_random_A_fn_class *jrt.Class



type A_arbace_math_random__inliner__446000074_A struct{ j2g_header uint64 }

var A_arbace_math_random__inliner__446000074_A_fn_class *jrt.Class



type A_arbace_math_rint_A struct{ j2g_header uint64 }

var A_arbace_math_rint_A_fn_class *jrt.Class



type A_arbace_math_rint__inliner__446000062_A struct{ j2g_header uint64 }

var A_arbace_math_rint__inliner__446000062_A_fn_class *jrt.Class



type A_arbace_math_round_A struct{ j2g_header uint64 }

var A_arbace_math_round_A_fn_class *jrt.Class



type A_arbace_math_round__inliner__446000071_A struct{ j2g_header uint64 }

var A_arbace_math_round__inliner__446000071_A_fn_class *jrt.Class



type A_arbace_math_scalb_A struct{ j2g_header uint64 }

var A_arbace_math_scalb_A_fn_class *jrt.Class



type A_arbace_math_scalb__inliner__446000140_A struct{ j2g_header uint64 }

var A_arbace_math_scalb__inliner__446000140_A_fn_class *jrt.Class



type A_arbace_math_signum_A struct{ j2g_header uint64 }

var A_arbace_math_signum_A_fn_class *jrt.Class



type A_arbace_math_signum__inliner__446000104_A struct{ j2g_header uint64 }

var A_arbace_math_signum__inliner__446000104_A_fn_class *jrt.Class



type A_arbace_math_sin_A struct{ j2g_header uint64 }

var A_arbace_math_sin_A_fn_class *jrt.Class



type A_arbace_math_sin__inliner__446000014_A struct{ j2g_header uint64 }

var A_arbace_math_sin__inliner__446000014_A_fn_class *jrt.Class



type A_arbace_math_sinh_A struct{ j2g_header uint64 }

var A_arbace_math_sinh_A_fn_class *jrt.Class



type A_arbace_math_sinh__inliner__446000107_A struct{ j2g_header uint64 }

var A_arbace_math_sinh__inliner__446000107_A_fn_class *jrt.Class



type A_arbace_math_sqrt_A struct{ j2g_header uint64 }

var A_arbace_math_sqrt_A_fn_class *jrt.Class



type A_arbace_math_sqrt__inliner__446000047_A struct{ j2g_header uint64 }

var A_arbace_math_sqrt__inliner__446000047_A_fn_class *jrt.Class



type A_arbace_math_subtract_exact_A struct{ j2g_header uint64 }

var A_arbace_math_subtract_exact_A_fn_class *jrt.Class



type A_arbace_math_subtract_exact__inliner__446000080_A struct{ j2g_header uint64 }

var A_arbace_math_subtract_exact__inliner__446000080_A_fn_class *jrt.Class



type A_arbace_math_tan_A struct{ j2g_header uint64 }

var A_arbace_math_tan_A_fn_class *jrt.Class



type A_arbace_math_tan__inliner__446000020_A struct{ j2g_header uint64 }

var A_arbace_math_tan__inliner__446000020_A_fn_class *jrt.Class



type A_arbace_math_tanh_A struct{ j2g_header uint64 }

var A_arbace_math_tanh_A_fn_class *jrt.Class



type A_arbace_math_tanh__inliner__446000113_A struct{ j2g_header uint64 }

var A_arbace_math_tanh__inliner__446000113_A_fn_class *jrt.Class



type A_arbace_math_to_degrees_A struct{ j2g_header uint64 }

var A_arbace_math_to_degrees_A_fn_class *jrt.Class



type A_arbace_math_to_degrees__inliner__446000035_A struct{ j2g_header uint64 }

var A_arbace_math_to_degrees__inliner__446000035_A_fn_class *jrt.Class



type A_arbace_math_to_radians_A struct{ j2g_header uint64 }

var A_arbace_math_to_radians_A_fn_class *jrt.Class



type A_arbace_math_to_radians__inliner__446000032_A struct{ j2g_header uint64 }

var A_arbace_math_to_radians__inliner__446000032_A_fn_class *jrt.Class



type A_arbace_math_ulp_A struct{ j2g_header uint64 }

var A_arbace_math_ulp_A_fn_class *jrt.Class



type A_arbace_math_ulp__inliner__446000101_A struct{ j2g_header uint64 }

var A_arbace_math_ulp__inliner__446000101_A_fn_class *jrt.Class
