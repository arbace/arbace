//line aot_arbace_math.ae:1
package aot_arbace_math

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New() *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A { A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_Init(); t := &A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_math_A_Init(); tmp4 = A_arbace_math_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_math_A_Init(); tmp6 = A_arbace_math_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :9:1
func A_arbace_math_eval446000008_fn__446000009_A_New() *A_arbace_math_eval446000008_fn__446000009_A { A_arbace_math_eval446000008_fn__446000009_A_Init(); t := &A_arbace_math_eval446000008_fn__446000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
































func A_arbace_math_sin_A_New() *A_arbace_math_sin_A { A_arbace_math_sin_A_Init(); t := &A_arbace_math_sin_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Sin_D__D(a__0)).Ref() }
//line :42:1
func A_arbace_math_sin__inliner__446000014_A_New() *A_arbace_math_sin__inliner__446000014_A { A_arbace_math_sin__inliner__446000014_A_Init(); t := &A_arbace_math_sin__inliner__446000014_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_10; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_11; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_cos_A_New() *A_arbace_math_cos_A { A_arbace_math_cos_A_Init(); t := &A_arbace_math_cos_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Cos_D__D(a__0)).Ref() }
//line :53:1
func A_arbace_math_cos__inliner__446000017_A_New() *A_arbace_math_cos__inliner__446000017_A { A_arbace_math_cos__inliner__446000017_A_Init(); t := &A_arbace_math_cos__inliner__446000017_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_12; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_13; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }









func A_arbace_math_tan_A_New() *A_arbace_math_tan_A { A_arbace_math_tan_A_Init(); t := &A_arbace_math_tan_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Tan_D__D(a__0)).Ref() }
//line :63:1
func A_arbace_math_tan__inliner__446000020_A_New() *A_arbace_math_tan__inliner__446000020_A { A_arbace_math_tan__inliner__446000020_A_Init(); t := &A_arbace_math_tan__inliner__446000020_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_14; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_15; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_asin_A_New() *A_arbace_math_asin_A { A_arbace_math_asin_A_Init(); t := &A_arbace_math_asin_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Asin_D__D(a__0)).Ref() }
//line :74:1
func A_arbace_math_asin__inliner__446000023_A_New() *A_arbace_math_asin__inliner__446000023_A { A_arbace_math_asin__inliner__446000023_A_Init(); t := &A_arbace_math_asin__inliner__446000023_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_16; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_17; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_acos_A_New() *A_arbace_math_acos_A { A_arbace_math_acos_A_Init(); t := &A_arbace_math_acos_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Acos_D__D(a__0)).Ref() }
//line :85:1
func A_arbace_math_acos__inliner__446000026_A_New() *A_arbace_math_acos__inliner__446000026_A { A_arbace_math_acos__inliner__446000026_A_Init(); t := &A_arbace_math_acos__inliner__446000026_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_18; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_19; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }









func A_arbace_math_atan_A_New() *A_arbace_math_atan_A { A_arbace_math_atan_A_Init(); t := &A_arbace_math_atan_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Atan_D__D(a__0)).Ref() }
//line :95:1
func A_arbace_math_atan__inliner__446000029_A_New() *A_arbace_math_atan__inliner__446000029_A { A_arbace_math_atan__inliner__446000029_A_Init(); t := &A_arbace_math_atan__inliner__446000029_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_20; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_21; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_to_radians_A_New() *A_arbace_math_to_radians_A { A_arbace_math_to_radians_A_Init(); t := &A_arbace_math_to_radians_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians_A) Invoke_O_O__O(self, p_deg__0 any) any { var deg__0 float64 = lang.RT_DoubleCast_O__D(p_deg__0); return jrt.Double_ValueOf_D__Double(jrt.Math_ToRadians_D__D(deg__0)).Ref() }
//line :106:1
func A_arbace_math_to_radians__inliner__446000032_A_New() *A_arbace_math_to_radians__inliner__446000032_A { A_arbace_math_to_radians__inliner__446000032_A_Init(); t := &A_arbace_math_to_radians__inliner__446000032_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Invoke_O_O__O(self, deg__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_22; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_23; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(deg__0)))))) }








func A_arbace_math_to_degrees_A_New() *A_arbace_math_to_degrees_A { A_arbace_math_to_degrees_A_Init(); t := &A_arbace_math_to_degrees_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees_A) Invoke_O_O__O(self, p_r__0 any) any { var r__0 float64 = lang.RT_DoubleCast_O__D(p_r__0); return jrt.Double_ValueOf_D__Double(jrt.Math_ToDegrees_D__D(r__0)).Ref() }
//line :115:1
func A_arbace_math_to_degrees__inliner__446000035_A_New() *A_arbace_math_to_degrees__inliner__446000035_A { A_arbace_math_to_degrees__inliner__446000035_A_Init(); t := &A_arbace_math_to_degrees__inliner__446000035_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Invoke_O_O__O(self, r__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_24; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_25; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(r__0)))))) }








func A_arbace_math_exp_A_New() *A_arbace_math_exp_A { A_arbace_math_exp_A_Init(); t := &A_arbace_math_exp_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Exp_D__D(a__0)).Ref() }
//line :124:1
func A_arbace_math_exp__inliner__446000038_A_New() *A_arbace_math_exp__inliner__446000038_A { A_arbace_math_exp__inliner__446000038_A_Init(); t := &A_arbace_math_exp__inliner__446000038_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_26; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_27; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_log_A_New() *A_arbace_math_log_A { A_arbace_math_log_A_Init(); t := &A_arbace_math_log_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Log_D__D(a__0)).Ref() }
//line :136:1
func A_arbace_math_log__inliner__446000041_A_New() *A_arbace_math_log__inliner__446000041_A { A_arbace_math_log__inliner__446000041_A_Init(); t := &A_arbace_math_log__inliner__446000041_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_28; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_29; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_log10_A_New() *A_arbace_math_log10_A { A_arbace_math_log10_A_Init(); t := &A_arbace_math_log10_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Log10_D__D(a__0)).Ref() }
//line :148:1
func A_arbace_math_log10__inliner__446000044_A_New() *A_arbace_math_log10__inliner__446000044_A { A_arbace_math_log10__inliner__446000044_A_Init(); t := &A_arbace_math_log10__inliner__446000044_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_30; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_31; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_sqrt_A_New() *A_arbace_math_sqrt_A { A_arbace_math_sqrt_A_Init(); t := &A_arbace_math_sqrt_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Sqrt_D__D(a__0)).Ref() }
//line :160:1
func A_arbace_math_sqrt__inliner__446000047_A_New() *A_arbace_math_sqrt__inliner__446000047_A { A_arbace_math_sqrt__inliner__446000047_A_Init(); t := &A_arbace_math_sqrt__inliner__446000047_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_32; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_33; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_cbrt_A_New() *A_arbace_math_cbrt_A { A_arbace_math_cbrt_A_Init(); t := &A_arbace_math_cbrt_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Cbrt_D__D(a__0)).Ref() }
//line :172:1
func A_arbace_math_cbrt__inliner__446000050_A_New() *A_arbace_math_cbrt__inliner__446000050_A { A_arbace_math_cbrt__inliner__446000050_A_Init(); t := &A_arbace_math_cbrt__inliner__446000050_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_34; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_35; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_IEEE_remainder_A_New() *A_arbace_math_IEEE_remainder_A { A_arbace_math_IEEE_remainder_A_Init(); t := &A_arbace_math_IEEE_remainder_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Invoke_O_O_O__O(self, p_dividend__0, p_divisor__1 any) any { var dividend__0 float64 = lang.RT_DoubleCast_O__D(p_dividend__0); var divisor__1 float64 = lang.RT_DoubleCast_O__D(p_divisor__1); return jrt.Double_ValueOf_D__Double(jrt.Math_IEEEremainder_D_D__D(dividend__0, divisor__1)).Ref() }
//line :184:1
func A_arbace_math_IEEE_remainder__inliner__446000053_A_New() *A_arbace_math_IEEE_remainder__inliner__446000053_A { A_arbace_math_IEEE_remainder__inliner__446000053_A_Init(); t := &A_arbace_math_IEEE_remainder__inliner__446000053_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Invoke_O_O_O__O(self, dividend__0, divisor__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_36; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_37; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(dividend__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_38; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(divisor__1)))))) }














func A_arbace_math_ceil_A_New() *A_arbace_math_ceil_A { A_arbace_math_ceil_A_Init(); t := &A_arbace_math_ceil_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Ceil_D__D(a__0)).Ref() }
//line :199:1
func A_arbace_math_ceil__inliner__446000056_A_New() *A_arbace_math_ceil__inliner__446000056_A { A_arbace_math_ceil__inliner__446000056_A_Init(); t := &A_arbace_math_ceil__inliner__446000056_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_39; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_40; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_floor_A_New() *A_arbace_math_floor_A { A_arbace_math_floor_A_Init(); t := &A_arbace_math_floor_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Floor_D__D(a__0)).Ref() }
//line :211:1
func A_arbace_math_floor__inliner__446000059_A_New() *A_arbace_math_floor__inliner__446000059_A { A_arbace_math_floor__inliner__446000059_A_Init(); t := &A_arbace_math_floor__inliner__446000059_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_41; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_42; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_rint_A_New() *A_arbace_math_rint_A { A_arbace_math_rint_A_Init(); t := &A_arbace_math_rint_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Rint_D__D(a__0)).Ref() }
//line :222:1
func A_arbace_math_rint__inliner__446000062_A_New() *A_arbace_math_rint__inliner__446000062_A { A_arbace_math_rint__inliner__446000062_A_Init(); t := &A_arbace_math_rint__inliner__446000062_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_43; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_44; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_atan2_A_New() *A_arbace_math_atan2_A { A_arbace_math_atan2_A_Init(); t := &A_arbace_math_atan2_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2_A) Invoke_O_O_O__O(self, p_y__0, p_x__1 any) any { var y__0 float64 = lang.RT_DoubleCast_O__D(p_y__0); var x__1 float64 = lang.RT_DoubleCast_O__D(p_x__1); return jrt.Double_ValueOf_D__Double(jrt.Math_Atan2_D_D__D(y__0, x__1)).Ref() }
//line :233:1
func A_arbace_math_atan2__inliner__446000065_A_New() *A_arbace_math_atan2__inliner__446000065_A { A_arbace_math_atan2__inliner__446000065_A_Init(); t := &A_arbace_math_atan2__inliner__446000065_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Invoke_O_O_O__O(self, y__0, x__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_45; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_46; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(y__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_47; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(x__1)))))) }










func A_arbace_math_pow_A_New() *A_arbace_math_pow_A { A_arbace_math_pow_A_Init(); t := &A_arbace_math_pow_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow_A) Invoke_O_O_O__O(self, p_a__0, p_b__1 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); var b__1 float64 = lang.RT_DoubleCast_O__D(p_b__1); return jrt.Double_ValueOf_D__Double(jrt.Math_Pow_D_D__D(a__0, b__1)).Ref() }
//line :244:1
func A_arbace_math_pow__inliner__446000068_A_New() *A_arbace_math_pow__inliner__446000068_A { A_arbace_math_pow__inliner__446000068_A_Init(); t := &A_arbace_math_pow__inliner__446000068_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_48; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_49; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_50; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(b__1)))))) }









func A_arbace_math_round_A_New() *A_arbace_math_round_A { A_arbace_math_round_A_Init(); t := &A_arbace_math_round_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D(p_a__0); return jrt.Long_ValueOf_J__Long(jrt.Math_Round_D__J(a__0)).Ref() }
//line :254:1
func A_arbace_math_round__inliner__446000071_A_New() *A_arbace_math_round__inliner__446000071_A { A_arbace_math_round__inliner__446000071_A_Init(); t := &A_arbace_math_round__inliner__446000071_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_51; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_52; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }












func A_arbace_math_random_A_New() *A_arbace_math_random_A { A_arbace_math_random_A_Init(); t := &A_arbace_math_random_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random_A) Invoke_O__O(self any) any { return jrt.Double_ValueOf_D__Double(jrt.Math_Random__D()).Ref() }
//line :267:1
func A_arbace_math_random__inliner__446000074_A_New() *A_arbace_math_random__inliner__446000074_A { A_arbace_math_random__inliner__446000074_A_Init(); t := &A_arbace_math_random__inliner__446000074_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_53; return tmp2.Invoke_O__O(tmp4.Invoke_O__O(tmp6.Invoke_O__O(tmp7))) }









func A_arbace_math_add_exact_A_New() *A_arbace_math_add_exact_A { A_arbace_math_add_exact_A_Init(); t := &A_arbace_math_add_exact_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J(p_y__1); return jrt.Long_ValueOf_J__Long(jrt.Math_AddExact_J_J__J(x__0, y__1)).Ref() }
//line :277:1
func A_arbace_math_add_exact__inliner__446000077_A_New() *A_arbace_math_add_exact__inliner__446000077_A { A_arbace_math_add_exact__inliner__446000077_A_Init(); t := &A_arbace_math_add_exact__inliner__446000077_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_54; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_55; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_56; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(y__1)))))) }








func A_arbace_math_subtract_exact_A_New() *A_arbace_math_subtract_exact_A { A_arbace_math_subtract_exact_A_Init(); t := &A_arbace_math_subtract_exact_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J(p_y__1); return jrt.Long_ValueOf_J__Long(jrt.Math_SubtractExact_J_J__J(x__0, y__1)).Ref() }
//line :286:1
func A_arbace_math_subtract_exact__inliner__446000080_A_New() *A_arbace_math_subtract_exact__inliner__446000080_A { A_arbace_math_subtract_exact__inliner__446000080_A_Init(); t := &A_arbace_math_subtract_exact__inliner__446000080_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_57; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_58; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_59; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(y__1)))))) }








func A_arbace_math_multiply_exact_A_New() *A_arbace_math_multiply_exact_A { A_arbace_math_multiply_exact_A_Init(); t := &A_arbace_math_multiply_exact_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J(p_y__1); return jrt.Long_ValueOf_J__Long(jrt.Math_MultiplyExact_J_J__J(x__0, y__1)).Ref() }
//line :295:1
func A_arbace_math_multiply_exact__inliner__446000083_A_New() *A_arbace_math_multiply_exact__inliner__446000083_A { A_arbace_math_multiply_exact__inliner__446000083_A_Init(); t := &A_arbace_math_multiply_exact__inliner__446000083_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_60; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_61; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_62; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(y__1)))))) }








func A_arbace_math_increment_exact_A_New() *A_arbace_math_increment_exact_A { A_arbace_math_increment_exact_A_Init(); t := &A_arbace_math_increment_exact_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J(p_a__0); return jrt.Long_ValueOf_J__Long(jrt.Math_IncrementExact_J__J(a__0)).Ref() }
//line :304:1
func A_arbace_math_increment_exact__inliner__446000086_A_New() *A_arbace_math_increment_exact__inliner__446000086_A { A_arbace_math_increment_exact__inliner__446000086_A_Init(); t := &A_arbace_math_increment_exact__inliner__446000086_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_63; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_64; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }








func A_arbace_math_decrement_exact_A_New() *A_arbace_math_decrement_exact_A { A_arbace_math_decrement_exact_A_Init(); t := &A_arbace_math_decrement_exact_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J(p_a__0); return jrt.Long_ValueOf_J__Long(jrt.Math_DecrementExact_J__J(a__0)).Ref() }
//line :313:1
func A_arbace_math_decrement_exact__inliner__446000089_A_New() *A_arbace_math_decrement_exact__inliner__446000089_A { A_arbace_math_decrement_exact__inliner__446000089_A_Init(); t := &A_arbace_math_decrement_exact__inliner__446000089_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_65; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_66; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }








func A_arbace_math_negate_exact_A_New() *A_arbace_math_negate_exact_A { A_arbace_math_negate_exact_A_Init(); t := &A_arbace_math_negate_exact_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J(p_a__0); return jrt.Long_ValueOf_J__Long(jrt.Math_NegateExact_J__J(a__0)).Ref() }
//line :322:1
func A_arbace_math_negate_exact__inliner__446000092_A_New() *A_arbace_math_negate_exact__inliner__446000092_A { A_arbace_math_negate_exact__inliner__446000092_A_Init(); t := &A_arbace_math_negate_exact__inliner__446000092_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Invoke_O_O__O(self, a__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_67; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_68; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0)))))) }








func A_arbace_math_floor_div_A_New() *A_arbace_math_floor_div_A { A_arbace_math_floor_div_A_Init(); t := &A_arbace_math_floor_div_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J(p_y__1); return jrt.Long_ValueOf_J__Long(jrt.Math_FloorDiv_J_J__J(x__0, y__1)).Ref() }
//line :331:1
func A_arbace_math_floor_div__inliner__446000095_A_New() *A_arbace_math_floor_div__inliner__446000095_A { A_arbace_math_floor_div__inliner__446000095_A_Init(); t := &A_arbace_math_floor_div__inliner__446000095_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_69; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_70; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_71; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(y__1)))))) }









func A_arbace_math_floor_mod_A_New() *A_arbace_math_floor_mod_A { A_arbace_math_floor_mod_A_Init(); t := &A_arbace_math_floor_mod_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J(p_y__1); return jrt.Long_ValueOf_J__Long(jrt.Math_FloorMod_J_J__J(x__0, y__1)).Ref() }
//line :341:1
func A_arbace_math_floor_mod__inliner__446000098_A_New() *A_arbace_math_floor_mod__inliner__446000098_A { A_arbace_math_floor_mod__inliner__446000098_A_Init(); t := &A_arbace_math_floor_mod__inliner__446000098_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_72; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_73; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_74; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(y__1)))))) }









func A_arbace_math_ulp_A_New() *A_arbace_math_ulp_A { A_arbace_math_ulp_A_Init(); t := &A_arbace_math_ulp_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Ulp_D__D(d__0)).Ref() }
//line :351:1
func A_arbace_math_ulp__inliner__446000101_A_New() *A_arbace_math_ulp__inliner__446000101_A { A_arbace_math_ulp__inliner__446000101_A_Init(); t := &A_arbace_math_ulp__inliner__446000101_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_75; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_76; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__0)))))) }












func A_arbace_math_signum_A_New() *A_arbace_math_signum_A { A_arbace_math_signum_A_Init(); t := &A_arbace_math_signum_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Signum_D__D(d__0)).Ref() }
//line :364:1
func A_arbace_math_signum__inliner__446000104_A_New() *A_arbace_math_signum__inliner__446000104_A { A_arbace_math_signum__inliner__446000104_A_Init(); t := &A_arbace_math_signum__inliner__446000104_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_77; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_78; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__0)))))) }









func A_arbace_math_sinh_A_New() *A_arbace_math_sinh_A { A_arbace_math_sinh_A_Init(); t := &A_arbace_math_sinh_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D(p_x__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Sinh_D__D(x__0)).Ref() }
//line :374:1
func A_arbace_math_sinh__inliner__446000107_A_New() *A_arbace_math_sinh__inliner__446000107_A { A_arbace_math_sinh__inliner__446000107_A_Init(); t := &A_arbace_math_sinh__inliner__446000107_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_79; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_80; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))))) }










func A_arbace_math_cosh_A_New() *A_arbace_math_cosh_A { A_arbace_math_cosh_A_Init(); t := &A_arbace_math_cosh_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D(p_x__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Cosh_D__D(x__0)).Ref() }
//line :385:1
func A_arbace_math_cosh__inliner__446000110_A_New() *A_arbace_math_cosh__inliner__446000110_A { A_arbace_math_cosh__inliner__446000110_A_Init(); t := &A_arbace_math_cosh__inliner__446000110_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_81; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_82; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))))) }











func A_arbace_math_tanh_A_New() *A_arbace_math_tanh_A { A_arbace_math_tanh_A_Init(); t := &A_arbace_math_tanh_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D(p_x__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Tanh_D__D(x__0)).Ref() }
//line :397:1
func A_arbace_math_tanh__inliner__446000113_A_New() *A_arbace_math_tanh__inliner__446000113_A { A_arbace_math_tanh__inliner__446000113_A_Init(); t := &A_arbace_math_tanh__inliner__446000113_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_83; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_84; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))))) }












func A_arbace_math_hypot_A_New() *A_arbace_math_hypot_A { A_arbace_math_hypot_A_Init(); t := &A_arbace_math_hypot_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D(p_x__0); var y__1 float64 = lang.RT_DoubleCast_O__D(p_y__1); return jrt.Double_ValueOf_D__Double(jrt.Math_Hypot_D_D__D(x__0, y__1)).Ref() }
//line :410:1
func A_arbace_math_hypot__inliner__446000116_A_New() *A_arbace_math_hypot__inliner__446000116_A { A_arbace_math_hypot__inliner__446000116_A_Init(); t := &A_arbace_math_hypot__inliner__446000116_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_85; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_86; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_87; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(y__1)))))) }










func A_arbace_math_expm1_A_New() *A_arbace_math_expm1_A { A_arbace_math_expm1_A_Init(); t := &A_arbace_math_expm1_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D(p_x__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Expm1_D__D(x__0)).Ref() }
//line :421:1
func A_arbace_math_expm1__inliner__446000119_A_New() *A_arbace_math_expm1__inliner__446000119_A { A_arbace_math_expm1__inliner__446000119_A_Init(); t := &A_arbace_math_expm1__inliner__446000119_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_88; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_89; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))))) }












func A_arbace_math_log1p_A_New() *A_arbace_math_log1p_A { A_arbace_math_log1p_A_Init(); t := &A_arbace_math_log1p_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D(p_x__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Log1p_D__D(x__0)).Ref() }
//line :434:1
func A_arbace_math_log1p__inliner__446000122_A_New() *A_arbace_math_log1p__inliner__446000122_A { A_arbace_math_log1p__inliner__446000122_A_Init(); t := &A_arbace_math_log1p__inliner__446000122_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_90; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_91; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(x__0)))))) }













func A_arbace_math_copy_sign_A_New() *A_arbace_math_copy_sign_A { A_arbace_math_copy_sign_A_Init(); t := &A_arbace_math_copy_sign_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign_A) Invoke_O_O_O__O(self, p_magnitude__0, p_sign__1 any) any { var magnitude__0 float64 = lang.RT_DoubleCast_O__D(p_magnitude__0); var sign__1 float64 = lang.RT_DoubleCast_O__D(p_sign__1); return jrt.Double_ValueOf_D__Double(jrt.Math_CopySign_D_D__D(magnitude__0, sign__1)).Ref() }
//line :448:1
func A_arbace_math_copy_sign__inliner__446000125_A_New() *A_arbace_math_copy_sign__inliner__446000125_A { A_arbace_math_copy_sign__inliner__446000125_A_Init(); t := &A_arbace_math_copy_sign__inliner__446000125_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Invoke_O_O_O__O(self, magnitude__0, sign__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_92; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_93; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(magnitude__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_94; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(sign__1)))))) }









func A_arbace_math_get_exponent_A_New() *A_arbace_math_get_exponent_A { A_arbace_math_get_exponent_A_Init(); t := &A_arbace_math_get_exponent_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); return /*line :467:1*/ jrt.Integer_ValueOf_I__Integer(jrt.Math_GetExponent_D__I(d__0)).Ref() }
//line :458:1
func A_arbace_math_get_exponent__inliner__446000128_A_New() *A_arbace_math_get_exponent__inliner__446000128_A { A_arbace_math_get_exponent__inliner__446000128_A_Init(); t := &A_arbace_math_get_exponent__inliner__446000128_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_95; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_96; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__0)))))) }










func A_arbace_math_next_after_A_New() *A_arbace_math_next_after_A { A_arbace_math_next_after_A_Init(); t := &A_arbace_math_next_after_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after_A) Invoke_O_O_O__O(self, p_start__0, p_direction__1 any) any { var start__0 float64 = lang.RT_DoubleCast_O__D(p_start__0); var direction__1 float64 = lang.RT_DoubleCast_O__D(p_direction__1); return jrt.Double_ValueOf_D__Double(jrt.Math_NextAfter_D_D__D(start__0, direction__1)).Ref() }
//line :469:1
func A_arbace_math_next_after__inliner__446000131_A_New() *A_arbace_math_next_after__inliner__446000131_A { A_arbace_math_next_after__inliner__446000131_A_Init(); t := &A_arbace_math_next_after__inliner__446000131_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Invoke_O_O_O__O(self, start__0, direction__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_97; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_98; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(start__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_99; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(direction__1)))))) }

















func A_arbace_math_next_up_A_New() *A_arbace_math_next_up_A { A_arbace_math_next_up_A_Init(); t := &A_arbace_math_next_up_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); return jrt.Double_ValueOf_D__Double(jrt.Math_NextUp_D__D(d__0)).Ref() }
//line :487:1
func A_arbace_math_next_up__inliner__446000134_A_New() *A_arbace_math_next_up__inliner__446000134_A { A_arbace_math_next_up__inliner__446000134_A_Init(); t := &A_arbace_math_next_up__inliner__446000134_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_100; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_101; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__0)))))) }











func A_arbace_math_next_down_A_New() *A_arbace_math_next_down_A { A_arbace_math_next_down_A_Init(); t := &A_arbace_math_next_down_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); return jrt.Double_ValueOf_D__Double(jrt.Math_NextDown_D__D(d__0)).Ref() }
//line :499:1
func A_arbace_math_next_down__inliner__446000137_A_New() *A_arbace_math_next_down__inliner__446000137_A { A_arbace_math_next_down__inliner__446000137_A_Init(); t := &A_arbace_math_next_down__inliner__446000137_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_102; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_103; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__0)))))) }











func A_arbace_math_scalb_A_New() *A_arbace_math_scalb_A { A_arbace_math_scalb_A_Init(); t := &A_arbace_math_scalb_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb_A) Invoke_O_O_O__O(self, p_d__0, scaleFactor__1 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D(p_d__0); return jrt.Double_ValueOf_D__Double(jrt.Math_Scalb_D_I__D(d__0, lang.RT_IntCast_O__I(scaleFactor__1))).Ref() }
//line :511:1
func A_arbace_math_scalb__inliner__446000140_A_New() *A_arbace_math_scalb__inliner__446000140_A { A_arbace_math_scalb__inliner__446000140_A_Init(); t := &A_arbace_math_scalb__inliner__446000140_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Invoke_O_O_O__O(self, d__0, scaleFactor__1 any) any { var tmp1 *lang.Var; A_arbace_math_A_Init(); tmp1 = A_arbace_math_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_math_A_Init(); tmp3 = A_arbace_math_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_math_A_Init(); tmp5 = A_arbace_math_A_const_9; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_math_A_Init(); tmp7 = A_arbace_math_A_const_104; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_math_A_Init(); tmp9 = A_arbace_math_A_const_9; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_math_A_Init(); tmp11 = A_arbace_math_A_const_7; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_math_A_Init(); tmp13 = A_arbace_math_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_math_A_Init(); tmp15 = A_arbace_math_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_math_A_Init(); tmp17 = A_arbace_math_A_const_105; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_math_A_Init(); tmp19 = A_arbace_math_A_const_9; var tmp20 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(d__0)))); var tmp21 *lang.Var; A_arbace_math_A_Init(); tmp21 = A_arbace_math_A_const_9; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_math_A_Init(); tmp23 = A_arbace_math_A_const_7; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_math_A_Init(); tmp25 = A_arbace_math_A_const_8; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_math_A_Init(); tmp27 = A_arbace_math_A_const_9; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_math_A_Init(); tmp29 = A_arbace_math_A_const_106; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_math_A_Init(); tmp31 = A_arbace_math_A_const_9; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp20, tmp22.Invoke_O__O(tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(scaleFactor__1)))))) }















































type A_arbace_math_A struct{ jrt.Object }

var A_arbace_math_A_const_0 *lang.Var

var A_arbace_math_A_const_1 any

var A_arbace_math_A_const_2 *lang.Var

var A_arbace_math_A_const_3 *lang.Var

var A_arbace_math_A_const_4 *lang.Var

var A_arbace_math_A_const_5 any

var A_arbace_math_A_const_6 *lang.Var

var A_arbace_math_A_const_7 *lang.Var

var A_arbace_math_A_const_8 *lang.Var

var A_arbace_math_A_const_9 *lang.Var

var A_arbace_math_A_const_10 any

var A_arbace_math_A_const_11 any

var A_arbace_math_A_const_12 any

var A_arbace_math_A_const_13 any

var A_arbace_math_A_const_14 any

var A_arbace_math_A_const_15 any

var A_arbace_math_A_const_16 any

var A_arbace_math_A_const_17 any

var A_arbace_math_A_const_18 any

var A_arbace_math_A_const_19 any

var A_arbace_math_A_const_20 any

var A_arbace_math_A_const_21 any

var A_arbace_math_A_const_22 any

var A_arbace_math_A_const_23 any

var A_arbace_math_A_const_24 any

var A_arbace_math_A_const_25 any

var A_arbace_math_A_const_26 any

var A_arbace_math_A_const_27 any

var A_arbace_math_A_const_28 any

var A_arbace_math_A_const_29 any

var A_arbace_math_A_const_30 any

var A_arbace_math_A_const_31 any

var A_arbace_math_A_const_32 any

var A_arbace_math_A_const_33 any

var A_arbace_math_A_const_34 any

var A_arbace_math_A_const_35 any

var A_arbace_math_A_const_36 any

var A_arbace_math_A_const_37 any

var A_arbace_math_A_const_38 any

var A_arbace_math_A_const_39 any

var A_arbace_math_A_const_40 any

var A_arbace_math_A_const_41 any

var A_arbace_math_A_const_42 any

var A_arbace_math_A_const_43 any

var A_arbace_math_A_const_44 any

var A_arbace_math_A_const_45 any

var A_arbace_math_A_const_46 any

var A_arbace_math_A_const_47 any

var A_arbace_math_A_const_48 any

var A_arbace_math_A_const_49 any

var A_arbace_math_A_const_50 any

var A_arbace_math_A_const_51 any

var A_arbace_math_A_const_52 any

var A_arbace_math_A_const_53 any

var A_arbace_math_A_const_54 any

var A_arbace_math_A_const_55 any

var A_arbace_math_A_const_56 any

var A_arbace_math_A_const_57 any

var A_arbace_math_A_const_58 any

var A_arbace_math_A_const_59 any

var A_arbace_math_A_const_60 any

var A_arbace_math_A_const_61 any

var A_arbace_math_A_const_62 any

var A_arbace_math_A_const_63 any

var A_arbace_math_A_const_64 any

var A_arbace_math_A_const_65 any

var A_arbace_math_A_const_66 any

var A_arbace_math_A_const_67 any

var A_arbace_math_A_const_68 any

var A_arbace_math_A_const_69 any

var A_arbace_math_A_const_70 any

var A_arbace_math_A_const_71 any

var A_arbace_math_A_const_72 any

var A_arbace_math_A_const_73 any

var A_arbace_math_A_const_74 any

var A_arbace_math_A_const_75 any

var A_arbace_math_A_const_76 any

var A_arbace_math_A_const_77 any

var A_arbace_math_A_const_78 any

var A_arbace_math_A_const_79 any

var A_arbace_math_A_const_80 any

var A_arbace_math_A_const_81 any

var A_arbace_math_A_const_82 any

var A_arbace_math_A_const_83 any

var A_arbace_math_A_const_84 any

var A_arbace_math_A_const_85 any

var A_arbace_math_A_const_86 any

var A_arbace_math_A_const_87 any

var A_arbace_math_A_const_88 any

var A_arbace_math_A_const_89 any

var A_arbace_math_A_const_90 any

var A_arbace_math_A_const_91 any

var A_arbace_math_A_const_92 any

var A_arbace_math_A_const_93 any

var A_arbace_math_A_const_94 any

var A_arbace_math_A_const_95 any

var A_arbace_math_A_const_96 any

var A_arbace_math_A_const_97 any

var A_arbace_math_A_const_98 any

var A_arbace_math_A_const_99 any

var A_arbace_math_A_const_100 any

var A_arbace_math_A_const_101 any

var A_arbace_math_A_const_102 any

var A_arbace_math_A_const_103 any

var A_arbace_math_A_const_104 any

var A_arbace_math_A_const_105 any

var A_arbace_math_A_const_106 any

var A_arbace_math_A_init jrt.ClassInit

func A_arbace_math_A_Init() { if !A_arbace_math_A_init.Done() { A_arbace_math_A_init.Run(A_arbace_math_A_clinit) } }

func A_arbace_math_A_clinit() { A_arbace_math_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_math_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_math_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_math_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_math_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_math_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_math_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_math_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_math_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_math_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_math_A_const_10 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_15).Ref(); A_arbace_math_A_const_11 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_12 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_17).Ref(); A_arbace_math_A_const_13 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_14 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_18).Ref(); A_arbace_math_A_const_15 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_16 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_19).Ref(); A_arbace_math_A_const_17 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_18 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_20).Ref(); A_arbace_math_A_const_19 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_20 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_21).Ref(); A_arbace_math_A_const_21 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_22 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_22).Ref(); A_arbace_math_A_const_23 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_24 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_23).Ref(); A_arbace_math_A_const_25 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_26 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_24).Ref(); A_arbace_math_A_const_27 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_28 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_25).Ref(); A_arbace_math_A_const_29 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_30 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_26).Ref(); A_arbace_math_A_const_31 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_32 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_27).Ref(); A_arbace_math_A_const_33 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_34 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_28).Ref(); A_arbace_math_A_const_35 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_36 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_29).Ref(); A_arbace_math_A_const_37 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_38 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_39 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_30).Ref(); A_arbace_math_A_const_40 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_41 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_31).Ref(); A_arbace_math_A_const_42 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_43 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_32).Ref(); A_arbace_math_A_const_44 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_45 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_33).Ref(); A_arbace_math_A_const_46 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_47 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_48 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_34).Ref(); A_arbace_math_A_const_49 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_50 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_51 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_35).Ref(); A_arbace_math_A_const_52 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_53 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_36).Ref(); A_arbace_math_A_const_54 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_37).Ref(); A_arbace_math_A_const_55 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_56 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_57 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_39).Ref(); A_arbace_math_A_const_58 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_59 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_60 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_40).Ref(); A_arbace_math_A_const_61 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_62 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_63 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_41).Ref(); A_arbace_math_A_const_64 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_65 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_42).Ref(); A_arbace_math_A_const_66 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_67 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_43).Ref(); A_arbace_math_A_const_68 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_69 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_44).Ref(); A_arbace_math_A_const_70 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_71 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_72 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_45).Ref(); A_arbace_math_A_const_73 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_74 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_math_A_const_75 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_46).Ref(); A_arbace_math_A_const_76 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_77 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_47).Ref(); A_arbace_math_A_const_78 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_79 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_48).Ref(); A_arbace_math_A_const_80 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_81 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_49).Ref(); A_arbace_math_A_const_82 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_83 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_50).Ref(); A_arbace_math_A_const_84 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_85 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_51).Ref(); A_arbace_math_A_const_86 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_87 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_88 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_52).Ref(); A_arbace_math_A_const_89 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_90 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_53).Ref(); A_arbace_math_A_const_91 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_92 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_54).Ref(); A_arbace_math_A_const_93 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_94 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_95 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_55).Ref(); A_arbace_math_A_const_96 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_97 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_56).Ref(); A_arbace_math_A_const_98 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_99 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_100 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_57).Ref(); A_arbace_math_A_const_101 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_102 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_58).Ref(); A_arbace_math_A_const_103 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_104 = lang.Symbol_Intern_String_String__Symbol(Lit_14, Lit_59).Ref(); A_arbace_math_A_const_105 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_16).Ref(); A_arbace_math_A_const_106 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_60).Ref() }

func A_arbace_math_A_New() *A_arbace_math_A { A_arbace_math_A_Init(); t := &A_arbace_math_A{}; t.Ctor(); return t }

func (t *A_arbace_math_A) Ctor() {}

func (t *A_arbace_math_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_A) GetClass__Class() *jrt.Class { return A_arbace_math_A_class }

func (t *A_arbace_math_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_A); return ok }

func A_arbace_math_A_Cast(x any) *A_arbace_math_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_A_class)) }; return v }



type A_arbace_math_IEEE_remainder_A struct{ jrt.Object }

func (t *A_arbace_math_IEEE_remainder_A) Is_Compiler_AOTF2() {}

var A_arbace_math_IEEE_remainder_A_fn_class *jrt.Class

var A_arbace_math_IEEE_remainder_A_init jrt.ClassInit

func A_arbace_math_IEEE_remainder_A_Init() { if !A_arbace_math_IEEE_remainder_A_init.Done() { A_arbace_math_IEEE_remainder_A_init.Run(A_arbace_math_IEEE_remainder_A_clinit) } }

func A_arbace_math_IEEE_remainder_A_clinit() { A_arbace_math_IEEE_remainder_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_IEEE_remainder_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_IEEE_remainder_A) GetClass__Class() *jrt.Class { return A_arbace_math_IEEE_remainder_A_class }

func (t *A_arbace_math_IEEE_remainder_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_IEEE_remainder_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_IEEE_remainder_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_IEEE_remainder_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_IEEE_remainder_A); return ok }

func A_arbace_math_IEEE_remainder_A_Cast(x any) *A_arbace_math_IEEE_remainder_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_IEEE_remainder_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_IEEE_remainder_A_class)) }; return v }



type A_arbace_math_IEEE_remainder__inliner__446000053_A struct{ jrt.Object }

func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Is_Compiler_AOTF2() {}

var A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class *jrt.Class

var A_arbace_math_IEEE_remainder__inliner__446000053_A_init jrt.ClassInit

func A_arbace_math_IEEE_remainder__inliner__446000053_A_Init() { if !A_arbace_math_IEEE_remainder__inliner__446000053_A_init.Done() { A_arbace_math_IEEE_remainder__inliner__446000053_A_init.Run(A_arbace_math_IEEE_remainder__inliner__446000053_A_clinit) } }

func A_arbace_math_IEEE_remainder__inliner__446000053_A_clinit() { A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) GetClass__Class() *jrt.Class { return A_arbace_math_IEEE_remainder__inliner__446000053_A_class }

func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_IEEE_remainder__inliner__446000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_IEEE_remainder__inliner__446000053_A); return ok }

func A_arbace_math_IEEE_remainder__inliner__446000053_A_Cast(x any) *A_arbace_math_IEEE_remainder__inliner__446000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_IEEE_remainder__inliner__446000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_IEEE_remainder__inliner__446000053_A_class)) }; return v }



type A_arbace_math_acos_A struct{ jrt.Object }

func (t *A_arbace_math_acos_A) Is_Compiler_AOTF1() {}

var A_arbace_math_acos_A_fn_class *jrt.Class

var A_arbace_math_acos_A_init jrt.ClassInit

func A_arbace_math_acos_A_Init() { if !A_arbace_math_acos_A_init.Done() { A_arbace_math_acos_A_init.Run(A_arbace_math_acos_A_clinit) } }

func A_arbace_math_acos_A_clinit() { A_arbace_math_acos_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_acos_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_acos_A) GetClass__Class() *jrt.Class { return A_arbace_math_acos_A_class }

func (t *A_arbace_math_acos_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_acos_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_acos_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_acos_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_acos_A); return ok }

func A_arbace_math_acos_A_Cast(x any) *A_arbace_math_acos_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_acos_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_acos_A_class)) }; return v }



type A_arbace_math_acos__inliner__446000026_A struct{ jrt.Object }

func (t *A_arbace_math_acos__inliner__446000026_A) Is_Compiler_AOTF1() {}

var A_arbace_math_acos__inliner__446000026_A_fn_class *jrt.Class

var A_arbace_math_acos__inliner__446000026_A_init jrt.ClassInit

func A_arbace_math_acos__inliner__446000026_A_Init() { if !A_arbace_math_acos__inliner__446000026_A_init.Done() { A_arbace_math_acos__inliner__446000026_A_init.Run(A_arbace_math_acos__inliner__446000026_A_clinit) } }

func A_arbace_math_acos__inliner__446000026_A_clinit() { A_arbace_math_acos__inliner__446000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_acos__inliner__446000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_acos__inliner__446000026_A) GetClass__Class() *jrt.Class { return A_arbace_math_acos__inliner__446000026_A_class }

func (t *A_arbace_math_acos__inliner__446000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_acos__inliner__446000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_acos__inliner__446000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_acos__inliner__446000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_acos__inliner__446000026_A); return ok }

func A_arbace_math_acos__inliner__446000026_A_Cast(x any) *A_arbace_math_acos__inliner__446000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_acos__inliner__446000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_acos__inliner__446000026_A_class)) }; return v }



type A_arbace_math_add_exact_A struct{ jrt.Object }

func (t *A_arbace_math_add_exact_A) Is_Compiler_AOTF2() {}

var A_arbace_math_add_exact_A_fn_class *jrt.Class

var A_arbace_math_add_exact_A_init jrt.ClassInit

func A_arbace_math_add_exact_A_Init() { if !A_arbace_math_add_exact_A_init.Done() { A_arbace_math_add_exact_A_init.Run(A_arbace_math_add_exact_A_clinit) } }

func A_arbace_math_add_exact_A_clinit() { A_arbace_math_add_exact_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_add_exact_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_add_exact_A) GetClass__Class() *jrt.Class { return A_arbace_math_add_exact_A_class }

func (t *A_arbace_math_add_exact_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_add_exact_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_add_exact_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_add_exact_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_add_exact_A); return ok }

func A_arbace_math_add_exact_A_Cast(x any) *A_arbace_math_add_exact_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_add_exact_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_add_exact_A_class)) }; return v }



type A_arbace_math_add_exact__inliner__446000077_A struct{ jrt.Object }

func (t *A_arbace_math_add_exact__inliner__446000077_A) Is_Compiler_AOTF2() {}

var A_arbace_math_add_exact__inliner__446000077_A_fn_class *jrt.Class

var A_arbace_math_add_exact__inliner__446000077_A_init jrt.ClassInit

func A_arbace_math_add_exact__inliner__446000077_A_Init() { if !A_arbace_math_add_exact__inliner__446000077_A_init.Done() { A_arbace_math_add_exact__inliner__446000077_A_init.Run(A_arbace_math_add_exact__inliner__446000077_A_clinit) } }

func A_arbace_math_add_exact__inliner__446000077_A_clinit() { A_arbace_math_add_exact__inliner__446000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_add_exact__inliner__446000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_add_exact__inliner__446000077_A) GetClass__Class() *jrt.Class { return A_arbace_math_add_exact__inliner__446000077_A_class }

func (t *A_arbace_math_add_exact__inliner__446000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_add_exact__inliner__446000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_add_exact__inliner__446000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_add_exact__inliner__446000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_add_exact__inliner__446000077_A); return ok }

func A_arbace_math_add_exact__inliner__446000077_A_Cast(x any) *A_arbace_math_add_exact__inliner__446000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_add_exact__inliner__446000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_add_exact__inliner__446000077_A_class)) }; return v }



type A_arbace_math_asin_A struct{ jrt.Object }

func (t *A_arbace_math_asin_A) Is_Compiler_AOTF1() {}

var A_arbace_math_asin_A_fn_class *jrt.Class

var A_arbace_math_asin_A_init jrt.ClassInit

func A_arbace_math_asin_A_Init() { if !A_arbace_math_asin_A_init.Done() { A_arbace_math_asin_A_init.Run(A_arbace_math_asin_A_clinit) } }

func A_arbace_math_asin_A_clinit() { A_arbace_math_asin_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_asin_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_asin_A) GetClass__Class() *jrt.Class { return A_arbace_math_asin_A_class }

func (t *A_arbace_math_asin_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_asin_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_asin_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_asin_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_asin_A); return ok }

func A_arbace_math_asin_A_Cast(x any) *A_arbace_math_asin_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_asin_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_asin_A_class)) }; return v }



type A_arbace_math_asin__inliner__446000023_A struct{ jrt.Object }

func (t *A_arbace_math_asin__inliner__446000023_A) Is_Compiler_AOTF1() {}

var A_arbace_math_asin__inliner__446000023_A_fn_class *jrt.Class

var A_arbace_math_asin__inliner__446000023_A_init jrt.ClassInit

func A_arbace_math_asin__inliner__446000023_A_Init() { if !A_arbace_math_asin__inliner__446000023_A_init.Done() { A_arbace_math_asin__inliner__446000023_A_init.Run(A_arbace_math_asin__inliner__446000023_A_clinit) } }

func A_arbace_math_asin__inliner__446000023_A_clinit() { A_arbace_math_asin__inliner__446000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_asin__inliner__446000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_asin__inliner__446000023_A) GetClass__Class() *jrt.Class { return A_arbace_math_asin__inliner__446000023_A_class }

func (t *A_arbace_math_asin__inliner__446000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_asin__inliner__446000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_asin__inliner__446000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_asin__inliner__446000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_asin__inliner__446000023_A); return ok }

func A_arbace_math_asin__inliner__446000023_A_Cast(x any) *A_arbace_math_asin__inliner__446000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_asin__inliner__446000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_asin__inliner__446000023_A_class)) }; return v }



type A_arbace_math_atan_A struct{ jrt.Object }

func (t *A_arbace_math_atan_A) Is_Compiler_AOTF1() {}

var A_arbace_math_atan_A_fn_class *jrt.Class

var A_arbace_math_atan_A_init jrt.ClassInit

func A_arbace_math_atan_A_Init() { if !A_arbace_math_atan_A_init.Done() { A_arbace_math_atan_A_init.Run(A_arbace_math_atan_A_clinit) } }

func A_arbace_math_atan_A_clinit() { A_arbace_math_atan_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_atan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_atan_A) GetClass__Class() *jrt.Class { return A_arbace_math_atan_A_class }

func (t *A_arbace_math_atan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_atan_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_atan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_atan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_atan_A); return ok }

func A_arbace_math_atan_A_Cast(x any) *A_arbace_math_atan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_atan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_atan_A_class)) }; return v }



type A_arbace_math_atan2_A struct{ jrt.Object }

func (t *A_arbace_math_atan2_A) Is_Compiler_AOTF2() {}

var A_arbace_math_atan2_A_fn_class *jrt.Class

var A_arbace_math_atan2_A_init jrt.ClassInit

func A_arbace_math_atan2_A_Init() { if !A_arbace_math_atan2_A_init.Done() { A_arbace_math_atan2_A_init.Run(A_arbace_math_atan2_A_clinit) } }

func A_arbace_math_atan2_A_clinit() { A_arbace_math_atan2_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_atan2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_atan2_A) GetClass__Class() *jrt.Class { return A_arbace_math_atan2_A_class }

func (t *A_arbace_math_atan2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_atan2_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_atan2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_atan2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_atan2_A); return ok }

func A_arbace_math_atan2_A_Cast(x any) *A_arbace_math_atan2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_atan2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_atan2_A_class)) }; return v }



type A_arbace_math_atan2__inliner__446000065_A struct{ jrt.Object }

func (t *A_arbace_math_atan2__inliner__446000065_A) Is_Compiler_AOTF2() {}

var A_arbace_math_atan2__inliner__446000065_A_fn_class *jrt.Class

var A_arbace_math_atan2__inliner__446000065_A_init jrt.ClassInit

func A_arbace_math_atan2__inliner__446000065_A_Init() { if !A_arbace_math_atan2__inliner__446000065_A_init.Done() { A_arbace_math_atan2__inliner__446000065_A_init.Run(A_arbace_math_atan2__inliner__446000065_A_clinit) } }

func A_arbace_math_atan2__inliner__446000065_A_clinit() { A_arbace_math_atan2__inliner__446000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_atan2__inliner__446000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_atan2__inliner__446000065_A) GetClass__Class() *jrt.Class { return A_arbace_math_atan2__inliner__446000065_A_class }

func (t *A_arbace_math_atan2__inliner__446000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_atan2__inliner__446000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_atan2__inliner__446000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_atan2__inliner__446000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_atan2__inliner__446000065_A); return ok }

func A_arbace_math_atan2__inliner__446000065_A_Cast(x any) *A_arbace_math_atan2__inliner__446000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_atan2__inliner__446000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_atan2__inliner__446000065_A_class)) }; return v }



type A_arbace_math_atan__inliner__446000029_A struct{ jrt.Object }

func (t *A_arbace_math_atan__inliner__446000029_A) Is_Compiler_AOTF1() {}

var A_arbace_math_atan__inliner__446000029_A_fn_class *jrt.Class

var A_arbace_math_atan__inliner__446000029_A_init jrt.ClassInit

func A_arbace_math_atan__inliner__446000029_A_Init() { if !A_arbace_math_atan__inliner__446000029_A_init.Done() { A_arbace_math_atan__inliner__446000029_A_init.Run(A_arbace_math_atan__inliner__446000029_A_clinit) } }

func A_arbace_math_atan__inliner__446000029_A_clinit() { A_arbace_math_atan__inliner__446000029_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_atan__inliner__446000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_atan__inliner__446000029_A) GetClass__Class() *jrt.Class { return A_arbace_math_atan__inliner__446000029_A_class }

func (t *A_arbace_math_atan__inliner__446000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_atan__inliner__446000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_atan__inliner__446000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_atan__inliner__446000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_atan__inliner__446000029_A); return ok }

func A_arbace_math_atan__inliner__446000029_A_Cast(x any) *A_arbace_math_atan__inliner__446000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_atan__inliner__446000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_atan__inliner__446000029_A_class)) }; return v }



type A_arbace_math_cbrt_A struct{ jrt.Object }

func (t *A_arbace_math_cbrt_A) Is_Compiler_AOTF1() {}

var A_arbace_math_cbrt_A_fn_class *jrt.Class

var A_arbace_math_cbrt_A_init jrt.ClassInit

func A_arbace_math_cbrt_A_Init() { if !A_arbace_math_cbrt_A_init.Done() { A_arbace_math_cbrt_A_init.Run(A_arbace_math_cbrt_A_clinit) } }

func A_arbace_math_cbrt_A_clinit() { A_arbace_math_cbrt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_cbrt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_cbrt_A) GetClass__Class() *jrt.Class { return A_arbace_math_cbrt_A_class }

func (t *A_arbace_math_cbrt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_cbrt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_cbrt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_cbrt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_cbrt_A); return ok }

func A_arbace_math_cbrt_A_Cast(x any) *A_arbace_math_cbrt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_cbrt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_cbrt_A_class)) }; return v }



type A_arbace_math_cbrt__inliner__446000050_A struct{ jrt.Object }

func (t *A_arbace_math_cbrt__inliner__446000050_A) Is_Compiler_AOTF1() {}

var A_arbace_math_cbrt__inliner__446000050_A_fn_class *jrt.Class

var A_arbace_math_cbrt__inliner__446000050_A_init jrt.ClassInit

func A_arbace_math_cbrt__inliner__446000050_A_Init() { if !A_arbace_math_cbrt__inliner__446000050_A_init.Done() { A_arbace_math_cbrt__inliner__446000050_A_init.Run(A_arbace_math_cbrt__inliner__446000050_A_clinit) } }

func A_arbace_math_cbrt__inliner__446000050_A_clinit() { A_arbace_math_cbrt__inliner__446000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_cbrt__inliner__446000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_cbrt__inliner__446000050_A) GetClass__Class() *jrt.Class { return A_arbace_math_cbrt__inliner__446000050_A_class }

func (t *A_arbace_math_cbrt__inliner__446000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_cbrt__inliner__446000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_cbrt__inliner__446000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_cbrt__inliner__446000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_cbrt__inliner__446000050_A); return ok }

func A_arbace_math_cbrt__inliner__446000050_A_Cast(x any) *A_arbace_math_cbrt__inliner__446000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_cbrt__inliner__446000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_cbrt__inliner__446000050_A_class)) }; return v }



type A_arbace_math_ceil_A struct{ jrt.Object }

func (t *A_arbace_math_ceil_A) Is_Compiler_AOTF1() {}

var A_arbace_math_ceil_A_fn_class *jrt.Class

var A_arbace_math_ceil_A_init jrt.ClassInit

func A_arbace_math_ceil_A_Init() { if !A_arbace_math_ceil_A_init.Done() { A_arbace_math_ceil_A_init.Run(A_arbace_math_ceil_A_clinit) } }

func A_arbace_math_ceil_A_clinit() { A_arbace_math_ceil_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_ceil_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_ceil_A) GetClass__Class() *jrt.Class { return A_arbace_math_ceil_A_class }

func (t *A_arbace_math_ceil_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_ceil_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_ceil_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_ceil_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_ceil_A); return ok }

func A_arbace_math_ceil_A_Cast(x any) *A_arbace_math_ceil_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_ceil_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_ceil_A_class)) }; return v }



type A_arbace_math_ceil__inliner__446000056_A struct{ jrt.Object }

func (t *A_arbace_math_ceil__inliner__446000056_A) Is_Compiler_AOTF1() {}

var A_arbace_math_ceil__inliner__446000056_A_fn_class *jrt.Class

var A_arbace_math_ceil__inliner__446000056_A_init jrt.ClassInit

func A_arbace_math_ceil__inliner__446000056_A_Init() { if !A_arbace_math_ceil__inliner__446000056_A_init.Done() { A_arbace_math_ceil__inliner__446000056_A_init.Run(A_arbace_math_ceil__inliner__446000056_A_clinit) } }

func A_arbace_math_ceil__inliner__446000056_A_clinit() { A_arbace_math_ceil__inliner__446000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_ceil__inliner__446000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_ceil__inliner__446000056_A) GetClass__Class() *jrt.Class { return A_arbace_math_ceil__inliner__446000056_A_class }

func (t *A_arbace_math_ceil__inliner__446000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_ceil__inliner__446000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_ceil__inliner__446000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_ceil__inliner__446000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_ceil__inliner__446000056_A); return ok }

func A_arbace_math_ceil__inliner__446000056_A_Cast(x any) *A_arbace_math_ceil__inliner__446000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_ceil__inliner__446000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_ceil__inliner__446000056_A_class)) }; return v }



type A_arbace_math_copy_sign_A struct{ jrt.Object }

func (t *A_arbace_math_copy_sign_A) Is_Compiler_AOTF2() {}

var A_arbace_math_copy_sign_A_fn_class *jrt.Class

var A_arbace_math_copy_sign_A_init jrt.ClassInit

func A_arbace_math_copy_sign_A_Init() { if !A_arbace_math_copy_sign_A_init.Done() { A_arbace_math_copy_sign_A_init.Run(A_arbace_math_copy_sign_A_clinit) } }

func A_arbace_math_copy_sign_A_clinit() { A_arbace_math_copy_sign_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_copy_sign_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_copy_sign_A) GetClass__Class() *jrt.Class { return A_arbace_math_copy_sign_A_class }

func (t *A_arbace_math_copy_sign_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_copy_sign_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_copy_sign_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_copy_sign_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_copy_sign_A); return ok }

func A_arbace_math_copy_sign_A_Cast(x any) *A_arbace_math_copy_sign_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_copy_sign_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_copy_sign_A_class)) }; return v }



type A_arbace_math_copy_sign__inliner__446000125_A struct{ jrt.Object }

func (t *A_arbace_math_copy_sign__inliner__446000125_A) Is_Compiler_AOTF2() {}

var A_arbace_math_copy_sign__inliner__446000125_A_fn_class *jrt.Class

var A_arbace_math_copy_sign__inliner__446000125_A_init jrt.ClassInit

func A_arbace_math_copy_sign__inliner__446000125_A_Init() { if !A_arbace_math_copy_sign__inliner__446000125_A_init.Done() { A_arbace_math_copy_sign__inliner__446000125_A_init.Run(A_arbace_math_copy_sign__inliner__446000125_A_clinit) } }

func A_arbace_math_copy_sign__inliner__446000125_A_clinit() { A_arbace_math_copy_sign__inliner__446000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_copy_sign__inliner__446000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_copy_sign__inliner__446000125_A) GetClass__Class() *jrt.Class { return A_arbace_math_copy_sign__inliner__446000125_A_class }

func (t *A_arbace_math_copy_sign__inliner__446000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_copy_sign__inliner__446000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_copy_sign__inliner__446000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_copy_sign__inliner__446000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_copy_sign__inliner__446000125_A); return ok }

func A_arbace_math_copy_sign__inliner__446000125_A_Cast(x any) *A_arbace_math_copy_sign__inliner__446000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_copy_sign__inliner__446000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_copy_sign__inliner__446000125_A_class)) }; return v }



type A_arbace_math_cos_A struct{ jrt.Object }

func (t *A_arbace_math_cos_A) Is_Compiler_AOTF1() {}

var A_arbace_math_cos_A_fn_class *jrt.Class

var A_arbace_math_cos_A_init jrt.ClassInit

func A_arbace_math_cos_A_Init() { if !A_arbace_math_cos_A_init.Done() { A_arbace_math_cos_A_init.Run(A_arbace_math_cos_A_clinit) } }

func A_arbace_math_cos_A_clinit() { A_arbace_math_cos_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_cos_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_cos_A) GetClass__Class() *jrt.Class { return A_arbace_math_cos_A_class }

func (t *A_arbace_math_cos_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_cos_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_cos_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_cos_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_cos_A); return ok }

func A_arbace_math_cos_A_Cast(x any) *A_arbace_math_cos_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_cos_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_cos_A_class)) }; return v }



type A_arbace_math_cos__inliner__446000017_A struct{ jrt.Object }

func (t *A_arbace_math_cos__inliner__446000017_A) Is_Compiler_AOTF1() {}

var A_arbace_math_cos__inliner__446000017_A_fn_class *jrt.Class

var A_arbace_math_cos__inliner__446000017_A_init jrt.ClassInit

func A_arbace_math_cos__inliner__446000017_A_Init() { if !A_arbace_math_cos__inliner__446000017_A_init.Done() { A_arbace_math_cos__inliner__446000017_A_init.Run(A_arbace_math_cos__inliner__446000017_A_clinit) } }

func A_arbace_math_cos__inliner__446000017_A_clinit() { A_arbace_math_cos__inliner__446000017_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_cos__inliner__446000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_cos__inliner__446000017_A) GetClass__Class() *jrt.Class { return A_arbace_math_cos__inliner__446000017_A_class }

func (t *A_arbace_math_cos__inliner__446000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_cos__inliner__446000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_cos__inliner__446000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_cos__inliner__446000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_cos__inliner__446000017_A); return ok }

func A_arbace_math_cos__inliner__446000017_A_Cast(x any) *A_arbace_math_cos__inliner__446000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_cos__inliner__446000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_cos__inliner__446000017_A_class)) }; return v }



type A_arbace_math_cosh_A struct{ jrt.Object }

func (t *A_arbace_math_cosh_A) Is_Compiler_AOTF1() {}

var A_arbace_math_cosh_A_fn_class *jrt.Class

var A_arbace_math_cosh_A_init jrt.ClassInit

func A_arbace_math_cosh_A_Init() { if !A_arbace_math_cosh_A_init.Done() { A_arbace_math_cosh_A_init.Run(A_arbace_math_cosh_A_clinit) } }

func A_arbace_math_cosh_A_clinit() { A_arbace_math_cosh_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_cosh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_cosh_A) GetClass__Class() *jrt.Class { return A_arbace_math_cosh_A_class }

func (t *A_arbace_math_cosh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_cosh_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_cosh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_cosh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_cosh_A); return ok }

func A_arbace_math_cosh_A_Cast(x any) *A_arbace_math_cosh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_cosh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_cosh_A_class)) }; return v }



type A_arbace_math_cosh__inliner__446000110_A struct{ jrt.Object }

func (t *A_arbace_math_cosh__inliner__446000110_A) Is_Compiler_AOTF1() {}

var A_arbace_math_cosh__inliner__446000110_A_fn_class *jrt.Class

var A_arbace_math_cosh__inliner__446000110_A_init jrt.ClassInit

func A_arbace_math_cosh__inliner__446000110_A_Init() { if !A_arbace_math_cosh__inliner__446000110_A_init.Done() { A_arbace_math_cosh__inliner__446000110_A_init.Run(A_arbace_math_cosh__inliner__446000110_A_clinit) } }

func A_arbace_math_cosh__inliner__446000110_A_clinit() { A_arbace_math_cosh__inliner__446000110_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_cosh__inliner__446000110_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_cosh__inliner__446000110_A) GetClass__Class() *jrt.Class { return A_arbace_math_cosh__inliner__446000110_A_class }

func (t *A_arbace_math_cosh__inliner__446000110_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_cosh__inliner__446000110_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_cosh__inliner__446000110_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_cosh__inliner__446000110_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_cosh__inliner__446000110_A); return ok }

func A_arbace_math_cosh__inliner__446000110_A_Cast(x any) *A_arbace_math_cosh__inliner__446000110_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_cosh__inliner__446000110_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_cosh__inliner__446000110_A_class)) }; return v }



type A_arbace_math_decrement_exact_A struct{ jrt.Object }

func (t *A_arbace_math_decrement_exact_A) Is_Compiler_AOTF1() {}

var A_arbace_math_decrement_exact_A_fn_class *jrt.Class

var A_arbace_math_decrement_exact_A_init jrt.ClassInit

func A_arbace_math_decrement_exact_A_Init() { if !A_arbace_math_decrement_exact_A_init.Done() { A_arbace_math_decrement_exact_A_init.Run(A_arbace_math_decrement_exact_A_clinit) } }

func A_arbace_math_decrement_exact_A_clinit() { A_arbace_math_decrement_exact_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_decrement_exact_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_decrement_exact_A) GetClass__Class() *jrt.Class { return A_arbace_math_decrement_exact_A_class }

func (t *A_arbace_math_decrement_exact_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_decrement_exact_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_decrement_exact_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_decrement_exact_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_decrement_exact_A); return ok }

func A_arbace_math_decrement_exact_A_Cast(x any) *A_arbace_math_decrement_exact_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_decrement_exact_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_decrement_exact_A_class)) }; return v }



type A_arbace_math_decrement_exact__inliner__446000089_A struct{ jrt.Object }

func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Is_Compiler_AOTF1() {}

var A_arbace_math_decrement_exact__inliner__446000089_A_fn_class *jrt.Class

var A_arbace_math_decrement_exact__inliner__446000089_A_init jrt.ClassInit

func A_arbace_math_decrement_exact__inliner__446000089_A_Init() { if !A_arbace_math_decrement_exact__inliner__446000089_A_init.Done() { A_arbace_math_decrement_exact__inliner__446000089_A_init.Run(A_arbace_math_decrement_exact__inliner__446000089_A_clinit) } }

func A_arbace_math_decrement_exact__inliner__446000089_A_clinit() { A_arbace_math_decrement_exact__inliner__446000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_decrement_exact__inliner__446000089_A) GetClass__Class() *jrt.Class { return A_arbace_math_decrement_exact__inliner__446000089_A_class }

func (t *A_arbace_math_decrement_exact__inliner__446000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_decrement_exact__inliner__446000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_decrement_exact__inliner__446000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_decrement_exact__inliner__446000089_A); return ok }

func A_arbace_math_decrement_exact__inliner__446000089_A_Cast(x any) *A_arbace_math_decrement_exact__inliner__446000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_decrement_exact__inliner__446000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_decrement_exact__inliner__446000089_A_class)) }; return v }



type A_arbace_math_eval446000004_A struct{ jrt.Object }

func A_arbace_math_eval446000004_A_New() *A_arbace_math_eval446000004_A { t := &A_arbace_math_eval446000004_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000004_A) Ctor() {}

func (t *A_arbace_math_eval446000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000004_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000004_A_class }

func (t *A_arbace_math_eval446000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000004_A); return ok }

func A_arbace_math_eval446000004_A_Cast(x any) *A_arbace_math_eval446000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000004_A_class)) }; return v }



type A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A struct{ jrt.Object }

func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Is_Compiler_AOTF0() {}

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class *jrt.Class

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_init jrt.ClassInit

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_Init() { if !A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_init.Done() { A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_init.Run(A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_clinit) } }

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_clinit() { A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_class }

func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A); return ok }

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_Cast(x any) *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_class)) }; return v }



type A_arbace_math_eval446000008_A struct{ jrt.Object }

func A_arbace_math_eval446000008_A_New() *A_arbace_math_eval446000008_A { t := &A_arbace_math_eval446000008_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000008_A) Ctor() {}

func (t *A_arbace_math_eval446000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000008_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000008_A_class }

func (t *A_arbace_math_eval446000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000008_A); return ok }

func A_arbace_math_eval446000008_A_Cast(x any) *A_arbace_math_eval446000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000008_A_class)) }; return v }



type A_arbace_math_eval446000008_fn__446000009_A struct{ jrt.Object }

func (t *A_arbace_math_eval446000008_fn__446000009_A) Is_Compiler_AOTF0() {}

var A_arbace_math_eval446000008_fn__446000009_A_fn_class *jrt.Class

var A_arbace_math_eval446000008_fn__446000009_A_init jrt.ClassInit

func A_arbace_math_eval446000008_fn__446000009_A_Init() { if !A_arbace_math_eval446000008_fn__446000009_A_init.Done() { A_arbace_math_eval446000008_fn__446000009_A_init.Run(A_arbace_math_eval446000008_fn__446000009_A_clinit) } }

func A_arbace_math_eval446000008_fn__446000009_A_clinit() { A_arbace_math_eval446000008_fn__446000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_eval446000008_fn__446000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000008_fn__446000009_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000008_fn__446000009_A_class }

func (t *A_arbace_math_eval446000008_fn__446000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000008_fn__446000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000008_fn__446000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000008_fn__446000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000008_fn__446000009_A); return ok }

func A_arbace_math_eval446000008_fn__446000009_A_Cast(x any) *A_arbace_math_eval446000008_fn__446000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000008_fn__446000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000008_fn__446000009_A_class)) }; return v }



type A_arbace_math_exp_A struct{ jrt.Object }

func (t *A_arbace_math_exp_A) Is_Compiler_AOTF1() {}

var A_arbace_math_exp_A_fn_class *jrt.Class

var A_arbace_math_exp_A_init jrt.ClassInit

func A_arbace_math_exp_A_Init() { if !A_arbace_math_exp_A_init.Done() { A_arbace_math_exp_A_init.Run(A_arbace_math_exp_A_clinit) } }

func A_arbace_math_exp_A_clinit() { A_arbace_math_exp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_exp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_exp_A) GetClass__Class() *jrt.Class { return A_arbace_math_exp_A_class }

func (t *A_arbace_math_exp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_exp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_exp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_exp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_exp_A); return ok }

func A_arbace_math_exp_A_Cast(x any) *A_arbace_math_exp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_exp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_exp_A_class)) }; return v }



type A_arbace_math_exp__inliner__446000038_A struct{ jrt.Object }

func (t *A_arbace_math_exp__inliner__446000038_A) Is_Compiler_AOTF1() {}

var A_arbace_math_exp__inliner__446000038_A_fn_class *jrt.Class

var A_arbace_math_exp__inliner__446000038_A_init jrt.ClassInit

func A_arbace_math_exp__inliner__446000038_A_Init() { if !A_arbace_math_exp__inliner__446000038_A_init.Done() { A_arbace_math_exp__inliner__446000038_A_init.Run(A_arbace_math_exp__inliner__446000038_A_clinit) } }

func A_arbace_math_exp__inliner__446000038_A_clinit() { A_arbace_math_exp__inliner__446000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_exp__inliner__446000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_exp__inliner__446000038_A) GetClass__Class() *jrt.Class { return A_arbace_math_exp__inliner__446000038_A_class }

func (t *A_arbace_math_exp__inliner__446000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_exp__inliner__446000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_exp__inliner__446000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_exp__inliner__446000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_exp__inliner__446000038_A); return ok }

func A_arbace_math_exp__inliner__446000038_A_Cast(x any) *A_arbace_math_exp__inliner__446000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_exp__inliner__446000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_exp__inliner__446000038_A_class)) }; return v }



type A_arbace_math_expm1_A struct{ jrt.Object }

func (t *A_arbace_math_expm1_A) Is_Compiler_AOTF1() {}

var A_arbace_math_expm1_A_fn_class *jrt.Class

var A_arbace_math_expm1_A_init jrt.ClassInit

func A_arbace_math_expm1_A_Init() { if !A_arbace_math_expm1_A_init.Done() { A_arbace_math_expm1_A_init.Run(A_arbace_math_expm1_A_clinit) } }

func A_arbace_math_expm1_A_clinit() { A_arbace_math_expm1_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_expm1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_expm1_A) GetClass__Class() *jrt.Class { return A_arbace_math_expm1_A_class }

func (t *A_arbace_math_expm1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_expm1_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_expm1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_expm1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_expm1_A); return ok }

func A_arbace_math_expm1_A_Cast(x any) *A_arbace_math_expm1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_expm1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_expm1_A_class)) }; return v }



type A_arbace_math_expm1__inliner__446000119_A struct{ jrt.Object }

func (t *A_arbace_math_expm1__inliner__446000119_A) Is_Compiler_AOTF1() {}

var A_arbace_math_expm1__inliner__446000119_A_fn_class *jrt.Class

var A_arbace_math_expm1__inliner__446000119_A_init jrt.ClassInit

func A_arbace_math_expm1__inliner__446000119_A_Init() { if !A_arbace_math_expm1__inliner__446000119_A_init.Done() { A_arbace_math_expm1__inliner__446000119_A_init.Run(A_arbace_math_expm1__inliner__446000119_A_clinit) } }

func A_arbace_math_expm1__inliner__446000119_A_clinit() { A_arbace_math_expm1__inliner__446000119_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_expm1__inliner__446000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_expm1__inliner__446000119_A) GetClass__Class() *jrt.Class { return A_arbace_math_expm1__inliner__446000119_A_class }

func (t *A_arbace_math_expm1__inliner__446000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_expm1__inliner__446000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_expm1__inliner__446000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_expm1__inliner__446000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_expm1__inliner__446000119_A); return ok }

func A_arbace_math_expm1__inliner__446000119_A_Cast(x any) *A_arbace_math_expm1__inliner__446000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_expm1__inliner__446000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_expm1__inliner__446000119_A_class)) }; return v }



type A_arbace_math_floor_A struct{ jrt.Object }

func (t *A_arbace_math_floor_A) Is_Compiler_AOTF1() {}

var A_arbace_math_floor_A_fn_class *jrt.Class

var A_arbace_math_floor_A_init jrt.ClassInit

func A_arbace_math_floor_A_Init() { if !A_arbace_math_floor_A_init.Done() { A_arbace_math_floor_A_init.Run(A_arbace_math_floor_A_clinit) } }

func A_arbace_math_floor_A_clinit() { A_arbace_math_floor_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_floor_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_floor_A) GetClass__Class() *jrt.Class { return A_arbace_math_floor_A_class }

func (t *A_arbace_math_floor_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_floor_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_floor_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_floor_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_floor_A); return ok }

func A_arbace_math_floor_A_Cast(x any) *A_arbace_math_floor_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_floor_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_floor_A_class)) }; return v }



type A_arbace_math_floor__inliner__446000059_A struct{ jrt.Object }

func (t *A_arbace_math_floor__inliner__446000059_A) Is_Compiler_AOTF1() {}

var A_arbace_math_floor__inliner__446000059_A_fn_class *jrt.Class

var A_arbace_math_floor__inliner__446000059_A_init jrt.ClassInit

func A_arbace_math_floor__inliner__446000059_A_Init() { if !A_arbace_math_floor__inliner__446000059_A_init.Done() { A_arbace_math_floor__inliner__446000059_A_init.Run(A_arbace_math_floor__inliner__446000059_A_clinit) } }

func A_arbace_math_floor__inliner__446000059_A_clinit() { A_arbace_math_floor__inliner__446000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_floor__inliner__446000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_floor__inliner__446000059_A) GetClass__Class() *jrt.Class { return A_arbace_math_floor__inliner__446000059_A_class }

func (t *A_arbace_math_floor__inliner__446000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_floor__inliner__446000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_floor__inliner__446000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_floor__inliner__446000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_floor__inliner__446000059_A); return ok }

func A_arbace_math_floor__inliner__446000059_A_Cast(x any) *A_arbace_math_floor__inliner__446000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_floor__inliner__446000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_floor__inliner__446000059_A_class)) }; return v }



type A_arbace_math_floor_div_A struct{ jrt.Object }

func (t *A_arbace_math_floor_div_A) Is_Compiler_AOTF2() {}

var A_arbace_math_floor_div_A_fn_class *jrt.Class

var A_arbace_math_floor_div_A_init jrt.ClassInit

func A_arbace_math_floor_div_A_Init() { if !A_arbace_math_floor_div_A_init.Done() { A_arbace_math_floor_div_A_init.Run(A_arbace_math_floor_div_A_clinit) } }

func A_arbace_math_floor_div_A_clinit() { A_arbace_math_floor_div_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_93, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_floor_div_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_floor_div_A) GetClass__Class() *jrt.Class { return A_arbace_math_floor_div_A_class }

func (t *A_arbace_math_floor_div_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_floor_div_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_floor_div_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_floor_div_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_floor_div_A); return ok }

func A_arbace_math_floor_div_A_Cast(x any) *A_arbace_math_floor_div_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_floor_div_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_floor_div_A_class)) }; return v }



type A_arbace_math_floor_div__inliner__446000095_A struct{ jrt.Object }

func (t *A_arbace_math_floor_div__inliner__446000095_A) Is_Compiler_AOTF2() {}

var A_arbace_math_floor_div__inliner__446000095_A_fn_class *jrt.Class

var A_arbace_math_floor_div__inliner__446000095_A_init jrt.ClassInit

func A_arbace_math_floor_div__inliner__446000095_A_Init() { if !A_arbace_math_floor_div__inliner__446000095_A_init.Done() { A_arbace_math_floor_div__inliner__446000095_A_init.Run(A_arbace_math_floor_div__inliner__446000095_A_clinit) } }

func A_arbace_math_floor_div__inliner__446000095_A_clinit() { A_arbace_math_floor_div__inliner__446000095_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_floor_div__inliner__446000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_floor_div__inliner__446000095_A) GetClass__Class() *jrt.Class { return A_arbace_math_floor_div__inliner__446000095_A_class }

func (t *A_arbace_math_floor_div__inliner__446000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_floor_div__inliner__446000095_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_floor_div__inliner__446000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_floor_div__inliner__446000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_floor_div__inliner__446000095_A); return ok }

func A_arbace_math_floor_div__inliner__446000095_A_Cast(x any) *A_arbace_math_floor_div__inliner__446000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_floor_div__inliner__446000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_floor_div__inliner__446000095_A_class)) }; return v }



type A_arbace_math_floor_mod_A struct{ jrt.Object }

func (t *A_arbace_math_floor_mod_A) Is_Compiler_AOTF2() {}

var A_arbace_math_floor_mod_A_fn_class *jrt.Class

var A_arbace_math_floor_mod_A_init jrt.ClassInit

func A_arbace_math_floor_mod_A_Init() { if !A_arbace_math_floor_mod_A_init.Done() { A_arbace_math_floor_mod_A_init.Run(A_arbace_math_floor_mod_A_clinit) } }

func A_arbace_math_floor_mod_A_clinit() { A_arbace_math_floor_mod_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_floor_mod_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_floor_mod_A) GetClass__Class() *jrt.Class { return A_arbace_math_floor_mod_A_class }

func (t *A_arbace_math_floor_mod_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_floor_mod_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_floor_mod_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_floor_mod_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_floor_mod_A); return ok }

func A_arbace_math_floor_mod_A_Cast(x any) *A_arbace_math_floor_mod_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_floor_mod_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_floor_mod_A_class)) }; return v }



type A_arbace_math_floor_mod__inliner__446000098_A struct{ jrt.Object }

func (t *A_arbace_math_floor_mod__inliner__446000098_A) Is_Compiler_AOTF2() {}

var A_arbace_math_floor_mod__inliner__446000098_A_fn_class *jrt.Class

var A_arbace_math_floor_mod__inliner__446000098_A_init jrt.ClassInit

func A_arbace_math_floor_mod__inliner__446000098_A_Init() { if !A_arbace_math_floor_mod__inliner__446000098_A_init.Done() { A_arbace_math_floor_mod__inliner__446000098_A_init.Run(A_arbace_math_floor_mod__inliner__446000098_A_clinit) } }

func A_arbace_math_floor_mod__inliner__446000098_A_clinit() { A_arbace_math_floor_mod__inliner__446000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_floor_mod__inliner__446000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_floor_mod__inliner__446000098_A) GetClass__Class() *jrt.Class { return A_arbace_math_floor_mod__inliner__446000098_A_class }

func (t *A_arbace_math_floor_mod__inliner__446000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_floor_mod__inliner__446000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_floor_mod__inliner__446000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_floor_mod__inliner__446000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_floor_mod__inliner__446000098_A); return ok }

func A_arbace_math_floor_mod__inliner__446000098_A_Cast(x any) *A_arbace_math_floor_mod__inliner__446000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_floor_mod__inliner__446000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_floor_mod__inliner__446000098_A_class)) }; return v }



type A_arbace_math_get_exponent_A struct{ jrt.Object }

func (t *A_arbace_math_get_exponent_A) Is_Compiler_AOTF1() {}

var A_arbace_math_get_exponent_A_fn_class *jrt.Class

var A_arbace_math_get_exponent_A_init jrt.ClassInit

func A_arbace_math_get_exponent_A_Init() { if !A_arbace_math_get_exponent_A_init.Done() { A_arbace_math_get_exponent_A_init.Run(A_arbace_math_get_exponent_A_clinit) } }

func A_arbace_math_get_exponent_A_clinit() { A_arbace_math_get_exponent_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_get_exponent_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_get_exponent_A) GetClass__Class() *jrt.Class { return A_arbace_math_get_exponent_A_class }

func (t *A_arbace_math_get_exponent_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_get_exponent_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_get_exponent_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_get_exponent_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_get_exponent_A); return ok }

func A_arbace_math_get_exponent_A_Cast(x any) *A_arbace_math_get_exponent_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_get_exponent_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_get_exponent_A_class)) }; return v }



type A_arbace_math_get_exponent__inliner__446000128_A struct{ jrt.Object }

func (t *A_arbace_math_get_exponent__inliner__446000128_A) Is_Compiler_AOTF1() {}

var A_arbace_math_get_exponent__inliner__446000128_A_fn_class *jrt.Class

var A_arbace_math_get_exponent__inliner__446000128_A_init jrt.ClassInit

func A_arbace_math_get_exponent__inliner__446000128_A_Init() { if !A_arbace_math_get_exponent__inliner__446000128_A_init.Done() { A_arbace_math_get_exponent__inliner__446000128_A_init.Run(A_arbace_math_get_exponent__inliner__446000128_A_clinit) } }

func A_arbace_math_get_exponent__inliner__446000128_A_clinit() { A_arbace_math_get_exponent__inliner__446000128_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_get_exponent__inliner__446000128_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_get_exponent__inliner__446000128_A) GetClass__Class() *jrt.Class { return A_arbace_math_get_exponent__inliner__446000128_A_class }

func (t *A_arbace_math_get_exponent__inliner__446000128_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_get_exponent__inliner__446000128_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_get_exponent__inliner__446000128_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_get_exponent__inliner__446000128_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_get_exponent__inliner__446000128_A); return ok }

func A_arbace_math_get_exponent__inliner__446000128_A_Cast(x any) *A_arbace_math_get_exponent__inliner__446000128_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_get_exponent__inliner__446000128_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_get_exponent__inliner__446000128_A_class)) }; return v }



type A_arbace_math_hypot_A struct{ jrt.Object }

func (t *A_arbace_math_hypot_A) Is_Compiler_AOTF2() {}

var A_arbace_math_hypot_A_fn_class *jrt.Class

var A_arbace_math_hypot_A_init jrt.ClassInit

func A_arbace_math_hypot_A_Init() { if !A_arbace_math_hypot_A_init.Done() { A_arbace_math_hypot_A_init.Run(A_arbace_math_hypot_A_clinit) } }

func A_arbace_math_hypot_A_clinit() { A_arbace_math_hypot_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_99, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_hypot_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_hypot_A) GetClass__Class() *jrt.Class { return A_arbace_math_hypot_A_class }

func (t *A_arbace_math_hypot_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_hypot_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_hypot_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_hypot_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_hypot_A); return ok }

func A_arbace_math_hypot_A_Cast(x any) *A_arbace_math_hypot_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_hypot_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_hypot_A_class)) }; return v }



type A_arbace_math_hypot__inliner__446000116_A struct{ jrt.Object }

func (t *A_arbace_math_hypot__inliner__446000116_A) Is_Compiler_AOTF2() {}

var A_arbace_math_hypot__inliner__446000116_A_fn_class *jrt.Class

var A_arbace_math_hypot__inliner__446000116_A_init jrt.ClassInit

func A_arbace_math_hypot__inliner__446000116_A_Init() { if !A_arbace_math_hypot__inliner__446000116_A_init.Done() { A_arbace_math_hypot__inliner__446000116_A_init.Run(A_arbace_math_hypot__inliner__446000116_A_clinit) } }

func A_arbace_math_hypot__inliner__446000116_A_clinit() { A_arbace_math_hypot__inliner__446000116_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_100, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_hypot__inliner__446000116_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_hypot__inliner__446000116_A) GetClass__Class() *jrt.Class { return A_arbace_math_hypot__inliner__446000116_A_class }

func (t *A_arbace_math_hypot__inliner__446000116_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_hypot__inliner__446000116_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_hypot__inliner__446000116_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_hypot__inliner__446000116_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_hypot__inliner__446000116_A); return ok }

func A_arbace_math_hypot__inliner__446000116_A_Cast(x any) *A_arbace_math_hypot__inliner__446000116_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_hypot__inliner__446000116_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_hypot__inliner__446000116_A_class)) }; return v }



type A_arbace_math_increment_exact_A struct{ jrt.Object }

func (t *A_arbace_math_increment_exact_A) Is_Compiler_AOTF1() {}

var A_arbace_math_increment_exact_A_fn_class *jrt.Class

var A_arbace_math_increment_exact_A_init jrt.ClassInit

func A_arbace_math_increment_exact_A_Init() { if !A_arbace_math_increment_exact_A_init.Done() { A_arbace_math_increment_exact_A_init.Run(A_arbace_math_increment_exact_A_clinit) } }

func A_arbace_math_increment_exact_A_clinit() { A_arbace_math_increment_exact_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_101, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_increment_exact_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_increment_exact_A) GetClass__Class() *jrt.Class { return A_arbace_math_increment_exact_A_class }

func (t *A_arbace_math_increment_exact_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_increment_exact_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_increment_exact_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_increment_exact_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_increment_exact_A); return ok }

func A_arbace_math_increment_exact_A_Cast(x any) *A_arbace_math_increment_exact_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_increment_exact_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_increment_exact_A_class)) }; return v }



type A_arbace_math_increment_exact__inliner__446000086_A struct{ jrt.Object }

func (t *A_arbace_math_increment_exact__inliner__446000086_A) Is_Compiler_AOTF1() {}

var A_arbace_math_increment_exact__inliner__446000086_A_fn_class *jrt.Class

var A_arbace_math_increment_exact__inliner__446000086_A_init jrt.ClassInit

func A_arbace_math_increment_exact__inliner__446000086_A_Init() { if !A_arbace_math_increment_exact__inliner__446000086_A_init.Done() { A_arbace_math_increment_exact__inliner__446000086_A_init.Run(A_arbace_math_increment_exact__inliner__446000086_A_clinit) } }

func A_arbace_math_increment_exact__inliner__446000086_A_clinit() { A_arbace_math_increment_exact__inliner__446000086_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_increment_exact__inliner__446000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_increment_exact__inliner__446000086_A) GetClass__Class() *jrt.Class { return A_arbace_math_increment_exact__inliner__446000086_A_class }

func (t *A_arbace_math_increment_exact__inliner__446000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_increment_exact__inliner__446000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_increment_exact__inliner__446000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_increment_exact__inliner__446000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_increment_exact__inliner__446000086_A); return ok }

func A_arbace_math_increment_exact__inliner__446000086_A_Cast(x any) *A_arbace_math_increment_exact__inliner__446000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_increment_exact__inliner__446000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_increment_exact__inliner__446000086_A_class)) }; return v }



type A_arbace_math_log_A struct{ jrt.Object }

func (t *A_arbace_math_log_A) Is_Compiler_AOTF1() {}

var A_arbace_math_log_A_fn_class *jrt.Class

var A_arbace_math_log_A_init jrt.ClassInit

func A_arbace_math_log_A_Init() { if !A_arbace_math_log_A_init.Done() { A_arbace_math_log_A_init.Run(A_arbace_math_log_A_clinit) } }

func A_arbace_math_log_A_clinit() { A_arbace_math_log_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_log_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_log_A) GetClass__Class() *jrt.Class { return A_arbace_math_log_A_class }

func (t *A_arbace_math_log_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_log_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_log_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_log_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_log_A); return ok }

func A_arbace_math_log_A_Cast(x any) *A_arbace_math_log_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_log_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_log_A_class)) }; return v }



type A_arbace_math_log10_A struct{ jrt.Object }

func (t *A_arbace_math_log10_A) Is_Compiler_AOTF1() {}

var A_arbace_math_log10_A_fn_class *jrt.Class

var A_arbace_math_log10_A_init jrt.ClassInit

func A_arbace_math_log10_A_Init() { if !A_arbace_math_log10_A_init.Done() { A_arbace_math_log10_A_init.Run(A_arbace_math_log10_A_clinit) } }

func A_arbace_math_log10_A_clinit() { A_arbace_math_log10_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_log10_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_log10_A) GetClass__Class() *jrt.Class { return A_arbace_math_log10_A_class }

func (t *A_arbace_math_log10_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_log10_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_log10_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_log10_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_log10_A); return ok }

func A_arbace_math_log10_A_Cast(x any) *A_arbace_math_log10_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_log10_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_log10_A_class)) }; return v }



type A_arbace_math_log10__inliner__446000044_A struct{ jrt.Object }

func (t *A_arbace_math_log10__inliner__446000044_A) Is_Compiler_AOTF1() {}

var A_arbace_math_log10__inliner__446000044_A_fn_class *jrt.Class

var A_arbace_math_log10__inliner__446000044_A_init jrt.ClassInit

func A_arbace_math_log10__inliner__446000044_A_Init() { if !A_arbace_math_log10__inliner__446000044_A_init.Done() { A_arbace_math_log10__inliner__446000044_A_init.Run(A_arbace_math_log10__inliner__446000044_A_clinit) } }

func A_arbace_math_log10__inliner__446000044_A_clinit() { A_arbace_math_log10__inliner__446000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_log10__inliner__446000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_log10__inliner__446000044_A) GetClass__Class() *jrt.Class { return A_arbace_math_log10__inliner__446000044_A_class }

func (t *A_arbace_math_log10__inliner__446000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_log10__inliner__446000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_log10__inliner__446000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_log10__inliner__446000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_log10__inliner__446000044_A); return ok }

func A_arbace_math_log10__inliner__446000044_A_Cast(x any) *A_arbace_math_log10__inliner__446000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_log10__inliner__446000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_log10__inliner__446000044_A_class)) }; return v }



type A_arbace_math_log1p_A struct{ jrt.Object }

func (t *A_arbace_math_log1p_A) Is_Compiler_AOTF1() {}

var A_arbace_math_log1p_A_fn_class *jrt.Class

var A_arbace_math_log1p_A_init jrt.ClassInit

func A_arbace_math_log1p_A_Init() { if !A_arbace_math_log1p_A_init.Done() { A_arbace_math_log1p_A_init.Run(A_arbace_math_log1p_A_clinit) } }

func A_arbace_math_log1p_A_clinit() { A_arbace_math_log1p_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_log1p_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_log1p_A) GetClass__Class() *jrt.Class { return A_arbace_math_log1p_A_class }

func (t *A_arbace_math_log1p_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_log1p_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_log1p_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_log1p_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_log1p_A); return ok }

func A_arbace_math_log1p_A_Cast(x any) *A_arbace_math_log1p_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_log1p_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_log1p_A_class)) }; return v }



type A_arbace_math_log1p__inliner__446000122_A struct{ jrt.Object }

func (t *A_arbace_math_log1p__inliner__446000122_A) Is_Compiler_AOTF1() {}

var A_arbace_math_log1p__inliner__446000122_A_fn_class *jrt.Class

var A_arbace_math_log1p__inliner__446000122_A_init jrt.ClassInit

func A_arbace_math_log1p__inliner__446000122_A_Init() { if !A_arbace_math_log1p__inliner__446000122_A_init.Done() { A_arbace_math_log1p__inliner__446000122_A_init.Run(A_arbace_math_log1p__inliner__446000122_A_clinit) } }

func A_arbace_math_log1p__inliner__446000122_A_clinit() { A_arbace_math_log1p__inliner__446000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_log1p__inliner__446000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_log1p__inliner__446000122_A) GetClass__Class() *jrt.Class { return A_arbace_math_log1p__inliner__446000122_A_class }

func (t *A_arbace_math_log1p__inliner__446000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_log1p__inliner__446000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_log1p__inliner__446000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_log1p__inliner__446000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_log1p__inliner__446000122_A); return ok }

func A_arbace_math_log1p__inliner__446000122_A_Cast(x any) *A_arbace_math_log1p__inliner__446000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_log1p__inliner__446000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_log1p__inliner__446000122_A_class)) }; return v }



type A_arbace_math_log__inliner__446000041_A struct{ jrt.Object }

func (t *A_arbace_math_log__inliner__446000041_A) Is_Compiler_AOTF1() {}

var A_arbace_math_log__inliner__446000041_A_fn_class *jrt.Class

var A_arbace_math_log__inliner__446000041_A_init jrt.ClassInit

func A_arbace_math_log__inliner__446000041_A_Init() { if !A_arbace_math_log__inliner__446000041_A_init.Done() { A_arbace_math_log__inliner__446000041_A_init.Run(A_arbace_math_log__inliner__446000041_A_clinit) } }

func A_arbace_math_log__inliner__446000041_A_clinit() { A_arbace_math_log__inliner__446000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_log__inliner__446000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_log__inliner__446000041_A) GetClass__Class() *jrt.Class { return A_arbace_math_log__inliner__446000041_A_class }

func (t *A_arbace_math_log__inliner__446000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_log__inliner__446000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_log__inliner__446000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_log__inliner__446000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_log__inliner__446000041_A); return ok }

func A_arbace_math_log__inliner__446000041_A_Cast(x any) *A_arbace_math_log__inliner__446000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_log__inliner__446000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_log__inliner__446000041_A_class)) }; return v }



type A_arbace_math_multiply_exact_A struct{ jrt.Object }

func (t *A_arbace_math_multiply_exact_A) Is_Compiler_AOTF2() {}

var A_arbace_math_multiply_exact_A_fn_class *jrt.Class

var A_arbace_math_multiply_exact_A_init jrt.ClassInit

func A_arbace_math_multiply_exact_A_Init() { if !A_arbace_math_multiply_exact_A_init.Done() { A_arbace_math_multiply_exact_A_init.Run(A_arbace_math_multiply_exact_A_clinit) } }

func A_arbace_math_multiply_exact_A_clinit() { A_arbace_math_multiply_exact_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_multiply_exact_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_multiply_exact_A) GetClass__Class() *jrt.Class { return A_arbace_math_multiply_exact_A_class }

func (t *A_arbace_math_multiply_exact_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_multiply_exact_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_multiply_exact_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_multiply_exact_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_multiply_exact_A); return ok }

func A_arbace_math_multiply_exact_A_Cast(x any) *A_arbace_math_multiply_exact_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_multiply_exact_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_multiply_exact_A_class)) }; return v }



type A_arbace_math_multiply_exact__inliner__446000083_A struct{ jrt.Object }

func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Is_Compiler_AOTF2() {}

var A_arbace_math_multiply_exact__inliner__446000083_A_fn_class *jrt.Class

var A_arbace_math_multiply_exact__inliner__446000083_A_init jrt.ClassInit

func A_arbace_math_multiply_exact__inliner__446000083_A_Init() { if !A_arbace_math_multiply_exact__inliner__446000083_A_init.Done() { A_arbace_math_multiply_exact__inliner__446000083_A_init.Run(A_arbace_math_multiply_exact__inliner__446000083_A_clinit) } }

func A_arbace_math_multiply_exact__inliner__446000083_A_clinit() { A_arbace_math_multiply_exact__inliner__446000083_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_multiply_exact__inliner__446000083_A) GetClass__Class() *jrt.Class { return A_arbace_math_multiply_exact__inliner__446000083_A_class }

func (t *A_arbace_math_multiply_exact__inliner__446000083_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_multiply_exact__inliner__446000083_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_multiply_exact__inliner__446000083_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_multiply_exact__inliner__446000083_A); return ok }

func A_arbace_math_multiply_exact__inliner__446000083_A_Cast(x any) *A_arbace_math_multiply_exact__inliner__446000083_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_multiply_exact__inliner__446000083_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_multiply_exact__inliner__446000083_A_class)) }; return v }



type A_arbace_math_negate_exact_A struct{ jrt.Object }

func (t *A_arbace_math_negate_exact_A) Is_Compiler_AOTF1() {}

var A_arbace_math_negate_exact_A_fn_class *jrt.Class

var A_arbace_math_negate_exact_A_init jrt.ClassInit

func A_arbace_math_negate_exact_A_Init() { if !A_arbace_math_negate_exact_A_init.Done() { A_arbace_math_negate_exact_A_init.Run(A_arbace_math_negate_exact_A_clinit) } }

func A_arbace_math_negate_exact_A_clinit() { A_arbace_math_negate_exact_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_negate_exact_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_negate_exact_A) GetClass__Class() *jrt.Class { return A_arbace_math_negate_exact_A_class }

func (t *A_arbace_math_negate_exact_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_negate_exact_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_negate_exact_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_negate_exact_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_negate_exact_A); return ok }

func A_arbace_math_negate_exact_A_Cast(x any) *A_arbace_math_negate_exact_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_negate_exact_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_negate_exact_A_class)) }; return v }



type A_arbace_math_negate_exact__inliner__446000092_A struct{ jrt.Object }

func (t *A_arbace_math_negate_exact__inliner__446000092_A) Is_Compiler_AOTF1() {}

var A_arbace_math_negate_exact__inliner__446000092_A_fn_class *jrt.Class

var A_arbace_math_negate_exact__inliner__446000092_A_init jrt.ClassInit

func A_arbace_math_negate_exact__inliner__446000092_A_Init() { if !A_arbace_math_negate_exact__inliner__446000092_A_init.Done() { A_arbace_math_negate_exact__inliner__446000092_A_init.Run(A_arbace_math_negate_exact__inliner__446000092_A_clinit) } }

func A_arbace_math_negate_exact__inliner__446000092_A_clinit() { A_arbace_math_negate_exact__inliner__446000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_negate_exact__inliner__446000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_negate_exact__inliner__446000092_A) GetClass__Class() *jrt.Class { return A_arbace_math_negate_exact__inliner__446000092_A_class }

func (t *A_arbace_math_negate_exact__inliner__446000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_negate_exact__inliner__446000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_negate_exact__inliner__446000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_negate_exact__inliner__446000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_negate_exact__inliner__446000092_A); return ok }

func A_arbace_math_negate_exact__inliner__446000092_A_Cast(x any) *A_arbace_math_negate_exact__inliner__446000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_negate_exact__inliner__446000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_negate_exact__inliner__446000092_A_class)) }; return v }



type A_arbace_math_next_after_A struct{ jrt.Object }

func (t *A_arbace_math_next_after_A) Is_Compiler_AOTF2() {}

var A_arbace_math_next_after_A_fn_class *jrt.Class

var A_arbace_math_next_after_A_init jrt.ClassInit

func A_arbace_math_next_after_A_Init() { if !A_arbace_math_next_after_A_init.Done() { A_arbace_math_next_after_A_init.Run(A_arbace_math_next_after_A_clinit) } }

func A_arbace_math_next_after_A_clinit() { A_arbace_math_next_after_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_next_after_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_next_after_A) GetClass__Class() *jrt.Class { return A_arbace_math_next_after_A_class }

func (t *A_arbace_math_next_after_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_next_after_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_next_after_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_next_after_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_next_after_A); return ok }

func A_arbace_math_next_after_A_Cast(x any) *A_arbace_math_next_after_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_next_after_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_next_after_A_class)) }; return v }



type A_arbace_math_next_after__inliner__446000131_A struct{ jrt.Object }

func (t *A_arbace_math_next_after__inliner__446000131_A) Is_Compiler_AOTF2() {}

var A_arbace_math_next_after__inliner__446000131_A_fn_class *jrt.Class

var A_arbace_math_next_after__inliner__446000131_A_init jrt.ClassInit

func A_arbace_math_next_after__inliner__446000131_A_Init() { if !A_arbace_math_next_after__inliner__446000131_A_init.Done() { A_arbace_math_next_after__inliner__446000131_A_init.Run(A_arbace_math_next_after__inliner__446000131_A_clinit) } }

func A_arbace_math_next_after__inliner__446000131_A_clinit() { A_arbace_math_next_after__inliner__446000131_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_next_after__inliner__446000131_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_next_after__inliner__446000131_A) GetClass__Class() *jrt.Class { return A_arbace_math_next_after__inliner__446000131_A_class }

func (t *A_arbace_math_next_after__inliner__446000131_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_next_after__inliner__446000131_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_next_after__inliner__446000131_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_next_after__inliner__446000131_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_next_after__inliner__446000131_A); return ok }

func A_arbace_math_next_after__inliner__446000131_A_Cast(x any) *A_arbace_math_next_after__inliner__446000131_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_next_after__inliner__446000131_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_next_after__inliner__446000131_A_class)) }; return v }



type A_arbace_math_next_down_A struct{ jrt.Object }

func (t *A_arbace_math_next_down_A) Is_Compiler_AOTF1() {}

var A_arbace_math_next_down_A_fn_class *jrt.Class

var A_arbace_math_next_down_A_init jrt.ClassInit

func A_arbace_math_next_down_A_Init() { if !A_arbace_math_next_down_A_init.Done() { A_arbace_math_next_down_A_init.Run(A_arbace_math_next_down_A_clinit) } }

func A_arbace_math_next_down_A_clinit() { A_arbace_math_next_down_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_next_down_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_next_down_A) GetClass__Class() *jrt.Class { return A_arbace_math_next_down_A_class }

func (t *A_arbace_math_next_down_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_next_down_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_next_down_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_next_down_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_next_down_A); return ok }

func A_arbace_math_next_down_A_Cast(x any) *A_arbace_math_next_down_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_next_down_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_next_down_A_class)) }; return v }



type A_arbace_math_next_down__inliner__446000137_A struct{ jrt.Object }

func (t *A_arbace_math_next_down__inliner__446000137_A) Is_Compiler_AOTF1() {}

var A_arbace_math_next_down__inliner__446000137_A_fn_class *jrt.Class

var A_arbace_math_next_down__inliner__446000137_A_init jrt.ClassInit

func A_arbace_math_next_down__inliner__446000137_A_Init() { if !A_arbace_math_next_down__inliner__446000137_A_init.Done() { A_arbace_math_next_down__inliner__446000137_A_init.Run(A_arbace_math_next_down__inliner__446000137_A_clinit) } }

func A_arbace_math_next_down__inliner__446000137_A_clinit() { A_arbace_math_next_down__inliner__446000137_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_next_down__inliner__446000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_next_down__inliner__446000137_A) GetClass__Class() *jrt.Class { return A_arbace_math_next_down__inliner__446000137_A_class }

func (t *A_arbace_math_next_down__inliner__446000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_next_down__inliner__446000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_next_down__inliner__446000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_next_down__inliner__446000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_next_down__inliner__446000137_A); return ok }

func A_arbace_math_next_down__inliner__446000137_A_Cast(x any) *A_arbace_math_next_down__inliner__446000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_next_down__inliner__446000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_next_down__inliner__446000137_A_class)) }; return v }



type A_arbace_math_next_up_A struct{ jrt.Object }

func (t *A_arbace_math_next_up_A) Is_Compiler_AOTF1() {}

var A_arbace_math_next_up_A_fn_class *jrt.Class

var A_arbace_math_next_up_A_init jrt.ClassInit

func A_arbace_math_next_up_A_Init() { if !A_arbace_math_next_up_A_init.Done() { A_arbace_math_next_up_A_init.Run(A_arbace_math_next_up_A_clinit) } }

func A_arbace_math_next_up_A_clinit() { A_arbace_math_next_up_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_next_up_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_next_up_A) GetClass__Class() *jrt.Class { return A_arbace_math_next_up_A_class }

func (t *A_arbace_math_next_up_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_next_up_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_next_up_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_next_up_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_next_up_A); return ok }

func A_arbace_math_next_up_A_Cast(x any) *A_arbace_math_next_up_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_next_up_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_next_up_A_class)) }; return v }



type A_arbace_math_next_up__inliner__446000134_A struct{ jrt.Object }

func (t *A_arbace_math_next_up__inliner__446000134_A) Is_Compiler_AOTF1() {}

var A_arbace_math_next_up__inliner__446000134_A_fn_class *jrt.Class

var A_arbace_math_next_up__inliner__446000134_A_init jrt.ClassInit

func A_arbace_math_next_up__inliner__446000134_A_Init() { if !A_arbace_math_next_up__inliner__446000134_A_init.Done() { A_arbace_math_next_up__inliner__446000134_A_init.Run(A_arbace_math_next_up__inliner__446000134_A_clinit) } }

func A_arbace_math_next_up__inliner__446000134_A_clinit() { A_arbace_math_next_up__inliner__446000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_next_up__inliner__446000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_next_up__inliner__446000134_A) GetClass__Class() *jrt.Class { return A_arbace_math_next_up__inliner__446000134_A_class }

func (t *A_arbace_math_next_up__inliner__446000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_next_up__inliner__446000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_next_up__inliner__446000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_next_up__inliner__446000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_next_up__inliner__446000134_A); return ok }

func A_arbace_math_next_up__inliner__446000134_A_Cast(x any) *A_arbace_math_next_up__inliner__446000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_next_up__inliner__446000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_next_up__inliner__446000134_A_class)) }; return v }



type A_arbace_math_pow_A struct{ jrt.Object }

func (t *A_arbace_math_pow_A) Is_Compiler_AOTF2() {}

var A_arbace_math_pow_A_fn_class *jrt.Class

var A_arbace_math_pow_A_init jrt.ClassInit

func A_arbace_math_pow_A_Init() { if !A_arbace_math_pow_A_init.Done() { A_arbace_math_pow_A_init.Run(A_arbace_math_pow_A_clinit) } }

func A_arbace_math_pow_A_clinit() { A_arbace_math_pow_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_pow_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_pow_A) GetClass__Class() *jrt.Class { return A_arbace_math_pow_A_class }

func (t *A_arbace_math_pow_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_pow_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_pow_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_pow_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_pow_A); return ok }

func A_arbace_math_pow_A_Cast(x any) *A_arbace_math_pow_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_pow_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_pow_A_class)) }; return v }



type A_arbace_math_pow__inliner__446000068_A struct{ jrt.Object }

func (t *A_arbace_math_pow__inliner__446000068_A) Is_Compiler_AOTF2() {}

var A_arbace_math_pow__inliner__446000068_A_fn_class *jrt.Class

var A_arbace_math_pow__inliner__446000068_A_init jrt.ClassInit

func A_arbace_math_pow__inliner__446000068_A_Init() { if !A_arbace_math_pow__inliner__446000068_A_init.Done() { A_arbace_math_pow__inliner__446000068_A_init.Run(A_arbace_math_pow__inliner__446000068_A_clinit) } }

func A_arbace_math_pow__inliner__446000068_A_clinit() { A_arbace_math_pow__inliner__446000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_pow__inliner__446000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_pow__inliner__446000068_A) GetClass__Class() *jrt.Class { return A_arbace_math_pow__inliner__446000068_A_class }

func (t *A_arbace_math_pow__inliner__446000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_pow__inliner__446000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_pow__inliner__446000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_pow__inliner__446000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_pow__inliner__446000068_A); return ok }

func A_arbace_math_pow__inliner__446000068_A_Cast(x any) *A_arbace_math_pow__inliner__446000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_pow__inliner__446000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_pow__inliner__446000068_A_class)) }; return v }



type A_arbace_math_random_A struct{ jrt.Object }

func (t *A_arbace_math_random_A) Is_Compiler_AOTF0() {}

var A_arbace_math_random_A_fn_class *jrt.Class

var A_arbace_math_random_A_init jrt.ClassInit

func A_arbace_math_random_A_Init() { if !A_arbace_math_random_A_init.Done() { A_arbace_math_random_A_init.Run(A_arbace_math_random_A_clinit) } }

func A_arbace_math_random_A_clinit() { A_arbace_math_random_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_random_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_random_A) GetClass__Class() *jrt.Class { return A_arbace_math_random_A_class }

func (t *A_arbace_math_random_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_random_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_random_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_random_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_random_A); return ok }

func A_arbace_math_random_A_Cast(x any) *A_arbace_math_random_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_random_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_random_A_class)) }; return v }



type A_arbace_math_random__inliner__446000074_A struct{ jrt.Object }

func (t *A_arbace_math_random__inliner__446000074_A) Is_Compiler_AOTF0() {}

var A_arbace_math_random__inliner__446000074_A_fn_class *jrt.Class

var A_arbace_math_random__inliner__446000074_A_init jrt.ClassInit

func A_arbace_math_random__inliner__446000074_A_Init() { if !A_arbace_math_random__inliner__446000074_A_init.Done() { A_arbace_math_random__inliner__446000074_A_init.Run(A_arbace_math_random__inliner__446000074_A_clinit) } }

func A_arbace_math_random__inliner__446000074_A_clinit() { A_arbace_math_random__inliner__446000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_random__inliner__446000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_random__inliner__446000074_A) GetClass__Class() *jrt.Class { return A_arbace_math_random__inliner__446000074_A_class }

func (t *A_arbace_math_random__inliner__446000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_random__inliner__446000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_random__inliner__446000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_random__inliner__446000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_random__inliner__446000074_A); return ok }

func A_arbace_math_random__inliner__446000074_A_Cast(x any) *A_arbace_math_random__inliner__446000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_random__inliner__446000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_random__inliner__446000074_A_class)) }; return v }



type A_arbace_math_rint_A struct{ jrt.Object }

func (t *A_arbace_math_rint_A) Is_Compiler_AOTF1() {}

var A_arbace_math_rint_A_fn_class *jrt.Class

var A_arbace_math_rint_A_init jrt.ClassInit

func A_arbace_math_rint_A_Init() { if !A_arbace_math_rint_A_init.Done() { A_arbace_math_rint_A_init.Run(A_arbace_math_rint_A_clinit) } }

func A_arbace_math_rint_A_clinit() { A_arbace_math_rint_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_rint_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_rint_A) GetClass__Class() *jrt.Class { return A_arbace_math_rint_A_class }

func (t *A_arbace_math_rint_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_rint_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_rint_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_rint_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_rint_A); return ok }

func A_arbace_math_rint_A_Cast(x any) *A_arbace_math_rint_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_rint_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_rint_A_class)) }; return v }



type A_arbace_math_rint__inliner__446000062_A struct{ jrt.Object }

func (t *A_arbace_math_rint__inliner__446000062_A) Is_Compiler_AOTF1() {}

var A_arbace_math_rint__inliner__446000062_A_fn_class *jrt.Class

var A_arbace_math_rint__inliner__446000062_A_init jrt.ClassInit

func A_arbace_math_rint__inliner__446000062_A_Init() { if !A_arbace_math_rint__inliner__446000062_A_init.Done() { A_arbace_math_rint__inliner__446000062_A_init.Run(A_arbace_math_rint__inliner__446000062_A_clinit) } }

func A_arbace_math_rint__inliner__446000062_A_clinit() { A_arbace_math_rint__inliner__446000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_rint__inliner__446000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_rint__inliner__446000062_A) GetClass__Class() *jrt.Class { return A_arbace_math_rint__inliner__446000062_A_class }

func (t *A_arbace_math_rint__inliner__446000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_rint__inliner__446000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_rint__inliner__446000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_rint__inliner__446000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_rint__inliner__446000062_A); return ok }

func A_arbace_math_rint__inliner__446000062_A_Cast(x any) *A_arbace_math_rint__inliner__446000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_rint__inliner__446000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_rint__inliner__446000062_A_class)) }; return v }



type A_arbace_math_round_A struct{ jrt.Object }

func (t *A_arbace_math_round_A) Is_Compiler_AOTF1() {}

var A_arbace_math_round_A_fn_class *jrt.Class

var A_arbace_math_round_A_init jrt.ClassInit

func A_arbace_math_round_A_Init() { if !A_arbace_math_round_A_init.Done() { A_arbace_math_round_A_init.Run(A_arbace_math_round_A_clinit) } }

func A_arbace_math_round_A_clinit() { A_arbace_math_round_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_round_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_round_A) GetClass__Class() *jrt.Class { return A_arbace_math_round_A_class }

func (t *A_arbace_math_round_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_round_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_round_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_round_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_round_A); return ok }

func A_arbace_math_round_A_Cast(x any) *A_arbace_math_round_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_round_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_round_A_class)) }; return v }



type A_arbace_math_round__inliner__446000071_A struct{ jrt.Object }

func (t *A_arbace_math_round__inliner__446000071_A) Is_Compiler_AOTF1() {}

var A_arbace_math_round__inliner__446000071_A_fn_class *jrt.Class

var A_arbace_math_round__inliner__446000071_A_init jrt.ClassInit

func A_arbace_math_round__inliner__446000071_A_Init() { if !A_arbace_math_round__inliner__446000071_A_init.Done() { A_arbace_math_round__inliner__446000071_A_init.Run(A_arbace_math_round__inliner__446000071_A_clinit) } }

func A_arbace_math_round__inliner__446000071_A_clinit() { A_arbace_math_round__inliner__446000071_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_round__inliner__446000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_round__inliner__446000071_A) GetClass__Class() *jrt.Class { return A_arbace_math_round__inliner__446000071_A_class }

func (t *A_arbace_math_round__inliner__446000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_round__inliner__446000071_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_round__inliner__446000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_round__inliner__446000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_round__inliner__446000071_A); return ok }

func A_arbace_math_round__inliner__446000071_A_Cast(x any) *A_arbace_math_round__inliner__446000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_round__inliner__446000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_round__inliner__446000071_A_class)) }; return v }



type A_arbace_math_scalb_A struct{ jrt.Object }

func (t *A_arbace_math_scalb_A) Is_Compiler_AOTF2() {}

var A_arbace_math_scalb_A_fn_class *jrt.Class

var A_arbace_math_scalb_A_init jrt.ClassInit

func A_arbace_math_scalb_A_Init() { if !A_arbace_math_scalb_A_init.Done() { A_arbace_math_scalb_A_init.Run(A_arbace_math_scalb_A_clinit) } }

func A_arbace_math_scalb_A_clinit() { A_arbace_math_scalb_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_scalb_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_scalb_A) GetClass__Class() *jrt.Class { return A_arbace_math_scalb_A_class }

func (t *A_arbace_math_scalb_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_scalb_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_scalb_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_scalb_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_scalb_A); return ok }

func A_arbace_math_scalb_A_Cast(x any) *A_arbace_math_scalb_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_scalb_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_scalb_A_class)) }; return v }



type A_arbace_math_scalb__inliner__446000140_A struct{ jrt.Object }

func (t *A_arbace_math_scalb__inliner__446000140_A) Is_Compiler_AOTF2() {}

var A_arbace_math_scalb__inliner__446000140_A_fn_class *jrt.Class

var A_arbace_math_scalb__inliner__446000140_A_init jrt.ClassInit

func A_arbace_math_scalb__inliner__446000140_A_Init() { if !A_arbace_math_scalb__inliner__446000140_A_init.Done() { A_arbace_math_scalb__inliner__446000140_A_init.Run(A_arbace_math_scalb__inliner__446000140_A_clinit) } }

func A_arbace_math_scalb__inliner__446000140_A_clinit() { A_arbace_math_scalb__inliner__446000140_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_scalb__inliner__446000140_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_scalb__inliner__446000140_A) GetClass__Class() *jrt.Class { return A_arbace_math_scalb__inliner__446000140_A_class }

func (t *A_arbace_math_scalb__inliner__446000140_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_scalb__inliner__446000140_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_scalb__inliner__446000140_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_scalb__inliner__446000140_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_scalb__inliner__446000140_A); return ok }

func A_arbace_math_scalb__inliner__446000140_A_Cast(x any) *A_arbace_math_scalb__inliner__446000140_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_scalb__inliner__446000140_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_scalb__inliner__446000140_A_class)) }; return v }



type A_arbace_math_signum_A struct{ jrt.Object }

func (t *A_arbace_math_signum_A) Is_Compiler_AOTF1() {}

var A_arbace_math_signum_A_fn_class *jrt.Class

var A_arbace_math_signum_A_init jrt.ClassInit

func A_arbace_math_signum_A_Init() { if !A_arbace_math_signum_A_init.Done() { A_arbace_math_signum_A_init.Run(A_arbace_math_signum_A_clinit) } }

func A_arbace_math_signum_A_clinit() { A_arbace_math_signum_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_signum_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_signum_A) GetClass__Class() *jrt.Class { return A_arbace_math_signum_A_class }

func (t *A_arbace_math_signum_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_signum_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_signum_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_signum_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_signum_A); return ok }

func A_arbace_math_signum_A_Cast(x any) *A_arbace_math_signum_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_signum_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_signum_A_class)) }; return v }



type A_arbace_math_signum__inliner__446000104_A struct{ jrt.Object }

func (t *A_arbace_math_signum__inliner__446000104_A) Is_Compiler_AOTF1() {}

var A_arbace_math_signum__inliner__446000104_A_fn_class *jrt.Class

var A_arbace_math_signum__inliner__446000104_A_init jrt.ClassInit

func A_arbace_math_signum__inliner__446000104_A_Init() { if !A_arbace_math_signum__inliner__446000104_A_init.Done() { A_arbace_math_signum__inliner__446000104_A_init.Run(A_arbace_math_signum__inliner__446000104_A_clinit) } }

func A_arbace_math_signum__inliner__446000104_A_clinit() { A_arbace_math_signum__inliner__446000104_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_signum__inliner__446000104_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_signum__inliner__446000104_A) GetClass__Class() *jrt.Class { return A_arbace_math_signum__inliner__446000104_A_class }

func (t *A_arbace_math_signum__inliner__446000104_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_signum__inliner__446000104_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_signum__inliner__446000104_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_signum__inliner__446000104_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_signum__inliner__446000104_A); return ok }

func A_arbace_math_signum__inliner__446000104_A_Cast(x any) *A_arbace_math_signum__inliner__446000104_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_signum__inliner__446000104_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_signum__inliner__446000104_A_class)) }; return v }



type A_arbace_math_sin_A struct{ jrt.Object }

func (t *A_arbace_math_sin_A) Is_Compiler_AOTF1() {}

var A_arbace_math_sin_A_fn_class *jrt.Class

var A_arbace_math_sin_A_init jrt.ClassInit

func A_arbace_math_sin_A_Init() { if !A_arbace_math_sin_A_init.Done() { A_arbace_math_sin_A_init.Run(A_arbace_math_sin_A_clinit) } }

func A_arbace_math_sin_A_clinit() { A_arbace_math_sin_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_sin_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_sin_A) GetClass__Class() *jrt.Class { return A_arbace_math_sin_A_class }

func (t *A_arbace_math_sin_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_sin_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_sin_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_sin_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_sin_A); return ok }

func A_arbace_math_sin_A_Cast(x any) *A_arbace_math_sin_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_sin_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_sin_A_class)) }; return v }



type A_arbace_math_sin__inliner__446000014_A struct{ jrt.Object }

func (t *A_arbace_math_sin__inliner__446000014_A) Is_Compiler_AOTF1() {}

var A_arbace_math_sin__inliner__446000014_A_fn_class *jrt.Class

var A_arbace_math_sin__inliner__446000014_A_init jrt.ClassInit

func A_arbace_math_sin__inliner__446000014_A_Init() { if !A_arbace_math_sin__inliner__446000014_A_init.Done() { A_arbace_math_sin__inliner__446000014_A_init.Run(A_arbace_math_sin__inliner__446000014_A_clinit) } }

func A_arbace_math_sin__inliner__446000014_A_clinit() { A_arbace_math_sin__inliner__446000014_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_sin__inliner__446000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_sin__inliner__446000014_A) GetClass__Class() *jrt.Class { return A_arbace_math_sin__inliner__446000014_A_class }

func (t *A_arbace_math_sin__inliner__446000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_sin__inliner__446000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_sin__inliner__446000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_sin__inliner__446000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_sin__inliner__446000014_A); return ok }

func A_arbace_math_sin__inliner__446000014_A_Cast(x any) *A_arbace_math_sin__inliner__446000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_sin__inliner__446000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_sin__inliner__446000014_A_class)) }; return v }



type A_arbace_math_sinh_A struct{ jrt.Object }

func (t *A_arbace_math_sinh_A) Is_Compiler_AOTF1() {}

var A_arbace_math_sinh_A_fn_class *jrt.Class

var A_arbace_math_sinh_A_init jrt.ClassInit

func A_arbace_math_sinh_A_Init() { if !A_arbace_math_sinh_A_init.Done() { A_arbace_math_sinh_A_init.Run(A_arbace_math_sinh_A_clinit) } }

func A_arbace_math_sinh_A_clinit() { A_arbace_math_sinh_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_sinh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_sinh_A) GetClass__Class() *jrt.Class { return A_arbace_math_sinh_A_class }

func (t *A_arbace_math_sinh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_sinh_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_sinh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_sinh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_sinh_A); return ok }

func A_arbace_math_sinh_A_Cast(x any) *A_arbace_math_sinh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_sinh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_sinh_A_class)) }; return v }



type A_arbace_math_sinh__inliner__446000107_A struct{ jrt.Object }

func (t *A_arbace_math_sinh__inliner__446000107_A) Is_Compiler_AOTF1() {}

var A_arbace_math_sinh__inliner__446000107_A_fn_class *jrt.Class

var A_arbace_math_sinh__inliner__446000107_A_init jrt.ClassInit

func A_arbace_math_sinh__inliner__446000107_A_Init() { if !A_arbace_math_sinh__inliner__446000107_A_init.Done() { A_arbace_math_sinh__inliner__446000107_A_init.Run(A_arbace_math_sinh__inliner__446000107_A_clinit) } }

func A_arbace_math_sinh__inliner__446000107_A_clinit() { A_arbace_math_sinh__inliner__446000107_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_sinh__inliner__446000107_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_sinh__inliner__446000107_A) GetClass__Class() *jrt.Class { return A_arbace_math_sinh__inliner__446000107_A_class }

func (t *A_arbace_math_sinh__inliner__446000107_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_sinh__inliner__446000107_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_sinh__inliner__446000107_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_sinh__inliner__446000107_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_sinh__inliner__446000107_A); return ok }

func A_arbace_math_sinh__inliner__446000107_A_Cast(x any) *A_arbace_math_sinh__inliner__446000107_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_sinh__inliner__446000107_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_sinh__inliner__446000107_A_class)) }; return v }



type A_arbace_math_sqrt_A struct{ jrt.Object }

func (t *A_arbace_math_sqrt_A) Is_Compiler_AOTF1() {}

var A_arbace_math_sqrt_A_fn_class *jrt.Class

var A_arbace_math_sqrt_A_init jrt.ClassInit

func A_arbace_math_sqrt_A_Init() { if !A_arbace_math_sqrt_A_init.Done() { A_arbace_math_sqrt_A_init.Run(A_arbace_math_sqrt_A_clinit) } }

func A_arbace_math_sqrt_A_clinit() { A_arbace_math_sqrt_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_sqrt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_sqrt_A) GetClass__Class() *jrt.Class { return A_arbace_math_sqrt_A_class }

func (t *A_arbace_math_sqrt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_sqrt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_sqrt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_sqrt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_sqrt_A); return ok }

func A_arbace_math_sqrt_A_Cast(x any) *A_arbace_math_sqrt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_sqrt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_sqrt_A_class)) }; return v }



type A_arbace_math_sqrt__inliner__446000047_A struct{ jrt.Object }

func (t *A_arbace_math_sqrt__inliner__446000047_A) Is_Compiler_AOTF1() {}

var A_arbace_math_sqrt__inliner__446000047_A_fn_class *jrt.Class

var A_arbace_math_sqrt__inliner__446000047_A_init jrt.ClassInit

func A_arbace_math_sqrt__inliner__446000047_A_Init() { if !A_arbace_math_sqrt__inliner__446000047_A_init.Done() { A_arbace_math_sqrt__inliner__446000047_A_init.Run(A_arbace_math_sqrt__inliner__446000047_A_clinit) } }

func A_arbace_math_sqrt__inliner__446000047_A_clinit() { A_arbace_math_sqrt__inliner__446000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_sqrt__inliner__446000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_sqrt__inliner__446000047_A) GetClass__Class() *jrt.Class { return A_arbace_math_sqrt__inliner__446000047_A_class }

func (t *A_arbace_math_sqrt__inliner__446000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_sqrt__inliner__446000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_sqrt__inliner__446000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_sqrt__inliner__446000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_sqrt__inliner__446000047_A); return ok }

func A_arbace_math_sqrt__inliner__446000047_A_Cast(x any) *A_arbace_math_sqrt__inliner__446000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_sqrt__inliner__446000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_sqrt__inliner__446000047_A_class)) }; return v }



type A_arbace_math_subtract_exact_A struct{ jrt.Object }

func (t *A_arbace_math_subtract_exact_A) Is_Compiler_AOTF2() {}

var A_arbace_math_subtract_exact_A_fn_class *jrt.Class

var A_arbace_math_subtract_exact_A_init jrt.ClassInit

func A_arbace_math_subtract_exact_A_Init() { if !A_arbace_math_subtract_exact_A_init.Done() { A_arbace_math_subtract_exact_A_init.Run(A_arbace_math_subtract_exact_A_clinit) } }

func A_arbace_math_subtract_exact_A_clinit() { A_arbace_math_subtract_exact_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_subtract_exact_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_subtract_exact_A) GetClass__Class() *jrt.Class { return A_arbace_math_subtract_exact_A_class }

func (t *A_arbace_math_subtract_exact_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_subtract_exact_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_subtract_exact_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_subtract_exact_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_subtract_exact_A); return ok }

func A_arbace_math_subtract_exact_A_Cast(x any) *A_arbace_math_subtract_exact_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_subtract_exact_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_subtract_exact_A_class)) }; return v }



type A_arbace_math_subtract_exact__inliner__446000080_A struct{ jrt.Object }

func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Is_Compiler_AOTF2() {}

var A_arbace_math_subtract_exact__inliner__446000080_A_fn_class *jrt.Class

var A_arbace_math_subtract_exact__inliner__446000080_A_init jrt.ClassInit

func A_arbace_math_subtract_exact__inliner__446000080_A_Init() { if !A_arbace_math_subtract_exact__inliner__446000080_A_init.Done() { A_arbace_math_subtract_exact__inliner__446000080_A_init.Run(A_arbace_math_subtract_exact__inliner__446000080_A_clinit) } }

func A_arbace_math_subtract_exact__inliner__446000080_A_clinit() { A_arbace_math_subtract_exact__inliner__446000080_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_subtract_exact__inliner__446000080_A) GetClass__Class() *jrt.Class { return A_arbace_math_subtract_exact__inliner__446000080_A_class }

func (t *A_arbace_math_subtract_exact__inliner__446000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_subtract_exact__inliner__446000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_subtract_exact__inliner__446000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_subtract_exact__inliner__446000080_A); return ok }

func A_arbace_math_subtract_exact__inliner__446000080_A_Cast(x any) *A_arbace_math_subtract_exact__inliner__446000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_subtract_exact__inliner__446000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_subtract_exact__inliner__446000080_A_class)) }; return v }



type A_arbace_math_tan_A struct{ jrt.Object }

func (t *A_arbace_math_tan_A) Is_Compiler_AOTF1() {}

var A_arbace_math_tan_A_fn_class *jrt.Class

var A_arbace_math_tan_A_init jrt.ClassInit

func A_arbace_math_tan_A_Init() { if !A_arbace_math_tan_A_init.Done() { A_arbace_math_tan_A_init.Run(A_arbace_math_tan_A_clinit) } }

func A_arbace_math_tan_A_clinit() { A_arbace_math_tan_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_tan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_tan_A) GetClass__Class() *jrt.Class { return A_arbace_math_tan_A_class }

func (t *A_arbace_math_tan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_tan_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_tan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_tan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_tan_A); return ok }

func A_arbace_math_tan_A_Cast(x any) *A_arbace_math_tan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_tan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_tan_A_class)) }; return v }



type A_arbace_math_tan__inliner__446000020_A struct{ jrt.Object }

func (t *A_arbace_math_tan__inliner__446000020_A) Is_Compiler_AOTF1() {}

var A_arbace_math_tan__inliner__446000020_A_fn_class *jrt.Class

var A_arbace_math_tan__inliner__446000020_A_init jrt.ClassInit

func A_arbace_math_tan__inliner__446000020_A_Init() { if !A_arbace_math_tan__inliner__446000020_A_init.Done() { A_arbace_math_tan__inliner__446000020_A_init.Run(A_arbace_math_tan__inliner__446000020_A_clinit) } }

func A_arbace_math_tan__inliner__446000020_A_clinit() { A_arbace_math_tan__inliner__446000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_tan__inliner__446000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_tan__inliner__446000020_A) GetClass__Class() *jrt.Class { return A_arbace_math_tan__inliner__446000020_A_class }

func (t *A_arbace_math_tan__inliner__446000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_tan__inliner__446000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_tan__inliner__446000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_tan__inliner__446000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_tan__inliner__446000020_A); return ok }

func A_arbace_math_tan__inliner__446000020_A_Cast(x any) *A_arbace_math_tan__inliner__446000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_tan__inliner__446000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_tan__inliner__446000020_A_class)) }; return v }



type A_arbace_math_tanh_A struct{ jrt.Object }

func (t *A_arbace_math_tanh_A) Is_Compiler_AOTF1() {}

var A_arbace_math_tanh_A_fn_class *jrt.Class

var A_arbace_math_tanh_A_init jrt.ClassInit

func A_arbace_math_tanh_A_Init() { if !A_arbace_math_tanh_A_init.Done() { A_arbace_math_tanh_A_init.Run(A_arbace_math_tanh_A_clinit) } }

func A_arbace_math_tanh_A_clinit() { A_arbace_math_tanh_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_tanh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_tanh_A) GetClass__Class() *jrt.Class { return A_arbace_math_tanh_A_class }

func (t *A_arbace_math_tanh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_tanh_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_tanh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_tanh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_tanh_A); return ok }

func A_arbace_math_tanh_A_Cast(x any) *A_arbace_math_tanh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_tanh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_tanh_A_class)) }; return v }



type A_arbace_math_tanh__inliner__446000113_A struct{ jrt.Object }

func (t *A_arbace_math_tanh__inliner__446000113_A) Is_Compiler_AOTF1() {}

var A_arbace_math_tanh__inliner__446000113_A_fn_class *jrt.Class

var A_arbace_math_tanh__inliner__446000113_A_init jrt.ClassInit

func A_arbace_math_tanh__inliner__446000113_A_Init() { if !A_arbace_math_tanh__inliner__446000113_A_init.Done() { A_arbace_math_tanh__inliner__446000113_A_init.Run(A_arbace_math_tanh__inliner__446000113_A_clinit) } }

func A_arbace_math_tanh__inliner__446000113_A_clinit() { A_arbace_math_tanh__inliner__446000113_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_tanh__inliner__446000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_tanh__inliner__446000113_A) GetClass__Class() *jrt.Class { return A_arbace_math_tanh__inliner__446000113_A_class }

func (t *A_arbace_math_tanh__inliner__446000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_tanh__inliner__446000113_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_tanh__inliner__446000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_tanh__inliner__446000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_tanh__inliner__446000113_A); return ok }

func A_arbace_math_tanh__inliner__446000113_A_Cast(x any) *A_arbace_math_tanh__inliner__446000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_tanh__inliner__446000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_tanh__inliner__446000113_A_class)) }; return v }



type A_arbace_math_to_degrees_A struct{ jrt.Object }

func (t *A_arbace_math_to_degrees_A) Is_Compiler_AOTF1() {}

var A_arbace_math_to_degrees_A_fn_class *jrt.Class

var A_arbace_math_to_degrees_A_init jrt.ClassInit

func A_arbace_math_to_degrees_A_Init() { if !A_arbace_math_to_degrees_A_init.Done() { A_arbace_math_to_degrees_A_init.Run(A_arbace_math_to_degrees_A_clinit) } }

func A_arbace_math_to_degrees_A_clinit() { A_arbace_math_to_degrees_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_to_degrees_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_to_degrees_A) GetClass__Class() *jrt.Class { return A_arbace_math_to_degrees_A_class }

func (t *A_arbace_math_to_degrees_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_to_degrees_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_to_degrees_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_to_degrees_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_to_degrees_A); return ok }

func A_arbace_math_to_degrees_A_Cast(x any) *A_arbace_math_to_degrees_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_to_degrees_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_to_degrees_A_class)) }; return v }



type A_arbace_math_to_degrees__inliner__446000035_A struct{ jrt.Object }

func (t *A_arbace_math_to_degrees__inliner__446000035_A) Is_Compiler_AOTF1() {}

var A_arbace_math_to_degrees__inliner__446000035_A_fn_class *jrt.Class

var A_arbace_math_to_degrees__inliner__446000035_A_init jrt.ClassInit

func A_arbace_math_to_degrees__inliner__446000035_A_Init() { if !A_arbace_math_to_degrees__inliner__446000035_A_init.Done() { A_arbace_math_to_degrees__inliner__446000035_A_init.Run(A_arbace_math_to_degrees__inliner__446000035_A_clinit) } }

func A_arbace_math_to_degrees__inliner__446000035_A_clinit() { A_arbace_math_to_degrees__inliner__446000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_to_degrees__inliner__446000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_to_degrees__inliner__446000035_A) GetClass__Class() *jrt.Class { return A_arbace_math_to_degrees__inliner__446000035_A_class }

func (t *A_arbace_math_to_degrees__inliner__446000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_to_degrees__inliner__446000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_to_degrees__inliner__446000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_to_degrees__inliner__446000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_to_degrees__inliner__446000035_A); return ok }

func A_arbace_math_to_degrees__inliner__446000035_A_Cast(x any) *A_arbace_math_to_degrees__inliner__446000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_to_degrees__inliner__446000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_to_degrees__inliner__446000035_A_class)) }; return v }



type A_arbace_math_to_radians_A struct{ jrt.Object }

func (t *A_arbace_math_to_radians_A) Is_Compiler_AOTF1() {}

var A_arbace_math_to_radians_A_fn_class *jrt.Class

var A_arbace_math_to_radians_A_init jrt.ClassInit

func A_arbace_math_to_radians_A_Init() { if !A_arbace_math_to_radians_A_init.Done() { A_arbace_math_to_radians_A_init.Run(A_arbace_math_to_radians_A_clinit) } }

func A_arbace_math_to_radians_A_clinit() { A_arbace_math_to_radians_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_to_radians_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_to_radians_A) GetClass__Class() *jrt.Class { return A_arbace_math_to_radians_A_class }

func (t *A_arbace_math_to_radians_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_to_radians_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_to_radians_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_to_radians_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_to_radians_A); return ok }

func A_arbace_math_to_radians_A_Cast(x any) *A_arbace_math_to_radians_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_to_radians_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_to_radians_A_class)) }; return v }



type A_arbace_math_to_radians__inliner__446000032_A struct{ jrt.Object }

func (t *A_arbace_math_to_radians__inliner__446000032_A) Is_Compiler_AOTF1() {}

var A_arbace_math_to_radians__inliner__446000032_A_fn_class *jrt.Class

var A_arbace_math_to_radians__inliner__446000032_A_init jrt.ClassInit

func A_arbace_math_to_radians__inliner__446000032_A_Init() { if !A_arbace_math_to_radians__inliner__446000032_A_init.Done() { A_arbace_math_to_radians__inliner__446000032_A_init.Run(A_arbace_math_to_radians__inliner__446000032_A_clinit) } }

func A_arbace_math_to_radians__inliner__446000032_A_clinit() { A_arbace_math_to_radians__inliner__446000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_146, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_to_radians__inliner__446000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_to_radians__inliner__446000032_A) GetClass__Class() *jrt.Class { return A_arbace_math_to_radians__inliner__446000032_A_class }

func (t *A_arbace_math_to_radians__inliner__446000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_to_radians__inliner__446000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_to_radians__inliner__446000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_to_radians__inliner__446000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_to_radians__inliner__446000032_A); return ok }

func A_arbace_math_to_radians__inliner__446000032_A_Cast(x any) *A_arbace_math_to_radians__inliner__446000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_to_radians__inliner__446000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_to_radians__inliner__446000032_A_class)) }; return v }



type A_arbace_math_ulp_A struct{ jrt.Object }

func (t *A_arbace_math_ulp_A) Is_Compiler_AOTF1() {}

var A_arbace_math_ulp_A_fn_class *jrt.Class

var A_arbace_math_ulp_A_init jrt.ClassInit

func A_arbace_math_ulp_A_Init() { if !A_arbace_math_ulp_A_init.Done() { A_arbace_math_ulp_A_init.Run(A_arbace_math_ulp_A_clinit) } }

func A_arbace_math_ulp_A_clinit() { A_arbace_math_ulp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_ulp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_ulp_A) GetClass__Class() *jrt.Class { return A_arbace_math_ulp_A_class }

func (t *A_arbace_math_ulp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_ulp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_ulp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_ulp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_ulp_A); return ok }

func A_arbace_math_ulp_A_Cast(x any) *A_arbace_math_ulp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_ulp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_ulp_A_class)) }; return v }



type A_arbace_math_ulp__inliner__446000101_A struct{ jrt.Object }

func (t *A_arbace_math_ulp__inliner__446000101_A) Is_Compiler_AOTF1() {}

var A_arbace_math_ulp__inliner__446000101_A_fn_class *jrt.Class

var A_arbace_math_ulp__inliner__446000101_A_init jrt.ClassInit

func A_arbace_math_ulp__inliner__446000101_A_Init() { if !A_arbace_math_ulp__inliner__446000101_A_init.Done() { A_arbace_math_ulp__inliner__446000101_A_init.Run(A_arbace_math_ulp__inliner__446000101_A_clinit) } }

func A_arbace_math_ulp__inliner__446000101_A_clinit() { A_arbace_math_ulp__inliner__446000101_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_math_ulp__inliner__446000101_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_ulp__inliner__446000101_A) GetClass__Class() *jrt.Class { return A_arbace_math_ulp__inliner__446000101_A_class }

func (t *A_arbace_math_ulp__inliner__446000101_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_ulp__inliner__446000101_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math_ulp__inliner__446000101_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_ulp__inliner__446000101_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_ulp__inliner__446000101_A); return ok }

func A_arbace_math_ulp__inliner__446000101_A_Cast(x any) *A_arbace_math_ulp__inliner__446000101_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_ulp__inliner__446000101_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_ulp__inliner__446000101_A_class)) }; return v }
