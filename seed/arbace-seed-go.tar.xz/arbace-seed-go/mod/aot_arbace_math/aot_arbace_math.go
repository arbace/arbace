//line aot_arbace_math.ae:1
package aot_arbace_math

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New() *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A { A_arbace_math_A_Init(); t := &A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_math_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_math_eval446000008_fn__446000009_A_New() *A_arbace_math_eval446000008_fn__446000009_A { A_arbace_math_A_Init(); t := &A_arbace_math_eval446000008_fn__446000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_math_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_math_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_math_A_const_5.GetRawRoot__O(), A_arbace_math_A_const_6) }
































func A_arbace_math_sin_A_New() *A_arbace_math_sin_A { A_arbace_math_A_Init(); t := &A_arbace_math_sin_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Sin_D__D(a__0)).Ref() }
//line :42:1
func A_arbace_math_sin__inliner__446000014_A_New() *A_arbace_math_sin__inliner__446000014_A { A_arbace_math_A_Init(); t := &A_arbace_math_sin__inliner__446000014_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Invoke_O_O__O(self, a__0 any) any { var root_29 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any; var root_24 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_10); var arg_28 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any; var root_15 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_11); var arg_19 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_16 == nil { arg_23 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { arg_23 = linked_16.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_20, arg_23) }; arg_28 = tmp1.Invoke_O__O(tmp2); if linked_25 == nil { arg_32 = ifn_26.Invoke_O_O__O(arg_27, arg_28) } else { arg_32 = linked_25.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_24, arg_27, arg_28) }; if linked_30 == nil { return ifn_31.Invoke_O__O(arg_32) } else { return linked_30.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_29, arg_32) } }










func A_arbace_math_cos_A_New() *A_arbace_math_cos_A { A_arbace_math_A_Init(); t := &A_arbace_math_cos_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Cos_D__D(a__0)).Ref() }
//line :53:1
func A_arbace_math_cos__inliner__446000017_A_New() *A_arbace_math_cos__inliner__446000017_A { A_arbace_math_A_Init(); t := &A_arbace_math_cos__inliner__446000017_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Invoke_O_O__O(self, a__0 any) any { var root_47 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any; var root_42 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_12); var arg_46 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_38 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var root_33 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_13); var arg_37 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_34 == nil { arg_41 = ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { arg_41 = linked_34.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) }; if linked_39 == nil { tmp2 = ifn_40.Invoke_O__O(arg_41) } else { tmp2 = linked_39.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_38, arg_41) }; arg_46 = tmp1.Invoke_O__O(tmp2); if linked_43 == nil { arg_50 = ifn_44.Invoke_O_O__O(arg_45, arg_46) } else { arg_50 = linked_43.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_42, arg_45, arg_46) }; if linked_48 == nil { return ifn_49.Invoke_O__O(arg_50) } else { return linked_48.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_47, arg_50) } }









func A_arbace_math_tan_A_New() *A_arbace_math_tan_A { A_arbace_math_A_Init(); t := &A_arbace_math_tan_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Tan_D__D(a__0)).Ref() }
//line :63:1
func A_arbace_math_tan__inliner__446000020_A_New() *A_arbace_math_tan__inliner__446000020_A { A_arbace_math_A_Init(); t := &A_arbace_math_tan__inliner__446000020_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Invoke_O_O__O(self, a__0 any) any { var root_65 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any; var root_60 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_14); var arg_64 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_56 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any; var root_51 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_15); var arg_55 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_52 == nil { arg_59 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { arg_59 = linked_52.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; if linked_57 == nil { tmp2 = ifn_58.Invoke_O__O(arg_59) } else { tmp2 = linked_57.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_56, arg_59) }; arg_64 = tmp1.Invoke_O__O(tmp2); if linked_61 == nil { arg_68 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { arg_68 = linked_61.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; if linked_66 == nil { return ifn_67.Invoke_O__O(arg_68) } else { return linked_66.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_65, arg_68) } }










func A_arbace_math_asin_A_New() *A_arbace_math_asin_A { A_arbace_math_A_Init(); t := &A_arbace_math_asin_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Asin_D__D(a__0)).Ref() }
//line :74:1
func A_arbace_math_asin__inliner__446000023_A_New() *A_arbace_math_asin__inliner__446000023_A { A_arbace_math_A_Init(); t := &A_arbace_math_asin__inliner__446000023_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Invoke_O_O__O(self, a__0 any) any { var root_83 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any; var root_78 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_16); var arg_82 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_74 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var root_69 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_17); var arg_73 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_70 == nil { arg_77 = ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { arg_77 = linked_70.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_69, arg_72, arg_73) }; if linked_75 == nil { tmp2 = ifn_76.Invoke_O__O(arg_77) } else { tmp2 = linked_75.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_74, arg_77) }; arg_82 = tmp1.Invoke_O__O(tmp2); if linked_79 == nil { arg_86 = ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { arg_86 = linked_79.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_78, arg_81, arg_82) }; if linked_84 == nil { return ifn_85.Invoke_O__O(arg_86) } else { return linked_84.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_83, arg_86) } }










func A_arbace_math_acos_A_New() *A_arbace_math_acos_A { A_arbace_math_A_Init(); t := &A_arbace_math_acos_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Acos_D__D(a__0)).Ref() }
//line :85:1
func A_arbace_math_acos__inliner__446000026_A_New() *A_arbace_math_acos__inliner__446000026_A { A_arbace_math_A_Init(); t := &A_arbace_math_acos__inliner__446000026_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Invoke_O_O__O(self, a__0 any) any { var root_101 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any; var root_96 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_18); var arg_100 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_92 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var root_87 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_19); var arg_91 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_88 == nil { arg_95 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { arg_95 = linked_88.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }; if linked_93 == nil { tmp2 = ifn_94.Invoke_O__O(arg_95) } else { tmp2 = linked_93.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_92, arg_95) }; arg_100 = tmp1.Invoke_O__O(tmp2); if linked_97 == nil { arg_104 = ifn_98.Invoke_O_O__O(arg_99, arg_100) } else { arg_104 = linked_97.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_96, arg_99, arg_100) }; if linked_102 == nil { return ifn_103.Invoke_O__O(arg_104) } else { return linked_102.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_101, arg_104) } }









func A_arbace_math_atan_A_New() *A_arbace_math_atan_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Atan_D__D(a__0)).Ref() }
//line :95:1
func A_arbace_math_atan__inliner__446000029_A_New() *A_arbace_math_atan__inliner__446000029_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan__inliner__446000029_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Invoke_O_O__O(self, a__0 any) any { var root_119 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var root_114 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_20); var arg_118 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_110 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var root_105 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_21); var arg_109 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_106 == nil { arg_113 = ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { arg_113 = linked_106.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) }; if linked_111 == nil { tmp2 = ifn_112.Invoke_O__O(arg_113) } else { tmp2 = linked_111.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_110, arg_113) }; arg_118 = tmp1.Invoke_O__O(tmp2); if linked_115 == nil { arg_122 = ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { arg_122 = linked_115.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) }; if linked_120 == nil { return ifn_121.Invoke_O__O(arg_122) } else { return linked_120.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_119, arg_122) } }










func A_arbace_math_to_radians_A_New() *A_arbace_math_to_radians_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_radians_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians_A) Invoke_O_O__O(self, p_deg__0 any) any { var deg__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_deg__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_ToRadians_D__D(deg__0)).Ref() }
//line :106:1
func A_arbace_math_to_radians__inliner__446000032_A_New() *A_arbace_math_to_radians__inliner__446000032_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_radians__inliner__446000032_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Invoke_O_O__O(self, deg__0 any) any { var root_137 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_132 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_22); var arg_136 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_128 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any; var root_123 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_23); var arg_127 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(deg__0); if linked_124 == nil { arg_131 = ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { arg_131 = linked_124.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; if linked_129 == nil { tmp2 = ifn_130.Invoke_O__O(arg_131) } else { tmp2 = linked_129.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_128, arg_131) }; arg_136 = tmp1.Invoke_O__O(tmp2); if linked_133 == nil { arg_140 = ifn_134.Invoke_O_O__O(arg_135, arg_136) } else { arg_140 = linked_133.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_132, arg_135, arg_136) }; if linked_138 == nil { return ifn_139.Invoke_O__O(arg_140) } else { return linked_138.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_137, arg_140) } }








func A_arbace_math_to_degrees_A_New() *A_arbace_math_to_degrees_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_degrees_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees_A) Invoke_O_O__O(self, p_r__0 any) any { var r__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_r__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_ToDegrees_D__D(r__0)).Ref() }
//line :115:1
func A_arbace_math_to_degrees__inliner__446000035_A_New() *A_arbace_math_to_degrees__inliner__446000035_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_degrees__inliner__446000035_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Invoke_O_O__O(self, r__0 any) any { var root_155 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_150 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_24); var arg_154 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_146 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_141 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_25); var arg_145 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(r__0); if linked_142 == nil { arg_149 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { arg_149 = linked_142.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }; if linked_147 == nil { tmp2 = ifn_148.Invoke_O__O(arg_149) } else { tmp2 = linked_147.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_146, arg_149) }; arg_154 = tmp1.Invoke_O__O(tmp2); if linked_151 == nil { arg_158 = ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { arg_158 = linked_151.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_150, arg_153, arg_154) }; if linked_156 == nil { return ifn_157.Invoke_O__O(arg_158) } else { return linked_156.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_155, arg_158) } }








func A_arbace_math_exp_A_New() *A_arbace_math_exp_A { A_arbace_math_A_Init(); t := &A_arbace_math_exp_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Exp_D__D(a__0)).Ref() }
//line :124:1
func A_arbace_math_exp__inliner__446000038_A_New() *A_arbace_math_exp__inliner__446000038_A { A_arbace_math_A_Init(); t := &A_arbace_math_exp__inliner__446000038_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Invoke_O_O__O(self, a__0 any) any { var root_173 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_168 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_26); var arg_172 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_164 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any; var root_159 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_27); var arg_163 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_160 == nil { arg_167 = ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { arg_167 = linked_160.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; if linked_165 == nil { tmp2 = ifn_166.Invoke_O__O(arg_167) } else { tmp2 = linked_165.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_164, arg_167) }; arg_172 = tmp1.Invoke_O__O(tmp2); if linked_169 == nil { arg_176 = ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { arg_176 = linked_169.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) }; if linked_174 == nil { return ifn_175.Invoke_O__O(arg_176) } else { return linked_174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_173, arg_176) } }











func A_arbace_math_log_A_New() *A_arbace_math_log_A { A_arbace_math_A_Init(); t := &A_arbace_math_log_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Log_D__D(a__0)).Ref() }
//line :136:1
func A_arbace_math_log__inliner__446000041_A_New() *A_arbace_math_log__inliner__446000041_A { A_arbace_math_A_Init(); t := &A_arbace_math_log__inliner__446000041_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Invoke_O_O__O(self, a__0 any) any { var root_191 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any; var root_186 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_28); var arg_190 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_182 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_177 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_29); var arg_181 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_178 == nil { arg_185 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { arg_185 = linked_178.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }; if linked_183 == nil { tmp2 = ifn_184.Invoke_O__O(arg_185) } else { tmp2 = linked_183.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_182, arg_185) }; arg_190 = tmp1.Invoke_O__O(tmp2); if linked_187 == nil { arg_194 = ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { arg_194 = linked_187.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_186, arg_189, arg_190) }; if linked_192 == nil { return ifn_193.Invoke_O__O(arg_194) } else { return linked_192.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_191, arg_194) } }











func A_arbace_math_log10_A_New() *A_arbace_math_log10_A { A_arbace_math_A_Init(); t := &A_arbace_math_log10_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Log10_D__D(a__0)).Ref() }
//line :148:1
func A_arbace_math_log10__inliner__446000044_A_New() *A_arbace_math_log10__inliner__446000044_A { A_arbace_math_A_Init(); t := &A_arbace_math_log10__inliner__446000044_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Invoke_O_O__O(self, a__0 any) any { var root_209 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var root_204 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_30); var arg_208 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_200 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_195 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_31); var arg_199 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_196 == nil { arg_203 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { arg_203 = linked_196.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }; if linked_201 == nil { tmp2 = ifn_202.Invoke_O__O(arg_203) } else { tmp2 = linked_201.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_200, arg_203) }; arg_208 = tmp1.Invoke_O__O(tmp2); if linked_205 == nil { arg_212 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { arg_212 = linked_205.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; if linked_210 == nil { return ifn_211.Invoke_O__O(arg_212) } else { return linked_210.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_209, arg_212) } }











func A_arbace_math_sqrt_A_New() *A_arbace_math_sqrt_A { A_arbace_math_A_Init(); t := &A_arbace_math_sqrt_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Sqrt_D__D(a__0)).Ref() }
//line :160:1
func A_arbace_math_sqrt__inliner__446000047_A_New() *A_arbace_math_sqrt__inliner__446000047_A { A_arbace_math_A_Init(); t := &A_arbace_math_sqrt__inliner__446000047_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Invoke_O_O__O(self, a__0 any) any { var root_227 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any; var root_222 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_32); var arg_226 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_218 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any; var root_213 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_33); var arg_217 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_214 == nil { arg_221 = ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { arg_221 = linked_214.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }; if linked_219 == nil { tmp2 = ifn_220.Invoke_O__O(arg_221) } else { tmp2 = linked_219.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_218, arg_221) }; arg_226 = tmp1.Invoke_O__O(tmp2); if linked_223 == nil { arg_230 = ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { arg_230 = linked_223.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }; if linked_228 == nil { return ifn_229.Invoke_O__O(arg_230) } else { return linked_228.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_227, arg_230) } }











func A_arbace_math_cbrt_A_New() *A_arbace_math_cbrt_A { A_arbace_math_A_Init(); t := &A_arbace_math_cbrt_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Cbrt_D__D(a__0)).Ref() }
//line :172:1
func A_arbace_math_cbrt__inliner__446000050_A_New() *A_arbace_math_cbrt__inliner__446000050_A { A_arbace_math_A_Init(); t := &A_arbace_math_cbrt__inliner__446000050_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Invoke_O_O__O(self, a__0 any) any { var root_245 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var root_240 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_34); var arg_244 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_236 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var root_231 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_35); var arg_235 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_232 == nil { arg_239 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { arg_239 = linked_232.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }; if linked_237 == nil { tmp2 = ifn_238.Invoke_O__O(arg_239) } else { tmp2 = linked_237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_236, arg_239) }; arg_244 = tmp1.Invoke_O__O(tmp2); if linked_241 == nil { arg_248 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { arg_248 = linked_241.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }; if linked_246 == nil { return ifn_247.Invoke_O__O(arg_248) } else { return linked_246.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_245, arg_248) } }











func A_arbace_math_IEEE_remainder_A_New() *A_arbace_math_IEEE_remainder_A { A_arbace_math_A_Init(); t := &A_arbace_math_IEEE_remainder_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Invoke_O_O_O__O(self, p_dividend__0, p_divisor__1 any) any { var dividend__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_dividend__0); var divisor__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_divisor__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_IEEEremainder_D_D__D(dividend__0, divisor__1)).Ref() }
//line :184:1
func A_arbace_math_IEEE_remainder__inliner__446000053_A_New() *A_arbace_math_IEEE_remainder__inliner__446000053_A { A_arbace_math_A_Init(); t := &A_arbace_math_IEEE_remainder__inliner__446000053_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Invoke_O_O_O__O(self, dividend__0, divisor__1 any) any { var root_273 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_36); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_254 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_249 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_37); var arg_253 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(dividend__0); if linked_250 == nil { arg_257 = ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { arg_257 = linked_250.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_249, arg_252, arg_253) }; if linked_255 == nil { tmp4 = ifn_256.Invoke_O__O(arg_257) } else { tmp4 = linked_255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_254, arg_257) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_263 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any; var root_258 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_38); var arg_262 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(divisor__1); if linked_259 == nil { arg_266 = ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { arg_266 = linked_259.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_258, arg_261, arg_262) }; if linked_264 == nil { tmp7 = ifn_265.Invoke_O__O(arg_266) } else { tmp7 = linked_264.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_263, arg_266) }; arg_276 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_274 == nil { return ifn_275.Invoke_O__O(arg_276) } else { return linked_274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_273, arg_276) } }














func A_arbace_math_ceil_A_New() *A_arbace_math_ceil_A { A_arbace_math_A_Init(); t := &A_arbace_math_ceil_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Ceil_D__D(a__0)).Ref() }
//line :199:1
func A_arbace_math_ceil__inliner__446000056_A_New() *A_arbace_math_ceil__inliner__446000056_A { A_arbace_math_A_Init(); t := &A_arbace_math_ceil__inliner__446000056_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Invoke_O_O__O(self, a__0 any) any { var root_291 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any; var root_286 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_39); var arg_290 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_282 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var root_277 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_40); var arg_281 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_278 == nil { arg_285 = ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { arg_285 = linked_278.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) }; if linked_283 == nil { tmp2 = ifn_284.Invoke_O__O(arg_285) } else { tmp2 = linked_283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_282, arg_285) }; arg_290 = tmp1.Invoke_O__O(tmp2); if linked_287 == nil { arg_294 = ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { arg_294 = linked_287.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) }; if linked_292 == nil { return ifn_293.Invoke_O__O(arg_294) } else { return linked_292.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_291, arg_294) } }











func A_arbace_math_floor_A_New() *A_arbace_math_floor_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Floor_D__D(a__0)).Ref() }
//line :211:1
func A_arbace_math_floor__inliner__446000059_A_New() *A_arbace_math_floor__inliner__446000059_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor__inliner__446000059_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Invoke_O_O__O(self, a__0 any) any { var root_309 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var root_304 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_41); var arg_308 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_300 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var root_295 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_42); var arg_299 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_296 == nil { arg_303 = ifn_297.Invoke_O_O__O(arg_298, arg_299) } else { arg_303 = linked_296.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_295, arg_298, arg_299) }; if linked_301 == nil { tmp2 = ifn_302.Invoke_O__O(arg_303) } else { tmp2 = linked_301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_300, arg_303) }; arg_308 = tmp1.Invoke_O__O(tmp2); if linked_305 == nil { arg_312 = ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { arg_312 = linked_305.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) }; if linked_310 == nil { return ifn_311.Invoke_O__O(arg_312) } else { return linked_310.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_309, arg_312) } }










func A_arbace_math_rint_A_New() *A_arbace_math_rint_A { A_arbace_math_A_Init(); t := &A_arbace_math_rint_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Rint_D__D(a__0)).Ref() }
//line :222:1
func A_arbace_math_rint__inliner__446000062_A_New() *A_arbace_math_rint__inliner__446000062_A { A_arbace_math_A_Init(); t := &A_arbace_math_rint__inliner__446000062_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Invoke_O_O__O(self, a__0 any) any { var root_327 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any; var root_322 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_43); var arg_326 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_318 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any; var root_313 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_44); var arg_317 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_314 == nil { arg_321 = ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { arg_321 = linked_314.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) }; if linked_319 == nil { tmp2 = ifn_320.Invoke_O__O(arg_321) } else { tmp2 = linked_319.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_318, arg_321) }; arg_326 = tmp1.Invoke_O__O(tmp2); if linked_323 == nil { arg_330 = ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { arg_330 = linked_323.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) }; if linked_328 == nil { return ifn_329.Invoke_O__O(arg_330) } else { return linked_328.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_327, arg_330) } }










func A_arbace_math_atan2_A_New() *A_arbace_math_atan2_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan2_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2_A) Invoke_O_O_O__O(self, p_y__0, p_x__1 any) any { var y__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_y__0); var x__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Atan2_D_D__D(y__0, x__1)).Ref() }
//line :233:1
func A_arbace_math_atan2__inliner__446000065_A_New() *A_arbace_math_atan2__inliner__446000065_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan2__inliner__446000065_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Invoke_O_O_O__O(self, y__0, x__1 any) any { var root_355 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_45); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_336 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any; var root_331 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_46); var arg_335 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__0); if linked_332 == nil { arg_339 = ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { arg_339 = linked_332.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) }; if linked_337 == nil { tmp4 = ifn_338.Invoke_O__O(arg_339) } else { tmp4 = linked_337.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_336, arg_339) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_345 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any; var root_340 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_47); var arg_344 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__1); if linked_341 == nil { arg_348 = ifn_342.Invoke_O_O__O(arg_343, arg_344) } else { arg_348 = linked_341.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_340, arg_343, arg_344) }; if linked_346 == nil { tmp7 = ifn_347.Invoke_O__O(arg_348) } else { tmp7 = linked_346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_345, arg_348) }; arg_358 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_356 == nil { return ifn_357.Invoke_O__O(arg_358) } else { return linked_356.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_355, arg_358) } }










func A_arbace_math_pow_A_New() *A_arbace_math_pow_A { A_arbace_math_A_Init(); t := &A_arbace_math_pow_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow_A) Invoke_O_O_O__O(self, p_a__0, p_b__1 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); var b__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_b__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Pow_D_D__D(a__0, b__1)).Ref() }
//line :244:1
func A_arbace_math_pow__inliner__446000068_A_New() *A_arbace_math_pow__inliner__446000068_A { A_arbace_math_A_Init(); t := &A_arbace_math_pow__inliner__446000068_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var root_383 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_48); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_364 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any; var root_359 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_49); var arg_363 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_360 == nil { arg_367 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { arg_367 = linked_360.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if linked_365 == nil { tmp4 = ifn_366.Invoke_O__O(arg_367) } else { tmp4 = linked_365.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_364, arg_367) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_373 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any; var root_368 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_50); var arg_372 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(b__1); if linked_369 == nil { arg_376 = ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { arg_376 = linked_369.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_368, arg_371, arg_372) }; if linked_374 == nil { tmp7 = ifn_375.Invoke_O__O(arg_376) } else { tmp7 = linked_374.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_373, arg_376) }; arg_386 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_384 == nil { return ifn_385.Invoke_O__O(arg_386) } else { return linked_384.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_383, arg_386) } }









func A_arbace_math_round_A_New() *A_arbace_math_round_A { A_arbace_math_A_Init(); t := &A_arbace_math_round_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_Round_D__J(a__0)).Ref() }
//line :254:1
func A_arbace_math_round__inliner__446000071_A_New() *A_arbace_math_round__inliner__446000071_A { A_arbace_math_A_Init(); t := &A_arbace_math_round__inliner__446000071_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Invoke_O_O__O(self, a__0 any) any { var root_401 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any; var root_396 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_51); var arg_400 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_392 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any; var root_387 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_52); var arg_391 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_388 == nil { arg_395 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { arg_395 = linked_388.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if linked_393 == nil { tmp2 = ifn_394.Invoke_O__O(arg_395) } else { tmp2 = linked_393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_392, arg_395) }; arg_400 = tmp1.Invoke_O__O(tmp2); if linked_397 == nil { arg_404 = ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { arg_404 = linked_397.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) }; if linked_402 == nil { return ifn_403.Invoke_O__O(arg_404) } else { return linked_402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_401, arg_404) } }












func A_arbace_math_random_A_New() *A_arbace_math_random_A { A_arbace_math_A_Init(); t := &A_arbace_math_random_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random_A) Invoke_O__O(self any) any { return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Random__D()).Ref() }
//line :267:1
func A_arbace_math_random__inliner__446000074_A_New() *A_arbace_math_random__inliner__446000074_A { A_arbace_math_A_Init(); t := &A_arbace_math_random__inliner__446000074_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Invoke_O__O(self any) any { var root_409 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any; var root_405 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_53); if linked_406 == nil { arg_412 = ifn_407.Invoke_O__O(arg_408) } else { arg_412 = linked_406.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_405, arg_408) }; if linked_410 == nil { return ifn_411.Invoke_O__O(arg_412) } else { return linked_410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_409, arg_412) } }









func A_arbace_math_add_exact_A_New() *A_arbace_math_add_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_add_exact_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_AddExact_J_J__J(x__0, y__1)).Ref() }
//line :277:1
func A_arbace_math_add_exact__inliner__446000077_A_New() *A_arbace_math_add_exact__inliner__446000077_A { A_arbace_math_A_Init(); t := &A_arbace_math_add_exact__inliner__446000077_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_437 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_54); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_418 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any; var root_413 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_55); var arg_417 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_414 == nil { arg_421 = ifn_415.Invoke_O_O__O(arg_416, arg_417) } else { arg_421 = linked_414.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_413, arg_416, arg_417) }; if linked_419 == nil { tmp4 = ifn_420.Invoke_O__O(arg_421) } else { tmp4 = linked_419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_418, arg_421) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_427 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var root_422 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_56); var arg_426 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_423 == nil { arg_430 = ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { arg_430 = linked_423.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) }; if linked_428 == nil { tmp7 = ifn_429.Invoke_O__O(arg_430) } else { tmp7 = linked_428.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_427, arg_430) }; arg_440 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_438 == nil { return ifn_439.Invoke_O__O(arg_440) } else { return linked_438.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_437, arg_440) } }








func A_arbace_math_subtract_exact_A_New() *A_arbace_math_subtract_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_subtract_exact_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_SubtractExact_J_J__J(x__0, y__1)).Ref() }
//line :286:1
func A_arbace_math_subtract_exact__inliner__446000080_A_New() *A_arbace_math_subtract_exact__inliner__446000080_A { A_arbace_math_A_Init(); t := &A_arbace_math_subtract_exact__inliner__446000080_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_465 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_57); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_446 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; var root_441 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_58); var arg_445 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_442 == nil { arg_449 = ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { arg_449 = linked_442.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_441, arg_444, arg_445) }; if linked_447 == nil { tmp4 = ifn_448.Invoke_O__O(arg_449) } else { tmp4 = linked_447.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_446, arg_449) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_455 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_457 lang.IFn; if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any; var root_450 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_59); var arg_454 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_451 == nil { arg_458 = ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { arg_458 = linked_451.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) }; if linked_456 == nil { tmp7 = ifn_457.Invoke_O__O(arg_458) } else { tmp7 = linked_456.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_455, arg_458) }; arg_468 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_466 == nil { return ifn_467.Invoke_O__O(arg_468) } else { return linked_466.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_465, arg_468) } }








func A_arbace_math_multiply_exact_A_New() *A_arbace_math_multiply_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_multiply_exact_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_MultiplyExact_J_J__J(x__0, y__1)).Ref() }
//line :295:1
func A_arbace_math_multiply_exact__inliner__446000083_A_New() *A_arbace_math_multiply_exact__inliner__446000083_A { A_arbace_math_A_Init(); t := &A_arbace_math_multiply_exact__inliner__446000083_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_493 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_60); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_474 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any; var root_469 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_61); var arg_473 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_470 == nil { arg_477 = ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { arg_477 = linked_470.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) }; if linked_475 == nil { tmp4 = ifn_476.Invoke_O__O(arg_477) } else { tmp4 = linked_475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_474, arg_477) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_483 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var root_478 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_62); var arg_482 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_479 == nil { arg_486 = ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { arg_486 = linked_479.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_478, arg_481, arg_482) }; if linked_484 == nil { tmp7 = ifn_485.Invoke_O__O(arg_486) } else { tmp7 = linked_484.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_483, arg_486) }; arg_496 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_494 == nil { return ifn_495.Invoke_O__O(arg_496) } else { return linked_494.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_493, arg_496) } }








func A_arbace_math_increment_exact_A_New() *A_arbace_math_increment_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_increment_exact_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_IncrementExact_J__J(a__0)).Ref() }
//line :304:1
func A_arbace_math_increment_exact__inliner__446000086_A_New() *A_arbace_math_increment_exact__inliner__446000086_A { A_arbace_math_A_Init(); t := &A_arbace_math_increment_exact__inliner__446000086_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Invoke_O_O__O(self, a__0 any) any { var root_511 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_506 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_63); var arg_510 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_502 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any; var root_497 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_64); var arg_501 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_498 == nil { arg_505 = ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { arg_505 = linked_498.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_497, arg_500, arg_501) }; if linked_503 == nil { tmp2 = ifn_504.Invoke_O__O(arg_505) } else { tmp2 = linked_503.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_502, arg_505) }; arg_510 = tmp1.Invoke_O__O(tmp2); if linked_507 == nil { arg_514 = ifn_508.Invoke_O_O__O(arg_509, arg_510) } else { arg_514 = linked_507.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_506, arg_509, arg_510) }; if linked_512 == nil { return ifn_513.Invoke_O__O(arg_514) } else { return linked_512.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_511, arg_514) } }








func A_arbace_math_decrement_exact_A_New() *A_arbace_math_decrement_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_decrement_exact_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_DecrementExact_J__J(a__0)).Ref() }
//line :313:1
func A_arbace_math_decrement_exact__inliner__446000089_A_New() *A_arbace_math_decrement_exact__inliner__446000089_A { A_arbace_math_A_Init(); t := &A_arbace_math_decrement_exact__inliner__446000089_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Invoke_O_O__O(self, a__0 any) any { var root_529 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any; var root_524 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_65); var arg_528 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_520 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var root_515 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_66); var arg_519 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_516 == nil { arg_523 = ifn_517.Invoke_O_O__O(arg_518, arg_519) } else { arg_523 = linked_516.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_515, arg_518, arg_519) }; if linked_521 == nil { tmp2 = ifn_522.Invoke_O__O(arg_523) } else { tmp2 = linked_521.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_520, arg_523) }; arg_528 = tmp1.Invoke_O__O(tmp2); if linked_525 == nil { arg_532 = ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { arg_532 = linked_525.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) }; if linked_530 == nil { return ifn_531.Invoke_O__O(arg_532) } else { return linked_530.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_529, arg_532) } }








func A_arbace_math_negate_exact_A_New() *A_arbace_math_negate_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_negate_exact_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_NegateExact_J__J(a__0)).Ref() }
//line :322:1
func A_arbace_math_negate_exact__inliner__446000092_A_New() *A_arbace_math_negate_exact__inliner__446000092_A { A_arbace_math_A_Init(); t := &A_arbace_math_negate_exact__inliner__446000092_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Invoke_O_O__O(self, a__0 any) any { var root_547 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var root_542 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_67); var arg_546 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_538 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var root_533 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_68); var arg_537 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0); if linked_534 == nil { arg_541 = ifn_535.Invoke_O_O__O(arg_536, arg_537) } else { arg_541 = linked_534.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_533, arg_536, arg_537) }; if linked_539 == nil { tmp2 = ifn_540.Invoke_O__O(arg_541) } else { tmp2 = linked_539.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_538, arg_541) }; arg_546 = tmp1.Invoke_O__O(tmp2); if linked_543 == nil { arg_550 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { arg_550 = linked_543.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) }; if linked_548 == nil { return ifn_549.Invoke_O__O(arg_550) } else { return linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) } }








func A_arbace_math_floor_div_A_New() *A_arbace_math_floor_div_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_div_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_FloorDiv_J_J__J(x__0, y__1)).Ref() }
//line :331:1
func A_arbace_math_floor_div__inliner__446000095_A_New() *A_arbace_math_floor_div__inliner__446000095_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_div__inliner__446000095_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_575 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_69); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_556 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any; var root_551 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_70); var arg_555 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_552 == nil { arg_559 = ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { arg_559 = linked_552.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) }; if linked_557 == nil { tmp4 = ifn_558.Invoke_O__O(arg_559) } else { tmp4 = linked_557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_556, arg_559) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_565 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any; var root_560 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_71); var arg_564 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_561 == nil { arg_568 = ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { arg_568 = linked_561.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) }; if linked_566 == nil { tmp7 = ifn_567.Invoke_O__O(arg_568) } else { tmp7 = linked_566.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_565, arg_568) }; arg_578 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_576 == nil { return ifn_577.Invoke_O__O(arg_578) } else { return linked_576.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_575, arg_578) } }









func A_arbace_math_floor_mod_A_New() *A_arbace_math_floor_mod_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_mod_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_FloorMod_J_J__J(x__0, y__1)).Ref() }
//line :341:1
func A_arbace_math_floor_mod__inliner__446000098_A_New() *A_arbace_math_floor_mod__inliner__446000098_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_mod__inliner__446000098_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_603 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_72); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_584 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any; var root_579 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_73); var arg_583 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_580 == nil { arg_587 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { arg_587 = linked_580.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_579, arg_582, arg_583) }; if linked_585 == nil { tmp4 = ifn_586.Invoke_O__O(arg_587) } else { tmp4 = linked_585.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_584, arg_587) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_593 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any; var root_588 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_74); var arg_592 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_589 == nil { arg_596 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { arg_596 = linked_589.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }; if linked_594 == nil { tmp7 = ifn_595.Invoke_O__O(arg_596) } else { tmp7 = linked_594.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_593, arg_596) }; arg_606 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_604 == nil { return ifn_605.Invoke_O__O(arg_606) } else { return linked_604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_603, arg_606) } }









func A_arbace_math_ulp_A_New() *A_arbace_math_ulp_A { A_arbace_math_A_Init(); t := &A_arbace_math_ulp_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Ulp_D__D(d__0)).Ref() }
//line :351:1
func A_arbace_math_ulp__inliner__446000101_A_New() *A_arbace_math_ulp__inliner__446000101_A { A_arbace_math_A_Init(); t := &A_arbace_math_ulp__inliner__446000101_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Invoke_O_O__O(self, d__0 any) any { var root_621 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var root_616 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_75); var arg_620 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_612 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var root_607 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_76); var arg_611 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_608 == nil { arg_615 = ifn_609.Invoke_O_O__O(arg_610, arg_611) } else { arg_615 = linked_608.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_607, arg_610, arg_611) }; if linked_613 == nil { tmp2 = ifn_614.Invoke_O__O(arg_615) } else { tmp2 = linked_613.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_612, arg_615) }; arg_620 = tmp1.Invoke_O__O(tmp2); if linked_617 == nil { arg_624 = ifn_618.Invoke_O_O__O(arg_619, arg_620) } else { arg_624 = linked_617.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_616, arg_619, arg_620) }; if linked_622 == nil { return ifn_623.Invoke_O__O(arg_624) } else { return linked_622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_621, arg_624) } }












func A_arbace_math_signum_A_New() *A_arbace_math_signum_A { A_arbace_math_A_Init(); t := &A_arbace_math_signum_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Signum_D__D(d__0)).Ref() }
//line :364:1
func A_arbace_math_signum__inliner__446000104_A_New() *A_arbace_math_signum__inliner__446000104_A { A_arbace_math_A_Init(); t := &A_arbace_math_signum__inliner__446000104_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Invoke_O_O__O(self, d__0 any) any { var root_639 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any; var root_634 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_77); var arg_638 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_630 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any; var root_625 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_78); var arg_629 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_626 == nil { arg_633 = ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { arg_633 = linked_626.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; if linked_631 == nil { tmp2 = ifn_632.Invoke_O__O(arg_633) } else { tmp2 = linked_631.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_630, arg_633) }; arg_638 = tmp1.Invoke_O__O(tmp2); if linked_635 == nil { arg_642 = ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { arg_642 = linked_635.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) }; if linked_640 == nil { return ifn_641.Invoke_O__O(arg_642) } else { return linked_640.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_639, arg_642) } }









func A_arbace_math_sinh_A_New() *A_arbace_math_sinh_A { A_arbace_math_A_Init(); t := &A_arbace_math_sinh_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Sinh_D__D(x__0)).Ref() }
//line :374:1
func A_arbace_math_sinh__inliner__446000107_A_New() *A_arbace_math_sinh__inliner__446000107_A { A_arbace_math_A_Init(); t := &A_arbace_math_sinh__inliner__446000107_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Invoke_O_O__O(self, x__0 any) any { var root_657 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any; var root_652 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_79); var arg_656 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_648 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_643 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_80); var arg_647 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_644 == nil { arg_651 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { arg_651 = linked_644.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }; if linked_649 == nil { tmp2 = ifn_650.Invoke_O__O(arg_651) } else { tmp2 = linked_649.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_648, arg_651) }; arg_656 = tmp1.Invoke_O__O(tmp2); if linked_653 == nil { arg_660 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { arg_660 = linked_653.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; if linked_658 == nil { return ifn_659.Invoke_O__O(arg_660) } else { return linked_658.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_657, arg_660) } }










func A_arbace_math_cosh_A_New() *A_arbace_math_cosh_A { A_arbace_math_A_Init(); t := &A_arbace_math_cosh_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Cosh_D__D(x__0)).Ref() }
//line :385:1
func A_arbace_math_cosh__inliner__446000110_A_New() *A_arbace_math_cosh__inliner__446000110_A { A_arbace_math_A_Init(); t := &A_arbace_math_cosh__inliner__446000110_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Invoke_O_O__O(self, x__0 any) any { var root_675 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any; var root_670 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_81); var arg_674 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_666 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any; var root_661 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_82); var arg_665 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_662 == nil { arg_669 = ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { arg_669 = linked_662.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) }; if linked_667 == nil { tmp2 = ifn_668.Invoke_O__O(arg_669) } else { tmp2 = linked_667.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_666, arg_669) }; arg_674 = tmp1.Invoke_O__O(tmp2); if linked_671 == nil { arg_678 = ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { arg_678 = linked_671.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_670, arg_673, arg_674) }; if linked_676 == nil { return ifn_677.Invoke_O__O(arg_678) } else { return linked_676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_675, arg_678) } }











func A_arbace_math_tanh_A_New() *A_arbace_math_tanh_A { A_arbace_math_A_Init(); t := &A_arbace_math_tanh_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Tanh_D__D(x__0)).Ref() }
//line :397:1
func A_arbace_math_tanh__inliner__446000113_A_New() *A_arbace_math_tanh__inliner__446000113_A { A_arbace_math_A_Init(); t := &A_arbace_math_tanh__inliner__446000113_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Invoke_O_O__O(self, x__0 any) any { var root_693 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any; var root_688 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_83); var arg_692 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_684 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any; var root_679 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_84); var arg_683 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_680 == nil { arg_687 = ifn_681.Invoke_O_O__O(arg_682, arg_683) } else { arg_687 = linked_680.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_679, arg_682, arg_683) }; if linked_685 == nil { tmp2 = ifn_686.Invoke_O__O(arg_687) } else { tmp2 = linked_685.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_684, arg_687) }; arg_692 = tmp1.Invoke_O__O(tmp2); if linked_689 == nil { arg_696 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { arg_696 = linked_689.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; if linked_694 == nil { return ifn_695.Invoke_O__O(arg_696) } else { return linked_694.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_693, arg_696) } }












func A_arbace_math_hypot_A_New() *A_arbace_math_hypot_A { A_arbace_math_A_Init(); t := &A_arbace_math_hypot_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); var y__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_y__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Hypot_D_D__D(x__0, y__1)).Ref() }
//line :410:1
func A_arbace_math_hypot__inliner__446000116_A_New() *A_arbace_math_hypot__inliner__446000116_A { A_arbace_math_A_Init(); t := &A_arbace_math_hypot__inliner__446000116_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { var root_721 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_85); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_702 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var root_697 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_86); var arg_701 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_698 == nil { arg_705 = ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { arg_705 = linked_698.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) }; if linked_703 == nil { tmp4 = ifn_704.Invoke_O__O(arg_705) } else { tmp4 = linked_703.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_702, arg_705) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_711 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any; var root_706 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_87); var arg_710 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1); if linked_707 == nil { arg_714 = ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { arg_714 = linked_707.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) }; if linked_712 == nil { tmp7 = ifn_713.Invoke_O__O(arg_714) } else { tmp7 = linked_712.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_711, arg_714) }; arg_724 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_722 == nil { return ifn_723.Invoke_O__O(arg_724) } else { return linked_722.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_721, arg_724) } }










func A_arbace_math_expm1_A_New() *A_arbace_math_expm1_A { A_arbace_math_A_Init(); t := &A_arbace_math_expm1_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Expm1_D__D(x__0)).Ref() }
//line :421:1
func A_arbace_math_expm1__inliner__446000119_A_New() *A_arbace_math_expm1__inliner__446000119_A { A_arbace_math_A_Init(); t := &A_arbace_math_expm1__inliner__446000119_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Invoke_O_O__O(self, x__0 any) any { var root_739 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any; var root_734 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_88); var arg_738 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_730 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var root_725 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_89); var arg_729 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_726 == nil { arg_733 = ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { arg_733 = linked_726.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) }; if linked_731 == nil { tmp2 = ifn_732.Invoke_O__O(arg_733) } else { tmp2 = linked_731.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_730, arg_733) }; arg_738 = tmp1.Invoke_O__O(tmp2); if linked_735 == nil { arg_742 = ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { arg_742 = linked_735.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) }; if linked_740 == nil { return ifn_741.Invoke_O__O(arg_742) } else { return linked_740.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_739, arg_742) } }












func A_arbace_math_log1p_A_New() *A_arbace_math_log1p_A { A_arbace_math_A_Init(); t := &A_arbace_math_log1p_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Log1p_D__D(x__0)).Ref() }
//line :434:1
func A_arbace_math_log1p__inliner__446000122_A_New() *A_arbace_math_log1p__inliner__446000122_A { A_arbace_math_A_Init(); t := &A_arbace_math_log1p__inliner__446000122_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Invoke_O_O__O(self, x__0 any) any { var root_757 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any; var root_752 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_90); var arg_756 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_748 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any; var root_743 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_91); var arg_747 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0); if linked_744 == nil { arg_751 = ifn_745.Invoke_O_O__O(arg_746, arg_747) } else { arg_751 = linked_744.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_743, arg_746, arg_747) }; if linked_749 == nil { tmp2 = ifn_750.Invoke_O__O(arg_751) } else { tmp2 = linked_749.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_748, arg_751) }; arg_756 = tmp1.Invoke_O__O(tmp2); if linked_753 == nil { arg_760 = ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { arg_760 = linked_753.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) }; if linked_758 == nil { return ifn_759.Invoke_O__O(arg_760) } else { return linked_758.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_757, arg_760) } }













func A_arbace_math_copy_sign_A_New() *A_arbace_math_copy_sign_A { A_arbace_math_A_Init(); t := &A_arbace_math_copy_sign_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign_A) Invoke_O_O_O__O(self, p_magnitude__0, p_sign__1 any) any { var magnitude__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_magnitude__0); var sign__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_sign__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_CopySign_D_D__D(magnitude__0, sign__1)).Ref() }
//line :448:1
func A_arbace_math_copy_sign__inliner__446000125_A_New() *A_arbace_math_copy_sign__inliner__446000125_A { A_arbace_math_A_Init(); t := &A_arbace_math_copy_sign__inliner__446000125_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Invoke_O_O_O__O(self, magnitude__0, sign__1 any) any { var root_785 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_92); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_766 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any; var root_761 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_93); var arg_765 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(magnitude__0); if linked_762 == nil { arg_769 = ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { arg_769 = linked_762.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) }; if linked_767 == nil { tmp4 = ifn_768.Invoke_O__O(arg_769) } else { tmp4 = linked_767.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_766, arg_769) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_775 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var root_770 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_94); var arg_774 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(sign__1); if linked_771 == nil { arg_778 = ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { arg_778 = linked_771.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) }; if linked_776 == nil { tmp7 = ifn_777.Invoke_O__O(arg_778) } else { tmp7 = linked_776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_775, arg_778) }; arg_788 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_786 == nil { return ifn_787.Invoke_O__O(arg_788) } else { return linked_786.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_785, arg_788) } }









func A_arbace_math_get_exponent_A_New() *A_arbace_math_get_exponent_A { A_arbace_math_A_Init(); t := &A_arbace_math_get_exponent_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return /*line :467:1*/ jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Math_GetExponent_D__I(d__0)).Ref() }
//line :458:1
func A_arbace_math_get_exponent__inliner__446000128_A_New() *A_arbace_math_get_exponent__inliner__446000128_A { A_arbace_math_A_Init(); t := &A_arbace_math_get_exponent__inliner__446000128_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Invoke_O_O__O(self, d__0 any) any { var root_803 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any; var root_798 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_95); var arg_802 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_794 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any; var root_789 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_96); var arg_793 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_790 == nil { arg_797 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { arg_797 = linked_790.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }; if linked_795 == nil { tmp2 = ifn_796.Invoke_O__O(arg_797) } else { tmp2 = linked_795.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_794, arg_797) }; arg_802 = tmp1.Invoke_O__O(tmp2); if linked_799 == nil { arg_806 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { arg_806 = linked_799.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; if linked_804 == nil { return ifn_805.Invoke_O__O(arg_806) } else { return linked_804.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_803, arg_806) } }










func A_arbace_math_next_after_A_New() *A_arbace_math_next_after_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_after_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after_A) Invoke_O_O_O__O(self, p_start__0, p_direction__1 any) any { var start__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_start__0); var direction__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_direction__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_NextAfter_D_D__D(start__0, direction__1)).Ref() }
//line :469:1
func A_arbace_math_next_after__inliner__446000131_A_New() *A_arbace_math_next_after__inliner__446000131_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_after__inliner__446000131_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Invoke_O_O_O__O(self, start__0, direction__1 any) any { var root_831 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_97); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_812 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any; var root_807 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_98); var arg_811 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(start__0); if linked_808 == nil { arg_815 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { arg_815 = linked_808.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; if linked_813 == nil { tmp4 = ifn_814.Invoke_O__O(arg_815) } else { tmp4 = linked_813.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_812, arg_815) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_821 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any; var root_816 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_99); var arg_820 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(direction__1); if linked_817 == nil { arg_824 = ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { arg_824 = linked_817.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) }; if linked_822 == nil { tmp7 = ifn_823.Invoke_O__O(arg_824) } else { tmp7 = linked_822.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_821, arg_824) }; arg_834 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_832 == nil { return ifn_833.Invoke_O__O(arg_834) } else { return linked_832.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_831, arg_834) } }

















func A_arbace_math_next_up_A_New() *A_arbace_math_next_up_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_up_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_NextUp_D__D(d__0)).Ref() }
//line :487:1
func A_arbace_math_next_up__inliner__446000134_A_New() *A_arbace_math_next_up__inliner__446000134_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_up__inliner__446000134_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Invoke_O_O__O(self, d__0 any) any { var root_849 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any; var root_844 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_100); var arg_848 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_840 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any; var root_835 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_101); var arg_839 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_836 == nil { arg_843 = ifn_837.Invoke_O_O__O(arg_838, arg_839) } else { arg_843 = linked_836.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_835, arg_838, arg_839) }; if linked_841 == nil { tmp2 = ifn_842.Invoke_O__O(arg_843) } else { tmp2 = linked_841.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_840, arg_843) }; arg_848 = tmp1.Invoke_O__O(tmp2); if linked_845 == nil { arg_852 = ifn_846.Invoke_O_O__O(arg_847, arg_848) } else { arg_852 = linked_845.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_844, arg_847, arg_848) }; if linked_850 == nil { return ifn_851.Invoke_O__O(arg_852) } else { return linked_850.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_849, arg_852) } }











func A_arbace_math_next_down_A_New() *A_arbace_math_next_down_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_down_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_NextDown_D__D(d__0)).Ref() }
//line :499:1
func A_arbace_math_next_down__inliner__446000137_A_New() *A_arbace_math_next_down__inliner__446000137_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_down__inliner__446000137_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Invoke_O_O__O(self, d__0 any) any { var root_867 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any; var root_862 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_102); var arg_866 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp2 any; var root_858 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any; var root_853 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_103); var arg_857 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_854 == nil { arg_861 = ifn_855.Invoke_O_O__O(arg_856, arg_857) } else { arg_861 = linked_854.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_853, arg_856, arg_857) }; if linked_859 == nil { tmp2 = ifn_860.Invoke_O__O(arg_861) } else { tmp2 = linked_859.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_858, arg_861) }; arg_866 = tmp1.Invoke_O__O(tmp2); if linked_863 == nil { arg_870 = ifn_864.Invoke_O_O__O(arg_865, arg_866) } else { arg_870 = linked_863.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_862, arg_865, arg_866) }; if linked_868 == nil { return ifn_869.Invoke_O__O(arg_870) } else { return linked_868.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_867, arg_870) } }











func A_arbace_math_scalb_A_New() *A_arbace_math_scalb_A { A_arbace_math_A_Init(); t := &A_arbace_math_scalb_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb_A) Invoke_O_O_O__O(self, p_d__0, scaleFactor__1 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Scalb_D_I__D(d__0, lang.RT_IntCast_O__I_NoInit(scaleFactor__1))).Ref() }
//line :511:1
func A_arbace_math_scalb__inliner__446000140_A_New() *A_arbace_math_scalb__inliner__446000140_A { A_arbace_math_A_Init(); t := &A_arbace_math_scalb__inliner__446000140_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Invoke_O_O_O__O(self, d__0, scaleFactor__1 any) any { var root_895 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_104); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp4 any; var root_876 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any; var root_871 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_105); var arg_875 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0); if linked_872 == nil { arg_879 = ifn_873.Invoke_O_O__O(arg_874, arg_875) } else { arg_879 = linked_872.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_871, arg_874, arg_875) }; if linked_877 == nil { tmp4 = ifn_878.Invoke_O__O(arg_879) } else { tmp4 = linked_877.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_876, arg_879) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()); var tmp7 any; var root_885 any = A_arbace_math_A_const_7.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any; var root_880 any = A_arbace_math_A_const_8.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_106); var arg_884 any = lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(scaleFactor__1); if linked_881 == nil { arg_888 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { arg_888 = linked_881.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) }; if linked_886 == nil { tmp7 = ifn_887.Invoke_O__O(arg_888) } else { tmp7 = linked_886.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_885, arg_888) }; arg_898 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_896 == nil { return ifn_897.Invoke_O__O(arg_898) } else { return linked_896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_895, arg_898) } }















































type A_arbace_math_A struct{ jrt.Object }

var A_arbace_math_A_const_pool *jrt.RefArray

var A_arbace_math_A_const_0 *lang.Var

var A_arbace_math_A_const_1 any

var A_arbace_math_A_const_2 *lang.Var

var A_arbace_math_A_const_3 *lang.Var

var A_arbace_math_A_const_4 *lang.Var

var A_arbace_math_A_const_5 *lang.Var

var A_arbace_math_A_const_6 any

var A_arbace_math_A_const_7 *lang.Var

var A_arbace_math_A_const_8 *lang.Var

var A_arbace_math_A_const_9 *lang.Var

var A_arbace_math_A_const_10 any

var A_arbace_math_A_const_11 any

var A_arbace_math_A_const_12 any

var A_arbace_math_A_const_13 any

var A_arbace_math_A_const_14 any

var A_arbace_math_A_const_15 any

var A_arbace_math_A_const_16 any

var A_arbace_math_A_const_17 any

var A_arbace_math_A_const_18 any

var A_arbace_math_A_const_19 any

var A_arbace_math_A_const_20 any

var A_arbace_math_A_const_21 any

var A_arbace_math_A_const_22 any

var A_arbace_math_A_const_23 any

var A_arbace_math_A_const_24 any

var A_arbace_math_A_const_25 any

var A_arbace_math_A_const_26 any

var A_arbace_math_A_const_27 any

var A_arbace_math_A_const_28 any

var A_arbace_math_A_const_29 any

var A_arbace_math_A_const_30 any

var A_arbace_math_A_const_31 any

var A_arbace_math_A_const_32 any

var A_arbace_math_A_const_33 any

var A_arbace_math_A_const_34 any

var A_arbace_math_A_const_35 any

var A_arbace_math_A_const_36 any

var A_arbace_math_A_const_37 any

var A_arbace_math_A_const_38 any

var A_arbace_math_A_const_39 any

var A_arbace_math_A_const_40 any

var A_arbace_math_A_const_41 any

var A_arbace_math_A_const_42 any

var A_arbace_math_A_const_43 any

var A_arbace_math_A_const_44 any

var A_arbace_math_A_const_45 any

var A_arbace_math_A_const_46 any

var A_arbace_math_A_const_47 any

var A_arbace_math_A_const_48 any

var A_arbace_math_A_const_49 any

var A_arbace_math_A_const_50 any

var A_arbace_math_A_const_51 any

var A_arbace_math_A_const_52 any

var A_arbace_math_A_const_53 any

var A_arbace_math_A_const_54 any

var A_arbace_math_A_const_55 any

var A_arbace_math_A_const_56 any

var A_arbace_math_A_const_57 any

var A_arbace_math_A_const_58 any

var A_arbace_math_A_const_59 any

var A_arbace_math_A_const_60 any

var A_arbace_math_A_const_61 any

var A_arbace_math_A_const_62 any

var A_arbace_math_A_const_63 any

var A_arbace_math_A_const_64 any

var A_arbace_math_A_const_65 any

var A_arbace_math_A_const_66 any

var A_arbace_math_A_const_67 any

var A_arbace_math_A_const_68 any

var A_arbace_math_A_const_69 any

var A_arbace_math_A_const_70 any

var A_arbace_math_A_const_71 any

var A_arbace_math_A_const_72 any

var A_arbace_math_A_const_73 any

var A_arbace_math_A_const_74 any

var A_arbace_math_A_const_75 any

var A_arbace_math_A_const_76 any

var A_arbace_math_A_const_77 any

var A_arbace_math_A_const_78 any

var A_arbace_math_A_const_79 any

var A_arbace_math_A_const_80 any

var A_arbace_math_A_const_81 any

var A_arbace_math_A_const_82 any

var A_arbace_math_A_const_83 any

var A_arbace_math_A_const_84 any

var A_arbace_math_A_const_85 any

var A_arbace_math_A_const_86 any

var A_arbace_math_A_const_87 any

var A_arbace_math_A_const_88 any

var A_arbace_math_A_const_89 any

var A_arbace_math_A_const_90 any

var A_arbace_math_A_const_91 any

var A_arbace_math_A_const_92 any

var A_arbace_math_A_const_93 any

var A_arbace_math_A_const_94 any

var A_arbace_math_A_const_95 any

var A_arbace_math_A_const_96 any

var A_arbace_math_A_const_97 any

var A_arbace_math_A_const_98 any

var A_arbace_math_A_const_99 any

var A_arbace_math_A_const_100 any

var A_arbace_math_A_const_101 any

var A_arbace_math_A_const_102 any

var A_arbace_math_A_const_103 any

var A_arbace_math_A_const_104 any

var A_arbace_math_A_const_105 any

var A_arbace_math_A_const_106 any

var A_arbace_math_A_init jrt.ClassInit

func A_arbace_math_A_Init() { if !A_arbace_math_A_init.Done() { A_arbace_math_A_init.Run(A_arbace_math_A_clinit) } }

func A_arbace_math_A_clinit() { A_arbace_math_A_clinit_p0(); A_arbace_math_A_clinit_p1(); A_arbace_math_A_clinit_p2(); A_arbace_math_A_clinit_p3(); A_arbace_math_A_clinit_p4(); A_arbace_math_A_clinit_p5(); A_arbace_math_A_clinit_p6() }

func A_arbace_math_A_clinit_p0() { jrt.StartCheck(); A_arbace_math_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 156); A_arbace_math_A_const_0 = lang.Var_Cast(A_arbace_math_A_const_pool.A[49]); A_arbace_math_A_const_1 = A_arbace_math_A_const_pool.A[50]; A_arbace_math_A_const_2 = lang.Var_Cast(A_arbace_math_A_const_pool.A[51]); A_arbace_math_A_const_3 = lang.Var_Cast(A_arbace_math_A_const_pool.A[52]); A_arbace_math_A_const_4 = lang.Var_Cast(A_arbace_math_A_const_pool.A[53]); A_arbace_math_A_const_5 = lang.Var_Cast(A_arbace_math_A_const_pool.A[54]); A_arbace_math_A_const_6 = A_arbace_math_A_const_pool.A[55]; A_arbace_math_A_const_7 = lang.Var_Cast(A_arbace_math_A_const_pool.A[56]); A_arbace_math_A_const_8 = lang.Var_Cast(A_arbace_math_A_const_pool.A[57]); A_arbace_math_A_const_9 = lang.Var_Cast(A_arbace_math_A_const_pool.A[58]); A_arbace_math_A_const_10 = A_arbace_math_A_const_pool.A[59]; A_arbace_math_A_const_11 = A_arbace_math_A_const_pool.A[60] }

func A_arbace_math_A_clinit_p1() { A_arbace_math_A_const_12 = A_arbace_math_A_const_pool.A[61]; A_arbace_math_A_const_13 = A_arbace_math_A_const_pool.A[62]; A_arbace_math_A_const_14 = A_arbace_math_A_const_pool.A[63]; A_arbace_math_A_const_15 = A_arbace_math_A_const_pool.A[64]; A_arbace_math_A_const_16 = A_arbace_math_A_const_pool.A[65]; A_arbace_math_A_const_17 = A_arbace_math_A_const_pool.A[66]; A_arbace_math_A_const_18 = A_arbace_math_A_const_pool.A[67]; A_arbace_math_A_const_19 = A_arbace_math_A_const_pool.A[68]; A_arbace_math_A_const_20 = A_arbace_math_A_const_pool.A[69]; A_arbace_math_A_const_21 = A_arbace_math_A_const_pool.A[70]; A_arbace_math_A_const_22 = A_arbace_math_A_const_pool.A[71]; A_arbace_math_A_const_23 = A_arbace_math_A_const_pool.A[72]; A_arbace_math_A_const_24 = A_arbace_math_A_const_pool.A[73]; A_arbace_math_A_const_25 = A_arbace_math_A_const_pool.A[74]; A_arbace_math_A_const_26 = A_arbace_math_A_const_pool.A[75]; A_arbace_math_A_const_27 = A_arbace_math_A_const_pool.A[76] }

func A_arbace_math_A_clinit_p2() { A_arbace_math_A_const_28 = A_arbace_math_A_const_pool.A[77]; A_arbace_math_A_const_29 = A_arbace_math_A_const_pool.A[78]; A_arbace_math_A_const_30 = A_arbace_math_A_const_pool.A[79]; A_arbace_math_A_const_31 = A_arbace_math_A_const_pool.A[80]; A_arbace_math_A_const_32 = A_arbace_math_A_const_pool.A[81]; A_arbace_math_A_const_33 = A_arbace_math_A_const_pool.A[82]; A_arbace_math_A_const_34 = A_arbace_math_A_const_pool.A[83]; A_arbace_math_A_const_35 = A_arbace_math_A_const_pool.A[84]; A_arbace_math_A_const_36 = A_arbace_math_A_const_pool.A[85]; A_arbace_math_A_const_37 = A_arbace_math_A_const_pool.A[86]; A_arbace_math_A_const_38 = A_arbace_math_A_const_pool.A[87]; A_arbace_math_A_const_39 = A_arbace_math_A_const_pool.A[88]; A_arbace_math_A_const_40 = A_arbace_math_A_const_pool.A[89]; A_arbace_math_A_const_41 = A_arbace_math_A_const_pool.A[90]; A_arbace_math_A_const_42 = A_arbace_math_A_const_pool.A[91]; A_arbace_math_A_const_43 = A_arbace_math_A_const_pool.A[92] }

func A_arbace_math_A_clinit_p3() { A_arbace_math_A_const_44 = A_arbace_math_A_const_pool.A[93]; A_arbace_math_A_const_45 = A_arbace_math_A_const_pool.A[94]; A_arbace_math_A_const_46 = A_arbace_math_A_const_pool.A[95]; A_arbace_math_A_const_47 = A_arbace_math_A_const_pool.A[96]; A_arbace_math_A_const_48 = A_arbace_math_A_const_pool.A[97]; A_arbace_math_A_const_49 = A_arbace_math_A_const_pool.A[98]; A_arbace_math_A_const_50 = A_arbace_math_A_const_pool.A[99]; A_arbace_math_A_const_51 = A_arbace_math_A_const_pool.A[100]; A_arbace_math_A_const_52 = A_arbace_math_A_const_pool.A[101]; A_arbace_math_A_const_53 = A_arbace_math_A_const_pool.A[102]; A_arbace_math_A_const_54 = A_arbace_math_A_const_pool.A[103]; A_arbace_math_A_const_55 = A_arbace_math_A_const_pool.A[104]; A_arbace_math_A_const_56 = A_arbace_math_A_const_pool.A[105]; A_arbace_math_A_const_57 = A_arbace_math_A_const_pool.A[106]; A_arbace_math_A_const_58 = A_arbace_math_A_const_pool.A[107]; A_arbace_math_A_const_59 = A_arbace_math_A_const_pool.A[108] }

func A_arbace_math_A_clinit_p4() { A_arbace_math_A_const_60 = A_arbace_math_A_const_pool.A[109]; A_arbace_math_A_const_61 = A_arbace_math_A_const_pool.A[110]; A_arbace_math_A_const_62 = A_arbace_math_A_const_pool.A[111]; A_arbace_math_A_const_63 = A_arbace_math_A_const_pool.A[112]; A_arbace_math_A_const_64 = A_arbace_math_A_const_pool.A[113]; A_arbace_math_A_const_65 = A_arbace_math_A_const_pool.A[114]; A_arbace_math_A_const_66 = A_arbace_math_A_const_pool.A[115]; A_arbace_math_A_const_67 = A_arbace_math_A_const_pool.A[116]; A_arbace_math_A_const_68 = A_arbace_math_A_const_pool.A[117]; A_arbace_math_A_const_69 = A_arbace_math_A_const_pool.A[118]; A_arbace_math_A_const_70 = A_arbace_math_A_const_pool.A[119]; A_arbace_math_A_const_71 = A_arbace_math_A_const_pool.A[120]; A_arbace_math_A_const_72 = A_arbace_math_A_const_pool.A[121]; A_arbace_math_A_const_73 = A_arbace_math_A_const_pool.A[122]; A_arbace_math_A_const_74 = A_arbace_math_A_const_pool.A[123]; A_arbace_math_A_const_75 = A_arbace_math_A_const_pool.A[124] }

func A_arbace_math_A_clinit_p5() { A_arbace_math_A_const_76 = A_arbace_math_A_const_pool.A[125]; A_arbace_math_A_const_77 = A_arbace_math_A_const_pool.A[126]; A_arbace_math_A_const_78 = A_arbace_math_A_const_pool.A[127]; A_arbace_math_A_const_79 = A_arbace_math_A_const_pool.A[128]; A_arbace_math_A_const_80 = A_arbace_math_A_const_pool.A[129]; A_arbace_math_A_const_81 = A_arbace_math_A_const_pool.A[130]; A_arbace_math_A_const_82 = A_arbace_math_A_const_pool.A[131]; A_arbace_math_A_const_83 = A_arbace_math_A_const_pool.A[132]; A_arbace_math_A_const_84 = A_arbace_math_A_const_pool.A[133]; A_arbace_math_A_const_85 = A_arbace_math_A_const_pool.A[134]; A_arbace_math_A_const_86 = A_arbace_math_A_const_pool.A[135]; A_arbace_math_A_const_87 = A_arbace_math_A_const_pool.A[136]; A_arbace_math_A_const_88 = A_arbace_math_A_const_pool.A[137]; A_arbace_math_A_const_89 = A_arbace_math_A_const_pool.A[138]; A_arbace_math_A_const_90 = A_arbace_math_A_const_pool.A[139]; A_arbace_math_A_const_91 = A_arbace_math_A_const_pool.A[140] }

func A_arbace_math_A_clinit_p6() { A_arbace_math_A_const_92 = A_arbace_math_A_const_pool.A[141]; A_arbace_math_A_const_93 = A_arbace_math_A_const_pool.A[142]; A_arbace_math_A_const_94 = A_arbace_math_A_const_pool.A[143]; A_arbace_math_A_const_95 = A_arbace_math_A_const_pool.A[144]; A_arbace_math_A_const_96 = A_arbace_math_A_const_pool.A[145]; A_arbace_math_A_const_97 = A_arbace_math_A_const_pool.A[146]; A_arbace_math_A_const_98 = A_arbace_math_A_const_pool.A[147]; A_arbace_math_A_const_99 = A_arbace_math_A_const_pool.A[148]; A_arbace_math_A_const_100 = A_arbace_math_A_const_pool.A[149]; A_arbace_math_A_const_101 = A_arbace_math_A_const_pool.A[150]; A_arbace_math_A_const_102 = A_arbace_math_A_const_pool.A[151]; A_arbace_math_A_const_103 = A_arbace_math_A_const_pool.A[152]; A_arbace_math_A_const_104 = A_arbace_math_A_const_pool.A[153]; A_arbace_math_A_const_105 = A_arbace_math_A_const_pool.A[154]; A_arbace_math_A_const_106 = A_arbace_math_A_const_pool.A[155] }

func A_arbace_math_A_New() *A_arbace_math_A { A_arbace_math_A_Init(); t := &A_arbace_math_A{}; t.Ctor(); return t }

func (t *A_arbace_math_A) Ctor() {}

func (t *A_arbace_math_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_A) GetClass__Class() *jrt.Class { return A_arbace_math_A_class }

func (t *A_arbace_math_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_A); return ok }

func A_arbace_math_A_Cast(x any) *A_arbace_math_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_A_class)) }; return v }



type A_arbace_math_IEEE_remainder_A struct{ j2g_header uint64 }

var A_arbace_math_IEEE_remainder_A_fn_class *jrt.Class



type A_arbace_math_IEEE_remainder__inliner__446000053_A struct{ j2g_header uint64 }

var A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class *jrt.Class



type A_arbace_math_acos_A struct{ j2g_header uint64 }

var A_arbace_math_acos_A_fn_class *jrt.Class



type A_arbace_math_acos__inliner__446000026_A struct{ j2g_header uint64 }

var A_arbace_math_acos__inliner__446000026_A_fn_class *jrt.Class



type A_arbace_math_add_exact_A struct{ j2g_header uint64 }

var A_arbace_math_add_exact_A_fn_class *jrt.Class



type A_arbace_math_add_exact__inliner__446000077_A struct{ j2g_header uint64 }

var A_arbace_math_add_exact__inliner__446000077_A_fn_class *jrt.Class



type A_arbace_math_asin_A struct{ j2g_header uint64 }

var A_arbace_math_asin_A_fn_class *jrt.Class



type A_arbace_math_asin__inliner__446000023_A struct{ j2g_header uint64 }

var A_arbace_math_asin__inliner__446000023_A_fn_class *jrt.Class



type A_arbace_math_atan_A struct{ j2g_header uint64 }

var A_arbace_math_atan_A_fn_class *jrt.Class



type A_arbace_math_atan2_A struct{ j2g_header uint64 }

var A_arbace_math_atan2_A_fn_class *jrt.Class



type A_arbace_math_atan2__inliner__446000065_A struct{ j2g_header uint64 }

var A_arbace_math_atan2__inliner__446000065_A_fn_class *jrt.Class



type A_arbace_math_atan__inliner__446000029_A struct{ j2g_header uint64 }

var A_arbace_math_atan__inliner__446000029_A_fn_class *jrt.Class



type A_arbace_math_cbrt_A struct{ j2g_header uint64 }

var A_arbace_math_cbrt_A_fn_class *jrt.Class



type A_arbace_math_cbrt__inliner__446000050_A struct{ j2g_header uint64 }

var A_arbace_math_cbrt__inliner__446000050_A_fn_class *jrt.Class



type A_arbace_math_ceil_A struct{ j2g_header uint64 }

var A_arbace_math_ceil_A_fn_class *jrt.Class



type A_arbace_math_ceil__inliner__446000056_A struct{ j2g_header uint64 }

var A_arbace_math_ceil__inliner__446000056_A_fn_class *jrt.Class



type A_arbace_math_copy_sign_A struct{ j2g_header uint64 }

var A_arbace_math_copy_sign_A_fn_class *jrt.Class



type A_arbace_math_copy_sign__inliner__446000125_A struct{ j2g_header uint64 }

var A_arbace_math_copy_sign__inliner__446000125_A_fn_class *jrt.Class



type A_arbace_math_cos_A struct{ j2g_header uint64 }

var A_arbace_math_cos_A_fn_class *jrt.Class



type A_arbace_math_cos__inliner__446000017_A struct{ j2g_header uint64 }

var A_arbace_math_cos__inliner__446000017_A_fn_class *jrt.Class



type A_arbace_math_cosh_A struct{ j2g_header uint64 }

var A_arbace_math_cosh_A_fn_class *jrt.Class



type A_arbace_math_cosh__inliner__446000110_A struct{ j2g_header uint64 }

var A_arbace_math_cosh__inliner__446000110_A_fn_class *jrt.Class



type A_arbace_math_decrement_exact_A struct{ j2g_header uint64 }

var A_arbace_math_decrement_exact_A_fn_class *jrt.Class



type A_arbace_math_decrement_exact__inliner__446000089_A struct{ j2g_header uint64 }

var A_arbace_math_decrement_exact__inliner__446000089_A_fn_class *jrt.Class



type A_arbace_math_eval446000004_A struct{ jrt.Object }

func A_arbace_math_eval446000004_A_New() *A_arbace_math_eval446000004_A { t := &A_arbace_math_eval446000004_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000004_A) Ctor() {}

func (t *A_arbace_math_eval446000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000004_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000004_A_class }

func (t *A_arbace_math_eval446000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000004_A); return ok }

func A_arbace_math_eval446000004_A_Cast(x any) *A_arbace_math_eval446000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000004_A_class)) }; return v }



type A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A struct{ j2g_header uint64 }

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class *jrt.Class



type A_arbace_math_eval446000008_A struct{ jrt.Object }

func A_arbace_math_eval446000008_A_New() *A_arbace_math_eval446000008_A { t := &A_arbace_math_eval446000008_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000008_A) Ctor() {}

func (t *A_arbace_math_eval446000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000008_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000008_A_class }

func (t *A_arbace_math_eval446000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000008_A); return ok }

func A_arbace_math_eval446000008_A_Cast(x any) *A_arbace_math_eval446000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000008_A_class)) }; return v }



type A_arbace_math_eval446000008_fn__446000009_A struct{ j2g_header uint64 }

var A_arbace_math_eval446000008_fn__446000009_A_fn_class *jrt.Class



type A_arbace_math_exp_A struct{ j2g_header uint64 }

var A_arbace_math_exp_A_fn_class *jrt.Class



type A_arbace_math_exp__inliner__446000038_A struct{ j2g_header uint64 }

var A_arbace_math_exp__inliner__446000038_A_fn_class *jrt.Class



type A_arbace_math_expm1_A struct{ j2g_header uint64 }

var A_arbace_math_expm1_A_fn_class *jrt.Class



type A_arbace_math_expm1__inliner__446000119_A struct{ j2g_header uint64 }

var A_arbace_math_expm1__inliner__446000119_A_fn_class *jrt.Class



type A_arbace_math_floor_A struct{ j2g_header uint64 }

var A_arbace_math_floor_A_fn_class *jrt.Class



type A_arbace_math_floor__inliner__446000059_A struct{ j2g_header uint64 }

var A_arbace_math_floor__inliner__446000059_A_fn_class *jrt.Class



type A_arbace_math_floor_div_A struct{ j2g_header uint64 }

var A_arbace_math_floor_div_A_fn_class *jrt.Class



type A_arbace_math_floor_div__inliner__446000095_A struct{ j2g_header uint64 }

var A_arbace_math_floor_div__inliner__446000095_A_fn_class *jrt.Class



type A_arbace_math_floor_mod_A struct{ j2g_header uint64 }

var A_arbace_math_floor_mod_A_fn_class *jrt.Class



type A_arbace_math_floor_mod__inliner__446000098_A struct{ j2g_header uint64 }

var A_arbace_math_floor_mod__inliner__446000098_A_fn_class *jrt.Class



type A_arbace_math_get_exponent_A struct{ j2g_header uint64 }

var A_arbace_math_get_exponent_A_fn_class *jrt.Class



type A_arbace_math_get_exponent__inliner__446000128_A struct{ j2g_header uint64 }

var A_arbace_math_get_exponent__inliner__446000128_A_fn_class *jrt.Class



type A_arbace_math_hypot_A struct{ j2g_header uint64 }

var A_arbace_math_hypot_A_fn_class *jrt.Class



type A_arbace_math_hypot__inliner__446000116_A struct{ j2g_header uint64 }

var A_arbace_math_hypot__inliner__446000116_A_fn_class *jrt.Class



type A_arbace_math_increment_exact_A struct{ j2g_header uint64 }

var A_arbace_math_increment_exact_A_fn_class *jrt.Class



type A_arbace_math_increment_exact__inliner__446000086_A struct{ j2g_header uint64 }

var A_arbace_math_increment_exact__inliner__446000086_A_fn_class *jrt.Class



type A_arbace_math_log_A struct{ j2g_header uint64 }

var A_arbace_math_log_A_fn_class *jrt.Class



type A_arbace_math_log10_A struct{ j2g_header uint64 }

var A_arbace_math_log10_A_fn_class *jrt.Class



type A_arbace_math_log10__inliner__446000044_A struct{ j2g_header uint64 }

var A_arbace_math_log10__inliner__446000044_A_fn_class *jrt.Class



type A_arbace_math_log1p_A struct{ j2g_header uint64 }

var A_arbace_math_log1p_A_fn_class *jrt.Class



type A_arbace_math_log1p__inliner__446000122_A struct{ j2g_header uint64 }

var A_arbace_math_log1p__inliner__446000122_A_fn_class *jrt.Class



type A_arbace_math_log__inliner__446000041_A struct{ j2g_header uint64 }

var A_arbace_math_log__inliner__446000041_A_fn_class *jrt.Class



type A_arbace_math_multiply_exact_A struct{ j2g_header uint64 }

var A_arbace_math_multiply_exact_A_fn_class *jrt.Class



type A_arbace_math_multiply_exact__inliner__446000083_A struct{ j2g_header uint64 }

var A_arbace_math_multiply_exact__inliner__446000083_A_fn_class *jrt.Class



type A_arbace_math_negate_exact_A struct{ j2g_header uint64 }

var A_arbace_math_negate_exact_A_fn_class *jrt.Class



type A_arbace_math_negate_exact__inliner__446000092_A struct{ j2g_header uint64 }

var A_arbace_math_negate_exact__inliner__446000092_A_fn_class *jrt.Class



type A_arbace_math_next_after_A struct{ j2g_header uint64 }

var A_arbace_math_next_after_A_fn_class *jrt.Class



type A_arbace_math_next_after__inliner__446000131_A struct{ j2g_header uint64 }

var A_arbace_math_next_after__inliner__446000131_A_fn_class *jrt.Class



type A_arbace_math_next_down_A struct{ j2g_header uint64 }

var A_arbace_math_next_down_A_fn_class *jrt.Class



type A_arbace_math_next_down__inliner__446000137_A struct{ j2g_header uint64 }

var A_arbace_math_next_down__inliner__446000137_A_fn_class *jrt.Class



type A_arbace_math_next_up_A struct{ j2g_header uint64 }

var A_arbace_math_next_up_A_fn_class *jrt.Class



type A_arbace_math_next_up__inliner__446000134_A struct{ j2g_header uint64 }

var A_arbace_math_next_up__inliner__446000134_A_fn_class *jrt.Class



type A_arbace_math_pow_A struct{ j2g_header uint64 }

var A_arbace_math_pow_A_fn_class *jrt.Class



type A_arbace_math_pow__inliner__446000068_A struct{ j2g_header uint64 }

var A_arbace_math_pow__inliner__446000068_A_fn_class *jrt.Class



type A_arbace_math_random_A struct{ j2g_header uint64 }

var A_arbace_math_random_A_fn_class *jrt.Class



type A_arbace_math_random__inliner__446000074_A struct{ j2g_header uint64 }

var A_arbace_math_random__inliner__446000074_A_fn_class *jrt.Class



type A_arbace_math_rint_A struct{ j2g_header uint64 }

var A_arbace_math_rint_A_fn_class *jrt.Class



type A_arbace_math_rint__inliner__446000062_A struct{ j2g_header uint64 }

var A_arbace_math_rint__inliner__446000062_A_fn_class *jrt.Class



type A_arbace_math_round_A struct{ j2g_header uint64 }

var A_arbace_math_round_A_fn_class *jrt.Class



type A_arbace_math_round__inliner__446000071_A struct{ j2g_header uint64 }

var A_arbace_math_round__inliner__446000071_A_fn_class *jrt.Class



type A_arbace_math_scalb_A struct{ j2g_header uint64 }

var A_arbace_math_scalb_A_fn_class *jrt.Class



type A_arbace_math_scalb__inliner__446000140_A struct{ j2g_header uint64 }

var A_arbace_math_scalb__inliner__446000140_A_fn_class *jrt.Class



type A_arbace_math_signum_A struct{ j2g_header uint64 }

var A_arbace_math_signum_A_fn_class *jrt.Class



type A_arbace_math_signum__inliner__446000104_A struct{ j2g_header uint64 }

var A_arbace_math_signum__inliner__446000104_A_fn_class *jrt.Class



type A_arbace_math_sin_A struct{ j2g_header uint64 }

var A_arbace_math_sin_A_fn_class *jrt.Class



type A_arbace_math_sin__inliner__446000014_A struct{ j2g_header uint64 }

var A_arbace_math_sin__inliner__446000014_A_fn_class *jrt.Class



type A_arbace_math_sinh_A struct{ j2g_header uint64 }

var A_arbace_math_sinh_A_fn_class *jrt.Class



type A_arbace_math_sinh__inliner__446000107_A struct{ j2g_header uint64 }

var A_arbace_math_sinh__inliner__446000107_A_fn_class *jrt.Class



type A_arbace_math_sqrt_A struct{ j2g_header uint64 }

var A_arbace_math_sqrt_A_fn_class *jrt.Class



type A_arbace_math_sqrt__inliner__446000047_A struct{ j2g_header uint64 }

var A_arbace_math_sqrt__inliner__446000047_A_fn_class *jrt.Class



type A_arbace_math_subtract_exact_A struct{ j2g_header uint64 }

var A_arbace_math_subtract_exact_A_fn_class *jrt.Class



type A_arbace_math_subtract_exact__inliner__446000080_A struct{ j2g_header uint64 }

var A_arbace_math_subtract_exact__inliner__446000080_A_fn_class *jrt.Class



type A_arbace_math_tan_A struct{ j2g_header uint64 }

var A_arbace_math_tan_A_fn_class *jrt.Class



type A_arbace_math_tan__inliner__446000020_A struct{ j2g_header uint64 }

var A_arbace_math_tan__inliner__446000020_A_fn_class *jrt.Class



type A_arbace_math_tanh_A struct{ j2g_header uint64 }

var A_arbace_math_tanh_A_fn_class *jrt.Class



type A_arbace_math_tanh__inliner__446000113_A struct{ j2g_header uint64 }

var A_arbace_math_tanh__inliner__446000113_A_fn_class *jrt.Class



type A_arbace_math_to_degrees_A struct{ j2g_header uint64 }

var A_arbace_math_to_degrees_A_fn_class *jrt.Class



type A_arbace_math_to_degrees__inliner__446000035_A struct{ j2g_header uint64 }

var A_arbace_math_to_degrees__inliner__446000035_A_fn_class *jrt.Class



type A_arbace_math_to_radians_A struct{ j2g_header uint64 }

var A_arbace_math_to_radians_A_fn_class *jrt.Class



type A_arbace_math_to_radians__inliner__446000032_A struct{ j2g_header uint64 }

var A_arbace_math_to_radians__inliner__446000032_A_fn_class *jrt.Class



type A_arbace_math_ulp_A struct{ j2g_header uint64 }

var A_arbace_math_ulp_A_fn_class *jrt.Class



type A_arbace_math_ulp__inliner__446000101_A struct{ j2g_header uint64 }

var A_arbace_math_ulp__inliner__446000101_A_fn_class *jrt.Class
