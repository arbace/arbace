//line aot_arbace_math.ae:1
package aot_arbace_math

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New() *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A { A_arbace_math_A_Init(); t := &A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_math_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_math_eval446000008_fn__446000009_A_New() *A_arbace_math_eval446000008_fn__446000009_A { A_arbace_math_A_Init(); t := &A_arbace_math_eval446000008_fn__446000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_math_eval446000008_fn__446000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_math_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_6), A_arbace_math_A_const_4.GetRawRoot__O(), A_arbace_math_A_const_5) }
































func A_arbace_math_sin_A_New() *A_arbace_math_sin_A { A_arbace_math_A_Init(); t := &A_arbace_math_sin_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Sin_D__D(a__0)).Ref() }
//line :42:1
func A_arbace_math_sin__inliner__446000014_A_New() *A_arbace_math_sin__inliner__446000014_A { A_arbace_math_A_Init(); t := &A_arbace_math_sin__inliner__446000014_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Ctor() {}
//line :42:1
func (t *A_arbace_math_sin__inliner__446000014_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_10), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_11), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_cos_A_New() *A_arbace_math_cos_A { A_arbace_math_A_Init(); t := &A_arbace_math_cos_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Cos_D__D(a__0)).Ref() }
//line :53:1
func A_arbace_math_cos__inliner__446000017_A_New() *A_arbace_math_cos__inliner__446000017_A { A_arbace_math_A_Init(); t := &A_arbace_math_cos__inliner__446000017_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Ctor() {}
//line :53:1
func (t *A_arbace_math_cos__inliner__446000017_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_12), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_13), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }









func A_arbace_math_tan_A_New() *A_arbace_math_tan_A { A_arbace_math_A_Init(); t := &A_arbace_math_tan_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Tan_D__D(a__0)).Ref() }
//line :63:1
func A_arbace_math_tan__inliner__446000020_A_New() *A_arbace_math_tan__inliner__446000020_A { A_arbace_math_A_Init(); t := &A_arbace_math_tan__inliner__446000020_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Ctor() {}
//line :63:1
func (t *A_arbace_math_tan__inliner__446000020_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_14), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_15), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_asin_A_New() *A_arbace_math_asin_A { A_arbace_math_A_Init(); t := &A_arbace_math_asin_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Asin_D__D(a__0)).Ref() }
//line :74:1
func A_arbace_math_asin__inliner__446000023_A_New() *A_arbace_math_asin__inliner__446000023_A { A_arbace_math_A_Init(); t := &A_arbace_math_asin__inliner__446000023_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Ctor() {}
//line :74:1
func (t *A_arbace_math_asin__inliner__446000023_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_16), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_17), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_acos_A_New() *A_arbace_math_acos_A { A_arbace_math_A_Init(); t := &A_arbace_math_acos_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Acos_D__D(a__0)).Ref() }
//line :85:1
func A_arbace_math_acos__inliner__446000026_A_New() *A_arbace_math_acos__inliner__446000026_A { A_arbace_math_A_Init(); t := &A_arbace_math_acos__inliner__446000026_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Ctor() {}
//line :85:1
func (t *A_arbace_math_acos__inliner__446000026_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_18), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_19), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }









func A_arbace_math_atan_A_New() *A_arbace_math_atan_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Atan_D__D(a__0)).Ref() }
//line :95:1
func A_arbace_math_atan__inliner__446000029_A_New() *A_arbace_math_atan__inliner__446000029_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan__inliner__446000029_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Ctor() {}
//line :95:1
func (t *A_arbace_math_atan__inliner__446000029_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_20), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_21), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_to_radians_A_New() *A_arbace_math_to_radians_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_radians_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians_A) Invoke_O_O__O(self, p_deg__0 any) any { var deg__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_deg__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_ToRadians_D__D(deg__0)).Ref() }
//line :106:1
func A_arbace_math_to_radians__inliner__446000032_A_New() *A_arbace_math_to_radians__inliner__446000032_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_radians__inliner__446000032_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Ctor() {}
//line :106:1
func (t *A_arbace_math_to_radians__inliner__446000032_A) Invoke_O_O__O(self, deg__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_22), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_23), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(deg__0)))))) }








func A_arbace_math_to_degrees_A_New() *A_arbace_math_to_degrees_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_degrees_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees_A) Invoke_O_O__O(self, p_r__0 any) any { var r__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_r__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_ToDegrees_D__D(r__0)).Ref() }
//line :115:1
func A_arbace_math_to_degrees__inliner__446000035_A_New() *A_arbace_math_to_degrees__inliner__446000035_A { A_arbace_math_A_Init(); t := &A_arbace_math_to_degrees__inliner__446000035_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Ctor() {}
//line :115:1
func (t *A_arbace_math_to_degrees__inliner__446000035_A) Invoke_O_O__O(self, r__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_24), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_25), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(r__0)))))) }








func A_arbace_math_exp_A_New() *A_arbace_math_exp_A { A_arbace_math_A_Init(); t := &A_arbace_math_exp_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Exp_D__D(a__0)).Ref() }
//line :124:1
func A_arbace_math_exp__inliner__446000038_A_New() *A_arbace_math_exp__inliner__446000038_A { A_arbace_math_A_Init(); t := &A_arbace_math_exp__inliner__446000038_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Ctor() {}
//line :124:1
func (t *A_arbace_math_exp__inliner__446000038_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_26), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_27), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_log_A_New() *A_arbace_math_log_A { A_arbace_math_A_Init(); t := &A_arbace_math_log_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Log_D__D(a__0)).Ref() }
//line :136:1
func A_arbace_math_log__inliner__446000041_A_New() *A_arbace_math_log__inliner__446000041_A { A_arbace_math_A_Init(); t := &A_arbace_math_log__inliner__446000041_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Ctor() {}
//line :136:1
func (t *A_arbace_math_log__inliner__446000041_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_28), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_29), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_log10_A_New() *A_arbace_math_log10_A { A_arbace_math_A_Init(); t := &A_arbace_math_log10_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Log10_D__D(a__0)).Ref() }
//line :148:1
func A_arbace_math_log10__inliner__446000044_A_New() *A_arbace_math_log10__inliner__446000044_A { A_arbace_math_A_Init(); t := &A_arbace_math_log10__inliner__446000044_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Ctor() {}
//line :148:1
func (t *A_arbace_math_log10__inliner__446000044_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_30), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_31), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_sqrt_A_New() *A_arbace_math_sqrt_A { A_arbace_math_A_Init(); t := &A_arbace_math_sqrt_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Sqrt_D__D(a__0)).Ref() }
//line :160:1
func A_arbace_math_sqrt__inliner__446000047_A_New() *A_arbace_math_sqrt__inliner__446000047_A { A_arbace_math_A_Init(); t := &A_arbace_math_sqrt__inliner__446000047_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Ctor() {}
//line :160:1
func (t *A_arbace_math_sqrt__inliner__446000047_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_32), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_33), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_cbrt_A_New() *A_arbace_math_cbrt_A { A_arbace_math_A_Init(); t := &A_arbace_math_cbrt_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Cbrt_D__D(a__0)).Ref() }
//line :172:1
func A_arbace_math_cbrt__inliner__446000050_A_New() *A_arbace_math_cbrt__inliner__446000050_A { A_arbace_math_A_Init(); t := &A_arbace_math_cbrt__inliner__446000050_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Ctor() {}
//line :172:1
func (t *A_arbace_math_cbrt__inliner__446000050_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_34), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_35), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_IEEE_remainder_A_New() *A_arbace_math_IEEE_remainder_A { A_arbace_math_A_Init(); t := &A_arbace_math_IEEE_remainder_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder_A) Invoke_O_O_O__O(self, p_dividend__0, p_divisor__1 any) any { var dividend__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_dividend__0); var divisor__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_divisor__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_IEEEremainder_D_D__D(dividend__0, divisor__1)).Ref() }
//line :184:1
func A_arbace_math_IEEE_remainder__inliner__446000053_A_New() *A_arbace_math_IEEE_remainder__inliner__446000053_A { A_arbace_math_A_Init(); t := &A_arbace_math_IEEE_remainder__inliner__446000053_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Ctor() {}
//line :184:1
func (t *A_arbace_math_IEEE_remainder__inliner__446000053_A) Invoke_O_O_O__O(self, dividend__0, divisor__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_36), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_37), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(dividend__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_38), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(divisor__1)))))) }














func A_arbace_math_ceil_A_New() *A_arbace_math_ceil_A { A_arbace_math_A_Init(); t := &A_arbace_math_ceil_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Ceil_D__D(a__0)).Ref() }
//line :199:1
func A_arbace_math_ceil__inliner__446000056_A_New() *A_arbace_math_ceil__inliner__446000056_A { A_arbace_math_A_Init(); t := &A_arbace_math_ceil__inliner__446000056_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Ctor() {}
//line :199:1
func (t *A_arbace_math_ceil__inliner__446000056_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_39), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_40), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }











func A_arbace_math_floor_A_New() *A_arbace_math_floor_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Floor_D__D(a__0)).Ref() }
//line :211:1
func A_arbace_math_floor__inliner__446000059_A_New() *A_arbace_math_floor__inliner__446000059_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor__inliner__446000059_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Ctor() {}
//line :211:1
func (t *A_arbace_math_floor__inliner__446000059_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_41), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_42), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_rint_A_New() *A_arbace_math_rint_A { A_arbace_math_A_Init(); t := &A_arbace_math_rint_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Rint_D__D(a__0)).Ref() }
//line :222:1
func A_arbace_math_rint__inliner__446000062_A_New() *A_arbace_math_rint__inliner__446000062_A { A_arbace_math_A_Init(); t := &A_arbace_math_rint__inliner__446000062_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Ctor() {}
//line :222:1
func (t *A_arbace_math_rint__inliner__446000062_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_43), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_44), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }










func A_arbace_math_atan2_A_New() *A_arbace_math_atan2_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan2_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2_A) Invoke_O_O_O__O(self, p_y__0, p_x__1 any) any { var y__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_y__0); var x__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Atan2_D_D__D(y__0, x__1)).Ref() }
//line :233:1
func A_arbace_math_atan2__inliner__446000065_A_New() *A_arbace_math_atan2__inliner__446000065_A { A_arbace_math_A_Init(); t := &A_arbace_math_atan2__inliner__446000065_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Ctor() {}
//line :233:1
func (t *A_arbace_math_atan2__inliner__446000065_A) Invoke_O_O_O__O(self, y__0, x__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_45), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_46), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_47), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__1)))))) }










func A_arbace_math_pow_A_New() *A_arbace_math_pow_A { A_arbace_math_A_Init(); t := &A_arbace_math_pow_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow_A) Invoke_O_O_O__O(self, p_a__0, p_b__1 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); var b__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_b__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Pow_D_D__D(a__0, b__1)).Ref() }
//line :244:1
func A_arbace_math_pow__inliner__446000068_A_New() *A_arbace_math_pow__inliner__446000068_A { A_arbace_math_A_Init(); t := &A_arbace_math_pow__inliner__446000068_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Ctor() {}
//line :244:1
func (t *A_arbace_math_pow__inliner__446000068_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_48), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_49), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_50), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(b__1)))))) }









func A_arbace_math_round_A_New() *A_arbace_math_round_A { A_arbace_math_A_Init(); t := &A_arbace_math_round_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_Round_D__J(a__0)).Ref() }
//line :254:1
func A_arbace_math_round__inliner__446000071_A_New() *A_arbace_math_round__inliner__446000071_A { A_arbace_math_A_Init(); t := &A_arbace_math_round__inliner__446000071_A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Ctor() {}
//line :254:1
func (t *A_arbace_math_round__inliner__446000071_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_51), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_52), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }












func A_arbace_math_random_A_New() *A_arbace_math_random_A { A_arbace_math_A_Init(); t := &A_arbace_math_random_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random_A) Invoke_O__O(self any) any { return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Random__D()).Ref() }
//line :267:1
func A_arbace_math_random__inliner__446000074_A_New() *A_arbace_math_random__inliner__446000074_A { A_arbace_math_A_Init(); t := &A_arbace_math_random__inliner__446000074_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Ctor() {}
//line :267:1
func (t *A_arbace_math_random__inliner__446000074_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_53))) }









func A_arbace_math_add_exact_A_New() *A_arbace_math_add_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_add_exact_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_AddExact_J_J__J(x__0, y__1)).Ref() }
//line :277:1
func A_arbace_math_add_exact__inliner__446000077_A_New() *A_arbace_math_add_exact__inliner__446000077_A { A_arbace_math_A_Init(); t := &A_arbace_math_add_exact__inliner__446000077_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Ctor() {}
//line :277:1
func (t *A_arbace_math_add_exact__inliner__446000077_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_54), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_55), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_56), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1)))))) }








func A_arbace_math_subtract_exact_A_New() *A_arbace_math_subtract_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_subtract_exact_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_SubtractExact_J_J__J(x__0, y__1)).Ref() }
//line :286:1
func A_arbace_math_subtract_exact__inliner__446000080_A_New() *A_arbace_math_subtract_exact__inliner__446000080_A { A_arbace_math_A_Init(); t := &A_arbace_math_subtract_exact__inliner__446000080_A{}; t.Ctor(); return t }
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Ctor() {}
//line :286:1
func (t *A_arbace_math_subtract_exact__inliner__446000080_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_57), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_58), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_59), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1)))))) }








func A_arbace_math_multiply_exact_A_New() *A_arbace_math_multiply_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_multiply_exact_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_MultiplyExact_J_J__J(x__0, y__1)).Ref() }
//line :295:1
func A_arbace_math_multiply_exact__inliner__446000083_A_New() *A_arbace_math_multiply_exact__inliner__446000083_A { A_arbace_math_A_Init(); t := &A_arbace_math_multiply_exact__inliner__446000083_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Ctor() {}
//line :295:1
func (t *A_arbace_math_multiply_exact__inliner__446000083_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_60), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_61), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_62), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1)))))) }








func A_arbace_math_increment_exact_A_New() *A_arbace_math_increment_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_increment_exact_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_IncrementExact_J__J(a__0)).Ref() }
//line :304:1
func A_arbace_math_increment_exact__inliner__446000086_A_New() *A_arbace_math_increment_exact__inliner__446000086_A { A_arbace_math_A_Init(); t := &A_arbace_math_increment_exact__inliner__446000086_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Ctor() {}
//line :304:1
func (t *A_arbace_math_increment_exact__inliner__446000086_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_63), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_64), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }








func A_arbace_math_decrement_exact_A_New() *A_arbace_math_decrement_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_decrement_exact_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_DecrementExact_J__J(a__0)).Ref() }
//line :313:1
func A_arbace_math_decrement_exact__inliner__446000089_A_New() *A_arbace_math_decrement_exact__inliner__446000089_A { A_arbace_math_A_Init(); t := &A_arbace_math_decrement_exact__inliner__446000089_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Ctor() {}
//line :313:1
func (t *A_arbace_math_decrement_exact__inliner__446000089_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_65), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_66), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }








func A_arbace_math_negate_exact_A_New() *A_arbace_math_negate_exact_A { A_arbace_math_A_Init(); t := &A_arbace_math_negate_exact_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact_A) Invoke_O_O__O(self, p_a__0 any) any { var a__0 int64 = lang.RT_LongCast_O__J_NoInit(p_a__0); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_NegateExact_J__J(a__0)).Ref() }
//line :322:1
func A_arbace_math_negate_exact__inliner__446000092_A_New() *A_arbace_math_negate_exact__inliner__446000092_A { A_arbace_math_A_Init(); t := &A_arbace_math_negate_exact__inliner__446000092_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Ctor() {}
//line :322:1
func (t *A_arbace_math_negate_exact__inliner__446000092_A) Invoke_O_O__O(self, a__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_67), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_68), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(a__0)))))) }








func A_arbace_math_floor_div_A_New() *A_arbace_math_floor_div_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_div_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_FloorDiv_J_J__J(x__0, y__1)).Ref() }
//line :331:1
func A_arbace_math_floor_div__inliner__446000095_A_New() *A_arbace_math_floor_div__inliner__446000095_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_div__inliner__446000095_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Ctor() {}
//line :331:1
func (t *A_arbace_math_floor_div__inliner__446000095_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_69), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_70), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_71), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1)))))) }









func A_arbace_math_floor_mod_A_New() *A_arbace_math_floor_mod_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_mod_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 int64 = lang.RT_LongCast_O__J_NoInit(p_x__0); var y__1 int64 = lang.RT_LongCast_O__J_NoInit(p_y__1); return jrt.Long_ValueOf_J__Long_NoInit(jrt.Math_FloorMod_J_J__J(x__0, y__1)).Ref() }
//line :341:1
func A_arbace_math_floor_mod__inliner__446000098_A_New() *A_arbace_math_floor_mod__inliner__446000098_A { A_arbace_math_A_Init(); t := &A_arbace_math_floor_mod__inliner__446000098_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Ctor() {}
//line :341:1
func (t *A_arbace_math_floor_mod__inliner__446000098_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_72), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_73), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_74), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1)))))) }









func A_arbace_math_ulp_A_New() *A_arbace_math_ulp_A { A_arbace_math_A_Init(); t := &A_arbace_math_ulp_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Ulp_D__D(d__0)).Ref() }
//line :351:1
func A_arbace_math_ulp__inliner__446000101_A_New() *A_arbace_math_ulp__inliner__446000101_A { A_arbace_math_A_Init(); t := &A_arbace_math_ulp__inliner__446000101_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Ctor() {}
//line :351:1
func (t *A_arbace_math_ulp__inliner__446000101_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_75), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_76), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0)))))) }












func A_arbace_math_signum_A_New() *A_arbace_math_signum_A { A_arbace_math_A_Init(); t := &A_arbace_math_signum_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Signum_D__D(d__0)).Ref() }
//line :364:1
func A_arbace_math_signum__inliner__446000104_A_New() *A_arbace_math_signum__inliner__446000104_A { A_arbace_math_A_Init(); t := &A_arbace_math_signum__inliner__446000104_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Ctor() {}
//line :364:1
func (t *A_arbace_math_signum__inliner__446000104_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_77), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_78), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0)))))) }









func A_arbace_math_sinh_A_New() *A_arbace_math_sinh_A { A_arbace_math_A_Init(); t := &A_arbace_math_sinh_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Sinh_D__D(x__0)).Ref() }
//line :374:1
func A_arbace_math_sinh__inliner__446000107_A_New() *A_arbace_math_sinh__inliner__446000107_A { A_arbace_math_A_Init(); t := &A_arbace_math_sinh__inliner__446000107_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Ctor() {}
//line :374:1
func (t *A_arbace_math_sinh__inliner__446000107_A) Invoke_O_O__O(self, x__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_79), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_80), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))))) }










func A_arbace_math_cosh_A_New() *A_arbace_math_cosh_A { A_arbace_math_A_Init(); t := &A_arbace_math_cosh_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Cosh_D__D(x__0)).Ref() }
//line :385:1
func A_arbace_math_cosh__inliner__446000110_A_New() *A_arbace_math_cosh__inliner__446000110_A { A_arbace_math_A_Init(); t := &A_arbace_math_cosh__inliner__446000110_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Ctor() {}
//line :385:1
func (t *A_arbace_math_cosh__inliner__446000110_A) Invoke_O_O__O(self, x__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_81), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_82), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))))) }











func A_arbace_math_tanh_A_New() *A_arbace_math_tanh_A { A_arbace_math_A_Init(); t := &A_arbace_math_tanh_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Tanh_D__D(x__0)).Ref() }
//line :397:1
func A_arbace_math_tanh__inliner__446000113_A_New() *A_arbace_math_tanh__inliner__446000113_A { A_arbace_math_A_Init(); t := &A_arbace_math_tanh__inliner__446000113_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Ctor() {}
//line :397:1
func (t *A_arbace_math_tanh__inliner__446000113_A) Invoke_O_O__O(self, x__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_83), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_84), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))))) }












func A_arbace_math_hypot_A_New() *A_arbace_math_hypot_A { A_arbace_math_A_Init(); t := &A_arbace_math_hypot_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot_A) Invoke_O_O_O__O(self, p_x__0, p_y__1 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); var y__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_y__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Hypot_D_D__D(x__0, y__1)).Ref() }
//line :410:1
func A_arbace_math_hypot__inliner__446000116_A_New() *A_arbace_math_hypot__inliner__446000116_A { A_arbace_math_A_Init(); t := &A_arbace_math_hypot__inliner__446000116_A{}; t.Ctor(); return t }
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Ctor() {}
//line :410:1
func (t *A_arbace_math_hypot__inliner__446000116_A) Invoke_O_O_O__O(self, x__0, y__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_85), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_86), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_87), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(y__1)))))) }










func A_arbace_math_expm1_A_New() *A_arbace_math_expm1_A { A_arbace_math_A_Init(); t := &A_arbace_math_expm1_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Expm1_D__D(x__0)).Ref() }
//line :421:1
func A_arbace_math_expm1__inliner__446000119_A_New() *A_arbace_math_expm1__inliner__446000119_A { A_arbace_math_A_Init(); t := &A_arbace_math_expm1__inliner__446000119_A{}; t.Ctor(); return t }
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Ctor() {}
//line :421:1
func (t *A_arbace_math_expm1__inliner__446000119_A) Invoke_O_O__O(self, x__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_88), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_89), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))))) }












func A_arbace_math_log1p_A_New() *A_arbace_math_log1p_A { A_arbace_math_A_Init(); t := &A_arbace_math_log1p_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p_A) Invoke_O_O__O(self, p_x__0 any) any { var x__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_x__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Log1p_D__D(x__0)).Ref() }
//line :434:1
func A_arbace_math_log1p__inliner__446000122_A_New() *A_arbace_math_log1p__inliner__446000122_A { A_arbace_math_A_Init(); t := &A_arbace_math_log1p__inliner__446000122_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Ctor() {}
//line :434:1
func (t *A_arbace_math_log1p__inliner__446000122_A) Invoke_O_O__O(self, x__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_90), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_91), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(x__0)))))) }













func A_arbace_math_copy_sign_A_New() *A_arbace_math_copy_sign_A { A_arbace_math_A_Init(); t := &A_arbace_math_copy_sign_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign_A) Invoke_O_O_O__O(self, p_magnitude__0, p_sign__1 any) any { var magnitude__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_magnitude__0); var sign__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_sign__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_CopySign_D_D__D(magnitude__0, sign__1)).Ref() }
//line :448:1
func A_arbace_math_copy_sign__inliner__446000125_A_New() *A_arbace_math_copy_sign__inliner__446000125_A { A_arbace_math_A_Init(); t := &A_arbace_math_copy_sign__inliner__446000125_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Ctor() {}
//line :448:1
func (t *A_arbace_math_copy_sign__inliner__446000125_A) Invoke_O_O_O__O(self, magnitude__0, sign__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_92), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_93), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(magnitude__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_94), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(sign__1)))))) }









func A_arbace_math_get_exponent_A_New() *A_arbace_math_get_exponent_A { A_arbace_math_A_Init(); t := &A_arbace_math_get_exponent_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return /*line :467:1*/ jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Math_GetExponent_D__I(d__0)).Ref() }
//line :458:1
func A_arbace_math_get_exponent__inliner__446000128_A_New() *A_arbace_math_get_exponent__inliner__446000128_A { A_arbace_math_A_Init(); t := &A_arbace_math_get_exponent__inliner__446000128_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Ctor() {}
//line :458:1
func (t *A_arbace_math_get_exponent__inliner__446000128_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_95), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_96), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0)))))) }










func A_arbace_math_next_after_A_New() *A_arbace_math_next_after_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_after_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after_A) Invoke_O_O_O__O(self, p_start__0, p_direction__1 any) any { var start__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_start__0); var direction__1 float64 = lang.RT_DoubleCast_O__D_NoInit(p_direction__1); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_NextAfter_D_D__D(start__0, direction__1)).Ref() }
//line :469:1
func A_arbace_math_next_after__inliner__446000131_A_New() *A_arbace_math_next_after__inliner__446000131_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_after__inliner__446000131_A{}; t.Ctor(); return t }
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Ctor() {}
//line :469:1
func (t *A_arbace_math_next_after__inliner__446000131_A) Invoke_O_O_O__O(self, start__0, direction__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_97), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_98), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(start__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_99), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(direction__1)))))) }

















func A_arbace_math_next_up_A_New() *A_arbace_math_next_up_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_up_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_NextUp_D__D(d__0)).Ref() }
//line :487:1
func A_arbace_math_next_up__inliner__446000134_A_New() *A_arbace_math_next_up__inliner__446000134_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_up__inliner__446000134_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Ctor() {}
//line :487:1
func (t *A_arbace_math_next_up__inliner__446000134_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_100), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_101), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0)))))) }











func A_arbace_math_next_down_A_New() *A_arbace_math_next_down_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_down_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_NextDown_D__D(d__0)).Ref() }
//line :499:1
func A_arbace_math_next_down__inliner__446000137_A_New() *A_arbace_math_next_down__inliner__446000137_A { A_arbace_math_A_Init(); t := &A_arbace_math_next_down__inliner__446000137_A{}; t.Ctor(); return t }
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Ctor() {}
//line :499:1
func (t *A_arbace_math_next_down__inliner__446000137_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_102), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_103), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0)))))) }











func A_arbace_math_scalb_A_New() *A_arbace_math_scalb_A { A_arbace_math_A_Init(); t := &A_arbace_math_scalb_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb_A) Invoke_O_O_O__O(self, p_d__0, scaleFactor__1 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); return jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Scalb_D_I__D(d__0, lang.RT_IntCast_O__I_NoInit(scaleFactor__1))).Ref() }
//line :511:1
func A_arbace_math_scalb__inliner__446000140_A_New() *A_arbace_math_scalb__inliner__446000140_A { A_arbace_math_A_Init(); t := &A_arbace_math_scalb__inliner__446000140_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Ctor() {}
//line :511:1
func (t *A_arbace_math_scalb__inliner__446000140_A) Invoke_O_O_O__O(self, d__0, scaleFactor__1 any) any { return lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_104), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_105), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(d__0)))), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_7.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_math_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_math_A_const_106), lang.IFn_Cast(A_arbace_math_A_const_9.GetRawRoot__O()).Invoke_O__O(scaleFactor__1)))))) }















































type A_arbace_math_A struct{ jrt.Object }

var A_arbace_math_A_const_pool *jrt.RefArray

var A_arbace_math_A_const_0 *lang.Var

var A_arbace_math_A_const_1 any

var A_arbace_math_A_const_2 *lang.Var

var A_arbace_math_A_const_3 *lang.Var

var A_arbace_math_A_const_4 *lang.Var

var A_arbace_math_A_const_5 any

var A_arbace_math_A_const_6 *lang.Var

var A_arbace_math_A_const_7 *lang.Var

var A_arbace_math_A_const_8 *lang.Var

var A_arbace_math_A_const_9 *lang.Var

var A_arbace_math_A_const_10 any

var A_arbace_math_A_const_11 any

var A_arbace_math_A_const_12 any

var A_arbace_math_A_const_13 any

var A_arbace_math_A_const_14 any

var A_arbace_math_A_const_15 any

var A_arbace_math_A_const_16 any

var A_arbace_math_A_const_17 any

var A_arbace_math_A_const_18 any

var A_arbace_math_A_const_19 any

var A_arbace_math_A_const_20 any

var A_arbace_math_A_const_21 any

var A_arbace_math_A_const_22 any

var A_arbace_math_A_const_23 any

var A_arbace_math_A_const_24 any

var A_arbace_math_A_const_25 any

var A_arbace_math_A_const_26 any

var A_arbace_math_A_const_27 any

var A_arbace_math_A_const_28 any

var A_arbace_math_A_const_29 any

var A_arbace_math_A_const_30 any

var A_arbace_math_A_const_31 any

var A_arbace_math_A_const_32 any

var A_arbace_math_A_const_33 any

var A_arbace_math_A_const_34 any

var A_arbace_math_A_const_35 any

var A_arbace_math_A_const_36 any

var A_arbace_math_A_const_37 any

var A_arbace_math_A_const_38 any

var A_arbace_math_A_const_39 any

var A_arbace_math_A_const_40 any

var A_arbace_math_A_const_41 any

var A_arbace_math_A_const_42 any

var A_arbace_math_A_const_43 any

var A_arbace_math_A_const_44 any

var A_arbace_math_A_const_45 any

var A_arbace_math_A_const_46 any

var A_arbace_math_A_const_47 any

var A_arbace_math_A_const_48 any

var A_arbace_math_A_const_49 any

var A_arbace_math_A_const_50 any

var A_arbace_math_A_const_51 any

var A_arbace_math_A_const_52 any

var A_arbace_math_A_const_53 any

var A_arbace_math_A_const_54 any

var A_arbace_math_A_const_55 any

var A_arbace_math_A_const_56 any

var A_arbace_math_A_const_57 any

var A_arbace_math_A_const_58 any

var A_arbace_math_A_const_59 any

var A_arbace_math_A_const_60 any

var A_arbace_math_A_const_61 any

var A_arbace_math_A_const_62 any

var A_arbace_math_A_const_63 any

var A_arbace_math_A_const_64 any

var A_arbace_math_A_const_65 any

var A_arbace_math_A_const_66 any

var A_arbace_math_A_const_67 any

var A_arbace_math_A_const_68 any

var A_arbace_math_A_const_69 any

var A_arbace_math_A_const_70 any

var A_arbace_math_A_const_71 any

var A_arbace_math_A_const_72 any

var A_arbace_math_A_const_73 any

var A_arbace_math_A_const_74 any

var A_arbace_math_A_const_75 any

var A_arbace_math_A_const_76 any

var A_arbace_math_A_const_77 any

var A_arbace_math_A_const_78 any

var A_arbace_math_A_const_79 any

var A_arbace_math_A_const_80 any

var A_arbace_math_A_const_81 any

var A_arbace_math_A_const_82 any

var A_arbace_math_A_const_83 any

var A_arbace_math_A_const_84 any

var A_arbace_math_A_const_85 any

var A_arbace_math_A_const_86 any

var A_arbace_math_A_const_87 any

var A_arbace_math_A_const_88 any

var A_arbace_math_A_const_89 any

var A_arbace_math_A_const_90 any

var A_arbace_math_A_const_91 any

var A_arbace_math_A_const_92 any

var A_arbace_math_A_const_93 any

var A_arbace_math_A_const_94 any

var A_arbace_math_A_const_95 any

var A_arbace_math_A_const_96 any

var A_arbace_math_A_const_97 any

var A_arbace_math_A_const_98 any

var A_arbace_math_A_const_99 any

var A_arbace_math_A_const_100 any

var A_arbace_math_A_const_101 any

var A_arbace_math_A_const_102 any

var A_arbace_math_A_const_103 any

var A_arbace_math_A_const_104 any

var A_arbace_math_A_const_105 any

var A_arbace_math_A_const_106 any

var A_arbace_math_A_init jrt.ClassInit

func A_arbace_math_A_Init() { if !A_arbace_math_A_init.Done() { A_arbace_math_A_init.Run(A_arbace_math_A_clinit) } }

func A_arbace_math_A_clinit() { A_arbace_math_A_clinit_p0(); A_arbace_math_A_clinit_p1(); A_arbace_math_A_clinit_p2(); A_arbace_math_A_clinit_p3(); A_arbace_math_A_clinit_p4(); A_arbace_math_A_clinit_p5(); A_arbace_math_A_clinit_p6() }

func A_arbace_math_A_clinit_p0() { jrt.StartCheck(); A_arbace_math_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 156); A_arbace_math_A_const_0 = lang.Var_Cast(A_arbace_math_A_const_pool.A[49]); A_arbace_math_A_const_1 = A_arbace_math_A_const_pool.A[50]; A_arbace_math_A_const_2 = lang.Var_Cast(A_arbace_math_A_const_pool.A[51]); A_arbace_math_A_const_3 = lang.Var_Cast(A_arbace_math_A_const_pool.A[52]); A_arbace_math_A_const_4 = lang.Var_Cast(A_arbace_math_A_const_pool.A[53]); A_arbace_math_A_const_5 = A_arbace_math_A_const_pool.A[54]; A_arbace_math_A_const_6 = lang.Var_Cast(A_arbace_math_A_const_pool.A[55]); A_arbace_math_A_const_7 = lang.Var_Cast(A_arbace_math_A_const_pool.A[56]); A_arbace_math_A_const_8 = lang.Var_Cast(A_arbace_math_A_const_pool.A[57]); A_arbace_math_A_const_9 = lang.Var_Cast(A_arbace_math_A_const_pool.A[58]); A_arbace_math_A_const_10 = A_arbace_math_A_const_pool.A[59]; A_arbace_math_A_const_11 = A_arbace_math_A_const_pool.A[60] }

func A_arbace_math_A_clinit_p1() { A_arbace_math_A_const_12 = A_arbace_math_A_const_pool.A[61]; A_arbace_math_A_const_13 = A_arbace_math_A_const_pool.A[62]; A_arbace_math_A_const_14 = A_arbace_math_A_const_pool.A[63]; A_arbace_math_A_const_15 = A_arbace_math_A_const_pool.A[64]; A_arbace_math_A_const_16 = A_arbace_math_A_const_pool.A[65]; A_arbace_math_A_const_17 = A_arbace_math_A_const_pool.A[66]; A_arbace_math_A_const_18 = A_arbace_math_A_const_pool.A[67]; A_arbace_math_A_const_19 = A_arbace_math_A_const_pool.A[68]; A_arbace_math_A_const_20 = A_arbace_math_A_const_pool.A[69]; A_arbace_math_A_const_21 = A_arbace_math_A_const_pool.A[70]; A_arbace_math_A_const_22 = A_arbace_math_A_const_pool.A[71]; A_arbace_math_A_const_23 = A_arbace_math_A_const_pool.A[72]; A_arbace_math_A_const_24 = A_arbace_math_A_const_pool.A[73]; A_arbace_math_A_const_25 = A_arbace_math_A_const_pool.A[74]; A_arbace_math_A_const_26 = A_arbace_math_A_const_pool.A[75]; A_arbace_math_A_const_27 = A_arbace_math_A_const_pool.A[76] }

func A_arbace_math_A_clinit_p2() { A_arbace_math_A_const_28 = A_arbace_math_A_const_pool.A[77]; A_arbace_math_A_const_29 = A_arbace_math_A_const_pool.A[78]; A_arbace_math_A_const_30 = A_arbace_math_A_const_pool.A[79]; A_arbace_math_A_const_31 = A_arbace_math_A_const_pool.A[80]; A_arbace_math_A_const_32 = A_arbace_math_A_const_pool.A[81]; A_arbace_math_A_const_33 = A_arbace_math_A_const_pool.A[82]; A_arbace_math_A_const_34 = A_arbace_math_A_const_pool.A[83]; A_arbace_math_A_const_35 = A_arbace_math_A_const_pool.A[84]; A_arbace_math_A_const_36 = A_arbace_math_A_const_pool.A[85]; A_arbace_math_A_const_37 = A_arbace_math_A_const_pool.A[86]; A_arbace_math_A_const_38 = A_arbace_math_A_const_pool.A[87]; A_arbace_math_A_const_39 = A_arbace_math_A_const_pool.A[88]; A_arbace_math_A_const_40 = A_arbace_math_A_const_pool.A[89]; A_arbace_math_A_const_41 = A_arbace_math_A_const_pool.A[90]; A_arbace_math_A_const_42 = A_arbace_math_A_const_pool.A[91]; A_arbace_math_A_const_43 = A_arbace_math_A_const_pool.A[92] }

func A_arbace_math_A_clinit_p3() { A_arbace_math_A_const_44 = A_arbace_math_A_const_pool.A[93]; A_arbace_math_A_const_45 = A_arbace_math_A_const_pool.A[94]; A_arbace_math_A_const_46 = A_arbace_math_A_const_pool.A[95]; A_arbace_math_A_const_47 = A_arbace_math_A_const_pool.A[96]; A_arbace_math_A_const_48 = A_arbace_math_A_const_pool.A[97]; A_arbace_math_A_const_49 = A_arbace_math_A_const_pool.A[98]; A_arbace_math_A_const_50 = A_arbace_math_A_const_pool.A[99]; A_arbace_math_A_const_51 = A_arbace_math_A_const_pool.A[100]; A_arbace_math_A_const_52 = A_arbace_math_A_const_pool.A[101]; A_arbace_math_A_const_53 = A_arbace_math_A_const_pool.A[102]; A_arbace_math_A_const_54 = A_arbace_math_A_const_pool.A[103]; A_arbace_math_A_const_55 = A_arbace_math_A_const_pool.A[104]; A_arbace_math_A_const_56 = A_arbace_math_A_const_pool.A[105]; A_arbace_math_A_const_57 = A_arbace_math_A_const_pool.A[106]; A_arbace_math_A_const_58 = A_arbace_math_A_const_pool.A[107]; A_arbace_math_A_const_59 = A_arbace_math_A_const_pool.A[108] }

func A_arbace_math_A_clinit_p4() { A_arbace_math_A_const_60 = A_arbace_math_A_const_pool.A[109]; A_arbace_math_A_const_61 = A_arbace_math_A_const_pool.A[110]; A_arbace_math_A_const_62 = A_arbace_math_A_const_pool.A[111]; A_arbace_math_A_const_63 = A_arbace_math_A_const_pool.A[112]; A_arbace_math_A_const_64 = A_arbace_math_A_const_pool.A[113]; A_arbace_math_A_const_65 = A_arbace_math_A_const_pool.A[114]; A_arbace_math_A_const_66 = A_arbace_math_A_const_pool.A[115]; A_arbace_math_A_const_67 = A_arbace_math_A_const_pool.A[116]; A_arbace_math_A_const_68 = A_arbace_math_A_const_pool.A[117]; A_arbace_math_A_const_69 = A_arbace_math_A_const_pool.A[118]; A_arbace_math_A_const_70 = A_arbace_math_A_const_pool.A[119]; A_arbace_math_A_const_71 = A_arbace_math_A_const_pool.A[120]; A_arbace_math_A_const_72 = A_arbace_math_A_const_pool.A[121]; A_arbace_math_A_const_73 = A_arbace_math_A_const_pool.A[122]; A_arbace_math_A_const_74 = A_arbace_math_A_const_pool.A[123]; A_arbace_math_A_const_75 = A_arbace_math_A_const_pool.A[124] }

func A_arbace_math_A_clinit_p5() { A_arbace_math_A_const_76 = A_arbace_math_A_const_pool.A[125]; A_arbace_math_A_const_77 = A_arbace_math_A_const_pool.A[126]; A_arbace_math_A_const_78 = A_arbace_math_A_const_pool.A[127]; A_arbace_math_A_const_79 = A_arbace_math_A_const_pool.A[128]; A_arbace_math_A_const_80 = A_arbace_math_A_const_pool.A[129]; A_arbace_math_A_const_81 = A_arbace_math_A_const_pool.A[130]; A_arbace_math_A_const_82 = A_arbace_math_A_const_pool.A[131]; A_arbace_math_A_const_83 = A_arbace_math_A_const_pool.A[132]; A_arbace_math_A_const_84 = A_arbace_math_A_const_pool.A[133]; A_arbace_math_A_const_85 = A_arbace_math_A_const_pool.A[134]; A_arbace_math_A_const_86 = A_arbace_math_A_const_pool.A[135]; A_arbace_math_A_const_87 = A_arbace_math_A_const_pool.A[136]; A_arbace_math_A_const_88 = A_arbace_math_A_const_pool.A[137]; A_arbace_math_A_const_89 = A_arbace_math_A_const_pool.A[138]; A_arbace_math_A_const_90 = A_arbace_math_A_const_pool.A[139]; A_arbace_math_A_const_91 = A_arbace_math_A_const_pool.A[140] }

func A_arbace_math_A_clinit_p6() { A_arbace_math_A_const_92 = A_arbace_math_A_const_pool.A[141]; A_arbace_math_A_const_93 = A_arbace_math_A_const_pool.A[142]; A_arbace_math_A_const_94 = A_arbace_math_A_const_pool.A[143]; A_arbace_math_A_const_95 = A_arbace_math_A_const_pool.A[144]; A_arbace_math_A_const_96 = A_arbace_math_A_const_pool.A[145]; A_arbace_math_A_const_97 = A_arbace_math_A_const_pool.A[146]; A_arbace_math_A_const_98 = A_arbace_math_A_const_pool.A[147]; A_arbace_math_A_const_99 = A_arbace_math_A_const_pool.A[148]; A_arbace_math_A_const_100 = A_arbace_math_A_const_pool.A[149]; A_arbace_math_A_const_101 = A_arbace_math_A_const_pool.A[150]; A_arbace_math_A_const_102 = A_arbace_math_A_const_pool.A[151]; A_arbace_math_A_const_103 = A_arbace_math_A_const_pool.A[152]; A_arbace_math_A_const_104 = A_arbace_math_A_const_pool.A[153]; A_arbace_math_A_const_105 = A_arbace_math_A_const_pool.A[154]; A_arbace_math_A_const_106 = A_arbace_math_A_const_pool.A[155] }

func A_arbace_math_A_New() *A_arbace_math_A { A_arbace_math_A_Init(); t := &A_arbace_math_A{}; t.Ctor(); return t }

func (t *A_arbace_math_A) Ctor() {}

func (t *A_arbace_math_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_A) GetClass__Class() *jrt.Class { return A_arbace_math_A_class }

func (t *A_arbace_math_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_A); return ok }

func A_arbace_math_A_Cast(x any) *A_arbace_math_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_A_class)) }; return v }



type A_arbace_math_IEEE_remainder_A struct{ j2g_header uint64 }

var A_arbace_math_IEEE_remainder_A_fn_class *jrt.Class



type A_arbace_math_IEEE_remainder__inliner__446000053_A struct{ j2g_header uint64 }

var A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class *jrt.Class



type A_arbace_math_acos_A struct{ j2g_header uint64 }

var A_arbace_math_acos_A_fn_class *jrt.Class



type A_arbace_math_acos__inliner__446000026_A struct{ j2g_header uint64 }

var A_arbace_math_acos__inliner__446000026_A_fn_class *jrt.Class



type A_arbace_math_add_exact_A struct{ j2g_header uint64 }

var A_arbace_math_add_exact_A_fn_class *jrt.Class



type A_arbace_math_add_exact__inliner__446000077_A struct{ j2g_header uint64 }

var A_arbace_math_add_exact__inliner__446000077_A_fn_class *jrt.Class



type A_arbace_math_asin_A struct{ j2g_header uint64 }

var A_arbace_math_asin_A_fn_class *jrt.Class



type A_arbace_math_asin__inliner__446000023_A struct{ j2g_header uint64 }

var A_arbace_math_asin__inliner__446000023_A_fn_class *jrt.Class



type A_arbace_math_atan_A struct{ j2g_header uint64 }

var A_arbace_math_atan_A_fn_class *jrt.Class



type A_arbace_math_atan2_A struct{ j2g_header uint64 }

var A_arbace_math_atan2_A_fn_class *jrt.Class



type A_arbace_math_atan2__inliner__446000065_A struct{ j2g_header uint64 }

var A_arbace_math_atan2__inliner__446000065_A_fn_class *jrt.Class



type A_arbace_math_atan__inliner__446000029_A struct{ j2g_header uint64 }

var A_arbace_math_atan__inliner__446000029_A_fn_class *jrt.Class



type A_arbace_math_cbrt_A struct{ j2g_header uint64 }

var A_arbace_math_cbrt_A_fn_class *jrt.Class



type A_arbace_math_cbrt__inliner__446000050_A struct{ j2g_header uint64 }

var A_arbace_math_cbrt__inliner__446000050_A_fn_class *jrt.Class



type A_arbace_math_ceil_A struct{ j2g_header uint64 }

var A_arbace_math_ceil_A_fn_class *jrt.Class



type A_arbace_math_ceil__inliner__446000056_A struct{ j2g_header uint64 }

var A_arbace_math_ceil__inliner__446000056_A_fn_class *jrt.Class



type A_arbace_math_copy_sign_A struct{ j2g_header uint64 }

var A_arbace_math_copy_sign_A_fn_class *jrt.Class



type A_arbace_math_copy_sign__inliner__446000125_A struct{ j2g_header uint64 }

var A_arbace_math_copy_sign__inliner__446000125_A_fn_class *jrt.Class



type A_arbace_math_cos_A struct{ j2g_header uint64 }

var A_arbace_math_cos_A_fn_class *jrt.Class



type A_arbace_math_cos__inliner__446000017_A struct{ j2g_header uint64 }

var A_arbace_math_cos__inliner__446000017_A_fn_class *jrt.Class



type A_arbace_math_cosh_A struct{ j2g_header uint64 }

var A_arbace_math_cosh_A_fn_class *jrt.Class



type A_arbace_math_cosh__inliner__446000110_A struct{ j2g_header uint64 }

var A_arbace_math_cosh__inliner__446000110_A_fn_class *jrt.Class



type A_arbace_math_decrement_exact_A struct{ j2g_header uint64 }

var A_arbace_math_decrement_exact_A_fn_class *jrt.Class



type A_arbace_math_decrement_exact__inliner__446000089_A struct{ j2g_header uint64 }

var A_arbace_math_decrement_exact__inliner__446000089_A_fn_class *jrt.Class



type A_arbace_math_eval446000004_A struct{ jrt.Object }

func A_arbace_math_eval446000004_A_New() *A_arbace_math_eval446000004_A { t := &A_arbace_math_eval446000004_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000004_A) Ctor() {}

func (t *A_arbace_math_eval446000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000004_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000004_A_class }

func (t *A_arbace_math_eval446000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000004_A); return ok }

func A_arbace_math_eval446000004_A_Cast(x any) *A_arbace_math_eval446000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000004_A_class)) }; return v }



type A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A struct{ j2g_header uint64 }

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class *jrt.Class



type A_arbace_math_eval446000008_A struct{ jrt.Object }

func A_arbace_math_eval446000008_A_New() *A_arbace_math_eval446000008_A { t := &A_arbace_math_eval446000008_A{}; t.Ctor(); return t }

func (t *A_arbace_math_eval446000008_A) Ctor() {}

func (t *A_arbace_math_eval446000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math_eval446000008_A) GetClass__Class() *jrt.Class { return A_arbace_math_eval446000008_A_class }

func (t *A_arbace_math_eval446000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math_eval446000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math_eval446000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math_eval446000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math_eval446000008_A); return ok }

func A_arbace_math_eval446000008_A_Cast(x any) *A_arbace_math_eval446000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math_eval446000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math_eval446000008_A_class)) }; return v }



type A_arbace_math_eval446000008_fn__446000009_A struct{ j2g_header uint64 }

var A_arbace_math_eval446000008_fn__446000009_A_fn_class *jrt.Class



type A_arbace_math_exp_A struct{ j2g_header uint64 }

var A_arbace_math_exp_A_fn_class *jrt.Class



type A_arbace_math_exp__inliner__446000038_A struct{ j2g_header uint64 }

var A_arbace_math_exp__inliner__446000038_A_fn_class *jrt.Class



type A_arbace_math_expm1_A struct{ j2g_header uint64 }

var A_arbace_math_expm1_A_fn_class *jrt.Class



type A_arbace_math_expm1__inliner__446000119_A struct{ j2g_header uint64 }

var A_arbace_math_expm1__inliner__446000119_A_fn_class *jrt.Class



type A_arbace_math_floor_A struct{ j2g_header uint64 }

var A_arbace_math_floor_A_fn_class *jrt.Class



type A_arbace_math_floor__inliner__446000059_A struct{ j2g_header uint64 }

var A_arbace_math_floor__inliner__446000059_A_fn_class *jrt.Class



type A_arbace_math_floor_div_A struct{ j2g_header uint64 }

var A_arbace_math_floor_div_A_fn_class *jrt.Class



type A_arbace_math_floor_div__inliner__446000095_A struct{ j2g_header uint64 }

var A_arbace_math_floor_div__inliner__446000095_A_fn_class *jrt.Class



type A_arbace_math_floor_mod_A struct{ j2g_header uint64 }

var A_arbace_math_floor_mod_A_fn_class *jrt.Class



type A_arbace_math_floor_mod__inliner__446000098_A struct{ j2g_header uint64 }

var A_arbace_math_floor_mod__inliner__446000098_A_fn_class *jrt.Class



type A_arbace_math_get_exponent_A struct{ j2g_header uint64 }

var A_arbace_math_get_exponent_A_fn_class *jrt.Class



type A_arbace_math_get_exponent__inliner__446000128_A struct{ j2g_header uint64 }

var A_arbace_math_get_exponent__inliner__446000128_A_fn_class *jrt.Class



type A_arbace_math_hypot_A struct{ j2g_header uint64 }

var A_arbace_math_hypot_A_fn_class *jrt.Class



type A_arbace_math_hypot__inliner__446000116_A struct{ j2g_header uint64 }

var A_arbace_math_hypot__inliner__446000116_A_fn_class *jrt.Class



type A_arbace_math_increment_exact_A struct{ j2g_header uint64 }

var A_arbace_math_increment_exact_A_fn_class *jrt.Class



type A_arbace_math_increment_exact__inliner__446000086_A struct{ j2g_header uint64 }

var A_arbace_math_increment_exact__inliner__446000086_A_fn_class *jrt.Class



type A_arbace_math_log_A struct{ j2g_header uint64 }

var A_arbace_math_log_A_fn_class *jrt.Class



type A_arbace_math_log10_A struct{ j2g_header uint64 }

var A_arbace_math_log10_A_fn_class *jrt.Class



type A_arbace_math_log10__inliner__446000044_A struct{ j2g_header uint64 }

var A_arbace_math_log10__inliner__446000044_A_fn_class *jrt.Class



type A_arbace_math_log1p_A struct{ j2g_header uint64 }

var A_arbace_math_log1p_A_fn_class *jrt.Class



type A_arbace_math_log1p__inliner__446000122_A struct{ j2g_header uint64 }

var A_arbace_math_log1p__inliner__446000122_A_fn_class *jrt.Class



type A_arbace_math_log__inliner__446000041_A struct{ j2g_header uint64 }

var A_arbace_math_log__inliner__446000041_A_fn_class *jrt.Class



type A_arbace_math_multiply_exact_A struct{ j2g_header uint64 }

var A_arbace_math_multiply_exact_A_fn_class *jrt.Class



type A_arbace_math_multiply_exact__inliner__446000083_A struct{ j2g_header uint64 }

var A_arbace_math_multiply_exact__inliner__446000083_A_fn_class *jrt.Class



type A_arbace_math_negate_exact_A struct{ j2g_header uint64 }

var A_arbace_math_negate_exact_A_fn_class *jrt.Class



type A_arbace_math_negate_exact__inliner__446000092_A struct{ j2g_header uint64 }

var A_arbace_math_negate_exact__inliner__446000092_A_fn_class *jrt.Class



type A_arbace_math_next_after_A struct{ j2g_header uint64 }

var A_arbace_math_next_after_A_fn_class *jrt.Class



type A_arbace_math_next_after__inliner__446000131_A struct{ j2g_header uint64 }

var A_arbace_math_next_after__inliner__446000131_A_fn_class *jrt.Class



type A_arbace_math_next_down_A struct{ j2g_header uint64 }

var A_arbace_math_next_down_A_fn_class *jrt.Class



type A_arbace_math_next_down__inliner__446000137_A struct{ j2g_header uint64 }

var A_arbace_math_next_down__inliner__446000137_A_fn_class *jrt.Class



type A_arbace_math_next_up_A struct{ j2g_header uint64 }

var A_arbace_math_next_up_A_fn_class *jrt.Class



type A_arbace_math_next_up__inliner__446000134_A struct{ j2g_header uint64 }

var A_arbace_math_next_up__inliner__446000134_A_fn_class *jrt.Class



type A_arbace_math_pow_A struct{ j2g_header uint64 }

var A_arbace_math_pow_A_fn_class *jrt.Class



type A_arbace_math_pow__inliner__446000068_A struct{ j2g_header uint64 }

var A_arbace_math_pow__inliner__446000068_A_fn_class *jrt.Class



type A_arbace_math_random_A struct{ j2g_header uint64 }

var A_arbace_math_random_A_fn_class *jrt.Class



type A_arbace_math_random__inliner__446000074_A struct{ j2g_header uint64 }

var A_arbace_math_random__inliner__446000074_A_fn_class *jrt.Class



type A_arbace_math_rint_A struct{ j2g_header uint64 }

var A_arbace_math_rint_A_fn_class *jrt.Class



type A_arbace_math_rint__inliner__446000062_A struct{ j2g_header uint64 }

var A_arbace_math_rint__inliner__446000062_A_fn_class *jrt.Class



type A_arbace_math_round_A struct{ j2g_header uint64 }

var A_arbace_math_round_A_fn_class *jrt.Class



type A_arbace_math_round__inliner__446000071_A struct{ j2g_header uint64 }

var A_arbace_math_round__inliner__446000071_A_fn_class *jrt.Class



type A_arbace_math_scalb_A struct{ j2g_header uint64 }

var A_arbace_math_scalb_A_fn_class *jrt.Class



type A_arbace_math_scalb__inliner__446000140_A struct{ j2g_header uint64 }

var A_arbace_math_scalb__inliner__446000140_A_fn_class *jrt.Class



type A_arbace_math_signum_A struct{ j2g_header uint64 }

var A_arbace_math_signum_A_fn_class *jrt.Class



type A_arbace_math_signum__inliner__446000104_A struct{ j2g_header uint64 }

var A_arbace_math_signum__inliner__446000104_A_fn_class *jrt.Class



type A_arbace_math_sin_A struct{ j2g_header uint64 }

var A_arbace_math_sin_A_fn_class *jrt.Class



type A_arbace_math_sin__inliner__446000014_A struct{ j2g_header uint64 }

var A_arbace_math_sin__inliner__446000014_A_fn_class *jrt.Class



type A_arbace_math_sinh_A struct{ j2g_header uint64 }

var A_arbace_math_sinh_A_fn_class *jrt.Class



type A_arbace_math_sinh__inliner__446000107_A struct{ j2g_header uint64 }

var A_arbace_math_sinh__inliner__446000107_A_fn_class *jrt.Class



type A_arbace_math_sqrt_A struct{ j2g_header uint64 }

var A_arbace_math_sqrt_A_fn_class *jrt.Class



type A_arbace_math_sqrt__inliner__446000047_A struct{ j2g_header uint64 }

var A_arbace_math_sqrt__inliner__446000047_A_fn_class *jrt.Class



type A_arbace_math_subtract_exact_A struct{ j2g_header uint64 }

var A_arbace_math_subtract_exact_A_fn_class *jrt.Class



type A_arbace_math_subtract_exact__inliner__446000080_A struct{ j2g_header uint64 }

var A_arbace_math_subtract_exact__inliner__446000080_A_fn_class *jrt.Class



type A_arbace_math_tan_A struct{ j2g_header uint64 }

var A_arbace_math_tan_A_fn_class *jrt.Class



type A_arbace_math_tan__inliner__446000020_A struct{ j2g_header uint64 }

var A_arbace_math_tan__inliner__446000020_A_fn_class *jrt.Class



type A_arbace_math_tanh_A struct{ j2g_header uint64 }

var A_arbace_math_tanh_A_fn_class *jrt.Class



type A_arbace_math_tanh__inliner__446000113_A struct{ j2g_header uint64 }

var A_arbace_math_tanh__inliner__446000113_A_fn_class *jrt.Class



type A_arbace_math_to_degrees_A struct{ j2g_header uint64 }

var A_arbace_math_to_degrees_A_fn_class *jrt.Class



type A_arbace_math_to_degrees__inliner__446000035_A struct{ j2g_header uint64 }

var A_arbace_math_to_degrees__inliner__446000035_A_fn_class *jrt.Class



type A_arbace_math_to_radians_A struct{ j2g_header uint64 }

var A_arbace_math_to_radians_A_fn_class *jrt.Class



type A_arbace_math_to_radians__inliner__446000032_A struct{ j2g_header uint64 }

var A_arbace_math_to_radians__inliner__446000032_A_fn_class *jrt.Class



type A_arbace_math_ulp_A struct{ j2g_header uint64 }

var A_arbace_math_ulp_A_fn_class *jrt.Class



type A_arbace_math_ulp__inliner__446000101_A struct{ j2g_header uint64 }

var A_arbace_math_ulp__inliner__446000101_A_fn_class *jrt.Class
