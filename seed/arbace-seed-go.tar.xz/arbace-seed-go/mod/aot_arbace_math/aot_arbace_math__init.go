//line aot_arbace_math__init.ae:1
package aot_arbace_math

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_math__init_A_Load__O() any { A_arbace_math__init_A_Init(); A_arbace_math__init_A_Unit0__O(); A_arbace_math__init_A_Unit1__O(); A_arbace_math__init_A_Unit2__O(); A_arbace_math__init_A_Unit3__O(); A_arbace_math__init_A_Unit4__O(); A_arbace_math__init_A_Unit5__O(); A_arbace_math__init_A_Unit6__O(); A_arbace_math__init_A_Unit7__O(); A_arbace_math__init_A_Unit8__O(); A_arbace_math__init_A_Unit9__O(); A_arbace_math__init_A_Unit10__O(); A_arbace_math__init_A_Unit11__O(); A_arbace_math__init_A_Unit12__O(); A_arbace_math__init_A_Unit13__O(); A_arbace_math__init_A_Unit14__O(); A_arbace_math__init_A_Unit15__O(); A_arbace_math__init_A_Unit16__O(); A_arbace_math__init_A_Unit17__O(); A_arbace_math__init_A_Unit18__O(); A_arbace_math__init_A_Unit19__O(); A_arbace_math__init_A_Unit20__O(); A_arbace_math__init_A_Unit21__O(); A_arbace_math__init_A_Unit22__O(); A_arbace_math__init_A_Unit23__O(); A_arbace_math__init_A_Unit24__O(); A_arbace_math__init_A_Unit25__O(); A_arbace_math__init_A_Unit26__O(); A_arbace_math__init_A_Unit27__O(); A_arbace_math__init_A_Unit28__O(); A_arbace_math__init_A_Unit29__O(); A_arbace_math__init_A_Unit30__O(); A_arbace_math__init_A_Unit31__O(); A_arbace_math__init_A_Unit32__O(); A_arbace_math__init_A_Unit33__O(); A_arbace_math__init_A_Unit34__O(); A_arbace_math__init_A_Unit35__O(); A_arbace_math__init_A_Unit36__O(); A_arbace_math__init_A_Unit37__O(); A_arbace_math__init_A_Unit38__O(); A_arbace_math__init_A_Unit39__O(); A_arbace_math__init_A_Unit40__O(); A_arbace_math__init_A_Unit41__O(); A_arbace_math__init_A_Unit42__O(); A_arbace_math__init_A_Unit43__O(); A_arbace_math__init_A_Unit44__O(); A_arbace_math__init_A_Unit45__O(); A_arbace_math__init_A_Unit46__O(); A_arbace_math__init_A_Unit47__O(); A_arbace_math__init_A_Unit48__O(); A_arbace_math__init_A_Unit49__O(); return nil }



func A_arbace_math__init_A_Unit0__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(A_arbace_math__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_math__init_A_const_1) }
//line :9:1
func A_arbace_math__init_A_Unit1__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_math__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_2)) }
//line :9:1
func A_arbace_math__init_A_Unit2__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_math__init_A_Unit3__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_math__init_A_const_1)).Equals_O__Z(A_arbace_math__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_math_eval446000008_fn__446000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_math_eval446000008_fn__446000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_math_eval446000008_fn__446000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }












func A_arbace_math__init_A_Unit4__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }

func A_arbace_math__init_A_Unit5__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_5; tmp1.BindRoot_O__V(jrt.Double_ValueOf_D__Double(2.718281828459045).Ref()); var tmp2 *lang.Var = A_arbace_math__init_A_const_5; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_6)); return A_arbace_math__init_A_const_5 }








func A_arbace_math__init_A_Unit6__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_7; tmp1.BindRoot_O__V(jrt.Double_ValueOf_D__Double(3.141592653589793).Ref()); var tmp2 *lang.Var = A_arbace_math__init_A_const_7; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_8)); return A_arbace_math__init_A_const_7 }








func A_arbace_math__init_A_Unit7__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_9; var tmp2 any = A_arbace_math_sin_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_math_sin_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_math_sin_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_9; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_11; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_14; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_sin__inliner__446000014_A_New(); var tmp12 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_math_sin__inliner__446000014_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_math_sin__inliner__446000014_A_fn_class = fncls__4d; tmp12 = fncls__4d } else { tmp12 = fncls__4 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_5, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_18, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_9 }










func A_arbace_math__init_A_Unit8__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_22; var tmp2 any = A_arbace_math_cos_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_math_cos_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_math_cos_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_22; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_23; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_24; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_cos__inliner__446000017_A_New(); var tmp12 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_math_cos__inliner__446000017_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_math_cos__inliner__446000017_A_fn_class = fncls__6d; tmp12 = fncls__6d } else { tmp12 = fncls__6 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_10, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_25, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_22 }









func A_arbace_math__init_A_Unit9__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_26; var tmp2 any = A_arbace_math_tan_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_math_tan_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_math_tan_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_26; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_27; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_28; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_tan__inliner__446000020_A_New(); var tmp12 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_math_tan__inliner__446000020_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_math_tan__inliner__446000020_A_fn_class = fncls__8d; tmp12 = fncls__8d } else { tmp12 = fncls__8 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_13, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_29, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_26 }










func A_arbace_math__init_A_Unit10__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_30; var tmp2 any = A_arbace_math_asin_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_math_asin_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_math_asin_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_30; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_31; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_32; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_asin__inliner__446000023_A_New(); var tmp12 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_math_asin__inliner__446000023_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_math_asin__inliner__446000023_A_fn_class = fncls__10d; tmp12 = fncls__10d } else { tmp12 = fncls__10 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_16, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_33, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_30 }










func A_arbace_math__init_A_Unit11__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_34; var tmp2 any = A_arbace_math_acos_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_math_acos_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_math_acos_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_34; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_35; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_36; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_acos__inliner__446000026_A_New(); var tmp12 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_math_acos__inliner__446000026_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_math_acos__inliner__446000026_A_fn_class = fncls__12d; tmp12 = fncls__12d } else { tmp12 = fncls__12 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_19, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_37, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_34 }









func A_arbace_math__init_A_Unit12__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_38; var tmp2 any = A_arbace_math_atan_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_math_atan_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_math_atan_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_38; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_39; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_40; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_atan__inliner__446000029_A_New(); var tmp12 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_math_atan__inliner__446000029_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_math_atan__inliner__446000029_A_fn_class = fncls__14d; tmp12 = fncls__14d } else { tmp12 = fncls__14 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_22, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_41, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_38 }










func A_arbace_math__init_A_Unit13__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_42; var tmp2 any = A_arbace_math_to_radians_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_math_to_radians_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_math_to_radians_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_42; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_43; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_44; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_to_radians__inliner__446000032_A_New(); var tmp12 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_math_to_radians__inliner__446000032_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_math_to_radians__inliner__446000032_A_fn_class = fncls__16d; tmp12 = fncls__16d } else { tmp12 = fncls__16 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_25, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_45, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_42 }








func A_arbace_math__init_A_Unit14__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_46; var tmp2 any = A_arbace_math_to_degrees_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_math_to_degrees_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_math_to_degrees_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_46; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_47; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_48; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_to_degrees__inliner__446000035_A_New(); var tmp12 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_math_to_degrees__inliner__446000035_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_math_to_degrees__inliner__446000035_A_fn_class = fncls__18d; tmp12 = fncls__18d } else { tmp12 = fncls__18 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_28, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_49, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_46 }








func A_arbace_math__init_A_Unit15__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_50; var tmp2 any = A_arbace_math_exp_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_math_exp_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_math_exp_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_50; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_51; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_52; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_exp__inliner__446000038_A_New(); var tmp12 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_math_exp__inliner__446000038_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_math_exp__inliner__446000038_A_fn_class = fncls__20d; tmp12 = fncls__20d } else { tmp12 = fncls__20 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_31, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_53, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_50 }











func A_arbace_math__init_A_Unit16__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(136, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_54; var tmp2 any = A_arbace_math_log_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_math_log_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_math_log_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_54; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_55; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_56; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_log__inliner__446000041_A_New(); var tmp12 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_math_log__inliner__446000041_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_math_log__inliner__446000041_A_fn_class = fncls__22d; tmp12 = fncls__22d } else { tmp12 = fncls__22 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_34, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_57, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_54 }











func A_arbace_math__init_A_Unit17__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_58; var tmp2 any = A_arbace_math_log10_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_math_log10_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_math_log10_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_58; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_59; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_60; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_log10__inliner__446000044_A_New(); var tmp12 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_math_log10__inliner__446000044_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_math_log10__inliner__446000044_A_fn_class = fncls__24d; tmp12 = fncls__24d } else { tmp12 = fncls__24 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_37, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_61, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_58 }











func A_arbace_math__init_A_Unit18__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_62; var tmp2 any = A_arbace_math_sqrt_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_math_sqrt_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_math_sqrt_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_62; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_63; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_64; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_sqrt__inliner__446000047_A_New(); var tmp12 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_math_sqrt__inliner__446000047_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_math_sqrt__inliner__446000047_A_fn_class = fncls__26d; tmp12 = fncls__26d } else { tmp12 = fncls__26 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_40, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_65, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_62 }











func A_arbace_math__init_A_Unit19__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_66; var tmp2 any = A_arbace_math_cbrt_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_math_cbrt_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_math_cbrt_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_66; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_67; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_68; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_cbrt__inliner__446000050_A_New(); var tmp12 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_math_cbrt__inliner__446000050_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_math_cbrt__inliner__446000050_A_fn_class = fncls__28d; tmp12 = fncls__28d } else { tmp12 = fncls__28 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_43, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_69, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_66 }











func A_arbace_math__init_A_Unit20__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(184, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_70; var tmp2 any = A_arbace_math_IEEE_remainder_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_math_IEEE_remainder_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_math_IEEE_remainder_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_70; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_71; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_72; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_IEEE_remainder__inliner__446000053_A_New(); var tmp12 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class = fncls__30d; tmp12 = fncls__30d } else { tmp12 = fncls__30 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_46, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_73, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_70 }














func A_arbace_math__init_A_Unit21__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(199, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_74; var tmp2 any = A_arbace_math_ceil_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_math_ceil_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_math_ceil_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_74; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_75; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_76; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_ceil__inliner__446000056_A_New(); var tmp12 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_math_ceil__inliner__446000056_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_math_ceil__inliner__446000056_A_fn_class = fncls__32d; tmp12 = fncls__32d } else { tmp12 = fncls__32 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_49, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_77, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_74 }











func A_arbace_math__init_A_Unit22__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(211, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_78; var tmp2 any = A_arbace_math_floor_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_math_floor_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_math_floor_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_78; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_79; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_80; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_floor__inliner__446000059_A_New(); var tmp12 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_math_floor__inliner__446000059_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_math_floor__inliner__446000059_A_fn_class = fncls__34d; tmp12 = fncls__34d } else { tmp12 = fncls__34 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_52, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_81, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_78 }










func A_arbace_math__init_A_Unit23__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(222, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_82; var tmp2 any = A_arbace_math_rint_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_math_rint_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_math_rint_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_82; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_83; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_84; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_rint__inliner__446000062_A_New(); var tmp12 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_math_rint__inliner__446000062_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_math_rint__inliner__446000062_A_fn_class = fncls__36d; tmp12 = fncls__36d } else { tmp12 = fncls__36 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_55, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_85, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_82 }










func A_arbace_math__init_A_Unit24__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(233, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_86; var tmp2 any = A_arbace_math_atan2_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_math_atan2_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_math_atan2_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_86; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_87; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_88; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_atan2__inliner__446000065_A_New(); var tmp12 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_math_atan2__inliner__446000065_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_math_atan2__inliner__446000065_A_fn_class = fncls__38d; tmp12 = fncls__38d } else { tmp12 = fncls__38 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_58, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_89, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_86 }










func A_arbace_math__init_A_Unit25__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(244, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_90; var tmp2 any = A_arbace_math_pow_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_math_pow_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_math_pow_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_90; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_91; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_92; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_pow__inliner__446000068_A_New(); var tmp12 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_math_pow__inliner__446000068_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_math_pow__inliner__446000068_A_fn_class = fncls__40d; tmp12 = fncls__40d } else { tmp12 = fncls__40 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_61, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_93, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_90 }









func A_arbace_math__init_A_Unit26__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(254, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_94; var tmp2 any = A_arbace_math_round_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_math_round_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_math_round_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_94; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_95; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_96; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_round__inliner__446000071_A_New(); var tmp12 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_math_round__inliner__446000071_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_math_round__inliner__446000071_A_fn_class = fncls__42d; tmp12 = fncls__42d } else { tmp12 = fncls__42 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_64, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_97, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_94 }












func A_arbace_math__init_A_Unit27__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_98; var tmp2 any = A_arbace_math_random_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_math_random_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_math_random_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_98; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_99; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_100; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_random__inliner__446000074_A_New(); var tmp12 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_math_random__inliner__446000074_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_math_random__inliner__446000074_A_fn_class = fncls__44d; tmp12 = fncls__44d } else { tmp12 = fncls__44 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_67, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_101, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_98 }









func A_arbace_math__init_A_Unit28__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(277, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_102; var tmp2 any = A_arbace_math_add_exact_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_math_add_exact_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_math_add_exact_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_102; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_103; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_104; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_add_exact__inliner__446000077_A_New(); var tmp12 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_math_add_exact__inliner__446000077_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_math_add_exact__inliner__446000077_A_fn_class = fncls__46d; tmp12 = fncls__46d } else { tmp12 = fncls__46 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_70, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_105, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_102 }








func A_arbace_math__init_A_Unit29__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(286, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_106; var tmp2 any = A_arbace_math_subtract_exact_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_math_subtract_exact_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_math_subtract_exact_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_106; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_107; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_108; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_subtract_exact__inliner__446000080_A_New(); var tmp12 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_math_subtract_exact__inliner__446000080_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_math_subtract_exact__inliner__446000080_A_fn_class = fncls__48d; tmp12 = fncls__48d } else { tmp12 = fncls__48 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_73, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_109, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_106 }








func A_arbace_math__init_A_Unit30__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(295, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_110; var tmp2 any = A_arbace_math_multiply_exact_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_math_multiply_exact_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_math_multiply_exact_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_110; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_111; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_112; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_multiply_exact__inliner__446000083_A_New(); var tmp12 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_math_multiply_exact__inliner__446000083_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_math_multiply_exact__inliner__446000083_A_fn_class = fncls__50d; tmp12 = fncls__50d } else { tmp12 = fncls__50 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_76, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_113, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_110 }








func A_arbace_math__init_A_Unit31__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(304, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_114; var tmp2 any = A_arbace_math_increment_exact_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_math_increment_exact_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_math_increment_exact_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_114; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_115; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_116; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_increment_exact__inliner__446000086_A_New(); var tmp12 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_math_increment_exact__inliner__446000086_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_math_increment_exact__inliner__446000086_A_fn_class = fncls__52d; tmp12 = fncls__52d } else { tmp12 = fncls__52 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_79, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_117, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_114 }








func A_arbace_math__init_A_Unit32__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(313, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_118; var tmp2 any = A_arbace_math_decrement_exact_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_math_decrement_exact_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_math_decrement_exact_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_118; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_119; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_120; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_decrement_exact__inliner__446000089_A_New(); var tmp12 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_math_decrement_exact__inliner__446000089_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_math_decrement_exact__inliner__446000089_A_fn_class = fncls__54d; tmp12 = fncls__54d } else { tmp12 = fncls__54 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_82, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_121, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_118 }








func A_arbace_math__init_A_Unit33__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(322, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_122; var tmp2 any = A_arbace_math_negate_exact_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_math_negate_exact_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_math_negate_exact_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_122; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_123; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_124; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_negate_exact__inliner__446000092_A_New(); var tmp12 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_math_negate_exact__inliner__446000092_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_math_negate_exact__inliner__446000092_A_fn_class = fncls__56d; tmp12 = fncls__56d } else { tmp12 = fncls__56 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_85, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_125, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_122 }








func A_arbace_math__init_A_Unit34__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(331, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_126; var tmp2 any = A_arbace_math_floor_div_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_math_floor_div_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_math_floor_div_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_126; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_127; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_128; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_floor_div__inliner__446000095_A_New(); var tmp12 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_math_floor_div__inliner__446000095_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_math_floor_div__inliner__446000095_A_fn_class = fncls__58d; tmp12 = fncls__58d } else { tmp12 = fncls__58 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_88, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_129, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_126 }









func A_arbace_math__init_A_Unit35__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(341, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_130; var tmp2 any = A_arbace_math_floor_mod_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_math_floor_mod_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_math_floor_mod_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_130; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_131; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_132; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_floor_mod__inliner__446000098_A_New(); var tmp12 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_math_floor_mod__inliner__446000098_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_math_floor_mod__inliner__446000098_A_fn_class = fncls__60d; tmp12 = fncls__60d } else { tmp12 = fncls__60 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_91, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_133, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_130 }









func A_arbace_math__init_A_Unit36__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(351, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_134; var tmp2 any = A_arbace_math_ulp_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_math_ulp_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_math_ulp_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_134; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_135; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_136; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_ulp__inliner__446000101_A_New(); var tmp12 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_math_ulp__inliner__446000101_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_math_ulp__inliner__446000101_A_fn_class = fncls__62d; tmp12 = fncls__62d } else { tmp12 = fncls__62 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_94, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_137, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_134 }












func A_arbace_math__init_A_Unit37__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(364, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_138; var tmp2 any = A_arbace_math_signum_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_math_signum_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_math_signum_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_138; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_139; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_140; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_signum__inliner__446000104_A_New(); var tmp12 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_math_signum__inliner__446000104_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_math_signum__inliner__446000104_A_fn_class = fncls__64d; tmp12 = fncls__64d } else { tmp12 = fncls__64 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_97, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_141, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_138 }









func A_arbace_math__init_A_Unit38__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(374, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_142; var tmp2 any = A_arbace_math_sinh_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_math_sinh_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); A_arbace_math_sinh_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_142; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_143; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_144; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_sinh__inliner__446000107_A_New(); var tmp12 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_math_sinh__inliner__446000107_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); A_arbace_math_sinh__inliner__446000107_A_fn_class = fncls__66d; tmp12 = fncls__66d } else { tmp12 = fncls__66 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_100, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_145, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_142 }










func A_arbace_math__init_A_Unit39__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(385, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_146; var tmp2 any = A_arbace_math_cosh_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_math_cosh_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_math_cosh_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_146; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_147; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_148; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_cosh__inliner__446000110_A_New(); var tmp12 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_math_cosh__inliner__446000110_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_math_cosh__inliner__446000110_A_fn_class = fncls__68d; tmp12 = fncls__68d } else { tmp12 = fncls__68 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_103, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_149, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_146 }











func A_arbace_math__init_A_Unit40__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(397, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_150; var tmp2 any = A_arbace_math_tanh_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_math_tanh_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_math_tanh_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_150; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_151; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_152; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_tanh__inliner__446000113_A_New(); var tmp12 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_math_tanh__inliner__446000113_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_math_tanh__inliner__446000113_A_fn_class = fncls__70d; tmp12 = fncls__70d } else { tmp12 = fncls__70 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_106, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_153, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_150 }












func A_arbace_math__init_A_Unit41__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(410, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_154; var tmp2 any = A_arbace_math_hypot_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_math_hypot_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_math_hypot_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_154; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_155; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_156; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_hypot__inliner__446000116_A_New(); var tmp12 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_math_hypot__inliner__446000116_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_math_hypot__inliner__446000116_A_fn_class = fncls__72d; tmp12 = fncls__72d } else { tmp12 = fncls__72 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_109, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_157, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_154 }










func A_arbace_math__init_A_Unit42__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(421, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_158; var tmp2 any = A_arbace_math_expm1_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_math_expm1_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_math_expm1_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_158; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_159; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_160; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_expm1__inliner__446000119_A_New(); var tmp12 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_math_expm1__inliner__446000119_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); A_arbace_math_expm1__inliner__446000119_A_fn_class = fncls__74d; tmp12 = fncls__74d } else { tmp12 = fncls__74 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_112, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_161, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_158 }












func A_arbace_math__init_A_Unit43__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(434, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_162; var tmp2 any = A_arbace_math_log1p_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_math_log1p_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_math_log1p_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_162; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_163; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_164; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_log1p__inliner__446000122_A_New(); var tmp12 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_math_log1p__inliner__446000122_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_math_log1p__inliner__446000122_A_fn_class = fncls__76d; tmp12 = fncls__76d } else { tmp12 = fncls__76 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_115, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_165, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_162 }













func A_arbace_math__init_A_Unit44__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(448, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_166; var tmp2 any = A_arbace_math_copy_sign_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_math_copy_sign_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_math_copy_sign_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_166; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_167; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_168; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_copy_sign__inliner__446000125_A_New(); var tmp12 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_math_copy_sign__inliner__446000125_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_math_copy_sign__inliner__446000125_A_fn_class = fncls__78d; tmp12 = fncls__78d } else { tmp12 = fncls__78 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_118, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_169, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_166 }









func A_arbace_math__init_A_Unit45__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(458, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_170; var tmp2 any = A_arbace_math_get_exponent_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_math_get_exponent_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_math_get_exponent_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_170; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_171; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_172; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_get_exponent__inliner__446000128_A_New(); var tmp12 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_math_get_exponent__inliner__446000128_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_math_get_exponent__inliner__446000128_A_fn_class = fncls__80d; tmp12 = fncls__80d } else { tmp12 = fncls__80 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_121, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_173, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_170 }










func A_arbace_math__init_A_Unit46__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(469, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_174; var tmp2 any = A_arbace_math_next_after_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_math_next_after_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); A_arbace_math_next_after_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_174; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_175; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_176; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_next_after__inliner__446000131_A_New(); var tmp12 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_math_next_after__inliner__446000131_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_125, false); A_arbace_math_next_after__inliner__446000131_A_fn_class = fncls__82d; tmp12 = fncls__82d } else { tmp12 = fncls__82 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_124, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_177, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_174 }

















func A_arbace_math__init_A_Unit47__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(487, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_178; var tmp2 any = A_arbace_math_next_up_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_math_next_up_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_math_next_up_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_178; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_179; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_180; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_next_up__inliner__446000134_A_New(); var tmp12 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_math_next_up__inliner__446000134_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_math_next_up__inliner__446000134_A_fn_class = fncls__84d; tmp12 = fncls__84d } else { tmp12 = fncls__84 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_127, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_181, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_178 }











func A_arbace_math__init_A_Unit48__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(499, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_182; var tmp2 any = A_arbace_math_next_down_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_math_next_down_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_math_next_down_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_182; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_183; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_184; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_next_down__inliner__446000137_A_New(); var tmp12 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_math_next_down__inliner__446000137_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_math_next_down__inliner__446000137_A_fn_class = fncls__86d; tmp12 = fncls__86d } else { tmp12 = fncls__86 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_130, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_185, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_182 }











func A_arbace_math__init_A_Unit49__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(511, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_186; var tmp2 any = A_arbace_math_scalb_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_math_scalb_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_math_scalb_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_186; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_187; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_188; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 any = A_arbace_math_scalb__inliner__446000140_A_New(); var tmp12 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_math_scalb__inliner__446000140_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_math_scalb__inliner__446000140_A_fn_class = fncls__88d; tmp12 = fncls__88d } else { tmp12 = fncls__88 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_133, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_189, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_186 }



type A_arbace_math__init_A struct{ jrt.Object }

var A_arbace_math__init_A_const_pool *jrt.RefArray

var A_arbace_math__init_A_const_0 *lang.Var

var A_arbace_math__init_A_const_1 any

var A_arbace_math__init_A_const_2 any

var A_arbace_math__init_A_const_3 any

var A_arbace_math__init_A_const_4 *lang.Var

var A_arbace_math__init_A_const_5 *lang.Var

var A_arbace_math__init_A_const_6 any

var A_arbace_math__init_A_const_7 *lang.Var

var A_arbace_math__init_A_const_8 any

var A_arbace_math__init_A_const_9 *lang.Var

var A_arbace_math__init_A_const_10 *lang.Keyword

var A_arbace_math__init_A_const_11 any

var A_arbace_math__init_A_const_12 *lang.Keyword

var A_arbace_math__init_A_const_13 *lang.Keyword

var A_arbace_math__init_A_const_14 any

var A_arbace_math__init_A_const_15 *lang.Keyword

var A_arbace_math__init_A_const_16 *lang.Keyword

var A_arbace_math__init_A_const_17 *lang.Keyword

var A_arbace_math__init_A_const_18 any

var A_arbace_math__init_A_const_19 *lang.Keyword

var A_arbace_math__init_A_const_20 any

var A_arbace_math__init_A_const_21 *lang.Keyword

var A_arbace_math__init_A_const_22 *lang.Var

var A_arbace_math__init_A_const_23 any

var A_arbace_math__init_A_const_24 any

var A_arbace_math__init_A_const_25 any

var A_arbace_math__init_A_const_26 *lang.Var

var A_arbace_math__init_A_const_27 any

var A_arbace_math__init_A_const_28 any

var A_arbace_math__init_A_const_29 any

var A_arbace_math__init_A_const_30 *lang.Var

var A_arbace_math__init_A_const_31 any

var A_arbace_math__init_A_const_32 any

var A_arbace_math__init_A_const_33 any

var A_arbace_math__init_A_const_34 *lang.Var

var A_arbace_math__init_A_const_35 any

var A_arbace_math__init_A_const_36 any

var A_arbace_math__init_A_const_37 any

var A_arbace_math__init_A_const_38 *lang.Var

var A_arbace_math__init_A_const_39 any

var A_arbace_math__init_A_const_40 any

var A_arbace_math__init_A_const_41 any

var A_arbace_math__init_A_const_42 *lang.Var

var A_arbace_math__init_A_const_43 any

var A_arbace_math__init_A_const_44 any

var A_arbace_math__init_A_const_45 any

var A_arbace_math__init_A_const_46 *lang.Var

var A_arbace_math__init_A_const_47 any

var A_arbace_math__init_A_const_48 any

var A_arbace_math__init_A_const_49 any

var A_arbace_math__init_A_const_50 *lang.Var

var A_arbace_math__init_A_const_51 any

var A_arbace_math__init_A_const_52 any

var A_arbace_math__init_A_const_53 any

var A_arbace_math__init_A_const_54 *lang.Var

var A_arbace_math__init_A_const_55 any

var A_arbace_math__init_A_const_56 any

var A_arbace_math__init_A_const_57 any

var A_arbace_math__init_A_const_58 *lang.Var

var A_arbace_math__init_A_const_59 any

var A_arbace_math__init_A_const_60 any

var A_arbace_math__init_A_const_61 any

var A_arbace_math__init_A_const_62 *lang.Var

var A_arbace_math__init_A_const_63 any

var A_arbace_math__init_A_const_64 any

var A_arbace_math__init_A_const_65 any

var A_arbace_math__init_A_const_66 *lang.Var

var A_arbace_math__init_A_const_67 any

var A_arbace_math__init_A_const_68 any

var A_arbace_math__init_A_const_69 any

var A_arbace_math__init_A_const_70 *lang.Var

var A_arbace_math__init_A_const_71 any

var A_arbace_math__init_A_const_72 any

var A_arbace_math__init_A_const_73 any

var A_arbace_math__init_A_const_74 *lang.Var

var A_arbace_math__init_A_const_75 any

var A_arbace_math__init_A_const_76 any

var A_arbace_math__init_A_const_77 any

var A_arbace_math__init_A_const_78 *lang.Var

var A_arbace_math__init_A_const_79 any

var A_arbace_math__init_A_const_80 any

var A_arbace_math__init_A_const_81 any

var A_arbace_math__init_A_const_82 *lang.Var

var A_arbace_math__init_A_const_83 any

var A_arbace_math__init_A_const_84 any

var A_arbace_math__init_A_const_85 any

var A_arbace_math__init_A_const_86 *lang.Var

var A_arbace_math__init_A_const_87 any

var A_arbace_math__init_A_const_88 any

var A_arbace_math__init_A_const_89 any

var A_arbace_math__init_A_const_90 *lang.Var

var A_arbace_math__init_A_const_91 any

var A_arbace_math__init_A_const_92 any

var A_arbace_math__init_A_const_93 any

var A_arbace_math__init_A_const_94 *lang.Var

var A_arbace_math__init_A_const_95 any

var A_arbace_math__init_A_const_96 any

var A_arbace_math__init_A_const_97 any

var A_arbace_math__init_A_const_98 *lang.Var

var A_arbace_math__init_A_const_99 any

var A_arbace_math__init_A_const_100 any

var A_arbace_math__init_A_const_101 any

var A_arbace_math__init_A_const_102 *lang.Var

var A_arbace_math__init_A_const_103 any

var A_arbace_math__init_A_const_104 any

var A_arbace_math__init_A_const_105 any

var A_arbace_math__init_A_const_106 *lang.Var

var A_arbace_math__init_A_const_107 any

var A_arbace_math__init_A_const_108 any

var A_arbace_math__init_A_const_109 any

var A_arbace_math__init_A_const_110 *lang.Var

var A_arbace_math__init_A_const_111 any

var A_arbace_math__init_A_const_112 any

var A_arbace_math__init_A_const_113 any

var A_arbace_math__init_A_const_114 *lang.Var

var A_arbace_math__init_A_const_115 any

var A_arbace_math__init_A_const_116 any

var A_arbace_math__init_A_const_117 any

var A_arbace_math__init_A_const_118 *lang.Var

var A_arbace_math__init_A_const_119 any

var A_arbace_math__init_A_const_120 any

var A_arbace_math__init_A_const_121 any

var A_arbace_math__init_A_const_122 *lang.Var

var A_arbace_math__init_A_const_123 any

var A_arbace_math__init_A_const_124 any

var A_arbace_math__init_A_const_125 any

var A_arbace_math__init_A_const_126 *lang.Var

var A_arbace_math__init_A_const_127 any

var A_arbace_math__init_A_const_128 any

var A_arbace_math__init_A_const_129 any

var A_arbace_math__init_A_const_130 *lang.Var

var A_arbace_math__init_A_const_131 any

var A_arbace_math__init_A_const_132 any

var A_arbace_math__init_A_const_133 any

var A_arbace_math__init_A_const_134 *lang.Var

var A_arbace_math__init_A_const_135 any

var A_arbace_math__init_A_const_136 any

var A_arbace_math__init_A_const_137 any

var A_arbace_math__init_A_const_138 *lang.Var

var A_arbace_math__init_A_const_139 any

var A_arbace_math__init_A_const_140 any

var A_arbace_math__init_A_const_141 any

var A_arbace_math__init_A_const_142 *lang.Var

var A_arbace_math__init_A_const_143 any

var A_arbace_math__init_A_const_144 any

var A_arbace_math__init_A_const_145 any

var A_arbace_math__init_A_const_146 *lang.Var

var A_arbace_math__init_A_const_147 any

var A_arbace_math__init_A_const_148 any

var A_arbace_math__init_A_const_149 any

var A_arbace_math__init_A_const_150 *lang.Var

var A_arbace_math__init_A_const_151 any

var A_arbace_math__init_A_const_152 any

var A_arbace_math__init_A_const_153 any

var A_arbace_math__init_A_const_154 *lang.Var

var A_arbace_math__init_A_const_155 any

var A_arbace_math__init_A_const_156 any

var A_arbace_math__init_A_const_157 any

var A_arbace_math__init_A_const_158 *lang.Var

var A_arbace_math__init_A_const_159 any

var A_arbace_math__init_A_const_160 any

var A_arbace_math__init_A_const_161 any

var A_arbace_math__init_A_const_162 *lang.Var

var A_arbace_math__init_A_const_163 any

var A_arbace_math__init_A_const_164 any

var A_arbace_math__init_A_const_165 any

var A_arbace_math__init_A_const_166 *lang.Var

var A_arbace_math__init_A_const_167 any

var A_arbace_math__init_A_const_168 any

var A_arbace_math__init_A_const_169 any

var A_arbace_math__init_A_const_170 *lang.Var

var A_arbace_math__init_A_const_171 any

var A_arbace_math__init_A_const_172 any

var A_arbace_math__init_A_const_173 any

var A_arbace_math__init_A_const_174 *lang.Var

var A_arbace_math__init_A_const_175 any

var A_arbace_math__init_A_const_176 any

var A_arbace_math__init_A_const_177 any

var A_arbace_math__init_A_const_178 *lang.Var

var A_arbace_math__init_A_const_179 any

var A_arbace_math__init_A_const_180 any

var A_arbace_math__init_A_const_181 any

var A_arbace_math__init_A_const_182 *lang.Var

var A_arbace_math__init_A_const_183 any

var A_arbace_math__init_A_const_184 any

var A_arbace_math__init_A_const_185 any

var A_arbace_math__init_A_const_186 *lang.Var

var A_arbace_math__init_A_const_187 any

var A_arbace_math__init_A_const_188 any

var A_arbace_math__init_A_const_189 any

var A_arbace_math__init_A_init jrt.ClassInit

func A_arbace_math__init_A_Init() { if !A_arbace_math__init_A_init.Done() { A_arbace_math__init_A_init.Run(A_arbace_math__init_A_clinit) } }

func A_arbace_math__init_A_clinit() { A_arbace_math__init_A_clinit_p0(); A_arbace_math__init_A_clinit_p1(); A_arbace_math__init_A_clinit_p2(); A_arbace_math__init_A_clinit_p3(); A_arbace_math__init_A_clinit_p4(); A_arbace_math__init_A_clinit_p5(); A_arbace_math__init_A_clinit_p6(); A_arbace_math__init_A_clinit_p7(); A_arbace_math__init_A_clinit_p8(); A_arbace_math__init_A_clinit_p9(); A_arbace_math__init_A_clinit_p10(); A_arbace_math__init_A_clinit_p11(); A_arbace_math__init_A_clinit_p12(); A_arbace_math__init_A_clinit_p13() }

func A_arbace_math__init_A_clinit_p0() { A_arbace_math__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_1, 205); A_arbace_math__init_A_const_0 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[15]); A_arbace_math__init_A_const_1 = A_arbace_math__init_A_const_pool.A[16]; A_arbace_math__init_A_const_2 = A_arbace_math__init_A_const_pool.A[17]; A_arbace_math__init_A_const_3 = A_arbace_math__init_A_const_pool.A[18]; A_arbace_math__init_A_const_4 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[19]); A_arbace_math__init_A_const_5 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[20]); A_arbace_math__init_A_const_6 = A_arbace_math__init_A_const_pool.A[21]; A_arbace_math__init_A_const_7 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[22]); A_arbace_math__init_A_const_8 = A_arbace_math__init_A_const_pool.A[23]; A_arbace_math__init_A_const_9 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[24]); A_arbace_math__init_A_const_10 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[25]); A_arbace_math__init_A_const_11 = A_arbace_math__init_A_const_pool.A[26]; A_arbace_math__init_A_const_12 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[27]) }

func A_arbace_math__init_A_clinit_p1() { A_arbace_math__init_A_const_13 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[28]); A_arbace_math__init_A_const_14 = A_arbace_math__init_A_const_pool.A[29]; A_arbace_math__init_A_const_15 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[30]); A_arbace_math__init_A_const_16 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[31]); A_arbace_math__init_A_const_17 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[32]); A_arbace_math__init_A_const_18 = A_arbace_math__init_A_const_pool.A[33]; A_arbace_math__init_A_const_19 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[34]); A_arbace_math__init_A_const_20 = A_arbace_math__init_A_const_pool.A[35]; A_arbace_math__init_A_const_21 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[36]); A_arbace_math__init_A_const_22 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[37]); A_arbace_math__init_A_const_23 = A_arbace_math__init_A_const_pool.A[38]; A_arbace_math__init_A_const_24 = A_arbace_math__init_A_const_pool.A[39]; A_arbace_math__init_A_const_25 = A_arbace_math__init_A_const_pool.A[40] }

func A_arbace_math__init_A_clinit_p2() { A_arbace_math__init_A_const_26 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[41]); A_arbace_math__init_A_const_27 = A_arbace_math__init_A_const_pool.A[42]; A_arbace_math__init_A_const_28 = A_arbace_math__init_A_const_pool.A[43]; A_arbace_math__init_A_const_29 = A_arbace_math__init_A_const_pool.A[44]; A_arbace_math__init_A_const_30 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[45]); A_arbace_math__init_A_const_31 = A_arbace_math__init_A_const_pool.A[46]; A_arbace_math__init_A_const_32 = A_arbace_math__init_A_const_pool.A[47]; A_arbace_math__init_A_const_33 = A_arbace_math__init_A_const_pool.A[48]; A_arbace_math__init_A_const_34 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[49]); A_arbace_math__init_A_const_35 = A_arbace_math__init_A_const_pool.A[50]; A_arbace_math__init_A_const_36 = A_arbace_math__init_A_const_pool.A[51]; A_arbace_math__init_A_const_37 = A_arbace_math__init_A_const_pool.A[52]; A_arbace_math__init_A_const_38 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[53]); A_arbace_math__init_A_const_39 = A_arbace_math__init_A_const_pool.A[54] }

func A_arbace_math__init_A_clinit_p3() { A_arbace_math__init_A_const_40 = A_arbace_math__init_A_const_pool.A[55]; A_arbace_math__init_A_const_41 = A_arbace_math__init_A_const_pool.A[56]; A_arbace_math__init_A_const_42 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[57]); A_arbace_math__init_A_const_43 = A_arbace_math__init_A_const_pool.A[58]; A_arbace_math__init_A_const_44 = A_arbace_math__init_A_const_pool.A[59]; A_arbace_math__init_A_const_45 = A_arbace_math__init_A_const_pool.A[60]; A_arbace_math__init_A_const_46 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[61]); A_arbace_math__init_A_const_47 = A_arbace_math__init_A_const_pool.A[62]; A_arbace_math__init_A_const_48 = A_arbace_math__init_A_const_pool.A[63]; A_arbace_math__init_A_const_49 = A_arbace_math__init_A_const_pool.A[64]; A_arbace_math__init_A_const_50 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[65]); A_arbace_math__init_A_const_51 = A_arbace_math__init_A_const_pool.A[66]; A_arbace_math__init_A_const_52 = A_arbace_math__init_A_const_pool.A[67]; A_arbace_math__init_A_const_53 = A_arbace_math__init_A_const_pool.A[68] }

func A_arbace_math__init_A_clinit_p4() { A_arbace_math__init_A_const_54 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[69]); A_arbace_math__init_A_const_55 = A_arbace_math__init_A_const_pool.A[70]; A_arbace_math__init_A_const_56 = A_arbace_math__init_A_const_pool.A[71]; A_arbace_math__init_A_const_57 = A_arbace_math__init_A_const_pool.A[72]; A_arbace_math__init_A_const_58 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[73]); A_arbace_math__init_A_const_59 = A_arbace_math__init_A_const_pool.A[74]; A_arbace_math__init_A_const_60 = A_arbace_math__init_A_const_pool.A[75]; A_arbace_math__init_A_const_61 = A_arbace_math__init_A_const_pool.A[76]; A_arbace_math__init_A_const_62 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[77]); A_arbace_math__init_A_const_63 = A_arbace_math__init_A_const_pool.A[78]; A_arbace_math__init_A_const_64 = A_arbace_math__init_A_const_pool.A[79]; A_arbace_math__init_A_const_65 = A_arbace_math__init_A_const_pool.A[80]; A_arbace_math__init_A_const_66 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[81]); A_arbace_math__init_A_const_67 = A_arbace_math__init_A_const_pool.A[82] }

func A_arbace_math__init_A_clinit_p5() { A_arbace_math__init_A_const_68 = A_arbace_math__init_A_const_pool.A[83]; A_arbace_math__init_A_const_69 = A_arbace_math__init_A_const_pool.A[84]; A_arbace_math__init_A_const_70 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[85]); A_arbace_math__init_A_const_71 = A_arbace_math__init_A_const_pool.A[86]; A_arbace_math__init_A_const_72 = A_arbace_math__init_A_const_pool.A[87]; A_arbace_math__init_A_const_73 = A_arbace_math__init_A_const_pool.A[88]; A_arbace_math__init_A_const_74 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[89]); A_arbace_math__init_A_const_75 = A_arbace_math__init_A_const_pool.A[90]; A_arbace_math__init_A_const_76 = A_arbace_math__init_A_const_pool.A[91]; A_arbace_math__init_A_const_77 = A_arbace_math__init_A_const_pool.A[92]; A_arbace_math__init_A_const_78 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[93]); A_arbace_math__init_A_const_79 = A_arbace_math__init_A_const_pool.A[94]; A_arbace_math__init_A_const_80 = A_arbace_math__init_A_const_pool.A[95]; A_arbace_math__init_A_const_81 = A_arbace_math__init_A_const_pool.A[96] }

func A_arbace_math__init_A_clinit_p6() { A_arbace_math__init_A_const_82 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[97]); A_arbace_math__init_A_const_83 = A_arbace_math__init_A_const_pool.A[98]; A_arbace_math__init_A_const_84 = A_arbace_math__init_A_const_pool.A[99]; A_arbace_math__init_A_const_85 = A_arbace_math__init_A_const_pool.A[100]; A_arbace_math__init_A_const_86 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[101]); A_arbace_math__init_A_const_87 = A_arbace_math__init_A_const_pool.A[102]; A_arbace_math__init_A_const_88 = A_arbace_math__init_A_const_pool.A[103]; A_arbace_math__init_A_const_89 = A_arbace_math__init_A_const_pool.A[104]; A_arbace_math__init_A_const_90 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[105]); A_arbace_math__init_A_const_91 = A_arbace_math__init_A_const_pool.A[106]; A_arbace_math__init_A_const_92 = A_arbace_math__init_A_const_pool.A[107]; A_arbace_math__init_A_const_93 = A_arbace_math__init_A_const_pool.A[108]; A_arbace_math__init_A_const_94 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[109]); A_arbace_math__init_A_const_95 = A_arbace_math__init_A_const_pool.A[110] }

func A_arbace_math__init_A_clinit_p7() { A_arbace_math__init_A_const_96 = A_arbace_math__init_A_const_pool.A[111]; A_arbace_math__init_A_const_97 = A_arbace_math__init_A_const_pool.A[112]; A_arbace_math__init_A_const_98 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[113]); A_arbace_math__init_A_const_99 = A_arbace_math__init_A_const_pool.A[114]; A_arbace_math__init_A_const_100 = A_arbace_math__init_A_const_pool.A[115]; A_arbace_math__init_A_const_101 = A_arbace_math__init_A_const_pool.A[116]; A_arbace_math__init_A_const_102 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[117]); A_arbace_math__init_A_const_103 = A_arbace_math__init_A_const_pool.A[118]; A_arbace_math__init_A_const_104 = A_arbace_math__init_A_const_pool.A[119]; A_arbace_math__init_A_const_105 = A_arbace_math__init_A_const_pool.A[120]; A_arbace_math__init_A_const_106 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[121]); A_arbace_math__init_A_const_107 = A_arbace_math__init_A_const_pool.A[122]; A_arbace_math__init_A_const_108 = A_arbace_math__init_A_const_pool.A[123]; A_arbace_math__init_A_const_109 = A_arbace_math__init_A_const_pool.A[124] }

func A_arbace_math__init_A_clinit_p8() { A_arbace_math__init_A_const_110 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[125]); A_arbace_math__init_A_const_111 = A_arbace_math__init_A_const_pool.A[126]; A_arbace_math__init_A_const_112 = A_arbace_math__init_A_const_pool.A[127]; A_arbace_math__init_A_const_113 = A_arbace_math__init_A_const_pool.A[128]; A_arbace_math__init_A_const_114 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[129]); A_arbace_math__init_A_const_115 = A_arbace_math__init_A_const_pool.A[130]; A_arbace_math__init_A_const_116 = A_arbace_math__init_A_const_pool.A[131]; A_arbace_math__init_A_const_117 = A_arbace_math__init_A_const_pool.A[132]; A_arbace_math__init_A_const_118 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[133]); A_arbace_math__init_A_const_119 = A_arbace_math__init_A_const_pool.A[134]; A_arbace_math__init_A_const_120 = A_arbace_math__init_A_const_pool.A[135]; A_arbace_math__init_A_const_121 = A_arbace_math__init_A_const_pool.A[136]; A_arbace_math__init_A_const_122 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[137]); A_arbace_math__init_A_const_123 = A_arbace_math__init_A_const_pool.A[138] }

func A_arbace_math__init_A_clinit_p9() { A_arbace_math__init_A_const_124 = A_arbace_math__init_A_const_pool.A[139]; A_arbace_math__init_A_const_125 = A_arbace_math__init_A_const_pool.A[140]; A_arbace_math__init_A_const_126 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[141]); A_arbace_math__init_A_const_127 = A_arbace_math__init_A_const_pool.A[142]; A_arbace_math__init_A_const_128 = A_arbace_math__init_A_const_pool.A[143]; A_arbace_math__init_A_const_129 = A_arbace_math__init_A_const_pool.A[144]; A_arbace_math__init_A_const_130 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[145]); A_arbace_math__init_A_const_131 = A_arbace_math__init_A_const_pool.A[146]; A_arbace_math__init_A_const_132 = A_arbace_math__init_A_const_pool.A[147]; A_arbace_math__init_A_const_133 = A_arbace_math__init_A_const_pool.A[148]; A_arbace_math__init_A_const_134 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[149]); A_arbace_math__init_A_const_135 = A_arbace_math__init_A_const_pool.A[150]; A_arbace_math__init_A_const_136 = A_arbace_math__init_A_const_pool.A[151]; A_arbace_math__init_A_const_137 = A_arbace_math__init_A_const_pool.A[152] }

func A_arbace_math__init_A_clinit_p10() { A_arbace_math__init_A_const_138 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[153]); A_arbace_math__init_A_const_139 = A_arbace_math__init_A_const_pool.A[154]; A_arbace_math__init_A_const_140 = A_arbace_math__init_A_const_pool.A[155]; A_arbace_math__init_A_const_141 = A_arbace_math__init_A_const_pool.A[156]; A_arbace_math__init_A_const_142 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[157]); A_arbace_math__init_A_const_143 = A_arbace_math__init_A_const_pool.A[158]; A_arbace_math__init_A_const_144 = A_arbace_math__init_A_const_pool.A[159]; A_arbace_math__init_A_const_145 = A_arbace_math__init_A_const_pool.A[160]; A_arbace_math__init_A_const_146 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[161]); A_arbace_math__init_A_const_147 = A_arbace_math__init_A_const_pool.A[162]; A_arbace_math__init_A_const_148 = A_arbace_math__init_A_const_pool.A[163]; A_arbace_math__init_A_const_149 = A_arbace_math__init_A_const_pool.A[164]; A_arbace_math__init_A_const_150 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[165]); A_arbace_math__init_A_const_151 = A_arbace_math__init_A_const_pool.A[166] }

func A_arbace_math__init_A_clinit_p11() { A_arbace_math__init_A_const_152 = A_arbace_math__init_A_const_pool.A[167]; A_arbace_math__init_A_const_153 = A_arbace_math__init_A_const_pool.A[168]; A_arbace_math__init_A_const_154 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[169]); A_arbace_math__init_A_const_155 = A_arbace_math__init_A_const_pool.A[170]; A_arbace_math__init_A_const_156 = A_arbace_math__init_A_const_pool.A[171]; A_arbace_math__init_A_const_157 = A_arbace_math__init_A_const_pool.A[172]; A_arbace_math__init_A_const_158 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[173]); A_arbace_math__init_A_const_159 = A_arbace_math__init_A_const_pool.A[174]; A_arbace_math__init_A_const_160 = A_arbace_math__init_A_const_pool.A[175]; A_arbace_math__init_A_const_161 = A_arbace_math__init_A_const_pool.A[176]; A_arbace_math__init_A_const_162 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[177]); A_arbace_math__init_A_const_163 = A_arbace_math__init_A_const_pool.A[178]; A_arbace_math__init_A_const_164 = A_arbace_math__init_A_const_pool.A[179]; A_arbace_math__init_A_const_165 = A_arbace_math__init_A_const_pool.A[180] }

func A_arbace_math__init_A_clinit_p12() { A_arbace_math__init_A_const_166 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[181]); A_arbace_math__init_A_const_167 = A_arbace_math__init_A_const_pool.A[182]; A_arbace_math__init_A_const_168 = A_arbace_math__init_A_const_pool.A[183]; A_arbace_math__init_A_const_169 = A_arbace_math__init_A_const_pool.A[184]; A_arbace_math__init_A_const_170 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[185]); A_arbace_math__init_A_const_171 = A_arbace_math__init_A_const_pool.A[186]; A_arbace_math__init_A_const_172 = A_arbace_math__init_A_const_pool.A[187]; A_arbace_math__init_A_const_173 = A_arbace_math__init_A_const_pool.A[188]; A_arbace_math__init_A_const_174 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[189]); A_arbace_math__init_A_const_175 = A_arbace_math__init_A_const_pool.A[190]; A_arbace_math__init_A_const_176 = A_arbace_math__init_A_const_pool.A[191]; A_arbace_math__init_A_const_177 = A_arbace_math__init_A_const_pool.A[192]; A_arbace_math__init_A_const_178 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[193]); A_arbace_math__init_A_const_179 = A_arbace_math__init_A_const_pool.A[194] }

func A_arbace_math__init_A_clinit_p13() { A_arbace_math__init_A_const_180 = A_arbace_math__init_A_const_pool.A[195]; A_arbace_math__init_A_const_181 = A_arbace_math__init_A_const_pool.A[196]; A_arbace_math__init_A_const_182 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[197]); A_arbace_math__init_A_const_183 = A_arbace_math__init_A_const_pool.A[198]; A_arbace_math__init_A_const_184 = A_arbace_math__init_A_const_pool.A[199]; A_arbace_math__init_A_const_185 = A_arbace_math__init_A_const_pool.A[200]; A_arbace_math__init_A_const_186 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[201]); A_arbace_math__init_A_const_187 = A_arbace_math__init_A_const_pool.A[202]; A_arbace_math__init_A_const_188 = A_arbace_math__init_A_const_pool.A[203]; A_arbace_math__init_A_const_189 = A_arbace_math__init_A_const_pool.A[204] }

func A_arbace_math__init_A_New() *A_arbace_math__init_A { A_arbace_math__init_A_Init(); t := &A_arbace_math__init_A{}; t.Ctor(); return t }

func (t *A_arbace_math__init_A) Ctor() {}

func (t *A_arbace_math__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math__init_A) GetClass__Class() *jrt.Class { return A_arbace_math__init_A_class }

func (t *A_arbace_math__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math__init_A); return ok }

func A_arbace_math__init_A_Cast(x any) *A_arbace_math__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math__init_A_class)) }; return v }
