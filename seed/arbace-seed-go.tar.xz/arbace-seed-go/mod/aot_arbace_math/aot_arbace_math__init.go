//line aot_arbace_math__init.ae:1
package aot_arbace_math

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_math__init_A_Load__O() any { A_arbace_math__init_A_Init(); A_arbace_math__init_A_Unit0__O(); A_arbace_math__init_A_Unit1__O(); A_arbace_math__init_A_Unit2__O(); A_arbace_math__init_A_Unit3__O(); A_arbace_math__init_A_Unit4__O(); A_arbace_math__init_A_Unit5__O(); A_arbace_math__init_A_Unit6__O(); A_arbace_math__init_A_Unit7__O(); A_arbace_math__init_A_Unit8__O(); A_arbace_math__init_A_Unit9__O(); A_arbace_math__init_A_Unit10__O(); A_arbace_math__init_A_Unit11__O(); A_arbace_math__init_A_Unit12__O(); A_arbace_math__init_A_Unit13__O(); A_arbace_math__init_A_Unit14__O(); A_arbace_math__init_A_Unit15__O(); A_arbace_math__init_A_Unit16__O(); A_arbace_math__init_A_Unit17__O(); A_arbace_math__init_A_Unit18__O(); A_arbace_math__init_A_Unit19__O(); A_arbace_math__init_A_Unit20__O(); A_arbace_math__init_A_Unit21__O(); A_arbace_math__init_A_Unit22__O(); A_arbace_math__init_A_Unit23__O(); A_arbace_math__init_A_Unit24__O(); A_arbace_math__init_A_Unit25__O(); A_arbace_math__init_A_Unit26__O(); A_arbace_math__init_A_Unit27__O(); A_arbace_math__init_A_Unit28__O(); A_arbace_math__init_A_Unit29__O(); A_arbace_math__init_A_Unit30__O(); A_arbace_math__init_A_Unit31__O(); A_arbace_math__init_A_Unit32__O(); A_arbace_math__init_A_Unit33__O(); A_arbace_math__init_A_Unit34__O(); A_arbace_math__init_A_Unit35__O(); A_arbace_math__init_A_Unit36__O(); A_arbace_math__init_A_Unit37__O(); A_arbace_math__init_A_Unit38__O(); A_arbace_math__init_A_Unit39__O(); A_arbace_math__init_A_Unit40__O(); A_arbace_math__init_A_Unit41__O(); A_arbace_math__init_A_Unit42__O(); A_arbace_math__init_A_Unit43__O(); A_arbace_math__init_A_Unit44__O(); A_arbace_math__init_A_Unit45__O(); A_arbace_math__init_A_Unit46__O(); A_arbace_math__init_A_Unit47__O(); A_arbace_math__init_A_Unit48__O(); A_arbace_math__init_A_Unit49__O(); return nil }



func A_arbace_math__init_A_Unit0__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_math__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_math__init_A_const_1) }
//line :9:1
func A_arbace_math__init_A_Unit1__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_math__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_2)) }
//line :9:1
func A_arbace_math__init_A_Unit2__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New(); var tmp2 *jrt.Class; A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_Init(); tmp2 = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_math__init_A_Unit3__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_math__init_A_const_1)).Equals_O__Z(A_arbace_math__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_math_eval446000008_fn__446000009_A_New(); var tmp2 *jrt.Class; A_arbace_math_eval446000008_fn__446000009_A_Init(); tmp2 = A_arbace_math_eval446000008_fn__446000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }












func A_arbace_math__init_A_Unit4__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_math__init_A_Unit5__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_5; jrt.NN(tmp1).BindRoot_O__V(jrt.Double_ValueOf_D__Double(2.718281828459045).Ref()); var tmp2 *lang.Var = A_arbace_math__init_A_const_5; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_6)); return A_arbace_math__init_A_const_5.Ref() }








func A_arbace_math__init_A_Unit6__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_7; jrt.NN(tmp1).BindRoot_O__V(jrt.Double_ValueOf_D__Double(3.141592653589793).Ref()); var tmp2 *lang.Var = A_arbace_math__init_A_const_7; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_8)); return A_arbace_math__init_A_const_7.Ref() }








func A_arbace_math__init_A_Unit7__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_9; var tmp2 any = A_arbace_math_sin_A_New(); var tmp3 *jrt.Class; A_arbace_math_sin_A_Init(); tmp3 = A_arbace_math_sin_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_9; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_11; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_14; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_sin__inliner__446000014_A_New(); var tmp12 *jrt.Class; A_arbace_math_sin__inliner__446000014_A_Init(); tmp12 = A_arbace_math_sin__inliner__446000014_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_196, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_18, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_9.Ref() }










func A_arbace_math__init_A_Unit8__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_22; var tmp2 any = A_arbace_math_cos_A_New(); var tmp3 *jrt.Class; A_arbace_math_cos_A_Init(); tmp3 = A_arbace_math_cos_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_22; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_23; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_24; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_cos__inliner__446000017_A_New(); var tmp12 *jrt.Class; A_arbace_math_cos__inliner__446000017_A_Init(); tmp12 = A_arbace_math_cos__inliner__446000017_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_197, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_25, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_22.Ref() }









func A_arbace_math__init_A_Unit9__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_26; var tmp2 any = A_arbace_math_tan_A_New(); var tmp3 *jrt.Class; A_arbace_math_tan_A_Init(); tmp3 = A_arbace_math_tan_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_26; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_27; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_28; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_tan__inliner__446000020_A_New(); var tmp12 *jrt.Class; A_arbace_math_tan__inliner__446000020_A_Init(); tmp12 = A_arbace_math_tan__inliner__446000020_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_198, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_29, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_26.Ref() }










func A_arbace_math__init_A_Unit10__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_30; var tmp2 any = A_arbace_math_asin_A_New(); var tmp3 *jrt.Class; A_arbace_math_asin_A_Init(); tmp3 = A_arbace_math_asin_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_30; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_31; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_32; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_asin__inliner__446000023_A_New(); var tmp12 *jrt.Class; A_arbace_math_asin__inliner__446000023_A_Init(); tmp12 = A_arbace_math_asin__inliner__446000023_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_199, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_33, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_30.Ref() }










func A_arbace_math__init_A_Unit11__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_34; var tmp2 any = A_arbace_math_acos_A_New(); var tmp3 *jrt.Class; A_arbace_math_acos_A_Init(); tmp3 = A_arbace_math_acos_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_34; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_35; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_36; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_acos__inliner__446000026_A_New(); var tmp12 *jrt.Class; A_arbace_math_acos__inliner__446000026_A_Init(); tmp12 = A_arbace_math_acos__inliner__446000026_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_200, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_37, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_34.Ref() }









func A_arbace_math__init_A_Unit12__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_38; var tmp2 any = A_arbace_math_atan_A_New(); var tmp3 *jrt.Class; A_arbace_math_atan_A_Init(); tmp3 = A_arbace_math_atan_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_38; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_39; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_40; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_atan__inliner__446000029_A_New(); var tmp12 *jrt.Class; A_arbace_math_atan__inliner__446000029_A_Init(); tmp12 = A_arbace_math_atan__inliner__446000029_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_201, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_41, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_38.Ref() }










func A_arbace_math__init_A_Unit13__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_42; var tmp2 any = A_arbace_math_to_radians_A_New(); var tmp3 *jrt.Class; A_arbace_math_to_radians_A_Init(); tmp3 = A_arbace_math_to_radians_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_42; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_43; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_44; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_to_radians__inliner__446000032_A_New(); var tmp12 *jrt.Class; A_arbace_math_to_radians__inliner__446000032_A_Init(); tmp12 = A_arbace_math_to_radians__inliner__446000032_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_202, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_45, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_42.Ref() }








func A_arbace_math__init_A_Unit14__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_46; var tmp2 any = A_arbace_math_to_degrees_A_New(); var tmp3 *jrt.Class; A_arbace_math_to_degrees_A_Init(); tmp3 = A_arbace_math_to_degrees_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_46; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_47; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_48; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_to_degrees__inliner__446000035_A_New(); var tmp12 *jrt.Class; A_arbace_math_to_degrees__inliner__446000035_A_Init(); tmp12 = A_arbace_math_to_degrees__inliner__446000035_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_203, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_49, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_46.Ref() }








func A_arbace_math__init_A_Unit15__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(124, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_50; var tmp2 any = A_arbace_math_exp_A_New(); var tmp3 *jrt.Class; A_arbace_math_exp_A_Init(); tmp3 = A_arbace_math_exp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_50; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_51; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_52; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_exp__inliner__446000038_A_New(); var tmp12 *jrt.Class; A_arbace_math_exp__inliner__446000038_A_Init(); tmp12 = A_arbace_math_exp__inliner__446000038_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_204, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_53, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_50.Ref() }











func A_arbace_math__init_A_Unit16__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(136, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_54; var tmp2 any = A_arbace_math_log_A_New(); var tmp3 *jrt.Class; A_arbace_math_log_A_Init(); tmp3 = A_arbace_math_log_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_54; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_55; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_56; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_log__inliner__446000041_A_New(); var tmp12 *jrt.Class; A_arbace_math_log__inliner__446000041_A_Init(); tmp12 = A_arbace_math_log__inliner__446000041_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_205, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_57, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_54.Ref() }











func A_arbace_math__init_A_Unit17__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_58; var tmp2 any = A_arbace_math_log10_A_New(); var tmp3 *jrt.Class; A_arbace_math_log10_A_Init(); tmp3 = A_arbace_math_log10_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_58; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_59; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_60; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_log10__inliner__446000044_A_New(); var tmp12 *jrt.Class; A_arbace_math_log10__inliner__446000044_A_Init(); tmp12 = A_arbace_math_log10__inliner__446000044_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_206, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_61, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_58.Ref() }











func A_arbace_math__init_A_Unit18__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_62; var tmp2 any = A_arbace_math_sqrt_A_New(); var tmp3 *jrt.Class; A_arbace_math_sqrt_A_Init(); tmp3 = A_arbace_math_sqrt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_62; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_63; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_64; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_sqrt__inliner__446000047_A_New(); var tmp12 *jrt.Class; A_arbace_math_sqrt__inliner__446000047_A_Init(); tmp12 = A_arbace_math_sqrt__inliner__446000047_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_207, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_65, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_62.Ref() }











func A_arbace_math__init_A_Unit19__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_66; var tmp2 any = A_arbace_math_cbrt_A_New(); var tmp3 *jrt.Class; A_arbace_math_cbrt_A_Init(); tmp3 = A_arbace_math_cbrt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_66; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_67; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_68; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_cbrt__inliner__446000050_A_New(); var tmp12 *jrt.Class; A_arbace_math_cbrt__inliner__446000050_A_Init(); tmp12 = A_arbace_math_cbrt__inliner__446000050_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_208, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_69, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_66.Ref() }











func A_arbace_math__init_A_Unit20__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(184, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_70; var tmp2 any = A_arbace_math_IEEE_remainder_A_New(); var tmp3 *jrt.Class; A_arbace_math_IEEE_remainder_A_Init(); tmp3 = A_arbace_math_IEEE_remainder_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_70; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_71; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_72; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_IEEE_remainder__inliner__446000053_A_New(); var tmp12 *jrt.Class; A_arbace_math_IEEE_remainder__inliner__446000053_A_Init(); tmp12 = A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_209, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_73, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_70.Ref() }














func A_arbace_math__init_A_Unit21__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(199, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_74; var tmp2 any = A_arbace_math_ceil_A_New(); var tmp3 *jrt.Class; A_arbace_math_ceil_A_Init(); tmp3 = A_arbace_math_ceil_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_74; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_75; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_76; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_ceil__inliner__446000056_A_New(); var tmp12 *jrt.Class; A_arbace_math_ceil__inliner__446000056_A_Init(); tmp12 = A_arbace_math_ceil__inliner__446000056_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_210, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_77, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_74.Ref() }











func A_arbace_math__init_A_Unit22__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(211, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_78; var tmp2 any = A_arbace_math_floor_A_New(); var tmp3 *jrt.Class; A_arbace_math_floor_A_Init(); tmp3 = A_arbace_math_floor_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_78; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_79; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_80; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_floor__inliner__446000059_A_New(); var tmp12 *jrt.Class; A_arbace_math_floor__inliner__446000059_A_Init(); tmp12 = A_arbace_math_floor__inliner__446000059_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_211, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_81, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_78.Ref() }










func A_arbace_math__init_A_Unit23__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(222, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_82; var tmp2 any = A_arbace_math_rint_A_New(); var tmp3 *jrt.Class; A_arbace_math_rint_A_Init(); tmp3 = A_arbace_math_rint_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_82; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_83; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_84; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_rint__inliner__446000062_A_New(); var tmp12 *jrt.Class; A_arbace_math_rint__inliner__446000062_A_Init(); tmp12 = A_arbace_math_rint__inliner__446000062_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_212, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_85, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_82.Ref() }










func A_arbace_math__init_A_Unit24__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(233, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_86; var tmp2 any = A_arbace_math_atan2_A_New(); var tmp3 *jrt.Class; A_arbace_math_atan2_A_Init(); tmp3 = A_arbace_math_atan2_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_86; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_87; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_88; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_atan2__inliner__446000065_A_New(); var tmp12 *jrt.Class; A_arbace_math_atan2__inliner__446000065_A_Init(); tmp12 = A_arbace_math_atan2__inliner__446000065_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_213, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_89, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_86.Ref() }










func A_arbace_math__init_A_Unit25__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(244, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_90; var tmp2 any = A_arbace_math_pow_A_New(); var tmp3 *jrt.Class; A_arbace_math_pow_A_Init(); tmp3 = A_arbace_math_pow_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_90; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_91; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_92; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_pow__inliner__446000068_A_New(); var tmp12 *jrt.Class; A_arbace_math_pow__inliner__446000068_A_Init(); tmp12 = A_arbace_math_pow__inliner__446000068_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_214, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_93, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_90.Ref() }









func A_arbace_math__init_A_Unit26__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(254, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_94; var tmp2 any = A_arbace_math_round_A_New(); var tmp3 *jrt.Class; A_arbace_math_round_A_Init(); tmp3 = A_arbace_math_round_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_94; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_95; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_96; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_round__inliner__446000071_A_New(); var tmp12 *jrt.Class; A_arbace_math_round__inliner__446000071_A_Init(); tmp12 = A_arbace_math_round__inliner__446000071_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_215, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_97, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_94.Ref() }












func A_arbace_math__init_A_Unit27__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_98; var tmp2 any = A_arbace_math_random_A_New(); var tmp3 *jrt.Class; A_arbace_math_random_A_Init(); tmp3 = A_arbace_math_random_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_98; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_99; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_100; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_random__inliner__446000074_A_New(); var tmp12 *jrt.Class; A_arbace_math_random__inliner__446000074_A_Init(); tmp12 = A_arbace_math_random__inliner__446000074_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_216, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_101, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_98.Ref() }









func A_arbace_math__init_A_Unit28__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(277, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_102; var tmp2 any = A_arbace_math_add_exact_A_New(); var tmp3 *jrt.Class; A_arbace_math_add_exact_A_Init(); tmp3 = A_arbace_math_add_exact_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_102; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_103; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_104; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_add_exact__inliner__446000077_A_New(); var tmp12 *jrt.Class; A_arbace_math_add_exact__inliner__446000077_A_Init(); tmp12 = A_arbace_math_add_exact__inliner__446000077_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_217, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_105, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_102.Ref() }








func A_arbace_math__init_A_Unit29__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(286, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_106; var tmp2 any = A_arbace_math_subtract_exact_A_New(); var tmp3 *jrt.Class; A_arbace_math_subtract_exact_A_Init(); tmp3 = A_arbace_math_subtract_exact_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_106; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_107; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_108; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_subtract_exact__inliner__446000080_A_New(); var tmp12 *jrt.Class; A_arbace_math_subtract_exact__inliner__446000080_A_Init(); tmp12 = A_arbace_math_subtract_exact__inliner__446000080_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_218, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_109, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_106.Ref() }








func A_arbace_math__init_A_Unit30__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(295, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_110; var tmp2 any = A_arbace_math_multiply_exact_A_New(); var tmp3 *jrt.Class; A_arbace_math_multiply_exact_A_Init(); tmp3 = A_arbace_math_multiply_exact_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_110; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_111; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_112; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_multiply_exact__inliner__446000083_A_New(); var tmp12 *jrt.Class; A_arbace_math_multiply_exact__inliner__446000083_A_Init(); tmp12 = A_arbace_math_multiply_exact__inliner__446000083_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_219, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_113, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_110.Ref() }








func A_arbace_math__init_A_Unit31__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(304, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_114; var tmp2 any = A_arbace_math_increment_exact_A_New(); var tmp3 *jrt.Class; A_arbace_math_increment_exact_A_Init(); tmp3 = A_arbace_math_increment_exact_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_114; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_115; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_116; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_increment_exact__inliner__446000086_A_New(); var tmp12 *jrt.Class; A_arbace_math_increment_exact__inliner__446000086_A_Init(); tmp12 = A_arbace_math_increment_exact__inliner__446000086_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_220, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_117, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_114.Ref() }








func A_arbace_math__init_A_Unit32__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(313, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_118; var tmp2 any = A_arbace_math_decrement_exact_A_New(); var tmp3 *jrt.Class; A_arbace_math_decrement_exact_A_Init(); tmp3 = A_arbace_math_decrement_exact_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_118; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_119; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_120; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_decrement_exact__inliner__446000089_A_New(); var tmp12 *jrt.Class; A_arbace_math_decrement_exact__inliner__446000089_A_Init(); tmp12 = A_arbace_math_decrement_exact__inliner__446000089_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_221, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_121, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_118.Ref() }








func A_arbace_math__init_A_Unit33__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(322, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_122; var tmp2 any = A_arbace_math_negate_exact_A_New(); var tmp3 *jrt.Class; A_arbace_math_negate_exact_A_Init(); tmp3 = A_arbace_math_negate_exact_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_122; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_123; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_124; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_negate_exact__inliner__446000092_A_New(); var tmp12 *jrt.Class; A_arbace_math_negate_exact__inliner__446000092_A_Init(); tmp12 = A_arbace_math_negate_exact__inliner__446000092_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_222, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_125, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_122.Ref() }








func A_arbace_math__init_A_Unit34__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(331, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_126; var tmp2 any = A_arbace_math_floor_div_A_New(); var tmp3 *jrt.Class; A_arbace_math_floor_div_A_Init(); tmp3 = A_arbace_math_floor_div_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_126; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_127; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_128; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_floor_div__inliner__446000095_A_New(); var tmp12 *jrt.Class; A_arbace_math_floor_div__inliner__446000095_A_Init(); tmp12 = A_arbace_math_floor_div__inliner__446000095_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_223, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_129, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_126.Ref() }









func A_arbace_math__init_A_Unit35__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(341, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_130; var tmp2 any = A_arbace_math_floor_mod_A_New(); var tmp3 *jrt.Class; A_arbace_math_floor_mod_A_Init(); tmp3 = A_arbace_math_floor_mod_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_130; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_131; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_132; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_floor_mod__inliner__446000098_A_New(); var tmp12 *jrt.Class; A_arbace_math_floor_mod__inliner__446000098_A_Init(); tmp12 = A_arbace_math_floor_mod__inliner__446000098_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_224, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_133, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_130.Ref() }









func A_arbace_math__init_A_Unit36__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(351, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_134; var tmp2 any = A_arbace_math_ulp_A_New(); var tmp3 *jrt.Class; A_arbace_math_ulp_A_Init(); tmp3 = A_arbace_math_ulp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_134; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_135; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_136; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_ulp__inliner__446000101_A_New(); var tmp12 *jrt.Class; A_arbace_math_ulp__inliner__446000101_A_Init(); tmp12 = A_arbace_math_ulp__inliner__446000101_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_225, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_137, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_134.Ref() }












func A_arbace_math__init_A_Unit37__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(364, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_138; var tmp2 any = A_arbace_math_signum_A_New(); var tmp3 *jrt.Class; A_arbace_math_signum_A_Init(); tmp3 = A_arbace_math_signum_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_138; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_139; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_140; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_signum__inliner__446000104_A_New(); var tmp12 *jrt.Class; A_arbace_math_signum__inliner__446000104_A_Init(); tmp12 = A_arbace_math_signum__inliner__446000104_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_226, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_141, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_138.Ref() }









func A_arbace_math__init_A_Unit38__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(374, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_142; var tmp2 any = A_arbace_math_sinh_A_New(); var tmp3 *jrt.Class; A_arbace_math_sinh_A_Init(); tmp3 = A_arbace_math_sinh_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_142; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_143; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_144; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_sinh__inliner__446000107_A_New(); var tmp12 *jrt.Class; A_arbace_math_sinh__inliner__446000107_A_Init(); tmp12 = A_arbace_math_sinh__inliner__446000107_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_227, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_145, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_142.Ref() }










func A_arbace_math__init_A_Unit39__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(385, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_146; var tmp2 any = A_arbace_math_cosh_A_New(); var tmp3 *jrt.Class; A_arbace_math_cosh_A_Init(); tmp3 = A_arbace_math_cosh_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_146; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_147; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_148; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_cosh__inliner__446000110_A_New(); var tmp12 *jrt.Class; A_arbace_math_cosh__inliner__446000110_A_Init(); tmp12 = A_arbace_math_cosh__inliner__446000110_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_228, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_149, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_146.Ref() }











func A_arbace_math__init_A_Unit40__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(397, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_150; var tmp2 any = A_arbace_math_tanh_A_New(); var tmp3 *jrt.Class; A_arbace_math_tanh_A_Init(); tmp3 = A_arbace_math_tanh_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_150; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_151; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_152; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_tanh__inliner__446000113_A_New(); var tmp12 *jrt.Class; A_arbace_math_tanh__inliner__446000113_A_Init(); tmp12 = A_arbace_math_tanh__inliner__446000113_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_229, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_153, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_150.Ref() }












func A_arbace_math__init_A_Unit41__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(410, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_154; var tmp2 any = A_arbace_math_hypot_A_New(); var tmp3 *jrt.Class; A_arbace_math_hypot_A_Init(); tmp3 = A_arbace_math_hypot_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_154; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_155; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_156; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_hypot__inliner__446000116_A_New(); var tmp12 *jrt.Class; A_arbace_math_hypot__inliner__446000116_A_Init(); tmp12 = A_arbace_math_hypot__inliner__446000116_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_230, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_157, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_154.Ref() }










func A_arbace_math__init_A_Unit42__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(421, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_158; var tmp2 any = A_arbace_math_expm1_A_New(); var tmp3 *jrt.Class; A_arbace_math_expm1_A_Init(); tmp3 = A_arbace_math_expm1_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_158; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_159; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_160; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_expm1__inliner__446000119_A_New(); var tmp12 *jrt.Class; A_arbace_math_expm1__inliner__446000119_A_Init(); tmp12 = A_arbace_math_expm1__inliner__446000119_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_231, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_161, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_158.Ref() }












func A_arbace_math__init_A_Unit43__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(434, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_162; var tmp2 any = A_arbace_math_log1p_A_New(); var tmp3 *jrt.Class; A_arbace_math_log1p_A_Init(); tmp3 = A_arbace_math_log1p_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_162; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_163; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_164; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_log1p__inliner__446000122_A_New(); var tmp12 *jrt.Class; A_arbace_math_log1p__inliner__446000122_A_Init(); tmp12 = A_arbace_math_log1p__inliner__446000122_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_232, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_165, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_162.Ref() }













func A_arbace_math__init_A_Unit44__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(448, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_166; var tmp2 any = A_arbace_math_copy_sign_A_New(); var tmp3 *jrt.Class; A_arbace_math_copy_sign_A_Init(); tmp3 = A_arbace_math_copy_sign_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_166; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_167; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_168; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_copy_sign__inliner__446000125_A_New(); var tmp12 *jrt.Class; A_arbace_math_copy_sign__inliner__446000125_A_Init(); tmp12 = A_arbace_math_copy_sign__inliner__446000125_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_233, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_169, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_166.Ref() }









func A_arbace_math__init_A_Unit45__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(458, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_170; var tmp2 any = A_arbace_math_get_exponent_A_New(); var tmp3 *jrt.Class; A_arbace_math_get_exponent_A_Init(); tmp3 = A_arbace_math_get_exponent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_170; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_171; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_172; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_get_exponent__inliner__446000128_A_New(); var tmp12 *jrt.Class; A_arbace_math_get_exponent__inliner__446000128_A_Init(); tmp12 = A_arbace_math_get_exponent__inliner__446000128_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_234, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_173, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_170.Ref() }










func A_arbace_math__init_A_Unit46__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(469, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_174; var tmp2 any = A_arbace_math_next_after_A_New(); var tmp3 *jrt.Class; A_arbace_math_next_after_A_Init(); tmp3 = A_arbace_math_next_after_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_174; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_175; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_176; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_next_after__inliner__446000131_A_New(); var tmp12 *jrt.Class; A_arbace_math_next_after__inliner__446000131_A_Init(); tmp12 = A_arbace_math_next_after__inliner__446000131_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_235, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_177, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_174.Ref() }

















func A_arbace_math__init_A_Unit47__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(487, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_178; var tmp2 any = A_arbace_math_next_up_A_New(); var tmp3 *jrt.Class; A_arbace_math_next_up_A_Init(); tmp3 = A_arbace_math_next_up_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_178; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_179; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_180; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_next_up__inliner__446000134_A_New(); var tmp12 *jrt.Class; A_arbace_math_next_up__inliner__446000134_A_Init(); tmp12 = A_arbace_math_next_up__inliner__446000134_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_236, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_181, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_178.Ref() }











func A_arbace_math__init_A_Unit48__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(499, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_182; var tmp2 any = A_arbace_math_next_down_A_New(); var tmp3 *jrt.Class; A_arbace_math_next_down_A_Init(); tmp3 = A_arbace_math_next_down_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_182; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_183; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_184; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_next_down__inliner__446000137_A_New(); var tmp12 *jrt.Class; A_arbace_math_next_down__inliner__446000137_A_Init(); tmp12 = A_arbace_math_next_down__inliner__446000137_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_237, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_185, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_182.Ref() }











func A_arbace_math__init_A_Unit49__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V(511, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_186; var tmp2 any = A_arbace_math_scalb_A_New(); var tmp3 *jrt.Class; A_arbace_math_scalb_A_Init(); tmp3 = A_arbace_math_scalb_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_math__init_A_const_186; var tmp5 any = A_arbace_math__init_A_const_10.Ref(); var tmp6 any = A_arbace_math__init_A_const_187; var tmp7 any = A_arbace_math__init_A_const_12.Ref(); var tmp8 any = A_arbace_math__init_A_const_13.Ref(); var tmp9 any = A_arbace_math__init_A_const_188; var tmp10 any = A_arbace_math__init_A_const_15.Ref(); var tmp11 any = A_arbace_math_scalb__inliner__446000140_A_New(); var tmp12 *jrt.Class; A_arbace_math_scalb__inliner__446000140_A_Init(); tmp12 = A_arbace_math_scalb__inliner__446000140_A_fn_class; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_238, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_math__init_A_const_16.Ref(), Lit_154, A_arbace_math__init_A_const_17.Ref(), A_arbace_math__init_A_const_189, A_arbace_math__init_A_const_19.Ref(), A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21.Ref(), Lit_160))); return A_arbace_math__init_A_const_186.Ref() }



type A_arbace_math__init_A struct{ jrt.Object }

var A_arbace_math__init_A_const_0 *lang.Var

var A_arbace_math__init_A_const_1 any

var A_arbace_math__init_A_const_2 any

var A_arbace_math__init_A_const_3 any

var A_arbace_math__init_A_const_4 *lang.Var

var A_arbace_math__init_A_const_5 *lang.Var

var A_arbace_math__init_A_const_6 any

var A_arbace_math__init_A_const_7 *lang.Var

var A_arbace_math__init_A_const_8 any

var A_arbace_math__init_A_const_9 *lang.Var

var A_arbace_math__init_A_const_10 *lang.Keyword

var A_arbace_math__init_A_const_11 any

var A_arbace_math__init_A_const_12 *lang.Keyword

var A_arbace_math__init_A_const_13 *lang.Keyword

var A_arbace_math__init_A_const_14 any

var A_arbace_math__init_A_const_15 *lang.Keyword

var A_arbace_math__init_A_const_16 *lang.Keyword

var A_arbace_math__init_A_const_17 *lang.Keyword

var A_arbace_math__init_A_const_18 any

var A_arbace_math__init_A_const_19 *lang.Keyword

var A_arbace_math__init_A_const_20 any

var A_arbace_math__init_A_const_21 *lang.Keyword

var A_arbace_math__init_A_const_22 *lang.Var

var A_arbace_math__init_A_const_23 any

var A_arbace_math__init_A_const_24 any

var A_arbace_math__init_A_const_25 any

var A_arbace_math__init_A_const_26 *lang.Var

var A_arbace_math__init_A_const_27 any

var A_arbace_math__init_A_const_28 any

var A_arbace_math__init_A_const_29 any

var A_arbace_math__init_A_const_30 *lang.Var

var A_arbace_math__init_A_const_31 any

var A_arbace_math__init_A_const_32 any

var A_arbace_math__init_A_const_33 any

var A_arbace_math__init_A_const_34 *lang.Var

var A_arbace_math__init_A_const_35 any

var A_arbace_math__init_A_const_36 any

var A_arbace_math__init_A_const_37 any

var A_arbace_math__init_A_const_38 *lang.Var

var A_arbace_math__init_A_const_39 any

var A_arbace_math__init_A_const_40 any

var A_arbace_math__init_A_const_41 any

var A_arbace_math__init_A_const_42 *lang.Var

var A_arbace_math__init_A_const_43 any

var A_arbace_math__init_A_const_44 any

var A_arbace_math__init_A_const_45 any

var A_arbace_math__init_A_const_46 *lang.Var

var A_arbace_math__init_A_const_47 any

var A_arbace_math__init_A_const_48 any

var A_arbace_math__init_A_const_49 any

var A_arbace_math__init_A_const_50 *lang.Var

var A_arbace_math__init_A_const_51 any

var A_arbace_math__init_A_const_52 any

var A_arbace_math__init_A_const_53 any

var A_arbace_math__init_A_const_54 *lang.Var

var A_arbace_math__init_A_const_55 any

var A_arbace_math__init_A_const_56 any

var A_arbace_math__init_A_const_57 any

var A_arbace_math__init_A_const_58 *lang.Var

var A_arbace_math__init_A_const_59 any

var A_arbace_math__init_A_const_60 any

var A_arbace_math__init_A_const_61 any

var A_arbace_math__init_A_const_62 *lang.Var

var A_arbace_math__init_A_const_63 any

var A_arbace_math__init_A_const_64 any

var A_arbace_math__init_A_const_65 any

var A_arbace_math__init_A_const_66 *lang.Var

var A_arbace_math__init_A_const_67 any

var A_arbace_math__init_A_const_68 any

var A_arbace_math__init_A_const_69 any

var A_arbace_math__init_A_const_70 *lang.Var

var A_arbace_math__init_A_const_71 any

var A_arbace_math__init_A_const_72 any

var A_arbace_math__init_A_const_73 any

var A_arbace_math__init_A_const_74 *lang.Var

var A_arbace_math__init_A_const_75 any

var A_arbace_math__init_A_const_76 any

var A_arbace_math__init_A_const_77 any

var A_arbace_math__init_A_const_78 *lang.Var

var A_arbace_math__init_A_const_79 any

var A_arbace_math__init_A_const_80 any

var A_arbace_math__init_A_const_81 any

var A_arbace_math__init_A_const_82 *lang.Var

var A_arbace_math__init_A_const_83 any

var A_arbace_math__init_A_const_84 any

var A_arbace_math__init_A_const_85 any

var A_arbace_math__init_A_const_86 *lang.Var

var A_arbace_math__init_A_const_87 any

var A_arbace_math__init_A_const_88 any

var A_arbace_math__init_A_const_89 any

var A_arbace_math__init_A_const_90 *lang.Var

var A_arbace_math__init_A_const_91 any

var A_arbace_math__init_A_const_92 any

var A_arbace_math__init_A_const_93 any

var A_arbace_math__init_A_const_94 *lang.Var

var A_arbace_math__init_A_const_95 any

var A_arbace_math__init_A_const_96 any

var A_arbace_math__init_A_const_97 any

var A_arbace_math__init_A_const_98 *lang.Var

var A_arbace_math__init_A_const_99 any

var A_arbace_math__init_A_const_100 any

var A_arbace_math__init_A_const_101 any

var A_arbace_math__init_A_const_102 *lang.Var

var A_arbace_math__init_A_const_103 any

var A_arbace_math__init_A_const_104 any

var A_arbace_math__init_A_const_105 any

var A_arbace_math__init_A_const_106 *lang.Var

var A_arbace_math__init_A_const_107 any

var A_arbace_math__init_A_const_108 any

var A_arbace_math__init_A_const_109 any

var A_arbace_math__init_A_const_110 *lang.Var

var A_arbace_math__init_A_const_111 any

var A_arbace_math__init_A_const_112 any

var A_arbace_math__init_A_const_113 any

var A_arbace_math__init_A_const_114 *lang.Var

var A_arbace_math__init_A_const_115 any

var A_arbace_math__init_A_const_116 any

var A_arbace_math__init_A_const_117 any

var A_arbace_math__init_A_const_118 *lang.Var

var A_arbace_math__init_A_const_119 any

var A_arbace_math__init_A_const_120 any

var A_arbace_math__init_A_const_121 any

var A_arbace_math__init_A_const_122 *lang.Var

var A_arbace_math__init_A_const_123 any

var A_arbace_math__init_A_const_124 any

var A_arbace_math__init_A_const_125 any

var A_arbace_math__init_A_const_126 *lang.Var

var A_arbace_math__init_A_const_127 any

var A_arbace_math__init_A_const_128 any

var A_arbace_math__init_A_const_129 any

var A_arbace_math__init_A_const_130 *lang.Var

var A_arbace_math__init_A_const_131 any

var A_arbace_math__init_A_const_132 any

var A_arbace_math__init_A_const_133 any

var A_arbace_math__init_A_const_134 *lang.Var

var A_arbace_math__init_A_const_135 any

var A_arbace_math__init_A_const_136 any

var A_arbace_math__init_A_const_137 any

var A_arbace_math__init_A_const_138 *lang.Var

var A_arbace_math__init_A_const_139 any

var A_arbace_math__init_A_const_140 any

var A_arbace_math__init_A_const_141 any

var A_arbace_math__init_A_const_142 *lang.Var

var A_arbace_math__init_A_const_143 any

var A_arbace_math__init_A_const_144 any

var A_arbace_math__init_A_const_145 any

var A_arbace_math__init_A_const_146 *lang.Var

var A_arbace_math__init_A_const_147 any

var A_arbace_math__init_A_const_148 any

var A_arbace_math__init_A_const_149 any

var A_arbace_math__init_A_const_150 *lang.Var

var A_arbace_math__init_A_const_151 any

var A_arbace_math__init_A_const_152 any

var A_arbace_math__init_A_const_153 any

var A_arbace_math__init_A_const_154 *lang.Var

var A_arbace_math__init_A_const_155 any

var A_arbace_math__init_A_const_156 any

var A_arbace_math__init_A_const_157 any

var A_arbace_math__init_A_const_158 *lang.Var

var A_arbace_math__init_A_const_159 any

var A_arbace_math__init_A_const_160 any

var A_arbace_math__init_A_const_161 any

var A_arbace_math__init_A_const_162 *lang.Var

var A_arbace_math__init_A_const_163 any

var A_arbace_math__init_A_const_164 any

var A_arbace_math__init_A_const_165 any

var A_arbace_math__init_A_const_166 *lang.Var

var A_arbace_math__init_A_const_167 any

var A_arbace_math__init_A_const_168 any

var A_arbace_math__init_A_const_169 any

var A_arbace_math__init_A_const_170 *lang.Var

var A_arbace_math__init_A_const_171 any

var A_arbace_math__init_A_const_172 any

var A_arbace_math__init_A_const_173 any

var A_arbace_math__init_A_const_174 *lang.Var

var A_arbace_math__init_A_const_175 any

var A_arbace_math__init_A_const_176 any

var A_arbace_math__init_A_const_177 any

var A_arbace_math__init_A_const_178 *lang.Var

var A_arbace_math__init_A_const_179 any

var A_arbace_math__init_A_const_180 any

var A_arbace_math__init_A_const_181 any

var A_arbace_math__init_A_const_182 *lang.Var

var A_arbace_math__init_A_const_183 any

var A_arbace_math__init_A_const_184 any

var A_arbace_math__init_A_const_185 any

var A_arbace_math__init_A_const_186 *lang.Var

var A_arbace_math__init_A_const_187 any

var A_arbace_math__init_A_const_188 any

var A_arbace_math__init_A_const_189 any

var A_arbace_math__init_A_init jrt.ClassInit

func A_arbace_math__init_A_Init() { if !A_arbace_math__init_A_init.Done() { A_arbace_math__init_A_init.Run(A_arbace_math__init_A_clinit) } }

func A_arbace_math__init_A_clinit() { A_arbace_math__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_149); A_arbace_math__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_math__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_math__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_math__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_150); A_arbace_math__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_5, Lit_151); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp2 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(); var tmp3 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; var tmp5 any = tmp4.Ref(); A_arbace_math__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, Lit_152, tmp2, Lit_154, tmp3, tmp5, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_math__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_5, Lit_161); var tmp6 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(); var tmp8 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; var tmp10 any = tmp9.Ref(); A_arbace_math__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_162, tmp7, Lit_154, tmp8, tmp10, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)); A_arbace_math__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_5, Lit_15); A_arbace_math__init_A_const_10 = lang.RT_Keyword_String_String__Keyword(nil, Lit_163); A_arbace_math__init_A_const_11 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_12 = lang.RT_Keyword_String_String__Keyword(nil, Lit_8); A_arbace_math__init_A_const_13 = lang.RT_Keyword_String_String__Keyword(nil, Lit_165); A_arbace_math__init_A_const_14 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_166); A_arbace_math__init_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_153); A_arbace_math__init_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_157); A_arbace_math__init_A_const_18 = jrt.Integer_ValueOf_I__Integer(42).Ref(); A_arbace_math__init_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_158); A_arbace_math__init_A_const_20 = jrt.Integer_ValueOf_I__Integer(1).Ref(); A_arbace_math__init_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_159); A_arbace_math__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_17); A_arbace_math__init_A_const_23 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_24 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_25 = jrt.Integer_ValueOf_I__Integer(53).Ref(); A_arbace_math__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_5, Lit_18); A_arbace_math__init_A_const_27 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_28 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_29 = jrt.Integer_ValueOf_I__Integer(63).Ref(); A_arbace_math__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_19); A_arbace_math__init_A_const_31 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_32 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_33 = jrt.Integer_ValueOf_I__Integer(74).Ref(); A_arbace_math__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); A_arbace_math__init_A_const_35 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_36 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_37 = jrt.Integer_ValueOf_I__Integer(85).Ref(); A_arbace_math__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); A_arbace_math__init_A_const_39 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_40 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_41 = jrt.Integer_ValueOf_I__Integer(95).Ref(); A_arbace_math__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_5, Lit_167); A_arbace_math__init_A_const_43 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_168)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_44 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_45 = jrt.Integer_ValueOf_I__Integer(106).Ref(); A_arbace_math__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_5, Lit_169); A_arbace_math__init_A_const_47 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_170)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_48 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_49 = jrt.Integer_ValueOf_I__Integer(115).Ref(); A_arbace_math__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); A_arbace_math__init_A_const_51 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_52 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_53 = jrt.Integer_ValueOf_I__Integer(124).Ref(); A_arbace_math__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); A_arbace_math__init_A_const_55 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_56 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_57 = jrt.Integer_ValueOf_I__Integer(136).Ref(); A_arbace_math__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_5, Lit_26); A_arbace_math__init_A_const_59 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_60 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_61 = jrt.Integer_ValueOf_I__Integer(148).Ref(); A_arbace_math__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); A_arbace_math__init_A_const_63 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_64 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_65 = jrt.Integer_ValueOf_I__Integer(160).Ref(); A_arbace_math__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_5, Lit_28); A_arbace_math__init_A_const_67 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_68 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_69 = jrt.Integer_ValueOf_I__Integer(172).Ref(); A_arbace_math__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_5, Lit_171); A_arbace_math__init_A_const_71 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_172)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_173)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_72 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_73 = jrt.Integer_ValueOf_I__Integer(184).Ref(); A_arbace_math__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_5, Lit_30); A_arbace_math__init_A_const_75 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_76 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_77 = jrt.Integer_ValueOf_I__Integer(199).Ref(); A_arbace_math__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_5, Lit_31); A_arbace_math__init_A_const_79 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_80 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_81 = jrt.Integer_ValueOf_I__Integer(211).Ref(); A_arbace_math__init_A_const_82 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_math__init_A_const_83 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_84 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_85 = jrt.Integer_ValueOf_I__Integer(222).Ref(); A_arbace_math__init_A_const_86 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_math__init_A_const_87 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_88 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_89 = jrt.Integer_ValueOf_I__Integer(233).Ref(); A_arbace_math__init_A_const_90 = lang.RT_Var_String_String__Var(Lit_5, Lit_34); A_arbace_math__init_A_const_91 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_176)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_92 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_93 = jrt.Integer_ValueOf_I__Integer(244).Ref(); A_arbace_math__init_A_const_94 = lang.RT_Var_String_String__Var(Lit_5, Lit_35); A_arbace_math__init_A_const_95 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_96 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_97 = jrt.Integer_ValueOf_I__Integer(254).Ref(); A_arbace_math__init_A_const_98 = lang.RT_Var_String_String__Var(Lit_5, Lit_36); A_arbace_math__init_A_const_99 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create__IPersistentVector()).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_100 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(0).Ref())).Ref(); A_arbace_math__init_A_const_101 = jrt.Integer_ValueOf_I__Integer(267).Ref(); A_arbace_math__init_A_const_102 = lang.RT_Var_String_String__Var(Lit_5, Lit_177); A_arbace_math__init_A_const_103 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_104 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_105 = jrt.Integer_ValueOf_I__Integer(277).Ref(); A_arbace_math__init_A_const_106 = lang.RT_Var_String_String__Var(Lit_5, Lit_178); A_arbace_math__init_A_const_107 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_108 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_109 = jrt.Integer_ValueOf_I__Integer(286).Ref(); A_arbace_math__init_A_const_110 = lang.RT_Var_String_String__Var(Lit_5, Lit_179); A_arbace_math__init_A_const_111 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_112 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_113 = jrt.Integer_ValueOf_I__Integer(295).Ref(); A_arbace_math__init_A_const_114 = lang.RT_Var_String_String__Var(Lit_5, Lit_180); A_arbace_math__init_A_const_115 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_116 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_117 = jrt.Integer_ValueOf_I__Integer(304).Ref(); A_arbace_math__init_A_const_118 = lang.RT_Var_String_String__Var(Lit_5, Lit_181); A_arbace_math__init_A_const_119 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_120 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_121 = jrt.Integer_ValueOf_I__Integer(313).Ref(); A_arbace_math__init_A_const_122 = lang.RT_Var_String_String__Var(Lit_5, Lit_182); A_arbace_math__init_A_const_123 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_124 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_125 = jrt.Integer_ValueOf_I__Integer(322).Ref(); A_arbace_math__init_A_const_126 = lang.RT_Var_String_String__Var(Lit_5, Lit_183); A_arbace_math__init_A_const_127 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_128 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_129 = jrt.Integer_ValueOf_I__Integer(331).Ref(); A_arbace_math__init_A_const_130 = lang.RT_Var_String_String__Var(Lit_5, Lit_184); A_arbace_math__init_A_const_131 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))))); A_arbace_math__init_A_const_132 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_133 = jrt.Integer_ValueOf_I__Integer(341).Ref(); A_arbace_math__init_A_const_134 = lang.RT_Var_String_String__Var(Lit_5, Lit_46); A_arbace_math__init_A_const_135 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_136 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_137 = jrt.Integer_ValueOf_I__Integer(351).Ref(); A_arbace_math__init_A_const_138 = lang.RT_Var_String_String__Var(Lit_5, Lit_47); A_arbace_math__init_A_const_139 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_140 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_141 = jrt.Integer_ValueOf_I__Integer(364).Ref(); A_arbace_math__init_A_const_142 = lang.RT_Var_String_String__Var(Lit_5, Lit_48); A_arbace_math__init_A_const_143 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_144 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_145 = jrt.Integer_ValueOf_I__Integer(374).Ref(); A_arbace_math__init_A_const_146 = lang.RT_Var_String_String__Var(Lit_5, Lit_49); A_arbace_math__init_A_const_147 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_148 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_149 = jrt.Integer_ValueOf_I__Integer(385).Ref(); A_arbace_math__init_A_const_150 = lang.RT_Var_String_String__Var(Lit_5, Lit_50); A_arbace_math__init_A_const_151 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_152 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_153 = jrt.Integer_ValueOf_I__Integer(397).Ref(); A_arbace_math__init_A_const_154 = lang.RT_Var_String_String__Var(Lit_5, Lit_51); A_arbace_math__init_A_const_155 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_156 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_157 = jrt.Integer_ValueOf_I__Integer(410).Ref(); A_arbace_math__init_A_const_158 = lang.RT_Var_String_String__Var(Lit_5, Lit_52); A_arbace_math__init_A_const_159 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_160 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_161 = jrt.Integer_ValueOf_I__Integer(421).Ref(); A_arbace_math__init_A_const_162 = lang.RT_Var_String_String__Var(Lit_5, Lit_53); A_arbace_math__init_A_const_163 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_164 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_165 = jrt.Integer_ValueOf_I__Integer(434).Ref(); A_arbace_math__init_A_const_166 = lang.RT_Var_String_String__Var(Lit_5, Lit_186); A_arbace_math__init_A_const_167 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_188)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_168 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_169 = jrt.Integer_ValueOf_I__Integer(448).Ref(); A_arbace_math__init_A_const_170 = lang.RT_Var_String_String__Var(Lit_5, Lit_189); A_arbace_math__init_A_const_171 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))))); A_arbace_math__init_A_const_172 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_173 = jrt.Integer_ValueOf_I__Integer(458).Ref(); A_arbace_math__init_A_const_174 = lang.RT_Var_String_String__Var(Lit_5, Lit_190); A_arbace_math__init_A_const_175 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_191)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_192)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_176 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_177 = jrt.Integer_ValueOf_I__Integer(469).Ref(); A_arbace_math__init_A_const_178 = lang.RT_Var_String_String__Var(Lit_5, Lit_193); A_arbace_math__init_A_const_179 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_180 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_181 = jrt.Integer_ValueOf_I__Integer(487).Ref(); A_arbace_math__init_A_const_182 = lang.RT_Var_String_String__Var(Lit_5, Lit_194); A_arbace_math__init_A_const_183 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_184 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(1).Ref())).Ref(); A_arbace_math__init_A_const_185 = jrt.Integer_ValueOf_I__Integer(499).Ref(); A_arbace_math__init_A_const_186 = lang.RT_Var_String_String__Var(Lit_5, Lit_59); A_arbace_math__init_A_const_187 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_185)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_195).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_156).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref())))))); A_arbace_math__init_A_const_188 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Long_ValueOf_J__Long(2).Ref())).Ref(); A_arbace_math__init_A_const_189 = jrt.Integer_ValueOf_I__Integer(511).Ref() }

func A_arbace_math__init_A_New() *A_arbace_math__init_A { A_arbace_math__init_A_Init(); t := &A_arbace_math__init_A{}; t.Ctor(); return t }

func (t *A_arbace_math__init_A) Ctor() {}

func (t *A_arbace_math__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math__init_A) GetClass__Class() *jrt.Class { return A_arbace_math__init_A_class }

func (t *A_arbace_math__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_math__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math__init_A); return ok }

func A_arbace_math__init_A_Cast(x any) *A_arbace_math__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math__init_A_class)) }; return v }
