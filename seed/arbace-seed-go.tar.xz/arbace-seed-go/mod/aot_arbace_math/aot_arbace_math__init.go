//line aot_arbace_math__init.ae:1
package aot_arbace_math

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_math__init_A_Load__O() any { A_arbace_math__init_A_Init(); jrt.StartCheck(); A_arbace_math__init_A_Unit0__O(); A_arbace_math__init_A_Unit1__O(); A_arbace_math__init_A_Unit2__O(); A_arbace_math__init_A_Unit3__O(); A_arbace_math__init_A_Unit4__O(); A_arbace_math__init_A_Unit5__O(); A_arbace_math__init_A_Unit6__O(); A_arbace_math__init_A_Unit7__O(); A_arbace_math__init_A_Unit8__O(); A_arbace_math__init_A_Unit9__O(); A_arbace_math__init_A_Unit10__O(); A_arbace_math__init_A_Unit11__O(); A_arbace_math__init_A_Unit12__O(); A_arbace_math__init_A_Unit13__O(); A_arbace_math__init_A_Unit14__O(); A_arbace_math__init_A_Unit15__O(); A_arbace_math__init_A_Unit16__O(); A_arbace_math__init_A_Unit17__O(); A_arbace_math__init_A_Unit18__O(); A_arbace_math__init_A_Unit19__O(); A_arbace_math__init_A_Unit20__O(); A_arbace_math__init_A_Unit21__O(); A_arbace_math__init_A_Unit22__O(); A_arbace_math__init_A_Unit23__O(); A_arbace_math__init_A_Unit24__O(); A_arbace_math__init_A_Unit25__O(); A_arbace_math__init_A_Unit26__O(); A_arbace_math__init_A_Unit27__O(); A_arbace_math__init_A_Unit28__O(); A_arbace_math__init_A_Unit29__O(); A_arbace_math__init_A_Unit30__O(); A_arbace_math__init_A_Unit31__O(); A_arbace_math__init_A_Unit32__O(); A_arbace_math__init_A_Unit33__O(); A_arbace_math__init_A_Unit34__O(); A_arbace_math__init_A_Unit35__O(); A_arbace_math__init_A_Unit36__O(); A_arbace_math__init_A_Unit37__O(); A_arbace_math__init_A_Unit38__O(); A_arbace_math__init_A_Unit39__O(); A_arbace_math__init_A_Unit40__O(); A_arbace_math__init_A_Unit41__O(); A_arbace_math__init_A_Unit42__O(); A_arbace_math__init_A_Unit43__O(); A_arbace_math__init_A_Unit44__O(); A_arbace_math__init_A_Unit45__O(); A_arbace_math__init_A_Unit46__O(); A_arbace_math__init_A_Unit47__O(); A_arbace_math__init_A_Unit48__O(); A_arbace_math__init_A_Unit49__O(); return nil }



func A_arbace_math__init_A_Unit0__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_math__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_math__init_A_const_1) }
//line :9:1
func A_arbace_math__init_A_Unit1__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_math__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_2)) }
//line :9:1
func A_arbace_math__init_A_Unit2__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :9:1
func A_arbace_math__init_A_Unit3__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_math__init_A_const_1)).Equals_O__Z(A_arbace_math__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_math_eval446000008_fn__446000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_math_eval446000008_fn__446000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_math_eval446000008_fn__446000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }












func A_arbace_math__init_A_Unit4__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); return A_arbace_math__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_math__init_A_Unit5__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_5; tmp1.BindRoot_O__V(jrt.Double_ValueOf_D__Double_NoInit(2.718281828459045).Ref()); var tmp2 *lang.Var = A_arbace_math__init_A_const_5; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_6)); return A_arbace_math__init_A_const_5 }








func A_arbace_math__init_A_Unit6__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_7; tmp1.BindRoot_O__V(jrt.Double_ValueOf_D__Double_NoInit(3.141592653589793).Ref()); var tmp2 *lang.Var = A_arbace_math__init_A_const_7; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_math__init_A_const_8)); return A_arbace_math__init_A_const_7 }








func A_arbace_math__init_A_Unit7__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_math_sin_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_math_sin_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_math_sin_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_9; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_11; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_14; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_math_sin__inliner__446000014_A_New(); var tmp12 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_math_sin__inliner__446000014_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_math_sin__inliner__446000014_A_fn_class = fncls__7d; tmp12 = fncls__7d } else { tmp12 = fncls__7 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_5, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_18, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_9 }










func A_arbace_math__init_A_Unit8__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_math_cos_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_math_cos_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_math_cos_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_22; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_23; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_24; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_math_cos__inliner__446000017_A_New(); var tmp12 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_math_cos__inliner__446000017_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); A_arbace_math_cos__inliner__446000017_A_fn_class = fncls__11d; tmp12 = fncls__11d } else { tmp12 = fncls__11 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_10, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_25, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_22 }









func A_arbace_math__init_A_Unit9__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_math_tan_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_math_tan_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_math_tan_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_26; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_27; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_28; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_math_tan__inliner__446000020_A_New(); var tmp12 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_math_tan__inliner__446000020_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); A_arbace_math_tan__inliner__446000020_A_fn_class = fncls__15d; tmp12 = fncls__15d } else { tmp12 = fncls__15 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_13, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_29, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_26 }










func A_arbace_math__init_A_Unit10__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_math_asin_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_math_asin_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_math_asin_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_30; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_31; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_32; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_math_asin__inliner__446000023_A_New(); var tmp12 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_math_asin__inliner__446000023_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_math_asin__inliner__446000023_A_fn_class = fncls__19d; tmp12 = fncls__19d } else { tmp12 = fncls__19 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_16, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_33, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_30 }










func A_arbace_math__init_A_Unit11__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_math_acos_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_math_acos_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_math_acos_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_34; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_35; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_36; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_math_acos__inliner__446000026_A_New(); var tmp12 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_math_acos__inliner__446000026_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_math_acos__inliner__446000026_A_fn_class = fncls__23d; tmp12 = fncls__23d } else { tmp12 = fncls__23 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_19, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_37, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_34 }









func A_arbace_math__init_A_Unit12__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_math_atan_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_math_atan_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_math_atan_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_38; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_39; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_40; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_math_atan__inliner__446000029_A_New(); var tmp12 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_math_atan__inliner__446000029_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_math_atan__inliner__446000029_A_fn_class = fncls__27d; tmp12 = fncls__27d } else { tmp12 = fncls__27 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_22, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_41, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_38 }










func A_arbace_math__init_A_Unit13__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_math_to_radians_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_math_to_radians_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_math_to_radians_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_42; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_43; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_44; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_math_to_radians__inliner__446000032_A_New(); var tmp12 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_math_to_radians__inliner__446000032_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_math_to_radians__inliner__446000032_A_fn_class = fncls__31d; tmp12 = fncls__31d } else { tmp12 = fncls__31 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_25, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_45, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_42 }








func A_arbace_math__init_A_Unit14__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_math_to_degrees_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_math_to_degrees_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_math_to_degrees_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_46; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_47; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_48; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_math_to_degrees__inliner__446000035_A_New(); var tmp12 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_math_to_degrees__inliner__446000035_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_math_to_degrees__inliner__446000035_A_fn_class = fncls__35d; tmp12 = fncls__35d } else { tmp12 = fncls__35 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_28, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_49, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_46 }








func A_arbace_math__init_A_Unit15__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_math_exp_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_math_exp_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_math_exp_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_50; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_51; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_52; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_math_exp__inliner__446000038_A_New(); var tmp12 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_math_exp__inliner__446000038_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_math_exp__inliner__446000038_A_fn_class = fncls__39d; tmp12 = fncls__39d } else { tmp12 = fncls__39 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_31, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_53, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_50 }











func A_arbace_math__init_A_Unit16__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(136, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_math_log_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_math_log_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_math_log_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_54; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_55; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_56; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_math_log__inliner__446000041_A_New(); var tmp12 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_math_log__inliner__446000041_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_math_log__inliner__446000041_A_fn_class = fncls__43d; tmp12 = fncls__43d } else { tmp12 = fncls__43 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_34, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_57, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_54 }











func A_arbace_math__init_A_Unit17__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_math_log10_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_math_log10_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_math_log10_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_58; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_59; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_60; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_math_log10__inliner__446000044_A_New(); var tmp12 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_math_log10__inliner__446000044_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_math_log10__inliner__446000044_A_fn_class = fncls__47d; tmp12 = fncls__47d } else { tmp12 = fncls__47 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_37, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_61, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_58 }











func A_arbace_math__init_A_Unit18__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_math_sqrt_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_math_sqrt_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_math_sqrt_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_62; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_63; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_64; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_math_sqrt__inliner__446000047_A_New(); var tmp12 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_math_sqrt__inliner__446000047_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_math_sqrt__inliner__446000047_A_fn_class = fncls__51d; tmp12 = fncls__51d } else { tmp12 = fncls__51 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_40, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_65, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_62 }











func A_arbace_math__init_A_Unit19__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_math_cbrt_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_math_cbrt_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_math_cbrt_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_66; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_67; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_68; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_math_cbrt__inliner__446000050_A_New(); var tmp12 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_math_cbrt__inliner__446000050_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_math_cbrt__inliner__446000050_A_fn_class = fncls__55d; tmp12 = fncls__55d } else { tmp12 = fncls__55 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_43, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_69, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_66 }











func A_arbace_math__init_A_Unit20__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_math_IEEE_remainder_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_math_IEEE_remainder_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, nil); A_arbace_math_IEEE_remainder_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_70; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_71; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_72; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_math_IEEE_remainder__inliner__446000053_A_New(); var tmp12 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class = fncls__59d; tmp12 = fncls__59d } else { tmp12 = fncls__59 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_46, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_73, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_70 }














func A_arbace_math__init_A_Unit21__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_math_ceil_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_math_ceil_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_math_ceil_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_74; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_75; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_76; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_math_ceil__inliner__446000056_A_New(); var tmp12 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_math_ceil__inliner__446000056_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_math_ceil__inliner__446000056_A_fn_class = fncls__63d; tmp12 = fncls__63d } else { tmp12 = fncls__63 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_49, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_77, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_74 }











func A_arbace_math__init_A_Unit22__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(211, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_math_floor_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_math_floor_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_math_floor_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_78; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_79; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_80; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_math_floor__inliner__446000059_A_New(); var tmp12 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_math_floor__inliner__446000059_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, nil); A_arbace_math_floor__inliner__446000059_A_fn_class = fncls__67d; tmp12 = fncls__67d } else { tmp12 = fncls__67 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_52, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_81, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_78 }










func A_arbace_math__init_A_Unit23__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_math_rint_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_math_rint_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_math_rint_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_82; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_83; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_84; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_math_rint__inliner__446000062_A_New(); var tmp12 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_math_rint__inliner__446000062_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_math_rint__inliner__446000062_A_fn_class = fncls__71d; tmp12 = fncls__71d } else { tmp12 = fncls__71 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_55, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_85, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_82 }










func A_arbace_math__init_A_Unit24__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_math_atan2_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_math_atan2_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_math_atan2_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_86; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_87; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_88; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_math_atan2__inliner__446000065_A_New(); var tmp12 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_math_atan2__inliner__446000065_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_math_atan2__inliner__446000065_A_fn_class = fncls__75d; tmp12 = fncls__75d } else { tmp12 = fncls__75 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_58, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_89, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_86 }










func A_arbace_math__init_A_Unit25__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_math_pow_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_math_pow_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); A_arbace_math_pow_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_90; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_91; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_92; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_math_pow__inliner__446000068_A_New(); var tmp12 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_math_pow__inliner__446000068_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_math_pow__inliner__446000068_A_fn_class = fncls__79d; tmp12 = fncls__79d } else { tmp12 = fncls__79 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_61, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_93, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_90 }









func A_arbace_math__init_A_Unit26__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_math_round_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_math_round_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_math_round_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_94; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_95; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_96; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_math_round__inliner__446000071_A_New(); var tmp12 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_math_round__inliner__446000071_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_math_round__inliner__446000071_A_fn_class = fncls__83d; tmp12 = fncls__83d } else { tmp12 = fncls__83 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_64, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_97, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_94 }












func A_arbace_math__init_A_Unit27__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_math_random_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_math_random_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_math_random_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_98; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_99; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_100; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_math_random__inliner__446000074_A_New(); var tmp12 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_math_random__inliner__446000074_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_math_random__inliner__446000074_A_fn_class = fncls__87d; tmp12 = fncls__87d } else { tmp12 = fncls__87 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_67, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_101, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_98 }









func A_arbace_math__init_A_Unit28__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_math_add_exact_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_math_add_exact_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_math_add_exact_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_102; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_103; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_104; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_math_add_exact__inliner__446000077_A_New(); var tmp12 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_math_add_exact__inliner__446000077_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_math_add_exact__inliner__446000077_A_fn_class = fncls__91d; tmp12 = fncls__91d } else { tmp12 = fncls__91 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_70, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_105, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_102 }








func A_arbace_math__init_A_Unit29__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_math_subtract_exact_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_math_subtract_exact_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_math_subtract_exact_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_106; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_107; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_108; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_math_subtract_exact__inliner__446000080_A_New(); var tmp12 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_math_subtract_exact__inliner__446000080_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_math_subtract_exact__inliner__446000080_A_fn_class = fncls__95d; tmp12 = fncls__95d } else { tmp12 = fncls__95 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_73, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_109, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_106 }








func A_arbace_math__init_A_Unit30__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_math_multiply_exact_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_math_multiply_exact_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_math_multiply_exact_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_110; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_111; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_112; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_math_multiply_exact__inliner__446000083_A_New(); var tmp12 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_math_multiply_exact__inliner__446000083_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, nil); A_arbace_math_multiply_exact__inliner__446000083_A_fn_class = fncls__99d; tmp12 = fncls__99d } else { tmp12 = fncls__99 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_76, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_113, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_110 }








func A_arbace_math__init_A_Unit31__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_math_increment_exact_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_math_increment_exact_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_math_increment_exact_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_114; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_115; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_116; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_math_increment_exact__inliner__446000086_A_New(); var tmp12 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_math_increment_exact__inliner__446000086_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); A_arbace_math_increment_exact__inliner__446000086_A_fn_class = fncls__103d; tmp12 = fncls__103d } else { tmp12 = fncls__103 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_79, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_117, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_114 }








func A_arbace_math__init_A_Unit32__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_math_decrement_exact_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_math_decrement_exact_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_math_decrement_exact_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_118; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_119; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_120; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_math_decrement_exact__inliner__446000089_A_New(); var tmp12 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_math_decrement_exact__inliner__446000089_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, nil); A_arbace_math_decrement_exact__inliner__446000089_A_fn_class = fncls__107d; tmp12 = fncls__107d } else { tmp12 = fncls__107 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_82, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_121, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_118 }








func A_arbace_math__init_A_Unit33__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_math_negate_exact_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_math_negate_exact_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_math_negate_exact_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_122; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_123; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_124; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_math_negate_exact__inliner__446000092_A_New(); var tmp12 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_math_negate_exact__inliner__446000092_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, nil); A_arbace_math_negate_exact__inliner__446000092_A_fn_class = fncls__111d; tmp12 = fncls__111d } else { tmp12 = fncls__111 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_85, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_125, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_122 }








func A_arbace_math__init_A_Unit34__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(331, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_math_floor_div_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_math_floor_div_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_math_floor_div_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_126; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_127; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_128; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_math_floor_div__inliner__446000095_A_New(); var tmp12 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_math_floor_div__inliner__446000095_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_math_floor_div__inliner__446000095_A_fn_class = fncls__115d; tmp12 = fncls__115d } else { tmp12 = fncls__115 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_88, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_129, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_126 }









func A_arbace_math__init_A_Unit35__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(341, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_math_floor_mod_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_math_floor_mod_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_math_floor_mod_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_130; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_131; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_132; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_math_floor_mod__inliner__446000098_A_New(); var tmp12 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_math_floor_mod__inliner__446000098_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_math_floor_mod__inliner__446000098_A_fn_class = fncls__119d; tmp12 = fncls__119d } else { tmp12 = fncls__119 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_91, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_133, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_130 }









func A_arbace_math__init_A_Unit36__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_math_ulp_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_math_ulp_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, nil); A_arbace_math_ulp_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_134; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_135; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_136; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_math_ulp__inliner__446000101_A_New(); var tmp12 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_math_ulp__inliner__446000101_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, nil); A_arbace_math_ulp__inliner__446000101_A_fn_class = fncls__123d; tmp12 = fncls__123d } else { tmp12 = fncls__123 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_94, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_137, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_134 }












func A_arbace_math__init_A_Unit37__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(364, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_math_signum_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_math_signum_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, nil); A_arbace_math_signum_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_138; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_139; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_140; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_math_signum__inliner__446000104_A_New(); var tmp12 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_math_signum__inliner__446000104_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_math_signum__inliner__446000104_A_fn_class = fncls__127d; tmp12 = fncls__127d } else { tmp12 = fncls__127 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_97, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_141, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_138 }









func A_arbace_math__init_A_Unit38__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(374, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_math_sinh_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_math_sinh_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_math_sinh_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_142; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_143; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_144; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_math_sinh__inliner__446000107_A_New(); var tmp12 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_math_sinh__inliner__446000107_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, nil); A_arbace_math_sinh__inliner__446000107_A_fn_class = fncls__131d; tmp12 = fncls__131d } else { tmp12 = fncls__131 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_100, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_145, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_142 }










func A_arbace_math__init_A_Unit39__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(385, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_math_cosh_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_math_cosh_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_math_cosh_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_146; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_147; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_148; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_math_cosh__inliner__446000110_A_New(); var tmp12 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_math_cosh__inliner__446000110_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, nil); A_arbace_math_cosh__inliner__446000110_A_fn_class = fncls__135d; tmp12 = fncls__135d } else { tmp12 = fncls__135 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_103, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_149, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_146 }











func A_arbace_math__init_A_Unit40__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(397, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_math_tanh_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_math_tanh_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_math_tanh_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_150; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_151; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_152; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_math_tanh__inliner__446000113_A_New(); var tmp12 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_math_tanh__inliner__446000113_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, nil); A_arbace_math_tanh__inliner__446000113_A_fn_class = fncls__139d; tmp12 = fncls__139d } else { tmp12 = fncls__139 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_106, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_153, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_150 }












func A_arbace_math__init_A_Unit41__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(410, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_math_hypot_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_math_hypot_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, nil); A_arbace_math_hypot_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_154; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_155; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_156; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_math_hypot__inliner__446000116_A_New(); var tmp12 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_math_hypot__inliner__446000116_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, nil); A_arbace_math_hypot__inliner__446000116_A_fn_class = fncls__143d; tmp12 = fncls__143d } else { tmp12 = fncls__143 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_109, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_157, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_154 }










func A_arbace_math__init_A_Unit42__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(421, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_math_expm1_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_math_expm1_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, nil); A_arbace_math_expm1_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_158; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_159; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_160; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_math_expm1__inliner__446000119_A_New(); var tmp12 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_math_expm1__inliner__446000119_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_math_expm1__inliner__446000119_A_fn_class = fncls__147d; tmp12 = fncls__147d } else { tmp12 = fncls__147 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_112, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_161, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_158 }












func A_arbace_math__init_A_Unit43__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_math_log1p_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_math_log1p_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); A_arbace_math_log1p_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_162; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_163; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_164; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_math_log1p__inliner__446000122_A_New(); var tmp12 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_math_log1p__inliner__446000122_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, nil); A_arbace_math_log1p__inliner__446000122_A_fn_class = fncls__151d; tmp12 = fncls__151d } else { tmp12 = fncls__151 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_115, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_165, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_162 }













func A_arbace_math__init_A_Unit44__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(448, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_math_copy_sign_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_math_copy_sign_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_math_copy_sign_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_166; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_167; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_168; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_math_copy_sign__inliner__446000125_A_New(); var tmp12 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_math_copy_sign__inliner__446000125_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, nil); A_arbace_math_copy_sign__inliner__446000125_A_fn_class = fncls__155d; tmp12 = fncls__155d } else { tmp12 = fncls__155 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_118, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_169, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_166 }









func A_arbace_math__init_A_Unit45__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(458, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__158 any = A_arbace_math_get_exponent_A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_math_get_exponent_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_math_get_exponent_A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_170; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_171; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_172; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_math_get_exponent__inliner__446000128_A_New(); var tmp12 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_math_get_exponent__inliner__446000128_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_math_get_exponent__inliner__446000128_A_fn_class = fncls__159d; tmp12 = fncls__159d } else { tmp12 = fncls__159 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_121, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_173, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_170 }










func A_arbace_math__init_A_Unit46__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(469, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_math_next_after_A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_math_next_after_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, nil); A_arbace_math_next_after_A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_174; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_175; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_176; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_math_next_after__inliner__446000131_A_New(); var tmp12 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_math_next_after__inliner__446000131_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, nil); A_arbace_math_next_after__inliner__446000131_A_fn_class = fncls__163d; tmp12 = fncls__163d } else { tmp12 = fncls__163 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_124, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_177, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_174 }

















func A_arbace_math__init_A_Unit47__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(487, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_math_next_up_A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_math_next_up_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_math_next_up_A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_178; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_179; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_180; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_math_next_up__inliner__446000134_A_New(); var tmp12 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_math_next_up__inliner__446000134_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_math_next_up__inliner__446000134_A_fn_class = fncls__167d; tmp12 = fncls__167d } else { tmp12 = fncls__167 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_127, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_181, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_178 }











func A_arbace_math__init_A_Unit48__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(499, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__170 any = A_arbace_math_next_down_A_New(); var tmp3 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_math_next_down_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_math_next_down_A_fn_class = fncls__169d; tmp3 = fncls__169d } else { tmp3 = fncls__169 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_182; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_183; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_184; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__172 any = A_arbace_math_next_down__inliner__446000137_A_New(); var tmp12 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_math_next_down__inliner__446000137_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_math_next_down__inliner__446000137_A_fn_class = fncls__171d; tmp12 = fncls__171d } else { tmp12 = fncls__171 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_130, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_185, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_182 }











func A_arbace_math__init_A_Unit49__O() any { A_arbace_math__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(511, 1); var tmp1 *lang.Var = A_arbace_math__init_A_const_186; var tmp2 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_math_scalb_A_New(); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_math_scalb_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_math_scalb_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_math__init_A_const_186; var tmp5 any = A_arbace_math__init_A_const_10; var tmp6 any = A_arbace_math__init_A_const_187; var tmp7 any = A_arbace_math__init_A_const_12; var tmp8 any = A_arbace_math__init_A_const_13; var tmp9 any = A_arbace_math__init_A_const_188; var tmp10 any = A_arbace_math__init_A_const_15; var tmp11 *lang.Compiler_AOTFn; var fnbody__176 any = A_arbace_math_scalb__inliner__446000140_A_New(); var tmp12 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_math_scalb__inliner__446000140_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, nil); A_arbace_math_scalb__inliner__446000140_A_fn_class = fncls__175d; tmp12 = fncls__175d } else { tmp12 = fncls__175 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__176, tmp12, nil); tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_133, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_math__init_A_const_16, Lit_7, A_arbace_math__init_A_const_17, A_arbace_math__init_A_const_189, A_arbace_math__init_A_const_19, A_arbace_math__init_A_const_20, A_arbace_math__init_A_const_21, Lit_8))); return A_arbace_math__init_A_const_186 }



type A_arbace_math__init_A struct{ jrt.Object }

var A_arbace_math__init_A_const_pool *jrt.RefArray

var A_arbace_math__init_A_const_0 *lang.Var

var A_arbace_math__init_A_const_1 any

var A_arbace_math__init_A_const_2 any

var A_arbace_math__init_A_const_3 any

var A_arbace_math__init_A_const_4 *lang.Var

var A_arbace_math__init_A_const_5 *lang.Var

var A_arbace_math__init_A_const_6 any

var A_arbace_math__init_A_const_7 *lang.Var

var A_arbace_math__init_A_const_8 any

var A_arbace_math__init_A_const_9 *lang.Var

var A_arbace_math__init_A_const_10 *lang.Keyword

var A_arbace_math__init_A_const_11 any

var A_arbace_math__init_A_const_12 *lang.Keyword

var A_arbace_math__init_A_const_13 *lang.Keyword

var A_arbace_math__init_A_const_14 any

var A_arbace_math__init_A_const_15 *lang.Keyword

var A_arbace_math__init_A_const_16 *lang.Keyword

var A_arbace_math__init_A_const_17 *lang.Keyword

var A_arbace_math__init_A_const_18 any

var A_arbace_math__init_A_const_19 *lang.Keyword

var A_arbace_math__init_A_const_20 any

var A_arbace_math__init_A_const_21 *lang.Keyword

var A_arbace_math__init_A_const_22 *lang.Var

var A_arbace_math__init_A_const_23 any

var A_arbace_math__init_A_const_24 any

var A_arbace_math__init_A_const_25 any

var A_arbace_math__init_A_const_26 *lang.Var

var A_arbace_math__init_A_const_27 any

var A_arbace_math__init_A_const_28 any

var A_arbace_math__init_A_const_29 any

var A_arbace_math__init_A_const_30 *lang.Var

var A_arbace_math__init_A_const_31 any

var A_arbace_math__init_A_const_32 any

var A_arbace_math__init_A_const_33 any

var A_arbace_math__init_A_const_34 *lang.Var

var A_arbace_math__init_A_const_35 any

var A_arbace_math__init_A_const_36 any

var A_arbace_math__init_A_const_37 any

var A_arbace_math__init_A_const_38 *lang.Var

var A_arbace_math__init_A_const_39 any

var A_arbace_math__init_A_const_40 any

var A_arbace_math__init_A_const_41 any

var A_arbace_math__init_A_const_42 *lang.Var

var A_arbace_math__init_A_const_43 any

var A_arbace_math__init_A_const_44 any

var A_arbace_math__init_A_const_45 any

var A_arbace_math__init_A_const_46 *lang.Var

var A_arbace_math__init_A_const_47 any

var A_arbace_math__init_A_const_48 any

var A_arbace_math__init_A_const_49 any

var A_arbace_math__init_A_const_50 *lang.Var

var A_arbace_math__init_A_const_51 any

var A_arbace_math__init_A_const_52 any

var A_arbace_math__init_A_const_53 any

var A_arbace_math__init_A_const_54 *lang.Var

var A_arbace_math__init_A_const_55 any

var A_arbace_math__init_A_const_56 any

var A_arbace_math__init_A_const_57 any

var A_arbace_math__init_A_const_58 *lang.Var

var A_arbace_math__init_A_const_59 any

var A_arbace_math__init_A_const_60 any

var A_arbace_math__init_A_const_61 any

var A_arbace_math__init_A_const_62 *lang.Var

var A_arbace_math__init_A_const_63 any

var A_arbace_math__init_A_const_64 any

var A_arbace_math__init_A_const_65 any

var A_arbace_math__init_A_const_66 *lang.Var

var A_arbace_math__init_A_const_67 any

var A_arbace_math__init_A_const_68 any

var A_arbace_math__init_A_const_69 any

var A_arbace_math__init_A_const_70 *lang.Var

var A_arbace_math__init_A_const_71 any

var A_arbace_math__init_A_const_72 any

var A_arbace_math__init_A_const_73 any

var A_arbace_math__init_A_const_74 *lang.Var

var A_arbace_math__init_A_const_75 any

var A_arbace_math__init_A_const_76 any

var A_arbace_math__init_A_const_77 any

var A_arbace_math__init_A_const_78 *lang.Var

var A_arbace_math__init_A_const_79 any

var A_arbace_math__init_A_const_80 any

var A_arbace_math__init_A_const_81 any

var A_arbace_math__init_A_const_82 *lang.Var

var A_arbace_math__init_A_const_83 any

var A_arbace_math__init_A_const_84 any

var A_arbace_math__init_A_const_85 any

var A_arbace_math__init_A_const_86 *lang.Var

var A_arbace_math__init_A_const_87 any

var A_arbace_math__init_A_const_88 any

var A_arbace_math__init_A_const_89 any

var A_arbace_math__init_A_const_90 *lang.Var

var A_arbace_math__init_A_const_91 any

var A_arbace_math__init_A_const_92 any

var A_arbace_math__init_A_const_93 any

var A_arbace_math__init_A_const_94 *lang.Var

var A_arbace_math__init_A_const_95 any

var A_arbace_math__init_A_const_96 any

var A_arbace_math__init_A_const_97 any

var A_arbace_math__init_A_const_98 *lang.Var

var A_arbace_math__init_A_const_99 any

var A_arbace_math__init_A_const_100 any

var A_arbace_math__init_A_const_101 any

var A_arbace_math__init_A_const_102 *lang.Var

var A_arbace_math__init_A_const_103 any

var A_arbace_math__init_A_const_104 any

var A_arbace_math__init_A_const_105 any

var A_arbace_math__init_A_const_106 *lang.Var

var A_arbace_math__init_A_const_107 any

var A_arbace_math__init_A_const_108 any

var A_arbace_math__init_A_const_109 any

var A_arbace_math__init_A_const_110 *lang.Var

var A_arbace_math__init_A_const_111 any

var A_arbace_math__init_A_const_112 any

var A_arbace_math__init_A_const_113 any

var A_arbace_math__init_A_const_114 *lang.Var

var A_arbace_math__init_A_const_115 any

var A_arbace_math__init_A_const_116 any

var A_arbace_math__init_A_const_117 any

var A_arbace_math__init_A_const_118 *lang.Var

var A_arbace_math__init_A_const_119 any

var A_arbace_math__init_A_const_120 any

var A_arbace_math__init_A_const_121 any

var A_arbace_math__init_A_const_122 *lang.Var

var A_arbace_math__init_A_const_123 any

var A_arbace_math__init_A_const_124 any

var A_arbace_math__init_A_const_125 any

var A_arbace_math__init_A_const_126 *lang.Var

var A_arbace_math__init_A_const_127 any

var A_arbace_math__init_A_const_128 any

var A_arbace_math__init_A_const_129 any

var A_arbace_math__init_A_const_130 *lang.Var

var A_arbace_math__init_A_const_131 any

var A_arbace_math__init_A_const_132 any

var A_arbace_math__init_A_const_133 any

var A_arbace_math__init_A_const_134 *lang.Var

var A_arbace_math__init_A_const_135 any

var A_arbace_math__init_A_const_136 any

var A_arbace_math__init_A_const_137 any

var A_arbace_math__init_A_const_138 *lang.Var

var A_arbace_math__init_A_const_139 any

var A_arbace_math__init_A_const_140 any

var A_arbace_math__init_A_const_141 any

var A_arbace_math__init_A_const_142 *lang.Var

var A_arbace_math__init_A_const_143 any

var A_arbace_math__init_A_const_144 any

var A_arbace_math__init_A_const_145 any

var A_arbace_math__init_A_const_146 *lang.Var

var A_arbace_math__init_A_const_147 any

var A_arbace_math__init_A_const_148 any

var A_arbace_math__init_A_const_149 any

var A_arbace_math__init_A_const_150 *lang.Var

var A_arbace_math__init_A_const_151 any

var A_arbace_math__init_A_const_152 any

var A_arbace_math__init_A_const_153 any

var A_arbace_math__init_A_const_154 *lang.Var

var A_arbace_math__init_A_const_155 any

var A_arbace_math__init_A_const_156 any

var A_arbace_math__init_A_const_157 any

var A_arbace_math__init_A_const_158 *lang.Var

var A_arbace_math__init_A_const_159 any

var A_arbace_math__init_A_const_160 any

var A_arbace_math__init_A_const_161 any

var A_arbace_math__init_A_const_162 *lang.Var

var A_arbace_math__init_A_const_163 any

var A_arbace_math__init_A_const_164 any

var A_arbace_math__init_A_const_165 any

var A_arbace_math__init_A_const_166 *lang.Var

var A_arbace_math__init_A_const_167 any

var A_arbace_math__init_A_const_168 any

var A_arbace_math__init_A_const_169 any

var A_arbace_math__init_A_const_170 *lang.Var

var A_arbace_math__init_A_const_171 any

var A_arbace_math__init_A_const_172 any

var A_arbace_math__init_A_const_173 any

var A_arbace_math__init_A_const_174 *lang.Var

var A_arbace_math__init_A_const_175 any

var A_arbace_math__init_A_const_176 any

var A_arbace_math__init_A_const_177 any

var A_arbace_math__init_A_const_178 *lang.Var

var A_arbace_math__init_A_const_179 any

var A_arbace_math__init_A_const_180 any

var A_arbace_math__init_A_const_181 any

var A_arbace_math__init_A_const_182 *lang.Var

var A_arbace_math__init_A_const_183 any

var A_arbace_math__init_A_const_184 any

var A_arbace_math__init_A_const_185 any

var A_arbace_math__init_A_const_186 *lang.Var

var A_arbace_math__init_A_const_187 any

var A_arbace_math__init_A_const_188 any

var A_arbace_math__init_A_const_189 any

var A_arbace_math__init_A_init jrt.ClassInit

func A_arbace_math__init_A_Init() { if !A_arbace_math__init_A_init.Done() { A_arbace_math__init_A_init.Run(A_arbace_math__init_A_clinit) } }

func A_arbace_math__init_A_clinit() { A_arbace_math__init_A_clinit_p0(); A_arbace_math__init_A_clinit_p1(); A_arbace_math__init_A_clinit_p2(); A_arbace_math__init_A_clinit_p3(); A_arbace_math__init_A_clinit_p4(); A_arbace_math__init_A_clinit_p5(); A_arbace_math__init_A_clinit_p6(); A_arbace_math__init_A_clinit_p7(); A_arbace_math__init_A_clinit_p8(); A_arbace_math__init_A_clinit_p9(); A_arbace_math__init_A_clinit_p10(); A_arbace_math__init_A_clinit_p11(); A_arbace_math__init_A_clinit_p12(); A_arbace_math__init_A_clinit_p13() }

func A_arbace_math__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_math__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_1, 205); A_arbace_math__init_A_const_0 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[15]); A_arbace_math__init_A_const_1 = A_arbace_math__init_A_const_pool.A[16]; A_arbace_math__init_A_const_2 = A_arbace_math__init_A_const_pool.A[17]; A_arbace_math__init_A_const_3 = A_arbace_math__init_A_const_pool.A[18]; A_arbace_math__init_A_const_4 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[19]); A_arbace_math__init_A_const_5 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[20]); A_arbace_math__init_A_const_6 = A_arbace_math__init_A_const_pool.A[21]; A_arbace_math__init_A_const_7 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[22]); A_arbace_math__init_A_const_8 = A_arbace_math__init_A_const_pool.A[23]; A_arbace_math__init_A_const_9 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[24]); A_arbace_math__init_A_const_10 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[25]); A_arbace_math__init_A_const_11 = A_arbace_math__init_A_const_pool.A[26] }

func A_arbace_math__init_A_clinit_p1() { A_arbace_math__init_A_const_12 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[27]); A_arbace_math__init_A_const_13 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[28]); A_arbace_math__init_A_const_14 = A_arbace_math__init_A_const_pool.A[29]; A_arbace_math__init_A_const_15 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[30]); A_arbace_math__init_A_const_16 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[31]); A_arbace_math__init_A_const_17 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[32]); A_arbace_math__init_A_const_18 = A_arbace_math__init_A_const_pool.A[33]; A_arbace_math__init_A_const_19 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[34]); A_arbace_math__init_A_const_20 = A_arbace_math__init_A_const_pool.A[35]; A_arbace_math__init_A_const_21 = lang.Keyword_Cast(A_arbace_math__init_A_const_pool.A[36]); A_arbace_math__init_A_const_22 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[37]); A_arbace_math__init_A_const_23 = A_arbace_math__init_A_const_pool.A[38]; A_arbace_math__init_A_const_24 = A_arbace_math__init_A_const_pool.A[39] }

func A_arbace_math__init_A_clinit_p2() { A_arbace_math__init_A_const_25 = A_arbace_math__init_A_const_pool.A[40]; A_arbace_math__init_A_const_26 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[41]); A_arbace_math__init_A_const_27 = A_arbace_math__init_A_const_pool.A[42]; A_arbace_math__init_A_const_28 = A_arbace_math__init_A_const_pool.A[43]; A_arbace_math__init_A_const_29 = A_arbace_math__init_A_const_pool.A[44]; A_arbace_math__init_A_const_30 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[45]); A_arbace_math__init_A_const_31 = A_arbace_math__init_A_const_pool.A[46]; A_arbace_math__init_A_const_32 = A_arbace_math__init_A_const_pool.A[47]; A_arbace_math__init_A_const_33 = A_arbace_math__init_A_const_pool.A[48]; A_arbace_math__init_A_const_34 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[49]); A_arbace_math__init_A_const_35 = A_arbace_math__init_A_const_pool.A[50]; A_arbace_math__init_A_const_36 = A_arbace_math__init_A_const_pool.A[51]; A_arbace_math__init_A_const_37 = A_arbace_math__init_A_const_pool.A[52]; A_arbace_math__init_A_const_38 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[53]) }

func A_arbace_math__init_A_clinit_p3() { A_arbace_math__init_A_const_39 = A_arbace_math__init_A_const_pool.A[54]; A_arbace_math__init_A_const_40 = A_arbace_math__init_A_const_pool.A[55]; A_arbace_math__init_A_const_41 = A_arbace_math__init_A_const_pool.A[56]; A_arbace_math__init_A_const_42 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[57]); A_arbace_math__init_A_const_43 = A_arbace_math__init_A_const_pool.A[58]; A_arbace_math__init_A_const_44 = A_arbace_math__init_A_const_pool.A[59]; A_arbace_math__init_A_const_45 = A_arbace_math__init_A_const_pool.A[60]; A_arbace_math__init_A_const_46 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[61]); A_arbace_math__init_A_const_47 = A_arbace_math__init_A_const_pool.A[62]; A_arbace_math__init_A_const_48 = A_arbace_math__init_A_const_pool.A[63]; A_arbace_math__init_A_const_49 = A_arbace_math__init_A_const_pool.A[64]; A_arbace_math__init_A_const_50 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[65]); A_arbace_math__init_A_const_51 = A_arbace_math__init_A_const_pool.A[66]; A_arbace_math__init_A_const_52 = A_arbace_math__init_A_const_pool.A[67]; A_arbace_math__init_A_const_53 = A_arbace_math__init_A_const_pool.A[68] }

func A_arbace_math__init_A_clinit_p4() { A_arbace_math__init_A_const_54 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[69]); A_arbace_math__init_A_const_55 = A_arbace_math__init_A_const_pool.A[70]; A_arbace_math__init_A_const_56 = A_arbace_math__init_A_const_pool.A[71]; A_arbace_math__init_A_const_57 = A_arbace_math__init_A_const_pool.A[72]; A_arbace_math__init_A_const_58 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[73]); A_arbace_math__init_A_const_59 = A_arbace_math__init_A_const_pool.A[74]; A_arbace_math__init_A_const_60 = A_arbace_math__init_A_const_pool.A[75]; A_arbace_math__init_A_const_61 = A_arbace_math__init_A_const_pool.A[76]; A_arbace_math__init_A_const_62 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[77]); A_arbace_math__init_A_const_63 = A_arbace_math__init_A_const_pool.A[78]; A_arbace_math__init_A_const_64 = A_arbace_math__init_A_const_pool.A[79]; A_arbace_math__init_A_const_65 = A_arbace_math__init_A_const_pool.A[80]; A_arbace_math__init_A_const_66 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[81]); A_arbace_math__init_A_const_67 = A_arbace_math__init_A_const_pool.A[82] }

func A_arbace_math__init_A_clinit_p5() { A_arbace_math__init_A_const_68 = A_arbace_math__init_A_const_pool.A[83]; A_arbace_math__init_A_const_69 = A_arbace_math__init_A_const_pool.A[84]; A_arbace_math__init_A_const_70 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[85]); A_arbace_math__init_A_const_71 = A_arbace_math__init_A_const_pool.A[86]; A_arbace_math__init_A_const_72 = A_arbace_math__init_A_const_pool.A[87]; A_arbace_math__init_A_const_73 = A_arbace_math__init_A_const_pool.A[88]; A_arbace_math__init_A_const_74 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[89]); A_arbace_math__init_A_const_75 = A_arbace_math__init_A_const_pool.A[90]; A_arbace_math__init_A_const_76 = A_arbace_math__init_A_const_pool.A[91]; A_arbace_math__init_A_const_77 = A_arbace_math__init_A_const_pool.A[92]; A_arbace_math__init_A_const_78 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[93]); A_arbace_math__init_A_const_79 = A_arbace_math__init_A_const_pool.A[94]; A_arbace_math__init_A_const_80 = A_arbace_math__init_A_const_pool.A[95]; A_arbace_math__init_A_const_81 = A_arbace_math__init_A_const_pool.A[96] }

func A_arbace_math__init_A_clinit_p6() { A_arbace_math__init_A_const_82 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[97]); A_arbace_math__init_A_const_83 = A_arbace_math__init_A_const_pool.A[98]; A_arbace_math__init_A_const_84 = A_arbace_math__init_A_const_pool.A[99]; A_arbace_math__init_A_const_85 = A_arbace_math__init_A_const_pool.A[100]; A_arbace_math__init_A_const_86 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[101]); A_arbace_math__init_A_const_87 = A_arbace_math__init_A_const_pool.A[102]; A_arbace_math__init_A_const_88 = A_arbace_math__init_A_const_pool.A[103]; A_arbace_math__init_A_const_89 = A_arbace_math__init_A_const_pool.A[104]; A_arbace_math__init_A_const_90 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[105]); A_arbace_math__init_A_const_91 = A_arbace_math__init_A_const_pool.A[106]; A_arbace_math__init_A_const_92 = A_arbace_math__init_A_const_pool.A[107]; A_arbace_math__init_A_const_93 = A_arbace_math__init_A_const_pool.A[108]; A_arbace_math__init_A_const_94 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[109]); A_arbace_math__init_A_const_95 = A_arbace_math__init_A_const_pool.A[110] }

func A_arbace_math__init_A_clinit_p7() { A_arbace_math__init_A_const_96 = A_arbace_math__init_A_const_pool.A[111]; A_arbace_math__init_A_const_97 = A_arbace_math__init_A_const_pool.A[112]; A_arbace_math__init_A_const_98 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[113]); A_arbace_math__init_A_const_99 = A_arbace_math__init_A_const_pool.A[114]; A_arbace_math__init_A_const_100 = A_arbace_math__init_A_const_pool.A[115]; A_arbace_math__init_A_const_101 = A_arbace_math__init_A_const_pool.A[116]; A_arbace_math__init_A_const_102 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[117]); A_arbace_math__init_A_const_103 = A_arbace_math__init_A_const_pool.A[118]; A_arbace_math__init_A_const_104 = A_arbace_math__init_A_const_pool.A[119]; A_arbace_math__init_A_const_105 = A_arbace_math__init_A_const_pool.A[120]; A_arbace_math__init_A_const_106 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[121]); A_arbace_math__init_A_const_107 = A_arbace_math__init_A_const_pool.A[122]; A_arbace_math__init_A_const_108 = A_arbace_math__init_A_const_pool.A[123]; A_arbace_math__init_A_const_109 = A_arbace_math__init_A_const_pool.A[124] }

func A_arbace_math__init_A_clinit_p8() { A_arbace_math__init_A_const_110 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[125]); A_arbace_math__init_A_const_111 = A_arbace_math__init_A_const_pool.A[126]; A_arbace_math__init_A_const_112 = A_arbace_math__init_A_const_pool.A[127]; A_arbace_math__init_A_const_113 = A_arbace_math__init_A_const_pool.A[128]; A_arbace_math__init_A_const_114 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[129]); A_arbace_math__init_A_const_115 = A_arbace_math__init_A_const_pool.A[130]; A_arbace_math__init_A_const_116 = A_arbace_math__init_A_const_pool.A[131]; A_arbace_math__init_A_const_117 = A_arbace_math__init_A_const_pool.A[132]; A_arbace_math__init_A_const_118 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[133]); A_arbace_math__init_A_const_119 = A_arbace_math__init_A_const_pool.A[134]; A_arbace_math__init_A_const_120 = A_arbace_math__init_A_const_pool.A[135]; A_arbace_math__init_A_const_121 = A_arbace_math__init_A_const_pool.A[136]; A_arbace_math__init_A_const_122 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[137]); A_arbace_math__init_A_const_123 = A_arbace_math__init_A_const_pool.A[138] }

func A_arbace_math__init_A_clinit_p9() { A_arbace_math__init_A_const_124 = A_arbace_math__init_A_const_pool.A[139]; A_arbace_math__init_A_const_125 = A_arbace_math__init_A_const_pool.A[140]; A_arbace_math__init_A_const_126 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[141]); A_arbace_math__init_A_const_127 = A_arbace_math__init_A_const_pool.A[142]; A_arbace_math__init_A_const_128 = A_arbace_math__init_A_const_pool.A[143]; A_arbace_math__init_A_const_129 = A_arbace_math__init_A_const_pool.A[144]; A_arbace_math__init_A_const_130 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[145]); A_arbace_math__init_A_const_131 = A_arbace_math__init_A_const_pool.A[146]; A_arbace_math__init_A_const_132 = A_arbace_math__init_A_const_pool.A[147]; A_arbace_math__init_A_const_133 = A_arbace_math__init_A_const_pool.A[148]; A_arbace_math__init_A_const_134 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[149]); A_arbace_math__init_A_const_135 = A_arbace_math__init_A_const_pool.A[150]; A_arbace_math__init_A_const_136 = A_arbace_math__init_A_const_pool.A[151]; A_arbace_math__init_A_const_137 = A_arbace_math__init_A_const_pool.A[152] }

func A_arbace_math__init_A_clinit_p10() { A_arbace_math__init_A_const_138 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[153]); A_arbace_math__init_A_const_139 = A_arbace_math__init_A_const_pool.A[154]; A_arbace_math__init_A_const_140 = A_arbace_math__init_A_const_pool.A[155]; A_arbace_math__init_A_const_141 = A_arbace_math__init_A_const_pool.A[156]; A_arbace_math__init_A_const_142 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[157]); A_arbace_math__init_A_const_143 = A_arbace_math__init_A_const_pool.A[158]; A_arbace_math__init_A_const_144 = A_arbace_math__init_A_const_pool.A[159]; A_arbace_math__init_A_const_145 = A_arbace_math__init_A_const_pool.A[160]; A_arbace_math__init_A_const_146 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[161]); A_arbace_math__init_A_const_147 = A_arbace_math__init_A_const_pool.A[162]; A_arbace_math__init_A_const_148 = A_arbace_math__init_A_const_pool.A[163]; A_arbace_math__init_A_const_149 = A_arbace_math__init_A_const_pool.A[164]; A_arbace_math__init_A_const_150 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[165]); A_arbace_math__init_A_const_151 = A_arbace_math__init_A_const_pool.A[166] }

func A_arbace_math__init_A_clinit_p11() { A_arbace_math__init_A_const_152 = A_arbace_math__init_A_const_pool.A[167]; A_arbace_math__init_A_const_153 = A_arbace_math__init_A_const_pool.A[168]; A_arbace_math__init_A_const_154 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[169]); A_arbace_math__init_A_const_155 = A_arbace_math__init_A_const_pool.A[170]; A_arbace_math__init_A_const_156 = A_arbace_math__init_A_const_pool.A[171]; A_arbace_math__init_A_const_157 = A_arbace_math__init_A_const_pool.A[172]; A_arbace_math__init_A_const_158 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[173]); A_arbace_math__init_A_const_159 = A_arbace_math__init_A_const_pool.A[174]; A_arbace_math__init_A_const_160 = A_arbace_math__init_A_const_pool.A[175]; A_arbace_math__init_A_const_161 = A_arbace_math__init_A_const_pool.A[176]; A_arbace_math__init_A_const_162 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[177]); A_arbace_math__init_A_const_163 = A_arbace_math__init_A_const_pool.A[178]; A_arbace_math__init_A_const_164 = A_arbace_math__init_A_const_pool.A[179]; A_arbace_math__init_A_const_165 = A_arbace_math__init_A_const_pool.A[180] }

func A_arbace_math__init_A_clinit_p12() { A_arbace_math__init_A_const_166 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[181]); A_arbace_math__init_A_const_167 = A_arbace_math__init_A_const_pool.A[182]; A_arbace_math__init_A_const_168 = A_arbace_math__init_A_const_pool.A[183]; A_arbace_math__init_A_const_169 = A_arbace_math__init_A_const_pool.A[184]; A_arbace_math__init_A_const_170 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[185]); A_arbace_math__init_A_const_171 = A_arbace_math__init_A_const_pool.A[186]; A_arbace_math__init_A_const_172 = A_arbace_math__init_A_const_pool.A[187]; A_arbace_math__init_A_const_173 = A_arbace_math__init_A_const_pool.A[188]; A_arbace_math__init_A_const_174 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[189]); A_arbace_math__init_A_const_175 = A_arbace_math__init_A_const_pool.A[190]; A_arbace_math__init_A_const_176 = A_arbace_math__init_A_const_pool.A[191]; A_arbace_math__init_A_const_177 = A_arbace_math__init_A_const_pool.A[192]; A_arbace_math__init_A_const_178 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[193]); A_arbace_math__init_A_const_179 = A_arbace_math__init_A_const_pool.A[194] }

func A_arbace_math__init_A_clinit_p13() { A_arbace_math__init_A_const_180 = A_arbace_math__init_A_const_pool.A[195]; A_arbace_math__init_A_const_181 = A_arbace_math__init_A_const_pool.A[196]; A_arbace_math__init_A_const_182 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[197]); A_arbace_math__init_A_const_183 = A_arbace_math__init_A_const_pool.A[198]; A_arbace_math__init_A_const_184 = A_arbace_math__init_A_const_pool.A[199]; A_arbace_math__init_A_const_185 = A_arbace_math__init_A_const_pool.A[200]; A_arbace_math__init_A_const_186 = lang.Var_Cast(A_arbace_math__init_A_const_pool.A[201]); A_arbace_math__init_A_const_187 = A_arbace_math__init_A_const_pool.A[202]; A_arbace_math__init_A_const_188 = A_arbace_math__init_A_const_pool.A[203]; A_arbace_math__init_A_const_189 = A_arbace_math__init_A_const_pool.A[204] }

func A_arbace_math__init_A_New() *A_arbace_math__init_A { A_arbace_math__init_A_Init(); t := &A_arbace_math__init_A{}; t.Ctor(); return t }

func (t *A_arbace_math__init_A) Ctor() {}

func (t *A_arbace_math__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_math__init_A) GetClass__Class() *jrt.Class { return A_arbace_math__init_A_class }

func (t *A_arbace_math__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_math__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_math__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_math__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_math__init_A); return ok }

func A_arbace_math__init_A_Cast(x any) *A_arbace_math__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_math__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_math__init_A_class)) }; return v }
