//line j2g_classes.ae:1
package aot_arbace_math

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_math_IEEE_remainder_A_class, Name: "arbace.math$IEEE_remainder", Modifiers: 25, Simple: "IEEE_remainder", Go: "arbace/aot_arbace_math.A_arbace_math_IEEE_remainder_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_IEEE_remainder__inliner__446000053_A_class, Name: "arbace.math$IEEE_remainder__inliner__446000053", Modifiers: 25, Simple: "IEEE_remainder__inliner__446000053", Go: "arbace/aot_arbace_math.A_arbace_math_IEEE_remainder__inliner__446000053_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_acos_A_class, Name: "arbace.math$acos", Modifiers: 25, Simple: "acos", Go: "arbace/aot_arbace_math.A_arbace_math_acos_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_acos__inliner__446000026_A_class, Name: "arbace.math$acos__inliner__446000026", Modifiers: 25, Simple: "acos__inliner__446000026", Go: "arbace/aot_arbace_math.A_arbace_math_acos__inliner__446000026_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_add_exact_A_class, Name: "arbace.math$add_exact", Modifiers: 25, Simple: "add_exact", Go: "arbace/aot_arbace_math.A_arbace_math_add_exact_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_add_exact__inliner__446000077_A_class, Name: "arbace.math$add_exact__inliner__446000077", Modifiers: 25, Simple: "add_exact__inliner__446000077", Go: "arbace/aot_arbace_math.A_arbace_math_add_exact__inliner__446000077_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_asin_A_class, Name: "arbace.math$asin", Modifiers: 25, Simple: "asin", Go: "arbace/aot_arbace_math.A_arbace_math_asin_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_asin__inliner__446000023_A_class, Name: "arbace.math$asin__inliner__446000023", Modifiers: 25, Simple: "asin__inliner__446000023", Go: "arbace/aot_arbace_math.A_arbace_math_asin__inliner__446000023_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_atan_A_class, Name: "arbace.math$atan", Modifiers: 25, Simple: "atan", Go: "arbace/aot_arbace_math.A_arbace_math_atan_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_atan2_A_class, Name: "arbace.math$atan2", Modifiers: 25, Simple: "atan2", Go: "arbace/aot_arbace_math.A_arbace_math_atan2_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_atan2__inliner__446000065_A_class, Name: "arbace.math$atan2__inliner__446000065", Modifiers: 25, Simple: "atan2__inliner__446000065", Go: "arbace/aot_arbace_math.A_arbace_math_atan2__inliner__446000065_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_atan__inliner__446000029_A_class, Name: "arbace.math$atan__inliner__446000029", Modifiers: 25, Simple: "atan__inliner__446000029", Go: "arbace/aot_arbace_math.A_arbace_math_atan__inliner__446000029_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_cbrt_A_class, Name: "arbace.math$cbrt", Modifiers: 25, Simple: "cbrt", Go: "arbace/aot_arbace_math.A_arbace_math_cbrt_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_cbrt__inliner__446000050_A_class, Name: "arbace.math$cbrt__inliner__446000050", Modifiers: 25, Simple: "cbrt__inliner__446000050", Go: "arbace/aot_arbace_math.A_arbace_math_cbrt__inliner__446000050_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_ceil_A_class, Name: "arbace.math$ceil", Modifiers: 25, Simple: "ceil", Go: "arbace/aot_arbace_math.A_arbace_math_ceil_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_ceil__inliner__446000056_A_class, Name: "arbace.math$ceil__inliner__446000056", Modifiers: 25, Simple: "ceil__inliner__446000056", Go: "arbace/aot_arbace_math.A_arbace_math_ceil__inliner__446000056_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_copy_sign_A_class, Name: "arbace.math$copy_sign", Modifiers: 25, Simple: "copy_sign", Go: "arbace/aot_arbace_math.A_arbace_math_copy_sign_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_copy_sign__inliner__446000125_A_class, Name: "arbace.math$copy_sign__inliner__446000125", Modifiers: 25, Simple: "copy_sign__inliner__446000125", Go: "arbace/aot_arbace_math.A_arbace_math_copy_sign__inliner__446000125_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_cos_A_class, Name: "arbace.math$cos", Modifiers: 25, Simple: "cos", Go: "arbace/aot_arbace_math.A_arbace_math_cos_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_cos__inliner__446000017_A_class, Name: "arbace.math$cos__inliner__446000017", Modifiers: 25, Simple: "cos__inliner__446000017", Go: "arbace/aot_arbace_math.A_arbace_math_cos__inliner__446000017_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_cosh_A_class, Name: "arbace.math$cosh", Modifiers: 25, Simple: "cosh", Go: "arbace/aot_arbace_math.A_arbace_math_cosh_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_cosh__inliner__446000110_A_class, Name: "arbace.math$cosh__inliner__446000110", Modifiers: 25, Simple: "cosh__inliner__446000110", Go: "arbace/aot_arbace_math.A_arbace_math_cosh__inliner__446000110_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_decrement_exact_A_class, Name: "arbace.math$decrement_exact", Modifiers: 25, Simple: "decrement_exact", Go: "arbace/aot_arbace_math.A_arbace_math_decrement_exact_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_decrement_exact__inliner__446000089_A_class, Name: "arbace.math$decrement_exact__inliner__446000089", Modifiers: 25, Simple: "decrement_exact__inliner__446000089", Go: "arbace/aot_arbace_math.A_arbace_math_decrement_exact__inliner__446000089_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_class, Name: "arbace.math$eval446000004$loading__1927001464__auto____446000005", Modifiers: 25, Simple: "loading__1927001464__auto____446000005", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A", Source: "math.ae", Declaring: &A_arbace_math_eval446000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_math_eval446000008_fn__446000009_A_class, Name: "arbace.math$eval446000008$fn__446000009", Modifiers: 25, Simple: "fn__446000009", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000008_fn__446000009_A", Source: "math.ae", Declaring: &A_arbace_math_eval446000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_math_exp_A_class, Name: "arbace.math$exp", Modifiers: 25, Simple: "exp", Go: "arbace/aot_arbace_math.A_arbace_math_exp_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_exp__inliner__446000038_A_class, Name: "arbace.math$exp__inliner__446000038", Modifiers: 25, Simple: "exp__inliner__446000038", Go: "arbace/aot_arbace_math.A_arbace_math_exp__inliner__446000038_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_expm1_A_class, Name: "arbace.math$expm1", Modifiers: 25, Simple: "expm1", Go: "arbace/aot_arbace_math.A_arbace_math_expm1_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_expm1__inliner__446000119_A_class, Name: "arbace.math$expm1__inliner__446000119", Modifiers: 25, Simple: "expm1__inliner__446000119", Go: "arbace/aot_arbace_math.A_arbace_math_expm1__inliner__446000119_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_floor_A_class, Name: "arbace.math$floor", Modifiers: 25, Simple: "floor", Go: "arbace/aot_arbace_math.A_arbace_math_floor_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_floor__inliner__446000059_A_class, Name: "arbace.math$floor__inliner__446000059", Modifiers: 25, Simple: "floor__inliner__446000059", Go: "arbace/aot_arbace_math.A_arbace_math_floor__inliner__446000059_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_floor_div_A_class, Name: "arbace.math$floor_div", Modifiers: 25, Simple: "floor_div", Go: "arbace/aot_arbace_math.A_arbace_math_floor_div_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_floor_div__inliner__446000095_A_class, Name: "arbace.math$floor_div__inliner__446000095", Modifiers: 25, Simple: "floor_div__inliner__446000095", Go: "arbace/aot_arbace_math.A_arbace_math_floor_div__inliner__446000095_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_floor_mod_A_class, Name: "arbace.math$floor_mod", Modifiers: 25, Simple: "floor_mod", Go: "arbace/aot_arbace_math.A_arbace_math_floor_mod_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_floor_mod__inliner__446000098_A_class, Name: "arbace.math$floor_mod__inliner__446000098", Modifiers: 25, Simple: "floor_mod__inliner__446000098", Go: "arbace/aot_arbace_math.A_arbace_math_floor_mod__inliner__446000098_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_get_exponent_A_class, Name: "arbace.math$get_exponent", Modifiers: 25, Simple: "get_exponent", Go: "arbace/aot_arbace_math.A_arbace_math_get_exponent_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_get_exponent__inliner__446000128_A_class, Name: "arbace.math$get_exponent__inliner__446000128", Modifiers: 25, Simple: "get_exponent__inliner__446000128", Go: "arbace/aot_arbace_math.A_arbace_math_get_exponent__inliner__446000128_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_hypot_A_class, Name: "arbace.math$hypot", Modifiers: 25, Simple: "hypot", Go: "arbace/aot_arbace_math.A_arbace_math_hypot_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_hypot__inliner__446000116_A_class, Name: "arbace.math$hypot__inliner__446000116", Modifiers: 25, Simple: "hypot__inliner__446000116", Go: "arbace/aot_arbace_math.A_arbace_math_hypot__inliner__446000116_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_increment_exact_A_class, Name: "arbace.math$increment_exact", Modifiers: 25, Simple: "increment_exact", Go: "arbace/aot_arbace_math.A_arbace_math_increment_exact_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_increment_exact__inliner__446000086_A_class, Name: "arbace.math$increment_exact__inliner__446000086", Modifiers: 25, Simple: "increment_exact__inliner__446000086", Go: "arbace/aot_arbace_math.A_arbace_math_increment_exact__inliner__446000086_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_log_A_class, Name: "arbace.math$log", Modifiers: 25, Simple: "log", Go: "arbace/aot_arbace_math.A_arbace_math_log_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_log10_A_class, Name: "arbace.math$log10", Modifiers: 25, Simple: "log10", Go: "arbace/aot_arbace_math.A_arbace_math_log10_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_log10__inliner__446000044_A_class, Name: "arbace.math$log10__inliner__446000044", Modifiers: 25, Simple: "log10__inliner__446000044", Go: "arbace/aot_arbace_math.A_arbace_math_log10__inliner__446000044_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_log1p_A_class, Name: "arbace.math$log1p", Modifiers: 25, Simple: "log1p", Go: "arbace/aot_arbace_math.A_arbace_math_log1p_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_log1p__inliner__446000122_A_class, Name: "arbace.math$log1p__inliner__446000122", Modifiers: 25, Simple: "log1p__inliner__446000122", Go: "arbace/aot_arbace_math.A_arbace_math_log1p__inliner__446000122_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_log__inliner__446000041_A_class, Name: "arbace.math$log__inliner__446000041", Modifiers: 25, Simple: "log__inliner__446000041", Go: "arbace/aot_arbace_math.A_arbace_math_log__inliner__446000041_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_multiply_exact_A_class, Name: "arbace.math$multiply_exact", Modifiers: 25, Simple: "multiply_exact", Go: "arbace/aot_arbace_math.A_arbace_math_multiply_exact_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_multiply_exact__inliner__446000083_A_class, Name: "arbace.math$multiply_exact__inliner__446000083", Modifiers: 25, Simple: "multiply_exact__inliner__446000083", Go: "arbace/aot_arbace_math.A_arbace_math_multiply_exact__inliner__446000083_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_negate_exact_A_class, Name: "arbace.math$negate_exact", Modifiers: 25, Simple: "negate_exact", Go: "arbace/aot_arbace_math.A_arbace_math_negate_exact_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_negate_exact__inliner__446000092_A_class, Name: "arbace.math$negate_exact__inliner__446000092", Modifiers: 25, Simple: "negate_exact__inliner__446000092", Go: "arbace/aot_arbace_math.A_arbace_math_negate_exact__inliner__446000092_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_next_after_A_class, Name: "arbace.math$next_after", Modifiers: 25, Simple: "next_after", Go: "arbace/aot_arbace_math.A_arbace_math_next_after_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_next_after__inliner__446000131_A_class, Name: "arbace.math$next_after__inliner__446000131", Modifiers: 25, Simple: "next_after__inliner__446000131", Go: "arbace/aot_arbace_math.A_arbace_math_next_after__inliner__446000131_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_next_down_A_class, Name: "arbace.math$next_down", Modifiers: 25, Simple: "next_down", Go: "arbace/aot_arbace_math.A_arbace_math_next_down_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_next_down__inliner__446000137_A_class, Name: "arbace.math$next_down__inliner__446000137", Modifiers: 25, Simple: "next_down__inliner__446000137", Go: "arbace/aot_arbace_math.A_arbace_math_next_down__inliner__446000137_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_next_up_A_class, Name: "arbace.math$next_up", Modifiers: 25, Simple: "next_up", Go: "arbace/aot_arbace_math.A_arbace_math_next_up_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_next_up__inliner__446000134_A_class, Name: "arbace.math$next_up__inliner__446000134", Modifiers: 25, Simple: "next_up__inliner__446000134", Go: "arbace/aot_arbace_math.A_arbace_math_next_up__inliner__446000134_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_pow_A_class, Name: "arbace.math$pow", Modifiers: 25, Simple: "pow", Go: "arbace/aot_arbace_math.A_arbace_math_pow_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_pow__inliner__446000068_A_class, Name: "arbace.math$pow__inliner__446000068", Modifiers: 25, Simple: "pow__inliner__446000068", Go: "arbace/aot_arbace_math.A_arbace_math_pow__inliner__446000068_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_random_A_class, Name: "arbace.math$random", Modifiers: 25, Simple: "random", Go: "arbace/aot_arbace_math.A_arbace_math_random_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_math_random__inliner__446000074_A_class, Name: "arbace.math$random__inliner__446000074", Modifiers: 25, Simple: "random__inliner__446000074", Go: "arbace/aot_arbace_math.A_arbace_math_random__inliner__446000074_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_math_rint_A_class, Name: "arbace.math$rint", Modifiers: 25, Simple: "rint", Go: "arbace/aot_arbace_math.A_arbace_math_rint_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_rint__inliner__446000062_A_class, Name: "arbace.math$rint__inliner__446000062", Modifiers: 25, Simple: "rint__inliner__446000062", Go: "arbace/aot_arbace_math.A_arbace_math_rint__inliner__446000062_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_round_A_class, Name: "arbace.math$round", Modifiers: 25, Simple: "round", Go: "arbace/aot_arbace_math.A_arbace_math_round_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_round__inliner__446000071_A_class, Name: "arbace.math$round__inliner__446000071", Modifiers: 25, Simple: "round__inliner__446000071", Go: "arbace/aot_arbace_math.A_arbace_math_round__inliner__446000071_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_scalb_A_class, Name: "arbace.math$scalb", Modifiers: 25, Simple: "scalb", Go: "arbace/aot_arbace_math.A_arbace_math_scalb_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_scalb__inliner__446000140_A_class, Name: "arbace.math$scalb__inliner__446000140", Modifiers: 25, Simple: "scalb__inliner__446000140", Go: "arbace/aot_arbace_math.A_arbace_math_scalb__inliner__446000140_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_signum_A_class, Name: "arbace.math$signum", Modifiers: 25, Simple: "signum", Go: "arbace/aot_arbace_math.A_arbace_math_signum_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_signum__inliner__446000104_A_class, Name: "arbace.math$signum__inliner__446000104", Modifiers: 25, Simple: "signum__inliner__446000104", Go: "arbace/aot_arbace_math.A_arbace_math_signum__inliner__446000104_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_sin_A_class, Name: "arbace.math$sin", Modifiers: 25, Simple: "sin", Go: "arbace/aot_arbace_math.A_arbace_math_sin_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_sin__inliner__446000014_A_class, Name: "arbace.math$sin__inliner__446000014", Modifiers: 25, Simple: "sin__inliner__446000014", Go: "arbace/aot_arbace_math.A_arbace_math_sin__inliner__446000014_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_sinh_A_class, Name: "arbace.math$sinh", Modifiers: 25, Simple: "sinh", Go: "arbace/aot_arbace_math.A_arbace_math_sinh_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_sinh__inliner__446000107_A_class, Name: "arbace.math$sinh__inliner__446000107", Modifiers: 25, Simple: "sinh__inliner__446000107", Go: "arbace/aot_arbace_math.A_arbace_math_sinh__inliner__446000107_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_sqrt_A_class, Name: "arbace.math$sqrt", Modifiers: 25, Simple: "sqrt", Go: "arbace/aot_arbace_math.A_arbace_math_sqrt_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_sqrt__inliner__446000047_A_class, Name: "arbace.math$sqrt__inliner__446000047", Modifiers: 25, Simple: "sqrt__inliner__446000047", Go: "arbace/aot_arbace_math.A_arbace_math_sqrt__inliner__446000047_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_subtract_exact_A_class, Name: "arbace.math$subtract_exact", Modifiers: 25, Simple: "subtract_exact", Go: "arbace/aot_arbace_math.A_arbace_math_subtract_exact_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_subtract_exact__inliner__446000080_A_class, Name: "arbace.math$subtract_exact__inliner__446000080", Modifiers: 25, Simple: "subtract_exact__inliner__446000080", Go: "arbace/aot_arbace_math.A_arbace_math_subtract_exact__inliner__446000080_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_math_tan_A_class, Name: "arbace.math$tan", Modifiers: 25, Simple: "tan", Go: "arbace/aot_arbace_math.A_arbace_math_tan_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_tan__inliner__446000020_A_class, Name: "arbace.math$tan__inliner__446000020", Modifiers: 25, Simple: "tan__inliner__446000020", Go: "arbace/aot_arbace_math.A_arbace_math_tan__inliner__446000020_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_tanh_A_class, Name: "arbace.math$tanh", Modifiers: 25, Simple: "tanh", Go: "arbace/aot_arbace_math.A_arbace_math_tanh_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_tanh__inliner__446000113_A_class, Name: "arbace.math$tanh__inliner__446000113", Modifiers: 25, Simple: "tanh__inliner__446000113", Go: "arbace/aot_arbace_math.A_arbace_math_tanh__inliner__446000113_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_to_degrees_A_class, Name: "arbace.math$to_degrees", Modifiers: 25, Simple: "to_degrees", Go: "arbace/aot_arbace_math.A_arbace_math_to_degrees_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_to_degrees__inliner__446000035_A_class, Name: "arbace.math$to_degrees__inliner__446000035", Modifiers: 25, Simple: "to_degrees__inliner__446000035", Go: "arbace/aot_arbace_math.A_arbace_math_to_degrees__inliner__446000035_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_to_radians_A_class, Name: "arbace.math$to_radians", Modifiers: 25, Simple: "to_radians", Go: "arbace/aot_arbace_math.A_arbace_math_to_radians_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_to_radians__inliner__446000032_A_class, Name: "arbace.math$to_radians__inliner__446000032", Modifiers: 25, Simple: "to_radians__inliner__446000032", Go: "arbace/aot_arbace_math.A_arbace_math_to_radians__inliner__446000032_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_ulp_A_class, Name: "arbace.math$ulp", Modifiers: 25, Simple: "ulp", Go: "arbace/aot_arbace_math.A_arbace_math_ulp_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_math_ulp__inliner__446000101_A_class, Name: "arbace.math$ulp__inliner__446000101", Modifiers: 25, Simple: "ulp__inliner__446000101", Go: "arbace/aot_arbace_math.A_arbace_math_ulp__inliner__446000101_A", Source: "math.ae", Declaring: &A_arbace_math_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_math_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_A_New()}; return nil }

var A_arbace_math_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_math_A_new}

var A_arbace_math_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_math.A_arbace_math_A"})

func init() { i := A_arbace_math_A_class.Info(); i.IsInstance = A_arbace_math_A_InstanceOf; i.Init = A_arbace_math_A_Init; i.Table = A_arbace_math_A_members }

var A_arbace_math_IEEE_remainder_A_class *jrt.Class

var A_arbace_math_IEEE_remainder__inliner__446000053_A_class *jrt.Class

var A_arbace_math_acos_A_class *jrt.Class

var A_arbace_math_acos__inliner__446000026_A_class *jrt.Class

var A_arbace_math_add_exact_A_class *jrt.Class

var A_arbace_math_add_exact__inliner__446000077_A_class *jrt.Class

var A_arbace_math_asin_A_class *jrt.Class

var A_arbace_math_asin__inliner__446000023_A_class *jrt.Class

var A_arbace_math_atan_A_class *jrt.Class

var A_arbace_math_atan2_A_class *jrt.Class

var A_arbace_math_atan2__inliner__446000065_A_class *jrt.Class

var A_arbace_math_atan__inliner__446000029_A_class *jrt.Class

var A_arbace_math_cbrt_A_class *jrt.Class

var A_arbace_math_cbrt__inliner__446000050_A_class *jrt.Class

var A_arbace_math_ceil_A_class *jrt.Class

var A_arbace_math_ceil__inliner__446000056_A_class *jrt.Class

var A_arbace_math_copy_sign_A_class *jrt.Class

var A_arbace_math_copy_sign__inliner__446000125_A_class *jrt.Class

var A_arbace_math_cos_A_class *jrt.Class

var A_arbace_math_cos__inliner__446000017_A_class *jrt.Class

var A_arbace_math_cosh_A_class *jrt.Class

var A_arbace_math_cosh__inliner__446000110_A_class *jrt.Class

var A_arbace_math_decrement_exact_A_class *jrt.Class

var A_arbace_math_decrement_exact__inliner__446000089_A_class *jrt.Class

func A_arbace_math_eval446000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_eval446000004_A_New()}; return nil }

var A_arbace_math_eval446000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_math_eval446000004_A_new}

var A_arbace_math_eval446000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$eval446000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_math_A_class, Simple: "eval446000004", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000004_A"})

func init() { i := A_arbace_math_eval446000004_A_class.Info(); i.IsInstance = A_arbace_math_eval446000004_A_InstanceOf; i.Table = A_arbace_math_eval446000004_A_members }

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_class *jrt.Class

func A_arbace_math_eval446000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_eval446000008_A_New()}; return nil }

var A_arbace_math_eval446000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_math_eval446000008_A_new}

var A_arbace_math_eval446000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$eval446000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_math_A_class, Simple: "eval446000008", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000008_A"})

func init() { i := A_arbace_math_eval446000008_A_class.Info(); i.IsInstance = A_arbace_math_eval446000008_A_InstanceOf; i.Table = A_arbace_math_eval446000008_A_members }

var A_arbace_math_eval446000008_fn__446000009_A_class *jrt.Class

var A_arbace_math_exp_A_class *jrt.Class

var A_arbace_math_exp__inliner__446000038_A_class *jrt.Class

var A_arbace_math_expm1_A_class *jrt.Class

var A_arbace_math_expm1__inliner__446000119_A_class *jrt.Class

var A_arbace_math_floor_A_class *jrt.Class

var A_arbace_math_floor__inliner__446000059_A_class *jrt.Class

var A_arbace_math_floor_div_A_class *jrt.Class

var A_arbace_math_floor_div__inliner__446000095_A_class *jrt.Class

var A_arbace_math_floor_mod_A_class *jrt.Class

var A_arbace_math_floor_mod__inliner__446000098_A_class *jrt.Class

var A_arbace_math_get_exponent_A_class *jrt.Class

var A_arbace_math_get_exponent__inliner__446000128_A_class *jrt.Class

var A_arbace_math_hypot_A_class *jrt.Class

var A_arbace_math_hypot__inliner__446000116_A_class *jrt.Class

var A_arbace_math_increment_exact_A_class *jrt.Class

var A_arbace_math_increment_exact__inliner__446000086_A_class *jrt.Class

var A_arbace_math_log_A_class *jrt.Class

var A_arbace_math_log10_A_class *jrt.Class

var A_arbace_math_log10__inliner__446000044_A_class *jrt.Class

var A_arbace_math_log1p_A_class *jrt.Class

var A_arbace_math_log1p__inliner__446000122_A_class *jrt.Class

var A_arbace_math_log__inliner__446000041_A_class *jrt.Class

var A_arbace_math_multiply_exact_A_class *jrt.Class

var A_arbace_math_multiply_exact__inliner__446000083_A_class *jrt.Class

var A_arbace_math_negate_exact_A_class *jrt.Class

var A_arbace_math_negate_exact__inliner__446000092_A_class *jrt.Class

var A_arbace_math_next_after_A_class *jrt.Class

var A_arbace_math_next_after__inliner__446000131_A_class *jrt.Class

var A_arbace_math_next_down_A_class *jrt.Class

var A_arbace_math_next_down__inliner__446000137_A_class *jrt.Class

var A_arbace_math_next_up_A_class *jrt.Class

var A_arbace_math_next_up__inliner__446000134_A_class *jrt.Class

var A_arbace_math_pow_A_class *jrt.Class

var A_arbace_math_pow__inliner__446000068_A_class *jrt.Class

var A_arbace_math_random_A_class *jrt.Class

var A_arbace_math_random__inliner__446000074_A_class *jrt.Class

var A_arbace_math_rint_A_class *jrt.Class

var A_arbace_math_rint__inliner__446000062_A_class *jrt.Class

var A_arbace_math_round_A_class *jrt.Class

var A_arbace_math_round__inliner__446000071_A_class *jrt.Class

var A_arbace_math_scalb_A_class *jrt.Class

var A_arbace_math_scalb__inliner__446000140_A_class *jrt.Class

var A_arbace_math_signum_A_class *jrt.Class

var A_arbace_math_signum__inliner__446000104_A_class *jrt.Class

var A_arbace_math_sin_A_class *jrt.Class

var A_arbace_math_sin__inliner__446000014_A_class *jrt.Class

var A_arbace_math_sinh_A_class *jrt.Class

var A_arbace_math_sinh__inliner__446000107_A_class *jrt.Class

var A_arbace_math_sqrt_A_class *jrt.Class

var A_arbace_math_sqrt__inliner__446000047_A_class *jrt.Class

var A_arbace_math_subtract_exact_A_class *jrt.Class

var A_arbace_math_subtract_exact__inliner__446000080_A_class *jrt.Class

var A_arbace_math_tan_A_class *jrt.Class

var A_arbace_math_tan__inliner__446000020_A_class *jrt.Class

var A_arbace_math_tanh_A_class *jrt.Class

var A_arbace_math_tanh__inliner__446000113_A_class *jrt.Class

var A_arbace_math_to_degrees_A_class *jrt.Class

var A_arbace_math_to_degrees__inliner__446000035_A_class *jrt.Class

var A_arbace_math_to_radians_A_class *jrt.Class

var A_arbace_math_to_radians__inliner__446000032_A_class *jrt.Class

var A_arbace_math_ulp_A_class *jrt.Class

var A_arbace_math_ulp__inliner__446000101_A_class *jrt.Class

func A_arbace_math__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_math__init_A_Load__O()}; return nil }

func A_arbace_math__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math__init_A_New()}; return nil }

var A_arbace_math__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_math__init_A_invoke, New: A_arbace_math__init_A_new}

var A_arbace_math__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_math.A_arbace_math__init_A", Source: "math.ae"})

func init() { i := A_arbace_math__init_A_class.Info(); i.IsInstance = A_arbace_math__init_A_InstanceOf; i.Init = A_arbace_math__init_A_Init; i.Table = A_arbace_math__init_A_members }
