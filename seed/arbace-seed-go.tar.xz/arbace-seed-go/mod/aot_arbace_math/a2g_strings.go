//line a2g_strings.ae:1
package aot_arbace_math

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.math")

var Lit_6 *jrt.String = jrt.Intern("author")

var Lit_7 *jrt.String = jrt.Intern("Alex Miller")

var Lit_8 *jrt.String = jrt.Intern("doc")

var Lit_9 *jrt.String = jrt.Intern("Clojure wrapper functions for java.lang.Math static methods.\n\n  Function calls are inlined for performance, and type hinted for primitive\n  long or double parameters where appropriate. In general, Math methods are\n  optimized for performance and have bounds for error tolerance. If\n  greater precision is needed, use java.lang.StrictMath directly instead.\n\n  For more complete information, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html")

var Lit_10 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_11 *jrt.String = jrt.Intern("seq")

var Lit_12 *jrt.String = jrt.Intern("concat")

var Lit_13 *jrt.String = jrt.Intern("list")

var Lit_14 *jrt.String = jrt.Intern("java.lang.Math")

var Lit_15 *jrt.String = jrt.Intern("sin")

var Lit_16 *jrt.String = jrt.Intern("double")

var Lit_17 *jrt.String = jrt.Intern("cos")

var Lit_18 *jrt.String = jrt.Intern("tan")

var Lit_19 *jrt.String = jrt.Intern("asin")

var Lit_20 *jrt.String = jrt.Intern("acos")

var Lit_21 *jrt.String = jrt.Intern("atan")

var Lit_22 *jrt.String = jrt.Intern("toRadians")

var Lit_23 *jrt.String = jrt.Intern("toDegrees")

var Lit_24 *jrt.String = jrt.Intern("exp")

var Lit_25 *jrt.String = jrt.Intern("log")

var Lit_26 *jrt.String = jrt.Intern("log10")

var Lit_27 *jrt.String = jrt.Intern("sqrt")

var Lit_28 *jrt.String = jrt.Intern("cbrt")

var Lit_29 *jrt.String = jrt.Intern("IEEEremainder")

var Lit_30 *jrt.String = jrt.Intern("ceil")

var Lit_31 *jrt.String = jrt.Intern("floor")

var Lit_32 *jrt.String = jrt.Intern("rint")

var Lit_33 *jrt.String = jrt.Intern("atan2")

var Lit_34 *jrt.String = jrt.Intern("pow")

var Lit_35 *jrt.String = jrt.Intern("round")

var Lit_36 *jrt.String = jrt.Intern("random")

var Lit_37 *jrt.String = jrt.Intern("addExact")

var Lit_38 *jrt.String = jrt.Intern("long")

var Lit_39 *jrt.String = jrt.Intern("subtractExact")

var Lit_40 *jrt.String = jrt.Intern("multiplyExact")

var Lit_41 *jrt.String = jrt.Intern("incrementExact")

var Lit_42 *jrt.String = jrt.Intern("decrementExact")

var Lit_43 *jrt.String = jrt.Intern("negateExact")

var Lit_44 *jrt.String = jrt.Intern("floorDiv")

var Lit_45 *jrt.String = jrt.Intern("floorMod")

var Lit_46 *jrt.String = jrt.Intern("ulp")

var Lit_47 *jrt.String = jrt.Intern("signum")

var Lit_48 *jrt.String = jrt.Intern("sinh")

var Lit_49 *jrt.String = jrt.Intern("cosh")

var Lit_50 *jrt.String = jrt.Intern("tanh")

var Lit_51 *jrt.String = jrt.Intern("hypot")

var Lit_52 *jrt.String = jrt.Intern("expm1")

var Lit_53 *jrt.String = jrt.Intern("log1p")

var Lit_54 *jrt.String = jrt.Intern("copySign")

var Lit_55 *jrt.String = jrt.Intern("getExponent")

var Lit_56 *jrt.String = jrt.Intern("nextAfter")

var Lit_57 *jrt.String = jrt.Intern("nextUp")

var Lit_58 *jrt.String = jrt.Intern("nextDown")

var Lit_59 *jrt.String = jrt.Intern("scalb")

var Lit_60 *jrt.String = jrt.Intern("int")

var Lit_61 *jrt.String = jrt.Intern("arbace.math$IEEE_remainder")

var Lit_62 *jrt.String = jrt.Intern("arbace.math$IEEE_remainder__inliner__446000053")

var Lit_63 *jrt.String = jrt.Intern("arbace.math$acos")

var Lit_64 *jrt.String = jrt.Intern("arbace.math$acos__inliner__446000026")

var Lit_65 *jrt.String = jrt.Intern("arbace.math$add_exact")

var Lit_66 *jrt.String = jrt.Intern("arbace.math$add_exact__inliner__446000077")

var Lit_67 *jrt.String = jrt.Intern("arbace.math$asin")

var Lit_68 *jrt.String = jrt.Intern("arbace.math$asin__inliner__446000023")

var Lit_69 *jrt.String = jrt.Intern("arbace.math$atan")

var Lit_70 *jrt.String = jrt.Intern("arbace.math$atan2")

var Lit_71 *jrt.String = jrt.Intern("arbace.math$atan2__inliner__446000065")

var Lit_72 *jrt.String = jrt.Intern("arbace.math$atan__inliner__446000029")

var Lit_73 *jrt.String = jrt.Intern("arbace.math$cbrt")

var Lit_74 *jrt.String = jrt.Intern("arbace.math$cbrt__inliner__446000050")

var Lit_75 *jrt.String = jrt.Intern("arbace.math$ceil")

var Lit_76 *jrt.String = jrt.Intern("arbace.math$ceil__inliner__446000056")

var Lit_77 *jrt.String = jrt.Intern("arbace.math$copy_sign")

var Lit_78 *jrt.String = jrt.Intern("arbace.math$copy_sign__inliner__446000125")

var Lit_79 *jrt.String = jrt.Intern("arbace.math$cos")

var Lit_80 *jrt.String = jrt.Intern("arbace.math$cos__inliner__446000017")

var Lit_81 *jrt.String = jrt.Intern("arbace.math$cosh")

var Lit_82 *jrt.String = jrt.Intern("arbace.math$cosh__inliner__446000110")

var Lit_83 *jrt.String = jrt.Intern("arbace.math$decrement_exact")

var Lit_84 *jrt.String = jrt.Intern("arbace.math$decrement_exact__inliner__446000089")

var Lit_85 *jrt.String = jrt.Intern("arbace.math$eval446000004$loading__1927001464__auto____446000005")

var Lit_86 *jrt.String = jrt.Intern("arbace.math$eval446000008$fn__446000009")

var Lit_87 *jrt.String = jrt.Intern("arbace.math$exp")

var Lit_88 *jrt.String = jrt.Intern("arbace.math$exp__inliner__446000038")

var Lit_89 *jrt.String = jrt.Intern("arbace.math$expm1")

var Lit_90 *jrt.String = jrt.Intern("arbace.math$expm1__inliner__446000119")

var Lit_91 *jrt.String = jrt.Intern("arbace.math$floor")

var Lit_92 *jrt.String = jrt.Intern("arbace.math$floor__inliner__446000059")

var Lit_93 *jrt.String = jrt.Intern("arbace.math$floor_div")

var Lit_94 *jrt.String = jrt.Intern("arbace.math$floor_div__inliner__446000095")

var Lit_95 *jrt.String = jrt.Intern("arbace.math$floor_mod")

var Lit_96 *jrt.String = jrt.Intern("arbace.math$floor_mod__inliner__446000098")

var Lit_97 *jrt.String = jrt.Intern("arbace.math$get_exponent")

var Lit_98 *jrt.String = jrt.Intern("arbace.math$get_exponent__inliner__446000128")

var Lit_99 *jrt.String = jrt.Intern("arbace.math$hypot")

var Lit_100 *jrt.String = jrt.Intern("arbace.math$hypot__inliner__446000116")

var Lit_101 *jrt.String = jrt.Intern("arbace.math$increment_exact")

var Lit_102 *jrt.String = jrt.Intern("arbace.math$increment_exact__inliner__446000086")

var Lit_103 *jrt.String = jrt.Intern("arbace.math$log")

var Lit_104 *jrt.String = jrt.Intern("arbace.math$log10")

var Lit_105 *jrt.String = jrt.Intern("arbace.math$log10__inliner__446000044")

var Lit_106 *jrt.String = jrt.Intern("arbace.math$log1p")

var Lit_107 *jrt.String = jrt.Intern("arbace.math$log1p__inliner__446000122")

var Lit_108 *jrt.String = jrt.Intern("arbace.math$log__inliner__446000041")

var Lit_109 *jrt.String = jrt.Intern("arbace.math$multiply_exact")

var Lit_110 *jrt.String = jrt.Intern("arbace.math$multiply_exact__inliner__446000083")

var Lit_111 *jrt.String = jrt.Intern("arbace.math$negate_exact")

var Lit_112 *jrt.String = jrt.Intern("arbace.math$negate_exact__inliner__446000092")

var Lit_113 *jrt.String = jrt.Intern("arbace.math$next_after")

var Lit_114 *jrt.String = jrt.Intern("arbace.math$next_after__inliner__446000131")

var Lit_115 *jrt.String = jrt.Intern("arbace.math$next_down")

var Lit_116 *jrt.String = jrt.Intern("arbace.math$next_down__inliner__446000137")

var Lit_117 *jrt.String = jrt.Intern("arbace.math$next_up")

var Lit_118 *jrt.String = jrt.Intern("arbace.math$next_up__inliner__446000134")

var Lit_119 *jrt.String = jrt.Intern("arbace.math$pow")

var Lit_120 *jrt.String = jrt.Intern("arbace.math$pow__inliner__446000068")

var Lit_121 *jrt.String = jrt.Intern("arbace.math$random")

var Lit_122 *jrt.String = jrt.Intern("arbace.math$random__inliner__446000074")

var Lit_123 *jrt.String = jrt.Intern("arbace.math$rint")

var Lit_124 *jrt.String = jrt.Intern("arbace.math$rint__inliner__446000062")

var Lit_125 *jrt.String = jrt.Intern("arbace.math$round")

var Lit_126 *jrt.String = jrt.Intern("arbace.math$round__inliner__446000071")

var Lit_127 *jrt.String = jrt.Intern("arbace.math$scalb")

var Lit_128 *jrt.String = jrt.Intern("arbace.math$scalb__inliner__446000140")

var Lit_129 *jrt.String = jrt.Intern("arbace.math$signum")

var Lit_130 *jrt.String = jrt.Intern("arbace.math$signum__inliner__446000104")

var Lit_131 *jrt.String = jrt.Intern("arbace.math$sin")

var Lit_132 *jrt.String = jrt.Intern("arbace.math$sin__inliner__446000014")

var Lit_133 *jrt.String = jrt.Intern("arbace.math$sinh")

var Lit_134 *jrt.String = jrt.Intern("arbace.math$sinh__inliner__446000107")

var Lit_135 *jrt.String = jrt.Intern("arbace.math$sqrt")

var Lit_136 *jrt.String = jrt.Intern("arbace.math$sqrt__inliner__446000047")

var Lit_137 *jrt.String = jrt.Intern("arbace.math$subtract_exact")

var Lit_138 *jrt.String = jrt.Intern("arbace.math$subtract_exact__inliner__446000080")

var Lit_139 *jrt.String = jrt.Intern("arbace.math$tan")

var Lit_140 *jrt.String = jrt.Intern("arbace.math$tan__inliner__446000020")

var Lit_141 *jrt.String = jrt.Intern("arbace.math$tanh")

var Lit_142 *jrt.String = jrt.Intern("arbace.math$tanh__inliner__446000113")

var Lit_143 *jrt.String = jrt.Intern("arbace.math$to_degrees")

var Lit_144 *jrt.String = jrt.Intern("arbace.math$to_degrees__inliner__446000035")

var Lit_145 *jrt.String = jrt.Intern("arbace.math$to_radians")

var Lit_146 *jrt.String = jrt.Intern("arbace.math$to_radians__inliner__446000032")

var Lit_147 *jrt.String = jrt.Intern("arbace.math$ulp")

var Lit_148 *jrt.String = jrt.Intern("arbace.math$ulp__inliner__446000101")

var Lit_149 *jrt.String = jrt.Intern("in-ns")

var Lit_150 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_151 *jrt.String = jrt.Intern("E")

var Lit_152 *jrt.String = jrt.Intern("Constant for e, the base for natural logarithms.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#E")

var Lit_153 *jrt.String = jrt.Intern("added")

var Lit_154 *jrt.String = jrt.Intern("1.11")

var Lit_155 *jrt.String = jrt.Intern("const")

var Lit_156 *jrt.String = jrt.Intern("tag")

var Lit_157 *jrt.String = jrt.Intern("line")

var Lit_158 *jrt.String = jrt.Intern("column")

var Lit_159 *jrt.String = jrt.Intern("file")

var Lit_160 *jrt.String = jrt.Intern("arbace/math.ae")

var Lit_161 *jrt.String = jrt.Intern("PI")

var Lit_162 *jrt.String = jrt.Intern("Constant for pi, the ratio of the circumference of a circle to its diameter.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#PI")

var Lit_163 *jrt.String = jrt.Intern("arglists")

var Lit_164 *jrt.String = jrt.Intern("a")

var Lit_165 *jrt.String = jrt.Intern("inline-arities")

var Lit_166 *jrt.String = jrt.Intern("inline")

var Lit_167 *jrt.String = jrt.Intern("to-radians")

var Lit_168 *jrt.String = jrt.Intern("deg")

var Lit_169 *jrt.String = jrt.Intern("to-degrees")

var Lit_170 *jrt.String = jrt.Intern("r")

var Lit_171 *jrt.String = jrt.Intern("IEEE-remainder")

var Lit_172 *jrt.String = jrt.Intern("dividend")

var Lit_173 *jrt.String = jrt.Intern("divisor")

var Lit_174 *jrt.String = jrt.Intern("y")

var Lit_175 *jrt.String = jrt.Intern("x")

var Lit_176 *jrt.String = jrt.Intern("b")

var Lit_177 *jrt.String = jrt.Intern("add-exact")

var Lit_178 *jrt.String = jrt.Intern("subtract-exact")

var Lit_179 *jrt.String = jrt.Intern("multiply-exact")

var Lit_180 *jrt.String = jrt.Intern("increment-exact")

var Lit_181 *jrt.String = jrt.Intern("decrement-exact")

var Lit_182 *jrt.String = jrt.Intern("negate-exact")

var Lit_183 *jrt.String = jrt.Intern("floor-div")

var Lit_184 *jrt.String = jrt.Intern("floor-mod")

var Lit_185 *jrt.String = jrt.Intern("d")

var Lit_186 *jrt.String = jrt.Intern("copy-sign")

var Lit_187 *jrt.String = jrt.Intern("magnitude")

var Lit_188 *jrt.String = jrt.Intern("sign")

var Lit_189 *jrt.String = jrt.Intern("get-exponent")

var Lit_190 *jrt.String = jrt.Intern("next-after")

var Lit_191 *jrt.String = jrt.Intern("start")

var Lit_192 *jrt.String = jrt.Intern("direction")

var Lit_193 *jrt.String = jrt.Intern("next-up")

var Lit_194 *jrt.String = jrt.Intern("next-down")

var Lit_195 *jrt.String = jrt.Intern("scaleFactor")

var Lit_196 *jrt.String = jrt.Intern("Returns the sine of an angle.\n  If a is ##NaN, ##-Inf, ##Inf => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sin-double-")

var Lit_197 *jrt.String = jrt.Intern("Returns the cosine of an angle.\n  If a is ##NaN, ##-Inf, ##Inf => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#cos-double-")

var Lit_198 *jrt.String = jrt.Intern("Returns the tangent of an angle.\n  If a is ##NaN, ##-Inf, ##Inf => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#tan-double-")

var Lit_199 *jrt.String = jrt.Intern("Returns the arc sine of an angle, in the range -pi/2 to pi/2.\n  If a is ##NaN or |a|>1 => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#asin-double-")

var Lit_200 *jrt.String = jrt.Intern("Returns the arc cosine of a, in the range 0.0 to pi.\n  If a is ##NaN or |a|>1 => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#acos-double-")

var Lit_201 *jrt.String = jrt.Intern("Returns the arc tangent of a, in the range of -pi/2 to pi/2.\n  If a is ##NaN => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#atan-double-")

var Lit_202 *jrt.String = jrt.Intern("Converts an angle in degrees to an approximate equivalent angle in radians.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#toRadians-double-")

var Lit_203 *jrt.String = jrt.Intern("Converts an angle in radians to an approximate equivalent angle in degrees.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#toDegrees-double-")

var Lit_204 *jrt.String = jrt.Intern("Returns Euler's number e raised to the power of a.\n  If a is ##NaN => ##NaN\n  If a is ##Inf => ##Inf\n  If a is ##-Inf => +0.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#exp-double-")

var Lit_205 *jrt.String = jrt.Intern("Returns the natural logarithm (base e) of a.\n  If a is ##NaN or negative => ##NaN\n  If a is ##Inf => ##Inf\n  If a is zero => ##-Inf\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#log-double-")

var Lit_206 *jrt.String = jrt.Intern("Returns the logarithm (base 10) of a.\n  If a is ##NaN or negative => ##NaN\n  If a is ##Inf => ##Inf\n  If a is zero => ##-Inf\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#log10-double-")

var Lit_207 *jrt.String = jrt.Intern("Returns the positive square root of a.\n  If a is ##NaN or negative => ##NaN\n  If a is ##Inf => ##Inf\n  If a is zero => a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sqrt-double-")

var Lit_208 *jrt.String = jrt.Intern("Returns the cube root of a.\n  If a is ##NaN => ##NaN\n  If a is ##Inf or ##-Inf => a\n  If a is zero => zero with sign matching a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#cbrt-double-")

var Lit_209 *jrt.String = jrt.Intern("Returns the remainder per IEEE 754 such that\n    remainder = dividend - divisor * n\n  where n is the integer closest to the exact value of dividend / divisor.\n  If two integers are equally close, then n is the even one.\n  If the remainder is zero, sign will match dividend.\n  If dividend or divisor is ##NaN, or dividend is ##Inf or ##-Inf, or divisor is zero => ##NaN\n  If dividend is finite and divisor is infinite => dividend\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#IEEEremainder-double-double-")

var Lit_210 *jrt.String = jrt.Intern("Returns the smallest double greater than or equal to a, and equal to a\n  mathematical integer.\n  If a is ##NaN or ##Inf or ##-Inf or already equal to an integer => a\n  If a is less than zero but greater than -1.0 => -0.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#ceil-double-")

var Lit_211 *jrt.String = jrt.Intern("Returns the largest double less than or equal to a, and equal to a\n  mathematical integer.\n  If a is ##NaN or ##Inf or ##-Inf or already equal to an integer => a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#floor-double-")

var Lit_212 *jrt.String = jrt.Intern("Returns the double closest to a and equal to a mathematical integer.\n  If two values are equally close, return the even one.\n  If a is ##NaN or ##Inf or ##-Inf or zero => a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#rint-double-")

var Lit_213 *jrt.String = jrt.Intern("Returns the angle theta from the conversion of rectangular coordinates (x, y) to polar coordinates (r, theta).\n  Computes the phase theta by computing an arc tangent of y/x in the range of -pi to pi.\n  For more details on special cases, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#atan2-double-double-")

var Lit_214 *jrt.String = jrt.Intern("Returns the value of a raised to the power of b.\n  For more details on special cases, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#pow-double-double-")

var Lit_215 *jrt.String = jrt.Intern("Returns the closest long to a. If equally close to two values, return the one\n  closer to ##Inf.\n  If a is ##NaN => 0\n  If a is ##-Inf or < Long/MIN_VALUE => Long/MIN_VALUE\n  If a is ##Inf or > Long/MAX_VALUE => Long/MAX_VALUE\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#round-double-")

var Lit_216 *jrt.String = jrt.Intern("Returns a positive double between 0.0 and 1.0, chosen pseudorandomly with\n  approximately random distribution.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#random--")

var Lit_217 *jrt.String = jrt.Intern("Returns the sum of x and y, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#addExact-long-long-")

var Lit_218 *jrt.String = jrt.Intern("Returns the difference of x and y, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#subtractExact-long-long-")

var Lit_219 *jrt.String = jrt.Intern("Returns the product of x and y, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#multiplyExact-long-long-")

var Lit_220 *jrt.String = jrt.Intern("Returns a incremented by 1, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#incrementExact-long-")

var Lit_221 *jrt.String = jrt.Intern("Returns a decremented by 1, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#decrementExact-long-")

var Lit_222 *jrt.String = jrt.Intern("Returns the negation of a, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#negateExact-long-")

var Lit_223 *jrt.String = jrt.Intern("Integer division that rounds to negative infinity (as opposed to zero).\n  The special case (floorDiv Long/MIN_VALUE -1) overflows and returns Long/MIN_VALUE.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#floorDiv-long-long-")

var Lit_224 *jrt.String = jrt.Intern("Integer modulus x - (floorDiv(x, y) * y). Sign matches y and is in the\n  range -|y| < r < |y|.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#floorMod-long-long-")

var Lit_225 *jrt.String = jrt.Intern("Returns the size of an ulp (unit in last place) for d.\n  If d is ##NaN => ##NaN\n  If d is ##Inf or ##-Inf => ##Inf\n  If d is zero => Double/MIN_VALUE\n  If d is +/- Double/MAX_VALUE => 2^971\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#ulp-double-")

var Lit_226 *jrt.String = jrt.Intern("Returns the signum function of d - zero for zero, 1.0 if >0, -1.0 if <0.\n  If d is ##NaN => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#signum-double-")

var Lit_227 *jrt.String = jrt.Intern("Returns the hyperbolic sine of x, (e^x - e^-x)/2.\n  If x is ##NaN => ##NaN\n  If x is ##Inf or ##-Inf or zero => x\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sinh-double-")

var Lit_228 *jrt.String = jrt.Intern("Returns the hyperbolic cosine of x, (e^x + e^-x)/2.\n  If x is ##NaN => ##NaN\n  If x is ##Inf or ##-Inf => ##Inf\n  If x is zero => 1.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#cosh-double-")

var Lit_229 *jrt.String = jrt.Intern("Returns the hyperbolic tangent of x, sinh(x)/cosh(x).\n  If x is ##NaN => ##NaN\n  If x is zero => zero, with same sign\n  If x is ##Inf => +1.0\n  If x is ##-Inf => -1.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#tanh-double-")

var Lit_230 *jrt.String = jrt.Intern("Returns sqrt(x^2 + y^2) without intermediate underflow or overflow.\n  If x or y is ##Inf or ##-Inf => ##Inf\n  If x or y is ##NaN and neither is ##Inf or ##-Inf => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#hypot-double-double-")

var Lit_231 *jrt.String = jrt.Intern("Returns e^x - 1. Near 0, expm1(x)+1 is more accurate to e^x than exp(x).\n  If x is ##NaN => ##NaN\n  If x is ##Inf => #Inf\n  If x is ##-Inf => -1.0\n  If x is zero => x\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#expm1-double-")

var Lit_232 *jrt.String = jrt.Intern("Returns ln(1+x). For small values of x, log1p(x) is more accurate than\n  log(1.0+x).\n  If x is ##NaN or < -1 => ##NaN\n  If x is ##Inf => ##Inf\n  If x is -1 => ##-Inf\n  If x is 0 => 0 with sign matching x\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#log1p-double-")

var Lit_233 *jrt.String = jrt.Intern("Returns a double with the magnitude of the first argument and the sign of\n  the second.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#copySign-double-double-")

var Lit_234 *jrt.String = jrt.Intern("Returns the exponent of d.\n  If d is ##NaN, ##Inf, ##-Inf => Double/MAX_EXPONENT + 1\n  If d is zero or subnormal => Double/MIN_EXPONENT - 1\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#getExponent-double-")

var Lit_235 *jrt.String = jrt.Intern("Returns the adjacent floating point number to start in the direction of\n  the second argument. If the arguments are equal, the second is returned.\n  If either arg is #NaN => #NaN\n  If both arguments are signed zeros => direction\n  If start is +-Double/MIN_VALUE and direction would cause a smaller magnitude\n    => zero with sign matching start\n  If start is ##Inf or ##-Inf and direction would cause a smaller magnitude\n    => Double/MAX_VALUE with same sign as start\n  If start is equal to +=Double/MAX_VALUE and direction would cause a larger magnitude\n    => ##Inf or ##-Inf with sign matching start\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#nextAfter-double-double-")

var Lit_236 *jrt.String = jrt.Intern("Returns the adjacent double of d in the direction of ##Inf.\n  If d is ##NaN => ##NaN\n  If d is ##Inf => ##Inf\n  If d is zero => Double/MIN_VALUE\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#nextUp-double-")

var Lit_237 *jrt.String = jrt.Intern("Returns the adjacent double of d in the direction of ##-Inf.\n  If d is ##NaN => ##NaN\n  If d is ##-Inf => ##-Inf\n  If d is zero => -Double/MIN_VALUE\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#nextDown-double-")

var Lit_238 *jrt.String = jrt.Intern("Returns d * 2^scaleFactor, scaling by a factor of 2. If the exponent\n  is between Double/MIN_EXPONENT and Double/MAX_EXPONENT, the answer is exact.\n  If d is ##NaN => ##NaN\n  If d is ##Inf or ##-Inf => ##Inf or ##-Inf respectively\n  If d is zero => zero of same sign as d\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#scalb-double-int-")
