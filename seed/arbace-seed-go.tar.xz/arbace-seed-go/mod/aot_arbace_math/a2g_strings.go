//line a2g_strings.ae:1
package aot_arbace_math

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn6,authorkn3,docys14,java.lang.Math3,sinys11,arbace.core6,doubleys14,java.lang.Math3,cosys14,java.lang.Math3,tanys14,java.lang.Math4,asinys14,java.lang.Math4,acosys14,java.lang.Math4,atanys14,java.lang.Math9,toRadiansys14,java.lang.Math9,toDegreesys14,java.lang.Math3,expys14,java.lang.Math3,logys14,java.lang.Math5,log10ys14,java.lang.Math4,sqrtys14,java.lang.Math4,cbrtys14,java.lang.Math13,IEEEremainderys14,java.lang.Math4,ceilys14,java.lang.Math5,floorys14,java.lang.Math4,rintys14,java.lang.Math5,atan2ys14,java.lang.Math3,powys14,java.lang.Math5,roundys14,java.lang.Math6,randomys14,java.lang.Math8,addExactys11,arbace.core4,longys14,java.lang.Math13,subtractExactys14,java.lang.Math13,multiplyExactys14,java.lang.Math14,incrementExactys14,java.lang.Math14,decrementExactys14,java.lang.Math11,negateExactys14,java.lang.Math8,floorDivys14,java.lang.Math8,floorModys14,java.lang.Math3,ulpys14,java.lang.Math6,signumys14,java.lang.Math4,sinhys14,java.lang.Math4,coshys14,java.lang.Math4,tanhys14,java.lang.Math5,hypotys14,java.lang.Math5,expm1ys14,java.lang.Math5,log1pys14,java.lang.Math8,copySignys14,java.lang.Math11,getExponentys14,java.lang.Math9,nextAfterys14,java.lang.Math6,nextUpys14,java.lang.Math8,nextDownys14,java.lang.Math5,scalbys11,arbace.core3,intv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn11,arbace.mathm4,R1,s11,Alex MillerR2,s458,Clojure wrapper functions for java.lang.Math static methods.\n\n  Function calls are inlined for performance, and type hinted for primitive\n  long or double parameters where appropriate. In general, Math methods are\n  optimized for performance and have bounds for error tolerance. If\n  greater precision is needed, use java.lang.StrictMath directly instead.\n\n  For more complete information, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.htmlv11,arbace.core13,*loaded-libs*v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR3,R4,R5,R4,R6,R4,R7,R4,R8,R4,R9,R4,R10,R4,R11,R4,R12,R4,R13,R4,R14,R4,R15,R4,R16,R4,R17,R4,R4,R18,R4,R19,R4,R20,R4,R21,R4,R4,R22,R4,R4,R23,R4,R24,R25,R26,R26,R27,R26,R26,R28,R26,R26,R29,R26,R30,R26,R31,R26,R32,R26,R26,R33,R26,R26,R34,R4,R35,R4,R36,R4,R37,R4,R38,R4,R39,R4,R4,R40,R4,R41,R4,R42,R4,R4,R43,R4,R44,R4,R4,R45,R4,R46,R4,R47,R4,R48,")

var Lit_1 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.corekn5,addedkn5,constkn3,tagyn6,doublekn4,linekn6,columnkn4,filekn8,arglistskn14,inline-aritieskn6,inlineyn4,longyn11,scaleFactorv11,arbace.core5,in-nsMyn11,arbace.mathm4,R0,s11,Alex MillerR1,s458,Clojure wrapper functions for java.lang.Math static methods.\n\n  Function calls are inlined for performance, and type hinted for primitive\n  long or double parameters where appropriate. In general, Math methods are\n  optimized for performance and have bounds for error tolerance. If\n  greater precision is needed, use java.lang.StrictMath directly instead.\n\n  For more complete information, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.htmlm4,R0,s11,Alex MillerR1,s458,Clojure wrapper functions for java.lang.Math static methods.\n\n  Function calls are inlined for performance, and type hinted for primitive\n  long or double parameters where appropriate. In general, Math methods are\n  optimized for performance and have bounds for error tolerance. If\n  greater precision is needed, use java.lang.StrictMath directly instead.\n\n  For more complete information, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.htmlR2,v11,arbace.core20,*warn-on-reflection*v11,arbace.math1,Em14,R1,s119,Constant for e, the base for natural logarithms.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#ER3,s4,1.11R4,TR5,R6,R7,i24,R8,i1,R9,s14,arbace/math.aev11,arbace.math2,PIm14,R1,s148,Constant for pi, the ratio of the circumference of a circle to its diameter.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#PIR3,s4,1.11R4,TR5,R6,R7,i33,R8,i1,R9,s14,arbace/math.aev11,arbace.math3,sinR10,L1,MV1,Myn1,am2,R5,R6,m2,R5,R6,R1,R11,S1,l1,R12,R3,R7,i42,R8,i1,R9,v11,arbace.math3,cosL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i53,v11,arbace.math3,tanL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i63,v11,arbace.math4,asinL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i74,v11,arbace.math4,acosL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i85,v11,arbace.math4,atanL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i95,v11,arbace.math10,to-radiansL1,MV1,Myn3,degm2,R5,R6,m2,R5,R6,S1,l1,i106,v11,arbace.math10,to-degreesL1,MV1,Myn1,rm2,R5,R6,m2,R5,R6,S1,l1,i115,v11,arbace.math3,expL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i124,v11,arbace.math3,logL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i136,v11,arbace.math5,log10L1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i148,v11,arbace.math4,sqrtL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i160,v11,arbace.math4,cbrtL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i172,v11,arbace.math14,IEEE-remainderL1,MV2,Myn8,dividendm2,R5,R6,Myn7,divisorm2,R5,R6,m2,R5,R6,S1,l2,i184,v11,arbace.math4,ceilL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i199,v11,arbace.math5,floorL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i211,v11,arbace.math4,rintL1,MV1,Myn1,am2,R5,R6,m2,R5,R6,S1,l1,i222,v11,arbace.math5,atan2L1,MV2,Myn1,ym2,R5,R6,Myn1,xm2,R5,R6,m2,R5,R6,S1,l2,i233,v11,arbace.math3,powL1,MV2,Myn1,am2,R5,R6,Myn1,bm2,R5,R6,m2,R5,R6,S1,l2,i244,v11,arbace.math5,roundL1,MV1,Myn1,am2,R5,R6,m2,R5,R13,S1,l1,i254,v11,arbace.math6,randomL1,MV0,m2,R5,R6,S1,l0,i267,v11,arbace.math9,add-exactL1,MV2,Myn1,xm2,R5,R13,Myn1,ym2,R5,R13,m2,R5,R13,S1,l2,i277,v11,arbace.math14,subtract-exactL1,MV2,Myn1,xm2,R5,R13,Myn1,ym2,R5,R13,m2,R5,R13,S1,l2,i286,v11,arbace.math14,multiply-exactL1,MV2,Myn1,xm2,R5,R13,Myn1,ym2,R5,R13,m2,R5,R13,S1,l2,i295,v11,arbace.math15,increment-exactL1,MV1,Myn1,am2,R5,R13,m2,R5,R13,S1,l1,i304,v11,arbace.math15,decrement-exactL1,MV1,Myn1,am2,R5,R13,m2,R5,R13,S1,l1,i313,v11,arbace.math12,negate-exactL1,MV1,Myn1,am2,R5,R13,m2,R5,R13,S1,l1,i322,v11,arbace.math9,floor-divL1,MV2,Myn1,xm2,R5,R13,Myn1,ym2,R5,R13,m2,R5,R13,S1,l2,i331,v11,arbace.math9,floor-modL1,MV2,Myn1,xm2,R5,R13,Myn1,ym2,R5,R13,m2,R5,R13,S1,l2,i341,v11,arbace.math3,ulpL1,MV1,Myn1,dm2,R5,R6,m2,R5,R6,S1,l1,i351,v11,arbace.math6,signumL1,MV1,Myn1,dm2,R5,R6,m2,R5,R6,S1,l1,i364,v11,arbace.math4,sinhL1,MV1,Myn1,xm2,R5,R6,m2,R5,R6,S1,l1,i374,v11,arbace.math4,coshL1,MV1,Myn1,xm2,R5,R6,m2,R5,R6,S1,l1,i385,v11,arbace.math4,tanhL1,MV1,Myn1,xm2,R5,R6,m2,R5,R6,S1,l1,i397,v11,arbace.math5,hypotL1,MV2,Myn1,xm2,R5,R6,Myn1,ym2,R5,R6,m2,R5,R6,S1,l2,i410,v11,arbace.math5,expm1L1,MV1,Myn1,xm2,R5,R6,m2,R5,R6,S1,l1,i421,v11,arbace.math5,log1pL1,MV1,Myn1,xm2,R5,R6,m2,R5,R6,S1,l1,i434,v11,arbace.math9,copy-signL1,MV2,Myn9,magnitudem2,R5,R6,Myn4,signm2,R5,R6,m2,R5,R6,S1,l2,i448,v11,arbace.math12,get-exponentL1,V1,Myn1,dm2,R5,R6,S1,l1,i458,v11,arbace.math10,next-afterL1,MV2,Myn5,startm2,R5,R6,Myn9,directionm2,R5,R6,m2,R5,R6,S1,l2,i469,v11,arbace.math7,next-upL1,MV1,Myn1,dm2,R5,R6,m2,R5,R6,S1,l1,i487,v11,arbace.math9,next-downL1,MV1,Myn1,dm2,R5,R6,m2,R5,R6,S1,l1,i499,v11,arbace.math5,scalbL1,MV2,Myn1,dm2,R5,R6,R14,m2,R5,R6,S1,l2,i511,")

var Lit_2 *jrt.String = jrt.Intern("arbace.math$eval446000004$loading__1927001464__auto____446000005")

var Lit_3 *jrt.String = jrt.Intern("arbace.math$eval446000008$fn__446000009")

var Lit_4 *jrt.String = jrt.Intern("arbace.math$sin")

var Lit_5 *jrt.String = jrt.Intern("Returns the sine of an angle.\n  If a is ##NaN, ##-Inf, ##Inf => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sin-double-")

var Lit_6 *jrt.String = jrt.Intern("arbace.math$sin__inliner__446000014")

var Lit_7 *jrt.String = jrt.Intern("1.11")

var Lit_8 *jrt.String = jrt.Intern("arbace/math.ae")

var Lit_9 *jrt.String = jrt.Intern("arbace.math$cos")

var Lit_10 *jrt.String = jrt.Intern("Returns the cosine of an angle.\n  If a is ##NaN, ##-Inf, ##Inf => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#cos-double-")

var Lit_11 *jrt.String = jrt.Intern("arbace.math$cos__inliner__446000017")

var Lit_12 *jrt.String = jrt.Intern("arbace.math$tan")

var Lit_13 *jrt.String = jrt.Intern("Returns the tangent of an angle.\n  If a is ##NaN, ##-Inf, ##Inf => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#tan-double-")

var Lit_14 *jrt.String = jrt.Intern("arbace.math$tan__inliner__446000020")

var Lit_15 *jrt.String = jrt.Intern("arbace.math$asin")

var Lit_16 *jrt.String = jrt.Intern("Returns the arc sine of an angle, in the range -pi/2 to pi/2.\n  If a is ##NaN or |a|>1 => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#asin-double-")

var Lit_17 *jrt.String = jrt.Intern("arbace.math$asin__inliner__446000023")

var Lit_18 *jrt.String = jrt.Intern("arbace.math$acos")

var Lit_19 *jrt.String = jrt.Intern("Returns the arc cosine of a, in the range 0.0 to pi.\n  If a is ##NaN or |a|>1 => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#acos-double-")

var Lit_20 *jrt.String = jrt.Intern("arbace.math$acos__inliner__446000026")

var Lit_21 *jrt.String = jrt.Intern("arbace.math$atan")

var Lit_22 *jrt.String = jrt.Intern("Returns the arc tangent of a, in the range of -pi/2 to pi/2.\n  If a is ##NaN => ##NaN\n  If a is zero => zero with the same sign as a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#atan-double-")

var Lit_23 *jrt.String = jrt.Intern("arbace.math$atan__inliner__446000029")

var Lit_24 *jrt.String = jrt.Intern("arbace.math$to_radians")

var Lit_25 *jrt.String = jrt.Intern("Converts an angle in degrees to an approximate equivalent angle in radians.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#toRadians-double-")

var Lit_26 *jrt.String = jrt.Intern("arbace.math$to_radians__inliner__446000032")

var Lit_27 *jrt.String = jrt.Intern("arbace.math$to_degrees")

var Lit_28 *jrt.String = jrt.Intern("Converts an angle in radians to an approximate equivalent angle in degrees.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#toDegrees-double-")

var Lit_29 *jrt.String = jrt.Intern("arbace.math$to_degrees__inliner__446000035")

var Lit_30 *jrt.String = jrt.Intern("arbace.math$exp")

var Lit_31 *jrt.String = jrt.Intern("Returns Euler's number e raised to the power of a.\n  If a is ##NaN => ##NaN\n  If a is ##Inf => ##Inf\n  If a is ##-Inf => +0.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#exp-double-")

var Lit_32 *jrt.String = jrt.Intern("arbace.math$exp__inliner__446000038")

var Lit_33 *jrt.String = jrt.Intern("arbace.math$log")

var Lit_34 *jrt.String = jrt.Intern("Returns the natural logarithm (base e) of a.\n  If a is ##NaN or negative => ##NaN\n  If a is ##Inf => ##Inf\n  If a is zero => ##-Inf\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#log-double-")

var Lit_35 *jrt.String = jrt.Intern("arbace.math$log__inliner__446000041")

var Lit_36 *jrt.String = jrt.Intern("arbace.math$log10")

var Lit_37 *jrt.String = jrt.Intern("Returns the logarithm (base 10) of a.\n  If a is ##NaN or negative => ##NaN\n  If a is ##Inf => ##Inf\n  If a is zero => ##-Inf\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#log10-double-")

var Lit_38 *jrt.String = jrt.Intern("arbace.math$log10__inliner__446000044")

var Lit_39 *jrt.String = jrt.Intern("arbace.math$sqrt")

var Lit_40 *jrt.String = jrt.Intern("Returns the positive square root of a.\n  If a is ##NaN or negative => ##NaN\n  If a is ##Inf => ##Inf\n  If a is zero => a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sqrt-double-")

var Lit_41 *jrt.String = jrt.Intern("arbace.math$sqrt__inliner__446000047")

var Lit_42 *jrt.String = jrt.Intern("arbace.math$cbrt")

var Lit_43 *jrt.String = jrt.Intern("Returns the cube root of a.\n  If a is ##NaN => ##NaN\n  If a is ##Inf or ##-Inf => a\n  If a is zero => zero with sign matching a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#cbrt-double-")

var Lit_44 *jrt.String = jrt.Intern("arbace.math$cbrt__inliner__446000050")

var Lit_45 *jrt.String = jrt.Intern("arbace.math$IEEE_remainder")

var Lit_46 *jrt.String = jrt.Intern("Returns the remainder per IEEE 754 such that\n    remainder = dividend - divisor * n\n  where n is the integer closest to the exact value of dividend / divisor.\n  If two integers are equally close, then n is the even one.\n  If the remainder is zero, sign will match dividend.\n  If dividend or divisor is ##NaN, or dividend is ##Inf or ##-Inf, or divisor is zero => ##NaN\n  If dividend is finite and divisor is infinite => dividend\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#IEEEremainder-double-double-")

var Lit_47 *jrt.String = jrt.Intern("arbace.math$IEEE_remainder__inliner__446000053")

var Lit_48 *jrt.String = jrt.Intern("arbace.math$ceil")

var Lit_49 *jrt.String = jrt.Intern("Returns the smallest double greater than or equal to a, and equal to a\n  mathematical integer.\n  If a is ##NaN or ##Inf or ##-Inf or already equal to an integer => a\n  If a is less than zero but greater than -1.0 => -0.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#ceil-double-")

var Lit_50 *jrt.String = jrt.Intern("arbace.math$ceil__inliner__446000056")

var Lit_51 *jrt.String = jrt.Intern("arbace.math$floor")

var Lit_52 *jrt.String = jrt.Intern("Returns the largest double less than or equal to a, and equal to a\n  mathematical integer.\n  If a is ##NaN or ##Inf or ##-Inf or already equal to an integer => a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#floor-double-")

var Lit_53 *jrt.String = jrt.Intern("arbace.math$floor__inliner__446000059")

var Lit_54 *jrt.String = jrt.Intern("arbace.math$rint")

var Lit_55 *jrt.String = jrt.Intern("Returns the double closest to a and equal to a mathematical integer.\n  If two values are equally close, return the even one.\n  If a is ##NaN or ##Inf or ##-Inf or zero => a\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#rint-double-")

var Lit_56 *jrt.String = jrt.Intern("arbace.math$rint__inliner__446000062")

var Lit_57 *jrt.String = jrt.Intern("arbace.math$atan2")

var Lit_58 *jrt.String = jrt.Intern("Returns the angle theta from the conversion of rectangular coordinates (x, y) to polar coordinates (r, theta).\n  Computes the phase theta by computing an arc tangent of y/x in the range of -pi to pi.\n  For more details on special cases, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#atan2-double-double-")

var Lit_59 *jrt.String = jrt.Intern("arbace.math$atan2__inliner__446000065")

var Lit_60 *jrt.String = jrt.Intern("arbace.math$pow")

var Lit_61 *jrt.String = jrt.Intern("Returns the value of a raised to the power of b.\n  For more details on special cases, see:\n  https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#pow-double-double-")

var Lit_62 *jrt.String = jrt.Intern("arbace.math$pow__inliner__446000068")

var Lit_63 *jrt.String = jrt.Intern("arbace.math$round")

var Lit_64 *jrt.String = jrt.Intern("Returns the closest long to a. If equally close to two values, return the one\n  closer to ##Inf.\n  If a is ##NaN => 0\n  If a is ##-Inf or < Long/MIN_VALUE => Long/MIN_VALUE\n  If a is ##Inf or > Long/MAX_VALUE => Long/MAX_VALUE\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#round-double-")

var Lit_65 *jrt.String = jrt.Intern("arbace.math$round__inliner__446000071")

var Lit_66 *jrt.String = jrt.Intern("arbace.math$random")

var Lit_67 *jrt.String = jrt.Intern("Returns a positive double between 0.0 and 1.0, chosen pseudorandomly with\n  approximately random distribution.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#random--")

var Lit_68 *jrt.String = jrt.Intern("arbace.math$random__inliner__446000074")

var Lit_69 *jrt.String = jrt.Intern("arbace.math$add_exact")

var Lit_70 *jrt.String = jrt.Intern("Returns the sum of x and y, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#addExact-long-long-")

var Lit_71 *jrt.String = jrt.Intern("arbace.math$add_exact__inliner__446000077")

var Lit_72 *jrt.String = jrt.Intern("arbace.math$subtract_exact")

var Lit_73 *jrt.String = jrt.Intern("Returns the difference of x and y, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#subtractExact-long-long-")

var Lit_74 *jrt.String = jrt.Intern("arbace.math$subtract_exact__inliner__446000080")

var Lit_75 *jrt.String = jrt.Intern("arbace.math$multiply_exact")

var Lit_76 *jrt.String = jrt.Intern("Returns the product of x and y, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#multiplyExact-long-long-")

var Lit_77 *jrt.String = jrt.Intern("arbace.math$multiply_exact__inliner__446000083")

var Lit_78 *jrt.String = jrt.Intern("arbace.math$increment_exact")

var Lit_79 *jrt.String = jrt.Intern("Returns a incremented by 1, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#incrementExact-long-")

var Lit_80 *jrt.String = jrt.Intern("arbace.math$increment_exact__inliner__446000086")

var Lit_81 *jrt.String = jrt.Intern("arbace.math$decrement_exact")

var Lit_82 *jrt.String = jrt.Intern("Returns a decremented by 1, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#decrementExact-long-")

var Lit_83 *jrt.String = jrt.Intern("arbace.math$decrement_exact__inliner__446000089")

var Lit_84 *jrt.String = jrt.Intern("arbace.math$negate_exact")

var Lit_85 *jrt.String = jrt.Intern("Returns the negation of a, throws ArithmeticException on overflow.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#negateExact-long-")

var Lit_86 *jrt.String = jrt.Intern("arbace.math$negate_exact__inliner__446000092")

var Lit_87 *jrt.String = jrt.Intern("arbace.math$floor_div")

var Lit_88 *jrt.String = jrt.Intern("Integer division that rounds to negative infinity (as opposed to zero).\n  The special case (floorDiv Long/MIN_VALUE -1) overflows and returns Long/MIN_VALUE.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#floorDiv-long-long-")

var Lit_89 *jrt.String = jrt.Intern("arbace.math$floor_div__inliner__446000095")

var Lit_90 *jrt.String = jrt.Intern("arbace.math$floor_mod")

var Lit_91 *jrt.String = jrt.Intern("Integer modulus x - (floorDiv(x, y) * y). Sign matches y and is in the\n  range -|y| < r < |y|.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#floorMod-long-long-")

var Lit_92 *jrt.String = jrt.Intern("arbace.math$floor_mod__inliner__446000098")

var Lit_93 *jrt.String = jrt.Intern("arbace.math$ulp")

var Lit_94 *jrt.String = jrt.Intern("Returns the size of an ulp (unit in last place) for d.\n  If d is ##NaN => ##NaN\n  If d is ##Inf or ##-Inf => ##Inf\n  If d is zero => Double/MIN_VALUE\n  If d is +/- Double/MAX_VALUE => 2^971\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#ulp-double-")

var Lit_95 *jrt.String = jrt.Intern("arbace.math$ulp__inliner__446000101")

var Lit_96 *jrt.String = jrt.Intern("arbace.math$signum")

var Lit_97 *jrt.String = jrt.Intern("Returns the signum function of d - zero for zero, 1.0 if >0, -1.0 if <0.\n  If d is ##NaN => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#signum-double-")

var Lit_98 *jrt.String = jrt.Intern("arbace.math$signum__inliner__446000104")

var Lit_99 *jrt.String = jrt.Intern("arbace.math$sinh")

var Lit_100 *jrt.String = jrt.Intern("Returns the hyperbolic sine of x, (e^x - e^-x)/2.\n  If x is ##NaN => ##NaN\n  If x is ##Inf or ##-Inf or zero => x\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#sinh-double-")

var Lit_101 *jrt.String = jrt.Intern("arbace.math$sinh__inliner__446000107")

var Lit_102 *jrt.String = jrt.Intern("arbace.math$cosh")

var Lit_103 *jrt.String = jrt.Intern("Returns the hyperbolic cosine of x, (e^x + e^-x)/2.\n  If x is ##NaN => ##NaN\n  If x is ##Inf or ##-Inf => ##Inf\n  If x is zero => 1.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#cosh-double-")

var Lit_104 *jrt.String = jrt.Intern("arbace.math$cosh__inliner__446000110")

var Lit_105 *jrt.String = jrt.Intern("arbace.math$tanh")

var Lit_106 *jrt.String = jrt.Intern("Returns the hyperbolic tangent of x, sinh(x)/cosh(x).\n  If x is ##NaN => ##NaN\n  If x is zero => zero, with same sign\n  If x is ##Inf => +1.0\n  If x is ##-Inf => -1.0\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#tanh-double-")

var Lit_107 *jrt.String = jrt.Intern("arbace.math$tanh__inliner__446000113")

var Lit_108 *jrt.String = jrt.Intern("arbace.math$hypot")

var Lit_109 *jrt.String = jrt.Intern("Returns sqrt(x^2 + y^2) without intermediate underflow or overflow.\n  If x or y is ##Inf or ##-Inf => ##Inf\n  If x or y is ##NaN and neither is ##Inf or ##-Inf => ##NaN\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#hypot-double-double-")

var Lit_110 *jrt.String = jrt.Intern("arbace.math$hypot__inliner__446000116")

var Lit_111 *jrt.String = jrt.Intern("arbace.math$expm1")

var Lit_112 *jrt.String = jrt.Intern("Returns e^x - 1. Near 0, expm1(x)+1 is more accurate to e^x than exp(x).\n  If x is ##NaN => ##NaN\n  If x is ##Inf => #Inf\n  If x is ##-Inf => -1.0\n  If x is zero => x\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#expm1-double-")

var Lit_113 *jrt.String = jrt.Intern("arbace.math$expm1__inliner__446000119")

var Lit_114 *jrt.String = jrt.Intern("arbace.math$log1p")

var Lit_115 *jrt.String = jrt.Intern("Returns ln(1+x). For small values of x, log1p(x) is more accurate than\n  log(1.0+x).\n  If x is ##NaN or < -1 => ##NaN\n  If x is ##Inf => ##Inf\n  If x is -1 => ##-Inf\n  If x is 0 => 0 with sign matching x\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#log1p-double-")

var Lit_116 *jrt.String = jrt.Intern("arbace.math$log1p__inliner__446000122")

var Lit_117 *jrt.String = jrt.Intern("arbace.math$copy_sign")

var Lit_118 *jrt.String = jrt.Intern("Returns a double with the magnitude of the first argument and the sign of\n  the second.\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#copySign-double-double-")

var Lit_119 *jrt.String = jrt.Intern("arbace.math$copy_sign__inliner__446000125")

var Lit_120 *jrt.String = jrt.Intern("arbace.math$get_exponent")

var Lit_121 *jrt.String = jrt.Intern("Returns the exponent of d.\n  If d is ##NaN, ##Inf, ##-Inf => Double/MAX_EXPONENT + 1\n  If d is zero or subnormal => Double/MIN_EXPONENT - 1\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#getExponent-double-")

var Lit_122 *jrt.String = jrt.Intern("arbace.math$get_exponent__inliner__446000128")

var Lit_123 *jrt.String = jrt.Intern("arbace.math$next_after")

var Lit_124 *jrt.String = jrt.Intern("Returns the adjacent floating point number to start in the direction of\n  the second argument. If the arguments are equal, the second is returned.\n  If either arg is #NaN => #NaN\n  If both arguments are signed zeros => direction\n  If start is +-Double/MIN_VALUE and direction would cause a smaller magnitude\n    => zero with sign matching start\n  If start is ##Inf or ##-Inf and direction would cause a smaller magnitude\n    => Double/MAX_VALUE with same sign as start\n  If start is equal to +=Double/MAX_VALUE and direction would cause a larger magnitude\n    => ##Inf or ##-Inf with sign matching start\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#nextAfter-double-double-")

var Lit_125 *jrt.String = jrt.Intern("arbace.math$next_after__inliner__446000131")

var Lit_126 *jrt.String = jrt.Intern("arbace.math$next_up")

var Lit_127 *jrt.String = jrt.Intern("Returns the adjacent double of d in the direction of ##Inf.\n  If d is ##NaN => ##NaN\n  If d is ##Inf => ##Inf\n  If d is zero => Double/MIN_VALUE\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#nextUp-double-")

var Lit_128 *jrt.String = jrt.Intern("arbace.math$next_up__inliner__446000134")

var Lit_129 *jrt.String = jrt.Intern("arbace.math$next_down")

var Lit_130 *jrt.String = jrt.Intern("Returns the adjacent double of d in the direction of ##-Inf.\n  If d is ##NaN => ##NaN\n  If d is ##-Inf => ##-Inf\n  If d is zero => -Double/MIN_VALUE\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#nextDown-double-")

var Lit_131 *jrt.String = jrt.Intern("arbace.math$next_down__inliner__446000137")

var Lit_132 *jrt.String = jrt.Intern("arbace.math$scalb")

var Lit_133 *jrt.String = jrt.Intern("Returns d * 2^scaleFactor, scaling by a factor of 2. If the exponent\n  is between Double/MIN_EXPONENT and Double/MAX_EXPONENT, the answer is exact.\n  If d is ##NaN => ##NaN\n  If d is ##Inf or ##-Inf => ##Inf or ##-Inf respectively\n  If d is zero => zero of same sign as d\n  See: https://docs.oracle.com/javase/8/docs/api/java/lang/Math.html#scalb-double-int-")

var Lit_134 *jrt.String = jrt.Intern("arbace.math$scalb__inliner__446000140")
