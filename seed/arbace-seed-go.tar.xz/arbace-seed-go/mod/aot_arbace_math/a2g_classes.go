//line a2g_classes.ae:1
package aot_arbace_math

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_math_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_A_New()}; return nil }

var A_arbace_math_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_math_A_new}

var A_arbace_math_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_math.A_arbace_math_A"})

func init() { i := A_arbace_math_A_class.Info(); i.IsInstance = A_arbace_math_A_InstanceOf; i.Init = A_arbace_math_A_Init; i.Table = A_arbace_math_A_members; jrt.RegisterGoType(A_arbace_math_A_class, reflect.TypeFor[A_arbace_math_A]()) }

func A_arbace_math_IEEE_remainder_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_IEEE_remainder_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_IEEE_remainder_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_IEEE_remainder_A_New()}; return nil }

func A_arbace_math_IEEE_remainder_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_IEEE_remainder_A_fn_class)}; return nil }

var A_arbace_math_IEEE_remainder_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_IEEE_remainder_A_invoke, New: A_arbace_math_IEEE_remainder_A_new, Get: A_arbace_math_IEEE_remainder_A_get}

var A_arbace_math_IEEE_remainder_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$IEEE_remainder", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "IEEE_remainder", Go: "arbace/aot_arbace_math.A_arbace_math_IEEE_remainder_A", Source: "math.ae"})

func init() { i := A_arbace_math_IEEE_remainder_A_class.Info(); i.IsInstance = A_arbace_math_IEEE_remainder_A_InstanceOf; i.Init = A_arbace_math_IEEE_remainder_A_Init; i.Table = A_arbace_math_IEEE_remainder_A_members; jrt.RegisterGoType(A_arbace_math_IEEE_remainder_A_class, reflect.TypeFor[A_arbace_math_IEEE_remainder_A]()) }

func A_arbace_math_IEEE_remainder__inliner__446000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_IEEE_remainder__inliner__446000053_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_IEEE_remainder__inliner__446000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_IEEE_remainder__inliner__446000053_A_New()}; return nil }

func A_arbace_math_IEEE_remainder__inliner__446000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_IEEE_remainder__inliner__446000053_A_fn_class)}; return nil }

var A_arbace_math_IEEE_remainder__inliner__446000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_IEEE_remainder__inliner__446000053_A_invoke, New: A_arbace_math_IEEE_remainder__inliner__446000053_A_new, Get: A_arbace_math_IEEE_remainder__inliner__446000053_A_get}

var A_arbace_math_IEEE_remainder__inliner__446000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$IEEE_remainder__inliner__446000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "IEEE_remainder__inliner__446000053", Go: "arbace/aot_arbace_math.A_arbace_math_IEEE_remainder__inliner__446000053_A", Source: "math.ae"})

func init() { i := A_arbace_math_IEEE_remainder__inliner__446000053_A_class.Info(); i.IsInstance = A_arbace_math_IEEE_remainder__inliner__446000053_A_InstanceOf; i.Init = A_arbace_math_IEEE_remainder__inliner__446000053_A_Init; i.Table = A_arbace_math_IEEE_remainder__inliner__446000053_A_members; jrt.RegisterGoType(A_arbace_math_IEEE_remainder__inliner__446000053_A_class, reflect.TypeFor[A_arbace_math_IEEE_remainder__inliner__446000053_A]()) }

func A_arbace_math_acos_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_acos_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_acos_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_acos_A_New()}; return nil }

func A_arbace_math_acos_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_acos_A_fn_class)}; return nil }

var A_arbace_math_acos_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_acos_A_invoke, New: A_arbace_math_acos_A_new, Get: A_arbace_math_acos_A_get}

var A_arbace_math_acos_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$acos", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "acos", Go: "arbace/aot_arbace_math.A_arbace_math_acos_A", Source: "math.ae"})

func init() { i := A_arbace_math_acos_A_class.Info(); i.IsInstance = A_arbace_math_acos_A_InstanceOf; i.Init = A_arbace_math_acos_A_Init; i.Table = A_arbace_math_acos_A_members; jrt.RegisterGoType(A_arbace_math_acos_A_class, reflect.TypeFor[A_arbace_math_acos_A]()) }

func A_arbace_math_acos__inliner__446000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_acos__inliner__446000026_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_acos__inliner__446000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_acos__inliner__446000026_A_New()}; return nil }

func A_arbace_math_acos__inliner__446000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_acos__inliner__446000026_A_fn_class)}; return nil }

var A_arbace_math_acos__inliner__446000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_acos__inliner__446000026_A_invoke, New: A_arbace_math_acos__inliner__446000026_A_new, Get: A_arbace_math_acos__inliner__446000026_A_get}

var A_arbace_math_acos__inliner__446000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$acos__inliner__446000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "acos__inliner__446000026", Go: "arbace/aot_arbace_math.A_arbace_math_acos__inliner__446000026_A", Source: "math.ae"})

func init() { i := A_arbace_math_acos__inliner__446000026_A_class.Info(); i.IsInstance = A_arbace_math_acos__inliner__446000026_A_InstanceOf; i.Init = A_arbace_math_acos__inliner__446000026_A_Init; i.Table = A_arbace_math_acos__inliner__446000026_A_members; jrt.RegisterGoType(A_arbace_math_acos__inliner__446000026_A_class, reflect.TypeFor[A_arbace_math_acos__inliner__446000026_A]()) }

func A_arbace_math_add_exact_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_add_exact_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_add_exact_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_add_exact_A_New()}; return nil }

func A_arbace_math_add_exact_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_add_exact_A_fn_class)}; return nil }

var A_arbace_math_add_exact_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_add_exact_A_invoke, New: A_arbace_math_add_exact_A_new, Get: A_arbace_math_add_exact_A_get}

var A_arbace_math_add_exact_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$add_exact", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "add_exact", Go: "arbace/aot_arbace_math.A_arbace_math_add_exact_A", Source: "math.ae"})

func init() { i := A_arbace_math_add_exact_A_class.Info(); i.IsInstance = A_arbace_math_add_exact_A_InstanceOf; i.Init = A_arbace_math_add_exact_A_Init; i.Table = A_arbace_math_add_exact_A_members; jrt.RegisterGoType(A_arbace_math_add_exact_A_class, reflect.TypeFor[A_arbace_math_add_exact_A]()) }

func A_arbace_math_add_exact__inliner__446000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_add_exact__inliner__446000077_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_add_exact__inliner__446000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_add_exact__inliner__446000077_A_New()}; return nil }

func A_arbace_math_add_exact__inliner__446000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_add_exact__inliner__446000077_A_fn_class)}; return nil }

var A_arbace_math_add_exact__inliner__446000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_add_exact__inliner__446000077_A_invoke, New: A_arbace_math_add_exact__inliner__446000077_A_new, Get: A_arbace_math_add_exact__inliner__446000077_A_get}

var A_arbace_math_add_exact__inliner__446000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$add_exact__inliner__446000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "add_exact__inliner__446000077", Go: "arbace/aot_arbace_math.A_arbace_math_add_exact__inliner__446000077_A", Source: "math.ae"})

func init() { i := A_arbace_math_add_exact__inliner__446000077_A_class.Info(); i.IsInstance = A_arbace_math_add_exact__inliner__446000077_A_InstanceOf; i.Init = A_arbace_math_add_exact__inliner__446000077_A_Init; i.Table = A_arbace_math_add_exact__inliner__446000077_A_members; jrt.RegisterGoType(A_arbace_math_add_exact__inliner__446000077_A_class, reflect.TypeFor[A_arbace_math_add_exact__inliner__446000077_A]()) }

func A_arbace_math_asin_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_asin_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_asin_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_asin_A_New()}; return nil }

func A_arbace_math_asin_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_asin_A_fn_class)}; return nil }

var A_arbace_math_asin_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_asin_A_invoke, New: A_arbace_math_asin_A_new, Get: A_arbace_math_asin_A_get}

var A_arbace_math_asin_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$asin", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "asin", Go: "arbace/aot_arbace_math.A_arbace_math_asin_A", Source: "math.ae"})

func init() { i := A_arbace_math_asin_A_class.Info(); i.IsInstance = A_arbace_math_asin_A_InstanceOf; i.Init = A_arbace_math_asin_A_Init; i.Table = A_arbace_math_asin_A_members; jrt.RegisterGoType(A_arbace_math_asin_A_class, reflect.TypeFor[A_arbace_math_asin_A]()) }

func A_arbace_math_asin__inliner__446000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_asin__inliner__446000023_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_asin__inliner__446000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_asin__inliner__446000023_A_New()}; return nil }

func A_arbace_math_asin__inliner__446000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_asin__inliner__446000023_A_fn_class)}; return nil }

var A_arbace_math_asin__inliner__446000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_asin__inliner__446000023_A_invoke, New: A_arbace_math_asin__inliner__446000023_A_new, Get: A_arbace_math_asin__inliner__446000023_A_get}

var A_arbace_math_asin__inliner__446000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$asin__inliner__446000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "asin__inliner__446000023", Go: "arbace/aot_arbace_math.A_arbace_math_asin__inliner__446000023_A", Source: "math.ae"})

func init() { i := A_arbace_math_asin__inliner__446000023_A_class.Info(); i.IsInstance = A_arbace_math_asin__inliner__446000023_A_InstanceOf; i.Init = A_arbace_math_asin__inliner__446000023_A_Init; i.Table = A_arbace_math_asin__inliner__446000023_A_members; jrt.RegisterGoType(A_arbace_math_asin__inliner__446000023_A_class, reflect.TypeFor[A_arbace_math_asin__inliner__446000023_A]()) }

func A_arbace_math_atan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_atan_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_atan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_atan_A_New()}; return nil }

func A_arbace_math_atan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_atan_A_fn_class)}; return nil }

var A_arbace_math_atan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_atan_A_invoke, New: A_arbace_math_atan_A_new, Get: A_arbace_math_atan_A_get}

var A_arbace_math_atan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$atan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "atan", Go: "arbace/aot_arbace_math.A_arbace_math_atan_A", Source: "math.ae"})

func init() { i := A_arbace_math_atan_A_class.Info(); i.IsInstance = A_arbace_math_atan_A_InstanceOf; i.Init = A_arbace_math_atan_A_Init; i.Table = A_arbace_math_atan_A_members; jrt.RegisterGoType(A_arbace_math_atan_A_class, reflect.TypeFor[A_arbace_math_atan_A]()) }

func A_arbace_math_atan2_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_atan2_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_atan2_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_atan2_A_New()}; return nil }

func A_arbace_math_atan2_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_atan2_A_fn_class)}; return nil }

var A_arbace_math_atan2_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_atan2_A_invoke, New: A_arbace_math_atan2_A_new, Get: A_arbace_math_atan2_A_get}

var A_arbace_math_atan2_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$atan2", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "atan2", Go: "arbace/aot_arbace_math.A_arbace_math_atan2_A", Source: "math.ae"})

func init() { i := A_arbace_math_atan2_A_class.Info(); i.IsInstance = A_arbace_math_atan2_A_InstanceOf; i.Init = A_arbace_math_atan2_A_Init; i.Table = A_arbace_math_atan2_A_members; jrt.RegisterGoType(A_arbace_math_atan2_A_class, reflect.TypeFor[A_arbace_math_atan2_A]()) }

func A_arbace_math_atan2__inliner__446000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_atan2__inliner__446000065_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_atan2__inliner__446000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_atan2__inliner__446000065_A_New()}; return nil }

func A_arbace_math_atan2__inliner__446000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_atan2__inliner__446000065_A_fn_class)}; return nil }

var A_arbace_math_atan2__inliner__446000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_atan2__inliner__446000065_A_invoke, New: A_arbace_math_atan2__inliner__446000065_A_new, Get: A_arbace_math_atan2__inliner__446000065_A_get}

var A_arbace_math_atan2__inliner__446000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$atan2__inliner__446000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "atan2__inliner__446000065", Go: "arbace/aot_arbace_math.A_arbace_math_atan2__inliner__446000065_A", Source: "math.ae"})

func init() { i := A_arbace_math_atan2__inliner__446000065_A_class.Info(); i.IsInstance = A_arbace_math_atan2__inliner__446000065_A_InstanceOf; i.Init = A_arbace_math_atan2__inliner__446000065_A_Init; i.Table = A_arbace_math_atan2__inliner__446000065_A_members; jrt.RegisterGoType(A_arbace_math_atan2__inliner__446000065_A_class, reflect.TypeFor[A_arbace_math_atan2__inliner__446000065_A]()) }

func A_arbace_math_atan__inliner__446000029_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_atan__inliner__446000029_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_atan__inliner__446000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_atan__inliner__446000029_A_New()}; return nil }

func A_arbace_math_atan__inliner__446000029_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_atan__inliner__446000029_A_fn_class)}; return nil }

var A_arbace_math_atan__inliner__446000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_atan__inliner__446000029_A_invoke, New: A_arbace_math_atan__inliner__446000029_A_new, Get: A_arbace_math_atan__inliner__446000029_A_get}

var A_arbace_math_atan__inliner__446000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$atan__inliner__446000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "atan__inliner__446000029", Go: "arbace/aot_arbace_math.A_arbace_math_atan__inliner__446000029_A", Source: "math.ae"})

func init() { i := A_arbace_math_atan__inliner__446000029_A_class.Info(); i.IsInstance = A_arbace_math_atan__inliner__446000029_A_InstanceOf; i.Init = A_arbace_math_atan__inliner__446000029_A_Init; i.Table = A_arbace_math_atan__inliner__446000029_A_members; jrt.RegisterGoType(A_arbace_math_atan__inliner__446000029_A_class, reflect.TypeFor[A_arbace_math_atan__inliner__446000029_A]()) }

func A_arbace_math_cbrt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_cbrt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_cbrt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_cbrt_A_New()}; return nil }

func A_arbace_math_cbrt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_cbrt_A_fn_class)}; return nil }

var A_arbace_math_cbrt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_cbrt_A_invoke, New: A_arbace_math_cbrt_A_new, Get: A_arbace_math_cbrt_A_get}

var A_arbace_math_cbrt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$cbrt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "cbrt", Go: "arbace/aot_arbace_math.A_arbace_math_cbrt_A", Source: "math.ae"})

func init() { i := A_arbace_math_cbrt_A_class.Info(); i.IsInstance = A_arbace_math_cbrt_A_InstanceOf; i.Init = A_arbace_math_cbrt_A_Init; i.Table = A_arbace_math_cbrt_A_members; jrt.RegisterGoType(A_arbace_math_cbrt_A_class, reflect.TypeFor[A_arbace_math_cbrt_A]()) }

func A_arbace_math_cbrt__inliner__446000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_cbrt__inliner__446000050_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_cbrt__inliner__446000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_cbrt__inliner__446000050_A_New()}; return nil }

func A_arbace_math_cbrt__inliner__446000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_cbrt__inliner__446000050_A_fn_class)}; return nil }

var A_arbace_math_cbrt__inliner__446000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_cbrt__inliner__446000050_A_invoke, New: A_arbace_math_cbrt__inliner__446000050_A_new, Get: A_arbace_math_cbrt__inliner__446000050_A_get}

var A_arbace_math_cbrt__inliner__446000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$cbrt__inliner__446000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "cbrt__inliner__446000050", Go: "arbace/aot_arbace_math.A_arbace_math_cbrt__inliner__446000050_A", Source: "math.ae"})

func init() { i := A_arbace_math_cbrt__inliner__446000050_A_class.Info(); i.IsInstance = A_arbace_math_cbrt__inliner__446000050_A_InstanceOf; i.Init = A_arbace_math_cbrt__inliner__446000050_A_Init; i.Table = A_arbace_math_cbrt__inliner__446000050_A_members; jrt.RegisterGoType(A_arbace_math_cbrt__inliner__446000050_A_class, reflect.TypeFor[A_arbace_math_cbrt__inliner__446000050_A]()) }

func A_arbace_math_ceil_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_ceil_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_ceil_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_ceil_A_New()}; return nil }

func A_arbace_math_ceil_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_ceil_A_fn_class)}; return nil }

var A_arbace_math_ceil_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_ceil_A_invoke, New: A_arbace_math_ceil_A_new, Get: A_arbace_math_ceil_A_get}

var A_arbace_math_ceil_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$ceil", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "ceil", Go: "arbace/aot_arbace_math.A_arbace_math_ceil_A", Source: "math.ae"})

func init() { i := A_arbace_math_ceil_A_class.Info(); i.IsInstance = A_arbace_math_ceil_A_InstanceOf; i.Init = A_arbace_math_ceil_A_Init; i.Table = A_arbace_math_ceil_A_members; jrt.RegisterGoType(A_arbace_math_ceil_A_class, reflect.TypeFor[A_arbace_math_ceil_A]()) }

func A_arbace_math_ceil__inliner__446000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_ceil__inliner__446000056_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_ceil__inliner__446000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_ceil__inliner__446000056_A_New()}; return nil }

func A_arbace_math_ceil__inliner__446000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_ceil__inliner__446000056_A_fn_class)}; return nil }

var A_arbace_math_ceil__inliner__446000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_ceil__inliner__446000056_A_invoke, New: A_arbace_math_ceil__inliner__446000056_A_new, Get: A_arbace_math_ceil__inliner__446000056_A_get}

var A_arbace_math_ceil__inliner__446000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$ceil__inliner__446000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "ceil__inliner__446000056", Go: "arbace/aot_arbace_math.A_arbace_math_ceil__inliner__446000056_A", Source: "math.ae"})

func init() { i := A_arbace_math_ceil__inliner__446000056_A_class.Info(); i.IsInstance = A_arbace_math_ceil__inliner__446000056_A_InstanceOf; i.Init = A_arbace_math_ceil__inliner__446000056_A_Init; i.Table = A_arbace_math_ceil__inliner__446000056_A_members; jrt.RegisterGoType(A_arbace_math_ceil__inliner__446000056_A_class, reflect.TypeFor[A_arbace_math_ceil__inliner__446000056_A]()) }

func A_arbace_math_copy_sign_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_copy_sign_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_copy_sign_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_copy_sign_A_New()}; return nil }

func A_arbace_math_copy_sign_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_copy_sign_A_fn_class)}; return nil }

var A_arbace_math_copy_sign_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_copy_sign_A_invoke, New: A_arbace_math_copy_sign_A_new, Get: A_arbace_math_copy_sign_A_get}

var A_arbace_math_copy_sign_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$copy_sign", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "copy_sign", Go: "arbace/aot_arbace_math.A_arbace_math_copy_sign_A", Source: "math.ae"})

func init() { i := A_arbace_math_copy_sign_A_class.Info(); i.IsInstance = A_arbace_math_copy_sign_A_InstanceOf; i.Init = A_arbace_math_copy_sign_A_Init; i.Table = A_arbace_math_copy_sign_A_members; jrt.RegisterGoType(A_arbace_math_copy_sign_A_class, reflect.TypeFor[A_arbace_math_copy_sign_A]()) }

func A_arbace_math_copy_sign__inliner__446000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_copy_sign__inliner__446000125_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_copy_sign__inliner__446000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_copy_sign__inliner__446000125_A_New()}; return nil }

func A_arbace_math_copy_sign__inliner__446000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_copy_sign__inliner__446000125_A_fn_class)}; return nil }

var A_arbace_math_copy_sign__inliner__446000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_copy_sign__inliner__446000125_A_invoke, New: A_arbace_math_copy_sign__inliner__446000125_A_new, Get: A_arbace_math_copy_sign__inliner__446000125_A_get}

var A_arbace_math_copy_sign__inliner__446000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$copy_sign__inliner__446000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "copy_sign__inliner__446000125", Go: "arbace/aot_arbace_math.A_arbace_math_copy_sign__inliner__446000125_A", Source: "math.ae"})

func init() { i := A_arbace_math_copy_sign__inliner__446000125_A_class.Info(); i.IsInstance = A_arbace_math_copy_sign__inliner__446000125_A_InstanceOf; i.Init = A_arbace_math_copy_sign__inliner__446000125_A_Init; i.Table = A_arbace_math_copy_sign__inliner__446000125_A_members; jrt.RegisterGoType(A_arbace_math_copy_sign__inliner__446000125_A_class, reflect.TypeFor[A_arbace_math_copy_sign__inliner__446000125_A]()) }

func A_arbace_math_cos_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_cos_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_cos_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_cos_A_New()}; return nil }

func A_arbace_math_cos_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_cos_A_fn_class)}; return nil }

var A_arbace_math_cos_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_cos_A_invoke, New: A_arbace_math_cos_A_new, Get: A_arbace_math_cos_A_get}

var A_arbace_math_cos_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$cos", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "cos", Go: "arbace/aot_arbace_math.A_arbace_math_cos_A", Source: "math.ae"})

func init() { i := A_arbace_math_cos_A_class.Info(); i.IsInstance = A_arbace_math_cos_A_InstanceOf; i.Init = A_arbace_math_cos_A_Init; i.Table = A_arbace_math_cos_A_members; jrt.RegisterGoType(A_arbace_math_cos_A_class, reflect.TypeFor[A_arbace_math_cos_A]()) }

func A_arbace_math_cos__inliner__446000017_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_cos__inliner__446000017_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_cos__inliner__446000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_cos__inliner__446000017_A_New()}; return nil }

func A_arbace_math_cos__inliner__446000017_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_cos__inliner__446000017_A_fn_class)}; return nil }

var A_arbace_math_cos__inliner__446000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_cos__inliner__446000017_A_invoke, New: A_arbace_math_cos__inliner__446000017_A_new, Get: A_arbace_math_cos__inliner__446000017_A_get}

var A_arbace_math_cos__inliner__446000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$cos__inliner__446000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "cos__inliner__446000017", Go: "arbace/aot_arbace_math.A_arbace_math_cos__inliner__446000017_A", Source: "math.ae"})

func init() { i := A_arbace_math_cos__inliner__446000017_A_class.Info(); i.IsInstance = A_arbace_math_cos__inliner__446000017_A_InstanceOf; i.Init = A_arbace_math_cos__inliner__446000017_A_Init; i.Table = A_arbace_math_cos__inliner__446000017_A_members; jrt.RegisterGoType(A_arbace_math_cos__inliner__446000017_A_class, reflect.TypeFor[A_arbace_math_cos__inliner__446000017_A]()) }

func A_arbace_math_cosh_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_cosh_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_cosh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_cosh_A_New()}; return nil }

func A_arbace_math_cosh_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_cosh_A_fn_class)}; return nil }

var A_arbace_math_cosh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_cosh_A_invoke, New: A_arbace_math_cosh_A_new, Get: A_arbace_math_cosh_A_get}

var A_arbace_math_cosh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$cosh", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "cosh", Go: "arbace/aot_arbace_math.A_arbace_math_cosh_A", Source: "math.ae"})

func init() { i := A_arbace_math_cosh_A_class.Info(); i.IsInstance = A_arbace_math_cosh_A_InstanceOf; i.Init = A_arbace_math_cosh_A_Init; i.Table = A_arbace_math_cosh_A_members; jrt.RegisterGoType(A_arbace_math_cosh_A_class, reflect.TypeFor[A_arbace_math_cosh_A]()) }

func A_arbace_math_cosh__inliner__446000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_cosh__inliner__446000110_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_cosh__inliner__446000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_cosh__inliner__446000110_A_New()}; return nil }

func A_arbace_math_cosh__inliner__446000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_cosh__inliner__446000110_A_fn_class)}; return nil }

var A_arbace_math_cosh__inliner__446000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_cosh__inliner__446000110_A_invoke, New: A_arbace_math_cosh__inliner__446000110_A_new, Get: A_arbace_math_cosh__inliner__446000110_A_get}

var A_arbace_math_cosh__inliner__446000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$cosh__inliner__446000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "cosh__inliner__446000110", Go: "arbace/aot_arbace_math.A_arbace_math_cosh__inliner__446000110_A", Source: "math.ae"})

func init() { i := A_arbace_math_cosh__inliner__446000110_A_class.Info(); i.IsInstance = A_arbace_math_cosh__inliner__446000110_A_InstanceOf; i.Init = A_arbace_math_cosh__inliner__446000110_A_Init; i.Table = A_arbace_math_cosh__inliner__446000110_A_members; jrt.RegisterGoType(A_arbace_math_cosh__inliner__446000110_A_class, reflect.TypeFor[A_arbace_math_cosh__inliner__446000110_A]()) }

func A_arbace_math_decrement_exact_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_decrement_exact_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_decrement_exact_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_decrement_exact_A_New()}; return nil }

func A_arbace_math_decrement_exact_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_decrement_exact_A_fn_class)}; return nil }

var A_arbace_math_decrement_exact_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_decrement_exact_A_invoke, New: A_arbace_math_decrement_exact_A_new, Get: A_arbace_math_decrement_exact_A_get}

var A_arbace_math_decrement_exact_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$decrement_exact", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "decrement_exact", Go: "arbace/aot_arbace_math.A_arbace_math_decrement_exact_A", Source: "math.ae"})

func init() { i := A_arbace_math_decrement_exact_A_class.Info(); i.IsInstance = A_arbace_math_decrement_exact_A_InstanceOf; i.Init = A_arbace_math_decrement_exact_A_Init; i.Table = A_arbace_math_decrement_exact_A_members; jrt.RegisterGoType(A_arbace_math_decrement_exact_A_class, reflect.TypeFor[A_arbace_math_decrement_exact_A]()) }

func A_arbace_math_decrement_exact__inliner__446000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_decrement_exact__inliner__446000089_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_decrement_exact__inliner__446000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_decrement_exact__inliner__446000089_A_New()}; return nil }

func A_arbace_math_decrement_exact__inliner__446000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_decrement_exact__inliner__446000089_A_fn_class)}; return nil }

var A_arbace_math_decrement_exact__inliner__446000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_decrement_exact__inliner__446000089_A_invoke, New: A_arbace_math_decrement_exact__inliner__446000089_A_new, Get: A_arbace_math_decrement_exact__inliner__446000089_A_get}

var A_arbace_math_decrement_exact__inliner__446000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$decrement_exact__inliner__446000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "decrement_exact__inliner__446000089", Go: "arbace/aot_arbace_math.A_arbace_math_decrement_exact__inliner__446000089_A", Source: "math.ae"})

func init() { i := A_arbace_math_decrement_exact__inliner__446000089_A_class.Info(); i.IsInstance = A_arbace_math_decrement_exact__inliner__446000089_A_InstanceOf; i.Init = A_arbace_math_decrement_exact__inliner__446000089_A_Init; i.Table = A_arbace_math_decrement_exact__inliner__446000089_A_members; jrt.RegisterGoType(A_arbace_math_decrement_exact__inliner__446000089_A_class, reflect.TypeFor[A_arbace_math_decrement_exact__inliner__446000089_A]()) }

func A_arbace_math_eval446000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_eval446000004_A_New()}; return nil }

var A_arbace_math_eval446000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_math_eval446000004_A_new}

var A_arbace_math_eval446000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$eval446000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_math_A_class, Simple: "eval446000004", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000004_A"})

func init() { i := A_arbace_math_eval446000004_A_class.Info(); i.IsInstance = A_arbace_math_eval446000004_A_InstanceOf; i.Table = A_arbace_math_eval446000004_A_members; jrt.RegisterGoType(A_arbace_math_eval446000004_A_class, reflect.TypeFor[A_arbace_math_eval446000004_A]()) }

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_New()}; return nil }

func A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_fn_class)}; return nil }

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_invoke, New: A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_new, Get: A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_get}

var A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$eval446000004$loading__1927001464__auto____446000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_math_eval446000004_A_class, Simple: "loading__1927001464__auto____446000005", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A", Source: "math.ae"})

func init() { i := A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_class.Info(); i.IsInstance = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_InstanceOf; i.Init = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_Init; i.Table = A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_members; jrt.RegisterGoType(A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A_class, reflect.TypeFor[A_arbace_math_eval446000004_loading__1927001464__auto____446000005_A]()) }

func A_arbace_math_eval446000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_eval446000008_A_New()}; return nil }

var A_arbace_math_eval446000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_math_eval446000008_A_new}

var A_arbace_math_eval446000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$eval446000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_math_A_class, Simple: "eval446000008", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000008_A"})

func init() { i := A_arbace_math_eval446000008_A_class.Info(); i.IsInstance = A_arbace_math_eval446000008_A_InstanceOf; i.Table = A_arbace_math_eval446000008_A_members; jrt.RegisterGoType(A_arbace_math_eval446000008_A_class, reflect.TypeFor[A_arbace_math_eval446000008_A]()) }

func A_arbace_math_eval446000008_fn__446000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_eval446000008_fn__446000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_math_eval446000008_fn__446000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_eval446000008_fn__446000009_A_New()}; return nil }

func A_arbace_math_eval446000008_fn__446000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_eval446000008_fn__446000009_A_fn_class)}; return nil }

var A_arbace_math_eval446000008_fn__446000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_eval446000008_fn__446000009_A_invoke, New: A_arbace_math_eval446000008_fn__446000009_A_new, Get: A_arbace_math_eval446000008_fn__446000009_A_get}

var A_arbace_math_eval446000008_fn__446000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$eval446000008$fn__446000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_math_eval446000008_A_class, Simple: "fn__446000009", Go: "arbace/aot_arbace_math.A_arbace_math_eval446000008_fn__446000009_A", Source: "math.ae"})

func init() { i := A_arbace_math_eval446000008_fn__446000009_A_class.Info(); i.IsInstance = A_arbace_math_eval446000008_fn__446000009_A_InstanceOf; i.Init = A_arbace_math_eval446000008_fn__446000009_A_Init; i.Table = A_arbace_math_eval446000008_fn__446000009_A_members; jrt.RegisterGoType(A_arbace_math_eval446000008_fn__446000009_A_class, reflect.TypeFor[A_arbace_math_eval446000008_fn__446000009_A]()) }

func A_arbace_math_exp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_exp_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_exp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_exp_A_New()}; return nil }

func A_arbace_math_exp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_exp_A_fn_class)}; return nil }

var A_arbace_math_exp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_exp_A_invoke, New: A_arbace_math_exp_A_new, Get: A_arbace_math_exp_A_get}

var A_arbace_math_exp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$exp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "exp", Go: "arbace/aot_arbace_math.A_arbace_math_exp_A", Source: "math.ae"})

func init() { i := A_arbace_math_exp_A_class.Info(); i.IsInstance = A_arbace_math_exp_A_InstanceOf; i.Init = A_arbace_math_exp_A_Init; i.Table = A_arbace_math_exp_A_members; jrt.RegisterGoType(A_arbace_math_exp_A_class, reflect.TypeFor[A_arbace_math_exp_A]()) }

func A_arbace_math_exp__inliner__446000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_exp__inliner__446000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_exp__inliner__446000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_exp__inliner__446000038_A_New()}; return nil }

func A_arbace_math_exp__inliner__446000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_exp__inliner__446000038_A_fn_class)}; return nil }

var A_arbace_math_exp__inliner__446000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_exp__inliner__446000038_A_invoke, New: A_arbace_math_exp__inliner__446000038_A_new, Get: A_arbace_math_exp__inliner__446000038_A_get}

var A_arbace_math_exp__inliner__446000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$exp__inliner__446000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "exp__inliner__446000038", Go: "arbace/aot_arbace_math.A_arbace_math_exp__inliner__446000038_A", Source: "math.ae"})

func init() { i := A_arbace_math_exp__inliner__446000038_A_class.Info(); i.IsInstance = A_arbace_math_exp__inliner__446000038_A_InstanceOf; i.Init = A_arbace_math_exp__inliner__446000038_A_Init; i.Table = A_arbace_math_exp__inliner__446000038_A_members; jrt.RegisterGoType(A_arbace_math_exp__inliner__446000038_A_class, reflect.TypeFor[A_arbace_math_exp__inliner__446000038_A]()) }

func A_arbace_math_expm1_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_expm1_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_expm1_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_expm1_A_New()}; return nil }

func A_arbace_math_expm1_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_expm1_A_fn_class)}; return nil }

var A_arbace_math_expm1_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_expm1_A_invoke, New: A_arbace_math_expm1_A_new, Get: A_arbace_math_expm1_A_get}

var A_arbace_math_expm1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$expm1", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "expm1", Go: "arbace/aot_arbace_math.A_arbace_math_expm1_A", Source: "math.ae"})

func init() { i := A_arbace_math_expm1_A_class.Info(); i.IsInstance = A_arbace_math_expm1_A_InstanceOf; i.Init = A_arbace_math_expm1_A_Init; i.Table = A_arbace_math_expm1_A_members; jrt.RegisterGoType(A_arbace_math_expm1_A_class, reflect.TypeFor[A_arbace_math_expm1_A]()) }

func A_arbace_math_expm1__inliner__446000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_expm1__inliner__446000119_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_expm1__inliner__446000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_expm1__inliner__446000119_A_New()}; return nil }

func A_arbace_math_expm1__inliner__446000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_expm1__inliner__446000119_A_fn_class)}; return nil }

var A_arbace_math_expm1__inliner__446000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_expm1__inliner__446000119_A_invoke, New: A_arbace_math_expm1__inliner__446000119_A_new, Get: A_arbace_math_expm1__inliner__446000119_A_get}

var A_arbace_math_expm1__inliner__446000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$expm1__inliner__446000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "expm1__inliner__446000119", Go: "arbace/aot_arbace_math.A_arbace_math_expm1__inliner__446000119_A", Source: "math.ae"})

func init() { i := A_arbace_math_expm1__inliner__446000119_A_class.Info(); i.IsInstance = A_arbace_math_expm1__inliner__446000119_A_InstanceOf; i.Init = A_arbace_math_expm1__inliner__446000119_A_Init; i.Table = A_arbace_math_expm1__inliner__446000119_A_members; jrt.RegisterGoType(A_arbace_math_expm1__inliner__446000119_A_class, reflect.TypeFor[A_arbace_math_expm1__inliner__446000119_A]()) }

func A_arbace_math_floor_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_floor_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_floor_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_floor_A_New()}; return nil }

func A_arbace_math_floor_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_floor_A_fn_class)}; return nil }

var A_arbace_math_floor_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_floor_A_invoke, New: A_arbace_math_floor_A_new, Get: A_arbace_math_floor_A_get}

var A_arbace_math_floor_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$floor", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "floor", Go: "arbace/aot_arbace_math.A_arbace_math_floor_A", Source: "math.ae"})

func init() { i := A_arbace_math_floor_A_class.Info(); i.IsInstance = A_arbace_math_floor_A_InstanceOf; i.Init = A_arbace_math_floor_A_Init; i.Table = A_arbace_math_floor_A_members; jrt.RegisterGoType(A_arbace_math_floor_A_class, reflect.TypeFor[A_arbace_math_floor_A]()) }

func A_arbace_math_floor__inliner__446000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_floor__inliner__446000059_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_floor__inliner__446000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_floor__inliner__446000059_A_New()}; return nil }

func A_arbace_math_floor__inliner__446000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_floor__inliner__446000059_A_fn_class)}; return nil }

var A_arbace_math_floor__inliner__446000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_floor__inliner__446000059_A_invoke, New: A_arbace_math_floor__inliner__446000059_A_new, Get: A_arbace_math_floor__inliner__446000059_A_get}

var A_arbace_math_floor__inliner__446000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$floor__inliner__446000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "floor__inliner__446000059", Go: "arbace/aot_arbace_math.A_arbace_math_floor__inliner__446000059_A", Source: "math.ae"})

func init() { i := A_arbace_math_floor__inliner__446000059_A_class.Info(); i.IsInstance = A_arbace_math_floor__inliner__446000059_A_InstanceOf; i.Init = A_arbace_math_floor__inliner__446000059_A_Init; i.Table = A_arbace_math_floor__inliner__446000059_A_members; jrt.RegisterGoType(A_arbace_math_floor__inliner__446000059_A_class, reflect.TypeFor[A_arbace_math_floor__inliner__446000059_A]()) }

func A_arbace_math_floor_div_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_floor_div_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_floor_div_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_floor_div_A_New()}; return nil }

func A_arbace_math_floor_div_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_floor_div_A_fn_class)}; return nil }

var A_arbace_math_floor_div_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_floor_div_A_invoke, New: A_arbace_math_floor_div_A_new, Get: A_arbace_math_floor_div_A_get}

var A_arbace_math_floor_div_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$floor_div", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "floor_div", Go: "arbace/aot_arbace_math.A_arbace_math_floor_div_A", Source: "math.ae"})

func init() { i := A_arbace_math_floor_div_A_class.Info(); i.IsInstance = A_arbace_math_floor_div_A_InstanceOf; i.Init = A_arbace_math_floor_div_A_Init; i.Table = A_arbace_math_floor_div_A_members; jrt.RegisterGoType(A_arbace_math_floor_div_A_class, reflect.TypeFor[A_arbace_math_floor_div_A]()) }

func A_arbace_math_floor_div__inliner__446000095_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_floor_div__inliner__446000095_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_floor_div__inliner__446000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_floor_div__inliner__446000095_A_New()}; return nil }

func A_arbace_math_floor_div__inliner__446000095_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_floor_div__inliner__446000095_A_fn_class)}; return nil }

var A_arbace_math_floor_div__inliner__446000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_floor_div__inliner__446000095_A_invoke, New: A_arbace_math_floor_div__inliner__446000095_A_new, Get: A_arbace_math_floor_div__inliner__446000095_A_get}

var A_arbace_math_floor_div__inliner__446000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$floor_div__inliner__446000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "floor_div__inliner__446000095", Go: "arbace/aot_arbace_math.A_arbace_math_floor_div__inliner__446000095_A", Source: "math.ae"})

func init() { i := A_arbace_math_floor_div__inliner__446000095_A_class.Info(); i.IsInstance = A_arbace_math_floor_div__inliner__446000095_A_InstanceOf; i.Init = A_arbace_math_floor_div__inliner__446000095_A_Init; i.Table = A_arbace_math_floor_div__inliner__446000095_A_members; jrt.RegisterGoType(A_arbace_math_floor_div__inliner__446000095_A_class, reflect.TypeFor[A_arbace_math_floor_div__inliner__446000095_A]()) }

func A_arbace_math_floor_mod_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_floor_mod_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_floor_mod_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_floor_mod_A_New()}; return nil }

func A_arbace_math_floor_mod_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_floor_mod_A_fn_class)}; return nil }

var A_arbace_math_floor_mod_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_floor_mod_A_invoke, New: A_arbace_math_floor_mod_A_new, Get: A_arbace_math_floor_mod_A_get}

var A_arbace_math_floor_mod_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$floor_mod", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "floor_mod", Go: "arbace/aot_arbace_math.A_arbace_math_floor_mod_A", Source: "math.ae"})

func init() { i := A_arbace_math_floor_mod_A_class.Info(); i.IsInstance = A_arbace_math_floor_mod_A_InstanceOf; i.Init = A_arbace_math_floor_mod_A_Init; i.Table = A_arbace_math_floor_mod_A_members; jrt.RegisterGoType(A_arbace_math_floor_mod_A_class, reflect.TypeFor[A_arbace_math_floor_mod_A]()) }

func A_arbace_math_floor_mod__inliner__446000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_floor_mod__inliner__446000098_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_floor_mod__inliner__446000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_floor_mod__inliner__446000098_A_New()}; return nil }

func A_arbace_math_floor_mod__inliner__446000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_floor_mod__inliner__446000098_A_fn_class)}; return nil }

var A_arbace_math_floor_mod__inliner__446000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_floor_mod__inliner__446000098_A_invoke, New: A_arbace_math_floor_mod__inliner__446000098_A_new, Get: A_arbace_math_floor_mod__inliner__446000098_A_get}

var A_arbace_math_floor_mod__inliner__446000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$floor_mod__inliner__446000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "floor_mod__inliner__446000098", Go: "arbace/aot_arbace_math.A_arbace_math_floor_mod__inliner__446000098_A", Source: "math.ae"})

func init() { i := A_arbace_math_floor_mod__inliner__446000098_A_class.Info(); i.IsInstance = A_arbace_math_floor_mod__inliner__446000098_A_InstanceOf; i.Init = A_arbace_math_floor_mod__inliner__446000098_A_Init; i.Table = A_arbace_math_floor_mod__inliner__446000098_A_members; jrt.RegisterGoType(A_arbace_math_floor_mod__inliner__446000098_A_class, reflect.TypeFor[A_arbace_math_floor_mod__inliner__446000098_A]()) }

func A_arbace_math_get_exponent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_get_exponent_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_get_exponent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_get_exponent_A_New()}; return nil }

func A_arbace_math_get_exponent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_get_exponent_A_fn_class)}; return nil }

var A_arbace_math_get_exponent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_get_exponent_A_invoke, New: A_arbace_math_get_exponent_A_new, Get: A_arbace_math_get_exponent_A_get}

var A_arbace_math_get_exponent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$get_exponent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "get_exponent", Go: "arbace/aot_arbace_math.A_arbace_math_get_exponent_A", Source: "math.ae"})

func init() { i := A_arbace_math_get_exponent_A_class.Info(); i.IsInstance = A_arbace_math_get_exponent_A_InstanceOf; i.Init = A_arbace_math_get_exponent_A_Init; i.Table = A_arbace_math_get_exponent_A_members; jrt.RegisterGoType(A_arbace_math_get_exponent_A_class, reflect.TypeFor[A_arbace_math_get_exponent_A]()) }

func A_arbace_math_get_exponent__inliner__446000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_get_exponent__inliner__446000128_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_get_exponent__inliner__446000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_get_exponent__inliner__446000128_A_New()}; return nil }

func A_arbace_math_get_exponent__inliner__446000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_get_exponent__inliner__446000128_A_fn_class)}; return nil }

var A_arbace_math_get_exponent__inliner__446000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_get_exponent__inliner__446000128_A_invoke, New: A_arbace_math_get_exponent__inliner__446000128_A_new, Get: A_arbace_math_get_exponent__inliner__446000128_A_get}

var A_arbace_math_get_exponent__inliner__446000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$get_exponent__inliner__446000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "get_exponent__inliner__446000128", Go: "arbace/aot_arbace_math.A_arbace_math_get_exponent__inliner__446000128_A", Source: "math.ae"})

func init() { i := A_arbace_math_get_exponent__inliner__446000128_A_class.Info(); i.IsInstance = A_arbace_math_get_exponent__inliner__446000128_A_InstanceOf; i.Init = A_arbace_math_get_exponent__inliner__446000128_A_Init; i.Table = A_arbace_math_get_exponent__inliner__446000128_A_members; jrt.RegisterGoType(A_arbace_math_get_exponent__inliner__446000128_A_class, reflect.TypeFor[A_arbace_math_get_exponent__inliner__446000128_A]()) }

func A_arbace_math_hypot_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_hypot_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_hypot_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_hypot_A_New()}; return nil }

func A_arbace_math_hypot_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_hypot_A_fn_class)}; return nil }

var A_arbace_math_hypot_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_hypot_A_invoke, New: A_arbace_math_hypot_A_new, Get: A_arbace_math_hypot_A_get}

var A_arbace_math_hypot_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$hypot", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "hypot", Go: "arbace/aot_arbace_math.A_arbace_math_hypot_A", Source: "math.ae"})

func init() { i := A_arbace_math_hypot_A_class.Info(); i.IsInstance = A_arbace_math_hypot_A_InstanceOf; i.Init = A_arbace_math_hypot_A_Init; i.Table = A_arbace_math_hypot_A_members; jrt.RegisterGoType(A_arbace_math_hypot_A_class, reflect.TypeFor[A_arbace_math_hypot_A]()) }

func A_arbace_math_hypot__inliner__446000116_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_hypot__inliner__446000116_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_hypot__inliner__446000116_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_hypot__inliner__446000116_A_New()}; return nil }

func A_arbace_math_hypot__inliner__446000116_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_hypot__inliner__446000116_A_fn_class)}; return nil }

var A_arbace_math_hypot__inliner__446000116_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_hypot__inliner__446000116_A_invoke, New: A_arbace_math_hypot__inliner__446000116_A_new, Get: A_arbace_math_hypot__inliner__446000116_A_get}

var A_arbace_math_hypot__inliner__446000116_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$hypot__inliner__446000116", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "hypot__inliner__446000116", Go: "arbace/aot_arbace_math.A_arbace_math_hypot__inliner__446000116_A", Source: "math.ae"})

func init() { i := A_arbace_math_hypot__inliner__446000116_A_class.Info(); i.IsInstance = A_arbace_math_hypot__inliner__446000116_A_InstanceOf; i.Init = A_arbace_math_hypot__inliner__446000116_A_Init; i.Table = A_arbace_math_hypot__inliner__446000116_A_members; jrt.RegisterGoType(A_arbace_math_hypot__inliner__446000116_A_class, reflect.TypeFor[A_arbace_math_hypot__inliner__446000116_A]()) }

func A_arbace_math_increment_exact_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_increment_exact_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_increment_exact_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_increment_exact_A_New()}; return nil }

func A_arbace_math_increment_exact_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_increment_exact_A_fn_class)}; return nil }

var A_arbace_math_increment_exact_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_increment_exact_A_invoke, New: A_arbace_math_increment_exact_A_new, Get: A_arbace_math_increment_exact_A_get}

var A_arbace_math_increment_exact_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$increment_exact", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "increment_exact", Go: "arbace/aot_arbace_math.A_arbace_math_increment_exact_A", Source: "math.ae"})

func init() { i := A_arbace_math_increment_exact_A_class.Info(); i.IsInstance = A_arbace_math_increment_exact_A_InstanceOf; i.Init = A_arbace_math_increment_exact_A_Init; i.Table = A_arbace_math_increment_exact_A_members; jrt.RegisterGoType(A_arbace_math_increment_exact_A_class, reflect.TypeFor[A_arbace_math_increment_exact_A]()) }

func A_arbace_math_increment_exact__inliner__446000086_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_increment_exact__inliner__446000086_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_increment_exact__inliner__446000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_increment_exact__inliner__446000086_A_New()}; return nil }

func A_arbace_math_increment_exact__inliner__446000086_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_increment_exact__inliner__446000086_A_fn_class)}; return nil }

var A_arbace_math_increment_exact__inliner__446000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_increment_exact__inliner__446000086_A_invoke, New: A_arbace_math_increment_exact__inliner__446000086_A_new, Get: A_arbace_math_increment_exact__inliner__446000086_A_get}

var A_arbace_math_increment_exact__inliner__446000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$increment_exact__inliner__446000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "increment_exact__inliner__446000086", Go: "arbace/aot_arbace_math.A_arbace_math_increment_exact__inliner__446000086_A", Source: "math.ae"})

func init() { i := A_arbace_math_increment_exact__inliner__446000086_A_class.Info(); i.IsInstance = A_arbace_math_increment_exact__inliner__446000086_A_InstanceOf; i.Init = A_arbace_math_increment_exact__inliner__446000086_A_Init; i.Table = A_arbace_math_increment_exact__inliner__446000086_A_members; jrt.RegisterGoType(A_arbace_math_increment_exact__inliner__446000086_A_class, reflect.TypeFor[A_arbace_math_increment_exact__inliner__446000086_A]()) }

func A_arbace_math_log_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_log_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_log_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_log_A_New()}; return nil }

func A_arbace_math_log_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_log_A_fn_class)}; return nil }

var A_arbace_math_log_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_log_A_invoke, New: A_arbace_math_log_A_new, Get: A_arbace_math_log_A_get}

var A_arbace_math_log_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$log", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "log", Go: "arbace/aot_arbace_math.A_arbace_math_log_A", Source: "math.ae"})

func init() { i := A_arbace_math_log_A_class.Info(); i.IsInstance = A_arbace_math_log_A_InstanceOf; i.Init = A_arbace_math_log_A_Init; i.Table = A_arbace_math_log_A_members; jrt.RegisterGoType(A_arbace_math_log_A_class, reflect.TypeFor[A_arbace_math_log_A]()) }

func A_arbace_math_log10_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_log10_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_log10_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_log10_A_New()}; return nil }

func A_arbace_math_log10_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_log10_A_fn_class)}; return nil }

var A_arbace_math_log10_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_log10_A_invoke, New: A_arbace_math_log10_A_new, Get: A_arbace_math_log10_A_get}

var A_arbace_math_log10_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$log10", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "log10", Go: "arbace/aot_arbace_math.A_arbace_math_log10_A", Source: "math.ae"})

func init() { i := A_arbace_math_log10_A_class.Info(); i.IsInstance = A_arbace_math_log10_A_InstanceOf; i.Init = A_arbace_math_log10_A_Init; i.Table = A_arbace_math_log10_A_members; jrt.RegisterGoType(A_arbace_math_log10_A_class, reflect.TypeFor[A_arbace_math_log10_A]()) }

func A_arbace_math_log10__inliner__446000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_log10__inliner__446000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_log10__inliner__446000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_log10__inliner__446000044_A_New()}; return nil }

func A_arbace_math_log10__inliner__446000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_log10__inliner__446000044_A_fn_class)}; return nil }

var A_arbace_math_log10__inliner__446000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_log10__inliner__446000044_A_invoke, New: A_arbace_math_log10__inliner__446000044_A_new, Get: A_arbace_math_log10__inliner__446000044_A_get}

var A_arbace_math_log10__inliner__446000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$log10__inliner__446000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "log10__inliner__446000044", Go: "arbace/aot_arbace_math.A_arbace_math_log10__inliner__446000044_A", Source: "math.ae"})

func init() { i := A_arbace_math_log10__inliner__446000044_A_class.Info(); i.IsInstance = A_arbace_math_log10__inliner__446000044_A_InstanceOf; i.Init = A_arbace_math_log10__inliner__446000044_A_Init; i.Table = A_arbace_math_log10__inliner__446000044_A_members; jrt.RegisterGoType(A_arbace_math_log10__inliner__446000044_A_class, reflect.TypeFor[A_arbace_math_log10__inliner__446000044_A]()) }

func A_arbace_math_log1p_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_log1p_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_log1p_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_log1p_A_New()}; return nil }

func A_arbace_math_log1p_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_log1p_A_fn_class)}; return nil }

var A_arbace_math_log1p_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_log1p_A_invoke, New: A_arbace_math_log1p_A_new, Get: A_arbace_math_log1p_A_get}

var A_arbace_math_log1p_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$log1p", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "log1p", Go: "arbace/aot_arbace_math.A_arbace_math_log1p_A", Source: "math.ae"})

func init() { i := A_arbace_math_log1p_A_class.Info(); i.IsInstance = A_arbace_math_log1p_A_InstanceOf; i.Init = A_arbace_math_log1p_A_Init; i.Table = A_arbace_math_log1p_A_members; jrt.RegisterGoType(A_arbace_math_log1p_A_class, reflect.TypeFor[A_arbace_math_log1p_A]()) }

func A_arbace_math_log1p__inliner__446000122_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_log1p__inliner__446000122_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_log1p__inliner__446000122_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_log1p__inliner__446000122_A_New()}; return nil }

func A_arbace_math_log1p__inliner__446000122_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_log1p__inliner__446000122_A_fn_class)}; return nil }

var A_arbace_math_log1p__inliner__446000122_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_log1p__inliner__446000122_A_invoke, New: A_arbace_math_log1p__inliner__446000122_A_new, Get: A_arbace_math_log1p__inliner__446000122_A_get}

var A_arbace_math_log1p__inliner__446000122_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$log1p__inliner__446000122", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "log1p__inliner__446000122", Go: "arbace/aot_arbace_math.A_arbace_math_log1p__inliner__446000122_A", Source: "math.ae"})

func init() { i := A_arbace_math_log1p__inliner__446000122_A_class.Info(); i.IsInstance = A_arbace_math_log1p__inliner__446000122_A_InstanceOf; i.Init = A_arbace_math_log1p__inliner__446000122_A_Init; i.Table = A_arbace_math_log1p__inliner__446000122_A_members; jrt.RegisterGoType(A_arbace_math_log1p__inliner__446000122_A_class, reflect.TypeFor[A_arbace_math_log1p__inliner__446000122_A]()) }

func A_arbace_math_log__inliner__446000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_log__inliner__446000041_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_log__inliner__446000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_log__inliner__446000041_A_New()}; return nil }

func A_arbace_math_log__inliner__446000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_log__inliner__446000041_A_fn_class)}; return nil }

var A_arbace_math_log__inliner__446000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_log__inliner__446000041_A_invoke, New: A_arbace_math_log__inliner__446000041_A_new, Get: A_arbace_math_log__inliner__446000041_A_get}

var A_arbace_math_log__inliner__446000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$log__inliner__446000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "log__inliner__446000041", Go: "arbace/aot_arbace_math.A_arbace_math_log__inliner__446000041_A", Source: "math.ae"})

func init() { i := A_arbace_math_log__inliner__446000041_A_class.Info(); i.IsInstance = A_arbace_math_log__inliner__446000041_A_InstanceOf; i.Init = A_arbace_math_log__inliner__446000041_A_Init; i.Table = A_arbace_math_log__inliner__446000041_A_members; jrt.RegisterGoType(A_arbace_math_log__inliner__446000041_A_class, reflect.TypeFor[A_arbace_math_log__inliner__446000041_A]()) }

func A_arbace_math_multiply_exact_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_multiply_exact_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_multiply_exact_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_multiply_exact_A_New()}; return nil }

func A_arbace_math_multiply_exact_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_multiply_exact_A_fn_class)}; return nil }

var A_arbace_math_multiply_exact_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_multiply_exact_A_invoke, New: A_arbace_math_multiply_exact_A_new, Get: A_arbace_math_multiply_exact_A_get}

var A_arbace_math_multiply_exact_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$multiply_exact", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "multiply_exact", Go: "arbace/aot_arbace_math.A_arbace_math_multiply_exact_A", Source: "math.ae"})

func init() { i := A_arbace_math_multiply_exact_A_class.Info(); i.IsInstance = A_arbace_math_multiply_exact_A_InstanceOf; i.Init = A_arbace_math_multiply_exact_A_Init; i.Table = A_arbace_math_multiply_exact_A_members; jrt.RegisterGoType(A_arbace_math_multiply_exact_A_class, reflect.TypeFor[A_arbace_math_multiply_exact_A]()) }

func A_arbace_math_multiply_exact__inliner__446000083_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_multiply_exact__inliner__446000083_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_multiply_exact__inliner__446000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_multiply_exact__inliner__446000083_A_New()}; return nil }

func A_arbace_math_multiply_exact__inliner__446000083_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_multiply_exact__inliner__446000083_A_fn_class)}; return nil }

var A_arbace_math_multiply_exact__inliner__446000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_multiply_exact__inliner__446000083_A_invoke, New: A_arbace_math_multiply_exact__inliner__446000083_A_new, Get: A_arbace_math_multiply_exact__inliner__446000083_A_get}

var A_arbace_math_multiply_exact__inliner__446000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$multiply_exact__inliner__446000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "multiply_exact__inliner__446000083", Go: "arbace/aot_arbace_math.A_arbace_math_multiply_exact__inliner__446000083_A", Source: "math.ae"})

func init() { i := A_arbace_math_multiply_exact__inliner__446000083_A_class.Info(); i.IsInstance = A_arbace_math_multiply_exact__inliner__446000083_A_InstanceOf; i.Init = A_arbace_math_multiply_exact__inliner__446000083_A_Init; i.Table = A_arbace_math_multiply_exact__inliner__446000083_A_members; jrt.RegisterGoType(A_arbace_math_multiply_exact__inliner__446000083_A_class, reflect.TypeFor[A_arbace_math_multiply_exact__inliner__446000083_A]()) }

func A_arbace_math_negate_exact_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_negate_exact_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_negate_exact_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_negate_exact_A_New()}; return nil }

func A_arbace_math_negate_exact_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_negate_exact_A_fn_class)}; return nil }

var A_arbace_math_negate_exact_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_negate_exact_A_invoke, New: A_arbace_math_negate_exact_A_new, Get: A_arbace_math_negate_exact_A_get}

var A_arbace_math_negate_exact_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$negate_exact", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "negate_exact", Go: "arbace/aot_arbace_math.A_arbace_math_negate_exact_A", Source: "math.ae"})

func init() { i := A_arbace_math_negate_exact_A_class.Info(); i.IsInstance = A_arbace_math_negate_exact_A_InstanceOf; i.Init = A_arbace_math_negate_exact_A_Init; i.Table = A_arbace_math_negate_exact_A_members; jrt.RegisterGoType(A_arbace_math_negate_exact_A_class, reflect.TypeFor[A_arbace_math_negate_exact_A]()) }

func A_arbace_math_negate_exact__inliner__446000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_negate_exact__inliner__446000092_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_negate_exact__inliner__446000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_negate_exact__inliner__446000092_A_New()}; return nil }

func A_arbace_math_negate_exact__inliner__446000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_negate_exact__inliner__446000092_A_fn_class)}; return nil }

var A_arbace_math_negate_exact__inliner__446000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_negate_exact__inliner__446000092_A_invoke, New: A_arbace_math_negate_exact__inliner__446000092_A_new, Get: A_arbace_math_negate_exact__inliner__446000092_A_get}

var A_arbace_math_negate_exact__inliner__446000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$negate_exact__inliner__446000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "negate_exact__inliner__446000092", Go: "arbace/aot_arbace_math.A_arbace_math_negate_exact__inliner__446000092_A", Source: "math.ae"})

func init() { i := A_arbace_math_negate_exact__inliner__446000092_A_class.Info(); i.IsInstance = A_arbace_math_negate_exact__inliner__446000092_A_InstanceOf; i.Init = A_arbace_math_negate_exact__inliner__446000092_A_Init; i.Table = A_arbace_math_negate_exact__inliner__446000092_A_members; jrt.RegisterGoType(A_arbace_math_negate_exact__inliner__446000092_A_class, reflect.TypeFor[A_arbace_math_negate_exact__inliner__446000092_A]()) }

func A_arbace_math_next_after_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_next_after_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_next_after_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_next_after_A_New()}; return nil }

func A_arbace_math_next_after_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_next_after_A_fn_class)}; return nil }

var A_arbace_math_next_after_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_next_after_A_invoke, New: A_arbace_math_next_after_A_new, Get: A_arbace_math_next_after_A_get}

var A_arbace_math_next_after_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$next_after", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "next_after", Go: "arbace/aot_arbace_math.A_arbace_math_next_after_A", Source: "math.ae"})

func init() { i := A_arbace_math_next_after_A_class.Info(); i.IsInstance = A_arbace_math_next_after_A_InstanceOf; i.Init = A_arbace_math_next_after_A_Init; i.Table = A_arbace_math_next_after_A_members; jrt.RegisterGoType(A_arbace_math_next_after_A_class, reflect.TypeFor[A_arbace_math_next_after_A]()) }

func A_arbace_math_next_after__inliner__446000131_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_next_after__inliner__446000131_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_next_after__inliner__446000131_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_next_after__inliner__446000131_A_New()}; return nil }

func A_arbace_math_next_after__inliner__446000131_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_next_after__inliner__446000131_A_fn_class)}; return nil }

var A_arbace_math_next_after__inliner__446000131_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_next_after__inliner__446000131_A_invoke, New: A_arbace_math_next_after__inliner__446000131_A_new, Get: A_arbace_math_next_after__inliner__446000131_A_get}

var A_arbace_math_next_after__inliner__446000131_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$next_after__inliner__446000131", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "next_after__inliner__446000131", Go: "arbace/aot_arbace_math.A_arbace_math_next_after__inliner__446000131_A", Source: "math.ae"})

func init() { i := A_arbace_math_next_after__inliner__446000131_A_class.Info(); i.IsInstance = A_arbace_math_next_after__inliner__446000131_A_InstanceOf; i.Init = A_arbace_math_next_after__inliner__446000131_A_Init; i.Table = A_arbace_math_next_after__inliner__446000131_A_members; jrt.RegisterGoType(A_arbace_math_next_after__inliner__446000131_A_class, reflect.TypeFor[A_arbace_math_next_after__inliner__446000131_A]()) }

func A_arbace_math_next_down_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_next_down_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_next_down_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_next_down_A_New()}; return nil }

func A_arbace_math_next_down_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_next_down_A_fn_class)}; return nil }

var A_arbace_math_next_down_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_next_down_A_invoke, New: A_arbace_math_next_down_A_new, Get: A_arbace_math_next_down_A_get}

var A_arbace_math_next_down_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$next_down", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "next_down", Go: "arbace/aot_arbace_math.A_arbace_math_next_down_A", Source: "math.ae"})

func init() { i := A_arbace_math_next_down_A_class.Info(); i.IsInstance = A_arbace_math_next_down_A_InstanceOf; i.Init = A_arbace_math_next_down_A_Init; i.Table = A_arbace_math_next_down_A_members; jrt.RegisterGoType(A_arbace_math_next_down_A_class, reflect.TypeFor[A_arbace_math_next_down_A]()) }

func A_arbace_math_next_down__inliner__446000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_next_down__inliner__446000137_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_next_down__inliner__446000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_next_down__inliner__446000137_A_New()}; return nil }

func A_arbace_math_next_down__inliner__446000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_next_down__inliner__446000137_A_fn_class)}; return nil }

var A_arbace_math_next_down__inliner__446000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_next_down__inliner__446000137_A_invoke, New: A_arbace_math_next_down__inliner__446000137_A_new, Get: A_arbace_math_next_down__inliner__446000137_A_get}

var A_arbace_math_next_down__inliner__446000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$next_down__inliner__446000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "next_down__inliner__446000137", Go: "arbace/aot_arbace_math.A_arbace_math_next_down__inliner__446000137_A", Source: "math.ae"})

func init() { i := A_arbace_math_next_down__inliner__446000137_A_class.Info(); i.IsInstance = A_arbace_math_next_down__inliner__446000137_A_InstanceOf; i.Init = A_arbace_math_next_down__inliner__446000137_A_Init; i.Table = A_arbace_math_next_down__inliner__446000137_A_members; jrt.RegisterGoType(A_arbace_math_next_down__inliner__446000137_A_class, reflect.TypeFor[A_arbace_math_next_down__inliner__446000137_A]()) }

func A_arbace_math_next_up_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_next_up_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_next_up_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_next_up_A_New()}; return nil }

func A_arbace_math_next_up_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_next_up_A_fn_class)}; return nil }

var A_arbace_math_next_up_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_next_up_A_invoke, New: A_arbace_math_next_up_A_new, Get: A_arbace_math_next_up_A_get}

var A_arbace_math_next_up_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$next_up", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "next_up", Go: "arbace/aot_arbace_math.A_arbace_math_next_up_A", Source: "math.ae"})

func init() { i := A_arbace_math_next_up_A_class.Info(); i.IsInstance = A_arbace_math_next_up_A_InstanceOf; i.Init = A_arbace_math_next_up_A_Init; i.Table = A_arbace_math_next_up_A_members; jrt.RegisterGoType(A_arbace_math_next_up_A_class, reflect.TypeFor[A_arbace_math_next_up_A]()) }

func A_arbace_math_next_up__inliner__446000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_next_up__inliner__446000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_next_up__inliner__446000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_next_up__inliner__446000134_A_New()}; return nil }

func A_arbace_math_next_up__inliner__446000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_next_up__inliner__446000134_A_fn_class)}; return nil }

var A_arbace_math_next_up__inliner__446000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_next_up__inliner__446000134_A_invoke, New: A_arbace_math_next_up__inliner__446000134_A_new, Get: A_arbace_math_next_up__inliner__446000134_A_get}

var A_arbace_math_next_up__inliner__446000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$next_up__inliner__446000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "next_up__inliner__446000134", Go: "arbace/aot_arbace_math.A_arbace_math_next_up__inliner__446000134_A", Source: "math.ae"})

func init() { i := A_arbace_math_next_up__inliner__446000134_A_class.Info(); i.IsInstance = A_arbace_math_next_up__inliner__446000134_A_InstanceOf; i.Init = A_arbace_math_next_up__inliner__446000134_A_Init; i.Table = A_arbace_math_next_up__inliner__446000134_A_members; jrt.RegisterGoType(A_arbace_math_next_up__inliner__446000134_A_class, reflect.TypeFor[A_arbace_math_next_up__inliner__446000134_A]()) }

func A_arbace_math_pow_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_pow_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_pow_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_pow_A_New()}; return nil }

func A_arbace_math_pow_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_pow_A_fn_class)}; return nil }

var A_arbace_math_pow_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_pow_A_invoke, New: A_arbace_math_pow_A_new, Get: A_arbace_math_pow_A_get}

var A_arbace_math_pow_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$pow", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "pow", Go: "arbace/aot_arbace_math.A_arbace_math_pow_A", Source: "math.ae"})

func init() { i := A_arbace_math_pow_A_class.Info(); i.IsInstance = A_arbace_math_pow_A_InstanceOf; i.Init = A_arbace_math_pow_A_Init; i.Table = A_arbace_math_pow_A_members; jrt.RegisterGoType(A_arbace_math_pow_A_class, reflect.TypeFor[A_arbace_math_pow_A]()) }

func A_arbace_math_pow__inliner__446000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_pow__inliner__446000068_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_pow__inliner__446000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_pow__inliner__446000068_A_New()}; return nil }

func A_arbace_math_pow__inliner__446000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_pow__inliner__446000068_A_fn_class)}; return nil }

var A_arbace_math_pow__inliner__446000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_pow__inliner__446000068_A_invoke, New: A_arbace_math_pow__inliner__446000068_A_new, Get: A_arbace_math_pow__inliner__446000068_A_get}

var A_arbace_math_pow__inliner__446000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$pow__inliner__446000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "pow__inliner__446000068", Go: "arbace/aot_arbace_math.A_arbace_math_pow__inliner__446000068_A", Source: "math.ae"})

func init() { i := A_arbace_math_pow__inliner__446000068_A_class.Info(); i.IsInstance = A_arbace_math_pow__inliner__446000068_A_InstanceOf; i.Init = A_arbace_math_pow__inliner__446000068_A_Init; i.Table = A_arbace_math_pow__inliner__446000068_A_members; jrt.RegisterGoType(A_arbace_math_pow__inliner__446000068_A_class, reflect.TypeFor[A_arbace_math_pow__inliner__446000068_A]()) }

func A_arbace_math_random_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_random_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_math_random_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_random_A_New()}; return nil }

func A_arbace_math_random_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_random_A_fn_class)}; return nil }

var A_arbace_math_random_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_random_A_invoke, New: A_arbace_math_random_A_new, Get: A_arbace_math_random_A_get}

var A_arbace_math_random_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$random", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_math_A_class, Simple: "random", Go: "arbace/aot_arbace_math.A_arbace_math_random_A", Source: "math.ae"})

func init() { i := A_arbace_math_random_A_class.Info(); i.IsInstance = A_arbace_math_random_A_InstanceOf; i.Init = A_arbace_math_random_A_Init; i.Table = A_arbace_math_random_A_members; jrt.RegisterGoType(A_arbace_math_random_A_class, reflect.TypeFor[A_arbace_math_random_A]()) }

func A_arbace_math_random__inliner__446000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_random__inliner__446000074_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_math_random__inliner__446000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_random__inliner__446000074_A_New()}; return nil }

func A_arbace_math_random__inliner__446000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_random__inliner__446000074_A_fn_class)}; return nil }

var A_arbace_math_random__inliner__446000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_random__inliner__446000074_A_invoke, New: A_arbace_math_random__inliner__446000074_A_new, Get: A_arbace_math_random__inliner__446000074_A_get}

var A_arbace_math_random__inliner__446000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$random__inliner__446000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_math_A_class, Simple: "random__inliner__446000074", Go: "arbace/aot_arbace_math.A_arbace_math_random__inliner__446000074_A", Source: "math.ae"})

func init() { i := A_arbace_math_random__inliner__446000074_A_class.Info(); i.IsInstance = A_arbace_math_random__inliner__446000074_A_InstanceOf; i.Init = A_arbace_math_random__inliner__446000074_A_Init; i.Table = A_arbace_math_random__inliner__446000074_A_members; jrt.RegisterGoType(A_arbace_math_random__inliner__446000074_A_class, reflect.TypeFor[A_arbace_math_random__inliner__446000074_A]()) }

func A_arbace_math_rint_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_rint_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_rint_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_rint_A_New()}; return nil }

func A_arbace_math_rint_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_rint_A_fn_class)}; return nil }

var A_arbace_math_rint_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_rint_A_invoke, New: A_arbace_math_rint_A_new, Get: A_arbace_math_rint_A_get}

var A_arbace_math_rint_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$rint", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "rint", Go: "arbace/aot_arbace_math.A_arbace_math_rint_A", Source: "math.ae"})

func init() { i := A_arbace_math_rint_A_class.Info(); i.IsInstance = A_arbace_math_rint_A_InstanceOf; i.Init = A_arbace_math_rint_A_Init; i.Table = A_arbace_math_rint_A_members; jrt.RegisterGoType(A_arbace_math_rint_A_class, reflect.TypeFor[A_arbace_math_rint_A]()) }

func A_arbace_math_rint__inliner__446000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_rint__inliner__446000062_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_rint__inliner__446000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_rint__inliner__446000062_A_New()}; return nil }

func A_arbace_math_rint__inliner__446000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_rint__inliner__446000062_A_fn_class)}; return nil }

var A_arbace_math_rint__inliner__446000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_rint__inliner__446000062_A_invoke, New: A_arbace_math_rint__inliner__446000062_A_new, Get: A_arbace_math_rint__inliner__446000062_A_get}

var A_arbace_math_rint__inliner__446000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$rint__inliner__446000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "rint__inliner__446000062", Go: "arbace/aot_arbace_math.A_arbace_math_rint__inliner__446000062_A", Source: "math.ae"})

func init() { i := A_arbace_math_rint__inliner__446000062_A_class.Info(); i.IsInstance = A_arbace_math_rint__inliner__446000062_A_InstanceOf; i.Init = A_arbace_math_rint__inliner__446000062_A_Init; i.Table = A_arbace_math_rint__inliner__446000062_A_members; jrt.RegisterGoType(A_arbace_math_rint__inliner__446000062_A_class, reflect.TypeFor[A_arbace_math_rint__inliner__446000062_A]()) }

func A_arbace_math_round_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_round_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_round_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_round_A_New()}; return nil }

func A_arbace_math_round_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_round_A_fn_class)}; return nil }

var A_arbace_math_round_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_round_A_invoke, New: A_arbace_math_round_A_new, Get: A_arbace_math_round_A_get}

var A_arbace_math_round_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$round", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "round", Go: "arbace/aot_arbace_math.A_arbace_math_round_A", Source: "math.ae"})

func init() { i := A_arbace_math_round_A_class.Info(); i.IsInstance = A_arbace_math_round_A_InstanceOf; i.Init = A_arbace_math_round_A_Init; i.Table = A_arbace_math_round_A_members; jrt.RegisterGoType(A_arbace_math_round_A_class, reflect.TypeFor[A_arbace_math_round_A]()) }

func A_arbace_math_round__inliner__446000071_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_round__inliner__446000071_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_round__inliner__446000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_round__inliner__446000071_A_New()}; return nil }

func A_arbace_math_round__inliner__446000071_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_round__inliner__446000071_A_fn_class)}; return nil }

var A_arbace_math_round__inliner__446000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_round__inliner__446000071_A_invoke, New: A_arbace_math_round__inliner__446000071_A_new, Get: A_arbace_math_round__inliner__446000071_A_get}

var A_arbace_math_round__inliner__446000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$round__inliner__446000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "round__inliner__446000071", Go: "arbace/aot_arbace_math.A_arbace_math_round__inliner__446000071_A", Source: "math.ae"})

func init() { i := A_arbace_math_round__inliner__446000071_A_class.Info(); i.IsInstance = A_arbace_math_round__inliner__446000071_A_InstanceOf; i.Init = A_arbace_math_round__inliner__446000071_A_Init; i.Table = A_arbace_math_round__inliner__446000071_A_members; jrt.RegisterGoType(A_arbace_math_round__inliner__446000071_A_class, reflect.TypeFor[A_arbace_math_round__inliner__446000071_A]()) }

func A_arbace_math_scalb_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_scalb_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_scalb_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_scalb_A_New()}; return nil }

func A_arbace_math_scalb_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_scalb_A_fn_class)}; return nil }

var A_arbace_math_scalb_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_scalb_A_invoke, New: A_arbace_math_scalb_A_new, Get: A_arbace_math_scalb_A_get}

var A_arbace_math_scalb_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$scalb", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "scalb", Go: "arbace/aot_arbace_math.A_arbace_math_scalb_A", Source: "math.ae"})

func init() { i := A_arbace_math_scalb_A_class.Info(); i.IsInstance = A_arbace_math_scalb_A_InstanceOf; i.Init = A_arbace_math_scalb_A_Init; i.Table = A_arbace_math_scalb_A_members; jrt.RegisterGoType(A_arbace_math_scalb_A_class, reflect.TypeFor[A_arbace_math_scalb_A]()) }

func A_arbace_math_scalb__inliner__446000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_scalb__inliner__446000140_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_scalb__inliner__446000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_scalb__inliner__446000140_A_New()}; return nil }

func A_arbace_math_scalb__inliner__446000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_scalb__inliner__446000140_A_fn_class)}; return nil }

var A_arbace_math_scalb__inliner__446000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_scalb__inliner__446000140_A_invoke, New: A_arbace_math_scalb__inliner__446000140_A_new, Get: A_arbace_math_scalb__inliner__446000140_A_get}

var A_arbace_math_scalb__inliner__446000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$scalb__inliner__446000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "scalb__inliner__446000140", Go: "arbace/aot_arbace_math.A_arbace_math_scalb__inliner__446000140_A", Source: "math.ae"})

func init() { i := A_arbace_math_scalb__inliner__446000140_A_class.Info(); i.IsInstance = A_arbace_math_scalb__inliner__446000140_A_InstanceOf; i.Init = A_arbace_math_scalb__inliner__446000140_A_Init; i.Table = A_arbace_math_scalb__inliner__446000140_A_members; jrt.RegisterGoType(A_arbace_math_scalb__inliner__446000140_A_class, reflect.TypeFor[A_arbace_math_scalb__inliner__446000140_A]()) }

func A_arbace_math_signum_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_signum_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_signum_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_signum_A_New()}; return nil }

func A_arbace_math_signum_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_signum_A_fn_class)}; return nil }

var A_arbace_math_signum_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_signum_A_invoke, New: A_arbace_math_signum_A_new, Get: A_arbace_math_signum_A_get}

var A_arbace_math_signum_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$signum", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "signum", Go: "arbace/aot_arbace_math.A_arbace_math_signum_A", Source: "math.ae"})

func init() { i := A_arbace_math_signum_A_class.Info(); i.IsInstance = A_arbace_math_signum_A_InstanceOf; i.Init = A_arbace_math_signum_A_Init; i.Table = A_arbace_math_signum_A_members; jrt.RegisterGoType(A_arbace_math_signum_A_class, reflect.TypeFor[A_arbace_math_signum_A]()) }

func A_arbace_math_signum__inliner__446000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_signum__inliner__446000104_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_signum__inliner__446000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_signum__inliner__446000104_A_New()}; return nil }

func A_arbace_math_signum__inliner__446000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_signum__inliner__446000104_A_fn_class)}; return nil }

var A_arbace_math_signum__inliner__446000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_signum__inliner__446000104_A_invoke, New: A_arbace_math_signum__inliner__446000104_A_new, Get: A_arbace_math_signum__inliner__446000104_A_get}

var A_arbace_math_signum__inliner__446000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$signum__inliner__446000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "signum__inliner__446000104", Go: "arbace/aot_arbace_math.A_arbace_math_signum__inliner__446000104_A", Source: "math.ae"})

func init() { i := A_arbace_math_signum__inliner__446000104_A_class.Info(); i.IsInstance = A_arbace_math_signum__inliner__446000104_A_InstanceOf; i.Init = A_arbace_math_signum__inliner__446000104_A_Init; i.Table = A_arbace_math_signum__inliner__446000104_A_members; jrt.RegisterGoType(A_arbace_math_signum__inliner__446000104_A_class, reflect.TypeFor[A_arbace_math_signum__inliner__446000104_A]()) }

func A_arbace_math_sin_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_sin_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_sin_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_sin_A_New()}; return nil }

func A_arbace_math_sin_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_sin_A_fn_class)}; return nil }

var A_arbace_math_sin_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_sin_A_invoke, New: A_arbace_math_sin_A_new, Get: A_arbace_math_sin_A_get}

var A_arbace_math_sin_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$sin", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "sin", Go: "arbace/aot_arbace_math.A_arbace_math_sin_A", Source: "math.ae"})

func init() { i := A_arbace_math_sin_A_class.Info(); i.IsInstance = A_arbace_math_sin_A_InstanceOf; i.Init = A_arbace_math_sin_A_Init; i.Table = A_arbace_math_sin_A_members; jrt.RegisterGoType(A_arbace_math_sin_A_class, reflect.TypeFor[A_arbace_math_sin_A]()) }

func A_arbace_math_sin__inliner__446000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_sin__inliner__446000014_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_sin__inliner__446000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_sin__inliner__446000014_A_New()}; return nil }

func A_arbace_math_sin__inliner__446000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_sin__inliner__446000014_A_fn_class)}; return nil }

var A_arbace_math_sin__inliner__446000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_sin__inliner__446000014_A_invoke, New: A_arbace_math_sin__inliner__446000014_A_new, Get: A_arbace_math_sin__inliner__446000014_A_get}

var A_arbace_math_sin__inliner__446000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$sin__inliner__446000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "sin__inliner__446000014", Go: "arbace/aot_arbace_math.A_arbace_math_sin__inliner__446000014_A", Source: "math.ae"})

func init() { i := A_arbace_math_sin__inliner__446000014_A_class.Info(); i.IsInstance = A_arbace_math_sin__inliner__446000014_A_InstanceOf; i.Init = A_arbace_math_sin__inliner__446000014_A_Init; i.Table = A_arbace_math_sin__inliner__446000014_A_members; jrt.RegisterGoType(A_arbace_math_sin__inliner__446000014_A_class, reflect.TypeFor[A_arbace_math_sin__inliner__446000014_A]()) }

func A_arbace_math_sinh_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_sinh_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_sinh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_sinh_A_New()}; return nil }

func A_arbace_math_sinh_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_sinh_A_fn_class)}; return nil }

var A_arbace_math_sinh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_sinh_A_invoke, New: A_arbace_math_sinh_A_new, Get: A_arbace_math_sinh_A_get}

var A_arbace_math_sinh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$sinh", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "sinh", Go: "arbace/aot_arbace_math.A_arbace_math_sinh_A", Source: "math.ae"})

func init() { i := A_arbace_math_sinh_A_class.Info(); i.IsInstance = A_arbace_math_sinh_A_InstanceOf; i.Init = A_arbace_math_sinh_A_Init; i.Table = A_arbace_math_sinh_A_members; jrt.RegisterGoType(A_arbace_math_sinh_A_class, reflect.TypeFor[A_arbace_math_sinh_A]()) }

func A_arbace_math_sinh__inliner__446000107_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_sinh__inliner__446000107_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_sinh__inliner__446000107_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_sinh__inliner__446000107_A_New()}; return nil }

func A_arbace_math_sinh__inliner__446000107_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_sinh__inliner__446000107_A_fn_class)}; return nil }

var A_arbace_math_sinh__inliner__446000107_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_sinh__inliner__446000107_A_invoke, New: A_arbace_math_sinh__inliner__446000107_A_new, Get: A_arbace_math_sinh__inliner__446000107_A_get}

var A_arbace_math_sinh__inliner__446000107_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$sinh__inliner__446000107", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "sinh__inliner__446000107", Go: "arbace/aot_arbace_math.A_arbace_math_sinh__inliner__446000107_A", Source: "math.ae"})

func init() { i := A_arbace_math_sinh__inliner__446000107_A_class.Info(); i.IsInstance = A_arbace_math_sinh__inliner__446000107_A_InstanceOf; i.Init = A_arbace_math_sinh__inliner__446000107_A_Init; i.Table = A_arbace_math_sinh__inliner__446000107_A_members; jrt.RegisterGoType(A_arbace_math_sinh__inliner__446000107_A_class, reflect.TypeFor[A_arbace_math_sinh__inliner__446000107_A]()) }

func A_arbace_math_sqrt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_sqrt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_sqrt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_sqrt_A_New()}; return nil }

func A_arbace_math_sqrt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_sqrt_A_fn_class)}; return nil }

var A_arbace_math_sqrt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_sqrt_A_invoke, New: A_arbace_math_sqrt_A_new, Get: A_arbace_math_sqrt_A_get}

var A_arbace_math_sqrt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$sqrt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "sqrt", Go: "arbace/aot_arbace_math.A_arbace_math_sqrt_A", Source: "math.ae"})

func init() { i := A_arbace_math_sqrt_A_class.Info(); i.IsInstance = A_arbace_math_sqrt_A_InstanceOf; i.Init = A_arbace_math_sqrt_A_Init; i.Table = A_arbace_math_sqrt_A_members; jrt.RegisterGoType(A_arbace_math_sqrt_A_class, reflect.TypeFor[A_arbace_math_sqrt_A]()) }

func A_arbace_math_sqrt__inliner__446000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_sqrt__inliner__446000047_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_sqrt__inliner__446000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_sqrt__inliner__446000047_A_New()}; return nil }

func A_arbace_math_sqrt__inliner__446000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_sqrt__inliner__446000047_A_fn_class)}; return nil }

var A_arbace_math_sqrt__inliner__446000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_sqrt__inliner__446000047_A_invoke, New: A_arbace_math_sqrt__inliner__446000047_A_new, Get: A_arbace_math_sqrt__inliner__446000047_A_get}

var A_arbace_math_sqrt__inliner__446000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$sqrt__inliner__446000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "sqrt__inliner__446000047", Go: "arbace/aot_arbace_math.A_arbace_math_sqrt__inliner__446000047_A", Source: "math.ae"})

func init() { i := A_arbace_math_sqrt__inliner__446000047_A_class.Info(); i.IsInstance = A_arbace_math_sqrt__inliner__446000047_A_InstanceOf; i.Init = A_arbace_math_sqrt__inliner__446000047_A_Init; i.Table = A_arbace_math_sqrt__inliner__446000047_A_members; jrt.RegisterGoType(A_arbace_math_sqrt__inliner__446000047_A_class, reflect.TypeFor[A_arbace_math_sqrt__inliner__446000047_A]()) }

func A_arbace_math_subtract_exact_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_subtract_exact_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_subtract_exact_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_subtract_exact_A_New()}; return nil }

func A_arbace_math_subtract_exact_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_subtract_exact_A_fn_class)}; return nil }

var A_arbace_math_subtract_exact_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_subtract_exact_A_invoke, New: A_arbace_math_subtract_exact_A_new, Get: A_arbace_math_subtract_exact_A_get}

var A_arbace_math_subtract_exact_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$subtract_exact", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "subtract_exact", Go: "arbace/aot_arbace_math.A_arbace_math_subtract_exact_A", Source: "math.ae"})

func init() { i := A_arbace_math_subtract_exact_A_class.Info(); i.IsInstance = A_arbace_math_subtract_exact_A_InstanceOf; i.Init = A_arbace_math_subtract_exact_A_Init; i.Table = A_arbace_math_subtract_exact_A_members; jrt.RegisterGoType(A_arbace_math_subtract_exact_A_class, reflect.TypeFor[A_arbace_math_subtract_exact_A]()) }

func A_arbace_math_subtract_exact__inliner__446000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_subtract_exact__inliner__446000080_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_math_subtract_exact__inliner__446000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_subtract_exact__inliner__446000080_A_New()}; return nil }

func A_arbace_math_subtract_exact__inliner__446000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_subtract_exact__inliner__446000080_A_fn_class)}; return nil }

var A_arbace_math_subtract_exact__inliner__446000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_subtract_exact__inliner__446000080_A_invoke, New: A_arbace_math_subtract_exact__inliner__446000080_A_new, Get: A_arbace_math_subtract_exact__inliner__446000080_A_get}

var A_arbace_math_subtract_exact__inliner__446000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$subtract_exact__inliner__446000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_math_A_class, Simple: "subtract_exact__inliner__446000080", Go: "arbace/aot_arbace_math.A_arbace_math_subtract_exact__inliner__446000080_A", Source: "math.ae"})

func init() { i := A_arbace_math_subtract_exact__inliner__446000080_A_class.Info(); i.IsInstance = A_arbace_math_subtract_exact__inliner__446000080_A_InstanceOf; i.Init = A_arbace_math_subtract_exact__inliner__446000080_A_Init; i.Table = A_arbace_math_subtract_exact__inliner__446000080_A_members; jrt.RegisterGoType(A_arbace_math_subtract_exact__inliner__446000080_A_class, reflect.TypeFor[A_arbace_math_subtract_exact__inliner__446000080_A]()) }

func A_arbace_math_tan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_tan_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_tan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_tan_A_New()}; return nil }

func A_arbace_math_tan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_tan_A_fn_class)}; return nil }

var A_arbace_math_tan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_tan_A_invoke, New: A_arbace_math_tan_A_new, Get: A_arbace_math_tan_A_get}

var A_arbace_math_tan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$tan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "tan", Go: "arbace/aot_arbace_math.A_arbace_math_tan_A", Source: "math.ae"})

func init() { i := A_arbace_math_tan_A_class.Info(); i.IsInstance = A_arbace_math_tan_A_InstanceOf; i.Init = A_arbace_math_tan_A_Init; i.Table = A_arbace_math_tan_A_members; jrt.RegisterGoType(A_arbace_math_tan_A_class, reflect.TypeFor[A_arbace_math_tan_A]()) }

func A_arbace_math_tan__inliner__446000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_tan__inliner__446000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_tan__inliner__446000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_tan__inliner__446000020_A_New()}; return nil }

func A_arbace_math_tan__inliner__446000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_tan__inliner__446000020_A_fn_class)}; return nil }

var A_arbace_math_tan__inliner__446000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_tan__inliner__446000020_A_invoke, New: A_arbace_math_tan__inliner__446000020_A_new, Get: A_arbace_math_tan__inliner__446000020_A_get}

var A_arbace_math_tan__inliner__446000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$tan__inliner__446000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "tan__inliner__446000020", Go: "arbace/aot_arbace_math.A_arbace_math_tan__inliner__446000020_A", Source: "math.ae"})

func init() { i := A_arbace_math_tan__inliner__446000020_A_class.Info(); i.IsInstance = A_arbace_math_tan__inliner__446000020_A_InstanceOf; i.Init = A_arbace_math_tan__inliner__446000020_A_Init; i.Table = A_arbace_math_tan__inliner__446000020_A_members; jrt.RegisterGoType(A_arbace_math_tan__inliner__446000020_A_class, reflect.TypeFor[A_arbace_math_tan__inliner__446000020_A]()) }

func A_arbace_math_tanh_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_tanh_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_tanh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_tanh_A_New()}; return nil }

func A_arbace_math_tanh_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_tanh_A_fn_class)}; return nil }

var A_arbace_math_tanh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_tanh_A_invoke, New: A_arbace_math_tanh_A_new, Get: A_arbace_math_tanh_A_get}

var A_arbace_math_tanh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$tanh", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "tanh", Go: "arbace/aot_arbace_math.A_arbace_math_tanh_A", Source: "math.ae"})

func init() { i := A_arbace_math_tanh_A_class.Info(); i.IsInstance = A_arbace_math_tanh_A_InstanceOf; i.Init = A_arbace_math_tanh_A_Init; i.Table = A_arbace_math_tanh_A_members; jrt.RegisterGoType(A_arbace_math_tanh_A_class, reflect.TypeFor[A_arbace_math_tanh_A]()) }

func A_arbace_math_tanh__inliner__446000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_tanh__inliner__446000113_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_tanh__inliner__446000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_tanh__inliner__446000113_A_New()}; return nil }

func A_arbace_math_tanh__inliner__446000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_tanh__inliner__446000113_A_fn_class)}; return nil }

var A_arbace_math_tanh__inliner__446000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_tanh__inliner__446000113_A_invoke, New: A_arbace_math_tanh__inliner__446000113_A_new, Get: A_arbace_math_tanh__inliner__446000113_A_get}

var A_arbace_math_tanh__inliner__446000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$tanh__inliner__446000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "tanh__inliner__446000113", Go: "arbace/aot_arbace_math.A_arbace_math_tanh__inliner__446000113_A", Source: "math.ae"})

func init() { i := A_arbace_math_tanh__inliner__446000113_A_class.Info(); i.IsInstance = A_arbace_math_tanh__inliner__446000113_A_InstanceOf; i.Init = A_arbace_math_tanh__inliner__446000113_A_Init; i.Table = A_arbace_math_tanh__inliner__446000113_A_members; jrt.RegisterGoType(A_arbace_math_tanh__inliner__446000113_A_class, reflect.TypeFor[A_arbace_math_tanh__inliner__446000113_A]()) }

func A_arbace_math_to_degrees_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_to_degrees_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_to_degrees_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_to_degrees_A_New()}; return nil }

func A_arbace_math_to_degrees_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_to_degrees_A_fn_class)}; return nil }

var A_arbace_math_to_degrees_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_to_degrees_A_invoke, New: A_arbace_math_to_degrees_A_new, Get: A_arbace_math_to_degrees_A_get}

var A_arbace_math_to_degrees_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$to_degrees", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "to_degrees", Go: "arbace/aot_arbace_math.A_arbace_math_to_degrees_A", Source: "math.ae"})

func init() { i := A_arbace_math_to_degrees_A_class.Info(); i.IsInstance = A_arbace_math_to_degrees_A_InstanceOf; i.Init = A_arbace_math_to_degrees_A_Init; i.Table = A_arbace_math_to_degrees_A_members; jrt.RegisterGoType(A_arbace_math_to_degrees_A_class, reflect.TypeFor[A_arbace_math_to_degrees_A]()) }

func A_arbace_math_to_degrees__inliner__446000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_to_degrees__inliner__446000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_to_degrees__inliner__446000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_to_degrees__inliner__446000035_A_New()}; return nil }

func A_arbace_math_to_degrees__inliner__446000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_to_degrees__inliner__446000035_A_fn_class)}; return nil }

var A_arbace_math_to_degrees__inliner__446000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_to_degrees__inliner__446000035_A_invoke, New: A_arbace_math_to_degrees__inliner__446000035_A_new, Get: A_arbace_math_to_degrees__inliner__446000035_A_get}

var A_arbace_math_to_degrees__inliner__446000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$to_degrees__inliner__446000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "to_degrees__inliner__446000035", Go: "arbace/aot_arbace_math.A_arbace_math_to_degrees__inliner__446000035_A", Source: "math.ae"})

func init() { i := A_arbace_math_to_degrees__inliner__446000035_A_class.Info(); i.IsInstance = A_arbace_math_to_degrees__inliner__446000035_A_InstanceOf; i.Init = A_arbace_math_to_degrees__inliner__446000035_A_Init; i.Table = A_arbace_math_to_degrees__inliner__446000035_A_members; jrt.RegisterGoType(A_arbace_math_to_degrees__inliner__446000035_A_class, reflect.TypeFor[A_arbace_math_to_degrees__inliner__446000035_A]()) }

func A_arbace_math_to_radians_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_to_radians_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_to_radians_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_to_radians_A_New()}; return nil }

func A_arbace_math_to_radians_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_to_radians_A_fn_class)}; return nil }

var A_arbace_math_to_radians_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_to_radians_A_invoke, New: A_arbace_math_to_radians_A_new, Get: A_arbace_math_to_radians_A_get}

var A_arbace_math_to_radians_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$to_radians", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "to_radians", Go: "arbace/aot_arbace_math.A_arbace_math_to_radians_A", Source: "math.ae"})

func init() { i := A_arbace_math_to_radians_A_class.Info(); i.IsInstance = A_arbace_math_to_radians_A_InstanceOf; i.Init = A_arbace_math_to_radians_A_Init; i.Table = A_arbace_math_to_radians_A_members; jrt.RegisterGoType(A_arbace_math_to_radians_A_class, reflect.TypeFor[A_arbace_math_to_radians_A]()) }

func A_arbace_math_to_radians__inliner__446000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_to_radians__inliner__446000032_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_to_radians__inliner__446000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_to_radians__inliner__446000032_A_New()}; return nil }

func A_arbace_math_to_radians__inliner__446000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_to_radians__inliner__446000032_A_fn_class)}; return nil }

var A_arbace_math_to_radians__inliner__446000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_to_radians__inliner__446000032_A_invoke, New: A_arbace_math_to_radians__inliner__446000032_A_new, Get: A_arbace_math_to_radians__inliner__446000032_A_get}

var A_arbace_math_to_radians__inliner__446000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$to_radians__inliner__446000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "to_radians__inliner__446000032", Go: "arbace/aot_arbace_math.A_arbace_math_to_radians__inliner__446000032_A", Source: "math.ae"})

func init() { i := A_arbace_math_to_radians__inliner__446000032_A_class.Info(); i.IsInstance = A_arbace_math_to_radians__inliner__446000032_A_InstanceOf; i.Init = A_arbace_math_to_radians__inliner__446000032_A_Init; i.Table = A_arbace_math_to_radians__inliner__446000032_A_members; jrt.RegisterGoType(A_arbace_math_to_radians__inliner__446000032_A_class, reflect.TypeFor[A_arbace_math_to_radians__inliner__446000032_A]()) }

func A_arbace_math_ulp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_ulp_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_ulp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_ulp_A_New()}; return nil }

func A_arbace_math_ulp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_ulp_A_fn_class)}; return nil }

var A_arbace_math_ulp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_ulp_A_invoke, New: A_arbace_math_ulp_A_new, Get: A_arbace_math_ulp_A_get}

var A_arbace_math_ulp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$ulp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "ulp", Go: "arbace/aot_arbace_math.A_arbace_math_ulp_A", Source: "math.ae"})

func init() { i := A_arbace_math_ulp_A_class.Info(); i.IsInstance = A_arbace_math_ulp_A_InstanceOf; i.Init = A_arbace_math_ulp_A_Init; i.Table = A_arbace_math_ulp_A_members; jrt.RegisterGoType(A_arbace_math_ulp_A_class, reflect.TypeFor[A_arbace_math_ulp_A]()) }

func A_arbace_math_ulp__inliner__446000101_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_math_ulp__inliner__446000101_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_math_ulp__inliner__446000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math_ulp__inliner__446000101_A_New()}; return nil }

func A_arbace_math_ulp__inliner__446000101_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_math_ulp__inliner__446000101_A_fn_class)}; return nil }

var A_arbace_math_ulp__inliner__446000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_math_ulp__inliner__446000101_A_invoke, New: A_arbace_math_ulp__inliner__446000101_A_new, Get: A_arbace_math_ulp__inliner__446000101_A_get}

var A_arbace_math_ulp__inliner__446000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math$ulp__inliner__446000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_math_A_class, Simple: "ulp__inliner__446000101", Go: "arbace/aot_arbace_math.A_arbace_math_ulp__inliner__446000101_A", Source: "math.ae"})

func init() { i := A_arbace_math_ulp__inliner__446000101_A_class.Info(); i.IsInstance = A_arbace_math_ulp__inliner__446000101_A_InstanceOf; i.Init = A_arbace_math_ulp__inliner__446000101_A_Init; i.Table = A_arbace_math_ulp__inliner__446000101_A_members; jrt.RegisterGoType(A_arbace_math_ulp__inliner__446000101_A_class, reflect.TypeFor[A_arbace_math_ulp__inliner__446000101_A]()) }

func A_arbace_math__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_math__init_A_Load__O(); case 1: return A_arbace_math__init_A_Unit0__O(); case 2: return A_arbace_math__init_A_Unit1__O(); case 3: return A_arbace_math__init_A_Unit10__O(); case 4: return A_arbace_math__init_A_Unit11__O(); case 5: return A_arbace_math__init_A_Unit12__O(); case 6: return A_arbace_math__init_A_Unit13__O(); case 7: return A_arbace_math__init_A_Unit14__O(); case 8: return A_arbace_math__init_A_Unit15__O(); case 9: return A_arbace_math__init_A_Unit16__O(); case 10: return A_arbace_math__init_A_Unit17__O(); case 11: return A_arbace_math__init_A_Unit18__O(); case 12: return A_arbace_math__init_A_Unit19__O(); case 13: return A_arbace_math__init_A_Unit2__O(); case 14: return A_arbace_math__init_A_Unit20__O(); case 15: return A_arbace_math__init_A_Unit21__O(); case 16: return A_arbace_math__init_A_Unit22__O(); case 17: return A_arbace_math__init_A_Unit23__O(); case 18: return A_arbace_math__init_A_Unit24__O(); case 19: return A_arbace_math__init_A_Unit25__O(); case 20: return A_arbace_math__init_A_Unit26__O(); case 21: return A_arbace_math__init_A_Unit27__O(); case 22: return A_arbace_math__init_A_Unit28__O(); case 23: return A_arbace_math__init_A_Unit29__O(); case 24: return A_arbace_math__init_A_Unit3__O(); case 25: return A_arbace_math__init_A_Unit30__O(); case 26: return A_arbace_math__init_A_Unit31__O(); case 27: return A_arbace_math__init_A_Unit32__O(); case 28: return A_arbace_math__init_A_Unit33__O(); case 29: return A_arbace_math__init_A_Unit34__O(); case 30: return A_arbace_math__init_A_Unit35__O(); case 31: return A_arbace_math__init_A_Unit36__O(); case 32: return A_arbace_math__init_A_Unit37__O(); case 33: return A_arbace_math__init_A_Unit38__O(); case 34: return A_arbace_math__init_A_Unit39__O(); case 35: return A_arbace_math__init_A_Unit4__O(); case 36: return A_arbace_math__init_A_Unit40__O(); case 37: return A_arbace_math__init_A_Unit41__O(); case 38: return A_arbace_math__init_A_Unit42__O(); case 39: return A_arbace_math__init_A_Unit43__O(); case 40: return A_arbace_math__init_A_Unit44__O(); case 41: return A_arbace_math__init_A_Unit45__O(); case 42: return A_arbace_math__init_A_Unit46__O(); case 43: return A_arbace_math__init_A_Unit47__O(); case 44: return A_arbace_math__init_A_Unit48__O(); case 45: return A_arbace_math__init_A_Unit49__O(); case 46: return A_arbace_math__init_A_Unit5__O(); case 47: return A_arbace_math__init_A_Unit6__O(); case 48: return A_arbace_math__init_A_Unit7__O(); case 49: return A_arbace_math__init_A_Unit8__O(); case 50: return A_arbace_math__init_A_Unit9__O()}; return nil }

func A_arbace_math__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_math__init_A_New()}; return nil }

var A_arbace_math__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_math__init_A_invoke, New: A_arbace_math__init_A_new}

var A_arbace_math__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.math__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_math.A_arbace_math__init_A", Source: "math.ae"})

func init() { i := A_arbace_math__init_A_class.Info(); i.IsInstance = A_arbace_math__init_A_InstanceOf; i.Init = A_arbace_math__init_A_Init; i.Table = A_arbace_math__init_A_members; jrt.RegisterGoType(A_arbace_math__init_A_class, reflect.TypeFor[A_arbace_math__init_A]()) }
