//line a2g_strings.ae:1
package aot_arbace_uuid

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.uuid")

var Lit_6 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_7 *jrt.String = jrt.Intern("string?")

var Lit_8 *jrt.String = jrt.Intern("str")

var Lit_9 *jrt.String = jrt.Intern("print-method")

var Lit_10 *jrt.String = jrt.Intern("arbace.uuid$default_uuid_reader")

var Lit_11 *jrt.String = jrt.Intern("#uuid data reader expected string")

var Lit_12 *jrt.String = jrt.Intern("arbace.uuid$eval427000002$loading__1927001464__auto____427000003")

var Lit_13 *jrt.String = jrt.Intern("arbace.uuid$eval427000006$fn__427000007")

var Lit_14 *jrt.String = jrt.Intern("arbace.uuid$eval427000011$fn__427000012")

var Lit_15 *jrt.String = jrt.Intern("#uuid \"")

var Lit_16 *jrt.String = jrt.Intern("\"")

var Lit_17 *jrt.String = jrt.Intern("arbace.uuid$eval427000015$fn__427000016")

var Lit_18 *jrt.String = jrt.Intern("in-ns")

var Lit_19 *jrt.String = jrt.Intern("default-uuid-reader")

var Lit_20 *jrt.String = jrt.Intern("private")

var Lit_21 *jrt.String = jrt.Intern("arglists")

var Lit_22 *jrt.String = jrt.Intern("form")

var Lit_23 *jrt.String = jrt.Intern("line")

var Lit_24 *jrt.String = jrt.Intern("column")

var Lit_25 *jrt.String = jrt.Intern("file")

var Lit_26 *jrt.String = jrt.Intern("arbace/uuid.ae")

var Lit_27 *jrt.String = jrt.Intern("java.util.UUID")

var Lit_28 *jrt.String = jrt.Intern("print-dup")
