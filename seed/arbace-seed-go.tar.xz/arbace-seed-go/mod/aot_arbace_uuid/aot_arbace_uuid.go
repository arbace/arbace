//line aot_arbace_uuid.ae:1
package aot_arbace_uuid

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_New() *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A { A_arbace_uuid_A_Init(); t := &A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) Ctor() {}
//line :9:1
func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_uuid_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_uuid_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_uuid_eval427000006_fn__427000007_A_New() *A_arbace_uuid_eval427000006_fn__427000007_A { A_arbace_uuid_A_Init(); t := &A_arbace_uuid_eval427000006_fn__427000007_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_uuid_eval427000006_fn__427000007_A) Ctor() {}
//line :9:1
func (t *A_arbace_uuid_eval427000006_fn__427000007_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_uuid_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_uuid_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_uuid_A_const_6), A_arbace_uuid_A_const_4.GetRawRoot__O(), A_arbace_uuid_A_const_5) }

func A_arbace_uuid_default_uuid_reader_A_New() *A_arbace_uuid_default_uuid_reader_A { A_arbace_uuid_A_Init(); t := &A_arbace_uuid_default_uuid_reader_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_uuid_default_uuid_reader_A) Ctor() {}
//line :11:1
func (t *A_arbace_uuid_default_uuid_reader_A) Invoke_O_O__O(self, form__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_uuid_A_const_7.GetRawRoot__O()).Invoke_O__O(form__0)) {
		return jrt.UUID_FromString_String__UUID(jrt.String_Cast(form__0)).Ref() } else {
//line :12:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(Lit_1)))
		}
}

func A_arbace_uuid_eval427000011_fn__427000012_A_New() *A_arbace_uuid_eval427000011_fn__427000012_A { A_arbace_uuid_A_Init(); t := &A_arbace_uuid_eval427000011_fn__427000012_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_uuid_eval427000011_fn__427000012_A) Ctor() {}
//line :16:1
func (t *A_arbace_uuid_eval427000011_fn__427000012_A) Invoke_O_O_O__O(self, uuid__1, w__2 any) any {
	jrt.Writer_Cast(w__2).Write_String__V(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_uuid_A_const_8.GetRawRoot__O()).Invoke_O__O(uuid__1), nil))); return nil
}
func A_arbace_uuid_eval427000015_fn__427000016_A_New() *A_arbace_uuid_eval427000015_fn__427000016_A { A_arbace_uuid_A_Init(); t := &A_arbace_uuid_eval427000015_fn__427000016_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_uuid_eval427000015_fn__427000016_A) Ctor() {}
//line :19:1
func (t *A_arbace_uuid_eval427000015_fn__427000016_A) Invoke_O_O_O__O(self, o__1, w__2 any) any {
	return lang.IFn_Cast(A_arbace_uuid_A_const_9.GetRawRoot__O()).Invoke_O_O__O(o__1, w__2)
}



















type A_arbace_uuid_A struct{ jrt.Object }

var A_arbace_uuid_A_const_pool *jrt.RefArray

var A_arbace_uuid_A_const_0 *lang.Var

var A_arbace_uuid_A_const_1 any

var A_arbace_uuid_A_const_2 *lang.Var

var A_arbace_uuid_A_const_3 *lang.Var

var A_arbace_uuid_A_const_4 *lang.Var

var A_arbace_uuid_A_const_5 any

var A_arbace_uuid_A_const_6 *lang.Var

var A_arbace_uuid_A_const_7 *lang.Var

var A_arbace_uuid_A_const_8 *lang.Var

var A_arbace_uuid_A_const_9 *lang.Var

var A_arbace_uuid_A_init jrt.ClassInit

func A_arbace_uuid_A_Init() { if !A_arbace_uuid_A_init.Done() { A_arbace_uuid_A_init.Run(A_arbace_uuid_A_clinit) } }

func A_arbace_uuid_A_clinit() { jrt.StartCheck(); A_arbace_uuid_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 12); A_arbace_uuid_A_const_0 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[2]); A_arbace_uuid_A_const_1 = A_arbace_uuid_A_const_pool.A[3]; A_arbace_uuid_A_const_2 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[4]); A_arbace_uuid_A_const_3 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[5]); A_arbace_uuid_A_const_4 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[6]); A_arbace_uuid_A_const_5 = A_arbace_uuid_A_const_pool.A[7]; A_arbace_uuid_A_const_6 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[8]); A_arbace_uuid_A_const_7 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[9]); A_arbace_uuid_A_const_8 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[10]); A_arbace_uuid_A_const_9 = lang.Var_Cast(A_arbace_uuid_A_const_pool.A[11]) }

func A_arbace_uuid_A_New() *A_arbace_uuid_A { A_arbace_uuid_A_Init(); t := &A_arbace_uuid_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_A) Ctor() {}

func (t *A_arbace_uuid_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_A_class }

func (t *A_arbace_uuid_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_uuid_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_A); return ok }

func A_arbace_uuid_A_Cast(x any) *A_arbace_uuid_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_A_class)) }; return v }



type A_arbace_uuid_default_uuid_reader_A struct{ j2g_header uint64 }

var A_arbace_uuid_default_uuid_reader_A_fn_class *jrt.Class



type A_arbace_uuid_eval427000002_A struct{ jrt.Object }

func A_arbace_uuid_eval427000002_A_New() *A_arbace_uuid_eval427000002_A { t := &A_arbace_uuid_eval427000002_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000002_A) Ctor() {}

func (t *A_arbace_uuid_eval427000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000002_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000002_A_class }

func (t *A_arbace_uuid_eval427000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000002_A); return ok }

func A_arbace_uuid_eval427000002_A_Cast(x any) *A_arbace_uuid_eval427000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000002_A_class)) }; return v }



type A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A struct{ j2g_header uint64 }

var A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_fn_class *jrt.Class



type A_arbace_uuid_eval427000006_A struct{ jrt.Object }

func A_arbace_uuid_eval427000006_A_New() *A_arbace_uuid_eval427000006_A { t := &A_arbace_uuid_eval427000006_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000006_A) Ctor() {}

func (t *A_arbace_uuid_eval427000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000006_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000006_A_class }

func (t *A_arbace_uuid_eval427000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000006_A); return ok }

func A_arbace_uuid_eval427000006_A_Cast(x any) *A_arbace_uuid_eval427000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000006_A_class)) }; return v }



type A_arbace_uuid_eval427000006_fn__427000007_A struct{ j2g_header uint64 }

var A_arbace_uuid_eval427000006_fn__427000007_A_fn_class *jrt.Class



type A_arbace_uuid_eval427000011_A struct{ jrt.Object }

func A_arbace_uuid_eval427000011_A_New() *A_arbace_uuid_eval427000011_A { t := &A_arbace_uuid_eval427000011_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000011_A) Ctor() {}

func (t *A_arbace_uuid_eval427000011_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000011_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000011_A_class }

func (t *A_arbace_uuid_eval427000011_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000011_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000011_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000011_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000011_A); return ok }

func A_arbace_uuid_eval427000011_A_Cast(x any) *A_arbace_uuid_eval427000011_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000011_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000011_A_class)) }; return v }



type A_arbace_uuid_eval427000011_fn__427000012_A struct{ j2g_header uint64 }

var A_arbace_uuid_eval427000011_fn__427000012_A_fn_class *jrt.Class



type A_arbace_uuid_eval427000015_A struct{ jrt.Object }

func A_arbace_uuid_eval427000015_A_New() *A_arbace_uuid_eval427000015_A { t := &A_arbace_uuid_eval427000015_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000015_A) Ctor() {}

func (t *A_arbace_uuid_eval427000015_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000015_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000015_A_class }

func (t *A_arbace_uuid_eval427000015_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000015_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000015_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000015_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000015_A); return ok }

func A_arbace_uuid_eval427000015_A_Cast(x any) *A_arbace_uuid_eval427000015_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000015_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000015_A_class)) }; return v }



type A_arbace_uuid_eval427000015_fn__427000016_A struct{ j2g_header uint64 }

var A_arbace_uuid_eval427000015_fn__427000016_A_fn_class *jrt.Class
