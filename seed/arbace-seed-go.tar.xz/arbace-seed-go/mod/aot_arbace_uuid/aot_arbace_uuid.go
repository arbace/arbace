//line aot_arbace_uuid.ae:1
package aot_arbace_uuid

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_New() *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A { A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_Init(); t := &A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) Ctor() {}
//line :9:1
func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_uuid_A_Init(); tmp4 = A_arbace_uuid_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_uuid_A_Init(); tmp6 = A_arbace_uuid_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :9:1
func A_arbace_uuid_eval427000006_fn__427000007_A_New() *A_arbace_uuid_eval427000006_fn__427000007_A { A_arbace_uuid_eval427000006_fn__427000007_A_Init(); t := &A_arbace_uuid_eval427000006_fn__427000007_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_uuid_eval427000006_fn__427000007_A) Ctor() {}
//line :9:1
func (t *A_arbace_uuid_eval427000006_fn__427000007_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_uuid_A_Init(); tmp1 = A_arbace_uuid_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_uuid_A_Init(); tmp3 = A_arbace_uuid_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_uuid_A_Init(); tmp5 = A_arbace_uuid_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_uuid_A_Init(); tmp7 = A_arbace_uuid_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_uuid_A_Init(); tmp9 = A_arbace_uuid_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }

func A_arbace_uuid_default_uuid_reader_A_New() *A_arbace_uuid_default_uuid_reader_A { A_arbace_uuid_default_uuid_reader_A_Init(); t := &A_arbace_uuid_default_uuid_reader_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_uuid_default_uuid_reader_A) Ctor() {}
//line :11:1
func (t *A_arbace_uuid_default_uuid_reader_A) Invoke_O_O__O(self, form__0 any) any {
	var tmp1 *lang.Var; A_arbace_uuid_A_Init(); tmp1 = A_arbace_uuid_A_const_7; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(form__0)) {
		return jrt.UUID_FromString_String__UUID(jrt.String_Cast(form__0)).Ref() } else {
//line :12:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(Lit_11)))
		}
}

func A_arbace_uuid_eval427000011_fn__427000012_A_New() *A_arbace_uuid_eval427000011_fn__427000012_A { A_arbace_uuid_eval427000011_fn__427000012_A_Init(); t := &A_arbace_uuid_eval427000011_fn__427000012_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_uuid_eval427000011_fn__427000012_A) Ctor() {}
//line :16:1
func (t *A_arbace_uuid_eval427000011_fn__427000012_A) Invoke_O_O_O__O(self, uuid__1, w__2 any) any {
	var tmp1 jrt.Writer_I = jrt.Writer_Cast(w__2); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_16); var tmp3 *lang.Var; A_arbace_uuid_A_Init(); tmp3 = A_arbace_uuid_A_const_8; tmp1.Write_String__V(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(uuid__1), nil))); return nil
}
func A_arbace_uuid_eval427000015_fn__427000016_A_New() *A_arbace_uuid_eval427000015_fn__427000016_A { A_arbace_uuid_eval427000015_fn__427000016_A_Init(); t := &A_arbace_uuid_eval427000015_fn__427000016_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_uuid_eval427000015_fn__427000016_A) Ctor() {}
//line :19:1
func (t *A_arbace_uuid_eval427000015_fn__427000016_A) Invoke_O_O_O__O(self, o__1, w__2 any) any {
	var tmp1 *lang.Var; A_arbace_uuid_A_Init(); tmp1 = A_arbace_uuid_A_const_9; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(o__1, w__2)
}



















type A_arbace_uuid_A struct{ jrt.Object }

var A_arbace_uuid_A_const_0 *lang.Var

var A_arbace_uuid_A_const_1 any

var A_arbace_uuid_A_const_2 *lang.Var

var A_arbace_uuid_A_const_3 *lang.Var

var A_arbace_uuid_A_const_4 *lang.Var

var A_arbace_uuid_A_const_5 any

var A_arbace_uuid_A_const_6 *lang.Var

var A_arbace_uuid_A_const_7 *lang.Var

var A_arbace_uuid_A_const_8 *lang.Var

var A_arbace_uuid_A_const_9 *lang.Var

var A_arbace_uuid_A_init jrt.ClassInit

func A_arbace_uuid_A_Init() { if !A_arbace_uuid_A_init.Done() { A_arbace_uuid_A_init.Run(A_arbace_uuid_A_clinit) } }

func A_arbace_uuid_A_clinit() { A_arbace_uuid_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_uuid_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_uuid_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_uuid_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_uuid_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_uuid_A_const_5 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(); A_arbace_uuid_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_uuid_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_uuid_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_uuid_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_9) }

func A_arbace_uuid_A_New() *A_arbace_uuid_A { A_arbace_uuid_A_Init(); t := &A_arbace_uuid_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_A) Ctor() {}

func (t *A_arbace_uuid_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_A_class }

func (t *A_arbace_uuid_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_A); return ok }

func A_arbace_uuid_A_Cast(x any) *A_arbace_uuid_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_A_class)) }; return v }



type A_arbace_uuid_default_uuid_reader_A struct{ jrt.Object }

func (t *A_arbace_uuid_default_uuid_reader_A) Is_Compiler_AOTF1() {}

var A_arbace_uuid_default_uuid_reader_A_fn_class *jrt.Class

var A_arbace_uuid_default_uuid_reader_A_init jrt.ClassInit

func A_arbace_uuid_default_uuid_reader_A_Init() { if !A_arbace_uuid_default_uuid_reader_A_init.Done() { A_arbace_uuid_default_uuid_reader_A_init.Run(A_arbace_uuid_default_uuid_reader_A_clinit) } }

func A_arbace_uuid_default_uuid_reader_A_clinit() { A_arbace_uuid_default_uuid_reader_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_10, lang.Compiler_AOTFn_class) }

func (t *A_arbace_uuid_default_uuid_reader_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_default_uuid_reader_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_default_uuid_reader_A_class }

func (t *A_arbace_uuid_default_uuid_reader_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_default_uuid_reader_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_default_uuid_reader_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_default_uuid_reader_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_default_uuid_reader_A); return ok }

func A_arbace_uuid_default_uuid_reader_A_Cast(x any) *A_arbace_uuid_default_uuid_reader_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_default_uuid_reader_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_default_uuid_reader_A_class)) }; return v }



type A_arbace_uuid_eval427000002_A struct{ jrt.Object }

func A_arbace_uuid_eval427000002_A_New() *A_arbace_uuid_eval427000002_A { t := &A_arbace_uuid_eval427000002_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000002_A) Ctor() {}

func (t *A_arbace_uuid_eval427000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000002_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000002_A_class }

func (t *A_arbace_uuid_eval427000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000002_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000002_A); return ok }

func A_arbace_uuid_eval427000002_A_Cast(x any) *A_arbace_uuid_eval427000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000002_A_class)) }; return v }



type A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A struct{ jrt.Object }

func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) Is_Compiler_AOTF0() {}

var A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_fn_class *jrt.Class

var A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_init jrt.ClassInit

func A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_Init() { if !A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_init.Done() { A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_init.Run(A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_clinit) } }

func A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_clinit() { A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_12, lang.Compiler_AOTFn_class) }

func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_class }

func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A); return ok }

func A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_Cast(x any) *A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_class)) }; return v }



type A_arbace_uuid_eval427000006_A struct{ jrt.Object }

func A_arbace_uuid_eval427000006_A_New() *A_arbace_uuid_eval427000006_A { t := &A_arbace_uuid_eval427000006_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000006_A) Ctor() {}

func (t *A_arbace_uuid_eval427000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000006_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000006_A_class }

func (t *A_arbace_uuid_eval427000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000006_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000006_A); return ok }

func A_arbace_uuid_eval427000006_A_Cast(x any) *A_arbace_uuid_eval427000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000006_A_class)) }; return v }



type A_arbace_uuid_eval427000006_fn__427000007_A struct{ jrt.Object }

func (t *A_arbace_uuid_eval427000006_fn__427000007_A) Is_Compiler_AOTF0() {}

var A_arbace_uuid_eval427000006_fn__427000007_A_fn_class *jrt.Class

var A_arbace_uuid_eval427000006_fn__427000007_A_init jrt.ClassInit

func A_arbace_uuid_eval427000006_fn__427000007_A_Init() { if !A_arbace_uuid_eval427000006_fn__427000007_A_init.Done() { A_arbace_uuid_eval427000006_fn__427000007_A_init.Run(A_arbace_uuid_eval427000006_fn__427000007_A_clinit) } }

func A_arbace_uuid_eval427000006_fn__427000007_A_clinit() { A_arbace_uuid_eval427000006_fn__427000007_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_13, lang.Compiler_AOTFn_class) }

func (t *A_arbace_uuid_eval427000006_fn__427000007_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000006_fn__427000007_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000006_fn__427000007_A_class }

func (t *A_arbace_uuid_eval427000006_fn__427000007_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000006_fn__427000007_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000006_fn__427000007_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000006_fn__427000007_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000006_fn__427000007_A); return ok }

func A_arbace_uuid_eval427000006_fn__427000007_A_Cast(x any) *A_arbace_uuid_eval427000006_fn__427000007_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000006_fn__427000007_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000006_fn__427000007_A_class)) }; return v }



type A_arbace_uuid_eval427000011_A struct{ jrt.Object }

func A_arbace_uuid_eval427000011_A_New() *A_arbace_uuid_eval427000011_A { t := &A_arbace_uuid_eval427000011_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000011_A) Ctor() {}

func (t *A_arbace_uuid_eval427000011_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000011_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000011_A_class }

func (t *A_arbace_uuid_eval427000011_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000011_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000011_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000011_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000011_A); return ok }

func A_arbace_uuid_eval427000011_A_Cast(x any) *A_arbace_uuid_eval427000011_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000011_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000011_A_class)) }; return v }



type A_arbace_uuid_eval427000011_fn__427000012_A struct{ jrt.Object }

func (t *A_arbace_uuid_eval427000011_fn__427000012_A) Is_Compiler_AOTF2() {}

var A_arbace_uuid_eval427000011_fn__427000012_A_fn_class *jrt.Class

var A_arbace_uuid_eval427000011_fn__427000012_A_init jrt.ClassInit

func A_arbace_uuid_eval427000011_fn__427000012_A_Init() { if !A_arbace_uuid_eval427000011_fn__427000012_A_init.Done() { A_arbace_uuid_eval427000011_fn__427000012_A_init.Run(A_arbace_uuid_eval427000011_fn__427000012_A_clinit) } }

func A_arbace_uuid_eval427000011_fn__427000012_A_clinit() { A_arbace_uuid_eval427000011_fn__427000012_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_14, lang.Compiler_AOTFn_class) }

func (t *A_arbace_uuid_eval427000011_fn__427000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000011_fn__427000012_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000011_fn__427000012_A_class }

func (t *A_arbace_uuid_eval427000011_fn__427000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000011_fn__427000012_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000011_fn__427000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000011_fn__427000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000011_fn__427000012_A); return ok }

func A_arbace_uuid_eval427000011_fn__427000012_A_Cast(x any) *A_arbace_uuid_eval427000011_fn__427000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000011_fn__427000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000011_fn__427000012_A_class)) }; return v }



type A_arbace_uuid_eval427000015_A struct{ jrt.Object }

func A_arbace_uuid_eval427000015_A_New() *A_arbace_uuid_eval427000015_A { t := &A_arbace_uuid_eval427000015_A{}; t.Ctor(); return t }

func (t *A_arbace_uuid_eval427000015_A) Ctor() {}

func (t *A_arbace_uuid_eval427000015_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000015_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000015_A_class }

func (t *A_arbace_uuid_eval427000015_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000015_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000015_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000015_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000015_A); return ok }

func A_arbace_uuid_eval427000015_A_Cast(x any) *A_arbace_uuid_eval427000015_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000015_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000015_A_class)) }; return v }



type A_arbace_uuid_eval427000015_fn__427000016_A struct{ jrt.Object }

func (t *A_arbace_uuid_eval427000015_fn__427000016_A) Is_Compiler_AOTF2() {}

var A_arbace_uuid_eval427000015_fn__427000016_A_fn_class *jrt.Class

var A_arbace_uuid_eval427000015_fn__427000016_A_init jrt.ClassInit

func A_arbace_uuid_eval427000015_fn__427000016_A_Init() { if !A_arbace_uuid_eval427000015_fn__427000016_A_init.Done() { A_arbace_uuid_eval427000015_fn__427000016_A_init.Run(A_arbace_uuid_eval427000015_fn__427000016_A_clinit) } }

func A_arbace_uuid_eval427000015_fn__427000016_A_clinit() { A_arbace_uuid_eval427000015_fn__427000016_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_17, lang.Compiler_AOTFn_class) }

func (t *A_arbace_uuid_eval427000015_fn__427000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_uuid_eval427000015_fn__427000016_A) GetClass__Class() *jrt.Class { return A_arbace_uuid_eval427000015_fn__427000016_A_class }

func (t *A_arbace_uuid_eval427000015_fn__427000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_uuid_eval427000015_fn__427000016_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_uuid_eval427000015_fn__427000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_uuid_eval427000015_fn__427000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_uuid_eval427000015_fn__427000016_A); return ok }

func A_arbace_uuid_eval427000015_fn__427000016_A_Cast(x any) *A_arbace_uuid_eval427000015_fn__427000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_uuid_eval427000015_fn__427000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_uuid_eval427000015_fn__427000016_A_class)) }; return v }
