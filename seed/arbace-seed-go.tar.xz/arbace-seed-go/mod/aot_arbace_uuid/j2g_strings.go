//line j2g_strings.ae:1
package aot_arbace_uuid

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn11,arbace.uuidv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjR1,v11,arbace.core7,string?v11,arbace.core3,strv11,arbace.core12,print-method")

var Lit_1 *jrt.String = jrt.Intern("#uuid data reader expected string")

var Lit_2 *jrt.String = jrt.Intern("#uuid \"")

var Lit_3 *jrt.String = jrt.Intern("\"")

var Lit_4 *jrt.String = jrt.Intern("yn11,arbace.uuidyn11,arbace.corekn7,privatekn8,arglistsyn4,formkn4,linekn6,columnkn4,filev11,arbace.core5,in-nsR0,R1,v11,arbace.uuid19,default-uuid-readerm10,R2,TR3,L1,V1,R4,R5,i11,R6,i1,R7,s14,arbace/uuid.aev11,arbace.core12,print-methodC14,java.util.UUIDv11,arbace.core9,print-dup")

var Lit_5 *jrt.String = jrt.Intern("arbace.uuid$eval427000002$loading__1927001464__auto____427000003")

var Lit_6 *jrt.String = jrt.Intern("arbace.uuid$eval427000006$fn__427000007")

var Lit_7 *jrt.String = jrt.Intern("arbace.uuid$default_uuid_reader")

var Lit_8 *jrt.String = jrt.Intern("arbace.uuid$eval427000011$fn__427000012")

var Lit_9 *jrt.String = jrt.Intern("arbace.uuid$eval427000015$fn__427000016")
