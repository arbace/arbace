//line a2g_classes.ae:1
package aot_arbace_uuid

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_uuid_default_uuid_reader_A_class, Name: "arbace.uuid$default_uuid_reader", Modifiers: 25, Simple: "default_uuid_reader", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_default_uuid_reader_A", Source: "uuid.ae", Declaring: &A_arbace_uuid_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_class, Name: "arbace.uuid$eval427000002$loading__1927001464__auto____427000003", Modifiers: 25, Simple: "loading__1927001464__auto____427000003", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A", Source: "uuid.ae", Declaring: &A_arbace_uuid_eval427000002_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_uuid_eval427000006_fn__427000007_A_class, Name: "arbace.uuid$eval427000006$fn__427000007", Modifiers: 25, Simple: "fn__427000007", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000006_fn__427000007_A", Source: "uuid.ae", Declaring: &A_arbace_uuid_eval427000006_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_uuid_eval427000011_fn__427000012_A_class, Name: "arbace.uuid$eval427000011$fn__427000012", Modifiers: 25, Simple: "fn__427000012", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000011_fn__427000012_A", Source: "uuid.ae", Declaring: &A_arbace_uuid_eval427000011_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_uuid_eval427000015_fn__427000016_A_class, Name: "arbace.uuid$eval427000015$fn__427000016", Modifiers: 25, Simple: "fn__427000016", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000015_fn__427000016_A", Source: "uuid.ae", Declaring: &A_arbace_uuid_eval427000015_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_uuid_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_uuid_A_New()}; return nil }

var A_arbace_uuid_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_uuid_A_new}

var A_arbace_uuid_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.uuid", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_uuid.A_arbace_uuid_A"})

func init() { i := A_arbace_uuid_A_class.Info(); i.IsInstance = A_arbace_uuid_A_InstanceOf; i.Init = A_arbace_uuid_A_Init; i.Table = A_arbace_uuid_A_members }

var A_arbace_uuid_default_uuid_reader_A_class *jrt.Class

func A_arbace_uuid_eval427000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_uuid_eval427000002_A_New()}; return nil }

var A_arbace_uuid_eval427000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_uuid_eval427000002_A_new}

var A_arbace_uuid_eval427000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.uuid$eval427000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_uuid_A_class, Simple: "eval427000002", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000002_A"})

func init() { i := A_arbace_uuid_eval427000002_A_class.Info(); i.IsInstance = A_arbace_uuid_eval427000002_A_InstanceOf; i.Table = A_arbace_uuid_eval427000002_A_members }

var A_arbace_uuid_eval427000002_loading__1927001464__auto____427000003_A_class *jrt.Class

func A_arbace_uuid_eval427000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_uuid_eval427000006_A_New()}; return nil }

var A_arbace_uuid_eval427000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_uuid_eval427000006_A_new}

var A_arbace_uuid_eval427000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.uuid$eval427000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_uuid_A_class, Simple: "eval427000006", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000006_A"})

func init() { i := A_arbace_uuid_eval427000006_A_class.Info(); i.IsInstance = A_arbace_uuid_eval427000006_A_InstanceOf; i.Table = A_arbace_uuid_eval427000006_A_members }

var A_arbace_uuid_eval427000006_fn__427000007_A_class *jrt.Class

func A_arbace_uuid_eval427000011_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_uuid_eval427000011_A_New()}; return nil }

var A_arbace_uuid_eval427000011_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_uuid_eval427000011_A_new}

var A_arbace_uuid_eval427000011_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.uuid$eval427000011", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_uuid_A_class, Simple: "eval427000011", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000011_A"})

func init() { i := A_arbace_uuid_eval427000011_A_class.Info(); i.IsInstance = A_arbace_uuid_eval427000011_A_InstanceOf; i.Table = A_arbace_uuid_eval427000011_A_members }

var A_arbace_uuid_eval427000011_fn__427000012_A_class *jrt.Class

func A_arbace_uuid_eval427000015_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_uuid_eval427000015_A_New()}; return nil }

var A_arbace_uuid_eval427000015_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_uuid_eval427000015_A_new}

var A_arbace_uuid_eval427000015_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.uuid$eval427000015", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_uuid_A_class, Simple: "eval427000015", Go: "arbace/aot_arbace_uuid.A_arbace_uuid_eval427000015_A"})

func init() { i := A_arbace_uuid_eval427000015_A_class.Info(); i.IsInstance = A_arbace_uuid_eval427000015_A_InstanceOf; i.Table = A_arbace_uuid_eval427000015_A_members }

var A_arbace_uuid_eval427000015_fn__427000016_A_class *jrt.Class

func A_arbace_uuid__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_uuid__init_A_Load__O()}; return nil }

func A_arbace_uuid__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_uuid__init_A_New()}; return nil }

var A_arbace_uuid__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_uuid__init_A_invoke, New: A_arbace_uuid__init_A_new}

var A_arbace_uuid__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.uuid__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_uuid.A_arbace_uuid__init_A", Source: "uuid.ae"})

func init() { i := A_arbace_uuid__init_A_class.Info(); i.IsInstance = A_arbace_uuid__init_A_InstanceOf; i.Init = A_arbace_uuid__init_A_Init; i.Table = A_arbace_uuid__init_A_members }
