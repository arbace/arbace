//line a2g_strings.ae:1
package aot_arbace_core_server

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn10,arbace.ednyn3,ednyn11,arbace.mainyn1,mkn3,dockn6,authorys11,arbace.core3,letyn26,lockee__1213000018__auto__kn3,tagyn40,java.util.concurrent.locks.ReentrantLockyn5,.lockyn3,tryyn7,finallyyn7,.unlockys11,arbace.core4,dotoyn17,java.lang.Thread.ys11,arbace.core2,fnyn10,.setDaemonyn6,.startkn4,namekn4,portkn6,acceptkn6,serverkn6,clientkn8,sessionskn7,addresskn4,argskn8,bind-errkn13,server-daemonkn13,client-daemonkn6,socketyn4,userkn10,line-startkn10,stream-endks4,repl4,quitkn9,read-condkn5,allowkn4,initkn4,readkn5,phasekn5,stdinkn3,tapkn3,valkn3,eofkn3,retkn2,nskn2,mskn4,formkn9,exceptionks12,arbace.error5,phasekn9,executionkn11,read-sourcekn3,outkn3,errkn4,valfkn17,print-eval-resultkn5,readfkn16,read-eval-resultv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn18,arbace.core.serverm4,R8,s21,Socket server supportR9,s11,Alex Millerv11,arbace.core13,*loaded-libs*v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR10,v11,arbace.core5,applyv11,arbace.core6,vectorR11,v11,arbace.core9,with-metam2,R12,R13,R14,R15,R16,R17,R18,R19,R20,R21,R22,v11,arbace.core7,ex-infov11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstR23,R24,R25,v11,arbace.core3,notv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstV3,R23,R24,R25,v18,arbace.core.server8,requiredv11,arbace.core10,chunk-restv11,arbace.core8,integer?v11,arbace.core2,<=l0,l65535,v11,arbace.core7,resolvev11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core4,*in*v11,arbace.core5,*out*v11,arbace.core5,*err*v18,arbace.core.server9,*session*R26,R27,v18,arbace.core.server4,lockv11,arbace.core14,alter-var-rootv18,arbace.core.server7,serversv11,arbace.core8,assoc-inR28,v11,arbace.core6,symbolv11,arbace.core9,namespacev11,arbace.core9,update-inv11,arbace.core6,dissocR29,R30,R31,R32,R33,v18,arbace.core.server13,validate-optsv11,arbace.core5,assocR34,v11,arbace.core3,strv18,arbace.core.server17,accept-connectionv11,arbace.core6,get-inv18,arbace.core.server11,stop-serverv11,arbace.core4,keysv11,arbace.core11,future-callv11,arbace.core6,reducev13,arbace.string5,splitp2,\\.v11,arbace.core5,mergev10,arbace.edn11,read-stringv18,arbace.core.server11,parse-propsv18,arbace.core.server12,start-serverv11,arbace.core5,in-nsR35,v11,arbace.main13,repl-requiresR36,R37,v11,arbace.core4,readR38,v11,arbace.main15,skip-whitespacem2,R39,R40,v11,arbace.main11,skip-if-eolv11,arbace.main4,replR41,v18,arbace.core.server9,repl-initR42,v18,arbace.core.server9,repl-readv11,arbace.core14,Throwable->mapR43,R44,R12,R45,R46,v11,arbace.core11,read+stringv11,arbace.core4,evalR47,R39,R40,v11,arbace.core2,*3v11,arbace.core2,*2v11,arbace.core2,*1R48,R49,R50,R51,v11,arbace.core4,*ns*v11,arbace.core2,*ev18,arbace.core.server8,ex->dataR52,R53,v11,arbace.core7,ex-dataR54,R55,v11,arbace.core10,remove-tapC16,java.lang.Threadv11,arbace.core20,*warn-on-reflection*v11,arbace.core14,*math-context*v11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core22,*print-namespace-maps*v11,arbace.core14,*data-readers*v11,arbace.core24,*default-data-reader-fn*v11,arbace.core14,*compile-path*v11,arbace.core19,*command-line-args*v11,arbace.core16,*unchecked-math*v11,arbace.core8,*assert*v17,arbace.spec.alpha13,*explain-out*R35,v11,arbace.core6,*repl*v11,arbace.core14,PrintWriter-onR56,R57,v11,arbace.core7,add-tapv11,arbace.core7,symbol?v11,arbace.core6,pr-strR58,v18,arbace.core.server10,resolve-fnv18,arbace.core.server5,preplv11,arbace.core3,prnv11,arbace.core18,*flush-on-newline*v11,arbace.core16,*print-readably*S2,R45,R48,R59,v11,arbace.core11,read-stringR60,v11,arbace.core7,string?l1024,S2,R45,R48,R61,")

var Lit_1 *jrt.String = jrt.Intern("arbace.core.server$accept_connection$fn__1213000038")

var Lit_2 *jrt.String = jrt.Intern("arbace.core.server$accept_connection$fn__1213000040")

var Lit_3 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_4 *jrt.String = jrt.Intern("java.net.InetAddress")

var Lit_5 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_6 *jrt.String = jrt.Intern("java.net.ServerSocket")

var Lit_7 *jrt.String = jrt.Intern("java.net.SocketException")

var Lit_8 *jrt.String = jrt.Intern("java.io.Reader")

var Lit_9 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_10 *jrt.String = jrt.Intern("java.io.PrintWriter")

var Lit_11 *jrt.String = jrt.Intern("java.io.BufferedWriter")

var Lit_12 *jrt.String = jrt.Intern("java.io.BufferedReader")

var Lit_13 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_14 *jrt.String = jrt.Intern("java.io.OutputStreamWriter")

var Lit_15 *jrt.String = jrt.Intern("java.util.Properties")

var Lit_16 *jrt.String = jrt.Intern("java.util.concurrent.locks.ReentrantLock")

var Lit_17 *jrt.String = jrt.Intern("arbace.core.server$io_prepl$fn__1213000112")

var Lit_18 *jrt.String = jrt.Intern("arbace.core.server$io_prepl$fn__1213000112$fn__1213000113")

var Lit_19 *jrt.String = jrt.Intern("arbace.core.server$parse_props$fn__1213000072")

var Lit_20 *jrt.String = jrt.Intern("arbace")

var Lit_21 *jrt.String = jrt.Intern("server")

var Lit_22 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_23 *jrt.String = jrt.Intern("setContextClassLoader")

var Lit_24 *jrt.String = jrt.Intern("arbace.core.server$prepl$tapfn__1213000094")

var Lit_25 *jrt.String = jrt.Intern("arbace.compile.path")

var Lit_26 *jrt.String = jrt.Intern("classes")

var Lit_27 *jrt.String = jrt.Intern("arbace.core.server$prepl$fn__1213000096")

var Lit_28 *jrt.String = jrt.Intern("arbace.core.server$prepl$fn__1213000098")

var Lit_29 *jrt.String = jrt.Intern("arbace.core.server$prepl$fn__1213000100")

var Lit_30 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl$default__1213000123__1213000125")

var Lit_31 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl$fn__1213000128")

var Lit_32 *jrt.String = jrt.Intern("arbace.core.server/remote-prepl")

var Lit_33 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl$fn__1213000128$fn__1213000131")

var Lit_34 *jrt.String = jrt.Intern("Missing required socket server property ")

var Lit_35 *jrt.String = jrt.Intern("can't resolve: ")

var Lit_36 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000049")

var Lit_37 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052")

var Lit_38 *jrt.String = jrt.Intern("Arbace Server ")

var Lit_39 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052$fn__1213000053")

var Lit_40 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052$fn__1213000058")

var Lit_41 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052$fn__1213000053$fn__1213000055")

var Lit_42 *jrt.String = jrt.Intern("Arbace Connection ")

var Lit_43 *jrt.String = jrt.Intern(" ")

var Lit_44 *jrt.String = jrt.Intern("arbace.core.server$stop_servers$fn__1213000067")

var Lit_45 *jrt.String = jrt.Intern("arbace.core.server$stop_servers$fn__1213000069")

var Lit_46 *jrt.String = jrt.Intern("Invalid socket server port: ")

var Lit_47 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn9,lock-expryn1,&yn4,bodykn3,tagyn6,Stringyn6,daemonyn4,optsyn4,propkn4,keysyn4,nameyn4,portyn6,acceptkn2,asyn6,Socketyn9,client-idyn2,inyn3,outyn3,erryn4,argsyn10,Propertiesyn12,system-propsyn14,request-promptyn12,request-exityn2,exyn5,phaseyn9,in-readeryn6,out-fnyn5,stdinkn5,addedyn4,valfkn2,oryn6,pr-stryn6,Readeryn5,readfyn11,read-stringyn3,fn*yn15,p1__1213000117#yn15,p2__1213000118#yn4,readv11,arbace.core5,in-nsMyn18,arbace.core.serverm4,R0,s21,Socket server supportR1,s11,Alex Millerm4,R0,s21,Socket server supportR1,s11,Alex MillerR2,v11,arbace.core20,*warn-on-reflection*v18,arbace.core.server9,*session*m8,R3,TR4,i24,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server4,lockm8,R7,TR4,i27,R5,i1,R6,s21,arbace/core/server.aem8,R7,TR4,i27,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server7,serversm8,R7,TR4,i28,R5,i1,R6,s21,arbace/core/server.aem8,R7,TR4,i28,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server9,with-lockm10,R7,TR8,L1,V3,R9,R10,R11,R4,i30,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server6,threadm10,R7,TR8,L1,V4,Myn4,namem2,R12,R13,R14,R10,R11,R4,i39,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server8,requiredm12,R7,TR8,L1,V2,R15,R16,R0,s36,Throw if opts does not contain prop.R4,i45,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server13,validate-optsm12,R7,TR8,L1,V1,m4,R17,V3,R18,R19,R20,R21,R15,R0,s30,Validate server config optionsR4,i51,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server17,accept-connectionm12,R7,TR8,L1,V8,Myn4,connm2,R12,R22,R18,R23,R24,R25,R26,R20,R27,R0,s278,Start accept function, to be invoked on a client thread, given:\n    conn - client socket\n    name - server name\n    client-id - client identifier\n    in - in stream\n    out - out stream\n    err - err stream\n    accept - accept fn symbol to invoke\n    args - to pass to accept-fnR4,i58,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server12,start-serverm10,R8,L1,V1,R15,R0,s518,Start a socket server given the specified opts:\n    :address Host or address, string, defaults to loopback address\n    :port Port, integer, required\n    :name Name, required\n    :accept Namespaced symbol of the accept function to invoke, required\n    :args Vector of args to pass to accept function\n    :bind-err Bind *err* to socket out stream?, defaults to true\n    :server-daemon Is server thread a daemon?, defaults to true\n    :client-daemon Are client threads daemons?, defaults to true\n   Returns server socket.R4,i85,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server11,stop-serverm10,R8,L2,V0,V1,R18,R0,s195,Stop server with name or use the server-name from *session* if none supplied.\n  Returns true if server stopped successfully, nil if not found, or throws if\n  there is an error closing the socket.R4,i126,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server12,stop-serversm10,R8,L1,V0,R0,s53,Stop all servers ignores all errors, and returns nil.R4,i140,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server11,parse-propsm12,R7,TR8,L1,V1,Myn5,propsm2,R12,R28,R0,s73,Parse arbace.server.* from properties to produce a map of server configs.R4,i147,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server13,start-serversm10,R8,L1,V1,R29,R0,s53,Start all servers specified in the system properties.R4,i160,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server9,repl-initm10,R8,L1,V0,R0,s66,Initialize repl in user namespace and make standard repl requires.R4,i166,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server9,repl-readm10,R8,L1,V2,R30,R31,R0,s51,Enhanced :read hook for repl supporting :repl/quit.R4,i172,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server4,replm10,R8,L1,V0,R0,s56,REPL with predefined hooks for attachable socket server.R4,i183,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server8,ex->datam10,R7,TR8,L1,V2,R32,R33,R4,i190,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server5,preplm12,R8,L1,V4,R34,R35,R10,m2,R17,V1,R36,R0,s880,a REPL with structured output (for programs)\n  reads forms to eval from in-reader (a LineNumberingPushbackReader)\n  Closing the input or passing the form :repl/quit will cause it to return\n\n  Calls out-fn with data, one of:\n  {:tag :ret\n   :val val ;;eval result, or Throwable->map data if exception thrown\n   :ns ns-name-string\n   :ms long ;;eval time in milliseconds\n   :form string ;;iff successfully read\n   :exception true ;;iff exception thrown\n  }\n  {:tag :out\n   :val string} ;chars from during-eval *out*\n  {:tag :err\n   :val string} ;chars from during-eval *err*\n  {:tag :tap\n   :val val} ;values from tap>\n\n  You might get more than one :out or :err per eval, but exactly one :ret\n  tap output can happen at any time (i.e. between evals)\n  If during eval an attempt is made to read *in* it will read from in-reader unless :stdin is supplied\n\n  Alpha, subject to change.R37,s4,1.10R4,i194,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server10,resolve-fnm10,R7,TR8,L1,V1,R38,R4,i269,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server8,io-preplm12,R8,L1,V2,R10,m4,R17,V1,R38,R39,m2,R38,R40,R0,s225,prepl bound to *in* and *out*, suitable for use with e.g. server/repl (socket-repl).\n  :ret and :tap vals will be processed by valf, a fn of one argument\n  or a symbol naming same (default pr-str)\n\n  Alpha, subject to change.R37,s4,1.10R4,i278,R5,i1,R6,s21,arbace/core/server.aev18,arbace.core.server12,remote-preplm12,R8,L1,V6,Myn4,hostm2,R12,R13,R19,Myn9,in-readerm2,R12,R41,R35,R10,m4,R17,V2,R38,R42,R39,m4,R38,R43,R42,L3,R44,V2,R45,R46,ML4,R47,R45,FR46,m4,R4,i313,R5,i73,R0,s440,Implements a prepl on in-reader and out-fn by forwarding to a\n  remote [io-]prepl over a socket.  Messages will be read by readf, a\n  fn of a LineNumberingPushbackReader and EOF value or a symbol naming\n  same (default #(read %1 false %2)),\n  :ret and :tap vals will be processed by valf, a fn of one argument\n  or a symbol naming same (default read-string). If that function\n  throws, :val will be unprocessed.\n\n  Alpha, subject to change.R37,s4,1.10R4,i301,R5,i1,R6,s21,arbace/core/server.ae")

var Lit_48 *jrt.String = jrt.Intern("arbace.core.server$eval1213000004$loading__1927001464__auto____1213000005")

var Lit_49 *jrt.String = jrt.Intern("arbace.core.server$eval1213000008$fn__1213000009")

var Lit_50 *jrt.String = jrt.Intern("arbace.core.server$with_lock")

var Lit_51 *jrt.String = jrt.Intern("arbace.core.server$thread")

var Lit_52 *jrt.String = jrt.Intern("arbace.core.server$required")

var Lit_53 *jrt.String = jrt.Intern("arbace.core.server$validate_opts")

var Lit_54 *jrt.String = jrt.Intern("arbace.core.server$accept_connection")

var Lit_55 *jrt.String = jrt.Intern("arbace.core.server$start_server")

var Lit_56 *jrt.String = jrt.Intern("arbace.core.server$stop_server")

var Lit_57 *jrt.String = jrt.Intern("arbace.core.server$stop_servers")

var Lit_58 *jrt.String = jrt.Intern("arbace.core.server$parse_props")

var Lit_59 *jrt.String = jrt.Intern("arbace.core.server$start_servers")

var Lit_60 *jrt.String = jrt.Intern("arbace.core.server$repl_init")

var Lit_61 *jrt.String = jrt.Intern("arbace.core.server$repl_read")

var Lit_62 *jrt.String = jrt.Intern("arbace.core.server$repl")

var Lit_63 *jrt.String = jrt.Intern("arbace.core.server$ex__GT_data")

var Lit_64 *jrt.String = jrt.Intern("arbace.core.server$prepl")

var Lit_65 *jrt.String = jrt.Intern("arbace.core.server$resolve_fn")

var Lit_66 *jrt.String = jrt.Intern("arbace.core.server$io_prepl")

var Lit_67 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl")
