//line a2g_strings.ae:1
package aot_arbace_core_server

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.edn")

var Lit_7 *jrt.String = jrt.Intern("edn")

var Lit_8 *jrt.String = jrt.Intern("arbace.main")

var Lit_9 *jrt.String = jrt.Intern("m")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.core.server")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("Socket server support")

var Lit_16 *jrt.String = jrt.Intern("author")

var Lit_17 *jrt.String = jrt.Intern("Alex Miller")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("seq")

var Lit_20 *jrt.String = jrt.Intern("concat")

var Lit_21 *jrt.String = jrt.Intern("list")

var Lit_22 *jrt.String = jrt.Intern("let")

var Lit_23 *jrt.String = jrt.Intern("apply")

var Lit_24 *jrt.String = jrt.Intern("vector")

var Lit_25 *jrt.String = jrt.Intern("lockee__1213000018__auto__")

var Lit_26 *jrt.String = jrt.Intern("with-meta")

var Lit_27 *jrt.String = jrt.Intern("tag")

var Lit_28 *jrt.String = jrt.Intern("java.util.concurrent.locks.ReentrantLock")

var Lit_29 *jrt.String = jrt.Intern(".lock")

var Lit_30 *jrt.String = jrt.Intern("try")

var Lit_31 *jrt.String = jrt.Intern("finally")

var Lit_32 *jrt.String = jrt.Intern(".unlock")

var Lit_33 *jrt.String = jrt.Intern("doto")

var Lit_34 *jrt.String = jrt.Intern("java.lang.Thread.")

var Lit_35 *jrt.String = jrt.Intern("fn")

var Lit_36 *jrt.String = jrt.Intern(".setDaemon")

var Lit_37 *jrt.String = jrt.Intern(".start")

var Lit_38 *jrt.String = jrt.Intern("ex-info")

var Lit_39 *jrt.String = jrt.Intern("next")

var Lit_40 *jrt.String = jrt.Intern("to-array")

var Lit_41 *jrt.String = jrt.Intern("first")

var Lit_42 *jrt.String = jrt.Intern("name")

var Lit_43 *jrt.String = jrt.Intern("port")

var Lit_44 *jrt.String = jrt.Intern("accept")

var Lit_45 *jrt.String = jrt.Intern("not")

var Lit_46 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_47 *jrt.String = jrt.Intern("chunk-first")

var Lit_48 *jrt.String = jrt.Intern("required")

var Lit_49 *jrt.String = jrt.Intern("chunk-rest")

var Lit_50 *jrt.String = jrt.Intern("integer?")

var Lit_51 *jrt.String = jrt.Intern("<=")

var Lit_52 *jrt.String = jrt.Intern("resolve")

var Lit_53 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_54 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_55 *jrt.String = jrt.Intern("hash-map")

var Lit_56 *jrt.String = jrt.Intern("*in*")

var Lit_57 *jrt.String = jrt.Intern("*out*")

var Lit_58 *jrt.String = jrt.Intern("*err*")

var Lit_59 *jrt.String = jrt.Intern("*session*")

var Lit_60 *jrt.String = jrt.Intern("server")

var Lit_61 *jrt.String = jrt.Intern("client")

var Lit_62 *jrt.String = jrt.Intern("lock")

var Lit_63 *jrt.String = jrt.Intern("alter-var-root")

var Lit_64 *jrt.String = jrt.Intern("servers")

var Lit_65 *jrt.String = jrt.Intern("assoc-in")

var Lit_66 *jrt.String = jrt.Intern("sessions")

var Lit_67 *jrt.String = jrt.Intern("symbol")

var Lit_68 *jrt.String = jrt.Intern("namespace")

var Lit_69 *jrt.String = jrt.Intern("update-in")

var Lit_70 *jrt.String = jrt.Intern("dissoc")

var Lit_71 *jrt.String = jrt.Intern("address")

var Lit_72 *jrt.String = jrt.Intern("args")

var Lit_73 *jrt.String = jrt.Intern("bind-err")

var Lit_74 *jrt.String = jrt.Intern("server-daemon")

var Lit_75 *jrt.String = jrt.Intern("client-daemon")

var Lit_76 *jrt.String = jrt.Intern("validate-opts")

var Lit_77 *jrt.String = jrt.Intern("assoc")

var Lit_78 *jrt.String = jrt.Intern("socket")

var Lit_79 *jrt.String = jrt.Intern("accept-connection")

var Lit_80 *jrt.String = jrt.Intern("get-in")

var Lit_81 *jrt.String = jrt.Intern("stop-server")

var Lit_82 *jrt.String = jrt.Intern("keys")

var Lit_83 *jrt.String = jrt.Intern("future-call")

var Lit_84 *jrt.String = jrt.Intern("reduce")

var Lit_85 *jrt.String = jrt.Intern("split")

var Lit_86 *jrt.String = jrt.Intern("\\.")

var Lit_87 *jrt.String = jrt.Intern("merge")

var Lit_88 *jrt.String = jrt.Intern("read-string")

var Lit_89 *jrt.String = jrt.Intern("parse-props")

var Lit_90 *jrt.String = jrt.Intern("start-server")

var Lit_91 *jrt.String = jrt.Intern("in-ns")

var Lit_92 *jrt.String = jrt.Intern("user")

var Lit_93 *jrt.String = jrt.Intern("repl-requires")

var Lit_94 *jrt.String = jrt.Intern("line-start")

var Lit_95 *jrt.String = jrt.Intern("stream-end")

var Lit_96 *jrt.String = jrt.Intern("read")

var Lit_97 *jrt.String = jrt.Intern("repl")

var Lit_98 *jrt.String = jrt.Intern("quit")

var Lit_99 *jrt.String = jrt.Intern("skip-whitespace")

var Lit_100 *jrt.String = jrt.Intern("read-cond")

var Lit_101 *jrt.String = jrt.Intern("allow")

var Lit_102 *jrt.String = jrt.Intern("skip-if-eol")

var Lit_103 *jrt.String = jrt.Intern("init")

var Lit_104 *jrt.String = jrt.Intern("repl-init")

var Lit_105 *jrt.String = jrt.Intern("repl-read")

var Lit_106 *jrt.String = jrt.Intern("Throwable->map")

var Lit_107 *jrt.String = jrt.Intern("phase")

var Lit_108 *jrt.String = jrt.Intern("stdin")

var Lit_109 *jrt.String = jrt.Intern("tap")

var Lit_110 *jrt.String = jrt.Intern("val")

var Lit_111 *jrt.String = jrt.Intern("read+string")

var Lit_112 *jrt.String = jrt.Intern("eval")

var Lit_113 *jrt.String = jrt.Intern("eof")

var Lit_114 *jrt.String = jrt.Intern("*3")

var Lit_115 *jrt.String = jrt.Intern("*2")

var Lit_116 *jrt.String = jrt.Intern("*1")

var Lit_117 *jrt.String = jrt.Intern("ret")

var Lit_118 *jrt.String = jrt.Intern("ns")

var Lit_119 *jrt.String = jrt.Intern("ms")

var Lit_120 *jrt.String = jrt.Intern("form")

var Lit_121 *jrt.String = jrt.Intern("*ns*")

var Lit_122 *jrt.String = jrt.Intern("*e")

var Lit_123 *jrt.String = jrt.Intern("ex->data")

var Lit_124 *jrt.String = jrt.Intern("exception")

var Lit_125 *jrt.String = jrt.Intern("arbace.error")

var Lit_126 *jrt.String = jrt.Intern("ex-data")

var Lit_127 *jrt.String = jrt.Intern("execution")

var Lit_128 *jrt.String = jrt.Intern("read-source")

var Lit_129 *jrt.String = jrt.Intern("remove-tap")

var Lit_130 *jrt.String = jrt.Intern("java.lang.Thread")

var Lit_131 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_132 *jrt.String = jrt.Intern("*math-context*")

var Lit_133 *jrt.String = jrt.Intern("*print-meta*")

var Lit_134 *jrt.String = jrt.Intern("*print-length*")

var Lit_135 *jrt.String = jrt.Intern("*print-level*")

var Lit_136 *jrt.String = jrt.Intern("*print-namespace-maps*")

var Lit_137 *jrt.String = jrt.Intern("*data-readers*")

var Lit_138 *jrt.String = jrt.Intern("*default-data-reader-fn*")

var Lit_139 *jrt.String = jrt.Intern("*compile-path*")

var Lit_140 *jrt.String = jrt.Intern("*command-line-args*")

var Lit_141 *jrt.String = jrt.Intern("*unchecked-math*")

var Lit_142 *jrt.String = jrt.Intern("*assert*")

var Lit_143 *jrt.String = jrt.Intern("arbace.spec.alpha")

var Lit_144 *jrt.String = jrt.Intern("*explain-out*")

var Lit_145 *jrt.String = jrt.Intern("*repl*")

var Lit_146 *jrt.String = jrt.Intern("PrintWriter-on")

var Lit_147 *jrt.String = jrt.Intern("out")

var Lit_148 *jrt.String = jrt.Intern("err")

var Lit_149 *jrt.String = jrt.Intern("add-tap")

var Lit_150 *jrt.String = jrt.Intern("symbol?")

var Lit_151 *jrt.String = jrt.Intern("pr-str")

var Lit_152 *jrt.String = jrt.Intern("valf")

var Lit_153 *jrt.String = jrt.Intern("resolve-fn")

var Lit_154 *jrt.String = jrt.Intern("prepl")

var Lit_155 *jrt.String = jrt.Intern("prn")

var Lit_156 *jrt.String = jrt.Intern("*flush-on-newline*")

var Lit_157 *jrt.String = jrt.Intern("*print-readably*")

var Lit_158 *jrt.String = jrt.Intern("print-eval-result")

var Lit_159 *jrt.String = jrt.Intern("readf")

var Lit_160 *jrt.String = jrt.Intern("string?")

var Lit_161 *jrt.String = jrt.Intern("read-eval-result")

var Lit_162 *jrt.String = jrt.Intern("arbace.core.server$accept_connection")

var Lit_163 *jrt.String = jrt.Intern("arbace.core.server$accept_connection$fn__1213000038")

var Lit_164 *jrt.String = jrt.Intern("arbace.core.server$accept_connection$fn__1213000040")

var Lit_165 *jrt.String = jrt.Intern("arbace.core.server$eval1213000004$loading__1927001464__auto____1213000005")

var Lit_166 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_167 *jrt.String = jrt.Intern("java.net.InetAddress")

var Lit_168 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_169 *jrt.String = jrt.Intern("java.net.ServerSocket")

var Lit_170 *jrt.String = jrt.Intern("java.net.SocketException")

var Lit_171 *jrt.String = jrt.Intern("java.io.Reader")

var Lit_172 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_173 *jrt.String = jrt.Intern("java.io.PrintWriter")

var Lit_174 *jrt.String = jrt.Intern("java.io.BufferedWriter")

var Lit_175 *jrt.String = jrt.Intern("java.io.BufferedReader")

var Lit_176 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_177 *jrt.String = jrt.Intern("java.io.OutputStreamWriter")

var Lit_178 *jrt.String = jrt.Intern("java.util.Properties")

var Lit_179 *jrt.String = jrt.Intern("arbace.core.server$eval1213000008$fn__1213000009")

var Lit_180 *jrt.String = jrt.Intern("arbace.core.server$ex__GT_data")

var Lit_181 *jrt.String = jrt.Intern("arbace.core.server$io_prepl")

var Lit_182 *jrt.String = jrt.Intern("arbace.core.server$io_prepl$fn__1213000112")

var Lit_183 *jrt.String = jrt.Intern("arbace.core.server$io_prepl$fn__1213000112$fn__1213000113")

var Lit_184 *jrt.String = jrt.Intern("arbace.core.server$parse_props")

var Lit_185 *jrt.String = jrt.Intern("arbace.core.server$parse_props$fn__1213000072")

var Lit_186 *jrt.String = jrt.Intern("arbace")

var Lit_187 *jrt.String = jrt.Intern("arbace.core.server$prepl")

var Lit_188 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_189 *jrt.String = jrt.Intern("setContextClassLoader")

var Lit_190 *jrt.String = jrt.Intern("arbace.compile.path")

var Lit_191 *jrt.String = jrt.Intern("classes")

var Lit_192 *jrt.String = jrt.Intern("arbace.core.server$prepl$fn__1213000096")

var Lit_193 *jrt.String = jrt.Intern("arbace.core.server$prepl$fn__1213000098")

var Lit_194 *jrt.String = jrt.Intern("arbace.core.server$prepl$fn__1213000100")

var Lit_195 *jrt.String = jrt.Intern("arbace.core.server$prepl$tapfn__1213000094")

var Lit_196 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl")

var Lit_197 *jrt.String = jrt.Intern("arbace.core.server/remote-prepl")

var Lit_198 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl$default__1213000123__1213000125")

var Lit_199 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl$fn__1213000128")

var Lit_200 *jrt.String = jrt.Intern("arbace.core.server$remote_prepl$fn__1213000128$fn__1213000131")

var Lit_201 *jrt.String = jrt.Intern("arbace.core.server$repl")

var Lit_202 *jrt.String = jrt.Intern("arbace.core.server$repl_init")

var Lit_203 *jrt.String = jrt.Intern("arbace.core.server$repl_read")

var Lit_204 *jrt.String = jrt.Intern("arbace.core.server$required")

var Lit_205 *jrt.String = jrt.Intern("Missing required socket server property ")

var Lit_206 *jrt.String = jrt.Intern("arbace.core.server$resolve_fn")

var Lit_207 *jrt.String = jrt.Intern("can't resolve: ")

var Lit_208 *jrt.String = jrt.Intern("arbace.core.server$start_server")

var Lit_209 *jrt.String = jrt.Intern("Arbace Server ")

var Lit_210 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000049")

var Lit_211 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052")

var Lit_212 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052$fn__1213000053")

var Lit_213 *jrt.String = jrt.Intern("Arbace Connection ")

var Lit_214 *jrt.String = jrt.Intern(" ")

var Lit_215 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052$fn__1213000053$fn__1213000055")

var Lit_216 *jrt.String = jrt.Intern("arbace.core.server$start_server$fn__1213000052$fn__1213000058")

var Lit_217 *jrt.String = jrt.Intern("arbace.core.server$start_servers")

var Lit_218 *jrt.String = jrt.Intern("arbace.core.server$stop_server")

var Lit_219 *jrt.String = jrt.Intern("arbace.core.server$stop_servers")

var Lit_220 *jrt.String = jrt.Intern("arbace.core.server$stop_servers$fn__1213000067")

var Lit_221 *jrt.String = jrt.Intern("arbace.core.server$stop_servers$fn__1213000069")

var Lit_222 *jrt.String = jrt.Intern("arbace.core.server$thread")

var Lit_223 *jrt.String = jrt.Intern("arbace.core.server$validate_opts")

var Lit_224 *jrt.String = jrt.Intern("Invalid socket server port: ")

var Lit_225 *jrt.String = jrt.Intern("arbace.core.server$with_lock")

var Lit_226 *jrt.String = jrt.Intern("dynamic")

var Lit_227 *jrt.String = jrt.Intern("line")

var Lit_228 *jrt.String = jrt.Intern("column")

var Lit_229 *jrt.String = jrt.Intern("file")

var Lit_230 *jrt.String = jrt.Intern("arbace/core/server.ae")

var Lit_231 *jrt.String = jrt.Intern("private")

var Lit_232 *jrt.String = jrt.Intern("with-lock")

var Lit_233 *jrt.String = jrt.Intern("arglists")

var Lit_234 *jrt.String = jrt.Intern("lock-expr")

var Lit_235 *jrt.String = jrt.Intern("&")

var Lit_236 *jrt.String = jrt.Intern("body")

var Lit_237 *jrt.String = jrt.Intern("thread")

var Lit_238 *jrt.String = jrt.Intern("String")

var Lit_239 *jrt.String = jrt.Intern("daemon")

var Lit_240 *jrt.String = jrt.Intern("opts")

var Lit_241 *jrt.String = jrt.Intern("prop")

var Lit_242 *jrt.String = jrt.Intern("Throw if opts does not contain prop.")

var Lit_243 *jrt.String = jrt.Intern("Validate server config options")

var Lit_244 *jrt.String = jrt.Intern("conn")

var Lit_245 *jrt.String = jrt.Intern("Socket")

var Lit_246 *jrt.String = jrt.Intern("client-id")

var Lit_247 *jrt.String = jrt.Intern("in")

var Lit_248 *jrt.String = jrt.Intern("Start accept function, to be invoked on a client thread, given:\n    conn - client socket\n    name - server name\n    client-id - client identifier\n    in - in stream\n    out - out stream\n    err - err stream\n    accept - accept fn symbol to invoke\n    args - to pass to accept-fn")

var Lit_249 *jrt.String = jrt.Intern("Start a socket server given the specified opts:\n    :address Host or address, string, defaults to loopback address\n    :port Port, integer, required\n    :name Name, required\n    :accept Namespaced symbol of the accept function to invoke, required\n    :args Vector of args to pass to accept function\n    :bind-err Bind *err* to socket out stream?, defaults to true\n    :server-daemon Is server thread a daemon?, defaults to true\n    :client-daemon Are client threads daemons?, defaults to true\n   Returns server socket.")

var Lit_250 *jrt.String = jrt.Intern("Stop server with name or use the server-name from *session* if none supplied.\n  Returns true if server stopped successfully, nil if not found, or throws if\n  there is an error closing the socket.")

var Lit_251 *jrt.String = jrt.Intern("stop-servers")

var Lit_252 *jrt.String = jrt.Intern("Stop all servers ignores all errors, and returns nil.")

var Lit_253 *jrt.String = jrt.Intern("props")

var Lit_254 *jrt.String = jrt.Intern("Properties")

var Lit_255 *jrt.String = jrt.Intern("Parse arbace.server.* from properties to produce a map of server configs.")

var Lit_256 *jrt.String = jrt.Intern("start-servers")

var Lit_257 *jrt.String = jrt.Intern("system-props")

var Lit_258 *jrt.String = jrt.Intern("Start all servers specified in the system properties.")

var Lit_259 *jrt.String = jrt.Intern("Initialize repl in user namespace and make standard repl requires.")

var Lit_260 *jrt.String = jrt.Intern("request-prompt")

var Lit_261 *jrt.String = jrt.Intern("request-exit")

var Lit_262 *jrt.String = jrt.Intern("Enhanced :read hook for repl supporting :repl/quit.")

var Lit_263 *jrt.String = jrt.Intern("REPL with predefined hooks for attachable socket server.")

var Lit_264 *jrt.String = jrt.Intern("ex")

var Lit_265 *jrt.String = jrt.Intern("in-reader")

var Lit_266 *jrt.String = jrt.Intern("out-fn")

var Lit_267 *jrt.String = jrt.Intern("a REPL with structured output (for programs)\n  reads forms to eval from in-reader (a LineNumberingPushbackReader)\n  Closing the input or passing the form :repl/quit will cause it to return\n\n  Calls out-fn with data, one of:\n  {:tag :ret\n   :val val ;;eval result, or Throwable->map data if exception thrown\n   :ns ns-name-string\n   :ms long ;;eval time in milliseconds\n   :form string ;;iff successfully read\n   :exception true ;;iff exception thrown\n  }\n  {:tag :out\n   :val string} ;chars from during-eval *out*\n  {:tag :err\n   :val string} ;chars from during-eval *err*\n  {:tag :tap\n   :val val} ;values from tap>\n\n  You might get more than one :out or :err per eval, but exactly one :ret\n  tap output can happen at any time (i.e. between evals)\n  If during eval an attempt is made to read *in* it will read from in-reader unless :stdin is supplied\n\n  Alpha, subject to change.")

var Lit_268 *jrt.String = jrt.Intern("added")

var Lit_269 *jrt.String = jrt.Intern("1.10")

var Lit_270 *jrt.String = jrt.Intern("io-prepl")

var Lit_271 *jrt.String = jrt.Intern("or")

var Lit_272 *jrt.String = jrt.Intern("prepl bound to *in* and *out*, suitable for use with e.g. server/repl (socket-repl).\n  :ret and :tap vals will be processed by valf, a fn of one argument\n  or a symbol naming same (default pr-str)\n\n  Alpha, subject to change.")

var Lit_273 *jrt.String = jrt.Intern("remote-prepl")

var Lit_274 *jrt.String = jrt.Intern("host")

var Lit_275 *jrt.String = jrt.Intern("Reader")

var Lit_276 *jrt.String = jrt.Intern("fn*")

var Lit_277 *jrt.String = jrt.Intern("p1__1213000117#")

var Lit_278 *jrt.String = jrt.Intern("p2__1213000118#")

var Lit_279 *jrt.String = jrt.Intern("Implements a prepl on in-reader and out-fn by forwarding to a\n  remote [io-]prepl over a socket.  Messages will be read by readf, a\n  fn of a LineNumberingPushbackReader and EOF value or a symbol naming\n  same (default #(read %1 false %2)),\n  :ret and :tap vals will be processed by valf, a fn of one argument\n  or a symbol naming same (default read-string). If that function\n  throws, :val will be unprocessed.\n\n  Alpha, subject to change.")
