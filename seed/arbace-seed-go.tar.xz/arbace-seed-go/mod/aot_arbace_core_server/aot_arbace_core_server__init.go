//line aot_arbace_core_server__init.ae:1
package aot_arbace_core_server

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_server__init_A_Load__O() any { A_arbace_core_server__init_A_Init(); A_arbace_core_server__init_A_Unit0__O(); A_arbace_core_server__init_A_Unit1__O(); A_arbace_core_server__init_A_Unit2__O(); A_arbace_core_server__init_A_Unit3__O(); A_arbace_core_server__init_A_Unit4__O(); A_arbace_core_server__init_A_Unit5__O(); A_arbace_core_server__init_A_Unit6__O(); A_arbace_core_server__init_A_Unit7__O(); A_arbace_core_server__init_A_Unit8__O(); A_arbace_core_server__init_A_Unit9__O(); A_arbace_core_server__init_A_Unit10__O(); A_arbace_core_server__init_A_Unit11__O(); A_arbace_core_server__init_A_Unit12__O(); A_arbace_core_server__init_A_Unit13__O(); A_arbace_core_server__init_A_Unit14__O(); A_arbace_core_server__init_A_Unit15__O(); A_arbace_core_server__init_A_Unit16__O(); A_arbace_core_server__init_A_Unit17__O(); A_arbace_core_server__init_A_Unit18__O(); A_arbace_core_server__init_A_Unit19__O(); A_arbace_core_server__init_A_Unit20__O(); A_arbace_core_server__init_A_Unit21__O(); A_arbace_core_server__init_A_Unit22__O(); A_arbace_core_server__init_A_Unit23__O(); A_arbace_core_server__init_A_Unit24__O(); A_arbace_core_server__init_A_Unit25__O(); A_arbace_core_server__init_A_Unit26__O(); A_arbace_core_server__init_A_Unit27__O(); A_arbace_core_server__init_A_Unit28__O(); A_arbace_core_server__init_A_Unit29__O(); return nil }



func A_arbace_core_server__init_A_Unit0__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(A_arbace_core_server__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server__init_A_const_1) }
//line :9:1
func A_arbace_core_server__init_A_Unit1__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_core_server__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_2)) }
//line :9:1
func A_arbace_core_server__init_A_Unit2__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_core_server__init_A_Unit3__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_server__init_A_const_1)).Equals_O__Z(A_arbace_core_server__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_core_server_eval1213000008_fn__1213000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }












func A_arbace_core_server__init_A_Unit4__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }

func A_arbace_core_server__init_A_Unit5__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); A_arbace_core_server__init_A_const_5.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_6)); return A_arbace_core_server__init_A_const_5.SetDynamic_Z__Var(true).Ref() }


func A_arbace_core_server__init_A_Unit6__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_server__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_8)); v__1927001498__auto____1 = A_arbace_core_server__init_A_const_7; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_server__init_A_const_7; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_9)); var tmp3 *lang.Var = A_arbace_core_server__init_A_const_7; tmp3.BindRoot_O__V(jrt.ReentrantLock_New()); return A_arbace_core_server__init_A_const_7 } }
func A_arbace_core_server__init_A_Unit7__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_server__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_11)); v__1927001498__auto____1 = A_arbace_core_server__init_A_const_10; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_server__init_A_const_10; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_12)); var tmp3 *lang.Var = A_arbace_core_server__init_A_const_10; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_core_server__init_A_const_10 } }

func A_arbace_core_server__init_A_Unit8__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_13; var tmp2 any = A_arbace_core_server_with_lock_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_core_server_with_lock_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, true); A_arbace_core_server_with_lock_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_14)); return A_arbace_core_server__init_A_const_13 }
//line :30:1
func A_arbace_core_server__init_A_Unit9__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); A_arbace_core_server__init_A_const_13.SetMacro__V(); return nil }
//line :30:1
func A_arbace_core_server__init_A_Unit10__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); return A_arbace_core_server__init_A_const_13 }








func A_arbace_core_server__init_A_Unit11__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_15; var tmp2 any = A_arbace_core_server_thread_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_core_server_thread_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, true); A_arbace_core_server_thread_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_16)); return A_arbace_core_server__init_A_const_15 }
//line :39:1
func A_arbace_core_server__init_A_Unit12__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); A_arbace_core_server__init_A_const_15.SetMacro__V(); return nil }
//line :39:1
func A_arbace_core_server__init_A_Unit13__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); return A_arbace_core_server__init_A_const_15 }





func A_arbace_core_server__init_A_Unit14__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_17; var tmp2 any = A_arbace_core_server_required_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_core_server_required_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_core_server_required_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_18)); return A_arbace_core_server__init_A_const_17 }





func A_arbace_core_server__init_A_Unit15__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_19; var tmp2 any = A_arbace_core_server_validate_opts_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_core_server_validate_opts_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_core_server_validate_opts_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_20)); return A_arbace_core_server__init_A_const_19 }






func A_arbace_core_server__init_A_Unit16__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_21; var tmp2 any = A_arbace_core_server_accept_connection_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_core_server_accept_connection_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_core_server_accept_connection_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_22)); return A_arbace_core_server__init_A_const_21 }


























func A_arbace_core_server__init_A_Unit17__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_23; var tmp2 any = A_arbace_core_server_start_server_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_core_server_start_server_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_core_server_start_server_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_24)); return A_arbace_core_server__init_A_const_23 }








































func A_arbace_core_server__init_A_Unit18__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_25; var tmp2 any = A_arbace_core_server_stop_server_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_core_server_stop_server_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_core_server_stop_server_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_26)); return A_arbace_core_server__init_A_const_25 }













func A_arbace_core_server__init_A_Unit19__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(140, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_27; var tmp2 any = A_arbace_core_server_stop_servers_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_core_server_stop_servers_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_core_server_stop_servers_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_28)); return A_arbace_core_server__init_A_const_27 }






func A_arbace_core_server__init_A_Unit20__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_29; var tmp2 any = A_arbace_core_server_parse_props_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_core_server_parse_props_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_core_server_parse_props_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_30)); return A_arbace_core_server__init_A_const_29 }












func A_arbace_core_server__init_A_Unit21__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_31; var tmp2 any = A_arbace_core_server_start_servers_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_server_start_servers_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_core_server_start_servers_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_32)); return A_arbace_core_server__init_A_const_31 }





func A_arbace_core_server__init_A_Unit22__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_33; var tmp2 any = A_arbace_core_server_repl_init_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_core_server_repl_init_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_core_server_repl_init_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_34)); return A_arbace_core_server__init_A_const_33 }





func A_arbace_core_server__init_A_Unit23__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_35; var tmp2 any = A_arbace_core_server_repl_read_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_core_server_repl_read_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_core_server_repl_read_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_36)); return A_arbace_core_server__init_A_const_35 }










func A_arbace_core_server__init_A_Unit24__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_37; var tmp2 any = A_arbace_core_server_repl_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_core_server_repl_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_core_server_repl_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_38)); return A_arbace_core_server__init_A_const_37 }






func A_arbace_core_server__init_A_Unit25__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_39; var tmp2 any = A_arbace_core_server_ex__GT_data_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_server_ex__GT_data_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_core_server_ex__GT_data_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_40)); return A_arbace_core_server__init_A_const_39 }



func A_arbace_core_server__init_A_Unit26__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(194, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_41; var tmp2 any = A_arbace_core_server_prepl_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_core_server_prepl_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, true); A_arbace_core_server_prepl_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_42)); return A_arbace_core_server__init_A_const_41 }










































































func A_arbace_core_server__init_A_Unit27__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(269, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_43; var tmp2 any = A_arbace_core_server_resolve_fn_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_core_server_resolve_fn_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_core_server_resolve_fn_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_44)); return A_arbace_core_server__init_A_const_43 }








func A_arbace_core_server__init_A_Unit28__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(278, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_45; var tmp2 any = A_arbace_core_server_io_prepl_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_core_server_io_prepl_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, true); A_arbace_core_server_io_prepl_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_46)); return A_arbace_core_server__init_A_const_45 }






















func A_arbace_core_server__init_A_Unit29__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(301, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_47; var tmp2 any = A_arbace_core_server_remote_prepl_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_core_server_remote_prepl_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, true); A_arbace_core_server_remote_prepl_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_48)); return A_arbace_core_server__init_A_const_47 }



type A_arbace_core_server__init_A struct{ jrt.Object }

var A_arbace_core_server__init_A_const_pool *jrt.RefArray

var A_arbace_core_server__init_A_const_0 *lang.Var

var A_arbace_core_server__init_A_const_1 any

var A_arbace_core_server__init_A_const_2 any

var A_arbace_core_server__init_A_const_3 any

var A_arbace_core_server__init_A_const_4 *lang.Var

var A_arbace_core_server__init_A_const_5 *lang.Var

var A_arbace_core_server__init_A_const_6 any

var A_arbace_core_server__init_A_const_7 *lang.Var

var A_arbace_core_server__init_A_const_8 any

var A_arbace_core_server__init_A_const_9 any

var A_arbace_core_server__init_A_const_10 *lang.Var

var A_arbace_core_server__init_A_const_11 any

var A_arbace_core_server__init_A_const_12 any

var A_arbace_core_server__init_A_const_13 *lang.Var

var A_arbace_core_server__init_A_const_14 any

var A_arbace_core_server__init_A_const_15 *lang.Var

var A_arbace_core_server__init_A_const_16 any

var A_arbace_core_server__init_A_const_17 *lang.Var

var A_arbace_core_server__init_A_const_18 any

var A_arbace_core_server__init_A_const_19 *lang.Var

var A_arbace_core_server__init_A_const_20 any

var A_arbace_core_server__init_A_const_21 *lang.Var

var A_arbace_core_server__init_A_const_22 any

var A_arbace_core_server__init_A_const_23 *lang.Var

var A_arbace_core_server__init_A_const_24 any

var A_arbace_core_server__init_A_const_25 *lang.Var

var A_arbace_core_server__init_A_const_26 any

var A_arbace_core_server__init_A_const_27 *lang.Var

var A_arbace_core_server__init_A_const_28 any

var A_arbace_core_server__init_A_const_29 *lang.Var

var A_arbace_core_server__init_A_const_30 any

var A_arbace_core_server__init_A_const_31 *lang.Var

var A_arbace_core_server__init_A_const_32 any

var A_arbace_core_server__init_A_const_33 *lang.Var

var A_arbace_core_server__init_A_const_34 any

var A_arbace_core_server__init_A_const_35 *lang.Var

var A_arbace_core_server__init_A_const_36 any

var A_arbace_core_server__init_A_const_37 *lang.Var

var A_arbace_core_server__init_A_const_38 any

var A_arbace_core_server__init_A_const_39 *lang.Var

var A_arbace_core_server__init_A_const_40 any

var A_arbace_core_server__init_A_const_41 *lang.Var

var A_arbace_core_server__init_A_const_42 any

var A_arbace_core_server__init_A_const_43 *lang.Var

var A_arbace_core_server__init_A_const_44 any

var A_arbace_core_server__init_A_const_45 *lang.Var

var A_arbace_core_server__init_A_const_46 any

var A_arbace_core_server__init_A_const_47 *lang.Var

var A_arbace_core_server__init_A_const_48 any

var A_arbace_core_server__init_A_init jrt.ClassInit

func A_arbace_core_server__init_A_Init() { if !A_arbace_core_server__init_A_init.Done() { A_arbace_core_server__init_A_init.Run(A_arbace_core_server__init_A_clinit) } }

func A_arbace_core_server__init_A_clinit() { A_arbace_core_server__init_A_clinit_p0(); A_arbace_core_server__init_A_clinit_p1(); A_arbace_core_server__init_A_clinit_p2(); A_arbace_core_server__init_A_clinit_p3() }

func A_arbace_core_server__init_A_clinit_p0() { A_arbace_core_server__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_47, 97); A_arbace_core_server__init_A_const_0 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[48]); A_arbace_core_server__init_A_const_1 = A_arbace_core_server__init_A_const_pool.A[49]; A_arbace_core_server__init_A_const_2 = A_arbace_core_server__init_A_const_pool.A[50]; A_arbace_core_server__init_A_const_3 = A_arbace_core_server__init_A_const_pool.A[51]; A_arbace_core_server__init_A_const_4 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[52]); A_arbace_core_server__init_A_const_5 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[53]); A_arbace_core_server__init_A_const_6 = A_arbace_core_server__init_A_const_pool.A[54]; A_arbace_core_server__init_A_const_7 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[55]); A_arbace_core_server__init_A_const_8 = A_arbace_core_server__init_A_const_pool.A[56]; A_arbace_core_server__init_A_const_9 = A_arbace_core_server__init_A_const_pool.A[57]; A_arbace_core_server__init_A_const_10 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[58]); A_arbace_core_server__init_A_const_11 = A_arbace_core_server__init_A_const_pool.A[59]; A_arbace_core_server__init_A_const_12 = A_arbace_core_server__init_A_const_pool.A[60] }

func A_arbace_core_server__init_A_clinit_p1() { A_arbace_core_server__init_A_const_13 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[61]); A_arbace_core_server__init_A_const_14 = A_arbace_core_server__init_A_const_pool.A[62]; A_arbace_core_server__init_A_const_15 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[63]); A_arbace_core_server__init_A_const_16 = A_arbace_core_server__init_A_const_pool.A[64]; A_arbace_core_server__init_A_const_17 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[65]); A_arbace_core_server__init_A_const_18 = A_arbace_core_server__init_A_const_pool.A[66]; A_arbace_core_server__init_A_const_19 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[67]); A_arbace_core_server__init_A_const_20 = A_arbace_core_server__init_A_const_pool.A[68]; A_arbace_core_server__init_A_const_21 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[69]); A_arbace_core_server__init_A_const_22 = A_arbace_core_server__init_A_const_pool.A[70]; A_arbace_core_server__init_A_const_23 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[71]); A_arbace_core_server__init_A_const_24 = A_arbace_core_server__init_A_const_pool.A[72]; A_arbace_core_server__init_A_const_25 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[73]) }

func A_arbace_core_server__init_A_clinit_p2() { A_arbace_core_server__init_A_const_26 = A_arbace_core_server__init_A_const_pool.A[74]; A_arbace_core_server__init_A_const_27 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[75]); A_arbace_core_server__init_A_const_28 = A_arbace_core_server__init_A_const_pool.A[76]; A_arbace_core_server__init_A_const_29 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[77]); A_arbace_core_server__init_A_const_30 = A_arbace_core_server__init_A_const_pool.A[78]; A_arbace_core_server__init_A_const_31 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[79]); A_arbace_core_server__init_A_const_32 = A_arbace_core_server__init_A_const_pool.A[80]; A_arbace_core_server__init_A_const_33 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[81]); A_arbace_core_server__init_A_const_34 = A_arbace_core_server__init_A_const_pool.A[82]; A_arbace_core_server__init_A_const_35 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[83]); A_arbace_core_server__init_A_const_36 = A_arbace_core_server__init_A_const_pool.A[84]; A_arbace_core_server__init_A_const_37 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[85]); A_arbace_core_server__init_A_const_38 = A_arbace_core_server__init_A_const_pool.A[86] }

func A_arbace_core_server__init_A_clinit_p3() { A_arbace_core_server__init_A_const_39 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[87]); A_arbace_core_server__init_A_const_40 = A_arbace_core_server__init_A_const_pool.A[88]; A_arbace_core_server__init_A_const_41 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[89]); A_arbace_core_server__init_A_const_42 = A_arbace_core_server__init_A_const_pool.A[90]; A_arbace_core_server__init_A_const_43 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[91]); A_arbace_core_server__init_A_const_44 = A_arbace_core_server__init_A_const_pool.A[92]; A_arbace_core_server__init_A_const_45 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[93]); A_arbace_core_server__init_A_const_46 = A_arbace_core_server__init_A_const_pool.A[94]; A_arbace_core_server__init_A_const_47 = lang.Var_Cast(A_arbace_core_server__init_A_const_pool.A[95]); A_arbace_core_server__init_A_const_48 = A_arbace_core_server__init_A_const_pool.A[96] }

func A_arbace_core_server__init_A_New() *A_arbace_core_server__init_A { A_arbace_core_server__init_A_Init(); t := &A_arbace_core_server__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server__init_A) Ctor() {}

func (t *A_arbace_core_server__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_server__init_A_class }

func (t *A_arbace_core_server__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server__init_A); return ok }

func A_arbace_core_server__init_A_Cast(x any) *A_arbace_core_server__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server__init_A_class)) }; return v }
