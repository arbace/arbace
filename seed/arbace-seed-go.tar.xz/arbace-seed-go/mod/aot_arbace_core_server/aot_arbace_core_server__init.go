//line aot_arbace_core_server__init.ae:1
package aot_arbace_core_server

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_server__init_A_Load__O() any { A_arbace_core_server__init_A_Init(); A_arbace_core_server__init_A_Unit0__O(); A_arbace_core_server__init_A_Unit1__O(); A_arbace_core_server__init_A_Unit2__O(); A_arbace_core_server__init_A_Unit3__O(); A_arbace_core_server__init_A_Unit4__O(); A_arbace_core_server__init_A_Unit5__O(); A_arbace_core_server__init_A_Unit6__O(); A_arbace_core_server__init_A_Unit7__O(); A_arbace_core_server__init_A_Unit8__O(); A_arbace_core_server__init_A_Unit9__O(); A_arbace_core_server__init_A_Unit10__O(); A_arbace_core_server__init_A_Unit11__O(); A_arbace_core_server__init_A_Unit12__O(); A_arbace_core_server__init_A_Unit13__O(); A_arbace_core_server__init_A_Unit14__O(); A_arbace_core_server__init_A_Unit15__O(); A_arbace_core_server__init_A_Unit16__O(); A_arbace_core_server__init_A_Unit17__O(); A_arbace_core_server__init_A_Unit18__O(); A_arbace_core_server__init_A_Unit19__O(); A_arbace_core_server__init_A_Unit20__O(); A_arbace_core_server__init_A_Unit21__O(); A_arbace_core_server__init_A_Unit22__O(); A_arbace_core_server__init_A_Unit23__O(); A_arbace_core_server__init_A_Unit24__O(); A_arbace_core_server__init_A_Unit25__O(); A_arbace_core_server__init_A_Unit26__O(); A_arbace_core_server__init_A_Unit27__O(); A_arbace_core_server__init_A_Unit28__O(); A_arbace_core_server__init_A_Unit29__O(); return nil }



func A_arbace_core_server__init_A_Unit0__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_server__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_server__init_A_const_1) }
//line :9:1
func A_arbace_core_server__init_A_Unit1__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_core_server__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_2)) }
//line :9:1
func A_arbace_core_server__init_A_Unit2__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_New(); var tmp2 *jrt.Class; A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_Init(); tmp2 = A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_core_server__init_A_Unit3__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_core_server__init_A_const_1)).Equals_O__Z(A_arbace_core_server__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_core_server_eval1213000008_fn__1213000009_A_New(); var tmp2 *jrt.Class; A_arbace_core_server_eval1213000008_fn__1213000009_A_Init(); tmp2 = A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }












func A_arbace_core_server__init_A_Unit4__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_core_server__init_A_Unit5__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); jrt.NN(A_arbace_core_server__init_A_const_5).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_5; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_6)); return jrt.NN(A_arbace_core_server__init_A_const_5).SetDynamic_Z__Var(true).Ref() }


func A_arbace_core_server__init_A_Unit6__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_server__init_A_const_7; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_8)); v__1927001498__auto____1 = A_arbace_core_server__init_A_const_7.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_server__init_A_const_7; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_9)); var tmp3 *lang.Var = A_arbace_core_server__init_A_const_7; jrt.NN(tmp3).BindRoot_O__V(jrt.ReentrantLock_New()); return A_arbace_core_server__init_A_const_7.Ref() } }
func A_arbace_core_server__init_A_Unit7__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core_server__init_A_const_10; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_11)); v__1927001498__auto____1 = A_arbace_core_server__init_A_const_10.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core_server__init_A_const_10; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_12)); var tmp3 *lang.Var = A_arbace_core_server__init_A_const_10; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_core_server__init_A_const_10.Ref() } }

func A_arbace_core_server__init_A_Unit8__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_13; var tmp2 any = A_arbace_core_server_with_lock_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_with_lock_A_Init(); tmp3 = A_arbace_core_server_with_lock_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_14)); return A_arbace_core_server__init_A_const_13.Ref() }
//line :30:1
func A_arbace_core_server__init_A_Unit9__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); jrt.NN(A_arbace_core_server__init_A_const_13).SetMacro__V(); return nil }
//line :30:1
func A_arbace_core_server__init_A_Unit10__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); return A_arbace_core_server__init_A_const_13.Ref() }








func A_arbace_core_server__init_A_Unit11__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_15; var tmp2 any = A_arbace_core_server_thread_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_thread_A_Init(); tmp3 = A_arbace_core_server_thread_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_16)); return A_arbace_core_server__init_A_const_15.Ref() }
//line :39:1
func A_arbace_core_server__init_A_Unit12__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); jrt.NN(A_arbace_core_server__init_A_const_15).SetMacro__V(); return nil }
//line :39:1
func A_arbace_core_server__init_A_Unit13__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); return A_arbace_core_server__init_A_const_15.Ref() }





func A_arbace_core_server__init_A_Unit14__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_17; var tmp2 any = A_arbace_core_server_required_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_required_A_Init(); tmp3 = A_arbace_core_server_required_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_18)); return A_arbace_core_server__init_A_const_17.Ref() }





func A_arbace_core_server__init_A_Unit15__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_19; var tmp2 any = A_arbace_core_server_validate_opts_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_validate_opts_A_Init(); tmp3 = A_arbace_core_server_validate_opts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_20)); return A_arbace_core_server__init_A_const_19.Ref() }






func A_arbace_core_server__init_A_Unit16__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_21; var tmp2 any = A_arbace_core_server_accept_connection_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_accept_connection_A_Init(); tmp3 = A_arbace_core_server_accept_connection_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_22)); return A_arbace_core_server__init_A_const_21.Ref() }


























func A_arbace_core_server__init_A_Unit17__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_23; var tmp2 any = A_arbace_core_server_start_server_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_start_server_A_Init(); tmp3 = A_arbace_core_server_start_server_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_24)); return A_arbace_core_server__init_A_const_23.Ref() }








































func A_arbace_core_server__init_A_Unit18__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_25; var tmp2 any = A_arbace_core_server_stop_server_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_stop_server_A_Init(); tmp3 = A_arbace_core_server_stop_server_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_26)); return A_arbace_core_server__init_A_const_25.Ref() }













func A_arbace_core_server__init_A_Unit19__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(140, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_27; var tmp2 any = A_arbace_core_server_stop_servers_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_stop_servers_A_Init(); tmp3 = A_arbace_core_server_stop_servers_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_28)); return A_arbace_core_server__init_A_const_27.Ref() }






func A_arbace_core_server__init_A_Unit20__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_29; var tmp2 any = A_arbace_core_server_parse_props_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_parse_props_A_Init(); tmp3 = A_arbace_core_server_parse_props_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_30)); return A_arbace_core_server__init_A_const_29.Ref() }












func A_arbace_core_server__init_A_Unit21__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_31; var tmp2 any = A_arbace_core_server_start_servers_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_start_servers_A_Init(); tmp3 = A_arbace_core_server_start_servers_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_32)); return A_arbace_core_server__init_A_const_31.Ref() }





func A_arbace_core_server__init_A_Unit22__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_33; var tmp2 any = A_arbace_core_server_repl_init_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_repl_init_A_Init(); tmp3 = A_arbace_core_server_repl_init_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_33; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_34)); return A_arbace_core_server__init_A_const_33.Ref() }





func A_arbace_core_server__init_A_Unit23__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_35; var tmp2 any = A_arbace_core_server_repl_read_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_repl_read_A_Init(); tmp3 = A_arbace_core_server_repl_read_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_36)); return A_arbace_core_server__init_A_const_35.Ref() }










func A_arbace_core_server__init_A_Unit24__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_37; var tmp2 any = A_arbace_core_server_repl_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_repl_A_Init(); tmp3 = A_arbace_core_server_repl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_38)); return A_arbace_core_server__init_A_const_37.Ref() }






func A_arbace_core_server__init_A_Unit25__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_39; var tmp2 any = A_arbace_core_server_ex__GT_data_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_ex__GT_data_A_Init(); tmp3 = A_arbace_core_server_ex__GT_data_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_40)); return A_arbace_core_server__init_A_const_39.Ref() }



func A_arbace_core_server__init_A_Unit26__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(194, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_41; var tmp2 any = A_arbace_core_server_prepl_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_prepl_A_Init(); tmp3 = A_arbace_core_server_prepl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_42)); return A_arbace_core_server__init_A_const_41.Ref() }










































































func A_arbace_core_server__init_A_Unit27__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(269, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_43; var tmp2 any = A_arbace_core_server_resolve_fn_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_resolve_fn_A_Init(); tmp3 = A_arbace_core_server_resolve_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_44)); return A_arbace_core_server__init_A_const_43.Ref() }








func A_arbace_core_server__init_A_Unit28__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(278, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_45; var tmp2 any = A_arbace_core_server_io_prepl_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_io_prepl_A_Init(); tmp3 = A_arbace_core_server_io_prepl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_46)); return A_arbace_core_server__init_A_const_45.Ref() }






















func A_arbace_core_server__init_A_Unit29__O() any { A_arbace_core_server__init_A_Init(); lang.Compiler_AOT_At_I_I__V(301, 1); var tmp1 *lang.Var = A_arbace_core_server__init_A_const_47; var tmp2 any = A_arbace_core_server_remote_prepl_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_remote_prepl_A_Init(); tmp3 = A_arbace_core_server_remote_prepl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core_server__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_server__init_A_const_48)); return A_arbace_core_server__init_A_const_47.Ref() }



type A_arbace_core_server__init_A struct{ jrt.Object }

var A_arbace_core_server__init_A_const_0 *lang.Var

var A_arbace_core_server__init_A_const_1 any

var A_arbace_core_server__init_A_const_2 any

var A_arbace_core_server__init_A_const_3 any

var A_arbace_core_server__init_A_const_4 *lang.Var

var A_arbace_core_server__init_A_const_5 *lang.Var

var A_arbace_core_server__init_A_const_6 any

var A_arbace_core_server__init_A_const_7 *lang.Var

var A_arbace_core_server__init_A_const_8 any

var A_arbace_core_server__init_A_const_9 any

var A_arbace_core_server__init_A_const_10 *lang.Var

var A_arbace_core_server__init_A_const_11 any

var A_arbace_core_server__init_A_const_12 any

var A_arbace_core_server__init_A_const_13 *lang.Var

var A_arbace_core_server__init_A_const_14 any

var A_arbace_core_server__init_A_const_15 *lang.Var

var A_arbace_core_server__init_A_const_16 any

var A_arbace_core_server__init_A_const_17 *lang.Var

var A_arbace_core_server__init_A_const_18 any

var A_arbace_core_server__init_A_const_19 *lang.Var

var A_arbace_core_server__init_A_const_20 any

var A_arbace_core_server__init_A_const_21 *lang.Var

var A_arbace_core_server__init_A_const_22 any

var A_arbace_core_server__init_A_const_23 *lang.Var

var A_arbace_core_server__init_A_const_24 any

var A_arbace_core_server__init_A_const_25 *lang.Var

var A_arbace_core_server__init_A_const_26 any

var A_arbace_core_server__init_A_const_27 *lang.Var

var A_arbace_core_server__init_A_const_28 any

var A_arbace_core_server__init_A_const_29 *lang.Var

var A_arbace_core_server__init_A_const_30 any

var A_arbace_core_server__init_A_const_31 *lang.Var

var A_arbace_core_server__init_A_const_32 any

var A_arbace_core_server__init_A_const_33 *lang.Var

var A_arbace_core_server__init_A_const_34 any

var A_arbace_core_server__init_A_const_35 *lang.Var

var A_arbace_core_server__init_A_const_36 any

var A_arbace_core_server__init_A_const_37 *lang.Var

var A_arbace_core_server__init_A_const_38 any

var A_arbace_core_server__init_A_const_39 *lang.Var

var A_arbace_core_server__init_A_const_40 any

var A_arbace_core_server__init_A_const_41 *lang.Var

var A_arbace_core_server__init_A_const_42 any

var A_arbace_core_server__init_A_const_43 *lang.Var

var A_arbace_core_server__init_A_const_44 any

var A_arbace_core_server__init_A_const_45 *lang.Var

var A_arbace_core_server__init_A_const_46 any

var A_arbace_core_server__init_A_const_47 *lang.Var

var A_arbace_core_server__init_A_const_48 any

var A_arbace_core_server__init_A_init jrt.ClassInit

func A_arbace_core_server__init_A_Init() { if !A_arbace_core_server__init_A_init.Done() { A_arbace_core_server__init_A_init.Run(A_arbace_core_server__init_A_clinit) } }

func A_arbace_core_server__init_A_clinit() { A_arbace_core_server__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_core_server__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_core_server__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_core_server__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_server__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_131); A_arbace_core_server__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_13, Lit_59); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_core_server__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_13, Lit_62); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_core_server__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_core_server__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_13, Lit_64); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_core_server__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_core_server__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_13, Lit_232); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_core_server__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_13, Lit_237); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_core_server__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_42)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_13, Lit_48); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_core_server__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_241).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_242, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_13, Lit_76); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_core_server__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_43).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref()), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_243, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(51).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_13, Lit_79); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_core_server__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_244)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_245).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_246).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_247).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_147).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_148).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_248, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_13, Lit_90); A_arbace_core_server__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_240).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_249, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(85).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_13, Lit_81); A_arbace_core_server__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_250, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(126).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_13, Lit_251); A_arbace_core_server__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_252, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(140).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_13, Lit_89); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_core_server__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_253)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_254).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_255, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(147).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_13, Lit_256); A_arbace_core_server__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_257).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_258, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(160).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_13, Lit_104); A_arbace_core_server__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_259, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(166).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_13, Lit_105); A_arbace_core_server__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_260).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_261).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_262, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(172).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_13, Lit_97); A_arbace_core_server__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_263, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(183).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_13, Lit_123); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_core_server__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_264).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(190).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_13, Lit_154); A_arbace_core_server__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_265).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_235).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_267, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), Lit_269, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(194).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_13, Lit_153); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_231).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_core_server__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(269).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_13, Lit_270); A_arbace_core_server__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_235).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref()), lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref())))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_272, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), Lit_269, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(278).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)); A_arbace_core_server__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_13, Lit_273); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(); var tmp41 any = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_274)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref()))); var tmp42 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_43).Ref(); var tmp43 any = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_265)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_275).Ref()))); var tmp44 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref(); var tmp45 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_235).Ref(); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(); var tmp47 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref()); var tmp48 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_271).Ref(); var tmp49 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref(); var tmp50 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(); var tmp51 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(); var tmp52 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_276).Ref(); var tmp53 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_277).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_278).Ref()); var tmp54 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref(); var tmp55 any = lang.Symbol_Intern_String_String__Symbol(nil, Lit_277).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_FALSE; var tmp57 any = tmp56.Ref(); A_arbace_core_server__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp41, tmp42, tmp43, tmp44, tmp45, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp47, tmp48, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp50, tmp51, lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp53, lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, tmp54, tmp55, tmp57, lang.Symbol_Intern_String_String__Symbol(nil, Lit_278).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(313).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(73).Ref())))))))))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_279, lang.RT_Keyword_String_String__Keyword(nil, Lit_268).Ref(), Lit_269, lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), jrt.Integer_ValueOf_I__Integer(301).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_228).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_229).Ref(), Lit_230)) }

func A_arbace_core_server__init_A_New() *A_arbace_core_server__init_A { A_arbace_core_server__init_A_Init(); t := &A_arbace_core_server__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server__init_A) Ctor() {}

func (t *A_arbace_core_server__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_server__init_A_class }

func (t *A_arbace_core_server__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server__init_A); return ok }

func A_arbace_core_server__init_A_Cast(x any) *A_arbace_core_server__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server__init_A_class)) }; return v }
