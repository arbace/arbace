//line a2g_classes.ae:1
package aot_arbace_core_server

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_core_server_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_A_New()}; return nil }

var A_arbace_core_server_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_server_A_new}

var A_arbace_core_server_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_server.A_arbace_core_server_A"})

func init() { i := A_arbace_core_server_A_class.Info(); i.IsInstance = A_arbace_core_server_A_InstanceOf; i.Init = A_arbace_core_server_A_Init; i.Table = A_arbace_core_server_A_members; jrt.RegisterGoType(A_arbace_core_server_A_class, reflect.TypeFor[A_arbace_core_server_A]()) }

func A_arbace_core_server_accept_connection_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_accept_connection_A).Invoke_O_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8])}; return nil }

func A_arbace_core_server_accept_connection_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_accept_connection_A_New()}; return nil }

func A_arbace_core_server_accept_connection_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_accept_connection_A_fn_class)}; return nil }

var A_arbace_core_server_accept_connection_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_accept_connection_A_invoke, New: A_arbace_core_server_accept_connection_A_new, Get: A_arbace_core_server_accept_connection_A_get}

var A_arbace_core_server_accept_connection_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$accept_connection", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF8_class}, Declaring: A_arbace_core_server_A_class, Simple: "accept_connection", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_accept_connection_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_accept_connection_A_class.Info(); i.IsInstance = A_arbace_core_server_accept_connection_A_InstanceOf; i.Init = A_arbace_core_server_accept_connection_A_Init; i.Table = A_arbace_core_server_accept_connection_A_members; jrt.RegisterGoType(A_arbace_core_server_accept_connection_A_class, reflect.TypeFor[A_arbace_core_server_accept_connection_A]()) }

func A_arbace_core_server_accept_connection_fn__1213000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_accept_connection_fn__1213000038_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_accept_connection_fn__1213000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_accept_connection_fn__1213000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class)}; return nil }

var A_arbace_core_server_accept_connection_fn__1213000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_accept_connection_fn__1213000038_A_invoke, New: A_arbace_core_server_accept_connection_fn__1213000038_A_new, Get: A_arbace_core_server_accept_connection_fn__1213000038_A_get}

var A_arbace_core_server_accept_connection_fn__1213000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$accept_connection$fn__1213000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_accept_connection_A_class, Simple: "fn__1213000038", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_accept_connection_fn__1213000038_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_accept_connection_fn__1213000038_A_class.Info(); i.IsInstance = A_arbace_core_server_accept_connection_fn__1213000038_A_InstanceOf; i.Init = A_arbace_core_server_accept_connection_fn__1213000038_A_Init; i.Table = A_arbace_core_server_accept_connection_fn__1213000038_A_members; jrt.RegisterGoType(A_arbace_core_server_accept_connection_fn__1213000038_A_class, reflect.TypeFor[A_arbace_core_server_accept_connection_fn__1213000038_A]()) }

func A_arbace_core_server_accept_connection_fn__1213000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_accept_connection_fn__1213000040_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_accept_connection_fn__1213000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_accept_connection_fn__1213000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class)}; return nil }

var A_arbace_core_server_accept_connection_fn__1213000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_accept_connection_fn__1213000040_A_invoke, New: A_arbace_core_server_accept_connection_fn__1213000040_A_new, Get: A_arbace_core_server_accept_connection_fn__1213000040_A_get}

var A_arbace_core_server_accept_connection_fn__1213000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$accept_connection$fn__1213000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_accept_connection_A_class, Simple: "fn__1213000040", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_accept_connection_fn__1213000040_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_accept_connection_fn__1213000040_A_class.Info(); i.IsInstance = A_arbace_core_server_accept_connection_fn__1213000040_A_InstanceOf; i.Init = A_arbace_core_server_accept_connection_fn__1213000040_A_Init; i.Table = A_arbace_core_server_accept_connection_fn__1213000040_A_members; jrt.RegisterGoType(A_arbace_core_server_accept_connection_fn__1213000040_A_class, reflect.TypeFor[A_arbace_core_server_accept_connection_fn__1213000040_A]()) }

func A_arbace_core_server_eval1213000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_eval1213000004_A_New()}; return nil }

var A_arbace_core_server_eval1213000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_server_eval1213000004_A_new}

var A_arbace_core_server_eval1213000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$eval1213000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_server_A_class, Simple: "eval1213000004", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000004_A"})

func init() { i := A_arbace_core_server_eval1213000004_A_class.Info(); i.IsInstance = A_arbace_core_server_eval1213000004_A_InstanceOf; i.Table = A_arbace_core_server_eval1213000004_A_members; jrt.RegisterGoType(A_arbace_core_server_eval1213000004_A_class, reflect.TypeFor[A_arbace_core_server_eval1213000004_A]()) }

func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_New()}; return nil }

func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class)}; return nil }

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_invoke, New: A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_new, Get: A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_get}

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$eval1213000004$loading__1927001464__auto____1213000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_eval1213000004_A_class, Simple: "loading__1927001464__auto____1213000005", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_class.Info(); i.IsInstance = A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_InstanceOf; i.Init = A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_Init; i.Table = A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_members; jrt.RegisterGoType(A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_class, reflect.TypeFor[A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A]()) }

func A_arbace_core_server_eval1213000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_eval1213000008_A_New()}; return nil }

var A_arbace_core_server_eval1213000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_server_eval1213000008_A_new}

var A_arbace_core_server_eval1213000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$eval1213000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_server_A_class, Simple: "eval1213000008", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000008_A"})

func init() { i := A_arbace_core_server_eval1213000008_A_class.Info(); i.IsInstance = A_arbace_core_server_eval1213000008_A_InstanceOf; i.Table = A_arbace_core_server_eval1213000008_A_members; jrt.RegisterGoType(A_arbace_core_server_eval1213000008_A_class, reflect.TypeFor[A_arbace_core_server_eval1213000008_A]()) }

func A_arbace_core_server_eval1213000008_fn__1213000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_eval1213000008_fn__1213000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_eval1213000008_fn__1213000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_eval1213000008_fn__1213000009_A_New()}; return nil }

func A_arbace_core_server_eval1213000008_fn__1213000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class)}; return nil }

var A_arbace_core_server_eval1213000008_fn__1213000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_eval1213000008_fn__1213000009_A_invoke, New: A_arbace_core_server_eval1213000008_fn__1213000009_A_new, Get: A_arbace_core_server_eval1213000008_fn__1213000009_A_get}

var A_arbace_core_server_eval1213000008_fn__1213000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$eval1213000008$fn__1213000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_eval1213000008_A_class, Simple: "fn__1213000009", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000008_fn__1213000009_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_eval1213000008_fn__1213000009_A_class.Info(); i.IsInstance = A_arbace_core_server_eval1213000008_fn__1213000009_A_InstanceOf; i.Init = A_arbace_core_server_eval1213000008_fn__1213000009_A_Init; i.Table = A_arbace_core_server_eval1213000008_fn__1213000009_A_members; jrt.RegisterGoType(A_arbace_core_server_eval1213000008_fn__1213000009_A_class, reflect.TypeFor[A_arbace_core_server_eval1213000008_fn__1213000009_A]()) }

func A_arbace_core_server_ex__GT_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_ex__GT_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_ex__GT_data_A_New()}; return nil }

func A_arbace_core_server_ex__GT_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_ex__GT_data_A_fn_class)}; return nil }

var A_arbace_core_server_ex__GT_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_ex__GT_data_A_invoke, New: A_arbace_core_server_ex__GT_data_A_new, Get: A_arbace_core_server_ex__GT_data_A_get}

var A_arbace_core_server_ex__GT_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$ex__GT_data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_server_A_class, Simple: "ex__GT_data", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_ex__GT_data_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_ex__GT_data_A_class.Info(); i.IsInstance = A_arbace_core_server_ex__GT_data_A_InstanceOf; i.Init = A_arbace_core_server_ex__GT_data_A_Init; i.Table = A_arbace_core_server_ex__GT_data_A_members; jrt.RegisterGoType(A_arbace_core_server_ex__GT_data_A_class, reflect.TypeFor[A_arbace_core_server_ex__GT_data_A]()) }

func A_arbace_core_server_io_prepl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_io_prepl_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_io_prepl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_io_prepl_A_New()}; return nil }

func A_arbace_core_server_io_prepl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_io_prepl_A_fn_class)}; return nil }

var A_arbace_core_server_io_prepl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_io_prepl_A_invoke, New: A_arbace_core_server_io_prepl_A_new, Get: A_arbace_core_server_io_prepl_A_get}

var A_arbace_core_server_io_prepl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$io_prepl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_core_server_A_class, Simple: "io_prepl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_io_prepl_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_io_prepl_A_class.Info(); i.IsInstance = A_arbace_core_server_io_prepl_A_InstanceOf; i.Init = A_arbace_core_server_io_prepl_A_Init; i.Table = A_arbace_core_server_io_prepl_A_members; jrt.RegisterGoType(A_arbace_core_server_io_prepl_A_class, reflect.TypeFor[A_arbace_core_server_io_prepl_A]()) }

func A_arbace_core_server_io_prepl_fn__1213000112_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_io_prepl_fn__1213000112_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_io_prepl_fn__1213000112_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_io_prepl_fn__1213000112_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class)}; return nil }

var A_arbace_core_server_io_prepl_fn__1213000112_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_io_prepl_fn__1213000112_A_invoke, New: A_arbace_core_server_io_prepl_fn__1213000112_A_new, Get: A_arbace_core_server_io_prepl_fn__1213000112_A_get}

var A_arbace_core_server_io_prepl_fn__1213000112_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$io_prepl$fn__1213000112", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_io_prepl_A_class, Simple: "fn__1213000112", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_io_prepl_fn__1213000112_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_io_prepl_fn__1213000112_A_class.Info(); i.IsInstance = A_arbace_core_server_io_prepl_fn__1213000112_A_InstanceOf; i.Init = A_arbace_core_server_io_prepl_fn__1213000112_A_Init; i.Table = A_arbace_core_server_io_prepl_fn__1213000112_A_members; jrt.RegisterGoType(A_arbace_core_server_io_prepl_fn__1213000112_A_class, reflect.TypeFor[A_arbace_core_server_io_prepl_fn__1213000112_A]()) }

func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class)}; return nil }

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_invoke, New: A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_new, Get: A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_get}

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$io_prepl$fn__1213000112$fn__1213000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_io_prepl_fn__1213000112_A_class, Simple: "fn__1213000113", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_class.Info(); i.IsInstance = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_InstanceOf; i.Init = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_Init; i.Table = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_members; jrt.RegisterGoType(A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_class, reflect.TypeFor[A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A]()) }

func A_arbace_core_server_parse_props_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_parse_props_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_parse_props_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_parse_props_A_New()}; return nil }

func A_arbace_core_server_parse_props_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_parse_props_A_fn_class)}; return nil }

var A_arbace_core_server_parse_props_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_parse_props_A_invoke, New: A_arbace_core_server_parse_props_A_new, Get: A_arbace_core_server_parse_props_A_get}

var A_arbace_core_server_parse_props_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$parse_props", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_A_class, Simple: "parse_props", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_parse_props_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_parse_props_A_class.Info(); i.IsInstance = A_arbace_core_server_parse_props_A_InstanceOf; i.Init = A_arbace_core_server_parse_props_A_Init; i.Table = A_arbace_core_server_parse_props_A_members; jrt.RegisterGoType(A_arbace_core_server_parse_props_A_class, reflect.TypeFor[A_arbace_core_server_parse_props_A]()) }

func A_arbace_core_server_parse_props_fn__1213000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_parse_props_fn__1213000072_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_parse_props_fn__1213000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_parse_props_fn__1213000072_A_New_O(args[0])}; return nil }

func A_arbace_core_server_parse_props_fn__1213000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_parse_props_fn__1213000072_A_fn_class)}; return nil }

var A_arbace_core_server_parse_props_fn__1213000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_parse_props_fn__1213000072_A_invoke, New: A_arbace_core_server_parse_props_fn__1213000072_A_new, Get: A_arbace_core_server_parse_props_fn__1213000072_A_get}

var A_arbace_core_server_parse_props_fn__1213000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$parse_props$fn__1213000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_server_parse_props_A_class, Simple: "fn__1213000072", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_parse_props_fn__1213000072_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_parse_props_fn__1213000072_A_class.Info(); i.IsInstance = A_arbace_core_server_parse_props_fn__1213000072_A_InstanceOf; i.Init = A_arbace_core_server_parse_props_fn__1213000072_A_Init; i.Table = A_arbace_core_server_parse_props_fn__1213000072_A_members; jrt.RegisterGoType(A_arbace_core_server_parse_props_fn__1213000072_A_class, reflect.TypeFor[A_arbace_core_server_parse_props_fn__1213000072_A]()) }

func A_arbace_core_server_prepl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_prepl_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_server_prepl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_prepl_A_New()}; return nil }

func A_arbace_core_server_prepl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_prepl_A_fn_class)}; return nil }

var A_arbace_core_server_prepl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_prepl_A_invoke, New: A_arbace_core_server_prepl_A_new, Get: A_arbace_core_server_prepl_A_get}

var A_arbace_core_server_prepl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$prepl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_core_server_A_class, Simple: "prepl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_prepl_A_class.Info(); i.IsInstance = A_arbace_core_server_prepl_A_InstanceOf; i.Init = A_arbace_core_server_prepl_A_Init; i.Table = A_arbace_core_server_prepl_A_members; jrt.RegisterGoType(A_arbace_core_server_prepl_A_class, reflect.TypeFor[A_arbace_core_server_prepl_A]()) }

func A_arbace_core_server_prepl_fn__1213000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_prepl_fn__1213000096_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_prepl_fn__1213000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_prepl_fn__1213000096_A_New_O(args[0])}; return nil }

func A_arbace_core_server_prepl_fn__1213000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_prepl_fn__1213000096_A_fn_class)}; return nil }

var A_arbace_core_server_prepl_fn__1213000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_prepl_fn__1213000096_A_invoke, New: A_arbace_core_server_prepl_fn__1213000096_A_new, Get: A_arbace_core_server_prepl_fn__1213000096_A_get}

var A_arbace_core_server_prepl_fn__1213000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$prepl$fn__1213000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_prepl_A_class, Simple: "fn__1213000096", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_fn__1213000096_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_prepl_fn__1213000096_A_class.Info(); i.IsInstance = A_arbace_core_server_prepl_fn__1213000096_A_InstanceOf; i.Init = A_arbace_core_server_prepl_fn__1213000096_A_Init; i.Table = A_arbace_core_server_prepl_fn__1213000096_A_members; jrt.RegisterGoType(A_arbace_core_server_prepl_fn__1213000096_A_class, reflect.TypeFor[A_arbace_core_server_prepl_fn__1213000096_A]()) }

func A_arbace_core_server_prepl_fn__1213000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_prepl_fn__1213000098_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_prepl_fn__1213000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_prepl_fn__1213000098_A_New_O(args[0])}; return nil }

func A_arbace_core_server_prepl_fn__1213000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_prepl_fn__1213000098_A_fn_class)}; return nil }

var A_arbace_core_server_prepl_fn__1213000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_prepl_fn__1213000098_A_invoke, New: A_arbace_core_server_prepl_fn__1213000098_A_new, Get: A_arbace_core_server_prepl_fn__1213000098_A_get}

var A_arbace_core_server_prepl_fn__1213000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$prepl$fn__1213000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_prepl_A_class, Simple: "fn__1213000098", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_fn__1213000098_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_prepl_fn__1213000098_A_class.Info(); i.IsInstance = A_arbace_core_server_prepl_fn__1213000098_A_InstanceOf; i.Init = A_arbace_core_server_prepl_fn__1213000098_A_Init; i.Table = A_arbace_core_server_prepl_fn__1213000098_A_members; jrt.RegisterGoType(A_arbace_core_server_prepl_fn__1213000098_A_class, reflect.TypeFor[A_arbace_core_server_prepl_fn__1213000098_A]()) }

func A_arbace_core_server_prepl_fn__1213000100_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_prepl_fn__1213000100_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_prepl_fn__1213000100_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_prepl_fn__1213000100_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_prepl_fn__1213000100_A_fn_class)}; return nil }

var A_arbace_core_server_prepl_fn__1213000100_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_prepl_fn__1213000100_A_invoke, New: A_arbace_core_server_prepl_fn__1213000100_A_new, Get: A_arbace_core_server_prepl_fn__1213000100_A_get}

var A_arbace_core_server_prepl_fn__1213000100_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$prepl$fn__1213000100", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_prepl_A_class, Simple: "fn__1213000100", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_fn__1213000100_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_prepl_fn__1213000100_A_class.Info(); i.IsInstance = A_arbace_core_server_prepl_fn__1213000100_A_InstanceOf; i.Init = A_arbace_core_server_prepl_fn__1213000100_A_Init; i.Table = A_arbace_core_server_prepl_fn__1213000100_A_members; jrt.RegisterGoType(A_arbace_core_server_prepl_fn__1213000100_A_class, reflect.TypeFor[A_arbace_core_server_prepl_fn__1213000100_A]()) }

func A_arbace_core_server_prepl_tapfn__1213000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_prepl_tapfn__1213000094_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_prepl_tapfn__1213000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(args[0])}; return nil }

func A_arbace_core_server_prepl_tapfn__1213000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class)}; return nil }

var A_arbace_core_server_prepl_tapfn__1213000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_prepl_tapfn__1213000094_A_invoke, New: A_arbace_core_server_prepl_tapfn__1213000094_A_new, Get: A_arbace_core_server_prepl_tapfn__1213000094_A_get}

var A_arbace_core_server_prepl_tapfn__1213000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$prepl$tapfn__1213000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_prepl_A_class, Simple: "tapfn__1213000094", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_tapfn__1213000094_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_prepl_tapfn__1213000094_A_class.Info(); i.IsInstance = A_arbace_core_server_prepl_tapfn__1213000094_A_InstanceOf; i.Init = A_arbace_core_server_prepl_tapfn__1213000094_A_Init; i.Table = A_arbace_core_server_prepl_tapfn__1213000094_A_members; jrt.RegisterGoType(A_arbace_core_server_prepl_tapfn__1213000094_A_class, reflect.TypeFor[A_arbace_core_server_prepl_tapfn__1213000094_A]()) }

func A_arbace_core_server_remote_prepl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_remote_prepl_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_core_server_remote_prepl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_remote_prepl_A_New()}; return nil }

func A_arbace_core_server_remote_prepl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_remote_prepl_A_fn_class)}; return nil }

var A_arbace_core_server_remote_prepl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_remote_prepl_A_invoke, New: A_arbace_core_server_remote_prepl_A_new, Get: A_arbace_core_server_remote_prepl_A_get}

var A_arbace_core_server_remote_prepl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$remote_prepl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_core_server_A_class, Simple: "remote_prepl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_remote_prepl_A_class.Info(); i.IsInstance = A_arbace_core_server_remote_prepl_A_InstanceOf; i.Init = A_arbace_core_server_remote_prepl_A_Init; i.Table = A_arbace_core_server_remote_prepl_A_members; jrt.RegisterGoType(A_arbace_core_server_remote_prepl_A_class, reflect.TypeFor[A_arbace_core_server_remote_prepl_A]()) }

func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New()}; return nil }

func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class)}; return nil }

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_invoke, New: A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_new, Get: A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_get}

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$remote_prepl$default__1213000123__1213000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_server_remote_prepl_A_class, Simple: "default__1213000123__1213000125", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_class.Info(); i.IsInstance = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_InstanceOf; i.Init = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_Init; i.Table = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_members; jrt.RegisterGoType(A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_class, reflect.TypeFor[A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A]()) }

func A_arbace_core_server_remote_prepl_fn__1213000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_remote_prepl_fn__1213000128_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_remote_prepl_fn__1213000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_core_server_remote_prepl_fn__1213000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class)}; return nil }

var A_arbace_core_server_remote_prepl_fn__1213000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_remote_prepl_fn__1213000128_A_invoke, New: A_arbace_core_server_remote_prepl_fn__1213000128_A_new, Get: A_arbace_core_server_remote_prepl_fn__1213000128_A_get}

var A_arbace_core_server_remote_prepl_fn__1213000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$remote_prepl$fn__1213000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_remote_prepl_A_class, Simple: "fn__1213000128", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_fn__1213000128_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_remote_prepl_fn__1213000128_A_class.Info(); i.IsInstance = A_arbace_core_server_remote_prepl_fn__1213000128_A_InstanceOf; i.Init = A_arbace_core_server_remote_prepl_fn__1213000128_A_Init; i.Table = A_arbace_core_server_remote_prepl_fn__1213000128_A_members; jrt.RegisterGoType(A_arbace_core_server_remote_prepl_fn__1213000128_A_class, reflect.TypeFor[A_arbace_core_server_remote_prepl_fn__1213000128_A]()) }

func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class)}; return nil }

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_invoke, New: A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_new, Get: A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_get}

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$remote_prepl$fn__1213000128$fn__1213000131", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_remote_prepl_fn__1213000128_A_class, Simple: "fn__1213000131", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_class.Info(); i.IsInstance = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_InstanceOf; i.Init = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_Init; i.Table = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_members; jrt.RegisterGoType(A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_class, reflect.TypeFor[A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A]()) }

func A_arbace_core_server_repl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_repl_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_repl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_repl_A_New()}; return nil }

func A_arbace_core_server_repl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_repl_A_fn_class)}; return nil }

var A_arbace_core_server_repl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_repl_A_invoke, New: A_arbace_core_server_repl_A_new, Get: A_arbace_core_server_repl_A_get}

var A_arbace_core_server_repl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$repl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_A_class, Simple: "repl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_repl_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_repl_A_class.Info(); i.IsInstance = A_arbace_core_server_repl_A_InstanceOf; i.Init = A_arbace_core_server_repl_A_Init; i.Table = A_arbace_core_server_repl_A_members; jrt.RegisterGoType(A_arbace_core_server_repl_A_class, reflect.TypeFor[A_arbace_core_server_repl_A]()) }

func A_arbace_core_server_repl_init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_repl_init_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_repl_init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_repl_init_A_New()}; return nil }

func A_arbace_core_server_repl_init_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_repl_init_A_fn_class)}; return nil }

var A_arbace_core_server_repl_init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_repl_init_A_invoke, New: A_arbace_core_server_repl_init_A_new, Get: A_arbace_core_server_repl_init_A_get}

var A_arbace_core_server_repl_init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$repl_init", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_A_class, Simple: "repl_init", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_repl_init_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_repl_init_A_class.Info(); i.IsInstance = A_arbace_core_server_repl_init_A_InstanceOf; i.Init = A_arbace_core_server_repl_init_A_Init; i.Table = A_arbace_core_server_repl_init_A_members; jrt.RegisterGoType(A_arbace_core_server_repl_init_A_class, reflect.TypeFor[A_arbace_core_server_repl_init_A]()) }

func A_arbace_core_server_repl_read_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_repl_read_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_repl_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_repl_read_A_New()}; return nil }

func A_arbace_core_server_repl_read_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_repl_read_A_fn_class)}; return nil }

var A_arbace_core_server_repl_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_repl_read_A_invoke, New: A_arbace_core_server_repl_read_A_new, Get: A_arbace_core_server_repl_read_A_get}

var A_arbace_core_server_repl_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$repl_read", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_server_A_class, Simple: "repl_read", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_repl_read_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_repl_read_A_class.Info(); i.IsInstance = A_arbace_core_server_repl_read_A_InstanceOf; i.Init = A_arbace_core_server_repl_read_A_Init; i.Table = A_arbace_core_server_repl_read_A_members; jrt.RegisterGoType(A_arbace_core_server_repl_read_A_class, reflect.TypeFor[A_arbace_core_server_repl_read_A]()) }

func A_arbace_core_server_required_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_required_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_required_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_required_A_New()}; return nil }

func A_arbace_core_server_required_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_required_A_fn_class)}; return nil }

var A_arbace_core_server_required_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_required_A_invoke, New: A_arbace_core_server_required_A_new, Get: A_arbace_core_server_required_A_get}

var A_arbace_core_server_required_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$required", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_server_A_class, Simple: "required", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_required_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_required_A_class.Info(); i.IsInstance = A_arbace_core_server_required_A_InstanceOf; i.Init = A_arbace_core_server_required_A_Init; i.Table = A_arbace_core_server_required_A_members; jrt.RegisterGoType(A_arbace_core_server_required_A_class, reflect.TypeFor[A_arbace_core_server_required_A]()) }

func A_arbace_core_server_resolve_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_resolve_fn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_resolve_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_resolve_fn_A_New()}; return nil }

func A_arbace_core_server_resolve_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_resolve_fn_A_fn_class)}; return nil }

var A_arbace_core_server_resolve_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_resolve_fn_A_invoke, New: A_arbace_core_server_resolve_fn_A_new, Get: A_arbace_core_server_resolve_fn_A_get}

var A_arbace_core_server_resolve_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$resolve_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_A_class, Simple: "resolve_fn", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_resolve_fn_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_resolve_fn_A_class.Info(); i.IsInstance = A_arbace_core_server_resolve_fn_A_InstanceOf; i.Init = A_arbace_core_server_resolve_fn_A_Init; i.Table = A_arbace_core_server_resolve_fn_A_members; jrt.RegisterGoType(A_arbace_core_server_resolve_fn_A_class, reflect.TypeFor[A_arbace_core_server_resolve_fn_A]()) }

func A_arbace_core_server_start_server_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_start_server_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_start_server_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_start_server_A_New()}; return nil }

func A_arbace_core_server_start_server_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_start_server_A_fn_class)}; return nil }

var A_arbace_core_server_start_server_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_start_server_A_invoke, New: A_arbace_core_server_start_server_A_new, Get: A_arbace_core_server_start_server_A_get}

var A_arbace_core_server_start_server_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$start_server", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_A_class, Simple: "start_server", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_start_server_A_class.Info(); i.IsInstance = A_arbace_core_server_start_server_A_InstanceOf; i.Init = A_arbace_core_server_start_server_A_Init; i.Table = A_arbace_core_server_start_server_A_members; jrt.RegisterGoType(A_arbace_core_server_start_server_A_class, reflect.TypeFor[A_arbace_core_server_start_server_A]()) }

func A_arbace_core_server_start_server_fn__1213000049_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_start_server_fn__1213000049_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_start_server_fn__1213000049_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_server_start_server_fn__1213000049_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_start_server_fn__1213000049_A_fn_class)}; return nil }

var A_arbace_core_server_start_server_fn__1213000049_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_start_server_fn__1213000049_A_invoke, New: A_arbace_core_server_start_server_fn__1213000049_A_new, Get: A_arbace_core_server_start_server_fn__1213000049_A_get}

var A_arbace_core_server_start_server_fn__1213000049_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$start_server$fn__1213000049", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_start_server_A_class, Simple: "fn__1213000049", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000049_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_start_server_fn__1213000049_A_class.Info(); i.IsInstance = A_arbace_core_server_start_server_fn__1213000049_A_InstanceOf; i.Init = A_arbace_core_server_start_server_fn__1213000049_A_Init; i.Table = A_arbace_core_server_start_server_fn__1213000049_A_members; jrt.RegisterGoType(A_arbace_core_server_start_server_fn__1213000049_A_class, reflect.TypeFor[A_arbace_core_server_start_server_fn__1213000049_A]()) }

func A_arbace_core_server_start_server_fn__1213000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_start_server_fn__1213000052_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_start_server_fn__1213000052_A_fn_class)}; return nil }

var A_arbace_core_server_start_server_fn__1213000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_start_server_fn__1213000052_A_invoke, New: A_arbace_core_server_start_server_fn__1213000052_A_new, Get: A_arbace_core_server_start_server_fn__1213000052_A_get}

var A_arbace_core_server_start_server_fn__1213000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$start_server$fn__1213000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_start_server_A_class, Simple: "fn__1213000052", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_start_server_fn__1213000052_A_class.Info(); i.IsInstance = A_arbace_core_server_start_server_fn__1213000052_A_InstanceOf; i.Init = A_arbace_core_server_start_server_fn__1213000052_A_Init; i.Table = A_arbace_core_server_start_server_fn__1213000052_A_members; jrt.RegisterGoType(A_arbace_core_server_start_server_fn__1213000052_A_class, reflect.TypeFor[A_arbace_core_server_start_server_fn__1213000052_A]()) }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(args[0], args[1], args[2].(int64), args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class)}; return nil }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;JLjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_invoke, New: A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_new, Get: A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_get}

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$start_server$fn__1213000052$fn__1213000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_start_server_fn__1213000052_A_class, Simple: "fn__1213000053", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class.Info(); i.IsInstance = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_InstanceOf; i.Init = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_Init; i.Table = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_members; jrt.RegisterGoType(A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class, reflect.TypeFor[A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A]()) }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class)}; return nil }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_invoke, New: A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_new, Get: A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_get}

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$start_server$fn__1213000052$fn__1213000053$fn__1213000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class, Simple: "fn__1213000055", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_class.Info(); i.IsInstance = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_InstanceOf; i.Init = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_Init; i.Table = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_members; jrt.RegisterGoType(A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_class, reflect.TypeFor[A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A]()) }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class)}; return nil }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_invoke, New: A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_new, Get: A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_get}

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$start_server$fn__1213000052$fn__1213000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_start_server_fn__1213000052_A_class, Simple: "fn__1213000058", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_class.Info(); i.IsInstance = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_InstanceOf; i.Init = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_Init; i.Table = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_members; jrt.RegisterGoType(A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_class, reflect.TypeFor[A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A]()) }

func A_arbace_core_server_start_servers_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_start_servers_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_start_servers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_start_servers_A_New()}; return nil }

func A_arbace_core_server_start_servers_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_start_servers_A_fn_class)}; return nil }

var A_arbace_core_server_start_servers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_start_servers_A_invoke, New: A_arbace_core_server_start_servers_A_new, Get: A_arbace_core_server_start_servers_A_get}

var A_arbace_core_server_start_servers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$start_servers", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_A_class, Simple: "start_servers", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_servers_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_start_servers_A_class.Info(); i.IsInstance = A_arbace_core_server_start_servers_A_InstanceOf; i.Init = A_arbace_core_server_start_servers_A_Init; i.Table = A_arbace_core_server_start_servers_A_members; jrt.RegisterGoType(A_arbace_core_server_start_servers_A_class, reflect.TypeFor[A_arbace_core_server_start_servers_A]()) }

func A_arbace_core_server_stop_server_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_stop_server_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_core_server_stop_server_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_stop_server_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_stop_server_A_New()}; return nil }

func A_arbace_core_server_stop_server_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_stop_server_A_fn_class)}; return nil }

var A_arbace_core_server_stop_server_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_stop_server_A_invoke, New: A_arbace_core_server_stop_server_A_new, Get: A_arbace_core_server_stop_server_A_get}

var A_arbace_core_server_stop_server_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$stop_server", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_A_class, Simple: "stop_server", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_server_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_stop_server_A_class.Info(); i.IsInstance = A_arbace_core_server_stop_server_A_InstanceOf; i.Init = A_arbace_core_server_stop_server_A_Init; i.Table = A_arbace_core_server_stop_server_A_members; jrt.RegisterGoType(A_arbace_core_server_stop_server_A_class, reflect.TypeFor[A_arbace_core_server_stop_server_A]()) }

func A_arbace_core_server_stop_servers_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_stop_servers_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_stop_servers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_stop_servers_A_New()}; return nil }

func A_arbace_core_server_stop_servers_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_stop_servers_A_fn_class)}; return nil }

var A_arbace_core_server_stop_servers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_stop_servers_A_invoke, New: A_arbace_core_server_stop_servers_A_new, Get: A_arbace_core_server_stop_servers_A_get}

var A_arbace_core_server_stop_servers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$stop_servers", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_A_class, Simple: "stop_servers", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_servers_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_stop_servers_A_class.Info(); i.IsInstance = A_arbace_core_server_stop_servers_A_InstanceOf; i.Init = A_arbace_core_server_stop_servers_A_Init; i.Table = A_arbace_core_server_stop_servers_A_members; jrt.RegisterGoType(A_arbace_core_server_stop_servers_A_class, reflect.TypeFor[A_arbace_core_server_stop_servers_A]()) }

func A_arbace_core_server_stop_servers_fn__1213000067_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_stop_servers_fn__1213000067_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_stop_servers_fn__1213000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(args[0])}; return nil }

func A_arbace_core_server_stop_servers_fn__1213000067_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class)}; return nil }

var A_arbace_core_server_stop_servers_fn__1213000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_stop_servers_fn__1213000067_A_invoke, New: A_arbace_core_server_stop_servers_fn__1213000067_A_new, Get: A_arbace_core_server_stop_servers_fn__1213000067_A_get}

var A_arbace_core_server_stop_servers_fn__1213000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$stop_servers$fn__1213000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_stop_servers_A_class, Simple: "fn__1213000067", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_servers_fn__1213000067_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_stop_servers_fn__1213000067_A_class.Info(); i.IsInstance = A_arbace_core_server_stop_servers_fn__1213000067_A_InstanceOf; i.Init = A_arbace_core_server_stop_servers_fn__1213000067_A_Init; i.Table = A_arbace_core_server_stop_servers_fn__1213000067_A_members; jrt.RegisterGoType(A_arbace_core_server_stop_servers_fn__1213000067_A_class, reflect.TypeFor[A_arbace_core_server_stop_servers_fn__1213000067_A]()) }

func A_arbace_core_server_stop_servers_fn__1213000069_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_stop_servers_fn__1213000069_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_server_stop_servers_fn__1213000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(args[0])}; return nil }

func A_arbace_core_server_stop_servers_fn__1213000069_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class)}; return nil }

var A_arbace_core_server_stop_servers_fn__1213000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_stop_servers_fn__1213000069_A_invoke, New: A_arbace_core_server_stop_servers_fn__1213000069_A_new, Get: A_arbace_core_server_stop_servers_fn__1213000069_A_get}

var A_arbace_core_server_stop_servers_fn__1213000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$stop_servers$fn__1213000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_server_stop_servers_A_class, Simple: "fn__1213000069", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_servers_fn__1213000069_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_stop_servers_fn__1213000069_A_class.Info(); i.IsInstance = A_arbace_core_server_stop_servers_fn__1213000069_A_InstanceOf; i.Init = A_arbace_core_server_stop_servers_fn__1213000069_A_Init; i.Table = A_arbace_core_server_stop_servers_fn__1213000069_A_members; jrt.RegisterGoType(A_arbace_core_server_stop_servers_fn__1213000069_A_class, reflect.TypeFor[A_arbace_core_server_stop_servers_fn__1213000069_A]()) }

func A_arbace_core_server_thread_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_thread_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_core_server_thread_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_thread_A_New()}; return nil }

func A_arbace_core_server_thread_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_thread_A_fn_class)}; return nil }

var A_arbace_core_server_thread_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_thread_A_invoke, New: A_arbace_core_server_thread_A_new, Get: A_arbace_core_server_thread_A_get}

var A_arbace_core_server_thread_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$thread", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_core_server_A_class, Simple: "thread", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_thread_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_thread_A_class.Info(); i.IsInstance = A_arbace_core_server_thread_A_InstanceOf; i.Init = A_arbace_core_server_thread_A_Init; i.Table = A_arbace_core_server_thread_A_members; jrt.RegisterGoType(A_arbace_core_server_thread_A_class, reflect.TypeFor[A_arbace_core_server_thread_A]()) }

func A_arbace_core_server_validate_opts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_validate_opts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_server_validate_opts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_validate_opts_A_New()}; return nil }

func A_arbace_core_server_validate_opts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_validate_opts_A_fn_class)}; return nil }

var A_arbace_core_server_validate_opts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_validate_opts_A_invoke, New: A_arbace_core_server_validate_opts_A_new, Get: A_arbace_core_server_validate_opts_A_get}

var A_arbace_core_server_validate_opts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$validate_opts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_server_A_class, Simple: "validate_opts", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_validate_opts_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_validate_opts_A_class.Info(); i.IsInstance = A_arbace_core_server_validate_opts_A_InstanceOf; i.Init = A_arbace_core_server_validate_opts_A_Init; i.Table = A_arbace_core_server_validate_opts_A_members; jrt.RegisterGoType(A_arbace_core_server_validate_opts_A_class, reflect.TypeFor[A_arbace_core_server_validate_opts_A]()) }

func A_arbace_core_server_with_lock_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_server_with_lock_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_core_server_with_lock_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_with_lock_A_New()}; return nil }

func A_arbace_core_server_with_lock_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_server_with_lock_A_fn_class)}; return nil }

var A_arbace_core_server_with_lock_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_server_with_lock_A_invoke, New: A_arbace_core_server_with_lock_A_new, Get: A_arbace_core_server_with_lock_A_get}

var A_arbace_core_server_with_lock_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$with_lock", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_core_server_A_class, Simple: "with_lock", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_with_lock_A", Source: "server.ae"})

func init() { i := A_arbace_core_server_with_lock_A_class.Info(); i.IsInstance = A_arbace_core_server_with_lock_A_InstanceOf; i.Init = A_arbace_core_server_with_lock_A_Init; i.Table = A_arbace_core_server_with_lock_A_members; jrt.RegisterGoType(A_arbace_core_server_with_lock_A_class, reflect.TypeFor[A_arbace_core_server_with_lock_A]()) }

func A_arbace_core_server__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_server__init_A_Load__O(); case 1: return A_arbace_core_server__init_A_Unit0__O(); case 2: return A_arbace_core_server__init_A_Unit1__O(); case 3: return A_arbace_core_server__init_A_Unit10__O(); case 4: return A_arbace_core_server__init_A_Unit11__O(); case 5: return A_arbace_core_server__init_A_Unit12__O(); case 6: return A_arbace_core_server__init_A_Unit13__O(); case 7: return A_arbace_core_server__init_A_Unit14__O(); case 8: return A_arbace_core_server__init_A_Unit15__O(); case 9: return A_arbace_core_server__init_A_Unit16__O(); case 10: return A_arbace_core_server__init_A_Unit17__O(); case 11: return A_arbace_core_server__init_A_Unit18__O(); case 12: return A_arbace_core_server__init_A_Unit19__O(); case 13: return A_arbace_core_server__init_A_Unit2__O(); case 14: return A_arbace_core_server__init_A_Unit20__O(); case 15: return A_arbace_core_server__init_A_Unit21__O(); case 16: return A_arbace_core_server__init_A_Unit22__O(); case 17: return A_arbace_core_server__init_A_Unit23__O(); case 18: return A_arbace_core_server__init_A_Unit24__O(); case 19: return A_arbace_core_server__init_A_Unit25__O(); case 20: return A_arbace_core_server__init_A_Unit26__O(); case 21: return A_arbace_core_server__init_A_Unit27__O(); case 22: return A_arbace_core_server__init_A_Unit28__O(); case 23: return A_arbace_core_server__init_A_Unit29__O(); case 24: return A_arbace_core_server__init_A_Unit3__O(); case 25: return A_arbace_core_server__init_A_Unit4__O(); case 26: return A_arbace_core_server__init_A_Unit5__O(); case 27: return A_arbace_core_server__init_A_Unit6__O(); case 28: return A_arbace_core_server__init_A_Unit7__O(); case 29: return A_arbace_core_server__init_A_Unit8__O(); case 30: return A_arbace_core_server__init_A_Unit9__O()}; return nil }

func A_arbace_core_server__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server__init_A_New()}; return nil }

var A_arbace_core_server__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_server__init_A_invoke, New: A_arbace_core_server__init_A_new}

var A_arbace_core_server__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_server.A_arbace_core_server__init_A", Source: "server.ae"})

func init() { i := A_arbace_core_server__init_A_class.Info(); i.IsInstance = A_arbace_core_server__init_A_InstanceOf; i.Init = A_arbace_core_server__init_A_Init; i.Table = A_arbace_core_server__init_A_members; jrt.RegisterGoType(A_arbace_core_server__init_A_class, reflect.TypeFor[A_arbace_core_server__init_A]()) }
