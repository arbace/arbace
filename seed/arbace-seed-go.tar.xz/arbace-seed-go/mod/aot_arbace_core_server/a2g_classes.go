//line a2g_classes.ae:1
package aot_arbace_core_server

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_core_server_accept_connection_A_class, Name: "arbace.core.server$accept_connection", Modifiers: 25, Simple: "accept_connection", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_accept_connection_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF8_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_accept_connection_fn__1213000038_A_class, Name: "arbace.core.server$accept_connection$fn__1213000038", Modifiers: 25, Simple: "fn__1213000038", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_accept_connection_fn__1213000038_A", Source: "server.ae", Declaring: &A_arbace_core_server_accept_connection_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_accept_connection_fn__1213000040_A_class, Name: "arbace.core.server$accept_connection$fn__1213000040", Modifiers: 25, Simple: "fn__1213000040", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_accept_connection_fn__1213000040_A", Source: "server.ae", Declaring: &A_arbace_core_server_accept_connection_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_class, Name: "arbace.core.server$eval1213000004$loading__1927001464__auto____1213000005", Modifiers: 25, Simple: "loading__1927001464__auto____1213000005", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A", Source: "server.ae", Declaring: &A_arbace_core_server_eval1213000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_eval1213000008_fn__1213000009_A_class, Name: "arbace.core.server$eval1213000008$fn__1213000009", Modifiers: 25, Simple: "fn__1213000009", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000008_fn__1213000009_A", Source: "server.ae", Declaring: &A_arbace_core_server_eval1213000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_ex__GT_data_A_class, Name: "arbace.core.server$ex__GT_data", Modifiers: 25, Simple: "ex__GT_data", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_ex__GT_data_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_io_prepl_A_class, Name: "arbace.core.server$io_prepl", Modifiers: 25, Simple: "io_prepl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_io_prepl_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_io_prepl_fn__1213000112_A_class, Name: "arbace.core.server$io_prepl$fn__1213000112", Modifiers: 25, Simple: "fn__1213000112", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_io_prepl_fn__1213000112_A", Source: "server.ae", Declaring: &A_arbace_core_server_io_prepl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_class, Name: "arbace.core.server$io_prepl$fn__1213000112$fn__1213000113", Modifiers: 25, Simple: "fn__1213000113", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A", Source: "server.ae", Declaring: &A_arbace_core_server_io_prepl_fn__1213000112_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_parse_props_A_class, Name: "arbace.core.server$parse_props", Modifiers: 25, Simple: "parse_props", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_parse_props_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_parse_props_fn__1213000072_A_class, Name: "arbace.core.server$parse_props$fn__1213000072", Modifiers: 25, Simple: "fn__1213000072", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_parse_props_fn__1213000072_A", Source: "server.ae", Declaring: &A_arbace_core_server_parse_props_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_prepl_A_class, Name: "arbace.core.server$prepl", Modifiers: 25, Simple: "prepl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_prepl_fn__1213000096_A_class, Name: "arbace.core.server$prepl$fn__1213000096", Modifiers: 25, Simple: "fn__1213000096", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_fn__1213000096_A", Source: "server.ae", Declaring: &A_arbace_core_server_prepl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_prepl_fn__1213000098_A_class, Name: "arbace.core.server$prepl$fn__1213000098", Modifiers: 25, Simple: "fn__1213000098", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_fn__1213000098_A", Source: "server.ae", Declaring: &A_arbace_core_server_prepl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_prepl_fn__1213000100_A_class, Name: "arbace.core.server$prepl$fn__1213000100", Modifiers: 25, Simple: "fn__1213000100", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_fn__1213000100_A", Source: "server.ae", Declaring: &A_arbace_core_server_prepl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_prepl_tapfn__1213000094_A_class, Name: "arbace.core.server$prepl$tapfn__1213000094", Modifiers: 25, Simple: "tapfn__1213000094", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_prepl_tapfn__1213000094_A", Source: "server.ae", Declaring: &A_arbace_core_server_prepl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_remote_prepl_A_class, Name: "arbace.core.server$remote_prepl", Modifiers: 25, Simple: "remote_prepl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR4_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_class, Name: "arbace.core.server$remote_prepl$default__1213000123__1213000125", Modifiers: 25, Simple: "default__1213000123__1213000125", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A", Source: "server.ae", Declaring: &A_arbace_core_server_remote_prepl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_remote_prepl_fn__1213000128_A_class, Name: "arbace.core.server$remote_prepl$fn__1213000128", Modifiers: 25, Simple: "fn__1213000128", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_fn__1213000128_A", Source: "server.ae", Declaring: &A_arbace_core_server_remote_prepl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_class, Name: "arbace.core.server$remote_prepl$fn__1213000128$fn__1213000131", Modifiers: 25, Simple: "fn__1213000131", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A", Source: "server.ae", Declaring: &A_arbace_core_server_remote_prepl_fn__1213000128_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_repl_A_class, Name: "arbace.core.server$repl", Modifiers: 25, Simple: "repl", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_repl_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_repl_init_A_class, Name: "arbace.core.server$repl_init", Modifiers: 25, Simple: "repl_init", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_repl_init_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_repl_read_A_class, Name: "arbace.core.server$repl_read", Modifiers: 25, Simple: "repl_read", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_repl_read_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_required_A_class, Name: "arbace.core.server$required", Modifiers: 25, Simple: "required", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_required_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_resolve_fn_A_class, Name: "arbace.core.server$resolve_fn", Modifiers: 25, Simple: "resolve_fn", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_resolve_fn_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_start_server_A_class, Name: "arbace.core.server$start_server", Modifiers: 25, Simple: "start_server", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_start_server_fn__1213000049_A_class, Name: "arbace.core.server$start_server$fn__1213000049", Modifiers: 25, Simple: "fn__1213000049", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000049_A", Source: "server.ae", Declaring: &A_arbace_core_server_start_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_start_server_fn__1213000052_A_class, Name: "arbace.core.server$start_server$fn__1213000052", Modifiers: 25, Simple: "fn__1213000052", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_A", Source: "server.ae", Declaring: &A_arbace_core_server_start_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class, Name: "arbace.core.server$start_server$fn__1213000052$fn__1213000053", Modifiers: 25, Simple: "fn__1213000053", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A", Source: "server.ae", Declaring: &A_arbace_core_server_start_server_fn__1213000052_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_class, Name: "arbace.core.server$start_server$fn__1213000052$fn__1213000053$fn__1213000055", Modifiers: 25, Simple: "fn__1213000055", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A", Source: "server.ae", Declaring: &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_class, Name: "arbace.core.server$start_server$fn__1213000052$fn__1213000058", Modifiers: 25, Simple: "fn__1213000058", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A", Source: "server.ae", Declaring: &A_arbace_core_server_start_server_fn__1213000052_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_start_servers_A_class, Name: "arbace.core.server$start_servers", Modifiers: 25, Simple: "start_servers", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_start_servers_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_stop_server_A_class, Name: "arbace.core.server$stop_server", Modifiers: 25, Simple: "stop_server", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_server_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_stop_servers_A_class, Name: "arbace.core.server$stop_servers", Modifiers: 25, Simple: "stop_servers", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_servers_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_stop_servers_fn__1213000067_A_class, Name: "arbace.core.server$stop_servers$fn__1213000067", Modifiers: 25, Simple: "fn__1213000067", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_servers_fn__1213000067_A", Source: "server.ae", Declaring: &A_arbace_core_server_stop_servers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_stop_servers_fn__1213000069_A_class, Name: "arbace.core.server$stop_servers$fn__1213000069", Modifiers: 25, Simple: "fn__1213000069", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_stop_servers_fn__1213000069_A", Source: "server.ae", Declaring: &A_arbace_core_server_stop_servers_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_thread_A_class, Name: "arbace.core.server$thread", Modifiers: 25, Simple: "thread", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_thread_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR4_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_validate_opts_A_class, Name: "arbace.core.server$validate_opts", Modifiers: 25, Simple: "validate_opts", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_validate_opts_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_server_with_lock_A_class, Name: "arbace.core.server$with_lock", Modifiers: 25, Simple: "with_lock", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_with_lock_A", Source: "server.ae", Declaring: &A_arbace_core_server_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_core_server_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_A_New()}; return nil }

var A_arbace_core_server_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_server_A_new}

var A_arbace_core_server_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_server.A_arbace_core_server_A"})

func init() { i := A_arbace_core_server_A_class.Info(); i.IsInstance = A_arbace_core_server_A_InstanceOf; i.Init = A_arbace_core_server_A_Init; i.Table = A_arbace_core_server_A_members }

var A_arbace_core_server_accept_connection_A_class *jrt.Class

var A_arbace_core_server_accept_connection_fn__1213000038_A_class *jrt.Class

var A_arbace_core_server_accept_connection_fn__1213000040_A_class *jrt.Class

func A_arbace_core_server_eval1213000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_eval1213000004_A_New()}; return nil }

var A_arbace_core_server_eval1213000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_server_eval1213000004_A_new}

var A_arbace_core_server_eval1213000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$eval1213000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_server_A_class, Simple: "eval1213000004", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000004_A"})

func init() { i := A_arbace_core_server_eval1213000004_A_class.Info(); i.IsInstance = A_arbace_core_server_eval1213000004_A_InstanceOf; i.Table = A_arbace_core_server_eval1213000004_A_members }

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_class *jrt.Class

func A_arbace_core_server_eval1213000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server_eval1213000008_A_New()}; return nil }

var A_arbace_core_server_eval1213000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_server_eval1213000008_A_new}

var A_arbace_core_server_eval1213000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server$eval1213000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_server_A_class, Simple: "eval1213000008", Go: "arbace/aot_arbace_core_server.A_arbace_core_server_eval1213000008_A"})

func init() { i := A_arbace_core_server_eval1213000008_A_class.Info(); i.IsInstance = A_arbace_core_server_eval1213000008_A_InstanceOf; i.Table = A_arbace_core_server_eval1213000008_A_members }

var A_arbace_core_server_eval1213000008_fn__1213000009_A_class *jrt.Class

var A_arbace_core_server_ex__GT_data_A_class *jrt.Class

var A_arbace_core_server_io_prepl_A_class *jrt.Class

var A_arbace_core_server_io_prepl_fn__1213000112_A_class *jrt.Class

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_class *jrt.Class

var A_arbace_core_server_parse_props_A_class *jrt.Class

var A_arbace_core_server_parse_props_fn__1213000072_A_class *jrt.Class

var A_arbace_core_server_prepl_A_class *jrt.Class

var A_arbace_core_server_prepl_fn__1213000096_A_class *jrt.Class

var A_arbace_core_server_prepl_fn__1213000098_A_class *jrt.Class

var A_arbace_core_server_prepl_fn__1213000100_A_class *jrt.Class

var A_arbace_core_server_prepl_tapfn__1213000094_A_class *jrt.Class

var A_arbace_core_server_remote_prepl_A_class *jrt.Class

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_class *jrt.Class

var A_arbace_core_server_remote_prepl_fn__1213000128_A_class *jrt.Class

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_class *jrt.Class

var A_arbace_core_server_repl_A_class *jrt.Class

var A_arbace_core_server_repl_init_A_class *jrt.Class

var A_arbace_core_server_repl_read_A_class *jrt.Class

var A_arbace_core_server_required_A_class *jrt.Class

var A_arbace_core_server_resolve_fn_A_class *jrt.Class

var A_arbace_core_server_start_server_A_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000049_A_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_A_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_class *jrt.Class

var A_arbace_core_server_start_servers_A_class *jrt.Class

var A_arbace_core_server_stop_server_A_class *jrt.Class

var A_arbace_core_server_stop_servers_A_class *jrt.Class

var A_arbace_core_server_stop_servers_fn__1213000067_A_class *jrt.Class

var A_arbace_core_server_stop_servers_fn__1213000069_A_class *jrt.Class

var A_arbace_core_server_thread_A_class *jrt.Class

var A_arbace_core_server_validate_opts_A_class *jrt.Class

var A_arbace_core_server_with_lock_A_class *jrt.Class

func A_arbace_core_server__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_server__init_A_Load__O()}; return nil }

func A_arbace_core_server__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_server__init_A_New()}; return nil }

var A_arbace_core_server__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_server__init_A_invoke, New: A_arbace_core_server__init_A_new}

var A_arbace_core_server__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.server__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_server.A_arbace_core_server__init_A", Source: "server.ae"})

func init() { i := A_arbace_core_server__init_A_class.Info(); i.IsInstance = A_arbace_core_server__init_A_InstanceOf; i.Init = A_arbace_core_server__init_A_Init; i.Table = A_arbace_core_server__init_A_members }
