//line aot_arbace_core_server.ae:1
package aot_arbace_core_server

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_New() *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_core_server_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_2); lang.IFn_Cast(A_arbace_core_server_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_server_A_const_3, A_arbace_core_server_A_const_4, A_arbace_core_server_A_const_5); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_3)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_4)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_6)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_7)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_8)); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_9)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_10)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_11)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_12)); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_13)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_14)); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_15)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_16)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp18 != nil { panic(tmp18) }; return tmp3 }
//line :9:1
func A_arbace_core_server_eval1213000008_fn__1213000009_A_New() *A_arbace_core_server_eval1213000008_fn__1213000009_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_eval1213000008_fn__1213000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_core_server_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_10), A_arbace_core_server_A_const_8.GetRawRoot__O(), A_arbace_core_server_A_const_9) }




















func A_arbace_core_server_with_lock_A_New() *A_arbace_core_server_with_lock_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_with_lock_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_core_server_with_lock_A) Ctor() {}
//line :30:1
func (t *A_arbace_core_server_with_lock_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, lock_expr__2, body__3 any) any { return lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_14), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_server_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lock_expr__2, A_arbace_core_server_A_const_19)))))), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_20), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17)))), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_21), body__3, lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_22), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_23), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17)))))))))))) }








func A_arbace_core_server_thread_A_New() *A_arbace_core_server_thread_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_thread_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_core_server_thread_A) Ctor() {}
//line :39:1
func (t *A_arbace_core_server_thread_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, daemon__3, body__4 any) any { return lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_24), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_25), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_26), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_server_A_const_16.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke__O()))), body__4))), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2)))), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_27), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(daemon__3)))), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_28)))))) }





func A_arbace_core_server_required_A_New() *A_arbace_core_server_required_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_required_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_core_server_required_A) Ctor() {}
//line :45:1
func (t *A_arbace_core_server_required_A) Invoke_O_O_O__O(self, opts__0, prop__1 any) any {


	if lang.Util_Identical_O_O__Z(lang.RT_Get_O_O__O(opts__0, prop__1), nil) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_core_server_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, prop__1)).Ref(), opts__0)))) } else { return nil
	}
}
func A_arbace_core_server_validate_opts_A_New() *A_arbace_core_server_validate_opts_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_validate_opts_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Invoke_O_O__O(self, p__1213000030__0 any) any { var map__1213000031__2 any = p__1213000030__0; var map__1213000031__3 any; if lang.ISeq_InstanceOf(map__1213000031__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1213000031__2)) { map__1213000031__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_core_server_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1213000031__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1213000031__2)) { map__1213000031__3 = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1213000031__2) } else { lang.PersistentArrayMap_Init(); map__1213000031__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000031__3 = map__1213000031__2 }; var opts__4 any = map__1213000031__3; var name__5 any = lang.RT_Get_O_O__O(map__1213000031__3, A_arbace_core_server_A_const_33); var port__6 any = lang.RT_Get_O_O__O(map__1213000031__3, A_arbace_core_server_A_const_34); var accept__7 any = lang.RT_Get_O_O__O(map__1213000031__3, A_arbace_core_server_A_const_35); var seq_1213000033__8 any = lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_39); var chunk_1213000034__9 any; var count_1213000035__10 int64 = 0; var i_1213000036__11 int64 = 0; _ = name__5; _ = accept__7; L1: for {


	if lang.Numbers_Lt_J_J__Z(i_1213000036__11, count_1213000035__10) { var prop__12 any = lang.Indexed_Cast(chunk_1213000034__9).Nth_I__O(lang.RT_IntCast_J__I(i_1213000036__11)); lang.IFn_Cast(A_arbace_core_server_A_const_40.GetRawRoot__O()).Invoke_O_O__O(opts__4, prop__12); seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, lang.Numbers_Unchecked_inc_J__J(i_1213000036__11); continue L1 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1213000033__8); if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1213000033__13 any = temp__1927000414__auto____12; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1213000033__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_core_server_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1213000033__13); seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = lang.IFn_Cast(A_arbace_core_server_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1213000033__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var prop__14 any = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1213000033__13); lang.IFn_Cast(A_arbace_core_server_A_const_40.GetRawRoot__O()).Invoke_O_O__O(opts__4, prop__14); seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1213000033__13), nil, 0, 0; continue L1 } } }
//line :51:1
	break L1 }; var tmp1 any; var or__1927000174__auto____8 any =



	lang.IFn_Cast(A_arbace_core_server_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_42.GetRawRoot__O()).Invoke_O__O(port__6)); if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { tmp1 = lang.IFn_Cast(A_arbace_core_server_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_server_A_const_44, port__6, A_arbace_core_server_A_const_45)) }; if jrt.J2g_Truth(tmp1) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_core_server_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, port__6)).Ref(), opts__4)))) } else { return nil } }


func A_arbace_core_server_accept_connection_A_New() *A_arbace_core_server_accept_connection_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Ctor() {}
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Invoke_O_O_O_O_O_O_O_O_O__O(self, conn__0, name__1, client_id__2, in__3, out__4, err__5, accept__6, args__7 any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_50; var tmp4 any = A_arbace_core_server_A_const_51; var tmp5 any = A_arbace_core_server_A_const_52; var tmp6 any = A_arbace_core_server_A_const_53; lang.IFn_Cast(A_arbace_core_server_A_const_48.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O_O_O__O(tmp3, in__3, tmp4, out__4, tmp5, err__5, tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_54, name__1, A_arbace_core_server_A_const_55, client_id__2)))); tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :58:1
		{ var lockee__1213000018__auto____13 any = A_arbace_core_server_A_const_56.GetRawRoot__O()















			jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____13)).Lock__V(); var tmp7 any = A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____13); var tmp8 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class = fncls__1d; tmp8 = fncls__1d } else { tmp8 = fncls__1 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()

			lang.IFn_Cast(A_arbace_core_server_A_const_1.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_62.GetRawRoot__O()).Invoke_O__O(accept__6)))
//line :58:1
			var accept_fn__13 any = lang.IFn_Cast(A_arbace_core_server_A_const_46.GetRawRoot__O()).Invoke_O__O(accept__6)



















			tmp1 = lang.IFn_Cast(A_arbace_core_server_A_const_15.GetRawRoot__O()).Invoke_O_O__O(accept_fn__13, args__7) }
//line :70:1
		return nil }(); lang.IFn_Cast(A_arbace_core_server_A_const_47.GetRawRoot__O()).Invoke__O()
//line :58:1
		if tmp9 != nil { panic(tmp9) } }; return nil }(); if tmp10 != nil { if jrt.SocketException_InstanceOf(tmp10) { var _disconnect__11 jrt.SocketException_I = jrt.SocketException_Cast(tmp10); _ = _disconnect__11; tmp1 = nil } else { panic(tmp10) } } }; return nil }(); var lockee__1213000018__auto____11 any = A_arbace_core_server_A_const_56.GetRawRoot__O();






















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____11)).Lock__V(); var tmp12 any = A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____11); var tmp13 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class = fncls__2d; tmp13 = fncls__2d } else { tmp13 = fncls__2 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O();

	jrt.Socket_Cast(conn__0).Close__V(); if /*line :58:1*/ tmp11 != nil { panic(tmp11) }; return tmp1 }















func A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000038_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000038_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_59.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; var tmp6 any = tmp5; var tmp7 any = A_arbace_core_server_A_const_60; var tmp8 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp8 = t__2; var tmp9 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp7, tmp8); var tmp10 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp9, tmp10.Ref()) }
//line :74:1
	return nil }(); var tmp12 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp12 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp12)).Unlock__V(); if tmp11 != nil { panic(tmp11) }; return tmp1 }






func A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000040_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000040_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_63.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(tmp5, A_arbace_core_server_A_const_60); var tmp7 any = A_arbace_core_server_A_const_64.GetRawRoot__O(); var tmp8 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp6, tmp7, tmp8) }
//line :81:1
	return nil }(); var tmp10 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp10 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp10)).Unlock__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }



func A_arbace_core_server_start_server_A_New() *A_arbace_core_server_start_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_core_server_start_server_A) Ctor() {}
//line :85:1
func (t *A_arbace_core_server_start_server_A) Invoke_O_O__O(self, opts__0 any) any {











	lang.IFn_Cast(A_arbace_core_server_A_const_70.GetRawRoot__O()).Invoke_O__O(opts__0)
//line :85:1
	var default__1213000045__2 any; jrt.Boolean_Init(); default__1213000045__2 = jrt.Boolean_TRUE.Ref(); var default__1213000046__3 any; jrt.Boolean_Init(); default__1213000046__3 = jrt.Boolean_TRUE.Ref(); var default__1213000047__4 any; jrt.Boolean_Init(); default__1213000047__4 = jrt.Boolean_TRUE.Ref(); var map__1213000043__5 any = opts__0; var map__1213000043__6 any












	if lang.ISeq_InstanceOf(map__1213000043__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1213000043__5)) { map__1213000043__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_core_server_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1213000043__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1213000043__5)) { map__1213000043__6 = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1213000043__5) } else { lang.PersistentArrayMap_Init(); map__1213000043__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000043__6 = map__1213000043__5 }
//line :85:1
	var address__7 any = lang.RT_Get_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_65); var port__8 any = lang.RT_Get_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_34); var name__9 any = lang.RT_Get_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_33); var accept__10 any = lang.RT_Get_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_35); var args__11 any = lang.RT_Get_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_66); var bind_err__12 any = lang.RT_Get_O_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_67, default__1213000045__2); var server_daemon__13 any = lang.RT_Get_O_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_68, default__1213000046__3); var client_daemon__14 any = lang.RT_Get_O_O_O__O(map__1213000043__6, A_arbace_core_server_A_const_69, default__1213000047__4); var address__15 any = jrt.InetAddress_GetByName_String__InetAddress(jrt.String_Cast(address__7)); var socket__16 any = jrt.ServerSocket_New_I_I_InetAddress(lang.RT_IntCast_O__I(port__8), lang.RT_IntCast_J__I(0), jrt.InetAddress_Cast(address__15)); var lockee__1213000018__auto____17 any = A_arbace_core_server_A_const_56.GetRawRoot__O()


















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____17)).Lock__V(); var tmp1 any = A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(name__9, socket__16, lockee__1213000018__auto____17); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_core_server_start_server_fn__1213000049_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_core_server_start_server_fn__1213000049_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :85:1
	var G__1213000051__17_ any; var tmp3 any = A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(name__9, socket__16, client_daemon__14, args__11, bind_err__12, accept__10); var tmp4 *jrt.Class
	var fncls__7 /*line :85:1*/*jrt.Class = A_arbace_core_server_start_server_fn__1213000052_A_fn_class




















	if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_core_server_start_server_fn__1213000052_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }
//line :85:1
	G__1213000051__17_ = jrt.Thread_New_Runnable_String(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__9)))




















	jrt.Thread_Cast(G__1213000051__17_).SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(server_daemon__13)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000051__17_).Start__V()
//line :85:1
	return socket__16
}

















func A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_start_server_fn__1213000049_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000049_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Ctor_O_O_O(c__name, c__socket, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_socket = c__socket; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var tmp5 any = t.F_name; var tmp6 any = A_arbace_core_server_A_const_33; var tmp7 any; var t_ any = t.F_name; t.F_name = nil; tmp7 = t_; var tmp8 any = tmp7; var tmp9 any = A_arbace_core_server_A_const_72; var tmp10 any; var t__2 any = t.F_socket; t.F_socket = nil; tmp10 = t__2; var tmp11 any = tmp10; var tmp12 any = A_arbace_core_server_A_const_60; var tmp13 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp13 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp11, tmp12, tmp13.Ref()))) }
//line :104:1
	return nil }(); var tmp15 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp15 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp15)).Unlock__V(); if tmp14 != nil { panic(tmp14) }; return tmp1 }

func A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_start_server_fn__1213000052_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Ctor_O_O_O_O_O_O(c__name, c__socket, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var client_counter__3 int64 = 1; L1: for {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_36.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.ServerSocket_Cast(t.F_socket)).IsClosed__Z()).Ref())) {
		var tmp2 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(t.F_name, t.F_socket, client_counter__3, t.F_client_daemon, t.F_args, t.F_bind_err, t.F_accept); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()








		client_counter__3 = lang.Numbers_Inc_J__J(client_counter__3); continue L1 } else {
//line :110:1
			tmp1 = nil }
//line :106:1
	break L1 } }; return nil }(); var lockee__1213000018__auto____3 any = A_arbace_core_server_A_const_56.GetRawRoot__O();















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____3)).Lock__V(); var tmp5 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(lockee__1213000018__auto____3, t.F_name); var tmp6 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class = fncls__4d; tmp6 = fncls__4d } else { tmp6 = fncls__4 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); if /*line :106:1*/ tmp4 != nil { panic(tmp4) }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(p0, p1 any, p2 int64, p3, p4, p5, p6 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A{}; t.Ctor_O_O_J_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Ctor_O_O_J_O_O_O_O(c__name, c__socket any, c__client_counter int64, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_counter = c__client_counter; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var conn__3 any; var tmp2 any; var t_ any = t.F_socket
													t.F_socket = nil; tmp2 = t_; conn__3 = jrt.NN(jrt.ServerSocket_Cast(tmp2)).Accept__Socket()
//line :111:1
	var in__4 any = lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(conn__3).GetInputStream__InputStream())); var out__5 any = jrt.BufferedWriter_New_Writer(jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(conn__3).GetOutputStream__OutputStream())); var client_id__6 any = lang.IFn_Cast(A_arbace_core_server_A_const_73.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(t.F_client_counter).Ref()); var G__1213000054__7_ any; var tmp3 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(in__4, t.F_name, client_id__6, conn__3, out__5, t.F_args, t.F_bind_err, t.F_accept); var tmp4 *jrt.Class
	var fncls__5 /*line :111:1*/*jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class




	if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }
//line :111:1
	var tmp5 jrt.Runnable = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp7 any; var t__2 any = t.F_name





	t.F_name = nil; tmp7 = t__2
//line :111:1
	G__1213000054__7_ = jrt.Thread_New_Runnable_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, client_id__6)))




	var tmp8 jrt.Thread_I = jrt.Thread_Cast(G__1213000054__7_); var tmp9 any; var t__3 any = t.F_client_daemon; t.F_client_daemon = nil; tmp9 = t__3; tmp8.SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(tmp9)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000054__7_).Start__V()
//line :111:1
	tmp1 = G__1213000054__7_ }; return nil }(); if tmp10 != nil { if jrt.SocketException_InstanceOf(tmp10) { var _disconnect__3 jrt.SocketException_I = jrt.SocketException_Cast(tmp10); _ = _disconnect__3; tmp1 = nil } else { panic(tmp10) } }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Ctor_O_O_O_O_O_O_O_O(c__in, c__name, c__client_id, c__conn, c__out, c__args, c__bind_err, c__accept any) { t.F_in = c__in; t.F_name = c__name; t.F_client_id = c__client_id; t.F_conn = c__conn; t.F_out = c__out; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Invoke_O__O(self any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_74.GetRawRoot__O()); var tmp2 any = t.F_conn; var tmp3 any = t.F_name; var tmp4 any = t.F_client_id; var tmp5 any = t.F_in; var tmp6 any = t.F_out; var tmp7 any; if jrt.J2g_Truth(t.F_bind_err) { tmp7 = t.F_out } else { tmp7 = A_arbace_core_server_A_const_52.Get__O() }; return tmp1.Invoke_O_O_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, t.F_accept, t.F_args)
}


func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(p0, p1 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A{}; t.Ctor_O_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Ctor_O_O(c__lockee__1213000018__auto__, c__name any) { t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__; t.F_name = c__name }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_64.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; tmp1 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5) }
//line :122:1
	return nil }(); var tmp7 any; var t__2 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp7 = t__2; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp7)).Unlock__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }



func A_arbace_core_server_stop_server_A_New() *A_arbace_core_server_stop_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_server_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Ctor() {}
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O_O__O(self, name__0 any) any { var lockee__1213000018__auto____2 any = A_arbace_core_server_A_const_56.GetRawRoot__O();






	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Lock__V(); var tmp1 any; tmp4 := /*line :126:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var server_socket__5 any = lang.IFn_Cast(A_arbace_core_server_A_const_75.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_server_A_const_58.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(name__0, A_arbace_core_server_A_const_72))








		if jrt.J2g_Truth(server_socket__5) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; tmp2.Invoke_O_O_O__O(tmp3, A_arbace_core_server_A_const_64.GetRawRoot__O(), name__0)
			jrt.NN(jrt.ServerSocket_Cast(server_socket__5)).Close__V()
//line :135:1
			jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() } else { tmp1 = nil } }; return nil }(); /*line :133:1*/jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Unlock__V(); if /*line :126:1*/ tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O__O(self any) any {




	var tmp1 *lang.Keyword = A_arbace_core_server_A_const_54; return lang.IFn_Cast(A_arbace_core_server_A_const_76.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_core_server_A_const_53.Get__O()))
}







func A_arbace_core_server_stop_servers_A_New() *A_arbace_core_server_stop_servers_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Ctor() {}
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Invoke_O__O(self any) any { var lockee__1213000018__auto____1 any = A_arbace_core_server_A_const_56.GetRawRoot__O();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Lock__V(); var tmp1 any; tmp8 := /*line :140:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1213000063__4 any = lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_77.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_58.GetRawRoot__O())); var chunk_1213000064__5 any; var count_1213000065__6 int64 = 0; var i_1213000066__7 int64 = 0; L1: for {



		if lang.Numbers_Lt_J_J__Z(i_1213000066__7, count_1213000065__6) { var name__8 any = lang.Indexed_Cast(chunk_1213000064__5).Nth_I__O(lang.RT_IntCast_J__I(i_1213000066__7)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_78.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(name__8); var tmp4 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class
			if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class = fncls__8d; tmp4 = fncls__8d } else { tmp4 = fncls__8 }; tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))
//line :144:1
			seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, lang.Numbers_Unchecked_inc_J__J(i_1213000066__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1213000063__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1213000063__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1213000063__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_core_server_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1213000063__9); seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = lang.IFn_Cast(A_arbace_core_server_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1213000063__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var name__10 any = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1213000063__9); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_78.GetRawRoot__O()); var tmp6 any = A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(name__10); var tmp7 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class
				if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class = fncls__9d; tmp7 = fncls__9d } else { tmp7 = fncls__9 }; tmp5.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil))
//line :144:1
				seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1213000063__9), nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :140:1
		break L1 } }; return nil }();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Unlock__V(); if /*line :140:1*/ tmp8 != nil { panic(tmp8) }; return tmp1 }




func A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000067_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000067_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_76.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_name; t.F_name = nil; tmp2 = t_; return tmp1.Invoke_O__O(tmp2) }
//line :145:1
func A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000069_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000069_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_76.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_name; t.F_name = nil; tmp2 = t_; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_core_server_parse_props_A_New() *A_arbace_core_server_parse_props_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_parse_props_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Ctor() {}
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Invoke_O_O__O(self, props__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_core_server_parse_props_fn__1213000072_A_New_O(props__0); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_core_server_parse_props_fn__1213000072_A_fn_class
	if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_core_server_parse_props_fn__1213000072_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }
//line :150:1
	var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; var tmp6 any = tmp5.Ref(); return tmp1.Invoke_O_O_O__O(tmp4, tmp6, jrt.Properties_Cast(props__0).StringPropertyNames__Set()) }
func A_arbace_core_server_parse_props_fn__1213000072_A_New_O(p0 any) *A_arbace_core_server_parse_props_fn__1213000072_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_parse_props_fn__1213000072_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Ctor_O(c__props any) { t.F_props = c__props }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var vec__1213000073__3 any = lang.IFn_Cast(A_arbace_core_server_A_const_80.GetRawRoot__O()).Invoke_O_O__O(k__2, A_arbace_core_server_A_const_81); var k1__4 any = lang.RT_Nth_O_I_O__O(vec__1213000073__3, lang.RT_IntCast_J__I(0), nil); var k2__5 any = lang.RT_Nth_O_I_O__O(vec__1213000073__3, lang.RT_IntCast_J__I(1), nil); var k3__6 any = lang.RT_Nth_O_I_O__O(vec__1213000073__3, lang.RT_IntCast_J__I(2), nil); var tmp1 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(k1__4, Lit_20); if and__1927000168__auto____7 {

	tmp1 = lang.Util_Equiv_O_O__Z(k2__5, Lit_21) } else { tmp1 = and__1927000168__auto____7 }; if tmp1 { var v__7 any = lang.RT_Get_O_O__O(t.F_props, k__2)

		return lang.IFn_Cast(A_arbace_core_server_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__1, lang.IFn_Cast(A_arbace_core_server_A_const_82.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_33, k3__6)), lang.IFn_Cast(A_arbace_core_server_A_const_83.GetRawRoot__O()).Invoke_O__O(v__7))) } else {
//line :153:1
			return acc__1 } }






func A_arbace_core_server_start_servers_A_New() *A_arbace_core_server_start_servers_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_servers_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Ctor() {}
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Invoke_O_O__O(self, system_props__0 any) any { { var seq_1213000078__2 any = lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_84.GetRawRoot__O()).Invoke_O__O(system_props__0)); var chunk_1213000079__3 any; var count_1213000080__4 int64 = 0; var i_1213000081__5 int64 = 0; L1: for {


	if lang.Numbers_Lt_J_J__Z(i_1213000081__5, count_1213000080__4) { var server__6 any = lang.Indexed_Cast(chunk_1213000079__3).Nth_I__O(lang.RT_IntCast_J__I(i_1213000081__5))
		lang.IFn_Cast(A_arbace_core_server_A_const_85.GetRawRoot__O()).Invoke_O__O(server__6)
//line :163:1
		seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, lang.Numbers_Unchecked_inc_J__J(i_1213000081__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1213000078__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1213000078__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1213000078__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_core_server_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1213000078__7); seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = lang.IFn_Cast(A_arbace_core_server_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1213000078__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var server__8 any = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1213000078__7)
			lang.IFn_Cast(A_arbace_core_server_A_const_85.GetRawRoot__O()).Invoke_O__O(server__8)
//line :163:1
			seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1213000078__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :160:1*/panic("j2g: unreachable") }





func A_arbace_core_server_repl_init_A_New() *A_arbace_core_server_repl_init_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_init_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Ctor() {}
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Invoke_O__O(self any) any {


	lang.IFn_Cast(A_arbace_core_server_A_const_86.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_87)
	return lang.IFn_Cast(A_arbace_core_server_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core_server_A_const_1.GetRawRoot__O(), A_arbace_core_server_A_const_88.GetRawRoot__O())
}
func A_arbace_core_server_repl_read_A_New() *A_arbace_core_server_repl_read_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_read_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Ctor() {}
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Invoke_O_O_O__O(self, request_prompt__0, request_exit__1 any) any { var or__1927000174__auto____3 any = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_89, request_prompt__0, A_arbace_core_server_A_const_90, request_exit__1))).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_93.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_50.Get__O())); if


	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_91.GetRawRoot__O()); var tmp2 any = A_arbace_core_server_A_const_94; var input__4 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_core_server_A_const_50.Get__O())


		lang.IFn_Cast(A_arbace_core_server_A_const_95.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_50.Get__O())
//line :175:1
		var G__1213000084__5_ any = input__4



		switch lang.Util_Hash_O__I(G__1213000084__5_) { case 1244597485: if any(G__1213000084__5_) == any(A_arbace_core_server_A_const_92) { return request_exit__1 }; default:}; return input__4 } }



func A_arbace_core_server_repl_A_New() *A_arbace_core_server_repl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_server_repl_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_server_repl_A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_core_server_A_const_97; var tmp3 any = A_arbace_core_server_A_const_98.GetRawRoot__O(); var tmp4 any = A_arbace_core_server_A_const_99; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, A_arbace_core_server_A_const_100.GetRawRoot__O())
}


func A_arbace_core_server_ex__GT_data_A_New() *A_arbace_core_server_ex__GT_data_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_ex__GT_data_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Invoke_O_O_O__O(self, ex__0, phase__1 any) any {

	return lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_101.GetRawRoot__O()).Invoke_O__O(ex__0), A_arbace_core_server_A_const_102, phase__1)
}
func A_arbace_core_server_prepl_A_New() *A_arbace_core_server_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_core_server_prepl_A) Ctor() {}
//line :194:1
func (t *A_arbace_core_server_prepl_A) DoInvoke_O_O_O_O__O(self, in_reader__0, out_fn__1, p__1213000091__2 any) any { var map__1213000092__4 any = p__1213000091__2; var map__1213000092__5 any; if lang.ISeq_InstanceOf(map__1213000092__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1213000092__4)) { map__1213000092__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_core_server_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1213000092__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1213000092__4)) { map__1213000092__5 = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1213000092__4) } else { lang.PersistentArrayMap_Init(); map__1213000092__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000092__5 = map__1213000092__4 }; var stdin__6 any = lang.RT_Get_O_O__O(map__1213000092__5, A_arbace_core_server_A_const_103); var tmp1 any = jrt.Thread_CurrentThread__Thread(); var tmp2 *jrt.Class = A_arbace_core_server_A_const_128; var cl__7 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp2, Lit_22, jrt.RefArrayOf(jrt.Object_class)); var tmp3 any = jrt.Thread_CurrentThread__Thread(); var tmp4 *jrt.Class = A_arbace_core_server_A_const_128;



























	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp3, tmp4, Lit_23, jrt.RefArrayOf(jrt.Object_class, cl__7)); var EOF__7_ any = /*line :194:1*/jrt.Object_New(); var tapfn__8 any; var tmp5 any = A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(out_fn__1); var tmp6 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class; if




























	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class = fncls__12d; tmp6 = fncls__12d } else { tmp6 = fncls__12 }; tapfn__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn =

	lang.IFn_Cast(A_arbace_core_server_A_const_48.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp9 any = A_arbace_core_server_A_const_119; var tmp10 any = A_arbace_core_server_A_const_119.Get__O(); var tmp11 any = A_arbace_core_server_A_const_129; var tmp12 any = A_arbace_core_server_A_const_129.Get__O(); var tmp13 any = A_arbace_core_server_A_const_130; var tmp14 any = A_arbace_core_server_A_const_130.Get__O(); var tmp15 any = A_arbace_core_server_A_const_131; var tmp16 any = A_arbace_core_server_A_const_131.Get__O(); var tmp17 any = A_arbace_core_server_A_const_132; var tmp18 any = A_arbace_core_server_A_const_132.Get__O(); var tmp19 any = A_arbace_core_server_A_const_133; var tmp20 any = A_arbace_core_server_A_const_133.Get__O(); var tmp21 any = A_arbace_core_server_A_const_134; var tmp22 *jrt.Boolean; jrt.Boolean_Init(); tmp22 = jrt.Boolean_TRUE; var tmp23 any = tmp22.Ref(); var tmp24 any = A_arbace_core_server_A_const_135; var tmp25 any = A_arbace_core_server_A_const_135.Get__O(); var tmp26 any = A_arbace_core_server_A_const_136; var tmp27 any = A_arbace_core_server_A_const_136.Get__O(); var tmp28 any = A_arbace_core_server_A_const_137; var tmp29 any = jrt.System_GetProperty_String_String__String(Lit_25, Lit_26).Ref(); var tmp30 any = A_arbace_core_server_A_const_138; var tmp31 any = A_arbace_core_server_A_const_138.Get__O(); var tmp32 any = A_arbace_core_server_A_const_139; var tmp33 any = A_arbace_core_server_A_const_139.Get__O(); var tmp34 any = A_arbace_core_server_A_const_140; var tmp35 any = A_arbace_core_server_A_const_140.Get__O(); var tmp36 any = A_arbace_core_server_A_const_141; tmp7.Invoke_O__O(tmp8.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, A_arbace_core_server_A_const_141.Get__O(), A_arbace_core_server_A_const_114, nil, A_arbace_core_server_A_const_113, nil, A_arbace_core_server_A_const_112, nil, A_arbace_core_server_A_const_120, nil))))); var tmp37 any; tmp63 := /*line :194:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)































		lang.IFn_Cast(A_arbace_core_server_A_const_86.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_142)
		{ var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_48.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp40 any = A_arbace_core_server_A_const_143; var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); var tmp43 any = A_arbace_core_server_A_const_50; var tmp44 any; var or__1927000174__auto____11 any = stdin__6
			if jrt.J2g_Truth(or__1927000174__auto____11) { tmp44 = or__1927000174__auto____11 } else { tmp44 = in_reader__0 }
//line :227:1
			var tmp45 any = tmp44; var tmp46 any = A_arbace_core_server_A_const_51; var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_144.GetRawRoot__O()); var tmp48 any = A_arbace_core_server_prepl_fn__1213000096_A_New_O(out_fn__1); var tmp49 *jrt.Class
			var fncls__14 /*line :227:1*/*jrt.Class = A_arbace_core_server_prepl_fn__1213000096_A_fn_class

			if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_core_server_prepl_fn__1213000096_A_fn_class = fncls__14d; tmp49 = fncls__14d } else { tmp49 = fncls__14 }
//line :227:1
			var tmp50 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp48, tmp49, nil); var tmp51 *jrt.Boolean; jrt.Boolean_Init(); tmp51 = jrt.Boolean_TRUE; var tmp52 any = tmp47.Invoke_O_O_O__O(tmp50, nil, tmp51.Ref()); var tmp53 any = A_arbace_core_server_A_const_52; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_144.GetRawRoot__O()); var tmp55 any = A_arbace_core_server_prepl_fn__1213000098_A_New_O(out_fn__1); var tmp56 *jrt.Class
			var fncls__15 /*line :227:1*/*jrt.Class = A_arbace_core_server_prepl_fn__1213000098_A_fn_class


			if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_core_server_prepl_fn__1213000098_A_fn_class = fncls__15d; tmp56 = fncls__15d } else { tmp56 = fncls__15 }
//line :227:1
			var tmp57 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil); var tmp58 *jrt.Boolean; jrt.Boolean_Init(); tmp58 = jrt.Boolean_TRUE; tmp38.Invoke_O__O(tmp39.Invoke_O_O_O_O_O_O_O_O__O(tmp40, tmp42, tmp43, tmp45, tmp46, tmp52, tmp53, tmp54.Invoke_O_O_O__O(tmp57, nil, tmp58.Ref()))); tmp62 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp61 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




				lang.IFn_Cast(A_arbace_core_server_A_const_147.GetRawRoot__O()).Invoke_O__O(tapfn__8)
//line :194:1
			L1: for {







































				var tmp59 any = A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(EOF__7_, out_fn__1, in_reader__0); var tmp60 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_core_server_prepl_fn__1213000100_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_core_server_prepl_fn__1213000100_A_fn_class = fncls__13d; tmp60 = fncls__13d } else { tmp60 = fncls__13 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil).Invoke__O()) {






























					continue L1 } else {
//line :234:1
						tmp37 = nil }
//line :194:1
				break L1
			}































				return nil
			}()






































				lang.IFn_Cast(A_arbace_core_server_A_const_127.GetRawRoot__O()).Invoke_O__O(tapfn__8)
//line :194:1
				if tmp61 != nil { panic(tmp61)
				}
			}; return nil }()






























			lang.IFn_Cast(A_arbace_core_server_A_const_47.GetRawRoot__O()).Invoke__O()
//line :194:1
			if tmp62 != nil { panic(tmp62) } }; return nil }();






























	lang.IFn_Cast(A_arbace_core_server_A_const_47.GetRawRoot__O()).Invoke__O(); if /*line :194:1*/ tmp63 != nil { panic(tmp63) }; return tmp37 }




























func A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(p0 any) *A_arbace_core_server_prepl_tapfn__1213000094_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_tapfn__1213000094_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Invoke_O_O__O(self, p1__1213000088_SHARP___1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_105, A_arbace_core_server_A_const_106, p1__1213000088_SHARP___1)))
}



func A_arbace_core_server_prepl_fn__1213000096_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000096_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000096_A{}; t.Ctor_O(p0); return t }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Invoke_O_O__O(self, p1__1213000089_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_145, A_arbace_core_server_A_const_106, p1__1213000089_SHARP___1))) }
func A_arbace_core_server_prepl_fn__1213000098_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000098_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000098_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Invoke_O_O__O(self, p1__1213000090_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_146, A_arbace_core_server_A_const_106, p1__1213000090_SHARP___1))) }



func A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_prepl_fn__1213000100_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000100_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Ctor_O_O_O(c__EOF, c__out_fn, c__in_reader any) { t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_in_reader = c__in_reader }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp31 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1213000101__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_107.GetRawRoot__O()); var tmp3 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_109, t.F_EOF, A_arbace_core_server_A_const_110, A_arbace_core_server_A_const_111)); var tmp4 any; var t_ any = t.F_in_reader
										t.F_in_reader = nil; tmp4 = t_; vec__1213000101__3 = tmp2.Invoke_O_O__O(tmp3, tmp4)
//line :234:1
	var form__4 any = lang.RT_Nth_O_I_O__O(vec__1213000101__3, lang.RT_IntCast_J__I(0), nil); var s__5 any = lang.RT_Nth_O_I_O__O(vec__1213000101__3, lang.RT_IntCast_J__I(1), nil); tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp5 any; var t__2 any = t.F_EOF; t.F_EOF = nil; tmp5 = t__2; if lang.Util_Identical_O_O__Z(form__4, tmp5) { tmp1 = nil } else { var start__8 int64 = jrt.System_NanoTime__J(); var ret__9 any = lang.IFn_Cast(A_arbace_core_server_A_const_108.GetRawRoot__O()).Invoke_O__O(form__4); var ms__10 int64 = lang.Numbers_Quotient_J_J__J(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), start__8), 1000000)



			if lang.Util_Equiv_O_O__Z(A_arbace_core_server_A_const_92, ret__9) { tmp1 = nil } else { var tmp6 *lang.Var = A_arbace_core_server_A_const_112; tmp6.Set_O__O(A_arbace_core_server_A_const_113.Get__O()); var tmp7 *lang.Var = A_arbace_core_server_A_const_113; tmp7.Set_O__O(A_arbace_core_server_A_const_114.Get__O()); A_arbace_core_server_A_const_114.Set_O__O(ret__9)



				var tmp8 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp9 any = A_arbace_core_server_A_const_104; var tmp10 any = A_arbace_core_server_A_const_115; var tmp11 any = A_arbace_core_server_A_const_106; var tmp12 any
				if jrt.Throwable_InstanceOf(ret__9) {
					tmp12 = lang.IFn_Cast(A_arbace_core_server_A_const_101.GetRawRoot__O()).Invoke_O__O(ret__9) } else {
//line :246:1
						tmp12 = ret__9 }
//line :245:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_core_server_A_const_116; var tmp15 any = lang.IFn_Cast(A_arbace_core_server_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(A_arbace_core_server_A_const_119.Get__O()).F_name.Ref()); var tmp16 any = A_arbace_core_server_A_const_117; tmp8.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp13, tmp14, tmp15, tmp16, jrt.Long_ValueOf_J__Long(ms__10).Ref(), A_arbace_core_server_A_const_118, s__5)))
//line :241:1
				jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() } } }
//line :234:1
		return nil }(); if tmp17 != nil { if true { var ex__8 jrt.Throwable_I = tmp17; A_arbace_core_server_A_const_120.Set_O__O(ex__8)




















			var tmp18 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp19 any = A_arbace_core_server_A_const_104; var tmp20 any = A_arbace_core_server_A_const_115; var tmp21 any = A_arbace_core_server_A_const_106; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_121.GetRawRoot__O()); var tmp23 any; var tmp24 *lang.Keyword = A_arbace_core_server_A_const_123; var or__1927000174__auto____9 any = tmp24.Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_124.GetRawRoot__O()).Invoke_O__O(ex__8)); if jrt.J2g_Truth(or__1927000174__auto____9) { tmp23 = or__1927000174__auto____9 } else { tmp23 = A_arbace_core_server_A_const_125 }; var tmp25 any = tmp22.Invoke_O_O__O(ex__8, tmp23); var tmp26 any = A_arbace_core_server_A_const_116; var tmp27 any = lang.IFn_Cast(A_arbace_core_server_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(A_arbace_core_server_A_const_119.Get__O()).F_name.Ref()); var tmp28 any = A_arbace_core_server_A_const_118; var tmp29 any = A_arbace_core_server_A_const_122; var tmp30 *jrt.Boolean; jrt.Boolean_Init(); tmp30 = jrt.Boolean_TRUE; tmp18.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp20, tmp21, tmp25, tmp26, tmp27, tmp28, s__5, tmp29, tmp30.Ref())))
//line :234:1
			jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() } } }; return nil }(); if tmp31 != nil { if true { var ex__3 jrt.Throwable_I = tmp31; A_arbace_core_server_A_const_120.Set_O__O(ex__3)


























				var tmp32 any; var t__3 any = t.F_out_fn; t.F_out_fn = nil; tmp32 = t__3; var tmp33 lang.IFn = lang.IFn_Cast(tmp32); var tmp34 any = A_arbace_core_server_A_const_104; var tmp35 any = A_arbace_core_server_A_const_115; var tmp36 any = A_arbace_core_server_A_const_106; var tmp37 any = lang.IFn_Cast(A_arbace_core_server_A_const_121.GetRawRoot__O()).Invoke_O_O__O(ex__3, A_arbace_core_server_A_const_126); var tmp38 any = A_arbace_core_server_A_const_116; var tmp39 any = lang.IFn_Cast(A_arbace_core_server_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(A_arbace_core_server_A_const_119.Get__O()).F_name.Ref()); var tmp40 any = A_arbace_core_server_A_const_122; var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; tmp33.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41.Ref())))
//line :234:1
				jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() } }; return tmp1 }


































func A_arbace_core_server_resolve_fn_A_New() *A_arbace_core_server_resolve_fn_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_resolve_fn_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Ctor() {}
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Invoke_O_O__O(self, valf__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_148.GetRawRoot__O()).Invoke_O__O(valf__0)) { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_core_server_A_const_46.GetRawRoot__O()).Invoke_O__O(valf__0)
		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_core_server_A_const_62.GetRawRoot__O()).Invoke_O__O(valf__0)
			if jrt.J2g_Truth(temp__1927000414__auto____3) { var nsname__4 any = temp__1927000414__auto____3
				lang.IFn_Cast(A_arbace_core_server_A_const_1.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_61.GetRawRoot__O()).Invoke_O__O(nsname__4))
				or__1927000174__auto____3 = lang.IFn_Cast(A_arbace_core_server_A_const_46.GetRawRoot__O()).Invoke_O__O(valf__0) } else {
//line :272:1
					or__1927000174__auto____3 = nil }
//line :271:1
			if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_35, nil), jrt.RefArrayOf(jrt.Object_class, nil, valf__0))))) } } } else {
//line :270:1
				return valf__0
			}
}





func A_arbace_core_server_io_prepl_A_New() *A_arbace_core_server_io_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) Ctor() {}
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) DoInvoke_O_O__O(self, p__1213000107__0 any) any { var default__1213000110__2 any = A_arbace_core_server_A_const_149.GetRawRoot__O(); var map__1213000108__3 any = p__1213000107__0; var map__1213000108__4 any; if lang.ISeq_InstanceOf(map__1213000108__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1213000108__3)) { map__1213000108__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_core_server_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1213000108__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1213000108__3)) { map__1213000108__4 = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1213000108__3) } else { lang.PersistentArrayMap_Init(); map__1213000108__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000108__4 = map__1213000108__3 }; var valf__5 any = lang.RT_Get_O_O_O__O(map__1213000108__4, A_arbace_core_server_A_const_150, default__1213000110__2); var valf__6 any = lang.IFn_Cast(A_arbace_core_server_A_const_151.GetRawRoot__O()).Invoke_O__O(valf__5); var out__7 any = A_arbace_core_server_A_const_51.Get__O(); var lock__8 any = jrt.Object_New(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_152.GetRawRoot__O()); var tmp2 any = A_arbace_core_server_A_const_50.Get__O(); var tmp3 any = A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(lock__8, out__7, valf__6); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class; if











	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; return /*line :289:1*/ tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
func A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_io_prepl_fn__1213000112_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Ctor_O_O_O(c__lock, c__out, c__valf any) { t.F_lock = c__lock; t.F_out = c__out; t.F_valf = c__valf }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_48.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_51; var tmp4 any = t.F_out; var tmp5 any = A_arbace_core_server_A_const_154; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_core_server_A_const_155; var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp7, tmp8, tmp9.Ref()))
//line :290:1
	var tmp10 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var lockee__1927000360__auto____4 any = t.F_lock; var locklocal__1927000361__auto____7 any = lockee__1927000360__auto____4; lang.Compiler_Evaluator_MonitorEnter_O__V(locklocal__1927000361__auto____7); tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_153.GetRawRoot__O()); var tmp12 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_156); if jrt.J2g_Truth(tmp13.Invoke_O__O(A_arbace_core_server_A_const_104.Invoke_O__O(m__1))) {
			var tmp14 any = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(m__1, t.F_valf); var tmp15 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class = fncls__16d; tmp15 = fncls__16d } else { tmp15 = fncls__16 }; tmp12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O() } else {
//line :293:1
				tmp12 = m__1 }; tmp10 = tmp11.Invoke_O__O(tmp12) }
//line :290:1
		return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V(locklocal__1927000361__auto____7); if tmp16 != nil { panic(tmp16) } }; return nil }()
	lang.IFn_Cast(A_arbace_core_server_A_const_47.GetRawRoot__O()).Invoke__O()
//line :290:1
	if tmp17 != nil { panic(tmp17) }; return tmp10
}


func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(p0, p1 any) *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A{}; t.Ctor_O_O(p0, p1); return t }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Ctor_O_O(c__m, c__valf any) { t.F_m = c__m; t.F_valf = c__valf }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp3 any = t.F_m; var tmp4 any = A_arbace_core_server_A_const_106; var tmp5 lang.IFn = lang.IFn_Cast(t.F_valf); tmp1 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O__O(A_arbace_core_server_A_const_106.Invoke_O__O(t.F_m))) }
//line :294:1
	return nil }(); if tmp6 != nil { if true { var ex__3 jrt.Throwable_I = tmp6; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp8 any; var t_ any = t.F_m


		t.F_m = nil; tmp8 = t_; var tmp9 any = tmp8; var tmp10 any = A_arbace_core_server_A_const_106; var tmp11 any; var t__2 any = t.F_valf; t.F_valf = nil; tmp11 = t__2; var tmp12 any = lang.IFn_Cast(tmp11).Invoke_O__O(lang.IFn_Cast(A_arbace_core_server_A_const_121.GetRawRoot__O()).Invoke_O_O__O(ex__3, A_arbace_core_server_A_const_157)); var tmp13 any = A_arbace_core_server_A_const_122; var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; tmp1 = tmp7.Invoke_O_O_O_O_O__O(tmp9, tmp10, tmp12, tmp13, tmp14.Ref()) } }; return tmp1 }



func A_arbace_core_server_remote_prepl_A_New() *A_arbace_core_server_remote_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) DoInvoke_O_O_O_O_O_O__O(self, host__0, port__1, in_reader__2, out_fn__3, p__1213000119__4 any) any { var default__1213000122__6 any = A_arbace_core_server_A_const_158.GetRawRoot__O(); var default__1213000123__7 any; var tmp1 any = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New(); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; default__1213000123__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var map__1213000120__8 any = p__1213000119__4; var map__1213000120__9 any; if lang.ISeq_InstanceOf(map__1213000120__8) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1213000120__8)) { map__1213000120__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_core_server_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1213000120__8), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1213000120__8)) { map__1213000120__9 = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1213000120__8) } else { lang.PersistentArrayMap_Init(); map__1213000120__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000120__9 = map__1213000120__8 }; var valf__10 any = lang.RT_Get_O_O_O__O(map__1213000120__9, A_arbace_core_server_A_const_150, default__1213000122__6); var readf__11 any = lang.RT_Get_O_O_O__O(map__1213000120__9, A_arbace_core_server_A_const_159, default__1213000123__7); var valf__12 any = lang.IFn_Cast(A_arbace_core_server_A_const_151.GetRawRoot__O()).Invoke_O__O(valf__10); var readf__13 any = lang.IFn_Cast(A_arbace_core_server_A_const_151.GetRawRoot__O()).Invoke_O__O(readf__11); var port__14 any; if














	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_160.GetRawRoot__O()).Invoke_O__O(port__1)) { port__14 = jrt.Integer_ValueOf_String__Integer(jrt.String_Cast(port__1)).Ref() } else { port__14 = port__1 }; var socket__15 any = /*line :301:1*/jrt.Socket_New_String_I(jrt.String_Cast(host__0), lang.RT_IntCast_O__I(port__14)); var rd__16 any = lang.LineNumberingPushbackReader_New_Reader(jrt.BufferedReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(socket__15).GetInputStream__InputStream()))); var wr__17 any = jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(socket__15).GetOutputStream__OutputStream()); var EOF__18_ any = jrt.Object_New(); var G__1213000127__19_ any; var tmp3 any = A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(rd__16, readf__13, wr__17, EOF__18_, out_fn__3, valf__12); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class; if



















	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; G__1213000127__19_ = /*line :301:1*/jrt.Thread_New_Runnable_String(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), Lit_32); var tmp5 jrt.Thread_I =



















	jrt.Thread_Cast(G__1213000127__19_); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; tmp5.SetDaemon_Z__V(jrt.NN(tmp6).BooleanValue__Z()); jrt.Thread_Cast(G__1213000127__19_).Start__V(); var buf__19 any = /*line :301:1*/lang.Numbers_Char_array_O__C1(A_arbace_core_server_A_const_161).Ref(); var tmp7 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L1: for { var n__22 int32 = jrt.Reader_Cast(in_reader__2).Read_C1__I(jrt.J2g_CastArray[*jrt.CharArray](buf__19, jrt.Prim_char.ArrayClass()))





































		if lang.Util_Equiv_J_J__Z(int64(n__22), -1) { tmp7 = nil } else {
			jrt.OutputStreamWriter_Cast(wr__17).Write_C1_I_I__V(jrt.J2g_CastArray[*jrt.CharArray](buf__19, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I(0), n__22)
			jrt.OutputStreamWriter_Cast(wr__17).Flush__V()
			continue L1 }
//line :301:1
		break L1 }; return nil }();










































	jrt.PushbackReader_Cast(rd__16).Close__V(); if /*line :301:1*/ tmp8 != nil { panic(tmp8) }; return tmp7 }
//line :301:1
func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New() *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Invoke_O_O_O__O(self, p1__1213000117_SHARP___1, p2__1213000118_SHARP___2 any) any {











	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_91.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O_O__O(p1__1213000117_SHARP___1, tmp2.Ref(), p2__1213000118_SHARP___2)
}






func A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_remote_prepl_fn__1213000128_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Ctor_O_O_O_O_O_O(c__rd, c__readf, c__wr, c__EOF, c__out_fn, c__valf any) { t.F_rd = c__rd; t.F_readf = c__readf; t.F_wr = c__wr; t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_valf = c__valf }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Invoke_O__O(self any) any { for { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L2: for { var map__1213000129__3 any = lang.IFn_Cast(t.F_readf).Invoke_O_O__O(t.F_rd, t.F_EOF); var map__1213000129__4 any

	if lang.ISeq_InstanceOf(map__1213000129__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1213000129__3)) { map__1213000129__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_core_server_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1213000129__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1213000129__3)) { map__1213000129__4 = lang.IFn_Cast(A_arbace_core_server_A_const_32.GetRawRoot__O()).Invoke_O__O(map__1213000129__3) } else { lang.PersistentArrayMap_Init(); map__1213000129__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000129__4 = map__1213000129__3 }
//line :321:1
	var m__5 any = map__1213000129__4; var tag__6 any = lang.RT_Get_O_O__O(map__1213000129__4, A_arbace_core_server_A_const_104); var val__7 any = lang.RT_Get_O_O__O(map__1213000129__4, A_arbace_core_server_A_const_106)


	if lang.Util_Identical_O_O__Z(m__5, t.F_EOF) { tmp1 = nil } else {
		var tmp2 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp3 any
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_162).Invoke_O__O(tag__6)) {
			var tmp4 any = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(m__5, t.F_valf, val__7); var tmp5 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class = fncls__19d; tmp5 = fncls__19d } else { tmp5 = fncls__19 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O() } else {
//line :326:1
				tmp3 = m__5 }
//line :325:1
		tmp2.Invoke_O__O(tmp3)







		continue L2 }
//line :321:1
	break L2 }; return nil }()













	jrt.OutputStreamWriter_Cast(t.F_wr).Close__V()
//line :321:1
	if tmp6 != nil { panic(tmp6) }; return tmp1 }; panic("j2g: unreachable") }





func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Ctor_O_O_O(c__m, c__valf, c__val any) { t.F_m = c__m; t.F_valf = c__valf; t.F_val = c__val }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp3 any = t.F_m; var tmp4 any = A_arbace_core_server_A_const_106; var tmp5 any; var t_ any = t.F_valf; t.F_valf = nil; tmp5 = t_; var tmp6 lang.IFn = lang.IFn_Cast(tmp5); var tmp7 any; var t__2 any = t.F_val; t.F_val = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp6.Invoke_O__O(tmp7)) }
//line :327:1
	return nil }(); if tmp8 != nil { if true { var ex__3 jrt.Throwable_I = tmp8; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp10 any; var t__3 any = t.F_m


		t.F_m = nil; tmp10 = t__3; var tmp11 any = tmp10; var tmp12 any = A_arbace_core_server_A_const_106; var tmp13 any = lang.IFn_Cast(A_arbace_core_server_A_const_121.GetRawRoot__O()).Invoke_O_O__O(ex__3, A_arbace_core_server_A_const_163); var tmp14 any = A_arbace_core_server_A_const_122; var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_TRUE; tmp1 = tmp9.Invoke_O_O_O_O_O__O(tmp11, tmp12, tmp13, tmp14, tmp15.Ref()) } }; return tmp1 }




type A_arbace_core_server_A struct{ jrt.Object }

var A_arbace_core_server_A_const_pool *jrt.RefArray

var A_arbace_core_server_A_const_0 *lang.Var

var A_arbace_core_server_A_const_1 *lang.Var

var A_arbace_core_server_A_const_2 any

var A_arbace_core_server_A_const_3 any

var A_arbace_core_server_A_const_4 any

var A_arbace_core_server_A_const_5 any

var A_arbace_core_server_A_const_6 *lang.Var

var A_arbace_core_server_A_const_7 *lang.Var

var A_arbace_core_server_A_const_8 *lang.Var

var A_arbace_core_server_A_const_9 any

var A_arbace_core_server_A_const_10 *lang.Var

var A_arbace_core_server_A_const_11 *lang.Var

var A_arbace_core_server_A_const_12 *lang.Var

var A_arbace_core_server_A_const_13 *lang.Var

var A_arbace_core_server_A_const_14 any

var A_arbace_core_server_A_const_15 *lang.Var

var A_arbace_core_server_A_const_16 *lang.Var

var A_arbace_core_server_A_const_17 any

var A_arbace_core_server_A_const_18 *lang.Var

var A_arbace_core_server_A_const_19 any

var A_arbace_core_server_A_const_20 any

var A_arbace_core_server_A_const_21 any

var A_arbace_core_server_A_const_22 any

var A_arbace_core_server_A_const_23 any

var A_arbace_core_server_A_const_24 any

var A_arbace_core_server_A_const_25 any

var A_arbace_core_server_A_const_26 any

var A_arbace_core_server_A_const_27 any

var A_arbace_core_server_A_const_28 any

var A_arbace_core_server_A_const_29 *lang.Var

var A_arbace_core_server_A_const_30 *lang.Var

var A_arbace_core_server_A_const_31 *lang.Var

var A_arbace_core_server_A_const_32 *lang.Var

var A_arbace_core_server_A_const_33 *lang.Keyword

var A_arbace_core_server_A_const_34 *lang.Keyword

var A_arbace_core_server_A_const_35 *lang.Keyword

var A_arbace_core_server_A_const_36 *lang.Var

var A_arbace_core_server_A_const_37 *lang.Var

var A_arbace_core_server_A_const_38 *lang.Var

var A_arbace_core_server_A_const_39 any

var A_arbace_core_server_A_const_40 *lang.Var

var A_arbace_core_server_A_const_41 *lang.Var

var A_arbace_core_server_A_const_42 *lang.Var

var A_arbace_core_server_A_const_43 *lang.Var

var A_arbace_core_server_A_const_44 any

var A_arbace_core_server_A_const_45 any

var A_arbace_core_server_A_const_46 *lang.Var

var A_arbace_core_server_A_const_47 *lang.Var

var A_arbace_core_server_A_const_48 *lang.Var

var A_arbace_core_server_A_const_49 *lang.Var

var A_arbace_core_server_A_const_50 *lang.Var

var A_arbace_core_server_A_const_51 *lang.Var

var A_arbace_core_server_A_const_52 *lang.Var

var A_arbace_core_server_A_const_53 *lang.Var

var A_arbace_core_server_A_const_54 *lang.Keyword

var A_arbace_core_server_A_const_55 *lang.Keyword

var A_arbace_core_server_A_const_56 *lang.Var

var A_arbace_core_server_A_const_57 *lang.Var

var A_arbace_core_server_A_const_58 *lang.Var

var A_arbace_core_server_A_const_59 *lang.Var

var A_arbace_core_server_A_const_60 *lang.Keyword

var A_arbace_core_server_A_const_61 *lang.Var

var A_arbace_core_server_A_const_62 *lang.Var

var A_arbace_core_server_A_const_63 *lang.Var

var A_arbace_core_server_A_const_64 *lang.Var

var A_arbace_core_server_A_const_65 *lang.Keyword

var A_arbace_core_server_A_const_66 *lang.Keyword

var A_arbace_core_server_A_const_67 *lang.Keyword

var A_arbace_core_server_A_const_68 *lang.Keyword

var A_arbace_core_server_A_const_69 *lang.Keyword

var A_arbace_core_server_A_const_70 *lang.Var

var A_arbace_core_server_A_const_71 *lang.Var

var A_arbace_core_server_A_const_72 *lang.Keyword

var A_arbace_core_server_A_const_73 *lang.Var

var A_arbace_core_server_A_const_74 *lang.Var

var A_arbace_core_server_A_const_75 *lang.Var

var A_arbace_core_server_A_const_76 *lang.Var

var A_arbace_core_server_A_const_77 *lang.Var

var A_arbace_core_server_A_const_78 *lang.Var

var A_arbace_core_server_A_const_79 *lang.Var

var A_arbace_core_server_A_const_80 *lang.Var

var A_arbace_core_server_A_const_81 any

var A_arbace_core_server_A_const_82 *lang.Var

var A_arbace_core_server_A_const_83 *lang.Var

var A_arbace_core_server_A_const_84 *lang.Var

var A_arbace_core_server_A_const_85 *lang.Var

var A_arbace_core_server_A_const_86 *lang.Var

var A_arbace_core_server_A_const_87 any

var A_arbace_core_server_A_const_88 *lang.Var

var A_arbace_core_server_A_const_89 *lang.Keyword

var A_arbace_core_server_A_const_90 *lang.Keyword

var A_arbace_core_server_A_const_91 *lang.Var

var A_arbace_core_server_A_const_92 *lang.Keyword

var A_arbace_core_server_A_const_93 *lang.Var

var A_arbace_core_server_A_const_94 any

var A_arbace_core_server_A_const_95 *lang.Var

var A_arbace_core_server_A_const_96 *lang.Var

var A_arbace_core_server_A_const_97 *lang.Keyword

var A_arbace_core_server_A_const_98 *lang.Var

var A_arbace_core_server_A_const_99 *lang.Keyword

var A_arbace_core_server_A_const_100 *lang.Var

var A_arbace_core_server_A_const_101 *lang.Var

var A_arbace_core_server_A_const_102 *lang.Keyword

var A_arbace_core_server_A_const_103 *lang.Keyword

var A_arbace_core_server_A_const_104 *lang.Keyword

var A_arbace_core_server_A_const_105 *lang.Keyword

var A_arbace_core_server_A_const_106 *lang.Keyword

var A_arbace_core_server_A_const_107 *lang.Var

var A_arbace_core_server_A_const_108 *lang.Var

var A_arbace_core_server_A_const_109 *lang.Keyword

var A_arbace_core_server_A_const_110 *lang.Keyword

var A_arbace_core_server_A_const_111 *lang.Keyword

var A_arbace_core_server_A_const_112 *lang.Var

var A_arbace_core_server_A_const_113 *lang.Var

var A_arbace_core_server_A_const_114 *lang.Var

var A_arbace_core_server_A_const_115 *lang.Keyword

var A_arbace_core_server_A_const_116 *lang.Keyword

var A_arbace_core_server_A_const_117 *lang.Keyword

var A_arbace_core_server_A_const_118 *lang.Keyword

var A_arbace_core_server_A_const_119 *lang.Var

var A_arbace_core_server_A_const_120 *lang.Var

var A_arbace_core_server_A_const_121 *lang.Var

var A_arbace_core_server_A_const_122 *lang.Keyword

var A_arbace_core_server_A_const_123 *lang.Keyword

var A_arbace_core_server_A_const_124 *lang.Var

var A_arbace_core_server_A_const_125 *lang.Keyword

var A_arbace_core_server_A_const_126 *lang.Keyword

var A_arbace_core_server_A_const_127 *lang.Var

var A_arbace_core_server_A_const_128 *jrt.Class

var A_arbace_core_server_A_const_129 *lang.Var

var A_arbace_core_server_A_const_130 *lang.Var

var A_arbace_core_server_A_const_131 *lang.Var

var A_arbace_core_server_A_const_132 *lang.Var

var A_arbace_core_server_A_const_133 *lang.Var

var A_arbace_core_server_A_const_134 *lang.Var

var A_arbace_core_server_A_const_135 *lang.Var

var A_arbace_core_server_A_const_136 *lang.Var

var A_arbace_core_server_A_const_137 *lang.Var

var A_arbace_core_server_A_const_138 *lang.Var

var A_arbace_core_server_A_const_139 *lang.Var

var A_arbace_core_server_A_const_140 *lang.Var

var A_arbace_core_server_A_const_141 *lang.Var

var A_arbace_core_server_A_const_142 any

var A_arbace_core_server_A_const_143 *lang.Var

var A_arbace_core_server_A_const_144 *lang.Var

var A_arbace_core_server_A_const_145 *lang.Keyword

var A_arbace_core_server_A_const_146 *lang.Keyword

var A_arbace_core_server_A_const_147 *lang.Var

var A_arbace_core_server_A_const_148 *lang.Var

var A_arbace_core_server_A_const_149 *lang.Var

var A_arbace_core_server_A_const_150 *lang.Keyword

var A_arbace_core_server_A_const_151 *lang.Var

var A_arbace_core_server_A_const_152 *lang.Var

var A_arbace_core_server_A_const_153 *lang.Var

var A_arbace_core_server_A_const_154 *lang.Var

var A_arbace_core_server_A_const_155 *lang.Var

var A_arbace_core_server_A_const_156 any

var A_arbace_core_server_A_const_157 *lang.Keyword

var A_arbace_core_server_A_const_158 *lang.Var

var A_arbace_core_server_A_const_159 *lang.Keyword

var A_arbace_core_server_A_const_160 *lang.Var

var A_arbace_core_server_A_const_161 any

var A_arbace_core_server_A_const_162 any

var A_arbace_core_server_A_const_163 *lang.Keyword

var A_arbace_core_server_A_init jrt.ClassInit

func A_arbace_core_server_A_Init() { if !A_arbace_core_server_A_init.Done() { A_arbace_core_server_A_init.Run(A_arbace_core_server_A_clinit) } }

func A_arbace_core_server_A_clinit() { A_arbace_core_server_A_clinit_p0(); A_arbace_core_server_A_clinit_p1(); A_arbace_core_server_A_clinit_p2(); A_arbace_core_server_A_clinit_p3(); A_arbace_core_server_A_clinit_p4(); A_arbace_core_server_A_clinit_p5(); A_arbace_core_server_A_clinit_p6(); A_arbace_core_server_A_clinit_p7(); A_arbace_core_server_A_clinit_p8(); A_arbace_core_server_A_clinit_p9(); A_arbace_core_server_A_clinit_p10(); A_arbace_core_server_A_clinit_p11(); A_arbace_core_server_A_clinit_p12(); A_arbace_core_server_A_clinit_p13() }

func A_arbace_core_server_A_clinit_p0() { A_arbace_core_server_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 226); A_arbace_core_server_A_const_0 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[62]); A_arbace_core_server_A_const_1 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[63]); A_arbace_core_server_A_const_2 = A_arbace_core_server_A_const_pool.A[64]; A_arbace_core_server_A_const_3 = A_arbace_core_server_A_const_pool.A[65]; A_arbace_core_server_A_const_4 = A_arbace_core_server_A_const_pool.A[66]; A_arbace_core_server_A_const_5 = A_arbace_core_server_A_const_pool.A[67]; A_arbace_core_server_A_const_6 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[68]); A_arbace_core_server_A_const_7 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[69]); A_arbace_core_server_A_const_8 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[70]); A_arbace_core_server_A_const_9 = A_arbace_core_server_A_const_pool.A[71]; A_arbace_core_server_A_const_10 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[72]); A_arbace_core_server_A_const_11 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[73]) }

func A_arbace_core_server_A_clinit_p1() { A_arbace_core_server_A_const_12 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[74]); A_arbace_core_server_A_const_13 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[75]); A_arbace_core_server_A_const_14 = A_arbace_core_server_A_const_pool.A[76]; A_arbace_core_server_A_const_15 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[77]); A_arbace_core_server_A_const_16 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[78]); A_arbace_core_server_A_const_17 = A_arbace_core_server_A_const_pool.A[79]; A_arbace_core_server_A_const_18 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[80]); A_arbace_core_server_A_const_19 = A_arbace_core_server_A_const_pool.A[81]; A_arbace_core_server_A_const_20 = A_arbace_core_server_A_const_pool.A[82]; A_arbace_core_server_A_const_21 = A_arbace_core_server_A_const_pool.A[83]; A_arbace_core_server_A_const_22 = A_arbace_core_server_A_const_pool.A[84]; A_arbace_core_server_A_const_23 = A_arbace_core_server_A_const_pool.A[85]; A_arbace_core_server_A_const_24 = A_arbace_core_server_A_const_pool.A[86]; A_arbace_core_server_A_const_25 = A_arbace_core_server_A_const_pool.A[87] }

func A_arbace_core_server_A_clinit_p2() { A_arbace_core_server_A_const_26 = A_arbace_core_server_A_const_pool.A[88]; A_arbace_core_server_A_const_27 = A_arbace_core_server_A_const_pool.A[89]; A_arbace_core_server_A_const_28 = A_arbace_core_server_A_const_pool.A[90]; A_arbace_core_server_A_const_29 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[91]); A_arbace_core_server_A_const_30 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[92]); A_arbace_core_server_A_const_31 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[93]); A_arbace_core_server_A_const_32 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[94]); A_arbace_core_server_A_const_33 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[95]); A_arbace_core_server_A_const_34 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[96]); A_arbace_core_server_A_const_35 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[97]); A_arbace_core_server_A_const_36 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[98]); A_arbace_core_server_A_const_37 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[99]) }

func A_arbace_core_server_A_clinit_p3() { A_arbace_core_server_A_const_38 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[100]); A_arbace_core_server_A_const_39 = A_arbace_core_server_A_const_pool.A[101]; A_arbace_core_server_A_const_40 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[102]); A_arbace_core_server_A_const_41 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[103]); A_arbace_core_server_A_const_42 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[104]); A_arbace_core_server_A_const_43 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[105]); A_arbace_core_server_A_const_44 = A_arbace_core_server_A_const_pool.A[106]; A_arbace_core_server_A_const_45 = A_arbace_core_server_A_const_pool.A[107]; A_arbace_core_server_A_const_46 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[108]); A_arbace_core_server_A_const_47 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[109]); A_arbace_core_server_A_const_48 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[110]); A_arbace_core_server_A_const_49 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[111]) }

func A_arbace_core_server_A_clinit_p4() { A_arbace_core_server_A_const_50 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[112]); A_arbace_core_server_A_const_51 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[113]); A_arbace_core_server_A_const_52 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[114]); A_arbace_core_server_A_const_53 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[115]); A_arbace_core_server_A_const_54 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[116]); A_arbace_core_server_A_const_55 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[117]); A_arbace_core_server_A_const_56 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[118]); A_arbace_core_server_A_const_57 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[119]); A_arbace_core_server_A_const_58 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[120]); A_arbace_core_server_A_const_59 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[121]); A_arbace_core_server_A_const_60 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[122]); A_arbace_core_server_A_const_61 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[123]) }

func A_arbace_core_server_A_clinit_p5() { A_arbace_core_server_A_const_62 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[124]); A_arbace_core_server_A_const_63 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[125]); A_arbace_core_server_A_const_64 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[126]); A_arbace_core_server_A_const_65 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[127]); A_arbace_core_server_A_const_66 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[128]); A_arbace_core_server_A_const_67 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[129]); A_arbace_core_server_A_const_68 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[130]); A_arbace_core_server_A_const_69 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[131]); A_arbace_core_server_A_const_70 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[132]); A_arbace_core_server_A_const_71 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[133]); A_arbace_core_server_A_const_72 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[134]); A_arbace_core_server_A_const_73 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[135]) }

func A_arbace_core_server_A_clinit_p6() { A_arbace_core_server_A_const_74 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[136]); A_arbace_core_server_A_const_75 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[137]); A_arbace_core_server_A_const_76 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[138]); A_arbace_core_server_A_const_77 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[139]); A_arbace_core_server_A_const_78 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[140]); A_arbace_core_server_A_const_79 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[141]); A_arbace_core_server_A_const_80 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[142]); A_arbace_core_server_A_const_81 = A_arbace_core_server_A_const_pool.A[143]; A_arbace_core_server_A_const_82 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[144]); A_arbace_core_server_A_const_83 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[145]); A_arbace_core_server_A_const_84 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[146]); A_arbace_core_server_A_const_85 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[147]) }

func A_arbace_core_server_A_clinit_p7() { A_arbace_core_server_A_const_86 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[148]); A_arbace_core_server_A_const_87 = A_arbace_core_server_A_const_pool.A[149]; A_arbace_core_server_A_const_88 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[150]); A_arbace_core_server_A_const_89 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[151]); A_arbace_core_server_A_const_90 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[152]); A_arbace_core_server_A_const_91 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[153]); A_arbace_core_server_A_const_92 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[154]); A_arbace_core_server_A_const_93 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[155]); A_arbace_core_server_A_const_94 = A_arbace_core_server_A_const_pool.A[156]; A_arbace_core_server_A_const_95 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[157]); A_arbace_core_server_A_const_96 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[158]); A_arbace_core_server_A_const_97 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[159]) }

func A_arbace_core_server_A_clinit_p8() { A_arbace_core_server_A_const_98 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[160]); A_arbace_core_server_A_const_99 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[161]); A_arbace_core_server_A_const_100 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[162]); A_arbace_core_server_A_const_101 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[163]); A_arbace_core_server_A_const_102 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[164]); A_arbace_core_server_A_const_103 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[165]); A_arbace_core_server_A_const_104 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[166]); A_arbace_core_server_A_const_105 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[167]); A_arbace_core_server_A_const_106 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[168]); A_arbace_core_server_A_const_107 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[169]); A_arbace_core_server_A_const_108 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[170]); A_arbace_core_server_A_const_109 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[171]) }

func A_arbace_core_server_A_clinit_p9() { A_arbace_core_server_A_const_110 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[172]); A_arbace_core_server_A_const_111 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[173]); A_arbace_core_server_A_const_112 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[174]); A_arbace_core_server_A_const_113 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[175]); A_arbace_core_server_A_const_114 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[176]); A_arbace_core_server_A_const_115 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[177]); A_arbace_core_server_A_const_116 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[178]); A_arbace_core_server_A_const_117 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[179]); A_arbace_core_server_A_const_118 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[180]); A_arbace_core_server_A_const_119 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[181]); A_arbace_core_server_A_const_120 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[182]); A_arbace_core_server_A_const_121 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[183]) }

func A_arbace_core_server_A_clinit_p10() { A_arbace_core_server_A_const_122 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[184]); A_arbace_core_server_A_const_123 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[185]); A_arbace_core_server_A_const_124 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[186]); A_arbace_core_server_A_const_125 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[187]); A_arbace_core_server_A_const_126 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[188]); A_arbace_core_server_A_const_127 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[189]); A_arbace_core_server_A_const_128 = jrt.Class_Cast(A_arbace_core_server_A_const_pool.A[190]); A_arbace_core_server_A_const_129 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[191]); A_arbace_core_server_A_const_130 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[192]); A_arbace_core_server_A_const_131 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[193]); A_arbace_core_server_A_const_132 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[194]); A_arbace_core_server_A_const_133 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[195]) }

func A_arbace_core_server_A_clinit_p11() { A_arbace_core_server_A_const_134 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[196]); A_arbace_core_server_A_const_135 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[197]); A_arbace_core_server_A_const_136 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[198]); A_arbace_core_server_A_const_137 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[199]); A_arbace_core_server_A_const_138 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[200]); A_arbace_core_server_A_const_139 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[201]); A_arbace_core_server_A_const_140 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[202]); A_arbace_core_server_A_const_141 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[203]); A_arbace_core_server_A_const_142 = A_arbace_core_server_A_const_pool.A[204]; A_arbace_core_server_A_const_143 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[205]); A_arbace_core_server_A_const_144 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[206]); A_arbace_core_server_A_const_145 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[207]) }

func A_arbace_core_server_A_clinit_p12() { A_arbace_core_server_A_const_146 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[208]); A_arbace_core_server_A_const_147 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[209]); A_arbace_core_server_A_const_148 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[210]); A_arbace_core_server_A_const_149 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[211]); A_arbace_core_server_A_const_150 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[212]); A_arbace_core_server_A_const_151 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[213]); A_arbace_core_server_A_const_152 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[214]); A_arbace_core_server_A_const_153 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[215]); A_arbace_core_server_A_const_154 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[216]); A_arbace_core_server_A_const_155 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[217]); A_arbace_core_server_A_const_156 = A_arbace_core_server_A_const_pool.A[218]; A_arbace_core_server_A_const_157 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[219]) }

func A_arbace_core_server_A_clinit_p13() { A_arbace_core_server_A_const_158 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[220]); A_arbace_core_server_A_const_159 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[221]); A_arbace_core_server_A_const_160 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[222]); A_arbace_core_server_A_const_161 = A_arbace_core_server_A_const_pool.A[223]; A_arbace_core_server_A_const_162 = A_arbace_core_server_A_const_pool.A[224]; A_arbace_core_server_A_const_163 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[225]) }

func A_arbace_core_server_A_New() *A_arbace_core_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_A) Ctor() {}

func (t *A_arbace_core_server_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_A_class }

func (t *A_arbace_core_server_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_A); return ok }

func A_arbace_core_server_A_Cast(x any) *A_arbace_core_server_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_A_class)) }; return v }



type A_arbace_core_server_accept_connection_A struct{ j2g_header uint64 }

var A_arbace_core_server_accept_connection_A_fn_class *jrt.Class



type A_arbace_core_server_accept_connection_fn__1213000038_A struct{ j2g_header uint64; F_name, F_client_id, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class *jrt.Class



type A_arbace_core_server_accept_connection_fn__1213000040_A struct{ j2g_header uint64; F_name, F_client_id, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class *jrt.Class



type A_arbace_core_server_eval1213000004_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000004_A_New() *A_arbace_core_server_eval1213000004_A { t := &A_arbace_core_server_eval1213000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000004_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000004_A_class }

func (t *A_arbace_core_server_eval1213000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000004_A); return ok }

func A_arbace_core_server_eval1213000004_A_Cast(x any) *A_arbace_core_server_eval1213000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000004_A_class)) }; return v }



type A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A struct{ j2g_header uint64 }

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class *jrt.Class



type A_arbace_core_server_eval1213000008_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000008_A_New() *A_arbace_core_server_eval1213000008_A { t := &A_arbace_core_server_eval1213000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000008_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000008_A_class }

func (t *A_arbace_core_server_eval1213000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000008_A); return ok }

func A_arbace_core_server_eval1213000008_A_Cast(x any) *A_arbace_core_server_eval1213000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000008_A_class)) }; return v }



type A_arbace_core_server_eval1213000008_fn__1213000009_A struct{ j2g_header uint64 }

var A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class *jrt.Class



type A_arbace_core_server_ex__GT_data_A struct{ j2g_header uint64 }

var A_arbace_core_server_ex__GT_data_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_io_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_fn__1213000112_A struct{ j2g_header uint64; F_lock, F_out, F_valf any }

var A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A struct{ j2g_header uint64; F_m, F_valf any }

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class *jrt.Class



type A_arbace_core_server_parse_props_A struct{ j2g_header uint64 }

var A_arbace_core_server_parse_props_A_fn_class *jrt.Class



type A_arbace_core_server_parse_props_fn__1213000072_A struct{ j2g_header uint64; F_props any }

var A_arbace_core_server_parse_props_fn__1213000072_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000096_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_fn__1213000096_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000098_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_fn__1213000098_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000100_A struct{ j2g_header uint64; F_EOF, F_out_fn, F_in_reader any }

var A_arbace_core_server_prepl_fn__1213000100_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_tapfn__1213000094_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_remote_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A struct{ j2g_header uint64 }

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_fn__1213000128_A struct{ j2g_header uint64; F_rd, F_readf, F_wr, F_EOF, F_out_fn, F_valf any }

var A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A struct{ j2g_header uint64; F_m, F_valf, F_val any }

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class *jrt.Class



type A_arbace_core_server_repl_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_A_fn_class *jrt.Class



type A_arbace_core_server_repl_init_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_init_A_fn_class *jrt.Class



type A_arbace_core_server_repl_read_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_read_A_fn_class *jrt.Class



type A_arbace_core_server_required_A struct{ j2g_header uint64 }

var A_arbace_core_server_required_A_fn_class *jrt.Class



type A_arbace_core_server_resolve_fn_A struct{ j2g_header uint64 }

var A_arbace_core_server_resolve_fn_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_A struct{ j2g_header uint64 }

var A_arbace_core_server_start_server_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000049_A struct{ j2g_header uint64; F_name, F_socket, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_start_server_fn__1213000049_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_A struct{ j2g_header uint64; F_name, F_socket, F_client_daemon, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A struct{ j2g_header uint64; F_name, F_socket any; F_client_counter int64; F_client_daemon, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A struct{ j2g_header uint64; F_in, F_name, F_client_id, F_conn, F_out, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A struct{ j2g_header uint64; F_lockee__1213000018__auto__, F_name any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class *jrt.Class



type A_arbace_core_server_start_servers_A struct{ j2g_header uint64 }

var A_arbace_core_server_start_servers_A_fn_class *jrt.Class



type A_arbace_core_server_stop_server_A struct{ j2g_header uint64 }

var A_arbace_core_server_stop_server_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_A struct{ j2g_header uint64 }

var A_arbace_core_server_stop_servers_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_fn__1213000067_A struct{ j2g_header uint64; F_name any }

var A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_fn__1213000069_A struct{ j2g_header uint64; F_name any }

var A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class *jrt.Class



type A_arbace_core_server_thread_A struct{ j2g_header uint64 }

var A_arbace_core_server_thread_A_fn_class *jrt.Class



type A_arbace_core_server_validate_opts_A struct{ j2g_header uint64 }

var A_arbace_core_server_validate_opts_A_fn_class *jrt.Class



type A_arbace_core_server_with_lock_A struct{ j2g_header uint64 }

var A_arbace_core_server_with_lock_A_fn_class *jrt.Class
