//line aot_arbace_core_server.ae:1
package aot_arbace_core_server

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_edn"
	"arbace/aot_arbace_main"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :9:1
func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_New() *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_core_server_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_1); lang.IFn_Cast(A_arbace_core_server_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_server_A_const_3, A_arbace_core_server_A_const_4, A_arbace_core_server_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_server_eval1213000008_fn__1213000009_A_New() *A_arbace_core_server_eval1213000008_fn__1213000009_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_eval1213000008_fn__1213000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_6.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_core_server_A_const_7.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_core_server_A_const_8; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core_server_A_const_9.GetRawRoot__O(), A_arbace_core_server_A_const_10) }




















func A_arbace_core_server_with_lock_A_New() *A_arbace_core_server_with_lock_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_with_lock_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_core_server_with_lock_A) Ctor() {}
//line :30:1
func (t *A_arbace_core_server_with_lock_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, lock_expr__2, body__3 any) any { var root_84 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_14); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp4 any; var root_35 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = A_arbace_core_server_A_const_16.GetRawRoot__O(); var arg_39 any; var root_31 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var root_26 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17); var arg_30 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp6 any; var root_21 any = A_arbace_core_server_A_const_18.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_23 lang.IFn; if

	linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = lock_expr__2; var arg_25 any = A_arbace_core_server_A_const_19; if linked_22 == nil { tmp6 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp6 = linked_22.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; arg_30 = /*line :30:1*/tmp5.Invoke_O__O(tmp6); if linked_27 == nil { arg_34 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_34 = linked_27.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_32 == nil { arg_39 = ifn_33.Invoke_O__O(arg_34) } else { arg_39 = linked_32.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_31, arg_34) }; if linked_36 == nil { tmp4 = ifn_37.Invoke_O_O__O(arg_38, arg_39) } else { tmp4 = linked_36.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_35, arg_38, arg_39) }; var tmp7 any = tmp3.Invoke_O__O(tmp4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp9 any; var root_45 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any; var root_40 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_20); var arg_44 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17); if linked_41 == nil { arg_48 = ifn_42.Invoke_O_O__O(arg_43, arg_44) } else { arg_48 = linked_41.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_40, arg_43, arg_44) }; if linked_46 == nil { tmp9 = ifn_47.Invoke_O__O(arg_48) } else { tmp9 = linked_46.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_45, arg_48) }; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp12 any; var root_73 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_21); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp16 any; var root_63 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var root_58 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_22); var arg_62 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp18 any; var root_54 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any; var root_49 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_23); var arg_53 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17); if linked_50 == nil { arg_57 = ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { arg_57 = linked_50.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }; if linked_55 == nil { tmp18 = ifn_56.Invoke_O__O(arg_57) } else { tmp18 = linked_55.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_54, arg_57) }; arg_62 = tmp17.Invoke_O__O(tmp18); if linked_59 == nil { arg_66 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { arg_66 = linked_59.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; if linked_64 == nil { tmp16 = ifn_65.Invoke_O__O(arg_66) } else { tmp16 = linked_64.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_63, arg_66) }; arg_76 = tmp13.Invoke_O_O_O__O(tmp14, body__3, tmp15.Invoke_O__O(tmp16)); if linked_74 == nil { tmp12 = ifn_75.Invoke_O__O(arg_76) } else { tmp12 = linked_74.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_73, arg_76) }; arg_87 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp7, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_85 == nil { return ifn_86.Invoke_O__O(arg_87) } else { return linked_85.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_84, arg_87) } }








func A_arbace_core_server_thread_A_New() *A_arbace_core_server_thread_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_thread_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_core_server_thread_A) Ctor() {}
//line :39:1
func (t *A_arbace_core_server_thread_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, daemon__3, body__4 any) any { var root_144 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_24); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp4 any; var root_116 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_25); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp8 any; var root_106 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_26); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp12 any; var root_95 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = A_arbace_core_server_A_const_16.GetRawRoot__O(); var arg_99 any; var root_91 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any; var root_88 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; if linked_89 == nil { arg_94 = ifn_90.Invoke__O() } else { arg_94 = linked_89.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_88) }; if linked_92 == nil { arg_99 = ifn_93.Invoke_O__O(arg_94) } else { arg_99 = linked_92.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_91, arg_94) }; if linked_96 == nil { tmp12 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { tmp12 = linked_96.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }; arg_109 = tmp9.Invoke_O_O_O__O(tmp10, tmp11.Invoke_O__O(tmp12), body__4); if linked_107 == nil { tmp8 = ifn_108.Invoke_O__O(arg_109) } else { tmp8 = linked_107.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_106, arg_109) }; arg_119 = tmp5.Invoke_O_O_O__O(tmp6, tmp7.Invoke_O__O(tmp8), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2)); if linked_117 == nil { tmp4 = ifn_118.Invoke_O__O(arg_119) } else { tmp4 = linked_117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_116, arg_119) }; var tmp13 any = tmp3.Invoke_O__O(tmp4); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp15 any; var root_125 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any; var root_120 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_27); var arg_124 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(daemon__3); if linked_121 == nil { arg_128 = ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { arg_128 = linked_121.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) }; if linked_126 == nil { tmp15 = ifn_127.Invoke_O__O(arg_128) } else { tmp15 = linked_126.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_125, arg_128) }; var tmp16 any = tmp14.Invoke_O__O(tmp15); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp18 any; var root_133 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var root_129 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_28); if linked_130 == nil { arg_136 = ifn_131.Invoke_O__O(arg_132) } else { arg_136 = linked_130.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_129, arg_132) }; if linked_134 == nil { tmp18 = ifn_135.Invoke_O__O(arg_136) } else { tmp18 = linked_134.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_133, arg_136) }; arg_147 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp13, tmp16, tmp17.Invoke_O__O(tmp18)); if linked_145 == nil { return ifn_146.Invoke_O__O(arg_147) } else { return linked_145.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_144, arg_147) } }





func A_arbace_core_server_required_A_New() *A_arbace_core_server_required_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_required_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_core_server_required_A) Ctor() {}
//line :45:1
func (t *A_arbace_core_server_required_A) Invoke_O_O_O__O(self, opts__0, prop__1 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(opts__0, prop__1), nil) { var tmp1 any; var root_148 any = A_arbace_core_server_A_const_29.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_150 lang.IFn
		if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, prop__1)).Ref(); var arg_152 any = opts__0; if linked_149 == nil { tmp1 = ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { tmp1 = linked_149.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }
//line :48:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } else { return nil
		}
}
func A_arbace_core_server_validate_opts_A_New() *A_arbace_core_server_validate_opts_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_validate_opts_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Invoke_O_O__O(self, p__1213000030__0 any) any { var map__1213000031__2 any = p__1213000030__0; var map__1213000031__3 any; if lang.ISeq_InstanceOf(map__1213000031__2) { var tmp1 any; var root_153 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = map__1213000031__2; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_153, arg_156) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_157 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = map__1213000031__2; if linked_158 == nil { tmp2 = ifn_159.Invoke_O__O(arg_160) } else { tmp2 = linked_158.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_157, arg_160) }; map__1213000031__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_161 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = map__1213000031__2; if linked_162 == nil { tmp3 = ifn_163.Invoke_O__O(arg_164) } else { tmp3 = linked_162.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_161, arg_164) }; if jrt.J2g_Truth(tmp3) { var root_165 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = map__1213000031__2; if linked_166 == nil { map__1213000031__3 = ifn_167.Invoke_O__O(arg_168) } else { map__1213000031__3 = linked_166.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_165, arg_168) } } else { map__1213000031__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000031__3 = map__1213000031__2 }; var opts__4 any = map__1213000031__3; var name__5 any = lang.RT_Get_O_O__O_NoInit(map__1213000031__3, A_arbace_core_server_A_const_33); var port__6 any = lang.RT_Get_O_O__O_NoInit(map__1213000031__3, A_arbace_core_server_A_const_34); var accept__7 any = lang.RT_Get_O_O__O_NoInit(map__1213000031__3, A_arbace_core_server_A_const_35); var seq_1213000033__8 any; var root_192 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_194 lang.IFn; _ = name__5; _ = accept__7; if


	linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = A_arbace_core_server_A_const_41; if linked_193 == nil { seq_1213000033__8 = ifn_194.Invoke_O__O(arg_195) } else { seq_1213000033__8 = linked_193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_192, arg_195) }; var chunk_1213000034__9 any; var count_1213000035__10 int64 = 0; var i_1213000036__11 int64 = 0; L1:
//line :51:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_1213000036__11, count_1213000035__10) { var prop__12 any = lang.Indexed_Cast(chunk_1213000034__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1213000036__11)); var root_212 any = A_arbace_core_server_A_const_44.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_core_server_required_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = opts__4; var arg_216 any = prop__12; if linked_213 == nil { ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { linked_213.(*A_arbace_core_server_required_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) }; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1213000036__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_196 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = seq_1213000033__8; if linked_197 == nil { temp__1927000414__auto____12 = ifn_198.Invoke_O__O(arg_199) } else { temp__1927000414__auto____12 = linked_197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_196, arg_199) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1213000033__13 any = temp__1927000414__auto____12; var tmp4 any; var root_200 any = A_arbace_core_server_A_const_42.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = seq_1213000033__13; if linked_201 == nil { tmp4 = ifn_202.Invoke_O__O(arg_203) } else { tmp4 = linked_201.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_204 any = A_arbace_core_server_A_const_43.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = seq_1213000033__13; if linked_205 == nil { c__1927000678__auto____14 = ifn_206.Invoke_O__O(arg_207) } else { c__1927000678__auto____14 = linked_205.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_204, arg_207) }; var tmp5 any; var root_217 any = A_arbace_core_server_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1213000033__13; if linked_218 == nil { tmp5 = ifn_219.Invoke_O__O(arg_220) } else { tmp5 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var prop__14 any; var root_208 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = seq_1213000033__13; if linked_209 == nil { prop__14 = ifn_210.Invoke_O__O(arg_211) } else { prop__14 = linked_209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_208, arg_211) }; var root_221 any = A_arbace_core_server_A_const_44.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, A_arbace_core_server_required_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = opts__4; var arg_225 any = prop__14; if linked_222 == nil { ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { linked_222.(*A_arbace_core_server_required_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }; var tmp6 any; var root_226 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = seq_1213000033__13; if linked_227 == nil { tmp6 = ifn_228.Invoke_O__O(arg_229) } else { tmp6 = linked_227.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_226, arg_229) }; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = tmp6, nil, 0, 0; continue L1 } } }
//line :51:1
		break L1 }; var tmp7 any; var or__1927000174__auto____8 any; var root_173 any =



	A_arbace_core_server_A_const_36.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_169 any = A_arbace_core_server_A_const_37.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = port__6; if linked_170 == nil { arg_176 = ifn_171.Invoke_O__O(arg_172) } else { arg_176 = linked_170.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_169, arg_172) }; if linked_174 == nil { or__1927000174__auto____8 = ifn_175.Invoke_O__O(arg_176) } else { or__1927000174__auto____8 = linked_174.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp7 = or__1927000174__auto____8 } else { var root_183 any = A_arbace_core_server_A_const_36.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = lang.IFn_Cast(A_arbace_core_server_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_server_A_const_39, port__6, A_arbace_core_server_A_const_40); if linked_184 == nil { tmp7 = ifn_185.Invoke_O__O(arg_186) } else { tmp7 = linked_184.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_183, arg_186) } }; if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_187 any = A_arbace_core_server_A_const_29.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_189 lang.IFn
		if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, port__6)).Ref(); var arg_191 any = opts__4; if linked_188 == nil { tmp8 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { tmp8 = linked_188.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }
//line :55:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp8))) } else { return nil } }


func A_arbace_core_server_accept_connection_A_New() *A_arbace_core_server_accept_connection_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Ctor() {}
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Invoke_O_O_O_O_O_O_O_O_O__O(self, conn__0, name__1, client_id__2, in__3, out__4, err__5, accept__6, args__7 any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











	{ var root_253 any = A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_50; var tmp4 any = A_arbace_core_server_A_const_51; var tmp5 any = A_arbace_core_server_A_const_52; var tmp6 any = A_arbace_core_server_A_const_53; var arg_256 any = tmp2.Invoke_O_O_O_O_O_O_O_O__O(tmp3, in__3, tmp4, out__4, tmp5, err__5, tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_54, name__1, A_arbace_core_server_A_const_55, client_id__2))); if linked_254 == nil { ifn_255.Invoke_O__O(arg_256) } else { linked_254.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_253, arg_256) }; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :58:1
		{ var lockee__1213000018__auto____13 any = A_arbace_core_server_A_const_56.GetRawRoot__O()















			jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____13)).Lock__V(); var tmp7 any = A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____13); var tmp8 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class = fncls__264d; tmp8 = fncls__264d } else { tmp8 = fncls__264 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()

			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_2.GetRawRoot__O()); var tmp10 any; var root_269 any = A_arbace_core_server_A_const_61.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any; var root_265 any = A_arbace_core_server_A_const_62.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = accept__6; if linked_266 == nil { arg_272 = ifn_267.Invoke_O__O(arg_268) } else { arg_272 = linked_266.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_265, arg_268) }; if linked_270 == nil { tmp10 = ifn_271.Invoke_O__O(arg_272) } else { tmp10 = linked_270.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_269, arg_272) }; tmp9.Invoke_O__O(tmp10)
//line :58:1
			var accept_fn__13 any; var root_230 any = A_arbace_core_server_A_const_46.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_232 lang.IFn


















			if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = accept__6; if linked_231 == nil { accept_fn__13 = ifn_232.Invoke_O__O(arg_233) } else { accept_fn__13 = linked_231.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_230, arg_233) }
			var root_234 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = accept_fn__13; var arg_238 any = args__7; if linked_235 == nil { tmp1 = ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { tmp1 = linked_235.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_234, arg_237, arg_238) } }
//line :70:1
		return nil }(); var root_239 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; if linked_240 == nil { ifn_241.Invoke__O() } else { linked_240.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_239) }
//line :58:1
		if tmp11 != nil { panic(tmp11) } }; return nil }(); if tmp12 != nil { if jrt.SocketException_InstanceOf(tmp12) { var _disconnect__11 jrt.SocketException_I = jrt.SocketException_Cast(tmp12); _ = _disconnect__11; tmp1 = nil } else { panic(tmp12) } } }; return nil }(); var lockee__1213000018__auto____11 any = A_arbace_core_server_A_const_56.GetRawRoot__O();






















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____11)).Lock__V(); var tmp14 any = A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____11); var tmp15 *jrt.Class; var fncls__285 *jrt.Class = A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class; if fncls__285 == nil { var fncls__285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class = fncls__285d; tmp15 = fncls__285d } else { tmp15 = fncls__285 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O();

	jrt.Socket_Cast(conn__0).Close__V(); if /*line :58:1*/ tmp13 != nil { panic(tmp13) }; return tmp1 }















func A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000038_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000038_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_59.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; var tmp6 any = tmp5; var tmp7 any = A_arbace_core_server_A_const_60; var tmp8 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp7, tmp8), lang.PersistentArrayMap_EMPTY.Ref()) }
//line :74:1
	return nil }(); var tmp10 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp10 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp10)).Unlock__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }






func A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000040_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000040_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_63.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(tmp5, A_arbace_core_server_A_const_60); var tmp7 any = A_arbace_core_server_A_const_64.GetRawRoot__O(); var tmp8 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp6, tmp7, tmp8) }
//line :81:1
	return nil }(); var tmp10 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp10 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp10)).Unlock__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }



func A_arbace_core_server_start_server_A_New() *A_arbace_core_server_start_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_core_server_start_server_A) Ctor() {}
//line :85:1
func (t *A_arbace_core_server_start_server_A) Invoke_O_O__O(self, opts__0 any) any {











	var root_302 any = A_arbace_core_server_A_const_70.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, A_arbace_core_server_validate_opts_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = opts__0; if linked_303 == nil { ifn_304.Invoke_O__O(arg_305) } else { linked_303.(*A_arbace_core_server_validate_opts_A).Invoke_O_O__O(root_302, arg_305) }
//line :85:1
	var default__1213000045__2 any = jrt.Boolean_TRUE.Ref(); var default__1213000046__3 any = jrt.Boolean_TRUE.Ref(); var default__1213000047__4 any = jrt.Boolean_TRUE.Ref(); var map__1213000043__5 any = opts__0; var map__1213000043__6 any












	if lang.ISeq_InstanceOf(map__1213000043__5) { var tmp1 any; var root_286 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = map__1213000043__5; if linked_287 == nil { tmp1 = ifn_288.Invoke_O__O(arg_289) } else { tmp1 = linked_287.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_290 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = map__1213000043__5; if linked_291 == nil { tmp2 = ifn_292.Invoke_O__O(arg_293) } else { tmp2 = linked_291.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_290, arg_293) }; map__1213000043__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_294 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = map__1213000043__5; if linked_295 == nil { tmp3 = ifn_296.Invoke_O__O(arg_297) } else { tmp3 = linked_295.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_294, arg_297) }; if jrt.J2g_Truth(tmp3) { var root_298 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = map__1213000043__5; if linked_299 == nil { map__1213000043__6 = ifn_300.Invoke_O__O(arg_301) } else { map__1213000043__6 = linked_299.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_298, arg_301) } } else { map__1213000043__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000043__6 = map__1213000043__5 }
//line :85:1
	var address__7 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_65); var port__8 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_34); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_33); var accept__10 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_35); var args__11 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_66); var bind_err__12 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_67, default__1213000045__2); var server_daemon__13 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_68, default__1213000046__3); var client_daemon__14 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_69, default__1213000047__4); var address__15 any = jrt.InetAddress_GetByName_String__InetAddress(jrt.String_Cast(address__7)); var socket__16 any = jrt.ServerSocket_New_I_I_InetAddress(lang.RT_IntCast_O__I_NoInit(port__8), lang.RT_IntCast_J__I_NoInit(0), jrt.InetAddress_Cast(address__15)); var lockee__1213000018__auto____17 any = A_arbace_core_server_A_const_56.GetRawRoot__O()


















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____17)).Lock__V(); var tmp4 any = A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(name__9, socket__16, lockee__1213000018__auto____17); var tmp5 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_core_server_start_server_fn__1213000049_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_core_server_start_server_fn__1213000049_A_fn_class = fncls__313d; tmp5 = fncls__313d } else { tmp5 = fncls__313 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :85:1
	var G__1213000051__17_ any; var tmp6 any = A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(name__9, socket__16, client_daemon__14, args__11, bind_err__12, accept__10); var tmp7 *jrt.Class
	var fncls__342 /*line :85:1*/*jrt.Class = A_arbace_core_server_start_server_fn__1213000052_A_fn_class




















	if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_core_server_start_server_fn__1213000052_A_fn_class = fncls__342d; tmp7 = fncls__342d } else { tmp7 = fncls__342 }
//line :85:1
	G__1213000051__17_ = jrt.Thread_New_Runnable_String(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__9)))




















	jrt.Thread_Cast(G__1213000051__17_).SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(server_daemon__13)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000051__17_).Start__V()
//line :85:1
	return socket__16
}

















func A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_start_server_fn__1213000049_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000049_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Ctor_O_O_O(c__name, c__socket, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_socket = c__socket; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var tmp5 any = t.F_name; var tmp6 any = A_arbace_core_server_A_const_33; var tmp7 any; var t_ any = t.F_name; t.F_name = nil; tmp7 = t_; var tmp8 any = tmp7; var tmp9 any = A_arbace_core_server_A_const_72; var tmp10 any; var t__2 any = t.F_socket; t.F_socket = nil; tmp10 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp10, A_arbace_core_server_A_const_60, lang.PersistentArrayMap_EMPTY.Ref()))) }
//line :104:1
	return nil }(); var tmp12 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp12 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp12)).Unlock__V(); if tmp11 != nil { panic(tmp11) }; return tmp1 }

func A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_start_server_fn__1213000052_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Ctor_O_O_O_O_O_O(c__name, c__socket, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var client_counter__3 int64 = 1; L1: for {



	var tmp2 any; var root_314 any = A_arbace_core_server_A_const_36.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ServerSocket_Cast(t.F_socket)).IsClosed__Z()).Ref(); if linked_315 == nil { tmp2 = ifn_316.Invoke_O__O(arg_317) } else { tmp2 = linked_315.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_314, arg_317) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(t.F_name, t.F_socket, client_counter__3, t.F_client_daemon, t.F_args, t.F_bind_err, t.F_accept); var tmp4 *jrt.Class; var fncls__341 *jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class; if fncls__341 == nil { var fncls__341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class = fncls__341d; tmp4 = fncls__341d } else { tmp4 = fncls__341 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()








		client_counter__3 = lang.Numbers_Inc_J__J_NoInit(client_counter__3); continue L1 } else {
//line :110:1
			tmp1 = nil }
//line :106:1
	break L1 } }; return nil }(); var lockee__1213000018__auto____3 any = A_arbace_core_server_A_const_56.GetRawRoot__O();















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____3)).Lock__V(); var tmp6 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(lockee__1213000018__auto____3, t.F_name); var tmp7 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class = fncls__324d; tmp7 = fncls__324d } else { tmp7 = fncls__324 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O(); if /*line :106:1*/ tmp5 != nil { panic(tmp5) }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(p0, p1 any, p2 int64, p3, p4, p5, p6 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A{}; t.Ctor_O_O_J_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Ctor_O_O_J_O_O_O_O(c__name, c__socket any, c__client_counter int64, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_counter = c__client_counter; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var conn__3 any; var tmp2 any; var t_ any = t.F_socket
													t.F_socket = nil; tmp2 = t_; conn__3 = jrt.NN(jrt.ServerSocket_Cast(tmp2)).Accept__Socket()
//line :111:1
	var in__4 any = lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(conn__3).GetInputStream__InputStream())); var out__5 any = jrt.BufferedWriter_New_Writer(jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(conn__3).GetOutputStream__OutputStream())); var client_id__6 any; var root_325 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_327 lang.IFn



	if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = jrt.Long_ValueOf_J__Long_NoInit(t.F_client_counter).Ref(); if linked_326 == nil { client_id__6 = ifn_327.Invoke_O__O(arg_328) } else { client_id__6 = linked_326.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_325, arg_328) }
//line :111:1
	var G__1213000054__7_ any; var tmp3 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(in__4, t.F_name, client_id__6, conn__3, out__5, t.F_args, t.F_bind_err, t.F_accept); var tmp4 *jrt.Class
	var fncls__340 /*line :111:1*/*jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class




	if fncls__340 == nil { var fncls__340d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class = fncls__340d; tmp4 = fncls__340d } else { tmp4 = fncls__340 }
//line :111:1
	var tmp5 jrt.Runnable = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp7 any; var t__2 any = t.F_name





	t.F_name = nil; tmp7 = t__2
//line :111:1
	G__1213000054__7_ = jrt.Thread_New_Runnable_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, client_id__6)))




	var tmp8 jrt.Thread_I = jrt.Thread_Cast(G__1213000054__7_); var tmp9 any; var t__3 any = t.F_client_daemon; t.F_client_daemon = nil; tmp9 = t__3; tmp8.SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(tmp9)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000054__7_).Start__V()
//line :111:1
	tmp1 = G__1213000054__7_ }; return nil }(); if tmp10 != nil { if jrt.SocketException_InstanceOf(tmp10) { var _disconnect__3 jrt.SocketException_I = jrt.SocketException_Cast(tmp10); _ = _disconnect__3; tmp1 = nil } else { panic(tmp10) } }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Ctor_O_O_O_O_O_O_O_O(c__in, c__name, c__client_id, c__conn, c__out, c__args, c__bind_err, c__accept any) { t.F_in = c__in; t.F_name = c__name; t.F_client_id = c__client_id; t.F_conn = c__conn; t.F_out = c__out; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Invoke_O__O(self any) any {

	var root_329 any = A_arbace_core_server_A_const_74.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, A_arbace_core_server_accept_connection_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = t.F_conn; var arg_333 any = t.F_name; var arg_334 any = t.F_client_id; var arg_335 any = t.F_in; var arg_336 any = t.F_out; var arg_337 any; if jrt.J2g_Truth(t.F_bind_err) { arg_337 = t.F_out } else { arg_337 = A_arbace_core_server_A_const_52.Get__O() }; var arg_338 any = t.F_accept; var arg_339 any = t.F_args; if linked_330 == nil { return ifn_331.Invoke_O_O_O_O_O_O_O_O__O(arg_332, arg_333, arg_334, arg_335, arg_336, arg_337, arg_338, arg_339) } else { return linked_330.(*A_arbace_core_server_accept_connection_A).Invoke_O_O_O_O_O_O_O_O_O__O(root_329, arg_332, arg_333, arg_334, arg_335, arg_336, arg_337, arg_338, arg_339)
	}
}

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(p0, p1 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A{}; t.Ctor_O_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Ctor_O_O(c__lockee__1213000018__auto__, c__name any) { t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__; t.F_name = c__name }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_64.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; tmp1 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5) }
//line :122:1
	return nil }(); var tmp7 any; var t__2 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp7 = t__2; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp7)).Unlock__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }



func A_arbace_core_server_stop_server_A_New() *A_arbace_core_server_stop_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_server_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Ctor() {}
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O_O__O(self, name__0 any) any { var lockee__1213000018__auto____2 any = A_arbace_core_server_A_const_56.GetRawRoot__O();






	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Lock__V(); var tmp1 any; tmp4 := /*line :126:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var server_socket__5 any; var root_343 any = A_arbace_core_server_A_const_75.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_345 lang.IFn







		if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_core_server_A_const_58.GetRawRoot__O(); var arg_347 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, A_arbace_core_server_A_const_72); if linked_344 == nil { server_socket__5 = ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { server_socket__5 = linked_344.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) }
		if jrt.J2g_Truth(server_socket__5) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; tmp2.Invoke_O_O_O__O(tmp3, A_arbace_core_server_A_const_64.GetRawRoot__O(), name__0)
			jrt.NN(jrt.ServerSocket_Cast(server_socket__5)).Close__V()
//line :135:1
			tmp1 = jrt.Boolean_TRUE.Ref() } else { tmp1 = nil } }; return nil }(); /*line :133:1*/jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Unlock__V(); if /*line :126:1*/ tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O__O(self any) any {




	var root_354 any = A_arbace_core_server_A_const_76.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, A_arbace_core_server_stop_server_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var tmp1 *lang.Keyword = A_arbace_core_server_A_const_54; var arg_357 any = tmp1.Invoke_O__O(A_arbace_core_server_A_const_53.Get__O()); if linked_355 == nil { return ifn_356.Invoke_O__O(arg_357) } else { return linked_355.(*A_arbace_core_server_stop_server_A).Invoke_O_O__O(root_354, arg_357)
	}
}






func A_arbace_core_server_stop_servers_A_New() *A_arbace_core_server_stop_servers_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Ctor() {}
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Invoke_O__O(self any) any { var lockee__1213000018__auto____1 any = A_arbace_core_server_A_const_56.GetRawRoot__O();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Lock__V(); var tmp1 any; tmp9 := /*line :140:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1213000063__4 any; var root_362 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_364 lang.IFn



		if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var root_358 any = A_arbace_core_server_A_const_77.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_core_server_A_const_58.GetRawRoot__O(); if linked_359 == nil { arg_365 = ifn_360.Invoke_O__O(arg_361) } else { arg_365 = linked_359.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_358, arg_361) }; if linked_363 == nil { seq_1213000063__4 = ifn_364.Invoke_O__O(arg_365) } else { seq_1213000063__4 = linked_363.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_362, arg_365) }
//line :140:1
		var chunk_1213000064__5 any; var count_1213000065__6 int64 = 0; var i_1213000066__7 int64 = 0; L1: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(i_1213000066__7, count_1213000065__6) { var name__8 any = lang.Indexed_Cast(chunk_1213000064__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1213000066__7)); var root_387 any = A_arbace_core_server_A_const_78.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_389 lang.IFn
				if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var tmp2 any = A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(name__8); var tmp3 *jrt.Class; var fncls__386 *jrt.Class = A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class; if fncls__386 == nil { var fncls__386d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class = fncls__386d; tmp3 = fncls__386d } else { tmp3 = fncls__386 }; arg_390 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_388 == nil { ifn_389.Invoke_O__O(arg_390) } else { linked_388.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_387, arg_390) }
//line :144:1
				seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1213000066__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_366 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = seq_1213000063__4; if linked_367 == nil { temp__1927000414__auto____8 = ifn_368.Invoke_O__O(arg_369) } else { temp__1927000414__auto____8 = linked_367.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_366, arg_369) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1213000063__9 any = temp__1927000414__auto____8; var tmp4 any; var root_370 any = A_arbace_core_server_A_const_42.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = seq_1213000063__9; if linked_371 == nil { tmp4 = ifn_372.Invoke_O__O(arg_373) } else { tmp4 = linked_371.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_370, arg_373) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____10 any; var root_374 any = A_arbace_core_server_A_const_43.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1213000063__9; if linked_375 == nil { c__1927000678__auto____10 = ifn_376.Invoke_O__O(arg_377) } else { c__1927000678__auto____10 = linked_375.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_374, arg_377) }; var tmp5 any; var root_391 any = A_arbace_core_server_A_const_45.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = seq_1213000063__9; if linked_392 == nil { tmp5 = ifn_393.Invoke_O__O(arg_394) } else { tmp5 = linked_392.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_391, arg_394) }; seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = tmp5, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var name__10 any; var root_378 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = seq_1213000063__9; if linked_379 == nil { name__10 = ifn_380.Invoke_O__O(arg_381) } else { name__10 = linked_379.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_378, arg_381) }
					var root_400 any = A_arbace_core_server_A_const_78.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any; var tmp6 any = A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(name__10); var tmp7 *jrt.Class; var fncls__399 *jrt.Class = A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class; if fncls__399 == nil { var fncls__399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class = fncls__399d; tmp7 = fncls__399d } else { tmp7 = fncls__399 }; arg_403 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_401 == nil { ifn_402.Invoke_O__O(arg_403) } else { linked_401.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_400, arg_403) }
//line :144:1
					var tmp8 any; var root_404 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = seq_1213000063__9; if linked_405 == nil { tmp8 = ifn_406.Invoke_O__O(arg_407) } else { tmp8 = linked_405.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_404, arg_407) }; seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = tmp8, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :140:1
			break L1 } }; return nil }();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Unlock__V(); if /*line :140:1*/ tmp9 != nil { panic(tmp9) }; return tmp1 }




func A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000067_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000067_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Invoke_O__O(self any) any { var root_382 any = A_arbace_core_server_A_const_76.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, A_arbace_core_server_stop_server_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var t_ any = t.F_name; t.F_name = nil; arg_385 = t_; if linked_383 == nil { return ifn_384.Invoke_O__O(arg_385) } else { return linked_383.(*A_arbace_core_server_stop_server_A).Invoke_O_O__O(root_382, arg_385) } }
//line :145:1
func A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000069_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000069_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Invoke_O__O(self any) any { var root_395 any = A_arbace_core_server_A_const_76.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_core_server_stop_server_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var t_ any = t.F_name; t.F_name = nil; arg_398 = t_; if linked_396 == nil { return ifn_397.Invoke_O__O(arg_398) } else { return linked_396.(*A_arbace_core_server_stop_server_A).Invoke_O_O__O(root_395, arg_398) } }

func A_arbace_core_server_parse_props_A_New() *A_arbace_core_server_parse_props_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_parse_props_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Ctor() {}
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Invoke_O_O__O(self, props__0 any) any {


	var root_428 any = A_arbace_core_server_A_const_79.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any; var tmp1 any = A_arbace_core_server_parse_props_fn__1213000072_A_New_O(props__0); var tmp2 *jrt.Class; var fncls__427 *jrt.Class = A_arbace_core_server_parse_props_fn__1213000072_A_fn_class
	if fncls__427 == nil { var fncls__427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_core_server_parse_props_fn__1213000072_A_fn_class = fncls__427d; tmp2 = fncls__427d } else { tmp2 = fncls__427 }; arg_431 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :150:1
	var arg_432 any = lang.PersistentVector_EMPTY.Ref(); var arg_433 any = jrt.Properties_Cast(props__0).StringPropertyNames__Set(); if linked_429 == nil { return ifn_430.Invoke_O_O_O__O(arg_431, arg_432, arg_433) } else { return linked_429.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_428, arg_431, arg_432, arg_433) } }
func A_arbace_core_server_parse_props_fn__1213000072_A_New_O(p0 any) *A_arbace_core_server_parse_props_fn__1213000072_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_parse_props_fn__1213000072_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Ctor_O(c__props any) { t.F_props = c__props }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var vec__1213000073__3 any; var root_408 any = A_arbace_core_server_A_const_80.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_410 lang.IFn; if
													linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = k__2; var arg_412 any = A_arbace_core_server_A_const_81; if linked_409 == nil { vec__1213000073__3 = ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { vec__1213000073__3 = linked_409.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_408, arg_411, arg_412) }; var k1__4 any = /*line :151:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1213000073__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k2__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000073__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k3__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000073__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(k1__4, Lit_20); if and__1927000168__auto____7 {

		tmp1 = lang.Util_Equiv_O_O__Z_NoInit(k2__5, Lit_21) } else { tmp1 = and__1927000168__auto____7 }; if tmp1 { var v__7 any = lang.RT_Get_O_O__O_NoInit(t.F_props, k__2); var root_422 any = A_arbace_core_server_A_const_9.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_424 lang.IFn

			if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = acc__1; var arg_426 any; var root_417 any = A_arbace_core_server_A_const_82.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_33, k3__6)); var arg_421 any; var root_413 any = A_arbace_core_server_A_const_83.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = v__7; if linked_414 == nil { arg_421 = ifn_415.Invoke_O__O(arg_416) } else { arg_421 = linked_414.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_413, arg_416) }; if linked_418 == nil { arg_426 = ifn_419.Invoke_O_O__O(arg_420, arg_421) } else { arg_426 = linked_418.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_417, arg_420, arg_421) }; if linked_423 == nil { return ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { return linked_423.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) } } else {
//line :153:1
				return acc__1 } }






func A_arbace_core_server_start_servers_A_New() *A_arbace_core_server_start_servers_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_servers_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Ctor() {}
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Invoke_O_O__O(self, system_props__0 any) any { { var seq_1213000078__2 any; var root_438 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_440 lang.IFn


	if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; var root_434 any = A_arbace_core_server_A_const_84.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_core_server_parse_props_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = system_props__0; if linked_435 == nil { arg_441 = ifn_436.Invoke_O__O(arg_437) } else { arg_441 = linked_435.(*A_arbace_core_server_parse_props_A).Invoke_O_O__O(root_434, arg_437) }; if linked_439 == nil { seq_1213000078__2 = ifn_440.Invoke_O__O(arg_441) } else { seq_1213000078__2 = linked_439.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_438, arg_441) }
//line :160:1
	var chunk_1213000079__3 any; var count_1213000080__4 int64 = 0; var i_1213000081__5 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_1213000081__5, count_1213000080__4) { var server__6 any = lang.Indexed_Cast(chunk_1213000079__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1213000081__5)); var root_458 any = A_arbace_core_server_A_const_85.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, A_arbace_core_server_start_server_A_fn_class); var ifn_460 lang.IFn
			if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = server__6; if linked_459 == nil { ifn_460.Invoke_O__O(arg_461) } else { linked_459.(*A_arbace_core_server_start_server_A).Invoke_O_O__O(root_458, arg_461) }
//line :163:1
			seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1213000081__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_442 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1213000078__2; if linked_443 == nil { temp__1927000414__auto____6 = ifn_444.Invoke_O__O(arg_445) } else { temp__1927000414__auto____6 = linked_443.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_442, arg_445) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1213000078__7 any = temp__1927000414__auto____6; var tmp1 any; var root_446 any = A_arbace_core_server_A_const_42.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = seq_1213000078__7; if linked_447 == nil { tmp1 = ifn_448.Invoke_O__O(arg_449) } else { tmp1 = linked_447.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_446, arg_449) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_450 any = A_arbace_core_server_A_const_43.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = seq_1213000078__7; if linked_451 == nil { c__1927000678__auto____8 = ifn_452.Invoke_O__O(arg_453) } else { c__1927000678__auto____8 = linked_451.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_450, arg_453) }; var tmp2 any; var root_462 any = A_arbace_core_server_A_const_45.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = seq_1213000078__7; if linked_463 == nil { tmp2 = ifn_464.Invoke_O__O(arg_465) } else { tmp2 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_462, arg_465) }; seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var server__8 any; var root_454 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1213000078__7; if linked_455 == nil { server__8 = ifn_456.Invoke_O__O(arg_457) } else { server__8 = linked_455.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_454, arg_457) }
				var root_466 any = A_arbace_core_server_A_const_85.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, A_arbace_core_server_start_server_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = server__8; if linked_467 == nil { ifn_468.Invoke_O__O(arg_469) } else { linked_467.(*A_arbace_core_server_start_server_A).Invoke_O_O__O(root_466, arg_469) }
//line :163:1
				var tmp3 any; var root_470 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = seq_1213000078__7; if linked_471 == nil { tmp3 = ifn_472.Invoke_O__O(arg_473) } else { tmp3 = linked_471.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_470, arg_473) }; seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :160:1*/panic("j2g: unreachable") }





func A_arbace_core_server_repl_init_A_New() *A_arbace_core_server_repl_init_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_init_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Ctor() {}
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Invoke_O__O(self any) any {


	lang.IFn_Cast(A_arbace_core_server_A_const_87.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_88)
	var root_474 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = A_arbace_core_server_A_const_2.GetRawRoot__O(); var arg_478 any = A_arbace_core_server_A_const_86.GetRawRoot__O(); if linked_475 == nil { return ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { return linked_475.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_474, arg_477, arg_478)
	} }
func A_arbace_core_server_repl_read_A_New() *A_arbace_core_server_repl_read_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_read_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Ctor() {}
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Invoke_O_O_O__O(self, request_prompt__0, request_exit__1 any) any { var or__1927000174__auto____3 any; var tmp1 lang.IFn = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_89, request_prompt__0, A_arbace_core_server_A_const_90, request_exit__1))); var tmp2 any; var root_485 any = A_arbace_core_server_A_const_94.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_main.A_arbace_main_skip_whitespace_A_fn_class); var ifn_487 lang.IFn; if



	linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = A_arbace_core_server_A_const_50.Get__O(); if linked_486 == nil { tmp2 = ifn_487.Invoke_O__O(arg_488) } else { tmp2 = linked_486.(*aot_arbace_main.A_arbace_main_skip_whitespace_A).Invoke_O_O__O(root_485, arg_488) }; or__1927000174__auto____3 = /*line :175:1*/tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var input__4 any; var root_479 any = A_arbace_core_server_A_const_91.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_481 lang.IFn

		if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = A_arbace_core_server_A_const_92; var arg_483 any = A_arbace_core_server_A_const_50.Get__O(); if linked_480 == nil { input__4 = ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { input__4 = linked_480.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_479, arg_482, arg_483) }
		var root_489 any = A_arbace_core_server_A_const_95.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_main.A_arbace_main_skip_if_eol_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = A_arbace_core_server_A_const_50.Get__O(); if linked_490 == nil { ifn_491.Invoke_O__O(arg_492) } else { linked_490.(*aot_arbace_main.A_arbace_main_skip_if_eol_A).Invoke_O_O__O(root_489, arg_492) }
//line :175:1
		var G__1213000084__5_ any = input__4



		switch lang.Util_Hash_O__I_NoInit(G__1213000084__5_) { case 1244597485: if any(G__1213000084__5_) == any(A_arbace_core_server_A_const_93) { return request_exit__1 }; default:}; return input__4 } }



func A_arbace_core_server_repl_A_New() *A_arbace_core_server_repl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_server_repl_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_server_repl_A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_core_server_A_const_97; var tmp3 any = A_arbace_core_server_A_const_98.GetRawRoot__O(); var tmp4 any = A_arbace_core_server_A_const_99; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, A_arbace_core_server_A_const_100.GetRawRoot__O())
}


func A_arbace_core_server_ex__GT_data_A_New() *A_arbace_core_server_ex__GT_data_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_ex__GT_data_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Invoke_O_O_O__O(self, ex__0, phase__1 any) any {

	var root_504 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any; var root_500 any = A_arbace_core_server_A_const_101.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = ex__0; if linked_501 == nil { arg_507 = ifn_502.Invoke_O__O(arg_503) } else { arg_507 = linked_501.(*aot_arbace_core.A_arbace_core_Throwable__GT_map_A).Invoke_O_O__O(root_500, arg_503) }; var arg_508 any = A_arbace_core_server_A_const_102; var arg_509 any = phase__1; if linked_505 == nil { return ifn_506.Invoke_O_O_O__O(arg_507, arg_508, arg_509) } else { return linked_505.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_504, arg_507, arg_508, arg_509)
	} }
func A_arbace_core_server_prepl_A_New() *A_arbace_core_server_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_core_server_prepl_A) Ctor() {}
//line :194:1
func (t *A_arbace_core_server_prepl_A) DoInvoke_O_O_O_O__O(self, in_reader__0, out_fn__1, p__1213000091__2 any) any { var map__1213000092__4 any = p__1213000091__2; var map__1213000092__5 any; if lang.ISeq_InstanceOf(map__1213000092__4) { var tmp1 any; var root_510 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = map__1213000092__4; if linked_511 == nil { tmp1 = ifn_512.Invoke_O__O(arg_513) } else { tmp1 = linked_511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_510, arg_513) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_514 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = map__1213000092__4; if linked_515 == nil { tmp2 = ifn_516.Invoke_O__O(arg_517) } else { tmp2 = linked_515.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_514, arg_517) }; map__1213000092__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_518 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = map__1213000092__4; if linked_519 == nil { tmp3 = ifn_520.Invoke_O__O(arg_521) } else { tmp3 = linked_519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_518, arg_521) }; if jrt.J2g_Truth(tmp3) { var root_522 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = map__1213000092__4; if linked_523 == nil { map__1213000092__5 = ifn_524.Invoke_O__O(arg_525) } else { map__1213000092__5 = linked_523.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_522, arg_525) } } else { map__1213000092__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000092__5 = map__1213000092__4 }; var stdin__6 any = lang.RT_Get_O_O__O_NoInit(map__1213000092__5, A_arbace_core_server_A_const_103); var tmp4 any = jrt.Thread_CurrentThread__Thread(); var tmp5 *jrt.Class = A_arbace_core_server_A_const_128; var cl__7 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp4, tmp5, Lit_22, jrt.RefArrayOf(jrt.Object_class)); var tmp6 any = jrt.Thread_CurrentThread__Thread(); var tmp7 *jrt.Class = A_arbace_core_server_A_const_128;



























	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp6, tmp7, Lit_23, jrt.RefArrayOf(jrt.Object_class, cl__7)); var EOF__7_ any = /*line :194:1*/jrt.Object_New(); var tapfn__8 any; var tmp8 any = A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(out_fn__1); var tmp9 *jrt.Class; var fncls__526 *jrt.Class = A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class; if




























	fncls__526 == nil { var fncls__526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class = fncls__526d; tmp9 = fncls__526d } else { tmp9 = fncls__526 }; tapfn__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var root_577 any =

	A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var tmp10 any = A_arbace_core_server_A_const_117; var tmp11 any = A_arbace_core_server_A_const_117.Get__O(); var tmp12 any = A_arbace_core_server_A_const_129; var tmp13 any = A_arbace_core_server_A_const_129.Get__O(); var tmp14 any = A_arbace_core_server_A_const_130; var tmp15 any = A_arbace_core_server_A_const_130.Get__O(); var tmp16 any = A_arbace_core_server_A_const_131; var tmp17 any = A_arbace_core_server_A_const_131.Get__O(); var tmp18 any = A_arbace_core_server_A_const_132; var tmp19 any = A_arbace_core_server_A_const_132.Get__O(); var tmp20 any = A_arbace_core_server_A_const_133; var tmp21 any = A_arbace_core_server_A_const_133.Get__O(); var tmp22 any = A_arbace_core_server_A_const_134; var tmp23 any = jrt.Boolean_TRUE.Ref(); var tmp24 any = A_arbace_core_server_A_const_135; var tmp25 any = A_arbace_core_server_A_const_135.Get__O(); var tmp26 any = A_arbace_core_server_A_const_136; var tmp27 any = A_arbace_core_server_A_const_136.Get__O(); var tmp28 any = A_arbace_core_server_A_const_137; var tmp29 any = jrt.System_GetProperty_String_String__String(Lit_25, Lit_26).Ref(); var tmp30 any = A_arbace_core_server_A_const_138; var tmp31 any = A_arbace_core_server_A_const_138.Get__O(); var tmp32 any = A_arbace_core_server_A_const_139; var tmp33 any = A_arbace_core_server_A_const_139.Get__O(); var tmp34 any = A_arbace_core_server_A_const_140; var tmp35 any = A_arbace_core_server_A_const_140.Get__O(); var tmp36 any = A_arbace_core_server_A_const_141; var arg_580 any = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, A_arbace_core_server_A_const_141.Get__O(), A_arbace_core_server_A_const_114, nil, A_arbace_core_server_A_const_113, nil, A_arbace_core_server_A_const_112, nil, A_arbace_core_server_A_const_120, nil)))); if linked_578 == nil { ifn_579.Invoke_O__O(arg_580) } else { linked_578.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_577, arg_580) }; var tmp37 any; tmp57 := /*line :194:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)































		lang.IFn_Cast(A_arbace_core_server_A_const_87.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_142)
		{ var root_606 any = A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp39 any = A_arbace_core_server_A_const_143; var tmp40 any = jrt.Boolean_TRUE.Ref(); var tmp41 any = A_arbace_core_server_A_const_50; var tmp42 any; var or__1927000174__auto____11 any = stdin__6
			if jrt.J2g_Truth(or__1927000174__auto____11) { tmp42 = or__1927000174__auto____11 } else { tmp42 = in_reader__0 }
//line :227:1
			var tmp43 any = tmp42; var tmp44 any = A_arbace_core_server_A_const_51; var tmp45 any; var root_582 any = A_arbace_core_server_A_const_144.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class); var ifn_584 lang.IFn

			if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any; var tmp46 any = A_arbace_core_server_prepl_fn__1213000096_A_New_O(out_fn__1); var tmp47 *jrt.Class; var fncls__581 *jrt.Class = A_arbace_core_server_prepl_fn__1213000096_A_fn_class; if fncls__581 == nil { var fncls__581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_core_server_prepl_fn__1213000096_A_fn_class = fncls__581d; tmp47 = fncls__581d } else { tmp47 = fncls__581 }; arg_585 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil); var arg_586 any; var arg_587 any = jrt.Boolean_TRUE.Ref(); if linked_583 == nil { tmp45 = ifn_584.Invoke_O_O_O__O(arg_585, arg_586, arg_587) } else { tmp45 = linked_583.(*aot_arbace_core.A_arbace_core_PrintWriter_on_A).Invoke_O_O_O_O__O(root_582, arg_585, arg_586, arg_587) }
//line :227:1
			var tmp48 any = tmp45; var tmp49 any = A_arbace_core_server_A_const_52; var tmp50 any; var root_589 any = A_arbace_core_server_A_const_144.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class); var ifn_591 lang.IFn


			if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any; var tmp51 any = A_arbace_core_server_prepl_fn__1213000098_A_New_O(out_fn__1); var tmp52 *jrt.Class; var fncls__588 *jrt.Class = A_arbace_core_server_prepl_fn__1213000098_A_fn_class; if fncls__588 == nil { var fncls__588d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_core_server_prepl_fn__1213000098_A_fn_class = fncls__588d; tmp52 = fncls__588d } else { tmp52 = fncls__588 }; arg_592 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil); var arg_593 any; var arg_594 any = jrt.Boolean_TRUE.Ref(); if linked_590 == nil { tmp50 = ifn_591.Invoke_O_O_O__O(arg_592, arg_593, arg_594) } else { tmp50 = linked_590.(*aot_arbace_core.A_arbace_core_PrintWriter_on_A).Invoke_O_O_O_O__O(root_589, arg_592, arg_593, arg_594) }
//line :227:1
			arg_609 = tmp38.Invoke_O_O_O_O_O_O_O_O__O(tmp39, tmp40, tmp41, tmp43, tmp44, tmp48, tmp49, tmp50); if linked_607 == nil { ifn_608.Invoke_O__O(arg_609) } else { linked_607.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_606, arg_609) }; tmp56 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







































				{ tmp55 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :232:1
					{ var root_610 any = A_arbace_core_server_A_const_147.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_add_tap_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = tapfn__8; if linked_611 == nil { ifn_612.Invoke_O__O(arg_613) } else { linked_611.(*aot_arbace_core.A_arbace_core_add_tap_A).Invoke_O_O__O(root_610, arg_613) }
//line :194:1
					L1: for {







































						var tmp53 any = A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(EOF__7_, out_fn__1, in_reader__0); var tmp54 *jrt.Class; var fncls__566 *jrt.Class = A_arbace_core_server_prepl_fn__1213000100_A_fn_class; if fncls__566 == nil { var fncls__566d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_core_server_prepl_fn__1213000100_A_fn_class = fncls__566d; tmp54 = fncls__566d } else { tmp54 = fncls__566 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O()) {






























							continue L1 } else {
//line :234:1
								tmp37 = nil }
//line :194:1
						break L1
					}
					}






































































					return nil }(); var root_567 any = A_arbace_core_server_A_const_127.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_remove_tap_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = tapfn__8; if linked_568 == nil { ifn_569.Invoke_O__O(arg_570) } else { linked_568.(*aot_arbace_core.A_arbace_core_remove_tap_A).Invoke_O_O__O(root_567, arg_570) }
//line :194:1
					if tmp55 != nil { panic(tmp55)
					}
				}






























				return nil }(); var root_571 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; if linked_572 == nil { ifn_573.Invoke__O() } else { linked_572.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_571) }
//line :194:1
			if tmp56 != nil { panic(tmp56) } }; return nil }(); var root_574 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_576 lang.IFn; if






























	linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; if linked_575 == nil { ifn_576.Invoke__O() } else { linked_575.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_574) }; if /*line :194:1*/ tmp57 != nil { panic(tmp57) }; return tmp37 }




























func A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(p0 any) *A_arbace_core_server_prepl_tapfn__1213000094_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_tapfn__1213000094_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Invoke_O_O__O(self, p1__1213000088_SHARP___1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_105, A_arbace_core_server_A_const_106, p1__1213000088_SHARP___1)))
}



func A_arbace_core_server_prepl_fn__1213000096_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000096_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000096_A{}; t.Ctor_O(p0); return t }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Invoke_O_O__O(self, p1__1213000089_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_145, A_arbace_core_server_A_const_106, p1__1213000089_SHARP___1))) }
func A_arbace_core_server_prepl_fn__1213000098_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000098_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000098_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Invoke_O_O__O(self, p1__1213000090_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_146, A_arbace_core_server_A_const_106, p1__1213000090_SHARP___1))) }



func A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_prepl_fn__1213000100_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000100_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Ctor_O_O_O(c__EOF, c__out_fn, c__in_reader any) { t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_in_reader = c__in_reader }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp26 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1213000101__3 any; var root_527 any = A_arbace_core_server_A_const_107.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_read_PLUS_string_A_fn_class); var ifn_529 lang.IFn
										if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_108, t.F_EOF, A_arbace_core_server_A_const_109, A_arbace_core_server_A_const_110)); var arg_531 any; var t_ any = t.F_in_reader; t.F_in_reader = nil; arg_531 = t_; if linked_528 == nil { vec__1213000101__3 = ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { vec__1213000101__3 = linked_528.(*aot_arbace_core.A_arbace_core_read_PLUS_string_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) }
//line :234:1
	var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000101__3, lang.RT_IntCast_J__I_NoInit(0), nil); var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000101__3, lang.RT_IntCast_J__I_NoInit(1), nil); tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp2 any; var t__2 any = t.F_EOF; t.F_EOF = nil; tmp2 = t__2; if lang.Util_Identical_O_O__Z_NoInit(form__4, tmp2) { tmp1 = nil } else { var start__8 int64 = jrt.System_NanoTime__J(); var ret__9 any; var root_532 any = A_arbace_core_server_A_const_111.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_eval_A_fn_class); var ifn_534 lang.IFn

			if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = form__4; if linked_533 == nil { ret__9 = ifn_534.Invoke_O__O(arg_535) } else { ret__9 = linked_533.(*aot_arbace_core.A_arbace_core_eval_A).Invoke_O_O__O(root_532, arg_535) }
//line :237:1
			var ms__10 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), start__8), 1000000)



			if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_core_server_A_const_93, ret__9) { tmp1 = nil } else { var tmp3 *lang.Var = A_arbace_core_server_A_const_112; tmp3.Set_O__O(A_arbace_core_server_A_const_113.Get__O()); var tmp4 *lang.Var = A_arbace_core_server_A_const_113; tmp4.Set_O__O(A_arbace_core_server_A_const_114.Get__O()); A_arbace_core_server_A_const_114.Set_O__O(ret__9)



				var tmp5 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp6 any = A_arbace_core_server_A_const_104; var tmp7 any = A_arbace_core_server_A_const_115; var tmp8 any = A_arbace_core_server_A_const_106; var tmp9 any
				if jrt.Throwable_InstanceOf(ret__9) {
					var root_536 any = A_arbace_core_server_A_const_101.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = ret__9; if linked_537 == nil { tmp9 = ifn_538.Invoke_O__O(arg_539) } else { tmp9 = linked_537.(*aot_arbace_core.A_arbace_core_Throwable__GT_map_A).Invoke_O_O__O(root_536, arg_539) } } else {
//line :246:1
						tmp9 = ret__9 }
//line :245:1
				var tmp10 any = tmp9; var tmp11 any = A_arbace_core_server_A_const_116; var tmp12 any; var root_540 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_542 lang.IFn



				if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = lang.Namespace_Cast(A_arbace_core_server_A_const_117.Get__O()).F_name.Ref(); if linked_541 == nil { tmp12 = ifn_542.Invoke_O__O(arg_543) } else { tmp12 = linked_541.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_540, arg_543) }
//line :245:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_core_server_A_const_118; tmp5.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp13, tmp14, jrt.Long_ValueOf_J__Long_NoInit(ms__10).Ref(), A_arbace_core_server_A_const_119, s__5)))
//line :241:1
				tmp1 = jrt.Boolean_TRUE.Ref() } } }
//line :234:1
		return nil }(); if tmp15 != nil { if true { var ex__8 jrt.Throwable_I = tmp15; A_arbace_core_server_A_const_120.Set_O__O(ex__8)




















			var tmp16 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp17 any = A_arbace_core_server_A_const_104; var tmp18 any = A_arbace_core_server_A_const_115; var tmp19 any = A_arbace_core_server_A_const_106; var tmp20 any; var root_548 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = ex__8; var arg_552 any; var or__1927000174__auto____9 any; var tmp21 *lang.Keyword = A_arbace_core_server_A_const_122; var tmp22 any; var root_544 any = A_arbace_core_server_A_const_123.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = ex__8; if linked_545 == nil { tmp22 = ifn_546.Invoke_O__O(arg_547) } else { tmp22 = linked_545.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_544, arg_547) }; or__1927000174__auto____9 = tmp21.Invoke_O__O(tmp22); if jrt.J2g_Truth(or__1927000174__auto____9) { arg_552 = or__1927000174__auto____9 } else { arg_552 = A_arbace_core_server_A_const_124 }; if linked_549 == nil { tmp20 = ifn_550.Invoke_O_O__O(arg_551, arg_552) } else { tmp20 = linked_549.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_548, arg_551, arg_552) }; var tmp23 any = tmp20; var tmp24 any = A_arbace_core_server_A_const_116; var tmp25 any; var root_553 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_555 lang.IFn
			if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = lang.Namespace_Cast(A_arbace_core_server_A_const_117.Get__O()).F_name.Ref(); if linked_554 == nil { tmp25 = ifn_555.Invoke_O__O(arg_556) } else { tmp25 = linked_554.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_553, arg_556) }
//line :255:1
			tmp16.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp23, tmp24, tmp25, A_arbace_core_server_A_const_119, s__5, A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref())))
//line :234:1
			tmp1 = jrt.Boolean_TRUE.Ref() } } }; return nil }(); if tmp26 != nil { if true { var ex__3 jrt.Throwable_I = tmp26; A_arbace_core_server_A_const_120.Set_O__O(ex__3)


























				var tmp27 any; var t__3 any = t.F_out_fn; t.F_out_fn = nil; tmp27 = t__3; var tmp28 lang.IFn = lang.IFn_Cast(tmp27); var tmp29 any = A_arbace_core_server_A_const_104; var tmp30 any = A_arbace_core_server_A_const_115; var tmp31 any = A_arbace_core_server_A_const_106; var tmp32 any; var root_557 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = ex__3; var arg_561 any = A_arbace_core_server_A_const_126; if linked_558 == nil { tmp32 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { tmp32 = linked_558.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) }; var tmp33 any = tmp32; var tmp34 any = A_arbace_core_server_A_const_116; var tmp35 any; var root_562 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_564 lang.IFn
				if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = lang.Namespace_Cast(A_arbace_core_server_A_const_117.Get__O()).F_name.Ref(); if linked_563 == nil { tmp35 = ifn_564.Invoke_O__O(arg_565) } else { tmp35 = linked_563.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_562, arg_565) }
//line :261:1
				tmp28.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, tmp33, tmp34, tmp35, A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref())))
//line :234:1
				tmp1 = jrt.Boolean_TRUE.Ref() } }; return tmp1 }


































func A_arbace_core_server_resolve_fn_A_New() *A_arbace_core_server_resolve_fn_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_resolve_fn_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Ctor() {}
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Invoke_O_O__O(self, valf__0 any) any {
	var tmp1 any; var root_614 any = A_arbace_core_server_A_const_148.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = valf__0; if linked_615 == nil { tmp1 = ifn_616.Invoke_O__O(arg_617) } else { tmp1 = linked_615.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_614, arg_617) }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var root_618 any = A_arbace_core_server_A_const_46.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_620 lang.IFn
		if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = valf__0; if linked_619 == nil { or__1927000174__auto____2 = ifn_620.Invoke_O__O(arg_621) } else { or__1927000174__auto____2 = linked_619.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_618, arg_621) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var root_622 any = A_arbace_core_server_A_const_62.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_624 lang.IFn
			if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = valf__0; if linked_623 == nil { temp__1927000414__auto____3 = ifn_624.Invoke_O__O(arg_625) } else { temp__1927000414__auto____3 = linked_623.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var nsname__4 any = temp__1927000414__auto____3; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_2.GetRawRoot__O()); var tmp3 any; var root_630 any = A_arbace_core_server_A_const_61.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_632 lang.IFn
				if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = nsname__4; if linked_631 == nil { tmp3 = ifn_632.Invoke_O__O(arg_633) } else { tmp3 = linked_631.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_630, arg_633) }; tmp2.Invoke_O__O(tmp3)
				var root_626 any = A_arbace_core_server_A_const_46.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = valf__0; if linked_627 == nil { or__1927000174__auto____3 = ifn_628.Invoke_O__O(arg_629) } else { or__1927000174__auto____3 = linked_627.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_626, arg_629) } } else {
//line :272:1
					or__1927000174__auto____3 = nil }
//line :271:1
			if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_35, nil), jrt.RefArrayOf(jrt.Object_class, nil, valf__0))))) } } } else {
//line :270:1
				return valf__0
			}
}





func A_arbace_core_server_io_prepl_A_New() *A_arbace_core_server_io_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) Ctor() {}
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) DoInvoke_O_O__O(self, p__1213000107__0 any) any { var default__1213000110__2 any = A_arbace_core_server_A_const_149.GetRawRoot__O(); var map__1213000108__3 any = p__1213000107__0; var map__1213000108__4 any; if lang.ISeq_InstanceOf(map__1213000108__3) { var tmp1 any; var root_638 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = map__1213000108__3; if linked_639 == nil { tmp1 = ifn_640.Invoke_O__O(arg_641) } else { tmp1 = linked_639.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_638, arg_641) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_642 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = map__1213000108__3; if linked_643 == nil { tmp2 = ifn_644.Invoke_O__O(arg_645) } else { tmp2 = linked_643.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_642, arg_645) }; map__1213000108__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_646 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = map__1213000108__3; if linked_647 == nil { tmp3 = ifn_648.Invoke_O__O(arg_649) } else { tmp3 = linked_647.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(tmp3) { var root_650 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = map__1213000108__3; if linked_651 == nil { map__1213000108__4 = ifn_652.Invoke_O__O(arg_653) } else { map__1213000108__4 = linked_651.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_650, arg_653) } } else { map__1213000108__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000108__4 = map__1213000108__3 }; var valf__5 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000108__4, A_arbace_core_server_A_const_150, default__1213000110__2); var valf__6 any; var root_654 any = A_arbace_core_server_A_const_151.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, A_arbace_core_server_resolve_fn_A_fn_class); var ifn_656 lang.IFn; if







	linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = valf__5; if linked_655 == nil { valf__6 = ifn_656.Invoke_O__O(arg_657) } else { valf__6 = linked_655.(*A_arbace_core_server_resolve_fn_A).Invoke_O_O__O(root_654, arg_657) }; var out__7 any = /*line :278:1*/A_arbace_core_server_A_const_51.Get__O(); var lock__8 any = jrt.Object_New(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_152.GetRawRoot__O()); var tmp5 any = A_arbace_core_server_A_const_50.Get__O(); var tmp6 any = A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(lock__8, out__7, valf__6); var tmp7 *jrt.Class; var fncls__698 *jrt.Class = A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class; if











	fncls__698 == nil { var fncls__698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class = fncls__698d; tmp7 = fncls__698d } else { tmp7 = fncls__698 }; return /*line :289:1*/ tmp4.Invoke_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)) }
func A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_io_prepl_fn__1213000112_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Ctor_O_O_O(c__lock, c__out, c__valf any) { t.F_lock = c__lock; t.F_out = c__out; t.F_valf = c__valf }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Invoke_O_O__O(self, m__1 any) any {
	var root_694 any = A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_core_server_A_const_51, t.F_out, A_arbace_core_server_A_const_156, jrt.Boolean_TRUE.Ref(), A_arbace_core_server_A_const_157, jrt.Boolean_TRUE.Ref()); if linked_695 == nil { ifn_696.Invoke_O__O(arg_697) } else { linked_695.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_694, arg_697) }
//line :290:1
	var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var lockee__1927000360__auto____4 any = t.F_lock; var locklocal__1927000361__auto____7 any = lockee__1927000360__auto____4; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____7); tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_153.GetRawRoot__O()); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_154); if jrt.J2g_Truth(tmp4.Invoke_O__O(A_arbace_core_server_A_const_104.Invoke_O__O(m__1))) {
			var tmp5 any = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(m__1, t.F_valf); var tmp6 *jrt.Class; var fncls__677 *jrt.Class = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class; if fncls__677 == nil { var fncls__677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class = fncls__677d; tmp6 = fncls__677d } else { tmp6 = fncls__677 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O() } else {
//line :293:1
				tmp3 = m__1 }; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :290:1
		return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____7); if tmp7 != nil { panic(tmp7) } }; return nil }(); var root_682 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_684 lang.IFn
	if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; if linked_683 == nil { ifn_684.Invoke__O() } else { linked_683.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_682) }
//line :290:1
	if tmp8 != nil { panic(tmp8) }; return tmp1
}


func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(p0, p1 any) *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A{}; t.Ctor_O_O(p0, p1); return t }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Ctor_O_O(c__m, c__valf any) { t.F_m = c__m; t.F_valf = c__valf }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_658 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = t.F_m; var arg_662 any = A_arbace_core_server_A_const_106; var tmp2 lang.IFn = lang.IFn_Cast(t.F_valf); var arg_663 any = tmp2.Invoke_O__O(A_arbace_core_server_A_const_106.Invoke_O__O(t.F_m)); if linked_659 == nil { tmp1 = ifn_660.Invoke_O_O_O__O(arg_661, arg_662, arg_663) } else { tmp1 = linked_659.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_658, arg_661, arg_662, arg_663) } }
//line :294:1
	return nil }(); if tmp3 != nil { if true { var ex__3 jrt.Throwable_I = tmp3; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_m


		t.F_m = nil; tmp5 = t_; var tmp6 any = tmp5; var tmp7 any = A_arbace_core_server_A_const_106; var tmp8 any; var t__2 any = t.F_valf; t.F_valf = nil; tmp8 = t__2; var tmp9 lang.IFn = lang.IFn_Cast(tmp8); var tmp10 any; var root_664 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = ex__3; var arg_668 any = A_arbace_core_server_A_const_155; if linked_665 == nil { tmp10 = ifn_666.Invoke_O_O__O(arg_667, arg_668) } else { tmp10 = linked_665.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_664, arg_667, arg_668) }; tmp1 = tmp4.Invoke_O_O_O_O_O__O(tmp6, tmp7, tmp9.Invoke_O__O(tmp10), A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref()) } }; return tmp1 }



func A_arbace_core_server_remote_prepl_A_New() *A_arbace_core_server_remote_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) DoInvoke_O_O_O_O_O_O__O(self, host__0, port__1, in_reader__2, out_fn__3, p__1213000119__4 any) any { var default__1213000122__6 any = A_arbace_core_server_A_const_158.GetRawRoot__O(); var default__1213000123__7 any; var tmp1 any = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New(); var tmp2 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class; if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class = fncls__710d; tmp2 = fncls__710d } else { tmp2 = fncls__710 }; default__1213000123__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var map__1213000120__8 any = p__1213000119__4; var map__1213000120__9 any; if lang.ISeq_InstanceOf(map__1213000120__8) { var tmp3 any; var root_711 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = map__1213000120__8; if linked_712 == nil { tmp3 = ifn_713.Invoke_O__O(arg_714) } else { tmp3 = linked_712.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_711, arg_714) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_715 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = map__1213000120__8; if linked_716 == nil { tmp4 = ifn_717.Invoke_O__O(arg_718) } else { tmp4 = linked_716.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_715, arg_718) }; map__1213000120__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp4, jrt.Object_class.ArrayClass())).Ref() } else { var tmp5 any; var root_719 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = map__1213000120__8; if linked_720 == nil { tmp5 = ifn_721.Invoke_O__O(arg_722) } else { tmp5 = linked_720.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_719, arg_722) }; if jrt.J2g_Truth(tmp5) { var root_723 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = map__1213000120__8; if linked_724 == nil { map__1213000120__9 = ifn_725.Invoke_O__O(arg_726) } else { map__1213000120__9 = linked_724.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_723, arg_726) } } else { map__1213000120__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000120__9 = map__1213000120__8 }; var valf__10 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000120__9, A_arbace_core_server_A_const_150, default__1213000122__6); var readf__11 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000120__9, A_arbace_core_server_A_const_159, default__1213000123__7); var valf__12 any; var root_727 any = A_arbace_core_server_A_const_151.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, A_arbace_core_server_resolve_fn_A_fn_class); var ifn_729 lang.IFn; if












	linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = valf__10; if linked_728 == nil { valf__12 = ifn_729.Invoke_O__O(arg_730) } else { valf__12 = linked_728.(*A_arbace_core_server_resolve_fn_A).Invoke_O_O__O(root_727, arg_730) }; var readf__13 any; var root_731 any = /*line :301:1*/A_arbace_core_server_A_const_151.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, A_arbace_core_server_resolve_fn_A_fn_class); var ifn_733 lang.IFn; if













	linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = readf__11; if linked_732 == nil { readf__13 = ifn_733.Invoke_O__O(arg_734) } else { readf__13 = linked_732.(*A_arbace_core_server_resolve_fn_A).Invoke_O_O__O(root_731, arg_734) }; var port__14 any; var tmp6 any; var root_735 any = /*line :301:1*/A_arbace_core_server_A_const_160.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_737 lang.IFn; if














	linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = port__1; if linked_736 == nil { tmp6 = ifn_737.Invoke_O__O(arg_738) } else { tmp6 = linked_736.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_735, arg_738) }; if jrt.J2g_Truth(tmp6) { port__14 = jrt.Integer_ValueOf_String__Integer_NoInit(jrt.String_Cast(port__1)).Ref() } else { port__14 = port__1 }; var socket__15 any = /*line :301:1*/jrt.Socket_New_String_I(jrt.String_Cast(host__0), lang.RT_IntCast_O__I_NoInit(port__14)); var rd__16 any = lang.LineNumberingPushbackReader_New_Reader(jrt.BufferedReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(socket__15).GetInputStream__InputStream()))); var wr__17 any = jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(socket__15).GetOutputStream__OutputStream()); var EOF__18_ any = jrt.Object_New(); var G__1213000127__19_ any; var tmp7 any = A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(rd__16, readf__13, wr__17, EOF__18_, out_fn__3, valf__12); var tmp8 *jrt.Class; var fncls__775 *jrt.Class = A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class; if



















	fncls__775 == nil { var fncls__775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class = fncls__775d; tmp8 = fncls__775d } else { tmp8 = fncls__775 }; G__1213000127__19_ = /*line :301:1*/jrt.Thread_New_Runnable_String(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), Lit_32);



















	jrt.Thread_Cast(G__1213000127__19_).SetDaemon_Z__V(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()); jrt.Thread_Cast(G__1213000127__19_).Start__V(); var buf__19 any = /*line :301:1*/lang.Numbers_Char_array_O__C1_NoInit(A_arbace_core_server_A_const_161).Ref(); var tmp9 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L1: for { var n__22 int32 = jrt.Reader_Cast(in_reader__2).Read_C1__I(jrt.J2g_CastArray[*jrt.CharArray](buf__19, jrt.Prim_char.ArrayClass()))





































		if lang.Util_Equiv_J_J__Z_NoInit(int64(n__22), -1) { tmp9 = nil } else {
			jrt.OutputStreamWriter_Cast(wr__17).Write_C1_I_I__V(jrt.J2g_CastArray[*jrt.CharArray](buf__19, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), n__22)
			jrt.OutputStreamWriter_Cast(wr__17).Flush__V()
			continue L1 }
//line :301:1
		break L1 }; return nil }();










































	jrt.PushbackReader_Cast(rd__16).Close__V(); if /*line :301:1*/ tmp10 != nil { panic(tmp10) }; return tmp9 }
//line :301:1
func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New() *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Invoke_O_O_O__O(self, p1__1213000117_SHARP___1, p2__1213000118_SHARP___2 any) any {











	var root_704 any = A_arbace_core_server_A_const_91.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = p1__1213000117_SHARP___1; var arg_708 any = jrt.Boolean_FALSE.Ref(); var arg_709 any = p2__1213000118_SHARP___2; if linked_705 == nil { return ifn_706.Invoke_O_O_O__O(arg_707, arg_708, arg_709) } else { return linked_705.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_704, arg_707, arg_708, arg_709)
	}
}





func A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_remote_prepl_fn__1213000128_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Ctor_O_O_O_O_O_O(c__rd, c__readf, c__wr, c__EOF, c__out_fn, c__valf any) { t.F_rd = c__rd; t.F_readf = c__readf; t.F_wr = c__wr; t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_valf = c__valf }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Invoke_O__O(self any) any { for { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L2: for { var map__1213000129__3 any = lang.IFn_Cast(t.F_readf).Invoke_O_O__O(t.F_rd, t.F_EOF); var map__1213000129__4 any

	if lang.ISeq_InstanceOf(map__1213000129__3) { var tmp2 any; var root_739 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = map__1213000129__3; if linked_740 == nil { tmp2 = ifn_741.Invoke_O__O(arg_742) } else { tmp2 = linked_740.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_739, arg_742) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_743 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = map__1213000129__3; if linked_744 == nil { tmp3 = ifn_745.Invoke_O__O(arg_746) } else { tmp3 = linked_744.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_743, arg_746) }; map__1213000129__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_747 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = map__1213000129__3; if linked_748 == nil { tmp4 = ifn_749.Invoke_O__O(arg_750) } else { tmp4 = linked_748.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_747, arg_750) }; if jrt.J2g_Truth(tmp4) { var root_751 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = map__1213000129__3; if linked_752 == nil { map__1213000129__4 = ifn_753.Invoke_O__O(arg_754) } else { map__1213000129__4 = linked_752.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_751, arg_754) } } else { map__1213000129__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000129__4 = map__1213000129__3 }
//line :321:1
	var m__5 any = map__1213000129__4; var tag__6 any = lang.RT_Get_O_O__O_NoInit(map__1213000129__4, A_arbace_core_server_A_const_104); var val__7 any = lang.RT_Get_O_O__O_NoInit(map__1213000129__4, A_arbace_core_server_A_const_106)


	if lang.Util_Identical_O_O__Z_NoInit(m__5, t.F_EOF) { tmp1 = nil } else {
		var tmp5 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp6 any
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_162).Invoke_O__O(tag__6)) {
			var tmp7 any = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(m__5, t.F_valf, val__7); var tmp8 *jrt.Class; var fncls__774 *jrt.Class = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class; if fncls__774 == nil { var fncls__774d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class = fncls__774d; tmp8 = fncls__774d } else { tmp8 = fncls__774 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O() } else {
//line :326:1
				tmp6 = m__5 }
//line :325:1
		tmp5.Invoke_O__O(tmp6)







		continue L2 }
//line :321:1
	break L2 }; return nil }()













	jrt.OutputStreamWriter_Cast(t.F_wr).Close__V()
//line :321:1
	if tmp9 != nil { panic(tmp9) }; return tmp1 }; panic("j2g: unreachable") }





func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Ctor_O_O_O(c__m, c__valf, c__val any) { t.F_m = c__m; t.F_valf = c__valf; t.F_val = c__val }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_755 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = t.F_m; var arg_759 any = A_arbace_core_server_A_const_106; var arg_760 any; var tmp2 any; var t_ any = t.F_valf; t.F_valf = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_val; t.F_val = nil; tmp4 = t__2; arg_760 = tmp3.Invoke_O__O(tmp4); if linked_756 == nil { tmp1 = ifn_757.Invoke_O_O_O__O(arg_758, arg_759, arg_760) } else { tmp1 = linked_756.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_755, arg_758, arg_759, arg_760) } }
//line :327:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp7 any; var t__3 any = t.F_m


		t.F_m = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any = A_arbace_core_server_A_const_106; var tmp10 any; var root_761 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = ex__3; var arg_765 any = A_arbace_core_server_A_const_163; if linked_762 == nil { tmp10 = ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { tmp10 = linked_762.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) }; tmp1 = tmp6.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref()) } }; return tmp1 }




type A_arbace_core_server_A struct{ jrt.Object }

var A_arbace_core_server_A_const_pool *jrt.RefArray

var A_arbace_core_server_A_const_0 *lang.Var

var A_arbace_core_server_A_const_1 any

var A_arbace_core_server_A_const_2 *lang.Var

var A_arbace_core_server_A_const_3 any

var A_arbace_core_server_A_const_4 any

var A_arbace_core_server_A_const_5 any

var A_arbace_core_server_A_const_6 *lang.Var

var A_arbace_core_server_A_const_7 *lang.Var

var A_arbace_core_server_A_const_8 *lang.Var

var A_arbace_core_server_A_const_9 *lang.Var

var A_arbace_core_server_A_const_10 any

var A_arbace_core_server_A_const_11 *lang.Var

var A_arbace_core_server_A_const_12 *lang.Var

var A_arbace_core_server_A_const_13 *lang.Var

var A_arbace_core_server_A_const_14 any

var A_arbace_core_server_A_const_15 *lang.Var

var A_arbace_core_server_A_const_16 *lang.Var

var A_arbace_core_server_A_const_17 any

var A_arbace_core_server_A_const_18 *lang.Var

var A_arbace_core_server_A_const_19 any

var A_arbace_core_server_A_const_20 any

var A_arbace_core_server_A_const_21 any

var A_arbace_core_server_A_const_22 any

var A_arbace_core_server_A_const_23 any

var A_arbace_core_server_A_const_24 any

var A_arbace_core_server_A_const_25 any

var A_arbace_core_server_A_const_26 any

var A_arbace_core_server_A_const_27 any

var A_arbace_core_server_A_const_28 any

var A_arbace_core_server_A_const_29 *lang.Var

var A_arbace_core_server_A_const_30 *lang.Var

var A_arbace_core_server_A_const_31 *lang.Var

var A_arbace_core_server_A_const_32 *lang.Var

var A_arbace_core_server_A_const_33 *lang.Keyword

var A_arbace_core_server_A_const_34 *lang.Keyword

var A_arbace_core_server_A_const_35 *lang.Keyword

var A_arbace_core_server_A_const_36 *lang.Var

var A_arbace_core_server_A_const_37 *lang.Var

var A_arbace_core_server_A_const_38 *lang.Var

var A_arbace_core_server_A_const_39 any

var A_arbace_core_server_A_const_40 any

var A_arbace_core_server_A_const_41 any

var A_arbace_core_server_A_const_42 *lang.Var

var A_arbace_core_server_A_const_43 *lang.Var

var A_arbace_core_server_A_const_44 *lang.Var

var A_arbace_core_server_A_const_45 *lang.Var

var A_arbace_core_server_A_const_46 *lang.Var

var A_arbace_core_server_A_const_47 *lang.Var

var A_arbace_core_server_A_const_48 *lang.Var

var A_arbace_core_server_A_const_49 *lang.Var

var A_arbace_core_server_A_const_50 *lang.Var

var A_arbace_core_server_A_const_51 *lang.Var

var A_arbace_core_server_A_const_52 *lang.Var

var A_arbace_core_server_A_const_53 *lang.Var

var A_arbace_core_server_A_const_54 *lang.Keyword

var A_arbace_core_server_A_const_55 *lang.Keyword

var A_arbace_core_server_A_const_56 *lang.Var

var A_arbace_core_server_A_const_57 *lang.Var

var A_arbace_core_server_A_const_58 *lang.Var

var A_arbace_core_server_A_const_59 *lang.Var

var A_arbace_core_server_A_const_60 *lang.Keyword

var A_arbace_core_server_A_const_61 *lang.Var

var A_arbace_core_server_A_const_62 *lang.Var

var A_arbace_core_server_A_const_63 *lang.Var

var A_arbace_core_server_A_const_64 *lang.Var

var A_arbace_core_server_A_const_65 *lang.Keyword

var A_arbace_core_server_A_const_66 *lang.Keyword

var A_arbace_core_server_A_const_67 *lang.Keyword

var A_arbace_core_server_A_const_68 *lang.Keyword

var A_arbace_core_server_A_const_69 *lang.Keyword

var A_arbace_core_server_A_const_70 *lang.Var

var A_arbace_core_server_A_const_71 *lang.Var

var A_arbace_core_server_A_const_72 *lang.Keyword

var A_arbace_core_server_A_const_73 *lang.Var

var A_arbace_core_server_A_const_74 *lang.Var

var A_arbace_core_server_A_const_75 *lang.Var

var A_arbace_core_server_A_const_76 *lang.Var

var A_arbace_core_server_A_const_77 *lang.Var

var A_arbace_core_server_A_const_78 *lang.Var

var A_arbace_core_server_A_const_79 *lang.Var

var A_arbace_core_server_A_const_80 *lang.Var

var A_arbace_core_server_A_const_81 any

var A_arbace_core_server_A_const_82 *lang.Var

var A_arbace_core_server_A_const_83 *lang.Var

var A_arbace_core_server_A_const_84 *lang.Var

var A_arbace_core_server_A_const_85 *lang.Var

var A_arbace_core_server_A_const_86 *lang.Var

var A_arbace_core_server_A_const_87 *lang.Var

var A_arbace_core_server_A_const_88 any

var A_arbace_core_server_A_const_89 *lang.Keyword

var A_arbace_core_server_A_const_90 *lang.Keyword

var A_arbace_core_server_A_const_91 *lang.Var

var A_arbace_core_server_A_const_92 any

var A_arbace_core_server_A_const_93 *lang.Keyword

var A_arbace_core_server_A_const_94 *lang.Var

var A_arbace_core_server_A_const_95 *lang.Var

var A_arbace_core_server_A_const_96 *lang.Var

var A_arbace_core_server_A_const_97 *lang.Keyword

var A_arbace_core_server_A_const_98 *lang.Var

var A_arbace_core_server_A_const_99 *lang.Keyword

var A_arbace_core_server_A_const_100 *lang.Var

var A_arbace_core_server_A_const_101 *lang.Var

var A_arbace_core_server_A_const_102 *lang.Keyword

var A_arbace_core_server_A_const_103 *lang.Keyword

var A_arbace_core_server_A_const_104 *lang.Keyword

var A_arbace_core_server_A_const_105 *lang.Keyword

var A_arbace_core_server_A_const_106 *lang.Keyword

var A_arbace_core_server_A_const_107 *lang.Var

var A_arbace_core_server_A_const_108 *lang.Keyword

var A_arbace_core_server_A_const_109 *lang.Keyword

var A_arbace_core_server_A_const_110 *lang.Keyword

var A_arbace_core_server_A_const_111 *lang.Var

var A_arbace_core_server_A_const_112 *lang.Var

var A_arbace_core_server_A_const_113 *lang.Var

var A_arbace_core_server_A_const_114 *lang.Var

var A_arbace_core_server_A_const_115 *lang.Keyword

var A_arbace_core_server_A_const_116 *lang.Keyword

var A_arbace_core_server_A_const_117 *lang.Var

var A_arbace_core_server_A_const_118 *lang.Keyword

var A_arbace_core_server_A_const_119 *lang.Keyword

var A_arbace_core_server_A_const_120 *lang.Var

var A_arbace_core_server_A_const_121 *lang.Var

var A_arbace_core_server_A_const_122 *lang.Keyword

var A_arbace_core_server_A_const_123 *lang.Var

var A_arbace_core_server_A_const_124 *lang.Keyword

var A_arbace_core_server_A_const_125 *lang.Keyword

var A_arbace_core_server_A_const_126 *lang.Keyword

var A_arbace_core_server_A_const_127 *lang.Var

var A_arbace_core_server_A_const_128 *jrt.Class

var A_arbace_core_server_A_const_129 *lang.Var

var A_arbace_core_server_A_const_130 *lang.Var

var A_arbace_core_server_A_const_131 *lang.Var

var A_arbace_core_server_A_const_132 *lang.Var

var A_arbace_core_server_A_const_133 *lang.Var

var A_arbace_core_server_A_const_134 *lang.Var

var A_arbace_core_server_A_const_135 *lang.Var

var A_arbace_core_server_A_const_136 *lang.Var

var A_arbace_core_server_A_const_137 *lang.Var

var A_arbace_core_server_A_const_138 *lang.Var

var A_arbace_core_server_A_const_139 *lang.Var

var A_arbace_core_server_A_const_140 *lang.Var

var A_arbace_core_server_A_const_141 *lang.Var

var A_arbace_core_server_A_const_142 any

var A_arbace_core_server_A_const_143 *lang.Var

var A_arbace_core_server_A_const_144 *lang.Var

var A_arbace_core_server_A_const_145 *lang.Keyword

var A_arbace_core_server_A_const_146 *lang.Keyword

var A_arbace_core_server_A_const_147 *lang.Var

var A_arbace_core_server_A_const_148 *lang.Var

var A_arbace_core_server_A_const_149 *lang.Var

var A_arbace_core_server_A_const_150 *lang.Keyword

var A_arbace_core_server_A_const_151 *lang.Var

var A_arbace_core_server_A_const_152 *lang.Var

var A_arbace_core_server_A_const_153 *lang.Var

var A_arbace_core_server_A_const_154 any

var A_arbace_core_server_A_const_155 *lang.Keyword

var A_arbace_core_server_A_const_156 *lang.Var

var A_arbace_core_server_A_const_157 *lang.Var

var A_arbace_core_server_A_const_158 *lang.Var

var A_arbace_core_server_A_const_159 *lang.Keyword

var A_arbace_core_server_A_const_160 *lang.Var

var A_arbace_core_server_A_const_161 any

var A_arbace_core_server_A_const_162 any

var A_arbace_core_server_A_const_163 *lang.Keyword

var A_arbace_core_server_A_init jrt.ClassInit

func A_arbace_core_server_A_Init() { if !A_arbace_core_server_A_init.Done() { A_arbace_core_server_A_init.Run(A_arbace_core_server_A_clinit) } }

func A_arbace_core_server_A_clinit() { A_arbace_core_server_A_clinit_p0(); A_arbace_core_server_A_clinit_p1(); A_arbace_core_server_A_clinit_p2(); A_arbace_core_server_A_clinit_p3(); A_arbace_core_server_A_clinit_p4(); A_arbace_core_server_A_clinit_p5(); A_arbace_core_server_A_clinit_p6(); A_arbace_core_server_A_clinit_p7(); A_arbace_core_server_A_clinit_p8(); A_arbace_core_server_A_clinit_p9(); A_arbace_core_server_A_clinit_p10(); A_arbace_core_server_A_clinit_p11(); A_arbace_core_server_A_clinit_p12(); A_arbace_core_server_A_clinit_p13() }

func A_arbace_core_server_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_server_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 226); A_arbace_core_server_A_const_0 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[62]); A_arbace_core_server_A_const_1 = A_arbace_core_server_A_const_pool.A[63]; A_arbace_core_server_A_const_2 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[64]); A_arbace_core_server_A_const_3 = A_arbace_core_server_A_const_pool.A[65]; A_arbace_core_server_A_const_4 = A_arbace_core_server_A_const_pool.A[66]; A_arbace_core_server_A_const_5 = A_arbace_core_server_A_const_pool.A[67]; A_arbace_core_server_A_const_6 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[68]); A_arbace_core_server_A_const_7 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[69]); A_arbace_core_server_A_const_8 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[70]); A_arbace_core_server_A_const_9 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[71]); A_arbace_core_server_A_const_10 = A_arbace_core_server_A_const_pool.A[72]; A_arbace_core_server_A_const_11 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[73]) }

func A_arbace_core_server_A_clinit_p1() { A_arbace_core_server_A_const_12 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[74]); A_arbace_core_server_A_const_13 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[75]); A_arbace_core_server_A_const_14 = A_arbace_core_server_A_const_pool.A[76]; A_arbace_core_server_A_const_15 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[77]); A_arbace_core_server_A_const_16 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[78]); A_arbace_core_server_A_const_17 = A_arbace_core_server_A_const_pool.A[79]; A_arbace_core_server_A_const_18 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[80]); A_arbace_core_server_A_const_19 = A_arbace_core_server_A_const_pool.A[81]; A_arbace_core_server_A_const_20 = A_arbace_core_server_A_const_pool.A[82]; A_arbace_core_server_A_const_21 = A_arbace_core_server_A_const_pool.A[83]; A_arbace_core_server_A_const_22 = A_arbace_core_server_A_const_pool.A[84]; A_arbace_core_server_A_const_23 = A_arbace_core_server_A_const_pool.A[85]; A_arbace_core_server_A_const_24 = A_arbace_core_server_A_const_pool.A[86]; A_arbace_core_server_A_const_25 = A_arbace_core_server_A_const_pool.A[87] }

func A_arbace_core_server_A_clinit_p2() { A_arbace_core_server_A_const_26 = A_arbace_core_server_A_const_pool.A[88]; A_arbace_core_server_A_const_27 = A_arbace_core_server_A_const_pool.A[89]; A_arbace_core_server_A_const_28 = A_arbace_core_server_A_const_pool.A[90]; A_arbace_core_server_A_const_29 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[91]); A_arbace_core_server_A_const_30 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[92]); A_arbace_core_server_A_const_31 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[93]); A_arbace_core_server_A_const_32 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[94]); A_arbace_core_server_A_const_33 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[95]); A_arbace_core_server_A_const_34 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[96]); A_arbace_core_server_A_const_35 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[97]); A_arbace_core_server_A_const_36 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[98]); A_arbace_core_server_A_const_37 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[99]) }

func A_arbace_core_server_A_clinit_p3() { A_arbace_core_server_A_const_38 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[100]); A_arbace_core_server_A_const_39 = A_arbace_core_server_A_const_pool.A[101]; A_arbace_core_server_A_const_40 = A_arbace_core_server_A_const_pool.A[102]; A_arbace_core_server_A_const_41 = A_arbace_core_server_A_const_pool.A[103]; A_arbace_core_server_A_const_42 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[104]); A_arbace_core_server_A_const_43 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[105]); A_arbace_core_server_A_const_44 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[106]); A_arbace_core_server_A_const_45 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[107]); A_arbace_core_server_A_const_46 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[108]); A_arbace_core_server_A_const_47 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[109]); A_arbace_core_server_A_const_48 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[110]); A_arbace_core_server_A_const_49 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[111]) }

func A_arbace_core_server_A_clinit_p4() { A_arbace_core_server_A_const_50 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[112]); A_arbace_core_server_A_const_51 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[113]); A_arbace_core_server_A_const_52 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[114]); A_arbace_core_server_A_const_53 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[115]); A_arbace_core_server_A_const_54 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[116]); A_arbace_core_server_A_const_55 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[117]); A_arbace_core_server_A_const_56 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[118]); A_arbace_core_server_A_const_57 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[119]); A_arbace_core_server_A_const_58 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[120]); A_arbace_core_server_A_const_59 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[121]); A_arbace_core_server_A_const_60 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[122]); A_arbace_core_server_A_const_61 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[123]) }

func A_arbace_core_server_A_clinit_p5() { A_arbace_core_server_A_const_62 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[124]); A_arbace_core_server_A_const_63 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[125]); A_arbace_core_server_A_const_64 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[126]); A_arbace_core_server_A_const_65 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[127]); A_arbace_core_server_A_const_66 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[128]); A_arbace_core_server_A_const_67 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[129]); A_arbace_core_server_A_const_68 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[130]); A_arbace_core_server_A_const_69 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[131]); A_arbace_core_server_A_const_70 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[132]); A_arbace_core_server_A_const_71 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[133]); A_arbace_core_server_A_const_72 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[134]); A_arbace_core_server_A_const_73 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[135]) }

func A_arbace_core_server_A_clinit_p6() { A_arbace_core_server_A_const_74 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[136]); A_arbace_core_server_A_const_75 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[137]); A_arbace_core_server_A_const_76 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[138]); A_arbace_core_server_A_const_77 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[139]); A_arbace_core_server_A_const_78 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[140]); A_arbace_core_server_A_const_79 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[141]); A_arbace_core_server_A_const_80 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[142]); A_arbace_core_server_A_const_81 = A_arbace_core_server_A_const_pool.A[143]; A_arbace_core_server_A_const_82 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[144]); A_arbace_core_server_A_const_83 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[145]); A_arbace_core_server_A_const_84 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[146]); A_arbace_core_server_A_const_85 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[147]) }

func A_arbace_core_server_A_clinit_p7() { A_arbace_core_server_A_const_86 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[148]); A_arbace_core_server_A_const_87 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[149]); A_arbace_core_server_A_const_88 = A_arbace_core_server_A_const_pool.A[150]; A_arbace_core_server_A_const_89 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[151]); A_arbace_core_server_A_const_90 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[152]); A_arbace_core_server_A_const_91 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[153]); A_arbace_core_server_A_const_92 = A_arbace_core_server_A_const_pool.A[154]; A_arbace_core_server_A_const_93 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[155]); A_arbace_core_server_A_const_94 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[156]); A_arbace_core_server_A_const_95 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[157]); A_arbace_core_server_A_const_96 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[158]); A_arbace_core_server_A_const_97 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[159]) }

func A_arbace_core_server_A_clinit_p8() { A_arbace_core_server_A_const_98 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[160]); A_arbace_core_server_A_const_99 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[161]); A_arbace_core_server_A_const_100 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[162]); A_arbace_core_server_A_const_101 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[163]); A_arbace_core_server_A_const_102 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[164]); A_arbace_core_server_A_const_103 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[165]); A_arbace_core_server_A_const_104 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[166]); A_arbace_core_server_A_const_105 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[167]); A_arbace_core_server_A_const_106 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[168]); A_arbace_core_server_A_const_107 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[169]); A_arbace_core_server_A_const_108 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[170]); A_arbace_core_server_A_const_109 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[171]) }

func A_arbace_core_server_A_clinit_p9() { A_arbace_core_server_A_const_110 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[172]); A_arbace_core_server_A_const_111 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[173]); A_arbace_core_server_A_const_112 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[174]); A_arbace_core_server_A_const_113 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[175]); A_arbace_core_server_A_const_114 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[176]); A_arbace_core_server_A_const_115 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[177]); A_arbace_core_server_A_const_116 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[178]); A_arbace_core_server_A_const_117 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[179]); A_arbace_core_server_A_const_118 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[180]); A_arbace_core_server_A_const_119 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[181]); A_arbace_core_server_A_const_120 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[182]); A_arbace_core_server_A_const_121 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[183]) }

func A_arbace_core_server_A_clinit_p10() { A_arbace_core_server_A_const_122 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[184]); A_arbace_core_server_A_const_123 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[185]); A_arbace_core_server_A_const_124 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[186]); A_arbace_core_server_A_const_125 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[187]); A_arbace_core_server_A_const_126 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[188]); A_arbace_core_server_A_const_127 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[189]); A_arbace_core_server_A_const_128 = jrt.Class_Cast(A_arbace_core_server_A_const_pool.A[190]); A_arbace_core_server_A_const_129 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[191]); A_arbace_core_server_A_const_130 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[192]); A_arbace_core_server_A_const_131 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[193]); A_arbace_core_server_A_const_132 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[194]); A_arbace_core_server_A_const_133 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[195]) }

func A_arbace_core_server_A_clinit_p11() { A_arbace_core_server_A_const_134 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[196]); A_arbace_core_server_A_const_135 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[197]); A_arbace_core_server_A_const_136 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[198]); A_arbace_core_server_A_const_137 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[199]); A_arbace_core_server_A_const_138 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[200]); A_arbace_core_server_A_const_139 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[201]); A_arbace_core_server_A_const_140 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[202]); A_arbace_core_server_A_const_141 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[203]); A_arbace_core_server_A_const_142 = A_arbace_core_server_A_const_pool.A[204]; A_arbace_core_server_A_const_143 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[205]); A_arbace_core_server_A_const_144 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[206]); A_arbace_core_server_A_const_145 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[207]) }

func A_arbace_core_server_A_clinit_p12() { A_arbace_core_server_A_const_146 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[208]); A_arbace_core_server_A_const_147 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[209]); A_arbace_core_server_A_const_148 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[210]); A_arbace_core_server_A_const_149 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[211]); A_arbace_core_server_A_const_150 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[212]); A_arbace_core_server_A_const_151 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[213]); A_arbace_core_server_A_const_152 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[214]); A_arbace_core_server_A_const_153 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[215]); A_arbace_core_server_A_const_154 = A_arbace_core_server_A_const_pool.A[216]; A_arbace_core_server_A_const_155 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[217]); A_arbace_core_server_A_const_156 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[218]); A_arbace_core_server_A_const_157 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[219]) }

func A_arbace_core_server_A_clinit_p13() { A_arbace_core_server_A_const_158 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[220]); A_arbace_core_server_A_const_159 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[221]); A_arbace_core_server_A_const_160 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[222]); A_arbace_core_server_A_const_161 = A_arbace_core_server_A_const_pool.A[223]; A_arbace_core_server_A_const_162 = A_arbace_core_server_A_const_pool.A[224]; A_arbace_core_server_A_const_163 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[225]) }

func A_arbace_core_server_A_New() *A_arbace_core_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_A) Ctor() {}

func (t *A_arbace_core_server_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_A_class }

func (t *A_arbace_core_server_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_A); return ok }

func A_arbace_core_server_A_Cast(x any) *A_arbace_core_server_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_A_class)) }; return v }



type A_arbace_core_server_accept_connection_A struct{ j2g_header uint64 }

var A_arbace_core_server_accept_connection_A_fn_class *jrt.Class



type A_arbace_core_server_accept_connection_fn__1213000038_A struct{ j2g_header uint64; F_name, F_client_id, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class *jrt.Class



type A_arbace_core_server_accept_connection_fn__1213000040_A struct{ j2g_header uint64; F_name, F_client_id, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class *jrt.Class



type A_arbace_core_server_eval1213000004_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000004_A_New() *A_arbace_core_server_eval1213000004_A { t := &A_arbace_core_server_eval1213000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000004_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000004_A_class }

func (t *A_arbace_core_server_eval1213000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000004_A); return ok }

func A_arbace_core_server_eval1213000004_A_Cast(x any) *A_arbace_core_server_eval1213000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000004_A_class)) }; return v }



type A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A struct{ j2g_header uint64 }

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class *jrt.Class



type A_arbace_core_server_eval1213000008_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000008_A_New() *A_arbace_core_server_eval1213000008_A { t := &A_arbace_core_server_eval1213000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000008_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000008_A_class }

func (t *A_arbace_core_server_eval1213000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000008_A); return ok }

func A_arbace_core_server_eval1213000008_A_Cast(x any) *A_arbace_core_server_eval1213000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000008_A_class)) }; return v }



type A_arbace_core_server_eval1213000008_fn__1213000009_A struct{ j2g_header uint64 }

var A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class *jrt.Class



type A_arbace_core_server_ex__GT_data_A struct{ j2g_header uint64 }

var A_arbace_core_server_ex__GT_data_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_io_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_fn__1213000112_A struct{ j2g_header uint64; F_lock, F_out, F_valf any }

var A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A struct{ j2g_header uint64; F_m, F_valf any }

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class *jrt.Class



type A_arbace_core_server_parse_props_A struct{ j2g_header uint64 }

var A_arbace_core_server_parse_props_A_fn_class *jrt.Class



type A_arbace_core_server_parse_props_fn__1213000072_A struct{ j2g_header uint64; F_props any }

var A_arbace_core_server_parse_props_fn__1213000072_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000096_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_fn__1213000096_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000098_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_fn__1213000098_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000100_A struct{ j2g_header uint64; F_EOF, F_out_fn, F_in_reader any }

var A_arbace_core_server_prepl_fn__1213000100_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_tapfn__1213000094_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_remote_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A struct{ j2g_header uint64 }

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_fn__1213000128_A struct{ j2g_header uint64; F_rd, F_readf, F_wr, F_EOF, F_out_fn, F_valf any }

var A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A struct{ j2g_header uint64; F_m, F_valf, F_val any }

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class *jrt.Class



type A_arbace_core_server_repl_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_A_fn_class *jrt.Class



type A_arbace_core_server_repl_init_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_init_A_fn_class *jrt.Class



type A_arbace_core_server_repl_read_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_read_A_fn_class *jrt.Class



type A_arbace_core_server_required_A struct{ j2g_header uint64 }

var A_arbace_core_server_required_A_fn_class *jrt.Class



type A_arbace_core_server_resolve_fn_A struct{ j2g_header uint64 }

var A_arbace_core_server_resolve_fn_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_A struct{ j2g_header uint64 }

var A_arbace_core_server_start_server_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000049_A struct{ j2g_header uint64; F_name, F_socket, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_start_server_fn__1213000049_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_A struct{ j2g_header uint64; F_name, F_socket, F_client_daemon, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A struct{ j2g_header uint64; F_name, F_socket any; F_client_counter int64; F_client_daemon, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A struct{ j2g_header uint64; F_in, F_name, F_client_id, F_conn, F_out, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A struct{ j2g_header uint64; F_lockee__1213000018__auto__, F_name any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class *jrt.Class



type A_arbace_core_server_start_servers_A struct{ j2g_header uint64 }

var A_arbace_core_server_start_servers_A_fn_class *jrt.Class



type A_arbace_core_server_stop_server_A struct{ j2g_header uint64 }

var A_arbace_core_server_stop_server_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_A struct{ j2g_header uint64 }

var A_arbace_core_server_stop_servers_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_fn__1213000067_A struct{ j2g_header uint64; F_name any }

var A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_fn__1213000069_A struct{ j2g_header uint64; F_name any }

var A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class *jrt.Class



type A_arbace_core_server_thread_A struct{ j2g_header uint64 }

var A_arbace_core_server_thread_A_fn_class *jrt.Class



type A_arbace_core_server_validate_opts_A struct{ j2g_header uint64 }

var A_arbace_core_server_validate_opts_A_fn_class *jrt.Class



type A_arbace_core_server_with_lock_A struct{ j2g_header uint64 }

var A_arbace_core_server_with_lock_A_fn_class *jrt.Class
