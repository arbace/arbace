//line aot_arbace_core_server.ae:1
package aot_arbace_core_server

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_New() *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A { A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_Init(); t := &A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp28 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_5; tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp13); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_166)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_167)); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_168)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_169)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_170)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_171)); var tmp20 *lang.Var; lang.RT_Init(); tmp20 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp20).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_172)); var tmp21 *lang.Var; lang.RT_Init(); tmp21 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp21).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_173)); var tmp22 *lang.Var; lang.RT_Init(); tmp22 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp22).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_174)); var tmp23 *lang.Var; lang.RT_Init(); tmp23 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp23).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_175)); var tmp24 *lang.Var; lang.RT_Init(); tmp24 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp24).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_176)); var tmp25 *lang.Var; lang.RT_Init(); tmp25 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp25).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_177)); var tmp26 *lang.Var; lang.RT_Init(); tmp26 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp26).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_178)); var tmp27 *lang.Var; lang.RT_Init(); tmp27 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp27).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_28)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp28 != nil { panic(tmp28) }; return tmp3 }
//line :9:1
func A_arbace_core_server_eval1213000008_fn__1213000009_A_New() *A_arbace_core_server_eval1213000008_fn__1213000009_A { A_arbace_core_server_eval1213000008_fn__1213000009_A_Init(); t := &A_arbace_core_server_eval1213000008_fn__1213000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_7; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_10; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_8; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_9; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }




















func A_arbace_core_server_with_lock_A_New() *A_arbace_core_server_with_lock_A { A_arbace_core_server_with_lock_A_Init(); t := &A_arbace_core_server_with_lock_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_core_server_with_lock_A) Ctor() {}
//line :30:1
func (t *A_arbace_core_server_with_lock_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, lock_expr__2, body__3 any) any { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_14; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_16; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_core_server_A_Init(); tmp15 = A_arbace_core_server_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_12; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_core_server_A_Init(); tmp19 = A_arbace_core_server_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_core_server_A_Init(); tmp21 = A_arbace_core_server_A_const_17; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_core_server_A_Init(); tmp23 = A_arbace_core_server_A_const_13; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_core_server_A_Init(); tmp25 = A_arbace_core_server_A_const_18; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_core_server_A_Init(); tmp27 = A_arbace_core_server_A_const_19; var tmp28 any = tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(lock_expr__2, tmp27)))))); var tmp29 *lang.Var; A_arbace_core_server_A_Init(); tmp29 = A_arbace_core_server_A_const_13; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_core_server_A_Init(); tmp31 = A_arbace_core_server_A_const_11; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_core_server_A_Init(); tmp33 = A_arbace_core_server_A_const_12; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_core_server_A_Init(); tmp35 = A_arbace_core_server_A_const_13; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 any; A_arbace_core_server_A_Init(); tmp37 = A_arbace_core_server_A_const_20; var tmp38 any = tmp36.Invoke_O__O(tmp37); var tmp39 *lang.Var; A_arbace_core_server_A_Init(); tmp39 = A_arbace_core_server_A_const_13; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; A_arbace_core_server_A_Init(); tmp41 = A_arbace_core_server_A_const_17; var tmp42 any = tmp30.Invoke_O__O(tmp32.Invoke_O__O(tmp34.Invoke_O_O__O(tmp38, tmp40.Invoke_O__O(tmp41)))); var tmp43 *lang.Var; A_arbace_core_server_A_Init(); tmp43 = A_arbace_core_server_A_const_13; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_core_server_A_Init(); tmp45 = A_arbace_core_server_A_const_11; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_core_server_A_Init(); tmp47 = A_arbace_core_server_A_const_12; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_core_server_A_Init(); tmp49 = A_arbace_core_server_A_const_13; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 any; A_arbace_core_server_A_Init(); tmp51 = A_arbace_core_server_A_const_21; var tmp52 any = tmp50.Invoke_O__O(tmp51); var tmp53 *lang.Var; A_arbace_core_server_A_Init(); tmp53 = A_arbace_core_server_A_const_13; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.Var; A_arbace_core_server_A_Init(); tmp55 = A_arbace_core_server_A_const_11; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_core_server_A_Init(); tmp57 = A_arbace_core_server_A_const_12; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_core_server_A_Init(); tmp59 = A_arbace_core_server_A_const_13; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_core_server_A_Init(); tmp61 = A_arbace_core_server_A_const_22; var tmp62 any = tmp60.Invoke_O__O(tmp61); var tmp63 *lang.Var; A_arbace_core_server_A_Init(); tmp63 = A_arbace_core_server_A_const_13; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Var; A_arbace_core_server_A_Init(); tmp65 = A_arbace_core_server_A_const_11; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Var; A_arbace_core_server_A_Init(); tmp67 = A_arbace_core_server_A_const_12; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Var; A_arbace_core_server_A_Init(); tmp69 = A_arbace_core_server_A_const_13; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 any; A_arbace_core_server_A_Init(); tmp71 = A_arbace_core_server_A_const_23; var tmp72 any = tmp70.Invoke_O__O(tmp71); var tmp73 *lang.Var; A_arbace_core_server_A_Init(); tmp73 = A_arbace_core_server_A_const_13; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 any; A_arbace_core_server_A_Init(); tmp75 = A_arbace_core_server_A_const_17; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(tmp8, tmp28, tmp42, tmp44.Invoke_O__O(tmp46.Invoke_O__O(tmp48.Invoke_O_O_O__O(tmp52, body__3, tmp54.Invoke_O__O(tmp56.Invoke_O__O(tmp58.Invoke_O_O__O(tmp62, tmp64.Invoke_O__O(tmp66.Invoke_O__O(tmp68.Invoke_O_O__O(tmp72, tmp74.Invoke_O__O(tmp75)))))))))))) }








func A_arbace_core_server_thread_A_New() *A_arbace_core_server_thread_A { A_arbace_core_server_thread_A_Init(); t := &A_arbace_core_server_thread_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_core_server_thread_A) Ctor() {}
//line :39:1
func (t *A_arbace_core_server_thread_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, daemon__3, body__4 any) any { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_13; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_24; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_11; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_12; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_core_server_A_Init(); tmp15 = A_arbace_core_server_A_const_13; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_25; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 *lang.Var; A_arbace_core_server_A_Init(); tmp19 = A_arbace_core_server_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_core_server_A_Init(); tmp21 = A_arbace_core_server_A_const_11; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_core_server_A_Init(); tmp23 = A_arbace_core_server_A_const_12; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_core_server_A_Init(); tmp25 = A_arbace_core_server_A_const_13; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_core_server_A_Init(); tmp27 = A_arbace_core_server_A_const_26; var tmp28 any = tmp26.Invoke_O__O(tmp27); var tmp29 *lang.Var; A_arbace_core_server_A_Init(); tmp29 = A_arbace_core_server_A_const_13; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_core_server_A_Init(); tmp31 = A_arbace_core_server_A_const_15; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_core_server_A_Init(); tmp33 = A_arbace_core_server_A_const_16; var tmp34 any = jrt.NN(tmp33).GetRawRoot__O(); var tmp35 *lang.Var; A_arbace_core_server_A_Init(); tmp35 = A_arbace_core_server_A_const_11; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_core_server_A_Init(); tmp37 = A_arbace_core_server_A_const_12; var tmp38 any = tmp20.Invoke_O__O(tmp22.Invoke_O__O(tmp24.Invoke_O_O_O__O(tmp28, tmp30.Invoke_O__O(tmp32.Invoke_O_O__O(tmp34, tmp36.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke__O()))), body__4))); var tmp39 *lang.Var; A_arbace_core_server_A_Init(); tmp39 = A_arbace_core_server_A_const_13; var tmp40 any = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O_O_O__O(tmp18, tmp38, lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(name__2)))); var tmp41 *lang.Var; A_arbace_core_server_A_Init(); tmp41 = A_arbace_core_server_A_const_13; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_core_server_A_Init(); tmp43 = A_arbace_core_server_A_const_11; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_core_server_A_Init(); tmp45 = A_arbace_core_server_A_const_12; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_core_server_A_Init(); tmp47 = A_arbace_core_server_A_const_13; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 any; A_arbace_core_server_A_Init(); tmp49 = A_arbace_core_server_A_const_27; var tmp50 any = tmp48.Invoke_O__O(tmp49); var tmp51 *lang.Var; A_arbace_core_server_A_Init(); tmp51 = A_arbace_core_server_A_const_13; var tmp52 any = tmp42.Invoke_O__O(tmp44.Invoke_O__O(tmp46.Invoke_O_O__O(tmp50, lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(daemon__3)))); var tmp53 *lang.Var; A_arbace_core_server_A_Init(); tmp53 = A_arbace_core_server_A_const_13; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.Var; A_arbace_core_server_A_Init(); tmp55 = A_arbace_core_server_A_const_11; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_core_server_A_Init(); tmp57 = A_arbace_core_server_A_const_12; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Var; A_arbace_core_server_A_Init(); tmp59 = A_arbace_core_server_A_const_13; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_core_server_A_Init(); tmp61 = A_arbace_core_server_A_const_28; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(tmp8, tmp40, tmp52, tmp54.Invoke_O__O(tmp56.Invoke_O__O(tmp58.Invoke_O__O(tmp60.Invoke_O__O(tmp61)))))) }





func A_arbace_core_server_required_A_New() *A_arbace_core_server_required_A { A_arbace_core_server_required_A_Init(); t := &A_arbace_core_server_required_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_core_server_required_A) Ctor() {}
//line :45:1
func (t *A_arbace_core_server_required_A) Invoke_O_O_O__O(self, opts__0, prop__1 any) any {


	if lang.Util_Identical_O_O__Z(lang.RT_Get_O_O__O(opts__0, prop__1), nil) { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_29; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_205, nil), jrt.RefArrayOf(jrt.Object_class, nil, prop__1)).Ref(), opts__0)))) } else { return nil
	}
}
func A_arbace_core_server_validate_opts_A_New() *A_arbace_core_server_validate_opts_A { A_arbace_core_server_validate_opts_A_Init(); t := &A_arbace_core_server_validate_opts_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Invoke_O_O__O(self, p__1213000030__0 any) any { var map__1213000031__2 any = p__1213000030__0; var map__1213000031__3 any; if lang.ISeq_InstanceOf(map__1213000031__2) { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1213000031__2)) { var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_31; map__1213000031__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1213000031__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1213000031__2)) { var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_32; map__1213000031__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1213000031__2) } else { lang.PersistentArrayMap_Init(); map__1213000031__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000031__3 = map__1213000031__2 }; var opts__4 any = map__1213000031__3; var name__5 any; var tmp5 *lang.Keyword; _ = name__5; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_33; name__5 = lang.RT_Get_O_O__O(map__1213000031__3, tmp5.Ref()); var port__6 any; var tmp6 *lang.Keyword; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_34; port__6 = lang.RT_Get_O_O__O(map__1213000031__3, tmp6.Ref()); var accept__7 any; var tmp7 *lang.Keyword; _ = accept__7; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_35; accept__7 = lang.RT_Get_O_O__O(map__1213000031__3, tmp7.Ref()); var seq_1213000033__8 any; var tmp8 *lang.Var;


	A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_11; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_39; seq_1213000033__8 = tmp9.Invoke_O__O(tmp10); var chunk_1213000034__9 any; var count_1213000035__10 int64 = 0; var i_1213000036__11 int64 = 0; L1:
//line :51:1
	for {


		if lang.Numbers_Lt_J_J__Z(i_1213000036__11, count_1213000035__10) { var prop__12 any = lang.Indexed_Cast(chunk_1213000034__9).Nth_I__O(lang.RT_IntCast_J__I(i_1213000036__11)); var tmp11 *lang.Var; A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_40; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(opts__4, prop__12); seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, lang.Numbers_Unchecked_inc_J__J(i_1213000036__11); continue L1 } else { var temp__1927000414__auto____12 any; var tmp12 *lang.Var; A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_11; temp__1927000414__auto____12 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_1213000033__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_1213000033__13 any = temp__1927000414__auto____12; var tmp13 *lang.Var; A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_1213000033__13)) { var c__1927000678__auto____14 any; var tmp14 *lang.Var; A_arbace_core_server_A_Init(); tmp14 = A_arbace_core_server_A_const_38; c__1927000678__auto____14 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_1213000033__13); var tmp15 *lang.Var; A_arbace_core_server_A_Init(); tmp15 = A_arbace_core_server_A_const_41; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_1213000033__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var prop__14 any; var tmp16 *lang.Var; A_arbace_core_server_A_Init(); tmp16 = A_arbace_core_server_A_const_32; prop__14 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1213000033__13); var tmp17 *lang.Var; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_40; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(opts__4, prop__14); var tmp18 *lang.Var; A_arbace_core_server_A_Init(); tmp18 = A_arbace_core_server_A_const_30; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_1213000033__13), nil, 0, 0; continue L1 } } }
//line :51:1
		break L1 }; var tmp19 any; var or__1927000174__auto____8 any; var tmp20 /*line :55:1*/*lang.Var; A_arbace_core_server_A_Init(); tmp20 = A_arbace_core_server_A_const_36; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_core_server_A_Init(); tmp22 = A_arbace_core_server_A_const_42; or__1927000174__auto____8 = tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(port__6)); if jrt.A2g_Truth(or__1927000174__auto____8) { tmp19 = or__1927000174__auto____8 } else { var tmp23 *lang.Var; A_arbace_core_server_A_Init(); tmp23 = A_arbace_core_server_A_const_36; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_core_server_A_Init(); tmp25 = A_arbace_core_server_A_const_43; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_core_server_A_Init(); tmp27 = A_arbace_core_server_A_const_44; var tmp28 any = tmp27; var tmp29 any; A_arbace_core_server_A_Init(); tmp29 = A_arbace_core_server_A_const_45; tmp19 = tmp24.Invoke_O__O(tmp26.Invoke_O_O_O__O(tmp28, port__6, tmp29)) }; if jrt.A2g_Truth(tmp19) { var tmp30 *lang.Var; A_arbace_core_server_A_Init(); tmp30 = A_arbace_core_server_A_const_29; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_224, nil), jrt.RefArrayOf(jrt.Object_class, nil, port__6)).Ref(), opts__4)))) } else { return nil } }


func A_arbace_core_server_accept_connection_A_New() *A_arbace_core_server_accept_connection_A { A_arbace_core_server_accept_connection_A_Init(); t := &A_arbace_core_server_accept_connection_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Ctor() {}
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Invoke_O_O_O_O_O_O_O_O_O__O(self, conn__0, name__1, client_id__2, in__3, out__4, err__5, accept__6, args__7 any) any { var tmp1 any; tmp30 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp29 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











	{ var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_48; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_49; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_50; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_51; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_52; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_53; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Keyword; A_arbace_core_server_A_Init(); tmp14 = A_arbace_core_server_A_const_54; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_core_server_A_Init(); tmp16 = A_arbace_core_server_A_const_55; tmp3.Invoke_O__O(tmp5.Invoke_O_O_O_O_O_O_O_O__O(tmp7, in__3, tmp9, out__4, tmp11, err__5, tmp13, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, name__1, tmp16.Ref(), client_id__2)))); tmp27 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :58:1
		{ var lockee__1213000018__auto____13 any; var tmp17 *lang.Var; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_56; lockee__1213000018__auto____13 = jrt.NN(tmp17).GetRawRoot__O()















			jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____13)).Lock__V(); var tmp18 any = A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____13); var tmp19 *jrt.Class; A_arbace_core_server_accept_connection_fn__1213000038_A_Init(); tmp19 = A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O()

			var tmp20 *lang.Var; A_arbace_core_server_A_Init(); tmp20 = A_arbace_core_server_A_const_1; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_core_server_A_Init(); tmp22 = A_arbace_core_server_A_const_61; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_core_server_A_Init(); tmp24 = A_arbace_core_server_A_const_62; tmp21.Invoke_O__O(tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(accept__6)))
//line :58:1
			var accept_fn__13 any; var tmp25 *lang.Var


















			A_arbace_core_server_A_Init(); tmp25 = A_arbace_core_server_A_const_46; accept_fn__13 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(accept__6)
			var tmp26 *lang.Var; A_arbace_core_server_A_Init(); tmp26 = A_arbace_core_server_A_const_15; tmp1 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O__O(accept_fn__13, args__7) }
//line :70:1
		return nil }(); var tmp28 *lang.Var; A_arbace_core_server_A_Init(); tmp28 = A_arbace_core_server_A_const_47; lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke__O()
//line :58:1
		if tmp27 != nil { panic(tmp27) } }; return nil }(); if tmp29 != nil { if jrt.SocketException_InstanceOf(tmp29) { var _disconnect__11 jrt.SocketException_I = jrt.SocketException_Cast(tmp29); _ = _disconnect__11; tmp1 = nil } else { panic(tmp29) } } }; return nil }(); var lockee__1213000018__auto____11 any; var tmp31 *lang.Var; A_arbace_core_server_A_Init(); tmp31 = A_arbace_core_server_A_const_56; lockee__1213000018__auto____11 = jrt.NN(tmp31).GetRawRoot__O();






















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____11)).Lock__V(); var tmp32 any = A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____11); var tmp33 *jrt.Class; A_arbace_core_server_accept_connection_fn__1213000040_A_Init(); tmp33 = A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil).Invoke__O();

	jrt.Socket_Cast(conn__0).Close__V(); if /*line :58:1*/ tmp30 != nil { panic(tmp30) }; return tmp1 }















func A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000038_A { A_arbace_core_server_accept_connection_fn__1213000038_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000038_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Invoke_O__O(self any) any { var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_57; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_58; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_59; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 any; var t_ any = t.F_name; t.F_name = nil; tmp8 = t_; var tmp9 any = tmp8; var tmp10 *lang.Keyword; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_60; var tmp11 any = tmp10.Ref(); var tmp12 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp12 = t__2; var tmp13 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, tmp11, tmp12); var tmp14 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp14 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp13, tmp14.Ref()) }
//line :74:1
	return nil }(); var tmp16 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp16 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp16)).Unlock__V(); if tmp15 != nil { panic(tmp15) }; return tmp1 }






func A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000040_A { A_arbace_core_server_accept_connection_fn__1213000040_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000040_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Invoke_O__O(self any) any { var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_57; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_58; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_63; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 any; var t_ any = t.F_name; t.F_name = nil; tmp8 = t_; var tmp9 any = tmp8; var tmp10 *lang.Keyword; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_60; var tmp11 any = lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Ref()); var tmp12 *lang.Var; A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_64; var tmp13 any = jrt.NN(tmp12).GetRawRoot__O(); var tmp14 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp14 = t__2; tmp1 = tmp3.Invoke_O_O_O_O_O__O(tmp5, tmp7, tmp11, tmp13, tmp14) }
//line :81:1
	return nil }(); var tmp16 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp16 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp16)).Unlock__V(); if tmp15 != nil { panic(tmp15) }; return tmp1 }



func A_arbace_core_server_start_server_A_New() *A_arbace_core_server_start_server_A { A_arbace_core_server_start_server_A_Init(); t := &A_arbace_core_server_start_server_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_core_server_start_server_A) Ctor() {}
//line :85:1
func (t *A_arbace_core_server_start_server_A) Invoke_O_O__O(self, opts__0 any) any {











	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_70; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(opts__0)
//line :85:1
	var default__1213000045__2 any; jrt.Boolean_Init(); default__1213000045__2 = jrt.Boolean_TRUE.Ref(); var default__1213000046__3 any; jrt.Boolean_Init(); default__1213000046__3 = jrt.Boolean_TRUE.Ref(); var default__1213000047__4 any; jrt.Boolean_Init(); default__1213000047__4 = jrt.Boolean_TRUE.Ref(); var map__1213000043__5 any = opts__0; var map__1213000043__6 any












	if lang.ISeq_InstanceOf(map__1213000043__5) { var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1213000043__5)) { var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_31; map__1213000043__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1213000043__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1213000043__5)) { var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_32; map__1213000043__6 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1213000043__5) } else { lang.PersistentArrayMap_Init(); map__1213000043__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000043__6 = map__1213000043__5 }
//line :85:1
	var address__7 any; var tmp6 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_65; address__7 = lang.RT_Get_O_O__O(map__1213000043__6, tmp6.Ref())
//line :85:1
	var port__8 any; var tmp7 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_34; port__8 = lang.RT_Get_O_O__O(map__1213000043__6, tmp7.Ref())
//line :85:1
	var name__9 any; var tmp8 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_33; name__9 = lang.RT_Get_O_O__O(map__1213000043__6, tmp8.Ref())
//line :85:1
	var accept__10 any; var tmp9 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_35; accept__10 = lang.RT_Get_O_O__O(map__1213000043__6, tmp9.Ref())
//line :85:1
	var args__11 any; var tmp10 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_66; args__11 = lang.RT_Get_O_O__O(map__1213000043__6, tmp10.Ref())
//line :85:1
	var bind_err__12 any; var tmp11 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_67; bind_err__12 = lang.RT_Get_O_O_O__O(map__1213000043__6, tmp11.Ref(), default__1213000045__2)
//line :85:1
	var server_daemon__13 any; var tmp12 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_68; server_daemon__13 = lang.RT_Get_O_O_O__O(map__1213000043__6, tmp12.Ref(), default__1213000046__3)
//line :85:1
	var client_daemon__14 any; var tmp13 *lang.Keyword












	A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_69; client_daemon__14 = lang.RT_Get_O_O_O__O(map__1213000043__6, tmp13.Ref(), default__1213000047__4)
//line :85:1
	var address__15 any = jrt.InetAddress_GetByName_String__InetAddress(jrt.String_Cast(address__7)); var socket__16 any = jrt.ServerSocket_New_I_I_InetAddress(lang.RT_IntCast_O__I(port__8), lang.RT_IntCast_J__I(0), jrt.InetAddress_Cast(address__15)); var lockee__1213000018__auto____17 any; var tmp14 *lang.Var; A_arbace_core_server_A_Init(); tmp14 = A_arbace_core_server_A_const_56; lockee__1213000018__auto____17 = jrt.NN(tmp14).GetRawRoot__O()


















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____17)).Lock__V(); var tmp15 any = A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(name__9, socket__16, lockee__1213000018__auto____17); var tmp16 *jrt.Class; A_arbace_core_server_start_server_fn__1213000049_A_Init(); tmp16 = A_arbace_core_server_start_server_fn__1213000049_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()
//line :85:1
	var G__1213000051__17_ any; var tmp17 any = A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(name__9, socket__16, client_daemon__14, args__11, bind_err__12, accept__10); var tmp18 *jrt.Class; A_arbace_core_server_start_server_fn__1213000052_A_Init(); tmp18 = A_arbace_core_server_start_server_fn__1213000052_A_fn_class; G__1213000051__17_ = jrt.Thread_New_Runnable_String(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_209, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__9)))




















	jrt.Thread_Cast(G__1213000051__17_).SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(server_daemon__13)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000051__17_).Start__V()
//line :85:1
	return socket__16
}

















func A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_start_server_fn__1213000049_A { A_arbace_core_server_start_server_fn__1213000049_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000049_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Ctor_O_O_O(c__name, c__socket, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_socket = c__socket; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp20 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_57; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_58; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_71; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 any = t.F_name; var tmp9 *lang.Keyword; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_33; var tmp10 any = tmp9.Ref(); var tmp11 any; var t_ any = t.F_name; t.F_name = nil; tmp11 = t_; var tmp12 any = tmp11; var tmp13 *lang.Keyword; A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_72; var tmp14 any = tmp13.Ref(); var tmp15 any; var t__2 any = t.F_socket; t.F_socket = nil; tmp15 = t__2; var tmp16 any = tmp15; var tmp17 *lang.Keyword; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_60; var tmp18 any = tmp17.Ref(); var tmp19 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp19 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp14, tmp16, tmp18, tmp19.Ref()))) }
//line :104:1
	return nil }(); var tmp21 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp21 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp21)).Unlock__V(); if tmp20 != nil { panic(tmp20) }; return tmp1 }

func A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_start_server_fn__1213000052_A { A_arbace_core_server_start_server_fn__1213000052_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Ctor_O_O_O_O_O_O(c__name, c__socket, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var client_counter__3 int64 = 1; L1: for {



	var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_36; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.ServerSocket_Cast(t.F_socket)).IsClosed__Z()).Ref())) {
		var tmp3 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(t.F_name, t.F_socket, client_counter__3, t.F_client_daemon, t.F_args, t.F_bind_err, t.F_accept); var tmp4 *jrt.Class; A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_Init(); tmp4 = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()








		client_counter__3 = lang.Numbers_Inc_J__J(client_counter__3); continue L1 } else {
//line :110:1
			tmp1 = nil }
//line :106:1
	break L1 } }; return nil }(); var lockee__1213000018__auto____3 any; var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_56; lockee__1213000018__auto____3 = jrt.NN(tmp6).GetRawRoot__O();















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____3)).Lock__V(); var tmp7 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(lockee__1213000018__auto____3, t.F_name); var tmp8 *jrt.Class; A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_Init(); tmp8 = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); if /*line :106:1*/ tmp5 != nil { panic(tmp5) }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(p0, p1 any, p2 int64, p3, p4, p5, p6 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A { A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A{}; t.Ctor_O_O_J_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Ctor_O_O_J_O_O_O_O(c__name, c__socket any, c__client_counter int64, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_counter = c__client_counter; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var conn__3 any; var tmp2 any; var t_ any = t.F_socket
													t.F_socket = nil; tmp2 = t_; conn__3 = jrt.NN(jrt.ServerSocket_Cast(tmp2)).Accept__Socket()
//line :111:1
	var in__4 any = lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(conn__3).GetInputStream__InputStream())); var out__5 any = jrt.BufferedWriter_New_Writer(jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(conn__3).GetOutputStream__OutputStream())); var client_id__6 any; var tmp3 *lang.Var



	A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_73; client_id__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(t.F_client_counter).Ref())
//line :111:1
	var G__1213000054__7_ any; var tmp4 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(in__4, t.F_name, client_id__6, conn__3, out__5, t.F_args, t.F_bind_err, t.F_accept); var tmp5 *jrt.Class; A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_Init(); tmp5 = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class; var tmp6 jrt.Runnable = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_213, nil, Lit_214, nil); var tmp8 any; var t__2 any = t.F_name





	t.F_name = nil; tmp8 = t__2
//line :111:1
	G__1213000054__7_ = jrt.Thread_New_Runnable_String(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, client_id__6)))




	var tmp9 jrt.Thread_I = jrt.Thread_Cast(G__1213000054__7_); var tmp10 any; var t__3 any = t.F_client_daemon; t.F_client_daemon = nil; tmp10 = t__3; tmp9.SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(tmp10)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000054__7_).Start__V()
//line :111:1
	tmp1 = G__1213000054__7_ }; return nil }(); if tmp11 != nil { if jrt.SocketException_InstanceOf(tmp11) { var _disconnect__3 jrt.SocketException_I = jrt.SocketException_Cast(tmp11); _ = _disconnect__3; tmp1 = nil } else { panic(tmp11) } }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A { A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Ctor_O_O_O_O_O_O_O_O(c__in, c__name, c__client_id, c__conn, c__out, c__args, c__bind_err, c__accept any) { t.F_in = c__in; t.F_name = c__name; t.F_client_id = c__client_id; t.F_conn = c__conn; t.F_out = c__out; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Invoke_O__O(self any) any {

	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_74; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_conn; var tmp4 any = t.F_name; var tmp5 any = t.F_client_id; var tmp6 any = t.F_in; var tmp7 any = t.F_out; var tmp8 any; if jrt.A2g_Truth(t.F_bind_err) { tmp8 = t.F_out } else { var tmp9 *lang.Var; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_52; tmp8 = jrt.NN(tmp9).Get__O() }; return tmp2.Invoke_O_O_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, t.F_accept, t.F_args)
}


func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(p0, p1 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A { A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A{}; t.Ctor_O_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Ctor_O_O(c__lockee__1213000018__auto__, c__name any) { t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__; t.F_name = c__name }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_57; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_58; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_64; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 any; var t_ any = t.F_name; t.F_name = nil; tmp8 = t_; tmp1 = tmp3.Invoke_O_O_O__O(tmp5, tmp7, tmp8) }
//line :122:1
	return nil }(); var tmp10 any; var t__2 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp10 = t__2; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp10)).Unlock__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }



func A_arbace_core_server_stop_server_A_New() *A_arbace_core_server_stop_server_A { A_arbace_core_server_stop_server_A_Init(); t := &A_arbace_core_server_stop_server_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Ctor() {}
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O_O__O(self, name__0 any) any { var lockee__1213000018__auto____2 any; var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_56; lockee__1213000018__auto____2 = jrt.NN(tmp1).GetRawRoot__O();






	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Lock__V(); var tmp2 any; tmp13 := /*line :126:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var server_socket__5 any; var tmp3 *lang.Var







		A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_75; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_58; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Keyword; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_72; server_socket__5 = tmp4.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(name__0, tmp7.Ref()))
		if jrt.A2g_Truth(server_socket__5) {
			var tmp8 *lang.Var; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_57; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_58; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_64; tmp9.Invoke_O_O_O__O(tmp11, jrt.NN(tmp12).GetRawRoot__O(), name__0)
			jrt.NN(jrt.ServerSocket_Cast(server_socket__5)).Close__V()
//line :135:1
			jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE.Ref() } else { tmp2 = nil } }; return nil }(); /*line :133:1*/jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Unlock__V(); if /*line :126:1*/ tmp13 != nil { panic(tmp13) }; return tmp2 }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O__O(self any) any {




	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_54; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_53; return tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O()))
}







func A_arbace_core_server_stop_servers_A_New() *A_arbace_core_server_stop_servers_A { A_arbace_core_server_stop_servers_A_Init(); t := &A_arbace_core_server_stop_servers_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Ctor() {}
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Invoke_O__O(self any) any { var lockee__1213000018__auto____1 any; var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_56; lockee__1213000018__auto____1 = jrt.NN(tmp1).GetRawRoot__O();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Lock__V(); var tmp2 any; tmp22 := /*line :140:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1213000063__4 any; var tmp3 *lang.Var



		A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_77; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_58; seq_1213000063__4 = tmp4.Invoke_O__O(tmp6.Invoke_O__O(jrt.NN(tmp7).GetRawRoot__O()))
//line :140:1
		var chunk_1213000064__5 any; var count_1213000065__6 int64 = 0; var i_1213000066__7 int64 = 0; L1: for {



			if lang.Numbers_Lt_J_J__Z(i_1213000066__7, count_1213000065__6) { var name__8 any = lang.Indexed_Cast(chunk_1213000064__5).Nth_I__O(lang.RT_IntCast_J__I(i_1213000066__7)); var tmp8 *lang.Var
				A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_78; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(name__8); var tmp11 *jrt.Class; A_arbace_core_server_stop_servers_fn__1213000067_A_Init(); tmp11 = A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class; tmp9.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))
//line :144:1
				seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, lang.Numbers_Unchecked_inc_J__J(i_1213000066__7); continue L1 } else { var temp__1927000414__auto____8 any; var tmp12 *lang.Var; A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_11; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_1213000063__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1213000063__9 any = temp__1927000414__auto____8; var tmp13 *lang.Var; A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_1213000063__9)) { var c__1927000678__auto____10 any; var tmp14 *lang.Var; A_arbace_core_server_A_Init(); tmp14 = A_arbace_core_server_A_const_38; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_1213000063__9); var tmp15 *lang.Var; A_arbace_core_server_A_Init(); tmp15 = A_arbace_core_server_A_const_41; seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_1213000063__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var name__10 any; var tmp16 *lang.Var; A_arbace_core_server_A_Init(); tmp16 = A_arbace_core_server_A_const_32; name__10 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1213000063__9)
					var tmp17 *lang.Var; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_78; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(name__10); var tmp20 *jrt.Class; A_arbace_core_server_stop_servers_fn__1213000069_A_Init(); tmp20 = A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class; tmp18.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil))
//line :144:1
					var tmp21 *lang.Var; A_arbace_core_server_A_Init(); tmp21 = A_arbace_core_server_A_const_30; seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_1213000063__9), nil, 0, 0; continue L1 } } else { tmp2 = nil } }
//line :140:1
			break L1 } }; return nil }();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Unlock__V(); if /*line :140:1*/ tmp22 != nil { panic(tmp22) }; return tmp2 }




func A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000067_A { A_arbace_core_server_stop_servers_fn__1213000067_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000067_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_name; t.F_name = nil; tmp3 = t_; return tmp2.Invoke_O__O(tmp3) }
//line :145:1
func A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000069_A { A_arbace_core_server_stop_servers_fn__1213000069_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000069_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_name; t.F_name = nil; tmp3 = t_; return tmp2.Invoke_O__O(tmp3) }

func A_arbace_core_server_parse_props_A_New() *A_arbace_core_server_parse_props_A { A_arbace_core_server_parse_props_A_Init(); t := &A_arbace_core_server_parse_props_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Ctor() {}
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Invoke_O_O__O(self, props__0 any) any {


	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_79; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_server_parse_props_fn__1213000072_A_New_O(props__0); var tmp4 *jrt.Class; A_arbace_core_server_parse_props_fn__1213000072_A_Init(); tmp4 = A_arbace_core_server_parse_props_fn__1213000072_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; var tmp7 any = tmp6.Ref(); return tmp2.Invoke_O_O_O__O(tmp5, tmp7, jrt.Properties_Cast(props__0).StringPropertyNames__Set()) }
func A_arbace_core_server_parse_props_fn__1213000072_A_New_O(p0 any) *A_arbace_core_server_parse_props_fn__1213000072_A { A_arbace_core_server_parse_props_fn__1213000072_A_Init(); t := &A_arbace_core_server_parse_props_fn__1213000072_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Ctor_O(c__props any) { t.F_props = c__props }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var vec__1213000073__3 any; var tmp1 *lang.Var;
													A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_80; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_81; vec__1213000073__3 = tmp2.Invoke_O_O__O(k__2, tmp3); var k1__4 any = /*line :151:1*/lang.RT_Nth_O_I_O__O(vec__1213000073__3, lang.RT_IntCast_J__I(0), nil); var k2__5 any = lang.RT_Nth_O_I_O__O(vec__1213000073__3, lang.RT_IntCast_J__I(1), nil); var k3__6 any = lang.RT_Nth_O_I_O__O(vec__1213000073__3, lang.RT_IntCast_J__I(2), nil); var tmp4 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(k1__4, Lit_186); if and__1927000168__auto____7 {

		tmp4 = lang.Util_Equiv_O_O__Z(k2__5, Lit_60) } else { tmp4 = and__1927000168__auto____7 }; if tmp4 { var v__7 any = lang.RT_Get_O_O__O(t.F_props, k__2); var tmp5 *lang.Var

			A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_8; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_82; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_33; var tmp10 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9.Ref(), k3__6)); var tmp11 *lang.Var; A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_83; return tmp6.Invoke_O_O__O(acc__1, tmp8.Invoke_O_O__O(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(v__7))) } else {
//line :153:1
				return acc__1 } }






func A_arbace_core_server_start_servers_A_New() *A_arbace_core_server_start_servers_A { A_arbace_core_server_start_servers_A_Init(); t := &A_arbace_core_server_start_servers_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Ctor() {}
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Invoke_O_O__O(self, system_props__0 any) any { { var seq_1213000078__2 any; var tmp1 *lang.Var


	A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_84; seq_1213000078__2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(system_props__0))
//line :160:1
	var chunk_1213000079__3 any; var count_1213000080__4 int64 = 0; var i_1213000081__5 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(i_1213000081__5, count_1213000080__4) { var server__6 any = lang.Indexed_Cast(chunk_1213000079__3).Nth_I__O(lang.RT_IntCast_J__I(i_1213000081__5)); var tmp4 *lang.Var
			A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_85; lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(server__6)
//line :163:1
			seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, lang.Numbers_Unchecked_inc_J__J(i_1213000081__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_11; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq_1213000078__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1213000078__7 any = temp__1927000414__auto____6; var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_1213000078__7)) { var c__1927000678__auto____8 any; var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_38; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_1213000078__7); var tmp8 *lang.Var; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_41; seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_1213000078__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var server__8 any; var tmp9 *lang.Var; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_32; server__8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_1213000078__7)
				var tmp10 *lang.Var; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_85; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(server__8)
//line :163:1
				var tmp11 *lang.Var; A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_30; seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_1213000078__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :160:1*/panic("a2g: unreachable") }





func A_arbace_core_server_repl_init_A_New() *A_arbace_core_server_repl_init_A { A_arbace_core_server_repl_init_A_Init(); t := &A_arbace_core_server_repl_init_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Ctor() {}
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_86; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_87; tmp2.Invoke_O__O(tmp3)
	var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_15; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_1; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 *lang.Var; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_88; return tmp5.Invoke_O_O__O(tmp7, jrt.NN(tmp8).GetRawRoot__O())
}
func A_arbace_core_server_repl_read_A_New() *A_arbace_core_server_repl_read_A { A_arbace_core_server_repl_read_A_Init(); t := &A_arbace_core_server_repl_read_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Ctor() {}
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Invoke_O_O_O__O(self, request_prompt__0, request_exit__1 any) any { var or__1927000174__auto____3 any; var tmp1 *lang.Keyword;


	A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_89; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, request_prompt__0, tmp3.Ref(), request_exit__1))); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_93; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_50; or__1927000174__auto____3 = tmp4.Invoke_O__O(tmp6.Invoke_O__O(jrt.NN(tmp7).Get__O())); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var input__4 any; var tmp8 *lang.Var

		A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_91; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_94; var tmp11 any = tmp10; var tmp12 *lang.Var; A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_50; input__4 = tmp9.Invoke_O_O__O(tmp11, jrt.NN(tmp12).Get__O())
		var tmp13 *lang.Var; A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_95; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_core_server_A_Init(); tmp15 = A_arbace_core_server_A_const_50; tmp14.Invoke_O__O(jrt.NN(tmp15).Get__O())
//line :175:1
		var G__1213000084__5_ any = input__4



		switch lang.Util_Hash_O__I(G__1213000084__5_) { case 1244597485: var tmp16 *lang.Keyword; A_arbace_core_server_A_Init(); tmp16 = A_arbace_core_server_A_const_92; if any(G__1213000084__5_) == any(tmp16.Ref()) { return request_exit__1 }; default:}; return input__4 } }



func A_arbace_core_server_repl_A_New() *A_arbace_core_server_repl_A { A_arbace_core_server_repl_A_Init(); t := &A_arbace_core_server_repl_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_server_repl_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_server_repl_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_96; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_97; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_98; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Keyword; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_99; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_100; return tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, tmp8, jrt.NN(tmp9).GetRawRoot__O())
}


func A_arbace_core_server_ex__GT_data_A_New() *A_arbace_core_server_ex__GT_data_A { A_arbace_core_server_ex__GT_data_A_Init(); t := &A_arbace_core_server_ex__GT_data_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Invoke_O_O_O__O(self, ex__0, phase__1 any) any {

	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_71; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_101; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(ex__0); var tmp5 *lang.Keyword; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_102; return tmp2.Invoke_O_O_O__O(tmp4, tmp5.Ref(), phase__1)
}
func A_arbace_core_server_prepl_A_New() *A_arbace_core_server_prepl_A { A_arbace_core_server_prepl_A_Init(); t := &A_arbace_core_server_prepl_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_core_server_prepl_A) Ctor() {}
//line :194:1
func (t *A_arbace_core_server_prepl_A) DoInvoke_O_O_O_O__O(self, in_reader__0, out_fn__1, p__1213000091__2 any) any { var map__1213000092__4 any = p__1213000091__2; var map__1213000092__5 any; if lang.ISeq_InstanceOf(map__1213000092__4) { var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1213000092__4)) { var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_31; map__1213000092__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1213000092__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1213000092__4)) { var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_32; map__1213000092__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1213000092__4) } else { lang.PersistentArrayMap_Init(); map__1213000092__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000092__5 = map__1213000092__4 }; var stdin__6 any; var tmp5 *lang.Keyword; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_103; stdin__6 = lang.RT_Get_O_O__O(map__1213000092__5, tmp5.Ref()); var cl__7 any; var tmp6 any = jrt.Thread_CurrentThread__Thread(); var tmp7 *jrt.Class;


























	A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_128; var tmp8 *jrt.Class = tmp7; cl__7 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp6, tmp8, Lit_188, jrt.RefArrayOf(jrt.Object_class)); var tmp9 any =
	jrt.Thread_CurrentThread__Thread(); var tmp10 *jrt.Class; A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_128; var tmp11 *jrt.Class = tmp10; lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp9, tmp11, Lit_189, jrt.RefArrayOf(jrt.Object_class, cl__7)); var EOF__7_ any = /*line :194:1*/jrt.Object_New(); var tapfn__8 any; var tmp12 any = A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(out_fn__1); var tmp13 *jrt.Class;




























	A_arbace_core_server_prepl_tapfn__1213000094_A_Init(); tmp13 = A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class; tapfn__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 /*line :225:1*/*lang.Var; A_arbace_core_server_A_Init(); tmp14 = A_arbace_core_server_A_const_48; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_core_server_A_Init(); tmp16 = A_arbace_core_server_A_const_49; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_core_server_A_Init(); tmp18 = A_arbace_core_server_A_const_119; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Var; A_arbace_core_server_A_Init(); tmp20 = A_arbace_core_server_A_const_119; var tmp21 any = jrt.NN(tmp20).Get__O(); var tmp22 *lang.Var; A_arbace_core_server_A_Init(); tmp22 = A_arbace_core_server_A_const_129; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_core_server_A_Init(); tmp24 = A_arbace_core_server_A_const_129; var tmp25 any = jrt.NN(tmp24).Get__O(); var tmp26 *lang.Var; A_arbace_core_server_A_Init(); tmp26 = A_arbace_core_server_A_const_130; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Var; A_arbace_core_server_A_Init(); tmp28 = A_arbace_core_server_A_const_130; var tmp29 any = jrt.NN(tmp28).Get__O(); var tmp30 *lang.Var; A_arbace_core_server_A_Init(); tmp30 = A_arbace_core_server_A_const_131; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Var; A_arbace_core_server_A_Init(); tmp32 = A_arbace_core_server_A_const_131; var tmp33 any = jrt.NN(tmp32).Get__O(); var tmp34 *lang.Var; A_arbace_core_server_A_Init(); tmp34 = A_arbace_core_server_A_const_132; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Var; A_arbace_core_server_A_Init(); tmp36 = A_arbace_core_server_A_const_132; var tmp37 any = jrt.NN(tmp36).Get__O(); var tmp38 *lang.Var; A_arbace_core_server_A_Init(); tmp38 = A_arbace_core_server_A_const_133; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Var; A_arbace_core_server_A_Init(); tmp40 = A_arbace_core_server_A_const_133; var tmp41 any = jrt.NN(tmp40).Get__O(); var tmp42 *lang.Var; A_arbace_core_server_A_Init(); tmp42 = A_arbace_core_server_A_const_134; var tmp43 any = tmp42.Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); var tmp46 *lang.Var; A_arbace_core_server_A_Init(); tmp46 = A_arbace_core_server_A_const_135; var tmp47 any = tmp46.Ref(); var tmp48 *lang.Var; A_arbace_core_server_A_Init(); tmp48 = A_arbace_core_server_A_const_135; var tmp49 any = jrt.NN(tmp48).Get__O(); var tmp50 *lang.Var; A_arbace_core_server_A_Init(); tmp50 = A_arbace_core_server_A_const_136; var tmp51 any = tmp50.Ref(); var tmp52 *lang.Var; A_arbace_core_server_A_Init(); tmp52 = A_arbace_core_server_A_const_136; var tmp53 any = jrt.NN(tmp52).Get__O(); var tmp54 *lang.Var; A_arbace_core_server_A_Init(); tmp54 = A_arbace_core_server_A_const_137; var tmp55 any = tmp54.Ref(); var tmp56 any = jrt.System_GetProperty_String_String__String(Lit_190, Lit_191).Ref(); var tmp57 *lang.Var; A_arbace_core_server_A_Init(); tmp57 = A_arbace_core_server_A_const_138; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Var; A_arbace_core_server_A_Init(); tmp59 = A_arbace_core_server_A_const_138; var tmp60 any = jrt.NN(tmp59).Get__O(); var tmp61 *lang.Var; A_arbace_core_server_A_Init(); tmp61 = A_arbace_core_server_A_const_139; var tmp62 any = tmp61.Ref(); var tmp63 *lang.Var; A_arbace_core_server_A_Init(); tmp63 = A_arbace_core_server_A_const_139; var tmp64 any = jrt.NN(tmp63).Get__O(); var tmp65 *lang.Var; A_arbace_core_server_A_Init(); tmp65 = A_arbace_core_server_A_const_140; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Var; A_arbace_core_server_A_Init(); tmp67 = A_arbace_core_server_A_const_140; var tmp68 any = jrt.NN(tmp67).Get__O(); var tmp69 *lang.Var; A_arbace_core_server_A_Init(); tmp69 = A_arbace_core_server_A_const_141; var tmp70 any = tmp69.Ref(); var tmp71 *lang.Var; A_arbace_core_server_A_Init(); tmp71 = A_arbace_core_server_A_const_141; var tmp72 any = jrt.NN(tmp71).Get__O(); var tmp73 *lang.Var; A_arbace_core_server_A_Init(); tmp73 = A_arbace_core_server_A_const_114; var tmp74 any = tmp73.Ref(); var tmp75 *lang.Var; A_arbace_core_server_A_Init(); tmp75 = A_arbace_core_server_A_const_113; var tmp76 any = tmp75.Ref(); var tmp77 *lang.Var; A_arbace_core_server_A_Init(); tmp77 = A_arbace_core_server_A_const_112; var tmp78 any = tmp77.Ref(); var tmp79 *lang.Var; A_arbace_core_server_A_Init(); tmp79 = A_arbace_core_server_A_const_120; tmp15.Invoke_O__O(tmp17.ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, tmp23, tmp25, tmp27, tmp29, tmp31, tmp33, tmp35, tmp37, tmp39, tmp41, tmp43, tmp45, tmp47, tmp49, tmp51, tmp53, tmp55, tmp56, tmp58, tmp60, tmp62, tmp64, tmp66, tmp68, tmp70, tmp72, tmp74, nil, tmp76, nil, tmp78, nil, tmp79.Ref(), nil))))); var tmp80 any; tmp120 := /*line :194:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)































		{ var tmp81 *lang.Var; A_arbace_core_server_A_Init(); tmp81 = A_arbace_core_server_A_const_86; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 any; A_arbace_core_server_A_Init(); tmp83 = A_arbace_core_server_A_const_142; tmp82.Invoke_O__O(tmp83)
			var tmp84 *lang.Var; A_arbace_core_server_A_Init(); tmp84 = A_arbace_core_server_A_const_48; var tmp85 lang.IFn = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()); var tmp86 *lang.Var; A_arbace_core_server_A_Init(); tmp86 = A_arbace_core_server_A_const_49; var tmp87 lang.IFn = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()); var tmp88 *lang.Var; A_arbace_core_server_A_Init(); tmp88 = A_arbace_core_server_A_const_143; var tmp89 any = tmp88.Ref(); var tmp90 *jrt.Boolean; jrt.Boolean_Init(); tmp90 = jrt.Boolean_TRUE; var tmp91 any = tmp90.Ref(); var tmp92 *lang.Var; A_arbace_core_server_A_Init(); tmp92 = A_arbace_core_server_A_const_50; var tmp93 any = tmp92.Ref(); var tmp94 any; var or__1927000174__auto____11 any = stdin__6
			if jrt.A2g_Truth(or__1927000174__auto____11) { tmp94 = or__1927000174__auto____11 } else { tmp94 = in_reader__0 }
//line :227:1
			var tmp95 any = tmp94; var tmp96 *lang.Var; A_arbace_core_server_A_Init(); tmp96 = A_arbace_core_server_A_const_51; var tmp97 any = tmp96.Ref(); var tmp98 *lang.Var; A_arbace_core_server_A_Init(); tmp98 = A_arbace_core_server_A_const_144; var tmp99 lang.IFn = lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()); var tmp100 any = A_arbace_core_server_prepl_fn__1213000096_A_New_O(out_fn__1); var tmp101 *jrt.Class; A_arbace_core_server_prepl_fn__1213000096_A_Init(); tmp101 = A_arbace_core_server_prepl_fn__1213000096_A_fn_class; var tmp102 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp100, tmp101, nil); var tmp103 *jrt.Boolean; jrt.Boolean_Init(); tmp103 = jrt.Boolean_TRUE; var tmp104 any = tmp99.Invoke_O_O_O__O(tmp102, nil, tmp103.Ref()); var tmp105 *lang.Var; A_arbace_core_server_A_Init(); tmp105 = A_arbace_core_server_A_const_52; var tmp106 any = tmp105.Ref(); var tmp107 *lang.Var; A_arbace_core_server_A_Init(); tmp107 = A_arbace_core_server_A_const_144; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 any = A_arbace_core_server_prepl_fn__1213000098_A_New_O(out_fn__1); var tmp110 *jrt.Class; A_arbace_core_server_prepl_fn__1213000098_A_Init(); tmp110 = A_arbace_core_server_prepl_fn__1213000098_A_fn_class; var tmp111 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp109, tmp110, nil); var tmp112 *jrt.Boolean; jrt.Boolean_Init(); tmp112 = jrt.Boolean_TRUE; tmp85.Invoke_O__O(tmp87.Invoke_O_O_O_O_O_O_O_O__O(tmp89, tmp91, tmp93, tmp95, tmp97, tmp104, tmp106, tmp108.Invoke_O_O_O__O(tmp111, nil, tmp112.Ref()))); tmp118 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







































				{ tmp116 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :232:1
					{ var tmp113 *lang.Var; A_arbace_core_server_A_Init(); tmp113 = A_arbace_core_server_A_const_147; lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()).Invoke_O__O(tapfn__8)
//line :194:1
					L1: for {







































						var tmp114 any = A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(EOF__7_, out_fn__1, in_reader__0); var tmp115 *jrt.Class; A_arbace_core_server_prepl_fn__1213000100_A_Init(); tmp115 = A_arbace_core_server_prepl_fn__1213000100_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp114, tmp115, nil).Invoke__O()) {






























							continue L1 } else {
//line :234:1
								tmp80 = nil }
//line :194:1
						break L1
					}
					}






































































					return nil }(); var tmp117 *lang.Var; A_arbace_core_server_A_Init(); tmp117 = A_arbace_core_server_A_const_127; lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()).Invoke_O__O(tapfn__8)
//line :194:1
					if tmp116 != nil { panic(tmp116)
					}
				}






























				return nil }(); var tmp119 *lang.Var; A_arbace_core_server_A_Init(); tmp119 = A_arbace_core_server_A_const_47; lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()).Invoke__O()
//line :194:1
			if tmp118 != nil { panic(tmp118) } }; return nil }(); var tmp121 *lang.Var;






























	A_arbace_core_server_A_Init(); tmp121 = A_arbace_core_server_A_const_47; lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()).Invoke__O(); if /*line :194:1*/ tmp120 != nil { panic(tmp120) }; return tmp80 }




























func A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(p0 any) *A_arbace_core_server_prepl_tapfn__1213000094_A { A_arbace_core_server_prepl_tapfn__1213000094_A_Init(); t := &A_arbace_core_server_prepl_tapfn__1213000094_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Invoke_O_O__O(self, p1__1213000088_SHARP___1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp2 *lang.Keyword; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_104; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_105; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_106; return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref(), p1__1213000088_SHARP___1)))
}



func A_arbace_core_server_prepl_fn__1213000096_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000096_A { A_arbace_core_server_prepl_fn__1213000096_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000096_A{}; t.Ctor_O(p0); return t }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Invoke_O_O__O(self, p1__1213000089_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp2 *lang.Keyword; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_104; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_145; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_106; return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref(), p1__1213000089_SHARP___1))) }
func A_arbace_core_server_prepl_fn__1213000098_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000098_A { A_arbace_core_server_prepl_fn__1213000098_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000098_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Invoke_O_O__O(self, p1__1213000090_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp2 *lang.Keyword; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_104; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_146; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_106; return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6.Ref(), p1__1213000090_SHARP___1))) }



func A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_prepl_fn__1213000100_A { A_arbace_core_server_prepl_fn__1213000100_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000100_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Ctor_O_O_O(c__EOF, c__out_fn, c__in_reader any) { t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_in_reader = c__in_reader }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp69 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1213000101__3 any; var tmp2 *lang.Var
										A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_107; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_109; var tmp5 any = tmp4.Ref(); var tmp6 any = t.F_EOF; var tmp7 *lang.Keyword; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_110; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Keyword; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_111; var tmp10 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp8, tmp9.Ref())); var tmp11 any; var t_ any = t.F_in_reader; t.F_in_reader = nil; tmp11 = t_; vec__1213000101__3 = tmp3.Invoke_O_O__O(tmp10, tmp11)
//line :234:1
	var form__4 any = lang.RT_Nth_O_I_O__O(vec__1213000101__3, lang.RT_IntCast_J__I(0), nil); var s__5 any = lang.RT_Nth_O_I_O__O(vec__1213000101__3, lang.RT_IntCast_J__I(1), nil); tmp42 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp12 any; var t__2 any = t.F_EOF; t.F_EOF = nil; tmp12 = t__2; if lang.Util_Identical_O_O__Z(form__4, tmp12) { tmp1 = nil } else { var start__8 int64 = jrt.System_NanoTime__J(); var ret__9 any; var tmp13 *lang.Var

			A_arbace_core_server_A_Init(); tmp13 = A_arbace_core_server_A_const_108; ret__9 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(form__4)
//line :237:1
			var ms__10 int64 = lang.Numbers_Quotient_J_J__J(lang.Numbers_Minus_J_J__J(jrt.System_NanoTime__J(), start__8), 1000000); var tmp14 *lang.Keyword



			A_arbace_core_server_A_Init(); tmp14 = A_arbace_core_server_A_const_92; if lang.Util_Equiv_O_O__Z(tmp14.Ref(), ret__9) { tmp1 = nil } else { var tmp15 *lang.Var; A_arbace_core_server_A_Init(); tmp15 = A_arbace_core_server_A_const_112; var tmp16 *lang.Var = tmp15; var tmp17 *lang.Var; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_113; jrt.NN(tmp16).Set_O__O(jrt.NN(tmp17).Get__O()); var tmp18 *lang.Var; A_arbace_core_server_A_Init(); tmp18 = A_arbace_core_server_A_const_113; var tmp19 *lang.Var = tmp18; var tmp20 *lang.Var; A_arbace_core_server_A_Init(); tmp20 = A_arbace_core_server_A_const_114; jrt.NN(tmp19).Set_O__O(jrt.NN(tmp20).Get__O()); var tmp21 *lang.Var; A_arbace_core_server_A_Init(); tmp21 = A_arbace_core_server_A_const_114; jrt.NN(tmp21).Set_O__O(ret__9)



				var tmp22 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp23 *lang.Keyword; A_arbace_core_server_A_Init(); tmp23 = A_arbace_core_server_A_const_104; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Keyword; A_arbace_core_server_A_Init(); tmp25 = A_arbace_core_server_A_const_115; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_core_server_A_Init(); tmp27 = A_arbace_core_server_A_const_106; var tmp28 any = tmp27.Ref(); var tmp29 any
				if jrt.Throwable_InstanceOf(ret__9) {
					var tmp30 *lang.Var; A_arbace_core_server_A_Init(); tmp30 = A_arbace_core_server_A_const_101; tmp29 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(ret__9) } else {
//line :246:1
						tmp29 = ret__9 }
//line :245:1
				var tmp31 any = tmp29; var tmp32 *lang.Keyword; A_arbace_core_server_A_Init(); tmp32 = A_arbace_core_server_A_const_116; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Var; A_arbace_core_server_A_Init(); tmp34 = A_arbace_core_server_A_const_73; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Var; A_arbace_core_server_A_Init(); tmp36 = A_arbace_core_server_A_const_119; var tmp37 any = tmp35.Invoke_O__O(lang.Namespace_Cast(jrt.NN(tmp36).Get__O()).F_name.Ref()); var tmp38 *lang.Keyword; A_arbace_core_server_A_Init(); tmp38 = A_arbace_core_server_A_const_117; var tmp39 any = tmp38.Ref(); var tmp40 any = jrt.Long_ValueOf_J__Long(ms__10).Ref(); var tmp41 *lang.Keyword; A_arbace_core_server_A_Init(); tmp41 = A_arbace_core_server_A_const_118; tmp22.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp26, tmp28, tmp31, tmp33, tmp37, tmp39, tmp40, tmp41.Ref(), s__5)))
//line :241:1
				jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() } } }
//line :234:1
		return nil }(); if tmp42 != nil { if true { var ex__8 jrt.Throwable_I = tmp42; var tmp43 *lang.Var; A_arbace_core_server_A_Init(); tmp43 = A_arbace_core_server_A_const_120; jrt.NN(tmp43).Set_O__O(ex__8)




















			var tmp44 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp45 *lang.Keyword; A_arbace_core_server_A_Init(); tmp45 = A_arbace_core_server_A_const_104; var tmp46 any = tmp45.Ref(); var tmp47 *lang.Keyword; A_arbace_core_server_A_Init(); tmp47 = A_arbace_core_server_A_const_115; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Keyword; A_arbace_core_server_A_Init(); tmp49 = A_arbace_core_server_A_const_106; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Var; A_arbace_core_server_A_Init(); tmp51 = A_arbace_core_server_A_const_121; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; var or__1927000174__auto____9 any; var tmp54 *lang.Keyword; A_arbace_core_server_A_Init(); tmp54 = A_arbace_core_server_A_const_123; var tmp55 *lang.Keyword = tmp54; var tmp56 *lang.Var; A_arbace_core_server_A_Init(); tmp56 = A_arbace_core_server_A_const_124; or__1927000174__auto____9 = jrt.NN(tmp55).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(ex__8)); if jrt.A2g_Truth(or__1927000174__auto____9) { tmp53 = or__1927000174__auto____9 } else { A_arbace_core_server_A_Init(); tmp53 = A_arbace_core_server_A_const_125.Ref() }; var tmp57 any = tmp52.Invoke_O_O__O(ex__8, tmp53); var tmp58 *lang.Keyword; A_arbace_core_server_A_Init(); tmp58 = A_arbace_core_server_A_const_116; var tmp59 any = tmp58.Ref(); var tmp60 *lang.Var; A_arbace_core_server_A_Init(); tmp60 = A_arbace_core_server_A_const_73; var tmp61 lang.IFn = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()); var tmp62 *lang.Var; A_arbace_core_server_A_Init(); tmp62 = A_arbace_core_server_A_const_119; var tmp63 any = tmp61.Invoke_O__O(lang.Namespace_Cast(jrt.NN(tmp62).Get__O()).F_name.Ref()); var tmp64 *lang.Keyword; A_arbace_core_server_A_Init(); tmp64 = A_arbace_core_server_A_const_118; var tmp65 any = tmp64.Ref(); var tmp66 *lang.Keyword; A_arbace_core_server_A_Init(); tmp66 = A_arbace_core_server_A_const_122; var tmp67 any = tmp66.Ref(); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; tmp44.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, tmp50, tmp57, tmp59, tmp63, tmp65, s__5, tmp67, tmp68.Ref())))
//line :234:1
			jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() } } }; return nil }(); if tmp69 != nil { if true { var ex__3 jrt.Throwable_I = tmp69; var tmp70 *lang.Var; A_arbace_core_server_A_Init(); tmp70 = A_arbace_core_server_A_const_120; jrt.NN(tmp70).Set_O__O(ex__3)


























				var tmp71 any; var t__3 any = t.F_out_fn; t.F_out_fn = nil; tmp71 = t__3; var tmp72 lang.IFn = lang.IFn_Cast(tmp71); var tmp73 *lang.Keyword; A_arbace_core_server_A_Init(); tmp73 = A_arbace_core_server_A_const_104; var tmp74 any = tmp73.Ref(); var tmp75 *lang.Keyword; A_arbace_core_server_A_Init(); tmp75 = A_arbace_core_server_A_const_115; var tmp76 any = tmp75.Ref(); var tmp77 *lang.Keyword; A_arbace_core_server_A_Init(); tmp77 = A_arbace_core_server_A_const_106; var tmp78 any = tmp77.Ref(); var tmp79 *lang.Var; A_arbace_core_server_A_Init(); tmp79 = A_arbace_core_server_A_const_121; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Keyword; A_arbace_core_server_A_Init(); tmp81 = A_arbace_core_server_A_const_126; var tmp82 any = tmp80.Invoke_O_O__O(ex__3, tmp81.Ref()); var tmp83 *lang.Keyword; A_arbace_core_server_A_Init(); tmp83 = A_arbace_core_server_A_const_116; var tmp84 any = tmp83.Ref(); var tmp85 *lang.Var; A_arbace_core_server_A_Init(); tmp85 = A_arbace_core_server_A_const_73; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Var; A_arbace_core_server_A_Init(); tmp87 = A_arbace_core_server_A_const_119; var tmp88 any = tmp86.Invoke_O__O(lang.Namespace_Cast(jrt.NN(tmp87).Get__O()).F_name.Ref()); var tmp89 *lang.Keyword; A_arbace_core_server_A_Init(); tmp89 = A_arbace_core_server_A_const_122; var tmp90 any = tmp89.Ref(); var tmp91 *jrt.Boolean; jrt.Boolean_Init(); tmp91 = jrt.Boolean_TRUE; tmp72.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp74, tmp76, tmp78, tmp82, tmp84, tmp88, tmp90, tmp91.Ref())))
//line :234:1
				jrt.Boolean_Init(); tmp1 = jrt.Boolean_TRUE.Ref() } }; return tmp1 }


































func A_arbace_core_server_resolve_fn_A_New() *A_arbace_core_server_resolve_fn_A { A_arbace_core_server_resolve_fn_A_Init(); t := &A_arbace_core_server_resolve_fn_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Ctor() {}
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Invoke_O_O__O(self, valf__0 any) any {
	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_148; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(valf__0)) { var or__1927000174__auto____2 any; var tmp2 *lang.Var
		A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_46; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(valf__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var tmp3 *lang.Var
			A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_62; temp__1927000414__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(valf__0); if jrt.A2g_Truth(temp__1927000414__auto____3) { var nsname__4 any = temp__1927000414__auto____3; var tmp4 *lang.Var
				A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_61; tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(nsname__4))
				var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_46; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(valf__0) } else {
//line :272:1
					or__1927000174__auto____3 = nil }
//line :271:1
			if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_207, nil), jrt.RefArrayOf(jrt.Object_class, nil, valf__0))))) } } } else {
//line :270:1
				return valf__0
			}
}





func A_arbace_core_server_io_prepl_A_New() *A_arbace_core_server_io_prepl_A { A_arbace_core_server_io_prepl_A_Init(); t := &A_arbace_core_server_io_prepl_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) Ctor() {}
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) DoInvoke_O_O__O(self, p__1213000107__0 any) any { var default__1213000110__2 any; var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_149; default__1213000110__2 = jrt.NN(tmp1).GetRawRoot__O(); var map__1213000108__3 any = p__1213000107__0; var map__1213000108__4 any; if lang.ISeq_InstanceOf(map__1213000108__3) { var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1213000108__3)) { var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_31; map__1213000108__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1213000108__3), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1213000108__3)) { var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_32; map__1213000108__4 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1213000108__3) } else { lang.PersistentArrayMap_Init(); map__1213000108__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000108__4 = map__1213000108__3 }; var valf__5 any; var tmp6 *lang.Keyword; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_150; valf__5 = lang.RT_Get_O_O_O__O(map__1213000108__4, tmp6.Ref(), default__1213000110__2); var valf__6 any; var tmp7 *lang.Var;







	A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_151; valf__6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(valf__5); var out__7 any; var tmp8 /*line :278:1*/*lang.Var; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_51; out__7 = jrt.NN(tmp8).Get__O(); var lock__8 any = jrt.Object_New(); var tmp9 *lang.Var;










	A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_152; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_50; var tmp12 any = jrt.NN(tmp11).Get__O(); var tmp13 any = A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(lock__8, out__7, valf__6); var tmp14 *jrt.Class; A_arbace_core_server_io_prepl_fn__1213000112_A_Init(); tmp14 = A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class; return tmp10.Invoke_O_O__O(tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)) }
func A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_io_prepl_fn__1213000112_A { A_arbace_core_server_io_prepl_fn__1213000112_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Ctor_O_O_O(c__lock, c__out, c__valf any) { t.F_lock = c__lock; t.F_out = c__out; t.F_valf = c__valf }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_48; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_49; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_51; var tmp6 any = tmp5.Ref(); var tmp7 any = t.F_out; var tmp8 *lang.Var; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_154; var tmp9 any = tmp8.Ref(); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_155; var tmp13 any = tmp12.Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O_O_O__O(tmp6, tmp7, tmp9, tmp11, tmp13, tmp14.Ref()))
//line :290:1
	var tmp15 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var lockee__1927000360__auto____4 any = t.F_lock; var locklocal__1927000361__auto____7 any = lockee__1927000360__auto____4; lang.Compiler_Evaluator_MonitorEnter_O__V(locklocal__1927000361__auto____7); tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp16 *lang.Var; A_arbace_core_server_A_Init(); tmp16 = A_arbace_core_server_A_const_153; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; var tmp19 any; A_arbace_core_server_A_Init(); tmp19 = A_arbace_core_server_A_const_156; var tmp20 lang.IFn = lang.IFn_Cast(tmp19); var tmp21 *lang.Keyword; A_arbace_core_server_A_Init(); tmp21 = A_arbace_core_server_A_const_104; if jrt.A2g_Truth(tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(m__1))) {
			var tmp22 any = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(m__1, t.F_valf); var tmp23 *jrt.Class; A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_Init(); tmp23 = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class; tmp18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil).Invoke__O() } else {
//line :293:1
				tmp18 = m__1 }; tmp15 = tmp17.Invoke_O__O(tmp18) }
//line :290:1
		return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V(locklocal__1927000361__auto____7); if tmp24 != nil { panic(tmp24) } }; return nil }(); var tmp26 *lang.Var
	A_arbace_core_server_A_Init(); tmp26 = A_arbace_core_server_A_const_47; lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke__O()
//line :290:1
	if tmp25 != nil { panic(tmp25) }; return tmp15
}


func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(p0, p1 any) *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A { A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A{}; t.Ctor_O_O(p0, p1); return t }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Ctor_O_O(c__m, c__valf any) { t.F_m = c__m; t.F_valf = c__valf }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_71; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_m; var tmp5 *lang.Keyword; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_106; var tmp6 any = tmp5.Ref(); var tmp7 lang.IFn = lang.IFn_Cast(t.F_valf); var tmp8 *lang.Keyword; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_106; tmp1 = tmp3.Invoke_O_O_O__O(tmp4, tmp6, tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(t.F_m))) }
//line :294:1
	return nil }(); if tmp9 != nil { if true { var ex__3 jrt.Throwable_I = tmp9; var tmp10 *lang.Var


		A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_71; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; var t_ any = t.F_m; t.F_m = nil; tmp12 = t_; var tmp13 any = tmp12; var tmp14 *lang.Keyword; A_arbace_core_server_A_Init(); tmp14 = A_arbace_core_server_A_const_106; var tmp15 any = tmp14.Ref(); var tmp16 any; var t__2 any = t.F_valf; t.F_valf = nil; tmp16 = t__2; var tmp17 lang.IFn = lang.IFn_Cast(tmp16); var tmp18 *lang.Var; A_arbace_core_server_A_Init(); tmp18 = A_arbace_core_server_A_const_121; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_core_server_A_Init(); tmp20 = A_arbace_core_server_A_const_157; var tmp21 any = tmp17.Invoke_O__O(tmp19.Invoke_O_O__O(ex__3, tmp20.Ref())); var tmp22 *lang.Keyword; A_arbace_core_server_A_Init(); tmp22 = A_arbace_core_server_A_const_122; var tmp23 any = tmp22.Ref(); var tmp24 *jrt.Boolean; jrt.Boolean_Init(); tmp24 = jrt.Boolean_TRUE; tmp1 = tmp11.Invoke_O_O_O_O_O__O(tmp13, tmp15, tmp21, tmp23, tmp24.Ref()) } }; return tmp1 }



func A_arbace_core_server_remote_prepl_A_New() *A_arbace_core_server_remote_prepl_A { A_arbace_core_server_remote_prepl_A_Init(); t := &A_arbace_core_server_remote_prepl_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) DoInvoke_O_O_O_O_O_O__O(self, host__0, port__1, in_reader__2, out_fn__3, p__1213000119__4 any) any { var default__1213000122__6 any; var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_158; default__1213000122__6 = jrt.NN(tmp1).GetRawRoot__O(); var default__1213000123__7 any; var tmp2 any = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New(); var tmp3 *jrt.Class; A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_Init(); tmp3 = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class; default__1213000123__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var map__1213000120__8 any = p__1213000119__4; var map__1213000120__9 any; if lang.ISeq_InstanceOf(map__1213000120__8) { var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1213000120__8)) { var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_31; map__1213000120__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1213000120__8), jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 *lang.Var; A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(map__1213000120__8)) { var tmp7 *lang.Var; A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_32; map__1213000120__9 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(map__1213000120__8) } else { lang.PersistentArrayMap_Init(); map__1213000120__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000120__9 = map__1213000120__8 }; var valf__10 any; var tmp8 *lang.Keyword; A_arbace_core_server_A_Init(); tmp8 = A_arbace_core_server_A_const_150; valf__10 = lang.RT_Get_O_O_O__O(map__1213000120__9, tmp8.Ref(), default__1213000122__6); var readf__11 any; var tmp9 *lang.Keyword; A_arbace_core_server_A_Init(); tmp9 = A_arbace_core_server_A_const_159; readf__11 = lang.RT_Get_O_O_O__O(map__1213000120__9, tmp9.Ref(), default__1213000123__7); var valf__12 any; var tmp10 *lang.Var;












	A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_151; valf__12 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(valf__10); var readf__13 any; var tmp11 /*line :301:1*/*lang.Var;













	A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_151; readf__13 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(readf__11); var port__14 any; var tmp12 /*line :301:1*/*lang.Var;














	A_arbace_core_server_A_Init(); tmp12 = A_arbace_core_server_A_const_160; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(port__1)) { port__14 = jrt.Integer_ValueOf_String__Integer(jrt.String_Cast(port__1)).Ref() } else { port__14 = port__1 }; var socket__15 any = /*line :301:1*/jrt.Socket_New_String_I(jrt.String_Cast(host__0), lang.RT_IntCast_O__I(port__14)); var rd__16 any = lang.LineNumberingPushbackReader_New_Reader(jrt.BufferedReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(socket__15).GetInputStream__InputStream()))); var wr__17 any = jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(socket__15).GetOutputStream__OutputStream()); var EOF__18_ any = jrt.Object_New(); var G__1213000127__19_ any; var tmp13 any = A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(rd__16, readf__13, wr__17, EOF__18_, out_fn__3, valf__12); var tmp14 *jrt.Class; A_arbace_core_server_remote_prepl_fn__1213000128_A_Init(); tmp14 = A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class; G__1213000127__19_ = jrt.Thread_New_Runnable_String(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), Lit_197); var tmp15 jrt.Thread_I =



















	jrt.Thread_Cast(G__1213000127__19_); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; tmp15.SetDaemon_Z__V(jrt.NN(tmp16).BooleanValue__Z()); jrt.Thread_Cast(G__1213000127__19_).Start__V(); var buf__19 any; var tmp17 any;














	A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_161; buf__19 = lang.Numbers_Char_array_O__C1(tmp17).Ref(); var tmp18 any; tmp19 := /*line :301:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L1: for { var n__22 int32 = jrt.Reader_Cast(in_reader__2).Read_C1__I(jrt.A2g_CastArray[*jrt.CharArray](buf__19, jrt.Prim_char.ArrayClass()))





































		if lang.Util_Equiv_J_J__Z(int64(n__22), -1) { tmp18 = nil } else {
			jrt.OutputStreamWriter_Cast(wr__17).Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](buf__19, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I(0), n__22)
			jrt.OutputStreamWriter_Cast(wr__17).Flush__V()
			continue L1 }
//line :301:1
		break L1 }; return nil }();










































	jrt.PushbackReader_Cast(rd__16).Close__V(); if /*line :301:1*/ tmp19 != nil { panic(tmp19) }; return tmp18 }
//line :301:1
func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New() *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A { A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_Init(); t := &A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Invoke_O_O_O__O(self, p1__1213000117_SHARP___1, p2__1213000118_SHARP___2 any) any {











	var tmp1 *lang.Var; A_arbace_core_server_A_Init(); tmp1 = A_arbace_core_server_A_const_91; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return tmp2.Invoke_O_O_O__O(p1__1213000117_SHARP___1, tmp3.Ref(), p2__1213000118_SHARP___2)
}






func A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_remote_prepl_fn__1213000128_A { A_arbace_core_server_remote_prepl_fn__1213000128_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Ctor_O_O_O_O_O_O(c__rd, c__readf, c__wr, c__EOF, c__out_fn, c__valf any) { t.F_rd = c__rd; t.F_readf = c__readf; t.F_wr = c__wr; t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_valf = c__valf }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Invoke_O__O(self any) any { for { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L2: for { var map__1213000129__3 any = lang.IFn_Cast(t.F_readf).Invoke_O_O__O(t.F_rd, t.F_EOF); var map__1213000129__4 any

	if lang.ISeq_InstanceOf(map__1213000129__3) { var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1213000129__3)) { var tmp3 *lang.Var; A_arbace_core_server_A_Init(); tmp3 = A_arbace_core_server_A_const_31; map__1213000129__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1213000129__3), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_core_server_A_Init(); tmp4 = A_arbace_core_server_A_const_11; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1213000129__3)) { var tmp5 *lang.Var; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_32; map__1213000129__4 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1213000129__3) } else { lang.PersistentArrayMap_Init(); map__1213000129__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000129__4 = map__1213000129__3 }
//line :321:1
	var m__5 any = map__1213000129__4; var tag__6 any; var tmp6 *lang.Keyword

	A_arbace_core_server_A_Init(); tmp6 = A_arbace_core_server_A_const_104; tag__6 = lang.RT_Get_O_O__O(map__1213000129__4, tmp6.Ref())
//line :321:1
	var val__7 any; var tmp7 *lang.Keyword

	A_arbace_core_server_A_Init(); tmp7 = A_arbace_core_server_A_const_106; val__7 = lang.RT_Get_O_O__O(map__1213000129__4, tmp7.Ref())
	if lang.Util_Identical_O_O__Z(m__5, t.F_EOF) { tmp1 = nil } else {
		var tmp8 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp9 any; var tmp10 any
		A_arbace_core_server_A_Init(); tmp10 = A_arbace_core_server_A_const_162; if jrt.A2g_Truth(lang.IFn_Cast(tmp10).Invoke_O__O(tag__6)) {
			var tmp11 any = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(m__5, t.F_valf, val__7); var tmp12 *jrt.Class; A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_Init(); tmp12 = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O() } else {
//line :326:1
				tmp9 = m__5 }
//line :325:1
		tmp8.Invoke_O__O(tmp9)







		continue L2 }
//line :321:1
	break L2 }; return nil }()













	jrt.OutputStreamWriter_Cast(t.F_wr).Close__V()
//line :321:1
	if tmp13 != nil { panic(tmp13) }; return tmp1 }; panic("a2g: unreachable") }





func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A { A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Ctor_O_O_O(c__m, c__valf, c__val any) { t.F_m = c__m; t.F_valf = c__valf; t.F_val = c__val }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 *lang.Var; A_arbace_core_server_A_Init(); tmp2 = A_arbace_core_server_A_const_71; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_m; var tmp5 *lang.Keyword; A_arbace_core_server_A_Init(); tmp5 = A_arbace_core_server_A_const_106; var tmp6 any = tmp5.Ref(); var tmp7 any; var t_ any = t.F_valf; t.F_valf = nil; tmp7 = t_; var tmp8 lang.IFn = lang.IFn_Cast(tmp7); var tmp9 any; var t__2 any = t.F_val; t.F_val = nil; tmp9 = t__2; tmp1 = tmp3.Invoke_O_O_O__O(tmp4, tmp6, tmp8.Invoke_O__O(tmp9)) }
//line :327:1
	return nil }(); if tmp10 != nil { if true { var ex__3 jrt.Throwable_I = tmp10; var tmp11 *lang.Var


		A_arbace_core_server_A_Init(); tmp11 = A_arbace_core_server_A_const_71; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; var t__3 any = t.F_m; t.F_m = nil; tmp13 = t__3; var tmp14 any = tmp13; var tmp15 *lang.Keyword; A_arbace_core_server_A_Init(); tmp15 = A_arbace_core_server_A_const_106; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_core_server_A_Init(); tmp17 = A_arbace_core_server_A_const_121; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_core_server_A_Init(); tmp19 = A_arbace_core_server_A_const_163; var tmp20 any = tmp18.Invoke_O_O__O(ex__3, tmp19.Ref()); var tmp21 *lang.Keyword; A_arbace_core_server_A_Init(); tmp21 = A_arbace_core_server_A_const_122; var tmp22 any = tmp21.Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; tmp1 = tmp12.Invoke_O_O_O_O_O__O(tmp14, tmp16, tmp20, tmp22, tmp23.Ref()) } }; return tmp1 }




type A_arbace_core_server_A struct{ jrt.Object }

var A_arbace_core_server_A_const_0 *lang.Var

var A_arbace_core_server_A_const_1 *lang.Var

var A_arbace_core_server_A_const_2 any

var A_arbace_core_server_A_const_3 any

var A_arbace_core_server_A_const_4 any

var A_arbace_core_server_A_const_5 any

var A_arbace_core_server_A_const_6 *lang.Var

var A_arbace_core_server_A_const_7 *lang.Var

var A_arbace_core_server_A_const_8 *lang.Var

var A_arbace_core_server_A_const_9 any

var A_arbace_core_server_A_const_10 *lang.Var

var A_arbace_core_server_A_const_11 *lang.Var

var A_arbace_core_server_A_const_12 *lang.Var

var A_arbace_core_server_A_const_13 *lang.Var

var A_arbace_core_server_A_const_14 any

var A_arbace_core_server_A_const_15 *lang.Var

var A_arbace_core_server_A_const_16 *lang.Var

var A_arbace_core_server_A_const_17 any

var A_arbace_core_server_A_const_18 *lang.Var

var A_arbace_core_server_A_const_19 any

var A_arbace_core_server_A_const_20 any

var A_arbace_core_server_A_const_21 any

var A_arbace_core_server_A_const_22 any

var A_arbace_core_server_A_const_23 any

var A_arbace_core_server_A_const_24 any

var A_arbace_core_server_A_const_25 any

var A_arbace_core_server_A_const_26 any

var A_arbace_core_server_A_const_27 any

var A_arbace_core_server_A_const_28 any

var A_arbace_core_server_A_const_29 *lang.Var

var A_arbace_core_server_A_const_30 *lang.Var

var A_arbace_core_server_A_const_31 *lang.Var

var A_arbace_core_server_A_const_32 *lang.Var

var A_arbace_core_server_A_const_33 *lang.Keyword

var A_arbace_core_server_A_const_34 *lang.Keyword

var A_arbace_core_server_A_const_35 *lang.Keyword

var A_arbace_core_server_A_const_36 *lang.Var

var A_arbace_core_server_A_const_37 *lang.Var

var A_arbace_core_server_A_const_38 *lang.Var

var A_arbace_core_server_A_const_39 any

var A_arbace_core_server_A_const_40 *lang.Var

var A_arbace_core_server_A_const_41 *lang.Var

var A_arbace_core_server_A_const_42 *lang.Var

var A_arbace_core_server_A_const_43 *lang.Var

var A_arbace_core_server_A_const_44 any

var A_arbace_core_server_A_const_45 any

var A_arbace_core_server_A_const_46 *lang.Var

var A_arbace_core_server_A_const_47 *lang.Var

var A_arbace_core_server_A_const_48 *lang.Var

var A_arbace_core_server_A_const_49 *lang.Var

var A_arbace_core_server_A_const_50 *lang.Var

var A_arbace_core_server_A_const_51 *lang.Var

var A_arbace_core_server_A_const_52 *lang.Var

var A_arbace_core_server_A_const_53 *lang.Var

var A_arbace_core_server_A_const_54 *lang.Keyword

var A_arbace_core_server_A_const_55 *lang.Keyword

var A_arbace_core_server_A_const_56 *lang.Var

var A_arbace_core_server_A_const_57 *lang.Var

var A_arbace_core_server_A_const_58 *lang.Var

var A_arbace_core_server_A_const_59 *lang.Var

var A_arbace_core_server_A_const_60 *lang.Keyword

var A_arbace_core_server_A_const_61 *lang.Var

var A_arbace_core_server_A_const_62 *lang.Var

var A_arbace_core_server_A_const_63 *lang.Var

var A_arbace_core_server_A_const_64 *lang.Var

var A_arbace_core_server_A_const_65 *lang.Keyword

var A_arbace_core_server_A_const_66 *lang.Keyword

var A_arbace_core_server_A_const_67 *lang.Keyword

var A_arbace_core_server_A_const_68 *lang.Keyword

var A_arbace_core_server_A_const_69 *lang.Keyword

var A_arbace_core_server_A_const_70 *lang.Var

var A_arbace_core_server_A_const_71 *lang.Var

var A_arbace_core_server_A_const_72 *lang.Keyword

var A_arbace_core_server_A_const_73 *lang.Var

var A_arbace_core_server_A_const_74 *lang.Var

var A_arbace_core_server_A_const_75 *lang.Var

var A_arbace_core_server_A_const_76 *lang.Var

var A_arbace_core_server_A_const_77 *lang.Var

var A_arbace_core_server_A_const_78 *lang.Var

var A_arbace_core_server_A_const_79 *lang.Var

var A_arbace_core_server_A_const_80 *lang.Var

var A_arbace_core_server_A_const_81 any

var A_arbace_core_server_A_const_82 *lang.Var

var A_arbace_core_server_A_const_83 *lang.Var

var A_arbace_core_server_A_const_84 *lang.Var

var A_arbace_core_server_A_const_85 *lang.Var

var A_arbace_core_server_A_const_86 *lang.Var

var A_arbace_core_server_A_const_87 any

var A_arbace_core_server_A_const_88 *lang.Var

var A_arbace_core_server_A_const_89 *lang.Keyword

var A_arbace_core_server_A_const_90 *lang.Keyword

var A_arbace_core_server_A_const_91 *lang.Var

var A_arbace_core_server_A_const_92 *lang.Keyword

var A_arbace_core_server_A_const_93 *lang.Var

var A_arbace_core_server_A_const_94 any

var A_arbace_core_server_A_const_95 *lang.Var

var A_arbace_core_server_A_const_96 *lang.Var

var A_arbace_core_server_A_const_97 *lang.Keyword

var A_arbace_core_server_A_const_98 *lang.Var

var A_arbace_core_server_A_const_99 *lang.Keyword

var A_arbace_core_server_A_const_100 *lang.Var

var A_arbace_core_server_A_const_101 *lang.Var

var A_arbace_core_server_A_const_102 *lang.Keyword

var A_arbace_core_server_A_const_103 *lang.Keyword

var A_arbace_core_server_A_const_104 *lang.Keyword

var A_arbace_core_server_A_const_105 *lang.Keyword

var A_arbace_core_server_A_const_106 *lang.Keyword

var A_arbace_core_server_A_const_107 *lang.Var

var A_arbace_core_server_A_const_108 *lang.Var

var A_arbace_core_server_A_const_109 *lang.Keyword

var A_arbace_core_server_A_const_110 *lang.Keyword

var A_arbace_core_server_A_const_111 *lang.Keyword

var A_arbace_core_server_A_const_112 *lang.Var

var A_arbace_core_server_A_const_113 *lang.Var

var A_arbace_core_server_A_const_114 *lang.Var

var A_arbace_core_server_A_const_115 *lang.Keyword

var A_arbace_core_server_A_const_116 *lang.Keyword

var A_arbace_core_server_A_const_117 *lang.Keyword

var A_arbace_core_server_A_const_118 *lang.Keyword

var A_arbace_core_server_A_const_119 *lang.Var

var A_arbace_core_server_A_const_120 *lang.Var

var A_arbace_core_server_A_const_121 *lang.Var

var A_arbace_core_server_A_const_122 *lang.Keyword

var A_arbace_core_server_A_const_123 *lang.Keyword

var A_arbace_core_server_A_const_124 *lang.Var

var A_arbace_core_server_A_const_125 *lang.Keyword

var A_arbace_core_server_A_const_126 *lang.Keyword

var A_arbace_core_server_A_const_127 *lang.Var

var A_arbace_core_server_A_const_128 *jrt.Class

var A_arbace_core_server_A_const_129 *lang.Var

var A_arbace_core_server_A_const_130 *lang.Var

var A_arbace_core_server_A_const_131 *lang.Var

var A_arbace_core_server_A_const_132 *lang.Var

var A_arbace_core_server_A_const_133 *lang.Var

var A_arbace_core_server_A_const_134 *lang.Var

var A_arbace_core_server_A_const_135 *lang.Var

var A_arbace_core_server_A_const_136 *lang.Var

var A_arbace_core_server_A_const_137 *lang.Var

var A_arbace_core_server_A_const_138 *lang.Var

var A_arbace_core_server_A_const_139 *lang.Var

var A_arbace_core_server_A_const_140 *lang.Var

var A_arbace_core_server_A_const_141 *lang.Var

var A_arbace_core_server_A_const_142 any

var A_arbace_core_server_A_const_143 *lang.Var

var A_arbace_core_server_A_const_144 *lang.Var

var A_arbace_core_server_A_const_145 *lang.Keyword

var A_arbace_core_server_A_const_146 *lang.Keyword

var A_arbace_core_server_A_const_147 *lang.Var

var A_arbace_core_server_A_const_148 *lang.Var

var A_arbace_core_server_A_const_149 *lang.Var

var A_arbace_core_server_A_const_150 *lang.Keyword

var A_arbace_core_server_A_const_151 *lang.Var

var A_arbace_core_server_A_const_152 *lang.Var

var A_arbace_core_server_A_const_153 *lang.Var

var A_arbace_core_server_A_const_154 *lang.Var

var A_arbace_core_server_A_const_155 *lang.Var

var A_arbace_core_server_A_const_156 any

var A_arbace_core_server_A_const_157 *lang.Keyword

var A_arbace_core_server_A_const_158 *lang.Var

var A_arbace_core_server_A_const_159 *lang.Keyword

var A_arbace_core_server_A_const_160 *lang.Var

var A_arbace_core_server_A_const_161 any

var A_arbace_core_server_A_const_162 any

var A_arbace_core_server_A_const_163 *lang.Keyword

var A_arbace_core_server_A_init jrt.ClassInit

func A_arbace_core_server_A_Init() { if !A_arbace_core_server_A_init.Done() { A_arbace_core_server_A_init.Run(A_arbace_core_server_A_clinit) } }

func A_arbace_core_server_A_clinit() { A_arbace_core_server_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_server_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_server_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_server_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_core_server_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_core_server_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_core_server_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_core_server_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_core_server_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_core_server_A_const_9 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_core_server_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_core_server_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_core_server_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_core_server_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_core_server_A_const_14 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_22).Ref(); A_arbace_core_server_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_core_server_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_core_server_A_const_17 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref(); A_arbace_core_server_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_core_server_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref())); A_arbace_core_server_A_const_20 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(); A_arbace_core_server_A_const_21 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref(); A_arbace_core_server_A_const_22 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref(); A_arbace_core_server_A_const_23 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(); A_arbace_core_server_A_const_24 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(); A_arbace_core_server_A_const_25 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(); A_arbace_core_server_A_const_26 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_35).Ref(); A_arbace_core_server_A_const_27 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(); A_arbace_core_server_A_const_28 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(); A_arbace_core_server_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_core_server_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_core_server_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_core_server_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_core_server_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_core_server_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_core_server_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_core_server_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_core_server_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_core_server_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_core_server_A_const_39 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_44).Ref()); A_arbace_core_server_A_const_40 = lang.RT_Var_String_String__Var(Lit_13, Lit_48); A_arbace_core_server_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_core_server_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_core_server_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_core_server_A_const_44 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_core_server_A_const_45 = jrt.Long_ValueOf_J__Long(65535).Ref(); A_arbace_core_server_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_core_server_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_core_server_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_core_server_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_core_server_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_core_server_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_core_server_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_core_server_A_const_53 = lang.RT_Var_String_String__Var(Lit_13, Lit_59); A_arbace_core_server_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_core_server_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_core_server_A_const_56 = lang.RT_Var_String_String__Var(Lit_13, Lit_62); A_arbace_core_server_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_core_server_A_const_58 = lang.RT_Var_String_String__Var(Lit_13, Lit_64); A_arbace_core_server_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_core_server_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_core_server_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_core_server_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_core_server_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_core_server_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_core_server_A_const_65 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_core_server_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_core_server_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_core_server_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_core_server_A_const_69 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_core_server_A_const_70 = lang.RT_Var_String_String__Var(Lit_13, Lit_76); A_arbace_core_server_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_core_server_A_const_72 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_core_server_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_core_server_A_const_74 = lang.RT_Var_String_String__Var(Lit_13, Lit_79); A_arbace_core_server_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_core_server_A_const_76 = lang.RT_Var_String_String__Var(Lit_13, Lit_81); A_arbace_core_server_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_core_server_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_core_server_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_core_server_A_const_80 = lang.RT_Var_String_String__Var(Lit_3, Lit_85); A_arbace_core_server_A_const_81 = jrt.Pattern_Compile_String__Pattern(Lit_86).Ref(); A_arbace_core_server_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_core_server_A_const_83 = lang.RT_Var_String_String__Var(Lit_6, Lit_88); A_arbace_core_server_A_const_84 = lang.RT_Var_String_String__Var(Lit_13, Lit_89); A_arbace_core_server_A_const_85 = lang.RT_Var_String_String__Var(Lit_13, Lit_90); A_arbace_core_server_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_core_server_A_const_87 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(); A_arbace_core_server_A_const_88 = lang.RT_Var_String_String__Var(Lit_8, Lit_93); A_arbace_core_server_A_const_89 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_core_server_A_const_90 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_core_server_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_core_server_A_const_92 = lang.RT_Keyword_String_String__Keyword(Lit_97, Lit_98); A_arbace_core_server_A_const_93 = lang.RT_Var_String_String__Var(Lit_8, Lit_99); A_arbace_core_server_A_const_94 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref())); A_arbace_core_server_A_const_95 = lang.RT_Var_String_String__Var(Lit_8, Lit_102); A_arbace_core_server_A_const_96 = lang.RT_Var_String_String__Var(Lit_8, Lit_97); A_arbace_core_server_A_const_97 = lang.RT_Keyword_String_String__Keyword(nil, Lit_103); A_arbace_core_server_A_const_98 = lang.RT_Var_String_String__Var(Lit_13, Lit_104); A_arbace_core_server_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_96); A_arbace_core_server_A_const_100 = lang.RT_Var_String_String__Var(Lit_13, Lit_105); A_arbace_core_server_A_const_101 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_core_server_A_const_102 = lang.RT_Keyword_String_String__Keyword(nil, Lit_107); A_arbace_core_server_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_core_server_A_const_104 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_core_server_A_const_105 = lang.RT_Keyword_String_String__Keyword(nil, Lit_109); A_arbace_core_server_A_const_106 = lang.RT_Keyword_String_String__Keyword(nil, Lit_110); A_arbace_core_server_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_core_server_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_core_server_A_const_109 = lang.RT_Keyword_String_String__Keyword(nil, Lit_113); A_arbace_core_server_A_const_110 = lang.RT_Keyword_String_String__Keyword(nil, Lit_100); A_arbace_core_server_A_const_111 = lang.RT_Keyword_String_String__Keyword(nil, Lit_101); A_arbace_core_server_A_const_112 = lang.RT_Var_String_String__Var(Lit_0, Lit_114); A_arbace_core_server_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_115); A_arbace_core_server_A_const_114 = lang.RT_Var_String_String__Var(Lit_0, Lit_116); A_arbace_core_server_A_const_115 = lang.RT_Keyword_String_String__Keyword(nil, Lit_117); A_arbace_core_server_A_const_116 = lang.RT_Keyword_String_String__Keyword(nil, Lit_118); A_arbace_core_server_A_const_117 = lang.RT_Keyword_String_String__Keyword(nil, Lit_119); A_arbace_core_server_A_const_118 = lang.RT_Keyword_String_String__Keyword(nil, Lit_120); A_arbace_core_server_A_const_119 = lang.RT_Var_String_String__Var(Lit_0, Lit_121); A_arbace_core_server_A_const_120 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_core_server_A_const_121 = lang.RT_Var_String_String__Var(Lit_13, Lit_123); A_arbace_core_server_A_const_122 = lang.RT_Keyword_String_String__Keyword(nil, Lit_124); A_arbace_core_server_A_const_123 = lang.RT_Keyword_String_String__Keyword(Lit_125, Lit_107); A_arbace_core_server_A_const_124 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_core_server_A_const_125 = lang.RT_Keyword_String_String__Keyword(nil, Lit_127); A_arbace_core_server_A_const_126 = lang.RT_Keyword_String_String__Keyword(nil, Lit_128); A_arbace_core_server_A_const_127 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_core_server_A_const_128 = lang.RT_ClassForNameNonLoading_String__Class(Lit_130); A_arbace_core_server_A_const_129 = lang.RT_Var_String_String__Var(Lit_0, Lit_131); A_arbace_core_server_A_const_130 = lang.RT_Var_String_String__Var(Lit_0, Lit_132); A_arbace_core_server_A_const_131 = lang.RT_Var_String_String__Var(Lit_0, Lit_133); A_arbace_core_server_A_const_132 = lang.RT_Var_String_String__Var(Lit_0, Lit_134); A_arbace_core_server_A_const_133 = lang.RT_Var_String_String__Var(Lit_0, Lit_135); A_arbace_core_server_A_const_134 = lang.RT_Var_String_String__Var(Lit_0, Lit_136); A_arbace_core_server_A_const_135 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_core_server_A_const_136 = lang.RT_Var_String_String__Var(Lit_0, Lit_138); A_arbace_core_server_A_const_137 = lang.RT_Var_String_String__Var(Lit_0, Lit_139); A_arbace_core_server_A_const_138 = lang.RT_Var_String_String__Var(Lit_0, Lit_140); A_arbace_core_server_A_const_139 = lang.RT_Var_String_String__Var(Lit_0, Lit_141); A_arbace_core_server_A_const_140 = lang.RT_Var_String_String__Var(Lit_0, Lit_142); A_arbace_core_server_A_const_141 = lang.RT_Var_String_String__Var(Lit_143, Lit_144); A_arbace_core_server_A_const_142 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(); A_arbace_core_server_A_const_143 = lang.RT_Var_String_String__Var(Lit_0, Lit_145); A_arbace_core_server_A_const_144 = lang.RT_Var_String_String__Var(Lit_0, Lit_146); A_arbace_core_server_A_const_145 = lang.RT_Keyword_String_String__Keyword(nil, Lit_147); A_arbace_core_server_A_const_146 = lang.RT_Keyword_String_String__Keyword(nil, Lit_148); A_arbace_core_server_A_const_147 = lang.RT_Var_String_String__Var(Lit_0, Lit_149); A_arbace_core_server_A_const_148 = lang.RT_Var_String_String__Var(Lit_0, Lit_150); A_arbace_core_server_A_const_149 = lang.RT_Var_String_String__Var(Lit_0, Lit_151); A_arbace_core_server_A_const_150 = lang.RT_Keyword_String_String__Keyword(nil, Lit_152); A_arbace_core_server_A_const_151 = lang.RT_Var_String_String__Var(Lit_13, Lit_153); A_arbace_core_server_A_const_152 = lang.RT_Var_String_String__Var(Lit_13, Lit_154); A_arbace_core_server_A_const_153 = lang.RT_Var_String_String__Var(Lit_0, Lit_155); A_arbace_core_server_A_const_154 = lang.RT_Var_String_String__Var(Lit_0, Lit_156); A_arbace_core_server_A_const_155 = lang.RT_Var_String_String__Var(Lit_0, Lit_157); A_arbace_core_server_A_const_156 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref())).Ref(); A_arbace_core_server_A_const_157 = lang.RT_Keyword_String_String__Keyword(nil, Lit_158); A_arbace_core_server_A_const_158 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_core_server_A_const_159 = lang.RT_Keyword_String_String__Keyword(nil, Lit_159); A_arbace_core_server_A_const_160 = lang.RT_Var_String_String__Var(Lit_0, Lit_160); A_arbace_core_server_A_const_161 = jrt.Long_ValueOf_J__Long(1024).Ref(); A_arbace_core_server_A_const_162 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_117).Ref())).Ref(); A_arbace_core_server_A_const_163 = lang.RT_Keyword_String_String__Keyword(nil, Lit_161) }

func A_arbace_core_server_A_New() *A_arbace_core_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_A) Ctor() {}

func (t *A_arbace_core_server_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_A_class }

func (t *A_arbace_core_server_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_A); return ok }

func A_arbace_core_server_A_Cast(x any) *A_arbace_core_server_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_A_class)) }; return v }



type A_arbace_core_server_accept_connection_A struct{ jrt.Object }

func (t *A_arbace_core_server_accept_connection_A) Is_Compiler_AOTF8() {}

var A_arbace_core_server_accept_connection_A_fn_class *jrt.Class

var A_arbace_core_server_accept_connection_A_init jrt.ClassInit

func A_arbace_core_server_accept_connection_A_Init() { if !A_arbace_core_server_accept_connection_A_init.Done() { A_arbace_core_server_accept_connection_A_init.Run(A_arbace_core_server_accept_connection_A_clinit) } }

func A_arbace_core_server_accept_connection_A_clinit() { A_arbace_core_server_accept_connection_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_accept_connection_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_accept_connection_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_accept_connection_A_class }

func (t *A_arbace_core_server_accept_connection_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_accept_connection_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_accept_connection_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_accept_connection_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_accept_connection_A); return ok }

func A_arbace_core_server_accept_connection_A_Cast(x any) *A_arbace_core_server_accept_connection_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_accept_connection_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_accept_connection_A_class)) }; return v }



type A_arbace_core_server_accept_connection_fn__1213000038_A struct{ jrt.Object; F_name, F_client_id, F_lockee__1213000018__auto__ any }

func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class *jrt.Class

var A_arbace_core_server_accept_connection_fn__1213000038_A_init jrt.ClassInit

func A_arbace_core_server_accept_connection_fn__1213000038_A_Init() { if !A_arbace_core_server_accept_connection_fn__1213000038_A_init.Done() { A_arbace_core_server_accept_connection_fn__1213000038_A_init.Run(A_arbace_core_server_accept_connection_fn__1213000038_A_clinit) } }

func A_arbace_core_server_accept_connection_fn__1213000038_A_clinit() { A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_accept_connection_fn__1213000038_A_class }

func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_accept_connection_fn__1213000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_accept_connection_fn__1213000038_A); return ok }

func A_arbace_core_server_accept_connection_fn__1213000038_A_Cast(x any) *A_arbace_core_server_accept_connection_fn__1213000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_accept_connection_fn__1213000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_accept_connection_fn__1213000038_A_class)) }; return v }



type A_arbace_core_server_accept_connection_fn__1213000040_A struct{ jrt.Object; F_name, F_client_id, F_lockee__1213000018__auto__ any }

func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class *jrt.Class

var A_arbace_core_server_accept_connection_fn__1213000040_A_init jrt.ClassInit

func A_arbace_core_server_accept_connection_fn__1213000040_A_Init() { if !A_arbace_core_server_accept_connection_fn__1213000040_A_init.Done() { A_arbace_core_server_accept_connection_fn__1213000040_A_init.Run(A_arbace_core_server_accept_connection_fn__1213000040_A_clinit) } }

func A_arbace_core_server_accept_connection_fn__1213000040_A_clinit() { A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_accept_connection_fn__1213000040_A_class }

func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_accept_connection_fn__1213000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_accept_connection_fn__1213000040_A); return ok }

func A_arbace_core_server_accept_connection_fn__1213000040_A_Cast(x any) *A_arbace_core_server_accept_connection_fn__1213000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_accept_connection_fn__1213000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_accept_connection_fn__1213000040_A_class)) }; return v }



type A_arbace_core_server_eval1213000004_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000004_A_New() *A_arbace_core_server_eval1213000004_A { t := &A_arbace_core_server_eval1213000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000004_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000004_A_class }

func (t *A_arbace_core_server_eval1213000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000004_A); return ok }

func A_arbace_core_server_eval1213000004_A_Cast(x any) *A_arbace_core_server_eval1213000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000004_A_class)) }; return v }



type A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A struct{ jrt.Object }

func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class *jrt.Class

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_init jrt.ClassInit

func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_Init() { if !A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_init.Done() { A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_init.Run(A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_clinit) } }

func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_clinit() { A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_class }

func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A); return ok }

func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_Cast(x any) *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_class)) }; return v }



type A_arbace_core_server_eval1213000008_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000008_A_New() *A_arbace_core_server_eval1213000008_A { t := &A_arbace_core_server_eval1213000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000008_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000008_A_class }

func (t *A_arbace_core_server_eval1213000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000008_A); return ok }

func A_arbace_core_server_eval1213000008_A_Cast(x any) *A_arbace_core_server_eval1213000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000008_A_class)) }; return v }



type A_arbace_core_server_eval1213000008_fn__1213000009_A struct{ jrt.Object }

func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class *jrt.Class

var A_arbace_core_server_eval1213000008_fn__1213000009_A_init jrt.ClassInit

func A_arbace_core_server_eval1213000008_fn__1213000009_A_Init() { if !A_arbace_core_server_eval1213000008_fn__1213000009_A_init.Done() { A_arbace_core_server_eval1213000008_fn__1213000009_A_init.Run(A_arbace_core_server_eval1213000008_fn__1213000009_A_clinit) } }

func A_arbace_core_server_eval1213000008_fn__1213000009_A_clinit() { A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_179, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000008_fn__1213000009_A_class }

func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000008_fn__1213000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000008_fn__1213000009_A); return ok }

func A_arbace_core_server_eval1213000008_fn__1213000009_A_Cast(x any) *A_arbace_core_server_eval1213000008_fn__1213000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000008_fn__1213000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000008_fn__1213000009_A_class)) }; return v }



type A_arbace_core_server_ex__GT_data_A struct{ jrt.Object }

func (t *A_arbace_core_server_ex__GT_data_A) Is_Compiler_AOTF2() {}

var A_arbace_core_server_ex__GT_data_A_fn_class *jrt.Class

var A_arbace_core_server_ex__GT_data_A_init jrt.ClassInit

func A_arbace_core_server_ex__GT_data_A_Init() { if !A_arbace_core_server_ex__GT_data_A_init.Done() { A_arbace_core_server_ex__GT_data_A_init.Run(A_arbace_core_server_ex__GT_data_A_clinit) } }

func A_arbace_core_server_ex__GT_data_A_clinit() { A_arbace_core_server_ex__GT_data_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_ex__GT_data_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_ex__GT_data_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_ex__GT_data_A_class }

func (t *A_arbace_core_server_ex__GT_data_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_ex__GT_data_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_ex__GT_data_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_ex__GT_data_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_ex__GT_data_A); return ok }

func A_arbace_core_server_ex__GT_data_A_Cast(x any) *A_arbace_core_server_ex__GT_data_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_ex__GT_data_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_ex__GT_data_A_class)) }; return v }



type A_arbace_core_server_io_prepl_A struct{ jrt.Object }

func (t *A_arbace_core_server_io_prepl_A) Is_Compiler_AOTR0() {}

var A_arbace_core_server_io_prepl_A_fn_class *jrt.Class

var A_arbace_core_server_io_prepl_A_init jrt.ClassInit

func A_arbace_core_server_io_prepl_A_Init() { if !A_arbace_core_server_io_prepl_A_init.Done() { A_arbace_core_server_io_prepl_A_init.Run(A_arbace_core_server_io_prepl_A_clinit) } }

func A_arbace_core_server_io_prepl_A_clinit() { A_arbace_core_server_io_prepl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_core_server_io_prepl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_io_prepl_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_io_prepl_A_class }

func (t *A_arbace_core_server_io_prepl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_io_prepl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_io_prepl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_io_prepl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_io_prepl_A); return ok }

func A_arbace_core_server_io_prepl_A_Cast(x any) *A_arbace_core_server_io_prepl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_io_prepl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_io_prepl_A_class)) }; return v }



type A_arbace_core_server_io_prepl_fn__1213000112_A struct{ jrt.Object; F_lock, F_out, F_valf any }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class *jrt.Class

var A_arbace_core_server_io_prepl_fn__1213000112_A_init jrt.ClassInit

func A_arbace_core_server_io_prepl_fn__1213000112_A_Init() { if !A_arbace_core_server_io_prepl_fn__1213000112_A_init.Done() { A_arbace_core_server_io_prepl_fn__1213000112_A_init.Run(A_arbace_core_server_io_prepl_fn__1213000112_A_clinit) } }

func A_arbace_core_server_io_prepl_fn__1213000112_A_clinit() { A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_io_prepl_fn__1213000112_A_class }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_io_prepl_fn__1213000112_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_io_prepl_fn__1213000112_A); return ok }

func A_arbace_core_server_io_prepl_fn__1213000112_A_Cast(x any) *A_arbace_core_server_io_prepl_fn__1213000112_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_io_prepl_fn__1213000112_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_io_prepl_fn__1213000112_A_class)) }; return v }



type A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A struct{ jrt.Object; F_m, F_valf any }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class *jrt.Class

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_init jrt.ClassInit

func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_Init() { if !A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_init.Done() { A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_init.Run(A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_clinit) } }

func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_clinit() { A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_183, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_class }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A); return ok }

func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_Cast(x any) *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_class)) }; return v }



type A_arbace_core_server_parse_props_A struct{ jrt.Object }

func (t *A_arbace_core_server_parse_props_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_parse_props_A_fn_class *jrt.Class

var A_arbace_core_server_parse_props_A_init jrt.ClassInit

func A_arbace_core_server_parse_props_A_Init() { if !A_arbace_core_server_parse_props_A_init.Done() { A_arbace_core_server_parse_props_A_init.Run(A_arbace_core_server_parse_props_A_clinit) } }

func A_arbace_core_server_parse_props_A_clinit() { A_arbace_core_server_parse_props_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_184, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_parse_props_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_parse_props_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_parse_props_A_class }

func (t *A_arbace_core_server_parse_props_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_parse_props_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_parse_props_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_parse_props_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_parse_props_A); return ok }

func A_arbace_core_server_parse_props_A_Cast(x any) *A_arbace_core_server_parse_props_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_parse_props_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_parse_props_A_class)) }; return v }



type A_arbace_core_server_parse_props_fn__1213000072_A struct{ jrt.Object; F_props any }

func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Is_Compiler_AOTF2() {}

var A_arbace_core_server_parse_props_fn__1213000072_A_fn_class *jrt.Class

var A_arbace_core_server_parse_props_fn__1213000072_A_init jrt.ClassInit

func A_arbace_core_server_parse_props_fn__1213000072_A_Init() { if !A_arbace_core_server_parse_props_fn__1213000072_A_init.Done() { A_arbace_core_server_parse_props_fn__1213000072_A_init.Run(A_arbace_core_server_parse_props_fn__1213000072_A_clinit) } }

func A_arbace_core_server_parse_props_fn__1213000072_A_clinit() { A_arbace_core_server_parse_props_fn__1213000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_185, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_parse_props_fn__1213000072_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_parse_props_fn__1213000072_A_class }

func (t *A_arbace_core_server_parse_props_fn__1213000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_parse_props_fn__1213000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_parse_props_fn__1213000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_parse_props_fn__1213000072_A); return ok }

func A_arbace_core_server_parse_props_fn__1213000072_A_Cast(x any) *A_arbace_core_server_parse_props_fn__1213000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_parse_props_fn__1213000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_parse_props_fn__1213000072_A_class)) }; return v }



type A_arbace_core_server_prepl_A struct{ jrt.Object }

func (t *A_arbace_core_server_prepl_A) Is_Compiler_AOTR2() {}

var A_arbace_core_server_prepl_A_fn_class *jrt.Class

var A_arbace_core_server_prepl_A_init jrt.ClassInit

func A_arbace_core_server_prepl_A_Init() { if !A_arbace_core_server_prepl_A_init.Done() { A_arbace_core_server_prepl_A_init.Run(A_arbace_core_server_prepl_A_clinit) } }

func A_arbace_core_server_prepl_A_clinit() { A_arbace_core_server_prepl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_187, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_core_server_prepl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_prepl_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_prepl_A_class }

func (t *A_arbace_core_server_prepl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_prepl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_prepl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_prepl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_prepl_A); return ok }

func A_arbace_core_server_prepl_A_Cast(x any) *A_arbace_core_server_prepl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_prepl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_prepl_A_class)) }; return v }



type A_arbace_core_server_prepl_fn__1213000096_A struct{ jrt.Object; F_out_fn any }

func (t *A_arbace_core_server_prepl_fn__1213000096_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_prepl_fn__1213000096_A_fn_class *jrt.Class

var A_arbace_core_server_prepl_fn__1213000096_A_init jrt.ClassInit

func A_arbace_core_server_prepl_fn__1213000096_A_Init() { if !A_arbace_core_server_prepl_fn__1213000096_A_init.Done() { A_arbace_core_server_prepl_fn__1213000096_A_init.Run(A_arbace_core_server_prepl_fn__1213000096_A_clinit) } }

func A_arbace_core_server_prepl_fn__1213000096_A_clinit() { A_arbace_core_server_prepl_fn__1213000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_192, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_prepl_fn__1213000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_prepl_fn__1213000096_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_prepl_fn__1213000096_A_class }

func (t *A_arbace_core_server_prepl_fn__1213000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_prepl_fn__1213000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_prepl_fn__1213000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_prepl_fn__1213000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_prepl_fn__1213000096_A); return ok }

func A_arbace_core_server_prepl_fn__1213000096_A_Cast(x any) *A_arbace_core_server_prepl_fn__1213000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_prepl_fn__1213000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_prepl_fn__1213000096_A_class)) }; return v }



type A_arbace_core_server_prepl_fn__1213000098_A struct{ jrt.Object; F_out_fn any }

func (t *A_arbace_core_server_prepl_fn__1213000098_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_prepl_fn__1213000098_A_fn_class *jrt.Class

var A_arbace_core_server_prepl_fn__1213000098_A_init jrt.ClassInit

func A_arbace_core_server_prepl_fn__1213000098_A_Init() { if !A_arbace_core_server_prepl_fn__1213000098_A_init.Done() { A_arbace_core_server_prepl_fn__1213000098_A_init.Run(A_arbace_core_server_prepl_fn__1213000098_A_clinit) } }

func A_arbace_core_server_prepl_fn__1213000098_A_clinit() { A_arbace_core_server_prepl_fn__1213000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_193, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_prepl_fn__1213000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_prepl_fn__1213000098_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_prepl_fn__1213000098_A_class }

func (t *A_arbace_core_server_prepl_fn__1213000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_prepl_fn__1213000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_prepl_fn__1213000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_prepl_fn__1213000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_prepl_fn__1213000098_A); return ok }

func A_arbace_core_server_prepl_fn__1213000098_A_Cast(x any) *A_arbace_core_server_prepl_fn__1213000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_prepl_fn__1213000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_prepl_fn__1213000098_A_class)) }; return v }



type A_arbace_core_server_prepl_fn__1213000100_A struct{ jrt.Object; F_EOF, F_out_fn, F_in_reader any }

func (t *A_arbace_core_server_prepl_fn__1213000100_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_prepl_fn__1213000100_A_fn_class *jrt.Class

var A_arbace_core_server_prepl_fn__1213000100_A_init jrt.ClassInit

func A_arbace_core_server_prepl_fn__1213000100_A_Init() { if !A_arbace_core_server_prepl_fn__1213000100_A_init.Done() { A_arbace_core_server_prepl_fn__1213000100_A_init.Run(A_arbace_core_server_prepl_fn__1213000100_A_clinit) } }

func A_arbace_core_server_prepl_fn__1213000100_A_clinit() { A_arbace_core_server_prepl_fn__1213000100_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_prepl_fn__1213000100_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_prepl_fn__1213000100_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_prepl_fn__1213000100_A_class }

func (t *A_arbace_core_server_prepl_fn__1213000100_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_prepl_fn__1213000100_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_prepl_fn__1213000100_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_prepl_fn__1213000100_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_prepl_fn__1213000100_A); return ok }

func A_arbace_core_server_prepl_fn__1213000100_A_Cast(x any) *A_arbace_core_server_prepl_fn__1213000100_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_prepl_fn__1213000100_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_prepl_fn__1213000100_A_class)) }; return v }



type A_arbace_core_server_prepl_tapfn__1213000094_A struct{ jrt.Object; F_out_fn any }

func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class *jrt.Class

var A_arbace_core_server_prepl_tapfn__1213000094_A_init jrt.ClassInit

func A_arbace_core_server_prepl_tapfn__1213000094_A_Init() { if !A_arbace_core_server_prepl_tapfn__1213000094_A_init.Done() { A_arbace_core_server_prepl_tapfn__1213000094_A_init.Run(A_arbace_core_server_prepl_tapfn__1213000094_A_clinit) } }

func A_arbace_core_server_prepl_tapfn__1213000094_A_clinit() { A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_195, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_prepl_tapfn__1213000094_A_class }

func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_prepl_tapfn__1213000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_prepl_tapfn__1213000094_A); return ok }

func A_arbace_core_server_prepl_tapfn__1213000094_A_Cast(x any) *A_arbace_core_server_prepl_tapfn__1213000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_prepl_tapfn__1213000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_prepl_tapfn__1213000094_A_class)) }; return v }



type A_arbace_core_server_remote_prepl_A struct{ jrt.Object }

func (t *A_arbace_core_server_remote_prepl_A) Is_Compiler_AOTR4() {}

var A_arbace_core_server_remote_prepl_A_fn_class *jrt.Class

var A_arbace_core_server_remote_prepl_A_init jrt.ClassInit

func A_arbace_core_server_remote_prepl_A_Init() { if !A_arbace_core_server_remote_prepl_A_init.Done() { A_arbace_core_server_remote_prepl_A_init.Run(A_arbace_core_server_remote_prepl_A_clinit) } }

func A_arbace_core_server_remote_prepl_A_clinit() { A_arbace_core_server_remote_prepl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_core_server_remote_prepl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_remote_prepl_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_remote_prepl_A_class }

func (t *A_arbace_core_server_remote_prepl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_remote_prepl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_remote_prepl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_remote_prepl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_remote_prepl_A); return ok }

func A_arbace_core_server_remote_prepl_A_Cast(x any) *A_arbace_core_server_remote_prepl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_remote_prepl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_remote_prepl_A_class)) }; return v }



type A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A struct{ jrt.Object }

func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Is_Compiler_AOTF2() {}

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class *jrt.Class

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_init jrt.ClassInit

func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_Init() { if !A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_init.Done() { A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_init.Run(A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_clinit) } }

func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_clinit() { A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_class }

func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A); return ok }

func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_Cast(x any) *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_class)) }; return v }



type A_arbace_core_server_remote_prepl_fn__1213000128_A struct{ jrt.Object; F_rd, F_readf, F_wr, F_EOF, F_out_fn, F_valf any }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class *jrt.Class

var A_arbace_core_server_remote_prepl_fn__1213000128_A_init jrt.ClassInit

func A_arbace_core_server_remote_prepl_fn__1213000128_A_Init() { if !A_arbace_core_server_remote_prepl_fn__1213000128_A_init.Done() { A_arbace_core_server_remote_prepl_fn__1213000128_A_init.Run(A_arbace_core_server_remote_prepl_fn__1213000128_A_clinit) } }

func A_arbace_core_server_remote_prepl_fn__1213000128_A_clinit() { A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_remote_prepl_fn__1213000128_A_class }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_remote_prepl_fn__1213000128_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_remote_prepl_fn__1213000128_A); return ok }

func A_arbace_core_server_remote_prepl_fn__1213000128_A_Cast(x any) *A_arbace_core_server_remote_prepl_fn__1213000128_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_remote_prepl_fn__1213000128_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_remote_prepl_fn__1213000128_A_class)) }; return v }



type A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A struct{ jrt.Object; F_m, F_valf, F_val any }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class *jrt.Class

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_init jrt.ClassInit

func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_Init() { if !A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_init.Done() { A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_init.Run(A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_clinit) } }

func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_clinit() { A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_class }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A); return ok }

func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_Cast(x any) *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_class)) }; return v }



type A_arbace_core_server_repl_A struct{ jrt.Object }

func (t *A_arbace_core_server_repl_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_repl_A_fn_class *jrt.Class

var A_arbace_core_server_repl_A_init jrt.ClassInit

func A_arbace_core_server_repl_A_Init() { if !A_arbace_core_server_repl_A_init.Done() { A_arbace_core_server_repl_A_init.Run(A_arbace_core_server_repl_A_clinit) } }

func A_arbace_core_server_repl_A_clinit() { A_arbace_core_server_repl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_repl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_repl_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_repl_A_class }

func (t *A_arbace_core_server_repl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_repl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_repl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_repl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_repl_A); return ok }

func A_arbace_core_server_repl_A_Cast(x any) *A_arbace_core_server_repl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_repl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_repl_A_class)) }; return v }



type A_arbace_core_server_repl_init_A struct{ jrt.Object }

func (t *A_arbace_core_server_repl_init_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_repl_init_A_fn_class *jrt.Class

var A_arbace_core_server_repl_init_A_init jrt.ClassInit

func A_arbace_core_server_repl_init_A_Init() { if !A_arbace_core_server_repl_init_A_init.Done() { A_arbace_core_server_repl_init_A_init.Run(A_arbace_core_server_repl_init_A_clinit) } }

func A_arbace_core_server_repl_init_A_clinit() { A_arbace_core_server_repl_init_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_repl_init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_repl_init_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_repl_init_A_class }

func (t *A_arbace_core_server_repl_init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_repl_init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_repl_init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_repl_init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_repl_init_A); return ok }

func A_arbace_core_server_repl_init_A_Cast(x any) *A_arbace_core_server_repl_init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_repl_init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_repl_init_A_class)) }; return v }



type A_arbace_core_server_repl_read_A struct{ jrt.Object }

func (t *A_arbace_core_server_repl_read_A) Is_Compiler_AOTF2() {}

var A_arbace_core_server_repl_read_A_fn_class *jrt.Class

var A_arbace_core_server_repl_read_A_init jrt.ClassInit

func A_arbace_core_server_repl_read_A_Init() { if !A_arbace_core_server_repl_read_A_init.Done() { A_arbace_core_server_repl_read_A_init.Run(A_arbace_core_server_repl_read_A_clinit) } }

func A_arbace_core_server_repl_read_A_clinit() { A_arbace_core_server_repl_read_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_repl_read_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_repl_read_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_repl_read_A_class }

func (t *A_arbace_core_server_repl_read_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_repl_read_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_repl_read_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_repl_read_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_repl_read_A); return ok }

func A_arbace_core_server_repl_read_A_Cast(x any) *A_arbace_core_server_repl_read_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_repl_read_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_repl_read_A_class)) }; return v }



type A_arbace_core_server_required_A struct{ jrt.Object }

func (t *A_arbace_core_server_required_A) Is_Compiler_AOTF2() {}

var A_arbace_core_server_required_A_fn_class *jrt.Class

var A_arbace_core_server_required_A_init jrt.ClassInit

func A_arbace_core_server_required_A_Init() { if !A_arbace_core_server_required_A_init.Done() { A_arbace_core_server_required_A_init.Run(A_arbace_core_server_required_A_clinit) } }

func A_arbace_core_server_required_A_clinit() { A_arbace_core_server_required_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_required_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_required_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_required_A_class }

func (t *A_arbace_core_server_required_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_required_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_required_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_required_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_required_A); return ok }

func A_arbace_core_server_required_A_Cast(x any) *A_arbace_core_server_required_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_required_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_required_A_class)) }; return v }



type A_arbace_core_server_resolve_fn_A struct{ jrt.Object }

func (t *A_arbace_core_server_resolve_fn_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_resolve_fn_A_fn_class *jrt.Class

var A_arbace_core_server_resolve_fn_A_init jrt.ClassInit

func A_arbace_core_server_resolve_fn_A_Init() { if !A_arbace_core_server_resolve_fn_A_init.Done() { A_arbace_core_server_resolve_fn_A_init.Run(A_arbace_core_server_resolve_fn_A_clinit) } }

func A_arbace_core_server_resolve_fn_A_clinit() { A_arbace_core_server_resolve_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_resolve_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_resolve_fn_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_resolve_fn_A_class }

func (t *A_arbace_core_server_resolve_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_resolve_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_resolve_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_resolve_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_resolve_fn_A); return ok }

func A_arbace_core_server_resolve_fn_A_Cast(x any) *A_arbace_core_server_resolve_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_resolve_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_resolve_fn_A_class)) }; return v }



type A_arbace_core_server_start_server_A struct{ jrt.Object }

func (t *A_arbace_core_server_start_server_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_start_server_A_fn_class *jrt.Class

var A_arbace_core_server_start_server_A_init jrt.ClassInit

func A_arbace_core_server_start_server_A_Init() { if !A_arbace_core_server_start_server_A_init.Done() { A_arbace_core_server_start_server_A_init.Run(A_arbace_core_server_start_server_A_clinit) } }

func A_arbace_core_server_start_server_A_clinit() { A_arbace_core_server_start_server_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_start_server_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_start_server_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_start_server_A_class }

func (t *A_arbace_core_server_start_server_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_start_server_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_start_server_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_start_server_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_start_server_A); return ok }

func A_arbace_core_server_start_server_A_Cast(x any) *A_arbace_core_server_start_server_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_start_server_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_start_server_A_class)) }; return v }



type A_arbace_core_server_start_server_fn__1213000049_A struct{ jrt.Object; F_name, F_socket, F_lockee__1213000018__auto__ any }

func (t *A_arbace_core_server_start_server_fn__1213000049_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_start_server_fn__1213000049_A_fn_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000049_A_init jrt.ClassInit

func A_arbace_core_server_start_server_fn__1213000049_A_Init() { if !A_arbace_core_server_start_server_fn__1213000049_A_init.Done() { A_arbace_core_server_start_server_fn__1213000049_A_init.Run(A_arbace_core_server_start_server_fn__1213000049_A_clinit) } }

func A_arbace_core_server_start_server_fn__1213000049_A_clinit() { A_arbace_core_server_start_server_fn__1213000049_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_start_server_fn__1213000049_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_start_server_fn__1213000049_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_start_server_fn__1213000049_A_class }

func (t *A_arbace_core_server_start_server_fn__1213000049_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_start_server_fn__1213000049_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_start_server_fn__1213000049_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_start_server_fn__1213000049_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_start_server_fn__1213000049_A); return ok }

func A_arbace_core_server_start_server_fn__1213000049_A_Cast(x any) *A_arbace_core_server_start_server_fn__1213000049_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_start_server_fn__1213000049_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_start_server_fn__1213000049_A_class)) }; return v }



type A_arbace_core_server_start_server_fn__1213000052_A struct{ jrt.Object; F_name, F_socket, F_client_daemon, F_args, F_bind_err, F_accept any }

func (t *A_arbace_core_server_start_server_fn__1213000052_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_start_server_fn__1213000052_A_fn_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_A_init jrt.ClassInit

func A_arbace_core_server_start_server_fn__1213000052_A_Init() { if !A_arbace_core_server_start_server_fn__1213000052_A_init.Done() { A_arbace_core_server_start_server_fn__1213000052_A_init.Run(A_arbace_core_server_start_server_fn__1213000052_A_clinit) } }

func A_arbace_core_server_start_server_fn__1213000052_A_clinit() { A_arbace_core_server_start_server_fn__1213000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_start_server_fn__1213000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_start_server_fn__1213000052_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_start_server_fn__1213000052_A_class }

func (t *A_arbace_core_server_start_server_fn__1213000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_start_server_fn__1213000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_A); return ok }

func A_arbace_core_server_start_server_fn__1213000052_A_Cast(x any) *A_arbace_core_server_start_server_fn__1213000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_start_server_fn__1213000052_A_class)) }; return v }



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A struct{ jrt.Object; F_name, F_socket any; F_client_counter int64; F_client_daemon, F_args, F_bind_err, F_accept any }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_init jrt.ClassInit

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_Init() { if !A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_init.Done() { A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_init.Run(A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_clinit) } }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_clinit() { A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A); return ok }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_Cast(x any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_class)) }; return v }



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A struct{ jrt.Object; F_in, F_name, F_client_id, F_conn, F_out, F_args, F_bind_err, F_accept any }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_init jrt.ClassInit

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_Init() { if !A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_init.Done() { A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_init.Run(A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_clinit) } }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_clinit() { A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_class }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A); return ok }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_Cast(x any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_class)) }; return v }



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A struct{ jrt.Object; F_lockee__1213000018__auto__, F_name any }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class *jrt.Class

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_init jrt.ClassInit

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_Init() { if !A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_init.Done() { A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_init.Run(A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_clinit) } }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_clinit() { A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_class }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A); return ok }

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_Cast(x any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_class)) }; return v }



type A_arbace_core_server_start_servers_A struct{ jrt.Object }

func (t *A_arbace_core_server_start_servers_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_start_servers_A_fn_class *jrt.Class

var A_arbace_core_server_start_servers_A_init jrt.ClassInit

func A_arbace_core_server_start_servers_A_Init() { if !A_arbace_core_server_start_servers_A_init.Done() { A_arbace_core_server_start_servers_A_init.Run(A_arbace_core_server_start_servers_A_clinit) } }

func A_arbace_core_server_start_servers_A_clinit() { A_arbace_core_server_start_servers_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_start_servers_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_start_servers_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_start_servers_A_class }

func (t *A_arbace_core_server_start_servers_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_start_servers_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_start_servers_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_start_servers_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_start_servers_A); return ok }

func A_arbace_core_server_start_servers_A_Cast(x any) *A_arbace_core_server_start_servers_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_start_servers_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_start_servers_A_class)) }; return v }



type A_arbace_core_server_stop_server_A struct{ jrt.Object }

func (t *A_arbace_core_server_stop_server_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_core_server_stop_server_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_stop_server_A_fn_class *jrt.Class

var A_arbace_core_server_stop_server_A_init jrt.ClassInit

func A_arbace_core_server_stop_server_A_Init() { if !A_arbace_core_server_stop_server_A_init.Done() { A_arbace_core_server_stop_server_A_init.Run(A_arbace_core_server_stop_server_A_clinit) } }

func A_arbace_core_server_stop_server_A_clinit() { A_arbace_core_server_stop_server_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_stop_server_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_stop_server_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_stop_server_A_class }

func (t *A_arbace_core_server_stop_server_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_stop_server_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_stop_server_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_stop_server_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_stop_server_A); return ok }

func A_arbace_core_server_stop_server_A_Cast(x any) *A_arbace_core_server_stop_server_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_stop_server_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_stop_server_A_class)) }; return v }



type A_arbace_core_server_stop_servers_A struct{ jrt.Object }

func (t *A_arbace_core_server_stop_servers_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_stop_servers_A_fn_class *jrt.Class

var A_arbace_core_server_stop_servers_A_init jrt.ClassInit

func A_arbace_core_server_stop_servers_A_Init() { if !A_arbace_core_server_stop_servers_A_init.Done() { A_arbace_core_server_stop_servers_A_init.Run(A_arbace_core_server_stop_servers_A_clinit) } }

func A_arbace_core_server_stop_servers_A_clinit() { A_arbace_core_server_stop_servers_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_219, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_stop_servers_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_stop_servers_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_stop_servers_A_class }

func (t *A_arbace_core_server_stop_servers_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_stop_servers_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_stop_servers_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_stop_servers_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_stop_servers_A); return ok }

func A_arbace_core_server_stop_servers_A_Cast(x any) *A_arbace_core_server_stop_servers_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_stop_servers_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_stop_servers_A_class)) }; return v }



type A_arbace_core_server_stop_servers_fn__1213000067_A struct{ jrt.Object; F_name any }

func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class *jrt.Class

var A_arbace_core_server_stop_servers_fn__1213000067_A_init jrt.ClassInit

func A_arbace_core_server_stop_servers_fn__1213000067_A_Init() { if !A_arbace_core_server_stop_servers_fn__1213000067_A_init.Done() { A_arbace_core_server_stop_servers_fn__1213000067_A_init.Run(A_arbace_core_server_stop_servers_fn__1213000067_A_clinit) } }

func A_arbace_core_server_stop_servers_fn__1213000067_A_clinit() { A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_stop_servers_fn__1213000067_A_class }

func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_stop_servers_fn__1213000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_stop_servers_fn__1213000067_A); return ok }

func A_arbace_core_server_stop_servers_fn__1213000067_A_Cast(x any) *A_arbace_core_server_stop_servers_fn__1213000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_stop_servers_fn__1213000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_stop_servers_fn__1213000067_A_class)) }; return v }



type A_arbace_core_server_stop_servers_fn__1213000069_A struct{ jrt.Object; F_name any }

func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Is_Compiler_AOTF0() {}

var A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class *jrt.Class

var A_arbace_core_server_stop_servers_fn__1213000069_A_init jrt.ClassInit

func A_arbace_core_server_stop_servers_fn__1213000069_A_Init() { if !A_arbace_core_server_stop_servers_fn__1213000069_A_init.Done() { A_arbace_core_server_stop_servers_fn__1213000069_A_init.Run(A_arbace_core_server_stop_servers_fn__1213000069_A_clinit) } }

func A_arbace_core_server_stop_servers_fn__1213000069_A_clinit() { A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_221, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_stop_servers_fn__1213000069_A_class }

func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_stop_servers_fn__1213000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_stop_servers_fn__1213000069_A); return ok }

func A_arbace_core_server_stop_servers_fn__1213000069_A_Cast(x any) *A_arbace_core_server_stop_servers_fn__1213000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_stop_servers_fn__1213000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_stop_servers_fn__1213000069_A_class)) }; return v }



type A_arbace_core_server_thread_A struct{ jrt.Object }

func (t *A_arbace_core_server_thread_A) Is_Compiler_AOTR4() {}

var A_arbace_core_server_thread_A_fn_class *jrt.Class

var A_arbace_core_server_thread_A_init jrt.ClassInit

func A_arbace_core_server_thread_A_Init() { if !A_arbace_core_server_thread_A_init.Done() { A_arbace_core_server_thread_A_init.Run(A_arbace_core_server_thread_A_clinit) } }

func A_arbace_core_server_thread_A_clinit() { A_arbace_core_server_thread_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_core_server_thread_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_thread_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_thread_A_class }

func (t *A_arbace_core_server_thread_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_thread_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_thread_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_thread_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_thread_A); return ok }

func A_arbace_core_server_thread_A_Cast(x any) *A_arbace_core_server_thread_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_thread_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_thread_A_class)) }; return v }



type A_arbace_core_server_validate_opts_A struct{ jrt.Object }

func (t *A_arbace_core_server_validate_opts_A) Is_Compiler_AOTF1() {}

var A_arbace_core_server_validate_opts_A_fn_class *jrt.Class

var A_arbace_core_server_validate_opts_A_init jrt.ClassInit

func A_arbace_core_server_validate_opts_A_Init() { if !A_arbace_core_server_validate_opts_A_init.Done() { A_arbace_core_server_validate_opts_A_init.Run(A_arbace_core_server_validate_opts_A_clinit) } }

func A_arbace_core_server_validate_opts_A_clinit() { A_arbace_core_server_validate_opts_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_223, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_server_validate_opts_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_validate_opts_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_validate_opts_A_class }

func (t *A_arbace_core_server_validate_opts_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_validate_opts_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_validate_opts_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_validate_opts_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_validate_opts_A); return ok }

func A_arbace_core_server_validate_opts_A_Cast(x any) *A_arbace_core_server_validate_opts_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_validate_opts_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_validate_opts_A_class)) }; return v }



type A_arbace_core_server_with_lock_A struct{ jrt.Object }

func (t *A_arbace_core_server_with_lock_A) Is_Compiler_AOTR3() {}

var A_arbace_core_server_with_lock_A_fn_class *jrt.Class

var A_arbace_core_server_with_lock_A_init jrt.ClassInit

func A_arbace_core_server_with_lock_A_Init() { if !A_arbace_core_server_with_lock_A_init.Done() { A_arbace_core_server_with_lock_A_init.Run(A_arbace_core_server_with_lock_A_clinit) } }

func A_arbace_core_server_with_lock_A_clinit() { A_arbace_core_server_with_lock_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_225, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_core_server_with_lock_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_with_lock_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_with_lock_A_class }

func (t *A_arbace_core_server_with_lock_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_with_lock_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_server_with_lock_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_with_lock_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_with_lock_A); return ok }

func A_arbace_core_server_with_lock_A_Cast(x any) *A_arbace_core_server_with_lock_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_with_lock_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_with_lock_A_class)) }; return v }
