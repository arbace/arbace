//line aot_arbace_core_server.ae:1
package aot_arbace_core_server

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_edn"
	"arbace/aot_arbace_main"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :9:1
func A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_New() *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_core_server_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_1); lang.IFn_Cast(A_arbace_core_server_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_server_A_const_3, A_arbace_core_server_A_const_4, A_arbace_core_server_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_core_server_eval1213000008_fn__1213000009_A_New() *A_arbace_core_server_eval1213000008_fn__1213000009_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_eval1213000008_fn__1213000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_core_server_eval1213000008_fn__1213000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_core_server_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_core_server_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core_server_A_const_9.GetRawRoot__O(), A_arbace_core_server_A_const_10) }




















func A_arbace_core_server_with_lock_A_New() *A_arbace_core_server_with_lock_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_with_lock_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_core_server_with_lock_A) Ctor() {}
//line :30:1
func (t *A_arbace_core_server_with_lock_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, lock_expr__2, body__3 any) any { var root_21 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_14); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp4 any; var root_32 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_core_server_A_const_16.GetRawRoot__O(); var arg_36 any; var root_37 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var root_41 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17); var arg_45 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp6 any; var root_46 any = A_arbace_core_server_A_const_18.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_48 lang.IFn; if

	linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = lock_expr__2; var arg_50 any = A_arbace_core_server_A_const_19; if linked_47 == nil { tmp6 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { tmp6 = linked_47.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; arg_45 = /*line :30:1*/tmp5.Invoke_O__O(tmp6); if linked_42 == nil { arg_40 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { arg_40 = linked_42.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if linked_38 == nil { arg_36 = ifn_39.Invoke_O__O(arg_40) } else { arg_36 = linked_38.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_37, arg_40) }; if linked_33 == nil { tmp4 = ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { tmp4 = linked_33.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) }; var tmp7 any = tmp3.Invoke_O__O(tmp4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp9 any; var root_51 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var root_55 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_20); var arg_59 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17); if linked_56 == nil { arg_54 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { arg_54 = linked_56.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }; if linked_52 == nil { tmp9 = ifn_53.Invoke_O__O(arg_54) } else { tmp9 = linked_52.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_51, arg_54) }; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp12 any; var root_60 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_21); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp16 any; var root_70 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_74 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_22); var arg_78 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp18 any; var root_79 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var root_83 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_23); var arg_87 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_17); if linked_84 == nil { arg_82 = ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { arg_82 = linked_84.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) }; if linked_80 == nil { tmp18 = ifn_81.Invoke_O__O(arg_82) } else { tmp18 = linked_80.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_79, arg_82) }; arg_78 = tmp17.Invoke_O__O(tmp18); if linked_75 == nil { arg_73 = ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { arg_73 = linked_75.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_74, arg_77, arg_78) }; if linked_71 == nil { tmp16 = ifn_72.Invoke_O__O(arg_73) } else { tmp16 = linked_71.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_70, arg_73) }; arg_63 = tmp13.Invoke_O_O_O__O(tmp14, body__3, tmp15.Invoke_O__O(tmp16)); if linked_61 == nil { tmp12 = ifn_62.Invoke_O__O(arg_63) } else { tmp12 = linked_61.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_60, arg_63) }; arg_24 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp7, tmp10, tmp11.Invoke_O__O(tmp12)); if linked_22 == nil { return ifn_23.Invoke_O__O(arg_24) } else { return linked_22.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_21, arg_24) } }








func A_arbace_core_server_thread_A_New() *A_arbace_core_server_thread_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_thread_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_core_server_thread_A) Ctor() {}
//line :39:1
func (t *A_arbace_core_server_thread_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, name__2, daemon__3, body__4 any) any { var root_88 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_24); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp4 any; var root_99 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_25); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp8 any; var root_109 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_12.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_26); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp12 any; var root_119 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = A_arbace_core_server_A_const_16.GetRawRoot__O(); var arg_123 any; var root_124 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_128 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; if linked_129 == nil { arg_127 = ifn_130.Invoke__O() } else { arg_127 = linked_129.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_128) }; if linked_125 == nil { arg_123 = ifn_126.Invoke_O__O(arg_127) } else { arg_123 = linked_125.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_124, arg_127) }; if linked_120 == nil { tmp12 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { tmp12 = linked_120.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }; arg_112 = tmp9.Invoke_O_O_O__O(tmp10, tmp11.Invoke_O__O(tmp12), body__4); if linked_110 == nil { tmp8 = ifn_111.Invoke_O__O(arg_112) } else { tmp8 = linked_110.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_109, arg_112) }; arg_102 = tmp5.Invoke_O_O_O__O(tmp6, tmp7.Invoke_O__O(tmp8), lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(name__2)); if linked_100 == nil { tmp4 = ifn_101.Invoke_O__O(arg_102) } else { tmp4 = linked_100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_99, arg_102) }; var tmp13 any = tmp3.Invoke_O__O(tmp4); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp15 any; var root_131 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var root_135 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_27); var arg_139 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(daemon__3); if linked_136 == nil { arg_134 = ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { arg_134 = linked_136.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) }; if linked_132 == nil { tmp15 = ifn_133.Invoke_O__O(arg_134) } else { tmp15 = linked_132.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_131, arg_134) }; var tmp16 any = tmp14.Invoke_O__O(tmp15); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()); var tmp18 any; var root_140 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_144 any = A_arbace_core_server_A_const_12.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = lang.IFn_Cast(A_arbace_core_server_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_28); if linked_145 == nil { arg_143 = ifn_146.Invoke_O__O(arg_147) } else { arg_143 = linked_145.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_144, arg_147) }; if linked_141 == nil { tmp18 = ifn_142.Invoke_O__O(arg_143) } else { tmp18 = linked_141.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_140, arg_143) }; arg_91 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp13, tmp16, tmp17.Invoke_O__O(tmp18)); if linked_89 == nil { return ifn_90.Invoke_O__O(arg_91) } else { return linked_89.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_88, arg_91) } }





func A_arbace_core_server_required_A_New() *A_arbace_core_server_required_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_required_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_core_server_required_A) Ctor() {}
//line :45:1
func (t *A_arbace_core_server_required_A) Invoke_O_O_O__O(self, opts__0, prop__1 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(lang.RT_Get_O_O__O_NoInit(opts__0, prop__1), nil) { var tmp1 any; var root_148 any = A_arbace_core_server_A_const_29.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_150 lang.IFn
		if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, prop__1)).Ref(); var arg_152 any = opts__0; if linked_149 == nil { tmp1 = ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { tmp1 = linked_149.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }
//line :48:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } else { return nil
		}
}
func A_arbace_core_server_validate_opts_A_New() *A_arbace_core_server_validate_opts_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_validate_opts_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Ctor() {}
//line :51:1
func (t *A_arbace_core_server_validate_opts_A) Invoke_O_O__O(self, p__1213000030__0 any) any { var map__1213000031__2 any = p__1213000030__0; var map__1213000031__3 any; if lang.ISeq_InstanceOf(map__1213000031__2) { var tmp1 any; var root_153 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = map__1213000031__2; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_153, arg_156) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_157 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = map__1213000031__2; if linked_158 == nil { tmp2 = ifn_159.Invoke_O__O(arg_160) } else { tmp2 = linked_158.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_157, arg_160) }; map__1213000031__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_161 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = map__1213000031__2; if linked_162 == nil { tmp3 = ifn_163.Invoke_O__O(arg_164) } else { tmp3 = linked_162.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_161, arg_164) }; if jrt.J2g_Truth(tmp3) { var root_165 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = map__1213000031__2; if linked_166 == nil { map__1213000031__3 = ifn_167.Invoke_O__O(arg_168) } else { map__1213000031__3 = linked_166.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_165, arg_168) } } else { map__1213000031__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000031__3 = map__1213000031__2 }; var opts__4 any = map__1213000031__3; var name__5 any = lang.RT_Get_O_O__O_NoInit(map__1213000031__3, A_arbace_core_server_A_const_33); var port__6 any = lang.RT_Get_O_O__O_NoInit(map__1213000031__3, A_arbace_core_server_A_const_34); var accept__7 any = lang.RT_Get_O_O__O_NoInit(map__1213000031__3, A_arbace_core_server_A_const_35); var seq_1213000033__8 any; var root_192 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_194 lang.IFn; _ = name__5; _ = accept__7; if


	linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = A_arbace_core_server_A_const_41; if linked_193 == nil { seq_1213000033__8 = ifn_194.Invoke_O__O(arg_195) } else { seq_1213000033__8 = linked_193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_192, arg_195) }; var chunk_1213000034__9 any; var count_1213000035__10 int64 = 0; var i_1213000036__11 int64 = 0; L1:
//line :51:1
	for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_1213000036__11, count_1213000035__10) { var prop__12 any = lang.Indexed_Cast(chunk_1213000034__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1213000036__11)); var root_212 any = A_arbace_core_server_A_const_44.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_core_server_required_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = opts__4; var arg_216 any = prop__12; if linked_213 == nil { ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { linked_213.(*A_arbace_core_server_required_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) }; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1213000036__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_196 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = seq_1213000033__8; if linked_197 == nil { temp__1927000414__auto____12 = ifn_198.Invoke_O__O(arg_199) } else { temp__1927000414__auto____12 = linked_197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_196, arg_199) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1213000033__13 any = temp__1927000414__auto____12; var tmp4 any; var root_200 any = A_arbace_core_server_A_const_42.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = seq_1213000033__13; if linked_201 == nil { tmp4 = ifn_202.Invoke_O__O(arg_203) } else { tmp4 = linked_201.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_204 any = A_arbace_core_server_A_const_43.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = seq_1213000033__13; if linked_205 == nil { c__1927000678__auto____14 = ifn_206.Invoke_O__O(arg_207) } else { c__1927000678__auto____14 = linked_205.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_204, arg_207) }; var tmp5 any; var root_217 any = A_arbace_core_server_A_const_45.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = seq_1213000033__13; if linked_218 == nil { tmp5 = ifn_219.Invoke_O__O(arg_220) } else { tmp5 = linked_218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_217, arg_220) }; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var prop__14 any; var root_208 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = seq_1213000033__13; if linked_209 == nil { prop__14 = ifn_210.Invoke_O__O(arg_211) } else { prop__14 = linked_209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_208, arg_211) }; var root_221 any = A_arbace_core_server_A_const_44.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, A_arbace_core_server_required_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = opts__4; var arg_225 any = prop__14; if linked_222 == nil { ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { linked_222.(*A_arbace_core_server_required_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }; var tmp6 any; var root_226 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = seq_1213000033__13; if linked_227 == nil { tmp6 = ifn_228.Invoke_O__O(arg_229) } else { tmp6 = linked_227.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_226, arg_229) }; seq_1213000033__8, chunk_1213000034__9, count_1213000035__10, i_1213000036__11 = tmp6, nil, 0, 0; continue L1 } } }
//line :51:1
		break L1 }; var tmp7 any; var or__1927000174__auto____8 any; var root_169 any =



	A_arbace_core_server_A_const_36.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any; var root_173 any = A_arbace_core_server_A_const_37.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = port__6; if linked_174 == nil { arg_172 = ifn_175.Invoke_O__O(arg_176) } else { arg_172 = linked_174.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_173, arg_176) }; if linked_170 == nil { or__1927000174__auto____8 = ifn_171.Invoke_O__O(arg_172) } else { or__1927000174__auto____8 = linked_170.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp7 = or__1927000174__auto____8 } else { var root_177 any = A_arbace_core_server_A_const_36.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = lang.IFn_Cast(A_arbace_core_server_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core_server_A_const_39, port__6, A_arbace_core_server_A_const_40); if linked_178 == nil { tmp7 = ifn_179.Invoke_O__O(arg_180) } else { tmp7 = linked_178.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_177, arg_180) } }; if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_187 any = A_arbace_core_server_A_const_29.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_189 lang.IFn
		if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, port__6)).Ref(); var arg_191 any = opts__4; if linked_188 == nil { tmp8 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { tmp8 = linked_188.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }
//line :55:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp8))) } else { return nil } }


func A_arbace_core_server_accept_connection_A_New() *A_arbace_core_server_accept_connection_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Ctor() {}
//line :58:1
func (t *A_arbace_core_server_accept_connection_A) Invoke_O_O_O_O_O_O_O_O_O__O(self, conn__0, name__1, client_id__2, in__3, out__4, err__5, accept__6, args__7 any) any { var tmp1 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)











	{ var root_242 any = A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_50; var tmp4 any = A_arbace_core_server_A_const_51; var tmp5 any = A_arbace_core_server_A_const_52; var tmp6 any = A_arbace_core_server_A_const_53; var arg_245 any = tmp2.Invoke_O_O_O_O_O_O_O_O__O(tmp3, in__3, tmp4, out__4, tmp5, err__5, tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_54, name__1, A_arbace_core_server_A_const_55, client_id__2))); if linked_243 == nil { ifn_244.Invoke_O__O(arg_245) } else { linked_243.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_242, arg_245) }; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :58:1
		{ var lockee__1213000018__auto____13 any = A_arbace_core_server_A_const_56.GetRawRoot__O()















			jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____13)).Lock__V(); var tmp7 *lang.Compiler_AOTFn; var fnbody__265 any = A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____13); var tmp8 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__265); A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class = fncls__264d; tmp8 = fncls__264d } else { tmp8 = fncls__264 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__265, tmp8, nil); Up_Compiler_AOTFn_IFn(tmp7).Invoke__O()

			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_2.GetRawRoot__O()); var tmp10 any; var root_270 any = A_arbace_core_server_A_const_61.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any; var root_274 any = A_arbace_core_server_A_const_62.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = accept__6; if linked_275 == nil { arg_273 = ifn_276.Invoke_O__O(arg_277) } else { arg_273 = linked_275.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_274, arg_277) }; if linked_271 == nil { tmp10 = ifn_272.Invoke_O__O(arg_273) } else { tmp10 = linked_271.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_270, arg_273) }; tmp9.Invoke_O__O(tmp10)
//line :58:1
			var accept_fn__13 any; var root_230 any = A_arbace_core_server_A_const_46.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_232 lang.IFn


















			if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = accept__6; if linked_231 == nil { accept_fn__13 = ifn_232.Invoke_O__O(arg_233) } else { accept_fn__13 = linked_231.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_230, arg_233) }
			var root_234 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = accept_fn__13; var arg_238 any = args__7; if linked_235 == nil { tmp1 = ifn_236.Invoke_O_O__O(arg_237, arg_238) } else { tmp1 = linked_235.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_234, arg_237, arg_238) } }
//line :70:1
		return nil }(); var root_239 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; if linked_240 == nil { ifn_241.Invoke__O() } else { linked_240.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_239) }
//line :58:1
		if tmp11 != nil { panic(tmp11) } }; return nil }(); if tmp12 != nil { if jrt.SocketException_InstanceOf(tmp12) { var _disconnect__11 jrt.SocketException_I = jrt.SocketException_Cast(tmp12); _ = _disconnect__11; tmp1 = nil } else { panic(tmp12) } } }; return nil }(); var lockee__1213000018__auto____11 any = A_arbace_core_server_A_const_56.GetRawRoot__O();






















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____11)).Lock__V(); var tmp14 *lang.Compiler_AOTFn; var fnbody__287 any = A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(name__1, client_id__2, lockee__1213000018__auto____11); var tmp15 *jrt.Class; var fncls__286 *jrt.Class = A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class; if fncls__286 == nil { var fncls__286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__287); A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class = fncls__286d; tmp15 = fncls__286d } else { tmp15 = fncls__286 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__287, tmp15, nil); Up_Compiler_AOTFn_IFn(tmp14).Invoke__O();

	jrt.Socket_Cast(conn__0).Close__V(); if /*line :58:1*/ tmp13 != nil { panic(tmp13) }; return tmp1 }















func A_arbace_core_server_accept_connection_fn__1213000038_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000038_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000038_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :74:1
func (t *A_arbace_core_server_accept_connection_fn__1213000038_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_59.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; var tmp6 any = tmp5; var tmp7 any = A_arbace_core_server_A_const_60; var tmp8 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp7, tmp8), lang.PersistentArrayMap_EMPTY.Ref()) }
//line :74:1
	return nil }(); var tmp10 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp10 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp10)).Unlock__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }






func A_arbace_core_server_accept_connection_fn__1213000040_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_accept_connection_fn__1213000040_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_accept_connection_fn__1213000040_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Ctor_O_O_O(c__name, c__client_id, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_client_id = c__client_id; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :81:1
func (t *A_arbace_core_server_accept_connection_fn__1213000040_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_63.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(tmp5, A_arbace_core_server_A_const_60); var tmp7 any = A_arbace_core_server_A_const_64.GetRawRoot__O(); var tmp8 any; var t__2 any = t.F_client_id; t.F_client_id = nil; tmp8 = t__2; tmp1 = tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp6, tmp7, tmp8) }
//line :81:1
	return nil }(); var tmp10 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp10 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp10)).Unlock__V(); if tmp9 != nil { panic(tmp9) }; return tmp1 }



func A_arbace_core_server_start_server_A_New() *A_arbace_core_server_start_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_core_server_start_server_A) Ctor() {}
//line :85:1
func (t *A_arbace_core_server_start_server_A) Invoke_O_O__O(self, opts__0 any) any {











	var root_304 any = A_arbace_core_server_A_const_70.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_core_server_validate_opts_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = opts__0; if linked_305 == nil { ifn_306.Invoke_O__O(arg_307) } else { linked_305.(*A_arbace_core_server_validate_opts_A).Invoke_O_O__O(root_304, arg_307) }
//line :85:1
	var default__1213000045__2 any = jrt.Boolean_TRUE.Ref(); var default__1213000046__3 any = jrt.Boolean_TRUE.Ref(); var default__1213000047__4 any = jrt.Boolean_TRUE.Ref(); var map__1213000043__5 any = opts__0; var map__1213000043__6 any












	if lang.ISeq_InstanceOf(map__1213000043__5) { var tmp1 any; var root_288 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = map__1213000043__5; if linked_289 == nil { tmp1 = ifn_290.Invoke_O__O(arg_291) } else { tmp1 = linked_289.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_288, arg_291) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_292 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = map__1213000043__5; if linked_293 == nil { tmp2 = ifn_294.Invoke_O__O(arg_295) } else { tmp2 = linked_293.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_292, arg_295) }; map__1213000043__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_296 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = map__1213000043__5; if linked_297 == nil { tmp3 = ifn_298.Invoke_O__O(arg_299) } else { tmp3 = linked_297.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_296, arg_299) }; if jrt.J2g_Truth(tmp3) { var root_300 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = map__1213000043__5; if linked_301 == nil { map__1213000043__6 = ifn_302.Invoke_O__O(arg_303) } else { map__1213000043__6 = linked_301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_300, arg_303) } } else { map__1213000043__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000043__6 = map__1213000043__5 }
//line :85:1
	var address__7 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_65); var port__8 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_34); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_33); var accept__10 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_35); var args__11 any = lang.RT_Get_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_66); var bind_err__12 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_67, default__1213000045__2); var server_daemon__13 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_68, default__1213000046__3); var client_daemon__14 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000043__6, A_arbace_core_server_A_const_69, default__1213000047__4); var address__15 any = jrt.InetAddress_GetByName_String__InetAddress(jrt.String_Cast(address__7)); var socket__16 any = jrt.ServerSocket_New_I_I_InetAddress(lang.RT_IntCast_O__I_NoInit(port__8), lang.RT_IntCast_J__I_NoInit(0), jrt.InetAddress_Cast(address__15)); var lockee__1213000018__auto____17 any = A_arbace_core_server_A_const_56.GetRawRoot__O()


















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____17)).Lock__V(); var tmp4 *lang.Compiler_AOTFn; var fnbody__316 any = A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(name__9, socket__16, lockee__1213000018__auto____17); var tmp5 *jrt.Class; var fncls__315 *jrt.Class = A_arbace_core_server_start_server_fn__1213000049_A_fn_class; if fncls__315 == nil { var fncls__315d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__316); A_arbace_core_server_start_server_fn__1213000049_A_fn_class = fncls__315d; tmp5 = fncls__315d } else { tmp5 = fncls__315 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__316, tmp5, nil); Up_Compiler_AOTFn_IFn(tmp4).Invoke__O()
//line :85:1
	var G__1213000051__17_ any; var tmp6 *lang.Compiler_AOTFn; var fnbody__349 any = A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(name__9, socket__16, client_daemon__14, args__11, bind_err__12, accept__10); var tmp7 *jrt.Class
	var fncls__348 /*line :85:1*/*jrt.Class = A_arbace_core_server_start_server_fn__1213000052_A_fn_class




















	if fncls__348 == nil { var fncls__348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__349); A_arbace_core_server_start_server_fn__1213000052_A_fn_class = fncls__348d; tmp7 = fncls__348d } else { tmp7 = fncls__348 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__349, tmp7, nil)
//line :85:1
	G__1213000051__17_ = jrt.Thread_New_Runnable_String(Up_Compiler_AOTFn_Runnable(tmp6), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__9)))




















	jrt.Thread_Cast(G__1213000051__17_).SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(server_daemon__13)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000051__17_).Start__V()
//line :85:1
	return socket__16
}

















func A_arbace_core_server_start_server_fn__1213000049_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_start_server_fn__1213000049_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000049_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Ctor_O_O_O(c__name, c__socket, c__lockee__1213000018__auto__ any) { t.F_name = c__name; t.F_socket = c__socket; t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__ }
//line :104:1
func (t *A_arbace_core_server_start_server_fn__1213000049_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var tmp5 any = t.F_name; var tmp6 any = A_arbace_core_server_A_const_33; var tmp7 any; var t_ any = t.F_name; t.F_name = nil; tmp7 = t_; var tmp8 any = tmp7; var tmp9 any = A_arbace_core_server_A_const_72; var tmp10 any; var t__2 any = t.F_socket; t.F_socket = nil; tmp10 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp10, A_arbace_core_server_A_const_60, lang.PersistentArrayMap_EMPTY.Ref()))) }
//line :104:1
	return nil }(); var tmp12 any; var t__3 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp12 = t__3; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp12)).Unlock__V(); if tmp11 != nil { panic(tmp11) }; return tmp1 }

func A_arbace_core_server_start_server_fn__1213000052_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_start_server_fn__1213000052_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Ctor_O_O_O_O_O_O(c__name, c__socket, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :106:1
func (t *A_arbace_core_server_start_server_fn__1213000052_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var client_counter__3 int64 = 1; L1: for {



	var tmp2 any; var root_317 any = A_arbace_core_server_A_const_36.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ServerSocket_Cast(t.F_socket)).IsClosed__Z()).Ref(); if linked_318 == nil { tmp2 = ifn_319.Invoke_O__O(arg_320) } else { tmp2 = linked_318.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_317, arg_320) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 *lang.Compiler_AOTFn; var fnbody__347 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(t.F_name, t.F_socket, client_counter__3, t.F_client_daemon, t.F_args, t.F_bind_err, t.F_accept); var tmp4 *jrt.Class; var fncls__346 *jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class; if fncls__346 == nil { var fncls__346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__347); A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class = fncls__346d; tmp4 = fncls__346d } else { tmp4 = fncls__346 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__347, tmp4, nil); Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()








		client_counter__3 = lang.Numbers_Inc_J__J_NoInit(client_counter__3); continue L1 } else {
//line :110:1
			tmp1 = nil }
//line :106:1
	break L1 } }; return nil }(); var lockee__1213000018__auto____3 any = A_arbace_core_server_A_const_56.GetRawRoot__O();















	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____3)).Lock__V(); var tmp6 *lang.Compiler_AOTFn; var fnbody__328 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(lockee__1213000018__auto____3, t.F_name); var tmp7 *jrt.Class; var fncls__327 *jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class; if fncls__327 == nil { var fncls__327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__328); A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class = fncls__327d; tmp7 = fncls__327d } else { tmp7 = fncls__327 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__328, tmp7, nil); Up_Compiler_AOTFn_IFn(tmp6).Invoke__O(); if /*line :106:1*/ tmp5 != nil { panic(tmp5) }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_New_O_O_J_O_O_O_O(p0, p1 any, p2 int64, p3, p4, p5, p6 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A{}; t.Ctor_O_O_J_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Ctor_O_O_J_O_O_O_O(c__name, c__socket any, c__client_counter int64, c__client_daemon, c__args, c__bind_err, c__accept any) { t.F_name = c__name; t.F_socket = c__socket; t.F_client_counter = c__client_counter; t.F_client_daemon = c__client_daemon; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :111:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var conn__3 any; var tmp2 any; var t_ any = t.F_socket
													t.F_socket = nil; tmp2 = t_; conn__3 = jrt.NN(jrt.ServerSocket_Cast(tmp2)).Accept__Socket()
//line :111:1
	var in__4 any = lang.LineNumberingPushbackReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(conn__3).GetInputStream__InputStream())); var out__5 any = jrt.BufferedWriter_New_Writer(jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(conn__3).GetOutputStream__OutputStream())); var client_id__6 any; var root_329 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_331 lang.IFn



	if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = jrt.Long_ValueOf_J__Long_NoInit(t.F_client_counter).Ref(); if linked_330 == nil { client_id__6 = ifn_331.Invoke_O__O(arg_332) } else { client_id__6 = linked_330.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_329, arg_332) }
//line :111:1
	var G__1213000054__7_ any; var tmp3 *lang.Compiler_AOTFn; var fnbody__345 any = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(in__4, t.F_name, client_id__6, conn__3, out__5, t.F_args, t.F_bind_err, t.F_accept); var tmp4 *jrt.Class
	var fncls__344 /*line :111:1*/*jrt.Class = A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class




	if fncls__344 == nil { var fncls__344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__345); A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class = fncls__344d; tmp4 = fncls__344d } else { tmp4 = fncls__344 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__345, tmp4, nil)
//line :111:1
	var tmp5 jrt.Runnable = Up_Compiler_AOTFn_Runnable(tmp3); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_42, nil, Lit_43, nil); var tmp7 any; var t__2 any = t.F_name





	t.F_name = nil; tmp7 = t__2
//line :111:1
	G__1213000054__7_ = jrt.Thread_New_Runnable_String(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, client_id__6)))




	var tmp8 jrt.Thread_I = jrt.Thread_Cast(G__1213000054__7_); var tmp9 any; var t__3 any = t.F_client_daemon; t.F_client_daemon = nil; tmp9 = t__3; tmp8.SetDaemon_Z__V(jrt.NN(jrt.Boolean_Cast(tmp9)).BooleanValue__Z()); jrt.Thread_Cast(G__1213000054__7_).Start__V()
//line :111:1
	tmp1 = G__1213000054__7_ }; return nil }(); if tmp10 != nil { if jrt.SocketException_InstanceOf(tmp10) { var _disconnect__3 jrt.SocketException_I = jrt.SocketException_Cast(tmp10); _ = _disconnect__3; tmp1 = nil } else { panic(tmp10) } }; return tmp1 }




func A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Ctor_O_O_O_O_O_O_O_O(c__in, c__name, c__client_id, c__conn, c__out, c__args, c__bind_err, c__accept any) { t.F_in = c__in; t.F_name = c__name; t.F_client_id = c__client_id; t.F_conn = c__conn; t.F_out = c__out; t.F_args = c__args; t.F_bind_err = c__bind_err; t.F_accept = c__accept }
//line :116:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A) Invoke_O__O(self any) any {

	var root_333 any = A_arbace_core_server_A_const_74.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_core_server_accept_connection_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = t.F_conn; var arg_337 any = t.F_name; var arg_338 any = t.F_client_id; var arg_339 any = t.F_in; var arg_340 any = t.F_out; var arg_341 any; if jrt.J2g_Truth(t.F_bind_err) { arg_341 = t.F_out } else { arg_341 = A_arbace_core_server_A_const_52.Get__O() }; var arg_342 any = t.F_accept; var arg_343 any = t.F_args; if linked_334 == nil { return ifn_335.Invoke_O_O_O_O_O_O_O_O__O(arg_336, arg_337, arg_338, arg_339, arg_340, arg_341, arg_342, arg_343) } else { return linked_334.(*A_arbace_core_server_accept_connection_A).Invoke_O_O_O_O_O_O_O_O_O__O(root_333, arg_336, arg_337, arg_338, arg_339, arg_340, arg_341, arg_342, arg_343)
	}
}

func A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_New_O_O(p0, p1 any) *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A{}; t.Ctor_O_O(p0, p1); return t }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Ctor_O_O(c__lockee__1213000018__auto__, c__name any) { t.F_lockee__1213000018__auto__ = c__lockee__1213000018__auto__; t.F_name = c__name }
//line :122:1
func (t *A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; var tmp4 any = A_arbace_core_server_A_const_64.GetRawRoot__O(); var tmp5 any; var t_ any = t.F_name; t.F_name = nil; tmp5 = t_; tmp1 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5) }
//line :122:1
	return nil }(); var tmp7 any; var t__2 any = t.F_lockee__1213000018__auto__; t.F_lockee__1213000018__auto__ = nil; tmp7 = t__2; jrt.NN(jrt.As[*jrt.ReentrantLock](tmp7)).Unlock__V(); if tmp6 != nil { panic(tmp6) }; return tmp1 }



func A_arbace_core_server_stop_server_A_New() *A_arbace_core_server_stop_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_server_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Ctor() {}
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O_O__O(self, name__0 any) any { var lockee__1213000018__auto____2 any = A_arbace_core_server_A_const_56.GetRawRoot__O();






	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Lock__V(); var tmp1 any; tmp4 := /*line :126:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var server_socket__5 any; var root_350 any = A_arbace_core_server_A_const_75.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_352 lang.IFn







		if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = A_arbace_core_server_A_const_58.GetRawRoot__O(); var arg_354 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, A_arbace_core_server_A_const_72); if linked_351 == nil { server_socket__5 = ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { server_socket__5 = linked_351.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) }
		if jrt.J2g_Truth(server_socket__5) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_57.GetRawRoot__O()); var tmp3 any = A_arbace_core_server_A_const_58; tmp2.Invoke_O_O_O__O(tmp3, A_arbace_core_server_A_const_64.GetRawRoot__O(), name__0)
			jrt.NN(jrt.ServerSocket_Cast(server_socket__5)).Close__V()
//line :135:1
			tmp1 = jrt.Boolean_TRUE.Ref() } else { tmp1 = nil } }; return nil }(); /*line :133:1*/jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____2)).Unlock__V(); if /*line :126:1*/ tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :126:1
func (t *A_arbace_core_server_stop_server_A) Invoke_O__O(self any) any {




	var root_361 any = A_arbace_core_server_A_const_76.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, A_arbace_core_server_stop_server_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var tmp1 *lang.Keyword = A_arbace_core_server_A_const_54; var arg_364 any = tmp1.Invoke_O__O(A_arbace_core_server_A_const_53.Get__O()); if linked_362 == nil { return ifn_363.Invoke_O__O(arg_364) } else { return linked_362.(*A_arbace_core_server_stop_server_A).Invoke_O_O__O(root_361, arg_364)
	}
}






func A_arbace_core_server_stop_servers_A_New() *A_arbace_core_server_stop_servers_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Ctor() {}
//line :140:1
func (t *A_arbace_core_server_stop_servers_A) Invoke_O__O(self any) any { var lockee__1213000018__auto____1 any = A_arbace_core_server_A_const_56.GetRawRoot__O();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Lock__V(); var tmp1 any; tmp7 := /*line :140:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1213000063__4 any; var root_365 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_367 lang.IFn



		if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any; var root_369 any = A_arbace_core_server_A_const_77.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = A_arbace_core_server_A_const_58.GetRawRoot__O(); if linked_370 == nil { arg_368 = ifn_371.Invoke_O__O(arg_372) } else { arg_368 = linked_370.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_369, arg_372) }; if linked_366 == nil { seq_1213000063__4 = ifn_367.Invoke_O__O(arg_368) } else { seq_1213000063__4 = linked_366.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_365, arg_368) }
//line :140:1
		var chunk_1213000064__5 any; var count_1213000065__6 int64 = 0; var i_1213000066__7 int64 = 0; L1: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(i_1213000066__7, count_1213000065__6) { var name__8 any = lang.Indexed_Cast(chunk_1213000064__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1213000066__7)); var root_389 any = A_arbace_core_server_A_const_78.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_391 lang.IFn
				if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var fnbody__398 any = A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(name__8); var tmp2 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class; if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__398); A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class = fncls__397d; tmp2 = fncls__397d } else { tmp2 = fncls__397 }; arg_392 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__398, tmp2, nil); if linked_390 == nil { ifn_391.Invoke_O__O(arg_392) } else { linked_390.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_389, arg_392) }
//line :144:1
				seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1213000066__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_373 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = seq_1213000063__4; if linked_374 == nil { temp__1927000414__auto____8 = ifn_375.Invoke_O__O(arg_376) } else { temp__1927000414__auto____8 = linked_374.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_373, arg_376) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1213000063__9 any = temp__1927000414__auto____8; var tmp3 any; var root_377 any = A_arbace_core_server_A_const_42.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = seq_1213000063__9; if linked_378 == nil { tmp3 = ifn_379.Invoke_O__O(arg_380) } else { tmp3 = linked_378.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_377, arg_380) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____10 any; var root_381 any = A_arbace_core_server_A_const_43.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = seq_1213000063__9; if linked_382 == nil { c__1927000678__auto____10 = ifn_383.Invoke_O__O(arg_384) } else { c__1927000678__auto____10 = linked_382.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_381, arg_384) }; var tmp4 any; var root_399 any = A_arbace_core_server_A_const_45.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = seq_1213000063__9; if linked_400 == nil { tmp4 = ifn_401.Invoke_O__O(arg_402) } else { tmp4 = linked_400.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_399, arg_402) }; seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = tmp4, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var name__10 any; var root_385 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = seq_1213000063__9; if linked_386 == nil { name__10 = ifn_387.Invoke_O__O(arg_388) } else { name__10 = linked_386.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_385, arg_388) }
					var root_403 any = A_arbace_core_server_A_const_78.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var fnbody__412 any = A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(name__10); var tmp5 *jrt.Class; var fncls__411 *jrt.Class = A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class; if fncls__411 == nil { var fncls__411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__412); A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class = fncls__411d; tmp5 = fncls__411d } else { tmp5 = fncls__411 }; arg_406 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__412, tmp5, nil); if linked_404 == nil { ifn_405.Invoke_O__O(arg_406) } else { linked_404.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_403, arg_406) }
//line :144:1
					var tmp6 any; var root_413 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = seq_1213000063__9; if linked_414 == nil { tmp6 = ifn_415.Invoke_O__O(arg_416) } else { tmp6 = linked_414.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_413, arg_416) }; seq_1213000063__4, chunk_1213000064__5, count_1213000065__6, i_1213000066__7 = tmp6, nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :140:1
			break L1 } }; return nil }();


	jrt.NN(jrt.As[*jrt.ReentrantLock](lockee__1213000018__auto____1)).Unlock__V(); if /*line :140:1*/ tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_core_server_stop_servers_fn__1213000067_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000067_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000067_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000067_A) Invoke_O__O(self any) any { var root_393 any = A_arbace_core_server_A_const_76.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_core_server_stop_server_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var t_ any = t.F_name; t.F_name = nil; arg_396 = t_; if linked_394 == nil { return ifn_395.Invoke_O__O(arg_396) } else { return linked_394.(*A_arbace_core_server_stop_server_A).Invoke_O_O__O(root_393, arg_396) } }
//line :145:1
func A_arbace_core_server_stop_servers_fn__1213000069_A_New_O(p0 any) *A_arbace_core_server_stop_servers_fn__1213000069_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_stop_servers_fn__1213000069_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :145:1
func (t *A_arbace_core_server_stop_servers_fn__1213000069_A) Invoke_O__O(self any) any { var root_407 any = A_arbace_core_server_A_const_76.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_core_server_stop_server_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var t_ any = t.F_name; t.F_name = nil; arg_410 = t_; if linked_408 == nil { return ifn_409.Invoke_O__O(arg_410) } else { return linked_408.(*A_arbace_core_server_stop_server_A).Invoke_O_O__O(root_407, arg_410) } }

func A_arbace_core_server_parse_props_A_New() *A_arbace_core_server_parse_props_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_parse_props_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Ctor() {}
//line :147:1
func (t *A_arbace_core_server_parse_props_A) Invoke_O_O__O(self, props__0 any) any {


	var root_417 any = A_arbace_core_server_A_const_79.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any; var fnbody__443 any = A_arbace_core_server_parse_props_fn__1213000072_A_New_O(props__0); var tmp1 *jrt.Class; var fncls__442 *jrt.Class = A_arbace_core_server_parse_props_fn__1213000072_A_fn_class
	if fncls__442 == nil { var fncls__442d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__443); A_arbace_core_server_parse_props_fn__1213000072_A_fn_class = fncls__442d; tmp1 = fncls__442d } else { tmp1 = fncls__442 }; arg_420 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__443, tmp1, nil)
//line :150:1
	var arg_421 any = lang.PersistentVector_EMPTY.Ref(); var arg_422 any = jrt.Properties_Cast(props__0).StringPropertyNames__Set(); if linked_418 == nil { return ifn_419.Invoke_O_O_O__O(arg_420, arg_421, arg_422) } else { return linked_418.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_417, arg_420, arg_421, arg_422) } }
func A_arbace_core_server_parse_props_fn__1213000072_A_New_O(p0 any) *A_arbace_core_server_parse_props_fn__1213000072_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_parse_props_fn__1213000072_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Ctor_O(c__props any) { t.F_props = c__props }
//line :151:1
func (t *A_arbace_core_server_parse_props_fn__1213000072_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var vec__1213000073__3 any; var root_423 any = A_arbace_core_server_A_const_80.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_425 lang.IFn; if
													linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = k__2; var arg_427 any = A_arbace_core_server_A_const_81; if linked_424 == nil { vec__1213000073__3 = ifn_425.Invoke_O_O__O(arg_426, arg_427) } else { vec__1213000073__3 = linked_424.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_423, arg_426, arg_427) }; var k1__4 any = /*line :151:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1213000073__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k2__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000073__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k3__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000073__3, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(k1__4, Lit_20); if and__1927000168__auto____7 {

		tmp1 = lang.Util_Equiv_O_O__Z_NoInit(k2__5, Lit_21) } else { tmp1 = and__1927000168__auto____7 }; if tmp1 { var v__7 any = lang.RT_Get_O_O__O_NoInit(t.F_props, k__2); var root_428 any = A_arbace_core_server_A_const_9.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_430 lang.IFn

			if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = acc__1; var arg_432 any; var root_433 any = A_arbace_core_server_A_const_82.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_33, k3__6)); var arg_437 any; var root_438 any = A_arbace_core_server_A_const_83.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_edn.A_arbace_edn_read_string_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = v__7; if linked_439 == nil { arg_437 = ifn_440.Invoke_O__O(arg_441) } else { arg_437 = linked_439.(*aot_arbace_edn.A_arbace_edn_read_string_A).Invoke_O_O__O(root_438, arg_441) }; if linked_434 == nil { arg_432 = ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { arg_432 = linked_434.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) }; if linked_429 == nil { return ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { return linked_429.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) } } else {
//line :153:1
				return acc__1 } }






func A_arbace_core_server_start_servers_A_New() *A_arbace_core_server_start_servers_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_start_servers_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Ctor() {}
//line :160:1
func (t *A_arbace_core_server_start_servers_A) Invoke_O_O__O(self, system_props__0 any) any { { var seq_1213000078__2 any; var root_444 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_446 lang.IFn


	if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any; var root_448 any = A_arbace_core_server_A_const_84.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, A_arbace_core_server_parse_props_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = system_props__0; if linked_449 == nil { arg_447 = ifn_450.Invoke_O__O(arg_451) } else { arg_447 = linked_449.(*A_arbace_core_server_parse_props_A).Invoke_O_O__O(root_448, arg_451) }; if linked_445 == nil { seq_1213000078__2 = ifn_446.Invoke_O__O(arg_447) } else { seq_1213000078__2 = linked_445.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_444, arg_447) }
//line :160:1
	var chunk_1213000079__3 any; var count_1213000080__4 int64 = 0; var i_1213000081__5 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(i_1213000081__5, count_1213000080__4) { var server__6 any = lang.Indexed_Cast(chunk_1213000079__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1213000081__5)); var root_468 any = A_arbace_core_server_A_const_85.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, A_arbace_core_server_start_server_A_fn_class); var ifn_470 lang.IFn
			if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = server__6; if linked_469 == nil { ifn_470.Invoke_O__O(arg_471) } else { linked_469.(*A_arbace_core_server_start_server_A).Invoke_O_O__O(root_468, arg_471) }
//line :163:1
			seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1213000081__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_452 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1213000078__2; if linked_453 == nil { temp__1927000414__auto____6 = ifn_454.Invoke_O__O(arg_455) } else { temp__1927000414__auto____6 = linked_453.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_452, arg_455) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1213000078__7 any = temp__1927000414__auto____6; var tmp1 any; var root_456 any = A_arbace_core_server_A_const_42.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = seq_1213000078__7; if linked_457 == nil { tmp1 = ifn_458.Invoke_O__O(arg_459) } else { tmp1 = linked_457.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_456, arg_459) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_460 any = A_arbace_core_server_A_const_43.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = seq_1213000078__7; if linked_461 == nil { c__1927000678__auto____8 = ifn_462.Invoke_O__O(arg_463) } else { c__1927000678__auto____8 = linked_461.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_460, arg_463) }; var tmp2 any; var root_472 any = A_arbace_core_server_A_const_45.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = seq_1213000078__7; if linked_473 == nil { tmp2 = ifn_474.Invoke_O__O(arg_475) } else { tmp2 = linked_473.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_472, arg_475) }; seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var server__8 any; var root_464 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = seq_1213000078__7; if linked_465 == nil { server__8 = ifn_466.Invoke_O__O(arg_467) } else { server__8 = linked_465.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_464, arg_467) }
				var root_476 any = A_arbace_core_server_A_const_85.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, A_arbace_core_server_start_server_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = server__8; if linked_477 == nil { ifn_478.Invoke_O__O(arg_479) } else { linked_477.(*A_arbace_core_server_start_server_A).Invoke_O_O__O(root_476, arg_479) }
//line :163:1
				var tmp3 any; var root_480 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = seq_1213000078__7; if linked_481 == nil { tmp3 = ifn_482.Invoke_O__O(arg_483) } else { tmp3 = linked_481.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_480, arg_483) }; seq_1213000078__2, chunk_1213000079__3, count_1213000080__4, i_1213000081__5 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :160:1*/panic("j2g: unreachable") }





func A_arbace_core_server_repl_init_A_New() *A_arbace_core_server_repl_init_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_init_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Ctor() {}
//line :166:1
func (t *A_arbace_core_server_repl_init_A) Invoke_O__O(self any) any {


	lang.IFn_Cast(A_arbace_core_server_A_const_87.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_88)
	var root_484 any = A_arbace_core_server_A_const_15.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = A_arbace_core_server_A_const_2.GetRawRoot__O(); var arg_488 any = A_arbace_core_server_A_const_86.GetRawRoot__O(); if linked_485 == nil { return ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { return linked_485.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_484, arg_487, arg_488)
	} }
func A_arbace_core_server_repl_read_A_New() *A_arbace_core_server_repl_read_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_read_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Ctor() {}
//line :172:1
func (t *A_arbace_core_server_repl_read_A) Invoke_O_O_O__O(self, request_prompt__0, request_exit__1 any) any { var or__1927000174__auto____3 any; var tmp1 lang.IFn = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_89, request_prompt__0, A_arbace_core_server_A_const_90, request_exit__1))); var tmp2 any; var root_495 any = A_arbace_core_server_A_const_94.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_main.A_arbace_main_skip_whitespace_A_fn_class); var ifn_497 lang.IFn; if



	linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = A_arbace_core_server_A_const_50.Get__O(); if linked_496 == nil { tmp2 = ifn_497.Invoke_O__O(arg_498) } else { tmp2 = linked_496.(*aot_arbace_main.A_arbace_main_skip_whitespace_A).Invoke_O_O__O(root_495, arg_498) }; or__1927000174__auto____3 = /*line :175:1*/tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var input__4 any; var root_489 any = A_arbace_core_server_A_const_91.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_491 lang.IFn

		if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = A_arbace_core_server_A_const_92; var arg_493 any = A_arbace_core_server_A_const_50.Get__O(); if linked_490 == nil { input__4 = ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { input__4 = linked_490.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) }
		var root_499 any = A_arbace_core_server_A_const_95.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_main.A_arbace_main_skip_if_eol_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = A_arbace_core_server_A_const_50.Get__O(); if linked_500 == nil { ifn_501.Invoke_O__O(arg_502) } else { linked_500.(*aot_arbace_main.A_arbace_main_skip_if_eol_A).Invoke_O_O__O(root_499, arg_502) }
//line :175:1
		var G__1213000084__5_ any = input__4



		switch lang.Util_Hash_O__I_NoInit(G__1213000084__5_) { case 1244597485: if any(G__1213000084__5_) == any(A_arbace_core_server_A_const_93) { return request_exit__1 }; default:}; return input__4 } }



func A_arbace_core_server_repl_A_New() *A_arbace_core_server_repl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_repl_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_core_server_repl_A) Ctor() {}
//line :183:1
func (t *A_arbace_core_server_repl_A) Invoke_O__O(self any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_core_server_A_const_97; var tmp3 any = A_arbace_core_server_A_const_98.GetRawRoot__O(); var tmp4 any = A_arbace_core_server_A_const_99; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, A_arbace_core_server_A_const_100.GetRawRoot__O())
}


func A_arbace_core_server_ex__GT_data_A_New() *A_arbace_core_server_ex__GT_data_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_ex__GT_data_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Ctor() {}
//line :190:1
func (t *A_arbace_core_server_ex__GT_data_A) Invoke_O_O_O__O(self, ex__0, phase__1 any) any {

	var root_510 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any; var root_516 any = A_arbace_core_server_A_const_101.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = ex__0; if linked_517 == nil { arg_513 = ifn_518.Invoke_O__O(arg_519) } else { arg_513 = linked_517.(*aot_arbace_core.A_arbace_core_Throwable__GT_map_A).Invoke_O_O__O(root_516, arg_519) }; var arg_514 any = A_arbace_core_server_A_const_102; var arg_515 any = phase__1; if linked_511 == nil { return ifn_512.Invoke_O_O_O__O(arg_513, arg_514, arg_515) } else { return linked_511.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_510, arg_513, arg_514, arg_515)
	} }
func A_arbace_core_server_prepl_A_New() *A_arbace_core_server_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_core_server_prepl_A) Ctor() {}
//line :194:1
func (t *A_arbace_core_server_prepl_A) DoInvoke_O_O_O_O__O(self, in_reader__0, out_fn__1, p__1213000091__2 any) any { var map__1213000092__4 any = p__1213000091__2; var map__1213000092__5 any; if lang.ISeq_InstanceOf(map__1213000092__4) { var tmp1 any; var root_520 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = map__1213000092__4; if linked_521 == nil { tmp1 = ifn_522.Invoke_O__O(arg_523) } else { tmp1 = linked_521.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_520, arg_523) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_524 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = map__1213000092__4; if linked_525 == nil { tmp2 = ifn_526.Invoke_O__O(arg_527) } else { tmp2 = linked_525.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_524, arg_527) }; map__1213000092__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_528 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = map__1213000092__4; if linked_529 == nil { tmp3 = ifn_530.Invoke_O__O(arg_531) } else { tmp3 = linked_529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_528, arg_531) }; if jrt.J2g_Truth(tmp3) { var root_532 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = map__1213000092__4; if linked_533 == nil { map__1213000092__5 = ifn_534.Invoke_O__O(arg_535) } else { map__1213000092__5 = linked_533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_532, arg_535) } } else { map__1213000092__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000092__5 = map__1213000092__4 }; var stdin__6 any = lang.RT_Get_O_O__O_NoInit(map__1213000092__5, A_arbace_core_server_A_const_103); var tmp4 any = jrt.Thread_CurrentThread__Thread(); var tmp5 *jrt.Class = A_arbace_core_server_A_const_128; var cl__7 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp4, tmp5, Lit_22, jrt.RefArrayOf(jrt.Object_class)); var tmp6 any = jrt.Thread_CurrentThread__Thread(); var tmp7 *jrt.Class = A_arbace_core_server_A_const_128;



























	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp6, tmp7, Lit_23, jrt.RefArrayOf(jrt.Object_class, cl__7)); var EOF__7_ any = /*line :194:1*/jrt.Object_New(); var tapfn__8 any; var fnbody__537 any = A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(out_fn__1); var tmp8 *jrt.Class; var fncls__536 *jrt.Class = A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class; if




























	fncls__536 == nil { var fncls__536d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__537); A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class = fncls__536d; tmp8 = fncls__536d } else { tmp8 = fncls__536 }; tapfn__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__537, tmp8, nil); var root_589 any =

	A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var tmp9 any = A_arbace_core_server_A_const_117; var tmp10 any = A_arbace_core_server_A_const_117.Get__O(); var tmp11 any = A_arbace_core_server_A_const_129; var tmp12 any = A_arbace_core_server_A_const_129.Get__O(); var tmp13 any = A_arbace_core_server_A_const_130; var tmp14 any = A_arbace_core_server_A_const_130.Get__O(); var tmp15 any = A_arbace_core_server_A_const_131; var tmp16 any = A_arbace_core_server_A_const_131.Get__O(); var tmp17 any = A_arbace_core_server_A_const_132; var tmp18 any = A_arbace_core_server_A_const_132.Get__O(); var tmp19 any = A_arbace_core_server_A_const_133; var tmp20 any = A_arbace_core_server_A_const_133.Get__O(); var tmp21 any = A_arbace_core_server_A_const_134; var tmp22 any = jrt.Boolean_TRUE.Ref(); var tmp23 any = A_arbace_core_server_A_const_135; var tmp24 any = A_arbace_core_server_A_const_135.Get__O(); var tmp25 any = A_arbace_core_server_A_const_136; var tmp26 any = A_arbace_core_server_A_const_136.Get__O(); var tmp27 any = A_arbace_core_server_A_const_137; var tmp28 any = jrt.System_GetProperty_String_String__String(Lit_25, Lit_26).Ref(); var tmp29 any = A_arbace_core_server_A_const_138; var tmp30 any = A_arbace_core_server_A_const_138.Get__O(); var tmp31 any = A_arbace_core_server_A_const_139; var tmp32 any = A_arbace_core_server_A_const_139.Get__O(); var tmp33 any = A_arbace_core_server_A_const_140; var tmp34 any = A_arbace_core_server_A_const_140.Get__O(); var tmp35 any = A_arbace_core_server_A_const_141; var arg_592 any = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, A_arbace_core_server_A_const_141.Get__O(), A_arbace_core_server_A_const_114, nil, A_arbace_core_server_A_const_113, nil, A_arbace_core_server_A_const_112, nil, A_arbace_core_server_A_const_120, nil)))); if linked_590 == nil { ifn_591.Invoke_O__O(arg_592) } else { linked_590.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_589, arg_592) }; var tmp36 any; tmp54 := /*line :194:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)































		lang.IFn_Cast(A_arbace_core_server_A_const_87.GetRawRoot__O()).Invoke_O__O(A_arbace_core_server_A_const_142)
		{ var root_593 any = A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()); var tmp38 any = A_arbace_core_server_A_const_143; var tmp39 any = jrt.Boolean_TRUE.Ref(); var tmp40 any = A_arbace_core_server_A_const_50; var tmp41 any; var or__1927000174__auto____11 any = stdin__6
			if jrt.J2g_Truth(or__1927000174__auto____11) { tmp41 = or__1927000174__auto____11 } else { tmp41 = in_reader__0 }
//line :227:1
			var tmp42 any = tmp41; var tmp43 any = A_arbace_core_server_A_const_51; var tmp44 any; var root_608 any = A_arbace_core_server_A_const_144.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class); var ifn_610 lang.IFn

			if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any; var fnbody__615 any = A_arbace_core_server_prepl_fn__1213000096_A_New_O(out_fn__1); var tmp45 *jrt.Class; var fncls__614 *jrt.Class = A_arbace_core_server_prepl_fn__1213000096_A_fn_class; if fncls__614 == nil { var fncls__614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__615); A_arbace_core_server_prepl_fn__1213000096_A_fn_class = fncls__614d; tmp45 = fncls__614d } else { tmp45 = fncls__614 }; arg_611 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__615, tmp45, nil); var arg_612 any; var arg_613 any = jrt.Boolean_TRUE.Ref(); if linked_609 == nil { tmp44 = ifn_610.Invoke_O_O_O__O(arg_611, arg_612, arg_613) } else { tmp44 = linked_609.(*aot_arbace_core.A_arbace_core_PrintWriter_on_A).Invoke_O_O_O_O__O(root_608, arg_611, arg_612, arg_613) }
//line :227:1
			var tmp46 any = tmp44; var tmp47 any = A_arbace_core_server_A_const_52; var tmp48 any; var root_616 any = A_arbace_core_server_A_const_144.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_PrintWriter_on_A_fn_class); var ifn_618 lang.IFn


			if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var fnbody__623 any = A_arbace_core_server_prepl_fn__1213000098_A_New_O(out_fn__1); var tmp49 *jrt.Class; var fncls__622 *jrt.Class = A_arbace_core_server_prepl_fn__1213000098_A_fn_class; if fncls__622 == nil { var fncls__622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__623); A_arbace_core_server_prepl_fn__1213000098_A_fn_class = fncls__622d; tmp49 = fncls__622d } else { tmp49 = fncls__622 }; arg_619 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__623, tmp49, nil); var arg_620 any; var arg_621 any = jrt.Boolean_TRUE.Ref(); if linked_617 == nil { tmp48 = ifn_618.Invoke_O_O_O__O(arg_619, arg_620, arg_621) } else { tmp48 = linked_617.(*aot_arbace_core.A_arbace_core_PrintWriter_on_A).Invoke_O_O_O_O__O(root_616, arg_619, arg_620, arg_621) }
//line :227:1
			arg_596 = tmp37.Invoke_O_O_O_O_O_O_O_O__O(tmp38, tmp39, tmp40, tmp42, tmp43, tmp46, tmp47, tmp48); if linked_594 == nil { ifn_595.Invoke_O__O(arg_596) } else { linked_594.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_593, arg_596) }; tmp53 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







































				{ tmp52 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
//line :232:1
					{ var root_624 any = A_arbace_core_server_A_const_147.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_add_tap_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = tapfn__8; if linked_625 == nil { ifn_626.Invoke_O__O(arg_627) } else { linked_625.(*aot_arbace_core.A_arbace_core_add_tap_A).Invoke_O_O__O(root_624, arg_627) }
//line :194:1
					L1: for {







































						var tmp50 *lang.Compiler_AOTFn; var fnbody__578 any = A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(EOF__7_, out_fn__1, in_reader__0); var tmp51 *jrt.Class; var fncls__577 *jrt.Class = A_arbace_core_server_prepl_fn__1213000100_A_fn_class; if fncls__577 == nil { var fncls__577d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__578); A_arbace_core_server_prepl_fn__1213000100_A_fn_class = fncls__577d; tmp51 = fncls__577d } else { tmp51 = fncls__577 }; tmp50 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__578, tmp51, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp50).Invoke__O()) {






























							continue L1 } else {
//line :234:1
								tmp36 = nil }
//line :194:1
						break L1
					}
					}






































































					return nil }(); var root_579 any = A_arbace_core_server_A_const_127.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_remove_tap_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = tapfn__8; if linked_580 == nil { ifn_581.Invoke_O__O(arg_582) } else { linked_580.(*aot_arbace_core.A_arbace_core_remove_tap_A).Invoke_O_O__O(root_579, arg_582) }
//line :194:1
					if tmp52 != nil { panic(tmp52)
					}
				}






























				return nil }(); var root_583 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; if linked_584 == nil { ifn_585.Invoke__O() } else { linked_584.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_583) }
//line :194:1
			if tmp53 != nil { panic(tmp53) } }; return nil }(); var root_586 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_588 lang.IFn; if






























	linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; if linked_587 == nil { ifn_588.Invoke__O() } else { linked_587.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_586) }; if /*line :194:1*/ tmp54 != nil { panic(tmp54) }; return tmp36 }




























func A_arbace_core_server_prepl_tapfn__1213000094_A_New_O(p0 any) *A_arbace_core_server_prepl_tapfn__1213000094_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_tapfn__1213000094_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :223:1
func (t *A_arbace_core_server_prepl_tapfn__1213000094_A) Invoke_O_O__O(self, p1__1213000088_SHARP___1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_105, A_arbace_core_server_A_const_106, p1__1213000088_SHARP___1)))
}



func A_arbace_core_server_prepl_fn__1213000096_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000096_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000096_A{}; t.Ctor_O(p0); return t }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :229:1
func (t *A_arbace_core_server_prepl_fn__1213000096_A) Invoke_O_O__O(self, p1__1213000089_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_145, A_arbace_core_server_A_const_106, p1__1213000089_SHARP___1))) }
func A_arbace_core_server_prepl_fn__1213000098_A_New_O(p0 any) *A_arbace_core_server_prepl_fn__1213000098_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000098_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Ctor_O(c__out_fn any) { t.F_out_fn = c__out_fn }
//line :230:1
func (t *A_arbace_core_server_prepl_fn__1213000098_A) Invoke_O_O__O(self, p1__1213000090_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_out_fn); return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_104, A_arbace_core_server_A_const_146, A_arbace_core_server_A_const_106, p1__1213000090_SHARP___1))) }



func A_arbace_core_server_prepl_fn__1213000100_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_prepl_fn__1213000100_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_prepl_fn__1213000100_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Ctor_O_O_O(c__EOF, c__out_fn, c__in_reader any) { t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_in_reader = c__in_reader }
//line :234:1
func (t *A_arbace_core_server_prepl_fn__1213000100_A) Invoke_O__O(self any) any { var tmp1 any; tmp26 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1213000101__3 any; var root_538 any = A_arbace_core_server_A_const_107.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_read_PLUS_string_A_fn_class); var ifn_540 lang.IFn
										if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_core_server_A_const_108, t.F_EOF, A_arbace_core_server_A_const_109, A_arbace_core_server_A_const_110)); var arg_542 any; var t_ any = t.F_in_reader; t.F_in_reader = nil; arg_542 = t_; if linked_539 == nil { vec__1213000101__3 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { vec__1213000101__3 = linked_539.(*aot_arbace_core.A_arbace_core_read_PLUS_string_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }
//line :234:1
	var form__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000101__3, lang.RT_IntCast_J__I_NoInit(0), nil); var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1213000101__3, lang.RT_IntCast_J__I_NoInit(1), nil); tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp2 any; var t__2 any = t.F_EOF; t.F_EOF = nil; tmp2 = t__2; if lang.Util_Identical_O_O__Z_NoInit(form__4, tmp2) { tmp1 = nil } else { var start__8 int64 = jrt.System_NanoTime__J(); var ret__9 any; var root_543 any = A_arbace_core_server_A_const_111.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_eval_A_fn_class); var ifn_545 lang.IFn

			if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = form__4; if linked_544 == nil { ret__9 = ifn_545.Invoke_O__O(arg_546) } else { ret__9 = linked_544.(*aot_arbace_core.A_arbace_core_eval_A).Invoke_O_O__O(root_543, arg_546) }
//line :237:1
			var ms__10 int64 = lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), start__8), 1000000)



			if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_core_server_A_const_93, ret__9) { tmp1 = nil } else { var tmp3 *lang.Var = A_arbace_core_server_A_const_112; tmp3.Set_O__O(A_arbace_core_server_A_const_113.Get__O()); var tmp4 *lang.Var = A_arbace_core_server_A_const_113; tmp4.Set_O__O(A_arbace_core_server_A_const_114.Get__O()); A_arbace_core_server_A_const_114.Set_O__O(ret__9)



				var tmp5 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp6 any = A_arbace_core_server_A_const_104; var tmp7 any = A_arbace_core_server_A_const_115; var tmp8 any = A_arbace_core_server_A_const_106; var tmp9 any
				if jrt.Throwable_InstanceOf(ret__9) {
					var root_547 any = A_arbace_core_server_A_const_101.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = ret__9; if linked_548 == nil { tmp9 = ifn_549.Invoke_O__O(arg_550) } else { tmp9 = linked_548.(*aot_arbace_core.A_arbace_core_Throwable__GT_map_A).Invoke_O_O__O(root_547, arg_550) } } else {
//line :246:1
						tmp9 = ret__9 }
//line :245:1
				var tmp10 any = tmp9; var tmp11 any = A_arbace_core_server_A_const_116; var tmp12 any; var root_551 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_553 lang.IFn



				if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = lang.Namespace_Cast(A_arbace_core_server_A_const_117.Get__O()).F_name.Ref(); if linked_552 == nil { tmp12 = ifn_553.Invoke_O__O(arg_554) } else { tmp12 = linked_552.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_551, arg_554) }
//line :245:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_core_server_A_const_118; tmp5.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp13, tmp14, jrt.Long_ValueOf_J__Long_NoInit(ms__10).Ref(), A_arbace_core_server_A_const_119, s__5)))
//line :241:1
				tmp1 = jrt.Boolean_TRUE.Ref() } } }
//line :234:1
		return nil }(); if tmp15 != nil { if true { var ex__8 jrt.Throwable_I = tmp15; A_arbace_core_server_A_const_120.Set_O__O(ex__8)




















			var tmp16 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp17 any = A_arbace_core_server_A_const_104; var tmp18 any = A_arbace_core_server_A_const_115; var tmp19 any = A_arbace_core_server_A_const_106; var tmp20 any; var root_555 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = ex__8; var arg_559 any; var or__1927000174__auto____9 any; var tmp21 *lang.Keyword = A_arbace_core_server_A_const_122; var tmp22 any; var root_560 any = A_arbace_core_server_A_const_123.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = ex__8; if linked_561 == nil { tmp22 = ifn_562.Invoke_O__O(arg_563) } else { tmp22 = linked_561.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_560, arg_563) }; or__1927000174__auto____9 = tmp21.Invoke_O__O(tmp22); if jrt.J2g_Truth(or__1927000174__auto____9) { arg_559 = or__1927000174__auto____9 } else { arg_559 = A_arbace_core_server_A_const_124 }; if linked_556 == nil { tmp20 = ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { tmp20 = linked_556.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) }; var tmp23 any = tmp20; var tmp24 any = A_arbace_core_server_A_const_116; var tmp25 any; var root_564 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_566 lang.IFn
			if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = lang.Namespace_Cast(A_arbace_core_server_A_const_117.Get__O()).F_name.Ref(); if linked_565 == nil { tmp25 = ifn_566.Invoke_O__O(arg_567) } else { tmp25 = linked_565.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_564, arg_567) }
//line :255:1
			tmp16.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp23, tmp24, tmp25, A_arbace_core_server_A_const_119, s__5, A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref())))
//line :234:1
			tmp1 = jrt.Boolean_TRUE.Ref() } } }; return nil }(); if tmp26 != nil { if true { var ex__3 jrt.Throwable_I = tmp26; A_arbace_core_server_A_const_120.Set_O__O(ex__3)


























				var tmp27 any; var t__3 any = t.F_out_fn; t.F_out_fn = nil; tmp27 = t__3; var tmp28 lang.IFn = lang.IFn_Cast(tmp27); var tmp29 any = A_arbace_core_server_A_const_104; var tmp30 any = A_arbace_core_server_A_const_115; var tmp31 any = A_arbace_core_server_A_const_106; var tmp32 any; var root_568 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = ex__3; var arg_572 any = A_arbace_core_server_A_const_126; if linked_569 == nil { tmp32 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { tmp32 = linked_569.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; var tmp33 any = tmp32; var tmp34 any = A_arbace_core_server_A_const_116; var tmp35 any; var root_573 any = A_arbace_core_server_A_const_73.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_575 lang.IFn
				if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = lang.Namespace_Cast(A_arbace_core_server_A_const_117.Get__O()).F_name.Ref(); if linked_574 == nil { tmp35 = ifn_575.Invoke_O__O(arg_576) } else { tmp35 = linked_574.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_573, arg_576) }
//line :261:1
				tmp28.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, tmp33, tmp34, tmp35, A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref())))
//line :234:1
				tmp1 = jrt.Boolean_TRUE.Ref() } }; return tmp1 }


































func A_arbace_core_server_resolve_fn_A_New() *A_arbace_core_server_resolve_fn_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_resolve_fn_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Ctor() {}
//line :269:1
func (t *A_arbace_core_server_resolve_fn_A) Invoke_O_O__O(self, valf__0 any) any {
	var tmp1 any; var root_628 any = A_arbace_core_server_A_const_148.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = valf__0; if linked_629 == nil { tmp1 = ifn_630.Invoke_O__O(arg_631) } else { tmp1 = linked_629.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_628, arg_631) }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var root_632 any = A_arbace_core_server_A_const_46.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_634 lang.IFn
		if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = valf__0; if linked_633 == nil { or__1927000174__auto____2 = ifn_634.Invoke_O__O(arg_635) } else { or__1927000174__auto____2 = linked_633.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_632, arg_635) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var temp__1927000414__auto____3 any; var root_636 any = A_arbace_core_server_A_const_62.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_638 lang.IFn
			if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = valf__0; if linked_637 == nil { temp__1927000414__auto____3 = ifn_638.Invoke_O__O(arg_639) } else { temp__1927000414__auto____3 = linked_637.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_636, arg_639) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var nsname__4 any = temp__1927000414__auto____3; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_2.GetRawRoot__O()); var tmp3 any; var root_648 any = A_arbace_core_server_A_const_61.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_650 lang.IFn
				if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = nsname__4; if linked_649 == nil { tmp3 = ifn_650.Invoke_O__O(arg_651) } else { tmp3 = linked_649.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_648, arg_651) }; tmp2.Invoke_O__O(tmp3)
				var root_640 any = A_arbace_core_server_A_const_46.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = valf__0; if linked_641 == nil { or__1927000174__auto____3 = ifn_642.Invoke_O__O(arg_643) } else { or__1927000174__auto____3 = linked_641.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_640, arg_643) } } else {
//line :272:1
					or__1927000174__auto____3 = nil }
//line :271:1
			if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_35, nil), jrt.RefArrayOf(jrt.Object_class, nil, valf__0))))) } } } else {
//line :270:1
				return valf__0
			}
}





func A_arbace_core_server_io_prepl_A_New() *A_arbace_core_server_io_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) Ctor() {}
//line :278:1
func (t *A_arbace_core_server_io_prepl_A) DoInvoke_O_O__O(self, p__1213000107__0 any) any { var default__1213000110__2 any = A_arbace_core_server_A_const_149.GetRawRoot__O(); var map__1213000108__3 any = p__1213000107__0; var map__1213000108__4 any; if lang.ISeq_InstanceOf(map__1213000108__3) { var tmp1 any; var root_652 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = map__1213000108__3; if linked_653 == nil { tmp1 = ifn_654.Invoke_O__O(arg_655) } else { tmp1 = linked_653.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_652, arg_655) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_656 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = map__1213000108__3; if linked_657 == nil { tmp2 = ifn_658.Invoke_O__O(arg_659) } else { tmp2 = linked_657.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_656, arg_659) }; map__1213000108__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_660 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = map__1213000108__3; if linked_661 == nil { tmp3 = ifn_662.Invoke_O__O(arg_663) } else { tmp3 = linked_661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_660, arg_663) }; if jrt.J2g_Truth(tmp3) { var root_664 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = map__1213000108__3; if linked_665 == nil { map__1213000108__4 = ifn_666.Invoke_O__O(arg_667) } else { map__1213000108__4 = linked_665.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_664, arg_667) } } else { map__1213000108__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000108__4 = map__1213000108__3 }; var valf__5 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000108__4, A_arbace_core_server_A_const_150, default__1213000110__2); var valf__6 any; var root_668 any = A_arbace_core_server_A_const_151.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, A_arbace_core_server_resolve_fn_A_fn_class); var ifn_670 lang.IFn; if







	linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = valf__5; if linked_669 == nil { valf__6 = ifn_670.Invoke_O__O(arg_671) } else { valf__6 = linked_669.(*A_arbace_core_server_resolve_fn_A).Invoke_O_O__O(root_668, arg_671) }; var out__7 any = /*line :278:1*/A_arbace_core_server_A_const_51.Get__O(); var lock__8 any = jrt.Object_New(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_152.GetRawRoot__O()); var tmp5 any = A_arbace_core_server_A_const_50.Get__O(); var tmp6 *lang.Compiler_AOTFn; var fnbody__719 any = A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(lock__8, out__7, valf__6); var tmp7 *jrt.Class; var fncls__718 *jrt.Class = A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class; if











	fncls__718 == nil { var fncls__718d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__719); A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class = fncls__718d; tmp7 = fncls__718d } else { tmp7 = fncls__718 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__719, tmp7, nil); return /*line :289:1*/ tmp4.Invoke_O_O__O(tmp5, tmp6.Ref()) }
func A_arbace_core_server_io_prepl_fn__1213000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_io_prepl_fn__1213000112_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Ctor_O_O_O(c__lock, c__out, c__valf any) { t.F_lock = c__lock; t.F_out = c__out; t.F_valf = c__valf }
//line :290:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_A) Invoke_O_O__O(self, m__1 any) any {
	var root_705 any = A_arbace_core_server_A_const_48.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = lang.IFn_Cast(A_arbace_core_server_A_const_49.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_core_server_A_const_51, t.F_out, A_arbace_core_server_A_const_156, jrt.Boolean_TRUE.Ref(), A_arbace_core_server_A_const_157, jrt.Boolean_TRUE.Ref()); if linked_706 == nil { ifn_707.Invoke_O__O(arg_708) } else { linked_706.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_705, arg_708) }
//line :290:1
	var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var lockee__1927000360__auto____4 any = t.F_lock; var locklocal__1927000361__auto____7 any = lockee__1927000360__auto____4; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____7); tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_153.GetRawRoot__O()); var tmp3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_154); if jrt.J2g_Truth(tmp4.Invoke_O__O(A_arbace_core_server_A_const_104.Invoke_O__O(m__1))) {
			var tmp5 *lang.Compiler_AOTFn; var fnbody__701 any = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(m__1, t.F_valf); var tmp6 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__701); A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class = fncls__700d; tmp6 = fncls__700d } else { tmp6 = fncls__700 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__701, tmp6, nil); tmp3 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O() } else {
//line :293:1
				tmp3 = m__1 }; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :290:1
		return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____7); if tmp7 != nil { panic(tmp7) } }; return nil }(); var root_702 any = A_arbace_core_server_A_const_47.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_704 lang.IFn
	if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; if linked_703 == nil { ifn_704.Invoke__O() } else { linked_703.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_702) }
//line :290:1
	if tmp8 != nil { panic(tmp8) }; return tmp1
}


func A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_New_O_O(p0, p1 any) *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A{}; t.Ctor_O_O(p0, p1); return t }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Ctor_O_O(c__m, c__valf any) { t.F_m = c__m; t.F_valf = c__valf }
//line :294:1
func (t *A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_681 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = t.F_m; var arg_685 any = A_arbace_core_server_A_const_106; var tmp2 lang.IFn = lang.IFn_Cast(t.F_valf); var arg_686 any = tmp2.Invoke_O__O(A_arbace_core_server_A_const_106.Invoke_O__O(t.F_m)); if linked_682 == nil { tmp1 = ifn_683.Invoke_O_O_O__O(arg_684, arg_685, arg_686) } else { tmp1 = linked_682.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_681, arg_684, arg_685, arg_686) } }
//line :294:1
	return nil }(); if tmp3 != nil { if true { var ex__3 jrt.Throwable_I = tmp3; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp5 any; var t_ any = t.F_m


		t.F_m = nil; tmp5 = t_; var tmp6 any = tmp5; var tmp7 any = A_arbace_core_server_A_const_106; var tmp8 any; var t__2 any = t.F_valf; t.F_valf = nil; tmp8 = t__2; var tmp9 lang.IFn = lang.IFn_Cast(tmp8); var tmp10 any; var root_695 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = ex__3; var arg_699 any = A_arbace_core_server_A_const_155; if linked_696 == nil { tmp10 = ifn_697.Invoke_O_O__O(arg_698, arg_699) } else { tmp10 = linked_696.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_695, arg_698, arg_699) }; tmp1 = tmp4.Invoke_O_O_O_O_O__O(tmp6, tmp7, tmp9.Invoke_O__O(tmp10), A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref()) } }; return tmp1 }



func A_arbace_core_server_remote_prepl_A_New() *A_arbace_core_server_remote_prepl_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_A) DoInvoke_O_O_O_O_O_O__O(self, host__0, port__1, in_reader__2, out_fn__3, p__1213000119__4 any) any { var default__1213000122__6 any = A_arbace_core_server_A_const_158.GetRawRoot__O(); var default__1213000123__7 any; var fnbody__727 any = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New(); var tmp1 *jrt.Class; var fncls__726 *jrt.Class = A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class; if fncls__726 == nil { var fncls__726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class = fncls__726d; tmp1 = fncls__726d } else { tmp1 = fncls__726 }; default__1213000123__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__727, tmp1, nil); var map__1213000120__8 any = p__1213000119__4; var map__1213000120__9 any; if lang.ISeq_InstanceOf(map__1213000120__8) { var tmp2 any; var root_728 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = map__1213000120__8; if linked_729 == nil { tmp2 = ifn_730.Invoke_O__O(arg_731) } else { tmp2 = linked_729.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_728, arg_731) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_732 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = map__1213000120__8; if linked_733 == nil { tmp3 = ifn_734.Invoke_O__O(arg_735) } else { tmp3 = linked_733.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_732, arg_735) }; map__1213000120__9 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_736 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = map__1213000120__8; if linked_737 == nil { tmp4 = ifn_738.Invoke_O__O(arg_739) } else { tmp4 = linked_737.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_736, arg_739) }; if jrt.J2g_Truth(tmp4) { var root_740 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = map__1213000120__8; if linked_741 == nil { map__1213000120__9 = ifn_742.Invoke_O__O(arg_743) } else { map__1213000120__9 = linked_741.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_740, arg_743) } } else { map__1213000120__9 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000120__9 = map__1213000120__8 }; var valf__10 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000120__9, A_arbace_core_server_A_const_150, default__1213000122__6); var readf__11 any = lang.RT_Get_O_O_O__O_NoInit(map__1213000120__9, A_arbace_core_server_A_const_159, default__1213000123__7); var valf__12 any; var root_744 any = A_arbace_core_server_A_const_151.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, A_arbace_core_server_resolve_fn_A_fn_class); var ifn_746 lang.IFn; if












	linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = valf__10; if linked_745 == nil { valf__12 = ifn_746.Invoke_O__O(arg_747) } else { valf__12 = linked_745.(*A_arbace_core_server_resolve_fn_A).Invoke_O_O__O(root_744, arg_747) }; var readf__13 any; var root_748 any = /*line :301:1*/A_arbace_core_server_A_const_151.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, A_arbace_core_server_resolve_fn_A_fn_class); var ifn_750 lang.IFn; if













	linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = readf__11; if linked_749 == nil { readf__13 = ifn_750.Invoke_O__O(arg_751) } else { readf__13 = linked_749.(*A_arbace_core_server_resolve_fn_A).Invoke_O_O__O(root_748, arg_751) }; var port__14 any; var tmp5 any; var root_752 any = /*line :301:1*/A_arbace_core_server_A_const_160.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_754 lang.IFn; if














	linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = port__1; if linked_753 == nil { tmp5 = ifn_754.Invoke_O__O(arg_755) } else { tmp5 = linked_753.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_752, arg_755) }; if jrt.J2g_Truth(tmp5) { port__14 = jrt.Integer_ValueOf_String__Integer_NoInit(jrt.String_Cast(port__1)).Ref() } else { port__14 = port__1 }; var socket__15 any = /*line :301:1*/jrt.Socket_New_String_I(jrt.String_Cast(host__0), lang.RT_IntCast_O__I_NoInit(port__14)); var rd__16 any = lang.LineNumberingPushbackReader_New_Reader(jrt.BufferedReader_New_Reader(jrt.InputStreamReader_New_InputStream(jrt.Socket_Cast(socket__15).GetInputStream__InputStream()))); var wr__17 any = jrt.OutputStreamWriter_New_OutputStream(jrt.Socket_Cast(socket__15).GetOutputStream__OutputStream()); var EOF__18_ any = jrt.Object_New(); var G__1213000127__19_ any; var tmp6 *lang.Compiler_AOTFn; var fnbody__794 any = A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(rd__16, readf__13, wr__17, EOF__18_, out_fn__3, valf__12); var tmp7 *jrt.Class; var fncls__793 *jrt.Class = A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class; if



















	fncls__793 == nil { var fncls__793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__794); A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class = fncls__793d; tmp7 = fncls__793d } else { tmp7 = fncls__793 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__794, tmp7, nil); G__1213000127__19_ = /*line :301:1*/jrt.Thread_New_Runnable_String(Up_Compiler_AOTFn_Runnable(tmp6), Lit_32);



















	jrt.Thread_Cast(G__1213000127__19_).SetDaemon_Z__V(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()); jrt.Thread_Cast(G__1213000127__19_).Start__V(); var buf__19 any = /*line :301:1*/lang.Numbers_Char_array_O__C1_NoInit(A_arbace_core_server_A_const_161).Ref(); var tmp8 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L1: for { var n__22 int32 = jrt.Reader_Cast(in_reader__2).Read_C1__I(jrt.CharArray_Cast(buf__19))





































		if lang.Util_Equiv_J_J__Z_NoInit(int64(n__22), -1) { tmp8 = nil } else {
			jrt.OutputStreamWriter_Cast(wr__17).Write_C1_I_I__V(jrt.CharArray_Cast(buf__19), lang.RT_IntCast_J__I_NoInit(0), n__22)
			jrt.OutputStreamWriter_Cast(wr__17).Flush__V()
			continue L1 }
//line :301:1
		break L1 }; return nil }();










































	jrt.PushbackReader_Cast(rd__16).Close__V(); if /*line :301:1*/ tmp9 != nil { panic(tmp9) }; return tmp8 }
//line :301:1
func A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_New() *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Ctor() {}
//line :301:1
func (t *A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A) Invoke_O_O_O__O(self, p1__1213000117_SHARP___1, p2__1213000118_SHARP___2 any) any {











	var root_720 any = A_arbace_core_server_A_const_91.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_read_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = p1__1213000117_SHARP___1; var arg_724 any = jrt.Boolean_FALSE.Ref(); var arg_725 any = p2__1213000118_SHARP___2; if linked_721 == nil { return ifn_722.Invoke_O_O_O__O(arg_723, arg_724, arg_725) } else { return linked_721.(*aot_arbace_core.A_arbace_core_read_A).Invoke_O_O_O_O__O(root_720, arg_723, arg_724, arg_725)
	}
}





func A_arbace_core_server_remote_prepl_fn__1213000128_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_core_server_remote_prepl_fn__1213000128_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Ctor_O_O_O_O_O_O(c__rd, c__readf, c__wr, c__EOF, c__out_fn, c__valf any) { t.F_rd = c__rd; t.F_readf = c__readf; t.F_wr = c__wr; t.F_EOF = c__EOF; t.F_out_fn = c__out_fn; t.F_valf = c__valf }
//line :321:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_A) Invoke_O__O(self any) any { for { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); L2: for { var map__1213000129__3 any = lang.IFn_Cast(t.F_readf).Invoke_O_O__O(t.F_rd, t.F_EOF); var map__1213000129__4 any

	if lang.ISeq_InstanceOf(map__1213000129__3) { var tmp2 any; var root_756 any = A_arbace_core_server_A_const_30.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = map__1213000129__3; if linked_757 == nil { tmp2 = ifn_758.Invoke_O__O(arg_759) } else { tmp2 = linked_757.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_756, arg_759) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_760 any = A_arbace_core_server_A_const_31.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = map__1213000129__3; if linked_761 == nil { tmp3 = ifn_762.Invoke_O__O(arg_763) } else { tmp3 = linked_761.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_760, arg_763) }; map__1213000129__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_764 any = A_arbace_core_server_A_const_11.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = map__1213000129__3; if linked_765 == nil { tmp4 = ifn_766.Invoke_O__O(arg_767) } else { tmp4 = linked_765.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_764, arg_767) }; if jrt.J2g_Truth(tmp4) { var root_768 any = A_arbace_core_server_A_const_32.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = map__1213000129__3; if linked_769 == nil { map__1213000129__4 = ifn_770.Invoke_O__O(arg_771) } else { map__1213000129__4 = linked_769.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_768, arg_771) } } else { map__1213000129__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1213000129__4 = map__1213000129__3 }
//line :321:1
	var m__5 any = map__1213000129__4; var tag__6 any = lang.RT_Get_O_O__O_NoInit(map__1213000129__4, A_arbace_core_server_A_const_104); var val__7 any = lang.RT_Get_O_O__O_NoInit(map__1213000129__4, A_arbace_core_server_A_const_106)


	if lang.Util_Identical_O_O__Z_NoInit(m__5, t.F_EOF) { tmp1 = nil } else {
		var tmp5 lang.IFn = lang.IFn_Cast(t.F_out_fn); var tmp6 any
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_core_server_A_const_162).Invoke_O__O(tag__6)) {
			var tmp7 *lang.Compiler_AOTFn; var fnbody__792 any = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(m__5, t.F_valf, val__7); var tmp8 *jrt.Class; var fncls__791 *jrt.Class = A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class; if fncls__791 == nil { var fncls__791d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__792); A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class = fncls__791d; tmp8 = fncls__791d } else { tmp8 = fncls__791 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__792, tmp8, nil); tmp6 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O() } else {
//line :326:1
				tmp6 = m__5 }
//line :325:1
		tmp5.Invoke_O__O(tmp6)







		continue L2 }
//line :321:1
	break L2 }; return nil }()













	jrt.OutputStreamWriter_Cast(t.F_wr).Close__V()
//line :321:1
	if tmp9 != nil { panic(tmp9) }; return tmp1 }; panic("j2g: unreachable") }





func A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_New_O_O_O(p0, p1, p2 any) *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Ctor_O_O_O(c__m, c__valf, c__val any) { t.F_m = c__m; t.F_valf = c__valf; t.F_val = c__val }
//line :327:1
func (t *A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
													{ var root_772 any = A_arbace_core_server_A_const_71.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = t.F_m; var arg_776 any = A_arbace_core_server_A_const_106; var arg_777 any; var tmp2 any; var t_ any = t.F_valf; t.F_valf = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_val; t.F_val = nil; tmp4 = t__2; arg_777 = tmp3.Invoke_O__O(tmp4); if linked_773 == nil { tmp1 = ifn_774.Invoke_O_O_O__O(arg_775, arg_776, arg_777) } else { tmp1 = linked_773.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_772, arg_775, arg_776, arg_777) } }
//line :327:1
	return nil }(); if tmp5 != nil { if true { var ex__3 jrt.Throwable_I = tmp5; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_core_server_A_const_71.GetRawRoot__O()); var tmp7 any; var t__3 any = t.F_m


		t.F_m = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any = A_arbace_core_server_A_const_106; var tmp10 any; var root_786 any = A_arbace_core_server_A_const_121.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, A_arbace_core_server_ex__GT_data_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = ex__3; var arg_790 any = A_arbace_core_server_A_const_163; if linked_787 == nil { tmp10 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { tmp10 = linked_787.(*A_arbace_core_server_ex__GT_data_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; tmp1 = tmp6.Invoke_O_O_O_O_O__O(tmp8, tmp9, tmp10, A_arbace_core_server_A_const_125, jrt.Boolean_TRUE.Ref()) } }; return tmp1 }




type A_arbace_core_server_A struct{ jrt.Object }

var A_arbace_core_server_A_const_pool *jrt.RefArray

var A_arbace_core_server_A_const_0 *lang.Var

var A_arbace_core_server_A_const_1 any

var A_arbace_core_server_A_const_2 *lang.Var

var A_arbace_core_server_A_const_3 any

var A_arbace_core_server_A_const_4 any

var A_arbace_core_server_A_const_5 any

var A_arbace_core_server_A_const_6 *lang.Var

var A_arbace_core_server_A_const_7 *lang.Var

var A_arbace_core_server_A_const_8 *lang.Var

var A_arbace_core_server_A_const_9 *lang.Var

var A_arbace_core_server_A_const_10 any

var A_arbace_core_server_A_const_11 *lang.Var

var A_arbace_core_server_A_const_12 *lang.Var

var A_arbace_core_server_A_const_13 *lang.Var

var A_arbace_core_server_A_const_14 any

var A_arbace_core_server_A_const_15 *lang.Var

var A_arbace_core_server_A_const_16 *lang.Var

var A_arbace_core_server_A_const_17 any

var A_arbace_core_server_A_const_18 *lang.Var

var A_arbace_core_server_A_const_19 any

var A_arbace_core_server_A_const_20 any

var A_arbace_core_server_A_const_21 any

var A_arbace_core_server_A_const_22 any

var A_arbace_core_server_A_const_23 any

var A_arbace_core_server_A_const_24 any

var A_arbace_core_server_A_const_25 any

var A_arbace_core_server_A_const_26 any

var A_arbace_core_server_A_const_27 any

var A_arbace_core_server_A_const_28 any

var A_arbace_core_server_A_const_29 *lang.Var

var A_arbace_core_server_A_const_30 *lang.Var

var A_arbace_core_server_A_const_31 *lang.Var

var A_arbace_core_server_A_const_32 *lang.Var

var A_arbace_core_server_A_const_33 *lang.Keyword

var A_arbace_core_server_A_const_34 *lang.Keyword

var A_arbace_core_server_A_const_35 *lang.Keyword

var A_arbace_core_server_A_const_36 *lang.Var

var A_arbace_core_server_A_const_37 *lang.Var

var A_arbace_core_server_A_const_38 *lang.Var

var A_arbace_core_server_A_const_39 any

var A_arbace_core_server_A_const_40 any

var A_arbace_core_server_A_const_41 any

var A_arbace_core_server_A_const_42 *lang.Var

var A_arbace_core_server_A_const_43 *lang.Var

var A_arbace_core_server_A_const_44 *lang.Var

var A_arbace_core_server_A_const_45 *lang.Var

var A_arbace_core_server_A_const_46 *lang.Var

var A_arbace_core_server_A_const_47 *lang.Var

var A_arbace_core_server_A_const_48 *lang.Var

var A_arbace_core_server_A_const_49 *lang.Var

var A_arbace_core_server_A_const_50 *lang.Var

var A_arbace_core_server_A_const_51 *lang.Var

var A_arbace_core_server_A_const_52 *lang.Var

var A_arbace_core_server_A_const_53 *lang.Var

var A_arbace_core_server_A_const_54 *lang.Keyword

var A_arbace_core_server_A_const_55 *lang.Keyword

var A_arbace_core_server_A_const_56 *lang.Var

var A_arbace_core_server_A_const_57 *lang.Var

var A_arbace_core_server_A_const_58 *lang.Var

var A_arbace_core_server_A_const_59 *lang.Var

var A_arbace_core_server_A_const_60 *lang.Keyword

var A_arbace_core_server_A_const_61 *lang.Var

var A_arbace_core_server_A_const_62 *lang.Var

var A_arbace_core_server_A_const_63 *lang.Var

var A_arbace_core_server_A_const_64 *lang.Var

var A_arbace_core_server_A_const_65 *lang.Keyword

var A_arbace_core_server_A_const_66 *lang.Keyword

var A_arbace_core_server_A_const_67 *lang.Keyword

var A_arbace_core_server_A_const_68 *lang.Keyword

var A_arbace_core_server_A_const_69 *lang.Keyword

var A_arbace_core_server_A_const_70 *lang.Var

var A_arbace_core_server_A_const_71 *lang.Var

var A_arbace_core_server_A_const_72 *lang.Keyword

var A_arbace_core_server_A_const_73 *lang.Var

var A_arbace_core_server_A_const_74 *lang.Var

var A_arbace_core_server_A_const_75 *lang.Var

var A_arbace_core_server_A_const_76 *lang.Var

var A_arbace_core_server_A_const_77 *lang.Var

var A_arbace_core_server_A_const_78 *lang.Var

var A_arbace_core_server_A_const_79 *lang.Var

var A_arbace_core_server_A_const_80 *lang.Var

var A_arbace_core_server_A_const_81 any

var A_arbace_core_server_A_const_82 *lang.Var

var A_arbace_core_server_A_const_83 *lang.Var

var A_arbace_core_server_A_const_84 *lang.Var

var A_arbace_core_server_A_const_85 *lang.Var

var A_arbace_core_server_A_const_86 *lang.Var

var A_arbace_core_server_A_const_87 *lang.Var

var A_arbace_core_server_A_const_88 any

var A_arbace_core_server_A_const_89 *lang.Keyword

var A_arbace_core_server_A_const_90 *lang.Keyword

var A_arbace_core_server_A_const_91 *lang.Var

var A_arbace_core_server_A_const_92 any

var A_arbace_core_server_A_const_93 *lang.Keyword

var A_arbace_core_server_A_const_94 *lang.Var

var A_arbace_core_server_A_const_95 *lang.Var

var A_arbace_core_server_A_const_96 *lang.Var

var A_arbace_core_server_A_const_97 *lang.Keyword

var A_arbace_core_server_A_const_98 *lang.Var

var A_arbace_core_server_A_const_99 *lang.Keyword

var A_arbace_core_server_A_const_100 *lang.Var

var A_arbace_core_server_A_const_101 *lang.Var

var A_arbace_core_server_A_const_102 *lang.Keyword

var A_arbace_core_server_A_const_103 *lang.Keyword

var A_arbace_core_server_A_const_104 *lang.Keyword

var A_arbace_core_server_A_const_105 *lang.Keyword

var A_arbace_core_server_A_const_106 *lang.Keyword

var A_arbace_core_server_A_const_107 *lang.Var

var A_arbace_core_server_A_const_108 *lang.Keyword

var A_arbace_core_server_A_const_109 *lang.Keyword

var A_arbace_core_server_A_const_110 *lang.Keyword

var A_arbace_core_server_A_const_111 *lang.Var

var A_arbace_core_server_A_const_112 *lang.Var

var A_arbace_core_server_A_const_113 *lang.Var

var A_arbace_core_server_A_const_114 *lang.Var

var A_arbace_core_server_A_const_115 *lang.Keyword

var A_arbace_core_server_A_const_116 *lang.Keyword

var A_arbace_core_server_A_const_117 *lang.Var

var A_arbace_core_server_A_const_118 *lang.Keyword

var A_arbace_core_server_A_const_119 *lang.Keyword

var A_arbace_core_server_A_const_120 *lang.Var

var A_arbace_core_server_A_const_121 *lang.Var

var A_arbace_core_server_A_const_122 *lang.Keyword

var A_arbace_core_server_A_const_123 *lang.Var

var A_arbace_core_server_A_const_124 *lang.Keyword

var A_arbace_core_server_A_const_125 *lang.Keyword

var A_arbace_core_server_A_const_126 *lang.Keyword

var A_arbace_core_server_A_const_127 *lang.Var

var A_arbace_core_server_A_const_128 *jrt.Class

var A_arbace_core_server_A_const_129 *lang.Var

var A_arbace_core_server_A_const_130 *lang.Var

var A_arbace_core_server_A_const_131 *lang.Var

var A_arbace_core_server_A_const_132 *lang.Var

var A_arbace_core_server_A_const_133 *lang.Var

var A_arbace_core_server_A_const_134 *lang.Var

var A_arbace_core_server_A_const_135 *lang.Var

var A_arbace_core_server_A_const_136 *lang.Var

var A_arbace_core_server_A_const_137 *lang.Var

var A_arbace_core_server_A_const_138 *lang.Var

var A_arbace_core_server_A_const_139 *lang.Var

var A_arbace_core_server_A_const_140 *lang.Var

var A_arbace_core_server_A_const_141 *lang.Var

var A_arbace_core_server_A_const_142 any

var A_arbace_core_server_A_const_143 *lang.Var

var A_arbace_core_server_A_const_144 *lang.Var

var A_arbace_core_server_A_const_145 *lang.Keyword

var A_arbace_core_server_A_const_146 *lang.Keyword

var A_arbace_core_server_A_const_147 *lang.Var

var A_arbace_core_server_A_const_148 *lang.Var

var A_arbace_core_server_A_const_149 *lang.Var

var A_arbace_core_server_A_const_150 *lang.Keyword

var A_arbace_core_server_A_const_151 *lang.Var

var A_arbace_core_server_A_const_152 *lang.Var

var A_arbace_core_server_A_const_153 *lang.Var

var A_arbace_core_server_A_const_154 any

var A_arbace_core_server_A_const_155 *lang.Keyword

var A_arbace_core_server_A_const_156 *lang.Var

var A_arbace_core_server_A_const_157 *lang.Var

var A_arbace_core_server_A_const_158 *lang.Var

var A_arbace_core_server_A_const_159 *lang.Keyword

var A_arbace_core_server_A_const_160 *lang.Var

var A_arbace_core_server_A_const_161 any

var A_arbace_core_server_A_const_162 any

var A_arbace_core_server_A_const_163 *lang.Keyword

var A_arbace_core_server_A_init jrt.ClassInit

func A_arbace_core_server_A_Init() { if !A_arbace_core_server_A_init.Done() { A_arbace_core_server_A_init.Run(A_arbace_core_server_A_clinit) } }

func A_arbace_core_server_A_clinit() { A_arbace_core_server_A_clinit_p0(); A_arbace_core_server_A_clinit_p1(); A_arbace_core_server_A_clinit_p2(); A_arbace_core_server_A_clinit_p3(); A_arbace_core_server_A_clinit_p4(); A_arbace_core_server_A_clinit_p5(); A_arbace_core_server_A_clinit_p6(); A_arbace_core_server_A_clinit_p7(); A_arbace_core_server_A_clinit_p8(); A_arbace_core_server_A_clinit_p9(); A_arbace_core_server_A_clinit_p10(); A_arbace_core_server_A_clinit_p11(); A_arbace_core_server_A_clinit_p12(); A_arbace_core_server_A_clinit_p13() }

func A_arbace_core_server_A_clinit_p0() { jrt.StartCheck(); A_arbace_core_server_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 226); A_arbace_core_server_A_const_0 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[62]); A_arbace_core_server_A_const_1 = A_arbace_core_server_A_const_pool.A[63]; A_arbace_core_server_A_const_2 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[64]); A_arbace_core_server_A_const_3 = A_arbace_core_server_A_const_pool.A[65]; A_arbace_core_server_A_const_4 = A_arbace_core_server_A_const_pool.A[66]; A_arbace_core_server_A_const_5 = A_arbace_core_server_A_const_pool.A[67]; A_arbace_core_server_A_const_6 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[68]); A_arbace_core_server_A_const_7 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[69]); A_arbace_core_server_A_const_8 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[70]); A_arbace_core_server_A_const_9 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[71]); A_arbace_core_server_A_const_10 = A_arbace_core_server_A_const_pool.A[72]; A_arbace_core_server_A_const_11 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[73]) }

func A_arbace_core_server_A_clinit_p1() { A_arbace_core_server_A_const_12 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[74]); A_arbace_core_server_A_const_13 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[75]); A_arbace_core_server_A_const_14 = A_arbace_core_server_A_const_pool.A[76]; A_arbace_core_server_A_const_15 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[77]); A_arbace_core_server_A_const_16 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[78]); A_arbace_core_server_A_const_17 = A_arbace_core_server_A_const_pool.A[79]; A_arbace_core_server_A_const_18 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[80]); A_arbace_core_server_A_const_19 = A_arbace_core_server_A_const_pool.A[81]; A_arbace_core_server_A_const_20 = A_arbace_core_server_A_const_pool.A[82]; A_arbace_core_server_A_const_21 = A_arbace_core_server_A_const_pool.A[83]; A_arbace_core_server_A_const_22 = A_arbace_core_server_A_const_pool.A[84]; A_arbace_core_server_A_const_23 = A_arbace_core_server_A_const_pool.A[85]; A_arbace_core_server_A_const_24 = A_arbace_core_server_A_const_pool.A[86]; A_arbace_core_server_A_const_25 = A_arbace_core_server_A_const_pool.A[87] }

func A_arbace_core_server_A_clinit_p2() { A_arbace_core_server_A_const_26 = A_arbace_core_server_A_const_pool.A[88]; A_arbace_core_server_A_const_27 = A_arbace_core_server_A_const_pool.A[89]; A_arbace_core_server_A_const_28 = A_arbace_core_server_A_const_pool.A[90]; A_arbace_core_server_A_const_29 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[91]); A_arbace_core_server_A_const_30 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[92]); A_arbace_core_server_A_const_31 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[93]); A_arbace_core_server_A_const_32 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[94]); A_arbace_core_server_A_const_33 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[95]); A_arbace_core_server_A_const_34 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[96]); A_arbace_core_server_A_const_35 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[97]); A_arbace_core_server_A_const_36 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[98]); A_arbace_core_server_A_const_37 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[99]) }

func A_arbace_core_server_A_clinit_p3() { A_arbace_core_server_A_const_38 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[100]); A_arbace_core_server_A_const_39 = A_arbace_core_server_A_const_pool.A[101]; A_arbace_core_server_A_const_40 = A_arbace_core_server_A_const_pool.A[102]; A_arbace_core_server_A_const_41 = A_arbace_core_server_A_const_pool.A[103]; A_arbace_core_server_A_const_42 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[104]); A_arbace_core_server_A_const_43 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[105]); A_arbace_core_server_A_const_44 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[106]); A_arbace_core_server_A_const_45 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[107]); A_arbace_core_server_A_const_46 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[108]); A_arbace_core_server_A_const_47 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[109]); A_arbace_core_server_A_const_48 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[110]); A_arbace_core_server_A_const_49 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[111]) }

func A_arbace_core_server_A_clinit_p4() { A_arbace_core_server_A_const_50 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[112]); A_arbace_core_server_A_const_51 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[113]); A_arbace_core_server_A_const_52 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[114]); A_arbace_core_server_A_const_53 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[115]); A_arbace_core_server_A_const_54 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[116]); A_arbace_core_server_A_const_55 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[117]); A_arbace_core_server_A_const_56 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[118]); A_arbace_core_server_A_const_57 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[119]); A_arbace_core_server_A_const_58 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[120]); A_arbace_core_server_A_const_59 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[121]); A_arbace_core_server_A_const_60 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[122]); A_arbace_core_server_A_const_61 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[123]) }

func A_arbace_core_server_A_clinit_p5() { A_arbace_core_server_A_const_62 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[124]); A_arbace_core_server_A_const_63 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[125]); A_arbace_core_server_A_const_64 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[126]); A_arbace_core_server_A_const_65 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[127]); A_arbace_core_server_A_const_66 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[128]); A_arbace_core_server_A_const_67 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[129]); A_arbace_core_server_A_const_68 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[130]); A_arbace_core_server_A_const_69 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[131]); A_arbace_core_server_A_const_70 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[132]); A_arbace_core_server_A_const_71 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[133]); A_arbace_core_server_A_const_72 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[134]); A_arbace_core_server_A_const_73 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[135]) }

func A_arbace_core_server_A_clinit_p6() { A_arbace_core_server_A_const_74 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[136]); A_arbace_core_server_A_const_75 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[137]); A_arbace_core_server_A_const_76 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[138]); A_arbace_core_server_A_const_77 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[139]); A_arbace_core_server_A_const_78 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[140]); A_arbace_core_server_A_const_79 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[141]); A_arbace_core_server_A_const_80 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[142]); A_arbace_core_server_A_const_81 = A_arbace_core_server_A_const_pool.A[143]; A_arbace_core_server_A_const_82 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[144]); A_arbace_core_server_A_const_83 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[145]); A_arbace_core_server_A_const_84 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[146]); A_arbace_core_server_A_const_85 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[147]) }

func A_arbace_core_server_A_clinit_p7() { A_arbace_core_server_A_const_86 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[148]); A_arbace_core_server_A_const_87 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[149]); A_arbace_core_server_A_const_88 = A_arbace_core_server_A_const_pool.A[150]; A_arbace_core_server_A_const_89 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[151]); A_arbace_core_server_A_const_90 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[152]); A_arbace_core_server_A_const_91 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[153]); A_arbace_core_server_A_const_92 = A_arbace_core_server_A_const_pool.A[154]; A_arbace_core_server_A_const_93 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[155]); A_arbace_core_server_A_const_94 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[156]); A_arbace_core_server_A_const_95 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[157]); A_arbace_core_server_A_const_96 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[158]); A_arbace_core_server_A_const_97 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[159]) }

func A_arbace_core_server_A_clinit_p8() { A_arbace_core_server_A_const_98 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[160]); A_arbace_core_server_A_const_99 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[161]); A_arbace_core_server_A_const_100 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[162]); A_arbace_core_server_A_const_101 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[163]); A_arbace_core_server_A_const_102 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[164]); A_arbace_core_server_A_const_103 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[165]); A_arbace_core_server_A_const_104 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[166]); A_arbace_core_server_A_const_105 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[167]); A_arbace_core_server_A_const_106 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[168]); A_arbace_core_server_A_const_107 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[169]); A_arbace_core_server_A_const_108 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[170]); A_arbace_core_server_A_const_109 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[171]) }

func A_arbace_core_server_A_clinit_p9() { A_arbace_core_server_A_const_110 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[172]); A_arbace_core_server_A_const_111 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[173]); A_arbace_core_server_A_const_112 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[174]); A_arbace_core_server_A_const_113 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[175]); A_arbace_core_server_A_const_114 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[176]); A_arbace_core_server_A_const_115 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[177]); A_arbace_core_server_A_const_116 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[178]); A_arbace_core_server_A_const_117 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[179]); A_arbace_core_server_A_const_118 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[180]); A_arbace_core_server_A_const_119 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[181]); A_arbace_core_server_A_const_120 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[182]); A_arbace_core_server_A_const_121 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[183]) }

func A_arbace_core_server_A_clinit_p10() { A_arbace_core_server_A_const_122 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[184]); A_arbace_core_server_A_const_123 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[185]); A_arbace_core_server_A_const_124 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[186]); A_arbace_core_server_A_const_125 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[187]); A_arbace_core_server_A_const_126 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[188]); A_arbace_core_server_A_const_127 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[189]); A_arbace_core_server_A_const_128 = jrt.Class_Cast(A_arbace_core_server_A_const_pool.A[190]); A_arbace_core_server_A_const_129 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[191]); A_arbace_core_server_A_const_130 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[192]); A_arbace_core_server_A_const_131 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[193]); A_arbace_core_server_A_const_132 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[194]); A_arbace_core_server_A_const_133 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[195]) }

func A_arbace_core_server_A_clinit_p11() { A_arbace_core_server_A_const_134 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[196]); A_arbace_core_server_A_const_135 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[197]); A_arbace_core_server_A_const_136 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[198]); A_arbace_core_server_A_const_137 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[199]); A_arbace_core_server_A_const_138 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[200]); A_arbace_core_server_A_const_139 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[201]); A_arbace_core_server_A_const_140 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[202]); A_arbace_core_server_A_const_141 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[203]); A_arbace_core_server_A_const_142 = A_arbace_core_server_A_const_pool.A[204]; A_arbace_core_server_A_const_143 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[205]); A_arbace_core_server_A_const_144 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[206]); A_arbace_core_server_A_const_145 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[207]) }

func A_arbace_core_server_A_clinit_p12() { A_arbace_core_server_A_const_146 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[208]); A_arbace_core_server_A_const_147 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[209]); A_arbace_core_server_A_const_148 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[210]); A_arbace_core_server_A_const_149 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[211]); A_arbace_core_server_A_const_150 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[212]); A_arbace_core_server_A_const_151 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[213]); A_arbace_core_server_A_const_152 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[214]); A_arbace_core_server_A_const_153 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[215]); A_arbace_core_server_A_const_154 = A_arbace_core_server_A_const_pool.A[216]; A_arbace_core_server_A_const_155 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[217]); A_arbace_core_server_A_const_156 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[218]); A_arbace_core_server_A_const_157 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[219]) }

func A_arbace_core_server_A_clinit_p13() { A_arbace_core_server_A_const_158 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[220]); A_arbace_core_server_A_const_159 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[221]); A_arbace_core_server_A_const_160 = lang.Var_Cast(A_arbace_core_server_A_const_pool.A[222]); A_arbace_core_server_A_const_161 = A_arbace_core_server_A_const_pool.A[223]; A_arbace_core_server_A_const_162 = A_arbace_core_server_A_const_pool.A[224]; A_arbace_core_server_A_const_163 = lang.Keyword_Cast(A_arbace_core_server_A_const_pool.A[225]) }

func A_arbace_core_server_A_New() *A_arbace_core_server_A { A_arbace_core_server_A_Init(); t := &A_arbace_core_server_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_A) Ctor() {}

func (t *A_arbace_core_server_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_A_class }

func (t *A_arbace_core_server_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_A); return ok }

func A_arbace_core_server_A_Cast(x any) *A_arbace_core_server_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_A_class)) }; return v }



type A_arbace_core_server_accept_connection_A struct{ j2g_header uint64 }

var A_arbace_core_server_accept_connection_A_fn_class *jrt.Class



type A_arbace_core_server_accept_connection_fn__1213000038_A struct{ j2g_header uint64; F_name, F_client_id, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_accept_connection_fn__1213000038_A_fn_class *jrt.Class



type A_arbace_core_server_accept_connection_fn__1213000040_A struct{ j2g_header uint64; F_name, F_client_id, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_accept_connection_fn__1213000040_A_fn_class *jrt.Class



type A_arbace_core_server_eval1213000004_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000004_A_New() *A_arbace_core_server_eval1213000004_A { t := &A_arbace_core_server_eval1213000004_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000004_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000004_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000004_A_class }

func (t *A_arbace_core_server_eval1213000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000004_A); return ok }

func A_arbace_core_server_eval1213000004_A_Cast(x any) *A_arbace_core_server_eval1213000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000004_A_class)) }; return v }



type A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A struct{ j2g_header uint64 }

var A_arbace_core_server_eval1213000004_loading__1927001464__auto____1213000005_A_fn_class *jrt.Class



type A_arbace_core_server_eval1213000008_A struct{ jrt.Object }

func A_arbace_core_server_eval1213000008_A_New() *A_arbace_core_server_eval1213000008_A { t := &A_arbace_core_server_eval1213000008_A{}; t.Ctor(); return t }

func (t *A_arbace_core_server_eval1213000008_A) Ctor() {}

func (t *A_arbace_core_server_eval1213000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_server_eval1213000008_A) GetClass__Class() *jrt.Class { return A_arbace_core_server_eval1213000008_A_class }

func (t *A_arbace_core_server_eval1213000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_server_eval1213000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_core_server_eval1213000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_server_eval1213000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_server_eval1213000008_A); return ok }

func A_arbace_core_server_eval1213000008_A_Cast(x any) *A_arbace_core_server_eval1213000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_server_eval1213000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_server_eval1213000008_A_class)) }; return v }



type A_arbace_core_server_eval1213000008_fn__1213000009_A struct{ j2g_header uint64 }

var A_arbace_core_server_eval1213000008_fn__1213000009_A_fn_class *jrt.Class



type A_arbace_core_server_ex__GT_data_A struct{ j2g_header uint64 }

var A_arbace_core_server_ex__GT_data_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_io_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_fn__1213000112_A struct{ j2g_header uint64; F_lock, F_out, F_valf any }

var A_arbace_core_server_io_prepl_fn__1213000112_A_fn_class *jrt.Class



type A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A struct{ j2g_header uint64; F_m, F_valf any }

var A_arbace_core_server_io_prepl_fn__1213000112_fn__1213000113_A_fn_class *jrt.Class



type A_arbace_core_server_parse_props_A struct{ j2g_header uint64 }

var A_arbace_core_server_parse_props_A_fn_class *jrt.Class



type A_arbace_core_server_parse_props_fn__1213000072_A struct{ j2g_header uint64; F_props any }

var A_arbace_core_server_parse_props_fn__1213000072_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000096_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_fn__1213000096_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000098_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_fn__1213000098_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_fn__1213000100_A struct{ j2g_header uint64; F_EOF, F_out_fn, F_in_reader any }

var A_arbace_core_server_prepl_fn__1213000100_A_fn_class *jrt.Class



type A_arbace_core_server_prepl_tapfn__1213000094_A struct{ j2g_header uint64; F_out_fn any }

var A_arbace_core_server_prepl_tapfn__1213000094_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_A struct{ j2g_header uint64 }

var A_arbace_core_server_remote_prepl_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A struct{ j2g_header uint64 }

var A_arbace_core_server_remote_prepl_default__1213000123__1213000125_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_fn__1213000128_A struct{ j2g_header uint64; F_rd, F_readf, F_wr, F_EOF, F_out_fn, F_valf any }

var A_arbace_core_server_remote_prepl_fn__1213000128_A_fn_class *jrt.Class



type A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A struct{ j2g_header uint64; F_m, F_valf, F_val any }

var A_arbace_core_server_remote_prepl_fn__1213000128_fn__1213000131_A_fn_class *jrt.Class



type A_arbace_core_server_repl_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_A_fn_class *jrt.Class



type A_arbace_core_server_repl_init_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_init_A_fn_class *jrt.Class



type A_arbace_core_server_repl_read_A struct{ j2g_header uint64 }

var A_arbace_core_server_repl_read_A_fn_class *jrt.Class



type A_arbace_core_server_required_A struct{ j2g_header uint64 }

var A_arbace_core_server_required_A_fn_class *jrt.Class



type A_arbace_core_server_resolve_fn_A struct{ j2g_header uint64 }

var A_arbace_core_server_resolve_fn_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_A struct{ j2g_header uint64 }

var A_arbace_core_server_start_server_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000049_A struct{ j2g_header uint64; F_name, F_socket, F_lockee__1213000018__auto__ any }

var A_arbace_core_server_start_server_fn__1213000049_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_A struct{ j2g_header uint64; F_name, F_socket, F_client_daemon, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A struct{ j2g_header uint64; F_name, F_socket any; F_client_counter int64; F_client_daemon, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A struct{ j2g_header uint64; F_in, F_name, F_client_id, F_conn, F_out, F_args, F_bind_err, F_accept any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000053_fn__1213000055_A_fn_class *jrt.Class



type A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A struct{ j2g_header uint64; F_lockee__1213000018__auto__, F_name any }

var A_arbace_core_server_start_server_fn__1213000052_fn__1213000058_A_fn_class *jrt.Class



type A_arbace_core_server_start_servers_A struct{ j2g_header uint64 }

var A_arbace_core_server_start_servers_A_fn_class *jrt.Class



type A_arbace_core_server_stop_server_A struct{ j2g_header uint64 }

var A_arbace_core_server_stop_server_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_A struct{ j2g_header uint64 }

var A_arbace_core_server_stop_servers_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_fn__1213000067_A struct{ j2g_header uint64; F_name any }

var A_arbace_core_server_stop_servers_fn__1213000067_A_fn_class *jrt.Class



type A_arbace_core_server_stop_servers_fn__1213000069_A struct{ j2g_header uint64; F_name any }

var A_arbace_core_server_stop_servers_fn__1213000069_A_fn_class *jrt.Class



type A_arbace_core_server_thread_A struct{ j2g_header uint64 }

var A_arbace_core_server_thread_A_fn_class *jrt.Class



type A_arbace_core_server_validate_opts_A struct{ j2g_header uint64 }

var A_arbace_core_server_validate_opts_A_fn_class *jrt.Class



type A_arbace_core_server_with_lock_A struct{ j2g_header uint64 }

var A_arbace_core_server_with_lock_A_fn_class *jrt.Class
