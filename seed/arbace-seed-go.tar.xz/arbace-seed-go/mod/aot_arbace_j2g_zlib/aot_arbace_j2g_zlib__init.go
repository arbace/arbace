//line aot_arbace_j2g_zlib__init.ae:1
package aot_arbace_j2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_zlib__init_A_Unit0__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_zlib__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib__init_A_const_1) }
//line :1:1
func A_arbace_j2g_zlib__init_A_Unit1__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_zlib__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_zlib__init_A_Unit2__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_zlib__init_A_Unit3__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_zlib__init_A_const_1)).Equals_O__Z(A_arbace_j2g_zlib__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_zlib__init_A_Load__O() any { A_arbace_j2g_zlib__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_zlib__init_A_Unit0__O(); A_arbace_j2g_zlib__init_A_Unit1__O(); A_arbace_j2g_zlib__init_A_Unit2__O(); A_arbace_j2g_zlib__init_A_Unit3__O(); A_arbace_j2g_zlib__init_A_Unit4__O(); A_arbace_j2g_zlib__init_A_Unit5__O(); A_arbace_j2g_zlib__init_A_Unit6__O(); A_arbace_j2g_zlib__init_A_Unit7__O(); A_arbace_j2g_zlib__init_A_Unit8__O(); A_arbace_j2g_zlib__init_A_Unit9__O(); A_arbace_j2g_zlib__init_A_Unit10__O(); A_arbace_j2g_zlib__init_A_Unit11__O(); A_arbace_j2g_zlib__init_A_Unit12__O(); A_arbace_j2g_zlib__init_A_Unit13__O(); A_arbace_j2g_zlib__init_A_Unit14__O(); A_arbace_j2g_zlib__init_A_Unit15__O(); A_arbace_j2g_zlib__init_A_Unit16__O(); A_arbace_j2g_zlib__init_A_Unit17__O(); A_arbace_j2g_zlib__init_A_Unit18__O(); A_arbace_j2g_zlib__init_A_Unit19__O(); A_arbace_j2g_zlib__init_A_Unit20__O(); A_arbace_j2g_zlib__init_A_Unit21__O(); A_arbace_j2g_zlib__init_A_Unit22__O(); A_arbace_j2g_zlib__init_A_Unit23__O(); A_arbace_j2g_zlib__init_A_Unit24__O(); A_arbace_j2g_zlib__init_A_Unit25__O(); return nil }













func A_arbace_j2g_zlib__init_A_Unit4__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_6)); var tmp2 *lang.Var = A_arbace_j2g_zlib__init_A_const_5; var tmp3 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_New(); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); return A_arbace_j2g_zlib__init_A_const_4 }



















func A_arbace_j2g_zlib__init_A_Unit5__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_zlib_reverse_bits_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_zlib_reverse_bits_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_j2g_zlib_reverse_bits_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_8)); return A_arbace_j2g_zlib__init_A_const_7 }






func A_arbace_j2g_zlib__init_A_Unit6__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_zlib_huffman_lengths_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_j2g_zlib_huffman_lengths_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_10)); return A_arbace_j2g_zlib__init_A_const_9 }




































func A_arbace_j2g_zlib__init_A_Unit7__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_zlib_canonical_codes_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_zlib_canonical_codes_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_j2g_zlib_canonical_codes_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_12)); return A_arbace_j2g_zlib__init_A_const_11 }























func A_arbace_j2g_zlib__init_A_Unit8__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_13; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib__init_A_const_14).Ref()); var tmp2 *lang.Var = A_arbace_j2g_zlib__init_A_const_13; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_15)); return A_arbace_j2g_zlib__init_A_const_13 }
func A_arbace_j2g_zlib__init_A_Unit9__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_16; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib__init_A_const_17).Ref()); var tmp2 *lang.Var = A_arbace_j2g_zlib__init_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_18)); return A_arbace_j2g_zlib__init_A_const_16 }
func A_arbace_j2g_zlib__init_A_Unit10__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_19; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib__init_A_const_20).Ref()); var tmp2 *lang.Var = A_arbace_j2g_zlib__init_A_const_19; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_21)); return A_arbace_j2g_zlib__init_A_const_19 }

func A_arbace_j2g_zlib__init_A_Unit11__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_22; tmp1.BindRoot_O__V(lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib__init_A_const_23).Ref()); var tmp2 *lang.Var = A_arbace_j2g_zlib__init_A_const_22; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_24)); return A_arbace_j2g_zlib__init_A_const_22 }

func A_arbace_j2g_zlib__init_A_Unit12__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_zlib_code_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_zlib_code_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_j2g_zlib_code_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_26)); return A_arbace_j2g_zlib__init_A_const_25 }









func A_arbace_j2g_zlib__init_A_Unit13__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); A_arbace_j2g_zlib__init_A_const_27.BindRoot_O__V(A_arbace_j2g_zlib__init_A_const_28); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_29)); return A_arbace_j2g_zlib__init_A_const_27 }
func A_arbace_j2g_zlib__init_A_Unit14__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); A_arbace_j2g_zlib__init_A_const_30.BindRoot_O__V(A_arbace_j2g_zlib__init_A_const_31); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_32)); return A_arbace_j2g_zlib__init_A_const_30 }
func A_arbace_j2g_zlib__init_A_Unit15__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); A_arbace_j2g_zlib__init_A_const_33.BindRoot_O__V(A_arbace_j2g_zlib__init_A_const_31); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_34)); return A_arbace_j2g_zlib__init_A_const_33 }

func A_arbace_j2g_zlib__init_A_Unit16__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_zlib_match_length_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_zlib_match_length_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_j2g_zlib_match_length_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_36)); return A_arbace_j2g_zlib__init_A_const_35 }




func A_arbace_j2g_zlib__init_A_Unit17__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_zlib_insert_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_zlib_insert_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_j2g_zlib_insert_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_38)); return A_arbace_j2g_zlib__init_A_const_37 }













func A_arbace_j2g_zlib__init_A_Unit18__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_zlib_longest_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_zlib_longest_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); A_arbace_j2g_zlib_longest_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_40)); return A_arbace_j2g_zlib__init_A_const_39 }

















func A_arbace_j2g_zlib__init_A_Unit19__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_zlib_lz77_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_zlib_lz77_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_j2g_zlib_lz77_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_42)); return A_arbace_j2g_zlib__init_A_const_41 }




































func A_arbace_j2g_zlib__init_A_Unit20__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(201, 1); A_arbace_j2g_zlib__init_A_const_43.BindRoot_O__V(A_arbace_j2g_zlib__init_A_const_44); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_45)); return A_arbace_j2g_zlib__init_A_const_43 }
func A_arbace_j2g_zlib__init_A_Unit21__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); A_arbace_j2g_zlib__init_A_const_46.BindRoot_O__V(A_arbace_j2g_zlib__init_A_const_47); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_48)); return A_arbace_j2g_zlib__init_A_const_46 }

func A_arbace_j2g_zlib__init_A_Unit22__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_zlib_rle_lengths_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_zlib_rle_lengths_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_j2g_zlib_rle_lengths_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_50)); return A_arbace_j2g_zlib__init_A_const_49 }














func A_arbace_j2g_zlib__init_A_Unit23__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_zlib_write_block_BANG__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_j2g_zlib_write_block_BANG__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_52)); return A_arbace_j2g_zlib__init_A_const_51 }




















































func A_arbace_j2g_zlib__init_A_Unit24__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(272, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_zlib_adler32_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_zlib_adler32_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_j2g_zlib_adler32_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_54)); return A_arbace_j2g_zlib__init_A_const_53 }






func A_arbace_j2g_zlib__init_A_Unit25__O() any { A_arbace_j2g_zlib__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.Var = A_arbace_j2g_zlib__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_zlib_deflate_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_zlib_deflate_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_j2g_zlib_deflate_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_zlib__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_zlib__init_A_const_56)); return A_arbace_j2g_zlib__init_A_const_55 }



type A_arbace_j2g_zlib__init_A struct{ jrt.Object }

var A_arbace_j2g_zlib__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_zlib__init_A_const_0 *lang.Var

var A_arbace_j2g_zlib__init_A_const_1 any

var A_arbace_j2g_zlib__init_A_const_2 any

var A_arbace_j2g_zlib__init_A_const_3 any

var A_arbace_j2g_zlib__init_A_const_4 *jrt.Class

var A_arbace_j2g_zlib__init_A_const_5 *lang.Var

var A_arbace_j2g_zlib__init_A_const_6 any

var A_arbace_j2g_zlib__init_A_const_7 *lang.Var

var A_arbace_j2g_zlib__init_A_const_8 any

var A_arbace_j2g_zlib__init_A_const_9 *lang.Var

var A_arbace_j2g_zlib__init_A_const_10 any

var A_arbace_j2g_zlib__init_A_const_11 *lang.Var

var A_arbace_j2g_zlib__init_A_const_12 any

var A_arbace_j2g_zlib__init_A_const_13 *lang.Var

var A_arbace_j2g_zlib__init_A_const_14 any

var A_arbace_j2g_zlib__init_A_const_15 any

var A_arbace_j2g_zlib__init_A_const_16 *lang.Var

var A_arbace_j2g_zlib__init_A_const_17 any

var A_arbace_j2g_zlib__init_A_const_18 any

var A_arbace_j2g_zlib__init_A_const_19 *lang.Var

var A_arbace_j2g_zlib__init_A_const_20 any

var A_arbace_j2g_zlib__init_A_const_21 any

var A_arbace_j2g_zlib__init_A_const_22 *lang.Var

var A_arbace_j2g_zlib__init_A_const_23 any

var A_arbace_j2g_zlib__init_A_const_24 any

var A_arbace_j2g_zlib__init_A_const_25 *lang.Var

var A_arbace_j2g_zlib__init_A_const_26 any

var A_arbace_j2g_zlib__init_A_const_27 *lang.Var

var A_arbace_j2g_zlib__init_A_const_28 any

var A_arbace_j2g_zlib__init_A_const_29 any

var A_arbace_j2g_zlib__init_A_const_30 *lang.Var

var A_arbace_j2g_zlib__init_A_const_31 any

var A_arbace_j2g_zlib__init_A_const_32 any

var A_arbace_j2g_zlib__init_A_const_33 *lang.Var

var A_arbace_j2g_zlib__init_A_const_34 any

var A_arbace_j2g_zlib__init_A_const_35 *lang.Var

var A_arbace_j2g_zlib__init_A_const_36 any

var A_arbace_j2g_zlib__init_A_const_37 *lang.Var

var A_arbace_j2g_zlib__init_A_const_38 any

var A_arbace_j2g_zlib__init_A_const_39 *lang.Var

var A_arbace_j2g_zlib__init_A_const_40 any

var A_arbace_j2g_zlib__init_A_const_41 *lang.Var

var A_arbace_j2g_zlib__init_A_const_42 any

var A_arbace_j2g_zlib__init_A_const_43 *lang.Var

var A_arbace_j2g_zlib__init_A_const_44 any

var A_arbace_j2g_zlib__init_A_const_45 any

var A_arbace_j2g_zlib__init_A_const_46 *lang.Var

var A_arbace_j2g_zlib__init_A_const_47 any

var A_arbace_j2g_zlib__init_A_const_48 any

var A_arbace_j2g_zlib__init_A_const_49 *lang.Var

var A_arbace_j2g_zlib__init_A_const_50 any

var A_arbace_j2g_zlib__init_A_const_51 *lang.Var

var A_arbace_j2g_zlib__init_A_const_52 any

var A_arbace_j2g_zlib__init_A_const_53 *lang.Var

var A_arbace_j2g_zlib__init_A_const_54 any

var A_arbace_j2g_zlib__init_A_const_55 *lang.Var

var A_arbace_j2g_zlib__init_A_const_56 any

var A_arbace_j2g_zlib__init_A_init jrt.ClassInit

func A_arbace_j2g_zlib__init_A_Init() { if !A_arbace_j2g_zlib__init_A_init.Done() { A_arbace_j2g_zlib__init_A_init.Run(A_arbace_j2g_zlib__init_A_clinit) } }

func A_arbace_j2g_zlib__init_A_clinit() { A_arbace_j2g_zlib__init_A_clinit_p0(); A_arbace_j2g_zlib__init_A_clinit_p1(); A_arbace_j2g_zlib__init_A_clinit_p2(); A_arbace_j2g_zlib__init_A_clinit_p3(); A_arbace_j2g_zlib__init_A_clinit_p4() }

func A_arbace_j2g_zlib__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_zlib__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_20, 78); A_arbace_j2g_zlib__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[21]); A_arbace_j2g_zlib__init_A_const_1 = A_arbace_j2g_zlib__init_A_const_pool.A[22]; A_arbace_j2g_zlib__init_A_const_2 = A_arbace_j2g_zlib__init_A_const_pool.A[23]; A_arbace_j2g_zlib__init_A_const_3 = A_arbace_j2g_zlib__init_A_const_pool.A[24]; A_arbace_j2g_zlib__init_A_const_4 = jrt.Class_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[25]); A_arbace_j2g_zlib__init_A_const_5 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[26]); A_arbace_j2g_zlib__init_A_const_6 = A_arbace_j2g_zlib__init_A_const_pool.A[27]; A_arbace_j2g_zlib__init_A_const_7 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[28]); A_arbace_j2g_zlib__init_A_const_8 = A_arbace_j2g_zlib__init_A_const_pool.A[29]; A_arbace_j2g_zlib__init_A_const_9 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[30]); A_arbace_j2g_zlib__init_A_const_10 = A_arbace_j2g_zlib__init_A_const_pool.A[31]; A_arbace_j2g_zlib__init_A_const_11 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[32]); A_arbace_j2g_zlib__init_A_const_12 = A_arbace_j2g_zlib__init_A_const_pool.A[33] }

func A_arbace_j2g_zlib__init_A_clinit_p1() { A_arbace_j2g_zlib__init_A_const_13 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[34]); A_arbace_j2g_zlib__init_A_const_14 = A_arbace_j2g_zlib__init_A_const_pool.A[35]; A_arbace_j2g_zlib__init_A_const_15 = A_arbace_j2g_zlib__init_A_const_pool.A[36]; A_arbace_j2g_zlib__init_A_const_16 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[37]); A_arbace_j2g_zlib__init_A_const_17 = A_arbace_j2g_zlib__init_A_const_pool.A[38]; A_arbace_j2g_zlib__init_A_const_18 = A_arbace_j2g_zlib__init_A_const_pool.A[39]; A_arbace_j2g_zlib__init_A_const_19 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[40]); A_arbace_j2g_zlib__init_A_const_20 = A_arbace_j2g_zlib__init_A_const_pool.A[41]; A_arbace_j2g_zlib__init_A_const_21 = A_arbace_j2g_zlib__init_A_const_pool.A[42]; A_arbace_j2g_zlib__init_A_const_22 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[43]); A_arbace_j2g_zlib__init_A_const_23 = A_arbace_j2g_zlib__init_A_const_pool.A[44]; A_arbace_j2g_zlib__init_A_const_24 = A_arbace_j2g_zlib__init_A_const_pool.A[45]; A_arbace_j2g_zlib__init_A_const_25 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[46]); A_arbace_j2g_zlib__init_A_const_26 = A_arbace_j2g_zlib__init_A_const_pool.A[47] }

func A_arbace_j2g_zlib__init_A_clinit_p2() { A_arbace_j2g_zlib__init_A_const_27 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[48]); A_arbace_j2g_zlib__init_A_const_28 = A_arbace_j2g_zlib__init_A_const_pool.A[49]; A_arbace_j2g_zlib__init_A_const_29 = A_arbace_j2g_zlib__init_A_const_pool.A[50]; A_arbace_j2g_zlib__init_A_const_30 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[51]); A_arbace_j2g_zlib__init_A_const_31 = A_arbace_j2g_zlib__init_A_const_pool.A[52]; A_arbace_j2g_zlib__init_A_const_32 = A_arbace_j2g_zlib__init_A_const_pool.A[53]; A_arbace_j2g_zlib__init_A_const_33 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[54]); A_arbace_j2g_zlib__init_A_const_34 = A_arbace_j2g_zlib__init_A_const_pool.A[55]; A_arbace_j2g_zlib__init_A_const_35 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[56]); A_arbace_j2g_zlib__init_A_const_36 = A_arbace_j2g_zlib__init_A_const_pool.A[57]; A_arbace_j2g_zlib__init_A_const_37 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[58]); A_arbace_j2g_zlib__init_A_const_38 = A_arbace_j2g_zlib__init_A_const_pool.A[59]; A_arbace_j2g_zlib__init_A_const_39 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[60]); A_arbace_j2g_zlib__init_A_const_40 = A_arbace_j2g_zlib__init_A_const_pool.A[61] }

func A_arbace_j2g_zlib__init_A_clinit_p3() { A_arbace_j2g_zlib__init_A_const_41 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[62]); A_arbace_j2g_zlib__init_A_const_42 = A_arbace_j2g_zlib__init_A_const_pool.A[63]; A_arbace_j2g_zlib__init_A_const_43 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[64]); A_arbace_j2g_zlib__init_A_const_44 = A_arbace_j2g_zlib__init_A_const_pool.A[65]; A_arbace_j2g_zlib__init_A_const_45 = A_arbace_j2g_zlib__init_A_const_pool.A[66]; A_arbace_j2g_zlib__init_A_const_46 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[67]); A_arbace_j2g_zlib__init_A_const_47 = A_arbace_j2g_zlib__init_A_const_pool.A[68]; A_arbace_j2g_zlib__init_A_const_48 = A_arbace_j2g_zlib__init_A_const_pool.A[69]; A_arbace_j2g_zlib__init_A_const_49 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[70]); A_arbace_j2g_zlib__init_A_const_50 = A_arbace_j2g_zlib__init_A_const_pool.A[71]; A_arbace_j2g_zlib__init_A_const_51 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[72]); A_arbace_j2g_zlib__init_A_const_52 = A_arbace_j2g_zlib__init_A_const_pool.A[73]; A_arbace_j2g_zlib__init_A_const_53 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[74]); A_arbace_j2g_zlib__init_A_const_54 = A_arbace_j2g_zlib__init_A_const_pool.A[75] }

func A_arbace_j2g_zlib__init_A_clinit_p4() { A_arbace_j2g_zlib__init_A_const_55 = lang.Var_Cast(A_arbace_j2g_zlib__init_A_const_pool.A[76]); A_arbace_j2g_zlib__init_A_const_56 = A_arbace_j2g_zlib__init_A_const_pool.A[77] }

func A_arbace_j2g_zlib__init_A_New() *A_arbace_j2g_zlib__init_A { A_arbace_j2g_zlib__init_A_Init(); t := &A_arbace_j2g_zlib__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib__init_A) Ctor() {}

func (t *A_arbace_j2g_zlib__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib__init_A_class }

func (t *A_arbace_j2g_zlib__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib__init_A); return ok }

func A_arbace_j2g_zlib__init_A_Cast(x any) *A_arbace_j2g_zlib__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib__init_A_class)) }; return v }
