//line j2g_classes.ae:1
package aot_arbace_j2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_zlib_adler32_A_class, Name: "arbace.j2g.zlib$adler32", Modifiers: 25, Simple: "adler32", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_adler32_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_canonical_codes_A_class, Name: "arbace.j2g.zlib$canonical_codes", Modifiers: 25, Simple: "canonical_codes", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_canonical_codes_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_code_of_A_class, Name: "arbace.j2g.zlib$code_of", Modifiers: 25, Simple: "code_of", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_code_of_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_deflate_A_class, Name: "arbace.j2g.zlib$deflate", Modifiers: 25, Simple: "deflate", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_deflate_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_class, Name: "arbace.j2g.zlib$eval1931000004$loading__1927001464__auto____1931000005", Modifiers: 25, Simple: "loading__1927001464__auto____1931000005", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_eval1931000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_class, Name: "arbace.j2g.zlib$eval1931000008$fn__1931000009", Modifiers: 25, Simple: "fn__1931000009", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_eval1931000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_class, Name: "arbace.j2g.zlib$eval1931000012$__GT_Bits__1931000014", Modifiers: 25, Simple: "__GT_Bits__1931000014", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_eval1931000012_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_huffman_lengths_A_class, Name: "arbace.j2g.zlib$huffman_lengths", Modifiers: 25, Simple: "huffman_lengths", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_huffman_lengths_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_class, Name: "arbace.j2g.zlib$huffman_lengths$fn__1931000019", Modifiers: 25, Simple: "fn__1931000019", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_huffman_lengths_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_class, Name: "arbace.j2g.zlib$huffman_lengths$fn__1931000021", Modifiers: 25, Simple: "fn__1931000021", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_huffman_lengths_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_class, Name: "arbace.j2g.zlib$huffman_lengths$fn__1931000023", Modifiers: 25, Simple: "fn__1931000023", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_huffman_lengths_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_class, Name: "arbace.j2g.zlib$huffman_lengths$fn__1931000025", Modifiers: 25, Simple: "fn__1931000025", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_huffman_lengths_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_class, Name: "arbace.j2g.zlib$huffman_lengths$fn__1931000025$fn__1931000026", Modifiers: 25, Simple: "fn__1931000026", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_insert_BANG__A_class, Name: "arbace.j2g.zlib$insert_BANG_", Modifiers: 25, Simple: "insert_BANG_", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_insert_BANG__A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_longest_A_class, Name: "arbace.j2g.zlib$longest", Modifiers: 25, Simple: "longest", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_longest_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_lz77_A_class, Name: "arbace.j2g.zlib$lz77", Modifiers: 25, Simple: "lz77", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_lz77_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_match_length_A_class, Name: "arbace.j2g.zlib$match_length", Modifiers: 25, Simple: "match_length", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_match_length_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_reverse_bits_A_class, Name: "arbace.j2g.zlib$reverse_bits", Modifiers: 25, Simple: "reverse_bits", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_reverse_bits_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_rle_lengths_A_class, Name: "arbace.j2g.zlib$rle_lengths", Modifiers: 25, Simple: "rle_lengths", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_rle_lengths_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_class, Name: "arbace.j2g.zlib$rle_lengths$fn__1931000038", Modifiers: 25, Simple: "fn__1931000038", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_rle_lengths_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_write_block_BANG__A_class, Name: "arbace.j2g.zlib$write_block_BANG_", Modifiers: 25, Simple: "write_block_BANG_", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_write_block_BANG__A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_class, Name: "arbace.j2g.zlib$write_block_BANG_$fn__1931000045", Modifiers: 25, Simple: "fn__1931000045", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_write_block_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_class, Name: "arbace.j2g.zlib$write_block_BANG_$fn__1931000047", Modifiers: 25, Simple: "fn__1931000047", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_write_block_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_class, Name: "arbace.j2g.zlib$write_block_BANG_$fn__1931000049", Modifiers: 25, Simple: "fn__1931000049", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_write_block_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_class, Name: "arbace.j2g.zlib$write_block_BANG_$fn__1931000055", Modifiers: 25, Simple: "fn__1931000055", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_write_block_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_class, Name: "arbace.j2g.zlib$write_block_BANG_$fn__1931000063", Modifiers: 25, Simple: "fn__1931000063", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A", Source: "zlib.ae", Declaring: &A_arbace_j2g_zlib_write_block_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_zlib_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_zlib_A_New()}; return nil }

var A_arbace_j2g_zlib_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_zlib_A_new}

var A_arbace_j2g_zlib_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.zlib", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_A"})

func init() { i := A_arbace_j2g_zlib_A_class.Info(); i.IsInstance = A_arbace_j2g_zlib_A_InstanceOf; i.Init = A_arbace_j2g_zlib_A_Init; i.Table = A_arbace_j2g_zlib_A_members }

var A_arbace_j2g_zlib_adler32_A_class *jrt.Class

var A_arbace_j2g_zlib_canonical_codes_A_class *jrt.Class

var A_arbace_j2g_zlib_code_of_A_class *jrt.Class

var A_arbace_j2g_zlib_deflate_A_class *jrt.Class

func A_arbace_j2g_zlib_eval1931000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_zlib_eval1931000004_A_New()}; return nil }

var A_arbace_j2g_zlib_eval1931000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_zlib_eval1931000004_A_new}

var A_arbace_j2g_zlib_eval1931000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.zlib$eval1931000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_zlib_A_class, Simple: "eval1931000004", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_eval1931000004_A"})

func init() { i := A_arbace_j2g_zlib_eval1931000004_A_class.Info(); i.IsInstance = A_arbace_j2g_zlib_eval1931000004_A_InstanceOf; i.Table = A_arbace_j2g_zlib_eval1931000004_A_members }

var A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_class *jrt.Class

func A_arbace_j2g_zlib_eval1931000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_zlib_eval1931000008_A_New()}; return nil }

var A_arbace_j2g_zlib_eval1931000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_zlib_eval1931000008_A_new}

var A_arbace_j2g_zlib_eval1931000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.zlib$eval1931000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_zlib_A_class, Simple: "eval1931000008", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_eval1931000008_A"})

func init() { i := A_arbace_j2g_zlib_eval1931000008_A_class.Info(); i.IsInstance = A_arbace_j2g_zlib_eval1931000008_A_InstanceOf; i.Table = A_arbace_j2g_zlib_eval1931000008_A_members }

var A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_class *jrt.Class

func A_arbace_j2g_zlib_eval1931000012_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_zlib_eval1931000012_A_New()}; return nil }

var A_arbace_j2g_zlib_eval1931000012_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_zlib_eval1931000012_A_new}

var A_arbace_j2g_zlib_eval1931000012_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.zlib$eval1931000012", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_zlib_A_class, Simple: "eval1931000012", Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_eval1931000012_A"})

func init() { i := A_arbace_j2g_zlib_eval1931000012_A_class.Info(); i.IsInstance = A_arbace_j2g_zlib_eval1931000012_A_InstanceOf; i.Table = A_arbace_j2g_zlib_eval1931000012_A_members }

var A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_class *jrt.Class

var A_arbace_j2g_zlib_huffman_lengths_A_class *jrt.Class

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_class *jrt.Class

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_class *jrt.Class

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_class *jrt.Class

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_class *jrt.Class

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_class *jrt.Class

var A_arbace_j2g_zlib_insert_BANG__A_class *jrt.Class

var A_arbace_j2g_zlib_longest_A_class *jrt.Class

var A_arbace_j2g_zlib_lz77_A_class *jrt.Class

var A_arbace_j2g_zlib_match_length_A_class *jrt.Class

var A_arbace_j2g_zlib_reverse_bits_A_class *jrt.Class

var A_arbace_j2g_zlib_rle_lengths_A_class *jrt.Class

var A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_class *jrt.Class

var A_arbace_j2g_zlib_write_block_BANG__A_class *jrt.Class

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_class *jrt.Class

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_class *jrt.Class

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_class *jrt.Class

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_class *jrt.Class

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_class *jrt.Class

func A_arbace_j2g_zlib_Bits_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_zlib_Bits_A_GetBasis__IPersistentVector(); case 1: return this.(*A_arbace_j2g_zlib_Bits_A).Invoke__O(); case 2: return this.(*A_arbace_j2g_zlib_Bits_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_j2g_zlib_Bits_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_zlib_Bits_A_New_O_J_J(args[0], args[1].(int64), args[2].(int64))}; return nil }

func A_arbace_j2g_zlib_Bits_A_get(i int32, o any) any { switch i { case 0: return o.(*A_arbace_j2g_zlib_Bits_A).F_out}; return nil }

var A_arbace_j2g_zlib_Bits_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 getBasis ()Larbace.lang.IPersistentVector;\nM1 invoke ()Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;JJ)V\nG17 out Ljava.lang.Object;", Invoke: A_arbace_j2g_zlib_Bits_A_invoke, New: A_arbace_j2g_zlib_Bits_A_new, Get: A_arbace_j2g_zlib_Bits_A_get}

var A_arbace_j2g_zlib_Bits_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.zlib.Bits", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IFn_class, lang.IType_class}, Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib_Bits_A", Source: "zlib.ae"})

func init() { i := A_arbace_j2g_zlib_Bits_A_class.Info(); i.IsInstance = A_arbace_j2g_zlib_Bits_A_InstanceOf; i.Table = A_arbace_j2g_zlib_Bits_A_members }

func A_arbace_j2g_zlib__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_zlib__init_A_Load__O()}; return nil }

func A_arbace_j2g_zlib__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_zlib__init_A_New()}; return nil }

var A_arbace_j2g_zlib__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_zlib__init_A_invoke, New: A_arbace_j2g_zlib__init_A_new}

var A_arbace_j2g_zlib__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.zlib__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_zlib.A_arbace_j2g_zlib__init_A", Source: "zlib.ae"})

func init() { i := A_arbace_j2g_zlib__init_A_class.Info(); i.IsInstance = A_arbace_j2g_zlib__init_A_InstanceOf; i.Init = A_arbace_j2g_zlib__init_A_Init; i.Table = A_arbace_j2g_zlib__init_A_members }
