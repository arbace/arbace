//line aot_arbace_j2g_zlib.ae:1
package aot_arbace_j2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_New() *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_zlib_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_1); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp5 != nil { panic(tmp5) }; return tmp3 }
//line :1:1
func A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_New() *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_zlib_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_6), A_arbace_j2g_zlib_A_const_4.GetRawRoot__O(), A_arbace_j2g_zlib_A_const_5) }

















func A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_New() *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Invoke_O_O_O_O__O(self, out__1, acc__2, n__3 any) any { return A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__1, lang.RT_LongCast_O__J(acc__2), lang.RT_LongCast_O__J(n__3)) }



















func A_arbace_j2g_zlib_reverse_bits_A_New() *A_arbace_j2g_zlib_reverse_bits_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_reverse_bits_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Invoke_O_O_O__O(self, p_code__0, p_len__1 any) any { var code__0 int64 = lang.RT_LongCast_O__J(p_code__0); var len__1 int64 = lang.RT_LongCast_O__J(p_len__1); var tmp1 int64; var c__3 int64 = code__0; var r__4 int64 = 0; var i__5 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z(i__5, len__1) { c__3, r__4, i__5 = lang.Numbers_ShiftRight_J_J__J(c__3, 1), lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(r__4, 1), lang.Numbers_And_J_J__J(c__3, 1)), lang.Numbers_Inc_J__J(i__5); continue L1 } else { tmp1 = r__4 }
//line :39:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }






func A_arbace_j2g_zlib_huffman_lengths_A_New() *A_arbace_j2g_zlib_huffman_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Ctor() {}
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Invoke_O_O_O__O(self, freqs__0, p_limit__1 any) any { { var limit__1 int64 = lang.RT_LongCast_O__J(p_limit__1); var n__3 int32 = lang.RT_Alength_J1__I(jrt.J2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())); var fs__4 any = lang.RT_Aclone_J1__J1(jrt.J2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())).Ref(); L1: for { var syms__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(fs__4); var tmp3 *jrt.Class
													var fncls__2 /*line :46:1*/*jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class






	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; syms__5 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(n__3).Ref()))
//line :46:1
	var lens__6 any = lang.Numbers_Long_array_O__J1(jrt.Integer_ValueOf_I__Integer(n__3).Ref()).Ref()








	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_8.GetRawRoot__O()).Invoke_O__O(syms__5)) { return lens__6 } else { if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(syms__5))) {

		jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](lens__6, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(syms__5))), 1))
//line :55:1
		return lens__6 } else { if A_arbace_j2g_zlib_A_const_9 != nil { var parent__7 any = lang.Numbers_Long_array_O__J1(jrt.Long_ValueOf_J__Long(lang.Numbers_Multiply_J_J__J(2, int64(n__3))).Ref()).Ref(); var start__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_10.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_15.GetRawRoot__O()).Invoke__O(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_16.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(fs__4); var tmp8 *jrt.Class
			var fncls__3 /*line :55:1*/*jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class






			if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class = fncls__3d; tmp8 = fncls__3d } else { tmp8 = fncls__3 }; start__8 = tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), syms__5))
//line :55:1
			var ___9 any; var tmp9 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(parent__7, n__3, start__8); var tmp10 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class; _ = ___9







			if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class = fncls__1d; tmp10 = fncls__1d } else { tmp10 = fncls__1 }; ___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :55:1
			var root__10 int64 = lang.Numbers_Add_J_J__J(lang.Numbers_Add_J_J__J(int64(n__3), lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(syms__5)))), -1); var maxlen__11 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_13.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(parent__7, lens__6, root__10); var tmp13 *jrt.Class
			var fncls__5 /*line :55:1*/*jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class















			if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class = fncls__5d; tmp13 = fncls__5d } else { tmp13 = fncls__5 }; maxlen__11 = tmp11.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_j2g_zlib_A_const_17, syms__5)




			if lang.Numbers_Lte_O_J__Z(maxlen__11, limit__1) { return lens__6 } else { var f2__12 any = lang.Numbers_Long_array_O__J1(jrt.Integer_ValueOf_I__Integer(n__3).Ref()).Ref(); var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J(n__3); var i__14 int64 = 0; L2: for {


				if lang.Numbers_Lt_J_J__Z(i__14, n__1927000701__auto____13) { var f__15 int64 = lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](fs__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__14))
					if lang.Numbers_IsPos_J__Z(f__15) { jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](f2__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__14), lang.Numbers_Max_J_J__J(1, lang.Numbers_ShiftRight_J_J__J(f__15, 1)))) }
//line :79:1
					i__14 = lang.Numbers_Unchecked_inc_J__J(i__14); continue L2 }
//line :76:1
				break L2
			}



				fs__4 = f2__12; continue L1 } } else {
//line :55:1
					return nil } } } } }; /*line :46:1*/panic("j2g: unreachable") }






func A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Invoke_O_O__O(self, p1__1931000018_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__1931000018_SHARP___1))))).Ref() }








func A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__1)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(s__1)).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(s__1)).Ref()) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Ctor_O_I_O(c__parent any, c__n int32, c__start any) { t.F_parent = c__parent; t.F_n = c__n; t.F_start = c__start }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Invoke_O__O(self any) any { { var q__1 any; var t_ any = t.F_start; t.F_start = nil; q__1 = t_; var next_id__2 int64 = lang.RT_LongCast_I__J(t.F_n); var order__3 int64 = lang.RT_LongCast_I__J(t.F_n); L1: for {
											if lang.Numbers_Gt_J_J__Z(int64(lang.RT_Count_O__I(q__1)), 1) { var a__4 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(q__1); var q__5 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_12.GetRawRoot__O()).Invoke_O_O__O(q__1, a__4); var b__6 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(q__5); var q__7 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_12.GetRawRoot__O()).Invoke_O_O__O(q__5, b__6); var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass())

		jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(lang.RT_Nth_O_I__O(a__4, lang.RT_IntCast_J__I(2)))), next_id__2))
		var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp2, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(lang.RT_Nth_O_I__O(b__6, lang.RT_IntCast_J__I(2)))), next_id__2))
		q__1, next_id__2, order__3 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()).Invoke_O_O__O(q__7, lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(lang.Numbers_Add_J_J__J(lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(a__4, lang.RT_IntCast_J__I(0))), lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(b__6, lang.RT_IntCast_J__I(0))))).Ref(), jrt.Long_ValueOf_J__Long(order__3).Ref(), jrt.Long_ValueOf_J__Long(next_id__2).Ref())), lang.Numbers_Inc_J__J(next_id__2), lang.Numbers_Inc_J__J(order__3); continue L1 } else {
//line :64:1
			return nil } } }; /*line :63:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Ctor_O_O_J(c__parent, c__lens any, c__root int64) { t.F_parent = c__parent; t.F_lens = c__lens; t.F_root = c__root }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Invoke_O_O_O__O(self, p_m__1, s__2 any) any { var m__1 int64 = lang.RT_LongCast_O__J(p_m__1); var d__3 int64; var tmp1 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(t.F_parent, s__2, t.F_root); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class; if
														fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; d__3 = lang.RT_LongCast_O__J(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()); var tmp3 /*line :73:1*/*jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_lens, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp3, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__2)), d__3)); return /*line :74:1*/ jrt.Long_ValueOf_J__Long(lang.Numbers_Max_J_J__J(m__1, d__3)).Ref() }
//line :72:1
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Ctor_O_O_J(c__parent, c__s any, c__root int64) { t.F_parent = c__parent; t.F_s = c__s; t.F_root = c__root }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Invoke_O__O(self any) any { { var x__1 int64; var tmp1 any; var t_ any = t.F_s; t.F_s = nil; tmp1 = t_; x__1 = lang.RT_LongCast_O__J(tmp1); var d__2 int64 = 0; L1: for { if lang.Numbers_Equiv_J_J__Z(x__1, t.F_root) { return jrt.Long_ValueOf_J__Long(d__2).Ref() } else { var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); x__1, d__2 = lang.RT_Aget_J1_I__J(tmp2, lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(x__1))), lang.Numbers_Inc_J__J(d__2); continue L1 } } }; panic("j2g: unreachable") }










func A_arbace_j2g_zlib_canonical_codes_A_New() *A_arbace_j2g_zlib_canonical_codes_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_canonical_codes_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Invoke_O_O__O(self, lens__0 any) any { var n__2 int32 = lang.RT_Alength_J1__I(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass())); var bl_count__3 any = lang.Numbers_Long_array_O__J1(A_arbace_j2g_zlib_A_const_18).Ref(); var next_code__4 any = lang.Numbers_Long_array_O__J1(A_arbace_j2g_zlib_A_const_18).Ref(); var codes__5 any = lang.Numbers_Long_array_O__J1(jrt.Integer_ValueOf_I__Integer(n__2).Ref()).Ref(); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J(n__2); var i__7 int64 = 0; L1: for {







	if lang.Numbers_Lt_J_J__Z(i__7, n__1927000701__auto____6) { var l__8 int64 = lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__7)); if lang.Numbers_IsPos_J__Z(l__8) { jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8)))))) }; i__7 = lang.Numbers_Unchecked_inc_J__J(i__7); continue L1 }
//line :83:1
	break L1 }; var bits__6 int64 = 1; var code__7 int64 = 0; L2: for {









		if lang.Numbers_Lt_J_J__Z(bits__6, 16) { var code__8 int64 = lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_Add_J_J__J(code__7, lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(bits__6)))), 1)

			jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(bits__6), code__8))
			bits__6, code__7 = lang.Numbers_Inc_J__J(bits__6), code__8; continue L2 }
//line :83:1
		break L2 }; var n__1927000701__auto____6_2 int64 = lang.RT_LongCast_I__J(n__2); var i__7_2 int64 = 0; L3: for {













			if lang.Numbers_Lt_J_J__Z(i__7_2, n__1927000701__auto____6_2) { var l__8_2 int64 = lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__7_2))

				if lang.Numbers_IsPos_J__Z(l__8_2) {
					jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](codes__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__7_2), lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8_2)))).Ref(), jrt.Long_ValueOf_J__Long(l__8_2).Ref()))))
					jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8_2)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(l__8_2)))))) }
//line :97:1
				i__7_2 = lang.Numbers_Unchecked_inc_J__J(i__7_2); continue L3 }
//line :83:1
			break L3 }; return codes__5 }





























func A_arbace_j2g_zlib_code_of_A_New() *A_arbace_j2g_zlib_code_of_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_code_of_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Invoke_O_O_O__O(self, bases__0, p_v__1 any) any { var v__1 int64 = lang.RT_LongCast_O__J(p_v__1); var tmp1 int64; var i__3 int64 = lang.Numbers_Dec_J__J(int64(lang.RT_Alength_J1__I(jrt.J2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass())))); L1: for {


	if lang.Numbers_Gt_J_J__Z(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(i__3)), v__1) { i__3 = lang.Numbers_Dec_J__J(i__3); continue L1 } else { tmp1 = i__3 }
//line :113:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }













func A_arbace_j2g_zlib_match_length_A_New() *A_arbace_j2g_zlib_match_length_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_match_length_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Invoke_O_O_O_O_O__O(self, b__0, p_i__1, p_j__2, p_max__3 any) any { var i__1 int64 = lang.RT_LongCast_O__J(p_i__1); var j__2 int64 = lang.RT_LongCast_O__J(p_j__2); var max__3 int64 = lang.RT_LongCast_O__J(p_max__3); var tmp1 int64; var k__5 int64 = 0; L1: for {


	var tmp2 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lt_J_J__Z(k__5, max__3); if and__1927000168__auto____6 { tmp2 = lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__1, k__5)))).Ref()), lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(j__2, k__5)))).Ref())) } else { tmp2 = and__1927000168__auto____6 }; if tmp2 { k__5 = lang.Numbers_Inc_J__J(k__5); continue L1 } else { tmp1 = k__5 }
//line :127:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }




func A_arbace_j2g_zlib_insert_BANG__A_New() *A_arbace_j2g_zlib_insert_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_insert_BANG__A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Invoke_O_O_O_O_O__O(self, b__0, head__1, prev__2, p_i__3 any) any { var i__3 int64 = lang.RT_LongCast_O__J(p_i__3); if



	lang.Numbers_Lte_J_J__Z(lang.Numbers_Add_J_J__J(i__3, 3), int64(lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var h__5 int64 = lang.Numbers_And_J_J__J(lang.Numbers_Xor_J_J__J(lang.Numbers_Xor_J_J__J(lang.Numbers_Xor_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__3))).Ref()), 255), 8), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__3, 1)))).Ref()), 255), 4)), lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__3, 2)))).Ref()), 255)), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(i__3, 2)))).Ref()), 255), 11)), 65535)





		jrt.Integer_ValueOf_I__Integer(lang.RT_Aset_I1_I_I__I(jrt.J2g_CastArray[*jrt.IntArray](prev__2, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(i__3), lang.RT_Aget_I1_I__I(jrt.J2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(h__5))))
		jrt.Integer_ValueOf_I__Integer(lang.RT_Aset_I1_I_I__I(jrt.J2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(h__5), lang.RT_IntCast_J__I(i__3))) }; return nil }


func A_arbace_j2g_zlib_longest_A_New() *A_arbace_j2g_zlib_longest_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_longest_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Invoke_O_O_O_O__O(self, b__0, prev__1, p_i__2 any) any { var i__2 int64 = lang.RT_LongCast_O__J(p_i__2); var tmp1 int64; var n__4 int32 = lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); if




	lang.Numbers_Gt_J_J__Z(lang.Numbers_Add_J_J__J(i__2, 3), int64(n__4)) { tmp1 = 0 } else { var maxl__5 int64 = lang.Numbers_Min_J_J__J(258, lang.Numbers_Minus_J_J__J(int64(n__4), i__2)); var j__6 int64 = lang.RT_LongCast_I__J(lang.RT_Aget_I1_I__I(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(i__2))); var chain__7 int64 = 0; var best__8 any = lang.RT_Box_J__Number(0); var bestd__9 int64 = 0; L1: for {



		var tmp2 bool; var or__1927000174__auto____10 bool = lang.Numbers_IsNeg_J__Z(j__6); if or__1927000174__auto____10 { tmp2 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 bool = lang.Numbers_Gt_J_J__Z(lang.Numbers_Minus_J_J__J(i__2, j__6), 32768); if or__1927000174__auto____11 { tmp2 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 bool = lang.Numbers_Gte_J_J__Z(chain__7, 64); if or__1927000174__auto____12 { tmp2 = or__1927000174__auto____12 } else { var or__1927000174__auto____13 bool = lang.Numbers_Gte_O_J__Z(best__8, 64); if or__1927000174__auto____13 { tmp2 = or__1927000174__auto____13 } else { tmp2 = lang.Numbers_Gte_O_J__Z(best__8, maxl__5) } } } }; if tmp2 {
			if lang.Numbers_Gte_O_J__Z(best__8, 3) { tmp1 = lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(best__8, 16), bestd__9) } else { tmp1 = 0 } } else {
//line :155:1
				var l__10 any

				if lang.Numbers_Equiv_J_J__Z(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(j__6, best__8)))).Ref()), lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(i__2, best__8)))).Ref())) {
					l__10 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, jrt.Long_ValueOf_J__Long(i__2).Ref(), jrt.Long_ValueOf_J__Long(j__6).Ref(), jrt.Long_ValueOf_J__Long(maxl__5).Ref()) } else {
//line :157:1
						l__10 = A_arbace_j2g_zlib_A_const_17
					}

				if lang.Numbers_Gt_J_O__Z(lang.RT_LongCast_O__J(l__10), best__8) {
					j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J(lang.RT_Aget_I1_I__I(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(j__6))), lang.Numbers_Inc_J__J(chain__7), l__10, lang.Numbers_Minus_J_J__J(i__2, j__6); continue L1 } else {
						j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J(lang.RT_Aget_I1_I__I(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I(j__6))), lang.Numbers_Inc_J__J(chain__7), best__8, bestd__9; continue L1 } }
//line :151:1
		break L1 } }; return /*line :146:1*/ jrt.Long_ValueOf_J__Long(tmp1).Ref() }

















func A_arbace_j2g_zlib_lz77_A_New() *A_arbace_j2g_zlib_lz77_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_lz77_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Invoke_O_O__O(self, b__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var head__3 any = lang.Numbers_Int_array_I_O__I1(lang.RT_IntCast_J__I(65536), A_arbace_j2g_zlib_A_const_21).Ref(); var prev__4 any = lang.Numbers_Int_array_I_O__I1(lang.RT_IntCast_J__I(lang.Numbers_Max_J_J__J(int64(n__2), 1)), A_arbace_j2g_zlib_A_const_21).Ref(); var out__5 any = lang.Numbers_Long_array_O__J1(jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(n__2))).Ref()).Ref(); var flag__6 int64 = lang.Numbers_ShiftLeft_J_J__J(1, 40); var i__7 int64 = 0; var k__8 int64 = 0; var pending__9 any = lang.RT_Box_J__Number(0); L1: for {











	if lang.Numbers_Gte_J_J__Z(i__7, int64(n__2)) {
		if lang.Numbers_IsPos_O__Z(pending__9) {
			jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.Numbers_Or_O_J__J(pending__9, flag__6)))
//line :177:1
			return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(k__8)).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long(k__8).Ref()) } } else {



				lang.IFn_Cast(A_arbace_j2g_zlib_A_const_23.GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, head__3, prev__4, jrt.Long_ValueOf_J__Long(i__7).Ref())
//line :176:1
				var m__10 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(b__0, prev__4, jrt.Long_ValueOf_J__Long(i__7).Ref())






				if lang.Numbers_IsPos_O__Z(pending__9) {

					if lang.Numbers_Gt_J_J__Z(lang.Numbers_ShiftRight_O_J__J(m__10, 16), lang.Numbers_ShiftRight_O_J__J(pending__9, 16)) {

						jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.RT_LongCast_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Dec_J__J(i__7)))).Ref()), 255))))
						i__7, k__8, pending__9 = lang.Numbers_Inc_J__J(i__7), lang.Numbers_Inc_J__J(k__8), m__10; continue L1 } else {
//line :185:1
							var end__11 int64 = lang.Numbers_Add_J_J__J(lang.Numbers_Dec_J__J(i__7), lang.Numbers_ShiftRight_O_J__J(pending__9, 16))





							jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.Numbers_Or_O_J__J(pending__9, flag__6)))
//line :185:1
							var x__12 int64 = lang.Numbers_Inc_J__J(i__7); L2: for {






								if lang.Numbers_Lt_J_J__Z(x__12, end__11) { lang.IFn_Cast(A_arbace_j2g_zlib_A_const_23.GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, head__3, prev__4, jrt.Long_ValueOf_J__Long(x__12).Ref()); x__12 = lang.Numbers_Inc_J__J(x__12); continue L2 }
//line :185:1
								break L2
							}






							i__7, k__8, pending__9 = end__11, lang.Numbers_Inc_J__J(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } } else {
//line :183:1
								if lang.Numbers_IsPos_O__Z(m__10) {










									i__7, k__8, pending__9 = lang.Numbers_Inc_J__J(i__7), k__8, m__10; continue L1 } else {
//line :183:1
										if A_arbace_j2g_zlib_A_const_9 != nil {











											jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(k__8), lang.RT_LongCast_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__7))).Ref()), 255))))
											i__7, k__8, pending__9 = lang.Numbers_Inc_J__J(i__7), lang.Numbers_Inc_J__J(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } else {
//line :183:1
												return nil } } } } } }; /*line :164:1*/panic("j2g: unreachable") }







































func A_arbace_j2g_zlib_rle_lengths_A_New() *A_arbace_j2g_zlib_rle_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Invoke_O_O__O(self, ls__0 any) any { { var v__2 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_24.GetRawRoot__O()).Invoke_O__O(ls__0); var n__3 int32 = lang.RT_Count_O__I(v__2); var i__4 any = lang.RT_Box_J__Number(0); var acc__5 any; lang.PersistentVector_Init(); acc__5 = lang.PersistentVector_EMPTY.Ref(); L1: for {




	if lang.Numbers_Gte_O_J__Z(i__4, int64(n__3)) { return acc__5 } else { var x__6 int64 = lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(v__2, lang.RT_IntCast_O__I(i__4))); var run__7 any; var tmp1 any = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(i__4, n__3, x__6, v__2); var tmp2 *jrt.Class
		var fncls__6 /*line :209:1*/*jrt.Class = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class


		if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; run__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
		var tmp3 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsZero_J__Z(x__6)
		if and__1927000168__auto____8 { tmp3 = lang.Numbers_Gte_O_J__Z(run__7, 11) } else { tmp3 = and__1927000168__auto____8 }
//line :213:1
		if tmp3 { var r__8 any = lang.Numbers_Min_O_J__O(run__7, 138); var tmp4 any = A_arbace_j2g_zlib_A_const_25
			i__4, acc__5 = lang.Numbers_Add_O_O__Number(i__4, r__8), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()).Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.Numbers_Minus_O_J__Number(r__8, 11))); continue L1 } else {
//line :213:1
				var tmp5 bool; var and__1927000168__auto____8_2 bool = lang.Numbers_IsZero_J__Z(x__6)

				if and__1927000168__auto____8_2 { tmp5 = lang.Numbers_Gte_O_J__Z(run__7, 3) } else { tmp5 = and__1927000168__auto____8_2 }
//line :213:1
				if tmp5 { var r__8_2 any = lang.Numbers_Min_O_J__O(run__7, 10)
					var tmp6 any = A_arbace_j2g_zlib_A_const_26
					i__4, acc__5 = lang.Numbers_Add_O_O__Number(i__4, r__8_2), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()).Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Numbers_Minus_O_J__Number(r__8_2, 3))); continue L1 } else {
//line :213:1
						var tmp7 bool; var and__1927000168__auto____8_3 bool = lang.Numbers_IsPos_J__Z(x__6)


						if and__1927000168__auto____8_3 { tmp7 = lang.Numbers_Gte_O_J__Z(run__7, 4) } else { tmp7 = and__1927000168__auto____8_3 }
//line :213:1
						if tmp7 { var r__8_3 any = lang.Numbers_Min_O_J__O(lang.Numbers_Dec_O__Number(run__7), 6)
							var tmp8 any = A_arbace_j2g_zlib_A_const_18

							i__4, acc__5 = lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_J__Number(i__4, 1), r__8_3), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(x__6).Ref(), A_arbace_j2g_zlib_A_const_17), lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.Numbers_Minus_O_J__Number(r__8_3, 3))); continue L1 } else {
//line :213:1
								if A_arbace_j2g_zlib_A_const_9 != nil {



									i__4, acc__5 = lang.Numbers_Inc_O__Number(i__4), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()).Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(x__6).Ref(), A_arbace_j2g_zlib_A_const_17)); continue L1 } else {
//line :213:1
										return nil } } } } } } }; /*line :204:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(p0 any, p1 int32, p2 int64, p3 any) *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A{}; t.Ctor_O_I_J_O(p0, p1, p2, p3); return t }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Ctor_O_I_J_O(c__i any, c__n int32, c__x int64, c__v any) { t.F_i = c__i; t.F_n = c__n; t.F_x = c__x; t.F_v = c__v }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Invoke_O__O(self any) any { { var j__1 any = t.F_i; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(t.F_n)); if and__1927000168__auto____2 { var tmp2 int64 = t.F_x; var tmp3 any = t.F_v; tmp1 = lang.Numbers_Equiv_J_J__Z(tmp2, lang.RT_LongCast_O__J(lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_O__I(j__1)))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return lang.Numbers_Minus_O_O__Number(j__1, t.F_i) } } }; panic("j2g: unreachable") }






func A_arbace_j2g_zlib_write_block_BANG__A_New() *A_arbace_j2g_zlib_write_block_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Ctor() {}
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Invoke_O_O_O_O_O_O__O(self, w__0, syms__1, from__2, to__3, last_QMARK___4 any) any { var from__6 int64 = lang.RT_LongCast_O__J(from__2); var to__7 int64 = lang.RT_LongCast_O__J(to__3); var lf__8 any = lang.Numbers_Long_array_O__J1(A_arbace_j2g_zlib_A_const_27).Ref(); var df__9 any = lang.Numbers_Long_array_O__J1(A_arbace_j2g_zlib_A_const_28).Ref(); var i__10 int64 = from__6; L1: for {




	if lang.Numbers_Lt_J_J__Z(i__10, to__7) { var s__11 int64 = lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(i__10)))

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_41.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(s__11).Ref(), A_arbace_j2g_zlib_A_const_43)) { var len__12 int64 = lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_J_J__J(s__11, 16), 65535); var d__13 int64 = lang.Numbers_And_J_J__J(s__11, 65535)

			jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(257, lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Long_ValueOf_J__Long(len__12).Ref())))), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(lang.Numbers_Add_J_J__J(257, lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Long_ValueOf_J__Long(len__12).Ref()))))))))
			jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Long_ValueOf_J__Long(d__13).Ref()))), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(lang.RT_LongCast_O__J(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Long_ValueOf_J__Long(d__13).Ref()))))))) } else {
				jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__11)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__11)))))) }
		i__10 = lang.Numbers_Inc_J__J(i__10); continue L1 }
//line :219:1
	break L1 };












	jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(256), 1)); var used__10 int32; var tmp1 lang.IFn = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(df__9); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class; if














	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; used__10 = lang.RT_Count_O__I(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_28))); if
	lang.Numbers_IsZero_J__Z(int64(used__10)) { jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(0), 1)); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(1), 1)) } else { if lang.Numbers_Equiv_J_J__Z(1, int64(used__10)) {
		var tmp4 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp5 int64; if lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(0))) { tmp5 = 1 } else { tmp5 = 0 }; jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp4, lang.RT_IntCast_J__I(tmp5), 1)) } }; var ll__10 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lf__8, A_arbace_j2g_zlib_A_const_46); var dl__11 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_29.GetRawRoot__O()).Invoke_O_O__O(df__9, A_arbace_j2g_zlib_A_const_46); var lc__12 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_30.GetRawRoot__O()).Invoke_O__O(ll__10); var dc__13 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_30.GetRawRoot__O()).Invoke_O__O(dl__11); var hlit__14 any; var tmp6 any; var or__1927000174__auto____14 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_31.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_40.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(ll__10); var tmp10 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class; if





















	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class = fncls__9d; tmp10 = fncls__9d } else { tmp10 = fncls__9 }; or__1927000174__auto____14 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_47))); if jrt.J2g_Truth(or__1927000174__auto____14) { tmp6 = or__1927000174__auto____14 } else { tmp6 = A_arbace_j2g_zlib_A_const_17 }; hlit__14 = lang.Numbers_Max_J_O__O(257, lang.Numbers_Inc_O__Number(tmp6)); var hdist__15 any; var tmp11 any; var or__1927000174__auto____15 any; var tmp12 lang.IFn = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_31.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(dl__11); var tmp15 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class; if






















	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class = fncls__10d; tmp15 = fncls__10d } else { tmp15 = fncls__10 }; or__1927000174__auto____15 = tmp12.Invoke_O__O(tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_28))); if jrt.J2g_Truth(or__1927000174__auto____15) { tmp11 = or__1927000174__auto____15 } else { tmp11 = A_arbace_j2g_zlib_A_const_17 }; hdist__15 = lang.Numbers_Max_J_O__O(1, lang.Numbers_Inc_O__Number(tmp11)); var rle__16 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_48.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_49.GetRawRoot__O()).Invoke_O_O__O(hlit__14, lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(ll__10)), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_49.GetRawRoot__O()).Invoke_O_O__O(hdist__15, lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(dl__11)))); var cf__17 any = lang.Numbers_Long_array_O__J1(A_arbace_j2g_zlib_A_const_33).Ref(); var ___18 any; var tmp16 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(cf__17, rle__16); var tmp17 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class; _ = ___18; if

























	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class = fncls__7d; tmp17 = fncls__7d } else { tmp17 = fncls__7 }; ___18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O(); var cl__19 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_29.GetRawRoot__O()).Invoke_O_O__O(cf__17, A_arbace_j2g_zlib_A_const_50); var cc__20 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_30.GetRawRoot__O()).Invoke_O__O(cl__19); var hclen__21 int64; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_39.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(cl__19); var tmp20 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class; if




























	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class = fncls__11d; tmp20 = fncls__11d } else { tmp20 = fncls__11 }; hclen__21 = lang.Numbers_Max_J_J__J(4, lang.Numbers_Minus_J_J__J(19, int64(lang.RT_Count_O__I(tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_52.GetRawRoot__O())))))); var tmp21 lang.IFn =
	lang.IFn_Cast(w__0); var tmp22 any; if jrt.J2g_Truth(last_QMARK___4) { tmp22 = A_arbace_j2g_zlib_A_const_53 } else { tmp22 = A_arbace_j2g_zlib_A_const_17 }; tmp21.Invoke_O_O__O(tmp22, A_arbace_j2g_zlib_A_const_53);
	lang.IFn_Cast(w__0).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_54, A_arbace_j2g_zlib_A_const_54);
	lang.IFn_Cast(w__0).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(hlit__14, 257), A_arbace_j2g_zlib_A_const_55);
	lang.IFn_Cast(w__0).Invoke_O_O__O(lang.Numbers_Minus_O_J__Number(hdist__15, 1), A_arbace_j2g_zlib_A_const_55);
	lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(hclen__21, 4)).Ref(), A_arbace_j2g_zlib_A_const_56); var seq_1931000065__22 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_49.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(hclen__21).Ref(), A_arbace_j2g_zlib_A_const_52.GetRawRoot__O())); var chunk_1931000066__23 any; var count_1931000067__24 int64 = 0; var i_1931000068__25 int64 = 0; L2: for {


































		if lang.Numbers_Lt_J_J__Z(i_1931000068__25, count_1931000067__24) { var s__26 any = lang.Indexed_Cast(chunk_1931000066__23).Nth_I__O(lang.RT_IntCast_J__I(i_1931000068__25)); lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__26)))).Ref(), A_arbace_j2g_zlib_A_const_57); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, lang.Numbers_Unchecked_inc_J__J(i_1931000068__25); continue L2 } else { var temp__1927000414__auto____26 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000065__22); if jrt.J2g_Truth(temp__1927000414__auto____26) { var seq_1931000065__27 any = temp__1927000414__auto____26; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27)) { var c__1927000678__auto____28 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27), c__1927000678__auto____28, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var s__28 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27); lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__28)))).Ref(), A_arbace_j2g_zlib_A_const_57); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27), nil, 0, 0; continue L2 } } }
//line :219:1
		break L2 }; var seq_1931000069__22 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(rle__16); var chunk_1931000070__23 any; var count_1931000071__24 int64 = 0; var i_1931000072__25 int64 = 0; L3: for {



































			if lang.Numbers_Lt_J_J__Z(i_1931000072__25, count_1931000071__24) { var vec__1931000073__26 any = lang.Indexed_Cast(chunk_1931000070__23).Nth_I__O(lang.RT_IntCast_J__I(i_1931000072__25)); var s__27 any = lang.RT_Nth_O_I_O__O(vec__1931000073__26, lang.RT_IntCast_J__I(0), nil); var x__28 any = lang.RT_Nth_O_I_O__O(vec__1931000073__26, lang.RT_IntCast_J__I(1), nil)
				lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__27)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__27)))).Ref())
//line :255:1
				var G__1931000076__29_ int32 = lang.RT_IntCast_O__I(s__27)

			L4: switch { default: switch G__1931000076__29_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_54); break L4; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_57); break L4; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_50); break L4; default:}}
//line :255:1
				seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, lang.Numbers_Unchecked_inc_J__J(i_1931000072__25); continue L3 } else { var temp__1927000414__auto____26_2 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000069__22); if jrt.J2g_Truth(temp__1927000414__auto____26_2) { var seq_1931000069__27 any = temp__1927000414__auto____26_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27)) { var c__1927000678__auto____28_2 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27); seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27), c__1927000678__auto____28_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____28_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__1931000077__28 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27); var s__29 any = lang.RT_Nth_O_I_O__O(vec__1931000077__28, lang.RT_IntCast_J__I(0), nil); var x__30 any = lang.RT_Nth_O_I_O__O(vec__1931000077__28, lang.RT_IntCast_J__I(1), nil)
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__29)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__29)))).Ref())
//line :255:1
					var G__1931000080__31_ int32 = lang.RT_IntCast_O__I(s__29)

				L5: switch { default: switch G__1931000080__31_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_54); break L5; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_57); break L5; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_50); break L5; default:}}
//line :255:1
					seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27), nil, 0, 0; continue L3 } } }
//line :219:1
			break L3 }; var i__22 int64 = from__6; L6: for {







































				if lang.Numbers_Lt_J_J__Z(i__22, to__7) { var s__23 int64 = lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(i__22)))

					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_41.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(s__23).Ref(), A_arbace_j2g_zlib_A_const_43)) { var len__24 int64 = lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_J_J__J(s__23, 16), 65535); var d__25 int64 = lang.Numbers_And_J_J__J(s__23, 65535); var lcode__26 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Long_ValueOf_J__Long(len__24).Ref()); var dcode__27 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Long_ValueOf_J__Long(d__25).Ref())


						lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(257, lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lang.Numbers_Add_J_O__Number(257, lcode__26)))).Ref())
						if lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_59.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lcode__26))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(len__24, lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_59.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(lcode__26))).Ref()) }
						lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](dc__13, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](dl__11, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))).Ref())
						if lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_58.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(d__25, lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_58.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I(dcode__27))).Ref()) } } else {
							lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__23)))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I(lang.RT_IntCast_J__I(s__23)))).Ref()) }
					i__22 = lang.Numbers_Inc_J__J(i__22); continue L6 }
//line :219:1
				break L6 }; return /*line :270:1*/ lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(256))).Ref(), jrt.Long_ValueOf_J__Long(lang.RT_Aget_J1_I__J(jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I(256))).Ref()) }
//line :234:1
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Ctor_O(c__df any) { t.F_df = c__df }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Invoke_O_O__O(self, p1__1931000041_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_df, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__1931000041_SHARP___1))))).Ref() }






func A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Ctor_O(c__ll any) { t.F_ll = c__ll }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Invoke_O_O__O(self, p1__1931000042_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_ll, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__1931000042_SHARP___1))))).Ref() }
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Ctor_O(c__dl any) { t.F_dl = c__dl }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Invoke_O_O__O(self, p1__1931000043_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_dl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__1931000043_SHARP___1))))).Ref() }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(p0, p1 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Ctor_O_O(c__cf, c__rle any) { t.F_cf = c__cf; t.F_rle = c__rle }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Invoke_O__O(self any) any { { var seq_1931000051__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_rle; t.F_rle = nil; tmp2 = t_; seq_1931000051__1 = tmp1.Invoke_O__O(tmp2); var chunk_1931000052__2 any; var count_1931000053__3 int64 = 0; var i_1931000054__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z(i_1931000054__4, count_1931000053__3) { var vec__1931000056__5 any = lang.Indexed_Cast(chunk_1931000052__2).Nth_I__O(lang.RT_IntCast_J__I(i_1931000054__4)); var s__6 any = lang.RT_Nth_O_I_O__O(vec__1931000056__5, lang.RT_IntCast_J__I(0), nil); var tmp3 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp4 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp3, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__6)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(tmp4, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__6)))))); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, lang.Numbers_Unchecked_inc_J__J(i_1931000054__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000051__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1931000051__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1931000059__7 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6); var s__8 any = lang.RT_Nth_O_I_O__O(vec__1931000059__7, lang.RT_IntCast_J__I(0), nil); var tmp5 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp6 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long(lang.RT_Aset_J1_I_J__J(tmp5, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__8)), lang.Numbers_Inc_J__J(lang.RT_Aget_J1_I__J(tmp6, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(s__8)))))); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Invoke_O_O__O(self, p1__1931000044_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.RT_Aget_J1_I__J(tmp1, lang.RT_IntCast_I__I(lang.RT_IntCast_O__I(p1__1931000044_SHARP___1))))).Ref() }























func A_arbace_j2g_zlib_adler32_A_New() *A_arbace_j2g_zlib_adler32_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_adler32_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Ctor() {}
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Invoke_O_O__O(self, b__0 any) any { var tmp1 int64; var i__2 int64 = 0; var a__3 int64 = 1; var s__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z(i__2, int64(lang.RT_Alength_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var a__5 int64 = lang.Numbers_Remainder_J_J__J(lang.Numbers_Add_J_J__J(a__3, lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(jrt.Byte_ValueOf_B__Byte(lang.RT_Aget_B1_I__B(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(i__2))).Ref()), 255)), 65521)

		i__2, a__3, s__4 = lang.Numbers_Inc_J__J(i__2), a__5, lang.Numbers_Remainder_J_J__J(lang.Numbers_Add_J_J__J(s__4, a__5), 65521); continue L1 } else {
			tmp1 = lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(s__4, 16), a__3) }
//line :272:1
	break L1 }; return jrt.Long_ValueOf_J__Long(tmp1).Ref() }






func A_arbace_j2g_zlib_deflate_A_New() *A_arbace_j2g_zlib_deflate_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_deflate_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Invoke_O_O__O(self, b__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var w__3 any = A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__2, 0, 0); var vec__1931000083__4 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_60.GetRawRoot__O()).Invoke_O__O(b__0); var syms__5 any = lang.RT_Nth_O_I_O__O(vec__1931000083__4, lang.RT_IntCast_J__I(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O(vec__1931000083__4, lang.RT_IntCast_J__I(1), nil); var k__7 int64 = lang.RT_LongCast_O__J(k__6);








	jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(120)); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(218)); if
	lang.Numbers_IsZero_J__Z(k__7) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_61.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_zlib_A_const_17; var tmp3 any = A_arbace_j2g_zlib_A_const_17; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; tmp1.Invoke_O_O_O_O_O__O(w__3, syms__5, tmp2, tmp3, tmp4.Ref()) } else {
//line :289:1
			var from__8 int64 = 0; L1: for { var to__9 int64 = lang.Numbers_Min_J_J__J(k__7, lang.Numbers_Add_J_J__J(from__8, 16384))



				lang.IFn_Cast(A_arbace_j2g_zlib_A_const_61.GetRawRoot__O()).Invoke_O_O_O_O_O__O(w__3, syms__5, jrt.Long_ValueOf_J__Long(from__8).Ref(), jrt.Long_ValueOf_J__Long(to__9).Ref(), jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(to__9, k__7)).Ref())
				if lang.Numbers_Lt_J_J__Z(to__9, k__7) { from__8 = to__9; continue L1 }
//line :289:1
				break L1 } };





	lang.IFn_Cast(w__3).Invoke__O(); var a__8 any = /*line :279:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_62.GetRawRoot__O()).Invoke_O__O(b__0); var seq_1931000086__9 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_63); var chunk_1931000087__10 any; var count_1931000088__11 int64 = 0; var i_1931000089__12 int64 = 0; L2: for {

















		if lang.Numbers_Lt_J_J__Z(i_1931000089__12, count_1931000088__11) { var sh__13 any = lang.Indexed_Cast(chunk_1931000087__10).Nth_I__O(lang.RT_IntCast_J__I(i_1931000089__12)); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_O_O__J(a__8, sh__13), 255))); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, lang.Numbers_Unchecked_inc_J__J(i_1931000089__12); continue L2 } else { var temp__1927000414__auto____13 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000086__9); if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1931000086__14 any = temp__1927000414__auto____13; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14)) { var c__1927000678__auto____15 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var sh__15 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I(lang.Numbers_And_J_J__J(lang.Numbers_ShiftRight_O_O__J(a__8, sh__15), 255))); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14), nil, 0, 0; continue L2 } } }
//line :279:1
		break L2 }; return /*line :298:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).ToByteArray__B1().Ref() }
//line :287:1
type A_arbace_j2g_zlib_A struct{ jrt.Object }

var A_arbace_j2g_zlib_A_const_pool *jrt.RefArray

var A_arbace_j2g_zlib_A_const_0 *lang.Var

var A_arbace_j2g_zlib_A_const_1 any

var A_arbace_j2g_zlib_A_const_2 *lang.Var

var A_arbace_j2g_zlib_A_const_3 *lang.Var

var A_arbace_j2g_zlib_A_const_4 *lang.Var

var A_arbace_j2g_zlib_A_const_5 any

var A_arbace_j2g_zlib_A_const_6 *lang.Var

var A_arbace_j2g_zlib_A_const_7 *lang.Var

var A_arbace_j2g_zlib_A_const_8 *lang.Var

var A_arbace_j2g_zlib_A_const_9 *lang.Keyword

var A_arbace_j2g_zlib_A_const_10 *lang.Var

var A_arbace_j2g_zlib_A_const_11 *lang.Var

var A_arbace_j2g_zlib_A_const_12 *lang.Var

var A_arbace_j2g_zlib_A_const_13 *lang.Var

var A_arbace_j2g_zlib_A_const_14 *lang.Var

var A_arbace_j2g_zlib_A_const_15 *lang.Var

var A_arbace_j2g_zlib_A_const_16 *lang.Var

var A_arbace_j2g_zlib_A_const_17 any

var A_arbace_j2g_zlib_A_const_18 any

var A_arbace_j2g_zlib_A_const_19 *lang.Var

var A_arbace_j2g_zlib_A_const_20 *lang.Var

var A_arbace_j2g_zlib_A_const_21 any

var A_arbace_j2g_zlib_A_const_22 *lang.Var

var A_arbace_j2g_zlib_A_const_23 *lang.Var

var A_arbace_j2g_zlib_A_const_24 *lang.Var

var A_arbace_j2g_zlib_A_const_25 any

var A_arbace_j2g_zlib_A_const_26 any

var A_arbace_j2g_zlib_A_const_27 any

var A_arbace_j2g_zlib_A_const_28 any

var A_arbace_j2g_zlib_A_const_29 *lang.Var

var A_arbace_j2g_zlib_A_const_30 *lang.Var

var A_arbace_j2g_zlib_A_const_31 *lang.Var

var A_arbace_j2g_zlib_A_const_32 *lang.Var

var A_arbace_j2g_zlib_A_const_33 any

var A_arbace_j2g_zlib_A_const_34 *lang.Var

var A_arbace_j2g_zlib_A_const_35 *lang.Var

var A_arbace_j2g_zlib_A_const_36 *lang.Var

var A_arbace_j2g_zlib_A_const_37 *lang.Var

var A_arbace_j2g_zlib_A_const_38 *lang.Var

var A_arbace_j2g_zlib_A_const_39 *lang.Var

var A_arbace_j2g_zlib_A_const_40 *lang.Var

var A_arbace_j2g_zlib_A_const_41 *lang.Var

var A_arbace_j2g_zlib_A_const_42 *lang.Var

var A_arbace_j2g_zlib_A_const_43 any

var A_arbace_j2g_zlib_A_const_44 *lang.Var

var A_arbace_j2g_zlib_A_const_45 *lang.Var

var A_arbace_j2g_zlib_A_const_46 any

var A_arbace_j2g_zlib_A_const_47 any

var A_arbace_j2g_zlib_A_const_48 *lang.Var

var A_arbace_j2g_zlib_A_const_49 *lang.Var

var A_arbace_j2g_zlib_A_const_50 any

var A_arbace_j2g_zlib_A_const_51 *lang.Var

var A_arbace_j2g_zlib_A_const_52 *lang.Var

var A_arbace_j2g_zlib_A_const_53 any

var A_arbace_j2g_zlib_A_const_54 any

var A_arbace_j2g_zlib_A_const_55 any

var A_arbace_j2g_zlib_A_const_56 any

var A_arbace_j2g_zlib_A_const_57 any

var A_arbace_j2g_zlib_A_const_58 *lang.Var

var A_arbace_j2g_zlib_A_const_59 *lang.Var

var A_arbace_j2g_zlib_A_const_60 *lang.Var

var A_arbace_j2g_zlib_A_const_61 *lang.Var

var A_arbace_j2g_zlib_A_const_62 *lang.Var

var A_arbace_j2g_zlib_A_const_63 any

var A_arbace_j2g_zlib_A_init jrt.ClassInit

func A_arbace_j2g_zlib_A_Init() { if !A_arbace_j2g_zlib_A_init.Done() { A_arbace_j2g_zlib_A_init.Run(A_arbace_j2g_zlib_A_clinit) } }

func A_arbace_j2g_zlib_A_clinit() { A_arbace_j2g_zlib_A_clinit_p0(); A_arbace_j2g_zlib_A_clinit_p1(); A_arbace_j2g_zlib_A_clinit_p2(); A_arbace_j2g_zlib_A_clinit_p3(); A_arbace_j2g_zlib_A_clinit_p4(); A_arbace_j2g_zlib_A_clinit_p5() }

func A_arbace_j2g_zlib_A_clinit_p0() { A_arbace_j2g_zlib_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 67); A_arbace_j2g_zlib_A_const_0 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[3]); A_arbace_j2g_zlib_A_const_1 = A_arbace_j2g_zlib_A_const_pool.A[4]; A_arbace_j2g_zlib_A_const_2 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[5]); A_arbace_j2g_zlib_A_const_3 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[6]); A_arbace_j2g_zlib_A_const_4 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[7]); A_arbace_j2g_zlib_A_const_5 = A_arbace_j2g_zlib_A_const_pool.A[8]; A_arbace_j2g_zlib_A_const_6 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[9]); A_arbace_j2g_zlib_A_const_7 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[10]); A_arbace_j2g_zlib_A_const_8 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[11]); A_arbace_j2g_zlib_A_const_9 = lang.Keyword_Cast(A_arbace_j2g_zlib_A_const_pool.A[12]); A_arbace_j2g_zlib_A_const_10 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[13]); A_arbace_j2g_zlib_A_const_11 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[14]) }

func A_arbace_j2g_zlib_A_clinit_p1() { A_arbace_j2g_zlib_A_const_12 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[15]); A_arbace_j2g_zlib_A_const_13 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[16]); A_arbace_j2g_zlib_A_const_14 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[17]); A_arbace_j2g_zlib_A_const_15 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[18]); A_arbace_j2g_zlib_A_const_16 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[19]); A_arbace_j2g_zlib_A_const_17 = A_arbace_j2g_zlib_A_const_pool.A[20]; A_arbace_j2g_zlib_A_const_18 = A_arbace_j2g_zlib_A_const_pool.A[21]; A_arbace_j2g_zlib_A_const_19 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[22]); A_arbace_j2g_zlib_A_const_20 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[23]); A_arbace_j2g_zlib_A_const_21 = A_arbace_j2g_zlib_A_const_pool.A[24]; A_arbace_j2g_zlib_A_const_22 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[25]); A_arbace_j2g_zlib_A_const_23 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[26]) }

func A_arbace_j2g_zlib_A_clinit_p2() { A_arbace_j2g_zlib_A_const_24 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[27]); A_arbace_j2g_zlib_A_const_25 = A_arbace_j2g_zlib_A_const_pool.A[28]; A_arbace_j2g_zlib_A_const_26 = A_arbace_j2g_zlib_A_const_pool.A[29]; A_arbace_j2g_zlib_A_const_27 = A_arbace_j2g_zlib_A_const_pool.A[30]; A_arbace_j2g_zlib_A_const_28 = A_arbace_j2g_zlib_A_const_pool.A[31]; A_arbace_j2g_zlib_A_const_29 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[32]); A_arbace_j2g_zlib_A_const_30 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[33]); A_arbace_j2g_zlib_A_const_31 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[34]); A_arbace_j2g_zlib_A_const_32 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[35]); A_arbace_j2g_zlib_A_const_33 = A_arbace_j2g_zlib_A_const_pool.A[36]; A_arbace_j2g_zlib_A_const_34 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[37]); A_arbace_j2g_zlib_A_const_35 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[38]); A_arbace_j2g_zlib_A_const_36 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[39]) }

func A_arbace_j2g_zlib_A_clinit_p3() { A_arbace_j2g_zlib_A_const_37 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[40]); A_arbace_j2g_zlib_A_const_38 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[41]); A_arbace_j2g_zlib_A_const_39 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[42]); A_arbace_j2g_zlib_A_const_40 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[43]); A_arbace_j2g_zlib_A_const_41 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[44]); A_arbace_j2g_zlib_A_const_42 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[45]); A_arbace_j2g_zlib_A_const_43 = A_arbace_j2g_zlib_A_const_pool.A[46]; A_arbace_j2g_zlib_A_const_44 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[47]); A_arbace_j2g_zlib_A_const_45 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[48]); A_arbace_j2g_zlib_A_const_46 = A_arbace_j2g_zlib_A_const_pool.A[49]; A_arbace_j2g_zlib_A_const_47 = A_arbace_j2g_zlib_A_const_pool.A[50]; A_arbace_j2g_zlib_A_const_48 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[51]) }

func A_arbace_j2g_zlib_A_clinit_p4() { A_arbace_j2g_zlib_A_const_49 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[52]); A_arbace_j2g_zlib_A_const_50 = A_arbace_j2g_zlib_A_const_pool.A[53]; A_arbace_j2g_zlib_A_const_51 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[54]); A_arbace_j2g_zlib_A_const_52 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[55]); A_arbace_j2g_zlib_A_const_53 = A_arbace_j2g_zlib_A_const_pool.A[56]; A_arbace_j2g_zlib_A_const_54 = A_arbace_j2g_zlib_A_const_pool.A[57]; A_arbace_j2g_zlib_A_const_55 = A_arbace_j2g_zlib_A_const_pool.A[58]; A_arbace_j2g_zlib_A_const_56 = A_arbace_j2g_zlib_A_const_pool.A[59]; A_arbace_j2g_zlib_A_const_57 = A_arbace_j2g_zlib_A_const_pool.A[60]; A_arbace_j2g_zlib_A_const_58 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[61]); A_arbace_j2g_zlib_A_const_59 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[62]); A_arbace_j2g_zlib_A_const_60 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[63]); A_arbace_j2g_zlib_A_const_61 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[64]) }

func A_arbace_j2g_zlib_A_clinit_p5() { A_arbace_j2g_zlib_A_const_62 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[65]); A_arbace_j2g_zlib_A_const_63 = A_arbace_j2g_zlib_A_const_pool.A[66] }

func A_arbace_j2g_zlib_A_New() *A_arbace_j2g_zlib_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_A) Ctor() {}

func (t *A_arbace_j2g_zlib_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_A_class }

func (t *A_arbace_j2g_zlib_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_A); return ok }

func A_arbace_j2g_zlib_A_Cast(x any) *A_arbace_j2g_zlib_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_A_class)) }; return v }



type A_arbace_j2g_zlib_adler32_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_adler32_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_canonical_codes_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_canonical_codes_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_code_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_code_of_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_deflate_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_deflate_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000004_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000004_A_New() *A_arbace_j2g_zlib_eval1931000004_A { t := &A_arbace_j2g_zlib_eval1931000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000004_A_class }

func (t *A_arbace_j2g_zlib_eval1931000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); return ok }

func A_arbace_j2g_zlib_eval1931000004_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000004_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000008_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000008_A_New() *A_arbace_j2g_zlib_eval1931000008_A { t := &A_arbace_j2g_zlib_eval1931000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000008_A_class }

func (t *A_arbace_j2g_zlib_eval1931000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); return ok }

func A_arbace_j2g_zlib_eval1931000008_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000008_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000012_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000012_A_New() *A_arbace_j2g_zlib_eval1931000012_A { t := &A_arbace_j2g_zlib_eval1931000012_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000012_A_class }

func (t *A_arbace_j2g_zlib_eval1931000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); return ok }

func A_arbace_j2g_zlib_eval1931000012_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000012_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_huffman_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A struct{ j2g_header uint64; F_parent any; F_n int32; F_start any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A struct{ j2g_header uint64; F_parent, F_lens any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A struct{ j2g_header uint64; F_parent, F_s any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_insert_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_insert_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_longest_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_longest_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_lz77_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_lz77_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_match_length_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_match_length_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_reverse_bits_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_reverse_bits_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_rle_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A struct{ j2g_header uint64; F_i any; F_n int32; F_x int64; F_v any }

var A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_write_block_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A struct{ j2g_header uint64; F_df any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A struct{ j2g_header uint64; F_ll any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A struct{ j2g_header uint64; F_dl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A struct{ j2g_header uint64; F_cf, F_rle any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A struct{ j2g_header uint64; F_cl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class *jrt.Class
