//line aot_arbace_j2g_zlib.ae:1
package aot_arbace_j2g_zlib

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_New() *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_zlib_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_New() *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_j2g_zlib_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_j2g_zlib_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(), A_arbace_j2g_zlib_A_const_6) }

















func A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_New() *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Invoke_O_O_O_O__O(self, out__1, acc__2, n__3 any) any { return A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__1, lang.RT_LongCast_O__J_NoInit(acc__2), lang.RT_LongCast_O__J_NoInit(n__3)) }



















func A_arbace_j2g_zlib_reverse_bits_A_New() *A_arbace_j2g_zlib_reverse_bits_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_reverse_bits_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) InvokePrim_O_J_J__J(self any, code__0, len__1 int64) int64 { { var c__3 int64 = code__0; var r__4 int64 = 0; var i__5 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, len__1) { c__3, r__4, i__5 = lang.Numbers_ShiftRight_J_J__J_NoInit(c__3, 1), lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(r__4, 1), lang.Numbers_And_J_J__J_NoInit(c__3, 1)), lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else { return r__4 } } }; /*line :39:1*/panic("j2g: unreachable") }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Invoke_O_O_O__O(self, p_code__0, p_len__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_code__0), lang.RT_LongCast_O__J_NoInit(p_len__1))).Ref() }






func A_arbace_j2g_zlib_huffman_lengths_A_New() *A_arbace_j2g_zlib_huffman_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Ctor() {}
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) InvokePrim_O_O_J__O(self, freqs__0 any, limit__1 int64) any { { var n__3 int32 = lang.RT_Alength_J1__I_NoInit(jrt.LongArray_Cast(freqs__0)); var fs__4 any = lang.RT_Aclone_J1__J1_NoInit(jrt.LongArray_Cast(freqs__0)).Ref(); L1: for { var syms__5 any; var root_15 any = A_arbace_j2g_zlib_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_17 lang.IFn






	if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var fnbody__21 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(fs__4); var tmp1 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__21); A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class = fncls__20d; tmp1 = fncls__20d } else { tmp1 = fncls__20 }; arg_18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__21, tmp1, nil); var arg_19 any; var root_22 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_23 == nil { arg_19 = ifn_24.Invoke_O__O(arg_25) } else { arg_19 = linked_23.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_22, arg_25) }; if linked_16 == nil { syms__5 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { syms__5 = linked_16.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }
//line :46:1
	var lens__6 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var tmp2 any; var root_26 any = A_arbace_j2g_zlib_A_const_9.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_28 lang.IFn









	if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = syms__5; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_26, arg_29) }
//line :55:1
	if jrt.J2g_Truth(tmp2) { return lens__6 } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(syms__5))) {

		var tmp3 *jrt.LongArray = jrt.LongArray_Cast(lens__6); var tmp4 any; var root_85 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = syms__5; if linked_86 == nil { tmp4 = ifn_87.Invoke_O__O(arg_88) } else { tmp4 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp3, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(tmp4)), 1))
//line :55:1
		return lens__6 } else { if A_arbace_j2g_zlib_A_const_10 != nil { var parent__7 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, int64(n__3))).Ref()).Ref(); var start__8 any; var root_30 any = A_arbace_j2g_zlib_A_const_11.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_32 lang.IFn






			if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_12.GetRawRoot__O()).Invoke__O(); var arg_34 any; var root_38 any = A_arbace_j2g_zlib_A_const_13.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var fnbody__44 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(fs__4); var tmp5 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__44); A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class = fncls__43d; tmp5 = fncls__43d } else { tmp5 = fncls__43 }; arg_41 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp5, nil); var arg_42 any = syms__5; if linked_39 == nil { arg_34 = ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { arg_34 = linked_39.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_38, arg_41, arg_42) }; if linked_31 == nil { start__8 = ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { start__8 = linked_31.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) }
//line :55:1
			var ___9 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__69 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(parent__7, n__3, start__8); var tmp7 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class; _ = ___9







			if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__69); A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class = fncls__68d; tmp7 = fncls__68d } else { tmp7 = fncls__68 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp7, nil); ___9 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :55:1
			var root__10 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(n__3), lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(syms__5)))), -1); var maxlen__11 any; var root_70 any = A_arbace_j2g_zlib_A_const_16.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_72 lang.IFn















			if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var fnbody__79 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(parent__7, lens__6, root__10); var tmp8 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__79); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class = fncls__78d; tmp8 = fncls__78d } else { tmp8 = fncls__78 }; arg_73 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp8, nil); var arg_74 any = A_arbace_j2g_zlib_A_const_17; var arg_75 any = syms__5; if linked_71 == nil { maxlen__11 = ifn_72.Invoke_O_O_O__O(arg_73, arg_74, arg_75) } else { maxlen__11 = linked_71.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_70, arg_73, arg_74, arg_75)
			}



			var tmp9 bool; var na_80 any = maxlen__11; var na_81 int64 = limit__1; if jrt.Long_InstanceOf(na_80) { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_80)).LongValue__J(); var n1_83 int64 = na_81; tmp9 = n0_82 <= n1_83 } else { tmp9 = lang.Numbers_Lte_O_J__Z_NoInit(na_80, na_81) }; if tmp9 { return lens__6 } else { var f2__12 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J_NoInit(n__3); var i__14 int64 = 0; L2: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i__14, n__1927000701__auto____13) { var f__15 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(fs__4), lang.RT_IntCast_J__I_NoInit(i__14))
					if lang.Numbers_IsPos_J__Z_NoInit(f__15) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(f2__12), lang.RT_IntCast_J__I_NoInit(i__14), lang.Numbers_Max_J_J__J_NoInit(1, lang.Numbers_ShiftRight_J_J__J_NoInit(f__15, 1)))) }
//line :79:1
					i__14 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__14); continue L2 }
//line :76:1
				break L2
			}



				fs__4 = f2__12; continue L1 } } else {
//line :55:1
					return nil } } } } }; /*line :46:1*/panic("j2g: unreachable") }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Invoke_O_O_O__O(self, freqs__0, p_limit__1 any) any { return t.InvokePrim_O_O_J__O(self, freqs__0, lang.RT_LongCast_O__J_NoInit(p_limit__1)) }






func A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Invoke_O_O__O(self, p1__1931000018_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_fs); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000018_SHARP___1))))).Ref() }








func A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_fs); return lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__1)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref()) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Ctor_O_I_O(c__parent any, c__n int32, c__start any) { t.F_parent = c__parent; t.F_n = c__n; t.F_start = c__start }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Invoke_O__O(self any) any { { var q__1 any; var t_ any = t.F_start; t.F_start = nil; q__1 = t_; var next_id__2 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); var order__3 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); L1: for {
											if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(q__1)), 1) { var a__4 any; var root_45 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_47 lang.IFn
												if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = q__1; if linked_46 == nil { a__4 = ifn_47.Invoke_O__O(arg_48) } else { a__4 = linked_46.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_45, arg_48) }
//line :64:1
		var q__5 any; var root_49 any = A_arbace_j2g_zlib_A_const_15.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_51 lang.IFn
		if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = q__1; var arg_53 any = a__4; if linked_50 == nil { q__5 = ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { q__5 = linked_50.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }
//line :64:1
		var b__6 any; var root_54 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_56 lang.IFn
		if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = q__5; if linked_55 == nil { b__6 = ifn_56.Invoke_O__O(arg_57) } else { b__6 = linked_55.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_54, arg_57) }
//line :64:1
		var q__7 any; var root_58 any = A_arbace_j2g_zlib_A_const_15.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_60 lang.IFn
		if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = q__5; var arg_62 any = b__6; if linked_59 == nil { q__7 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { q__7 = linked_59.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }
		var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_parent); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		var tmp2 *jrt.LongArray = jrt.LongArray_Cast(t.F_parent); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		var tmp3 any; var root_63 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = q__7; var arg_67 any = lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(0))), lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(0))))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(order__3).Ref(), jrt.Long_ValueOf_J__Long_NoInit(next_id__2).Ref()); if linked_64 == nil { tmp3 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { tmp3 = linked_64.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; q__1, next_id__2, order__3 = tmp3, lang.Numbers_Inc_J__J_NoInit(next_id__2), lang.Numbers_Inc_J__J_NoInit(order__3); continue L1 } else {
//line :64:1
			return nil } } }; /*line :63:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Ctor_O_O_J(c__parent, c__lens any, c__root int64) { t.F_parent = c__parent; t.F_lens = c__lens; t.F_root = c__root }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) InvokePrim_O_J_O__O(self any, m__1 int64, s__2 any) any { var d__3 int64; var tmp1 *lang.Compiler_AOTFn; var fnbody__77 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(t.F_parent, s__2, t.F_root); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class; if
															fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__77); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__77, tmp2, nil); d__3 = lang.RT_LongCast_O__J_NoInit(Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()); var tmp3 /*line :73:1*/*jrt.LongArray = jrt.LongArray_Cast(t.F_lens); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp3, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__2)), d__3)); return /*line :74:1*/ jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(m__1, d__3)).Ref() }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Invoke_O_O_O__O(self, p_m__1, s__2 any) any { return t.InvokePrim_O_J_O__O(self, lang.RT_LongCast_O__J_NoInit(p_m__1), s__2) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Ctor_O_O_J(c__parent, c__s any, c__root int64) { t.F_parent = c__parent; t.F_s = c__s; t.F_root = c__root }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Invoke_O__O(self any) any { { var x__1 int64; var tmp1 any; var t_ any = t.F_s; t.F_s = nil; tmp1 = t_; x__1 = lang.RT_LongCast_O__J_NoInit(tmp1); var d__2 int64 = 0; L1: for { if lang.Numbers_Equiv_J_J__Z_NoInit(x__1, t.F_root) { return jrt.Long_ValueOf_J__Long_NoInit(d__2).Ref() } else { var tmp2 *jrt.LongArray = jrt.LongArray_Cast(t.F_parent); x__1, d__2 = lang.RT_Aget_J1_I__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(x__1))), lang.Numbers_Inc_J__J_NoInit(d__2); continue L1 } } }; panic("j2g: unreachable") }










func A_arbace_j2g_zlib_canonical_codes_A_New() *A_arbace_j2g_zlib_canonical_codes_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_canonical_codes_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Invoke_O_O__O(self, lens__0 any) any { var n__2 int32 = lang.RT_Alength_J1__I_NoInit(jrt.LongArray_Cast(lens__0)); var bl_count__3 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var next_code__4 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var codes__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref()).Ref(); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7 int64 = 0; L1: for {







	if lang.Numbers_Lt_J_J__Z_NoInit(i__7, n__1927000701__auto____6) { var l__8 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lens__0), lang.RT_IntCast_J__I_NoInit(i__7)); if lang.Numbers_IsPos_J__Z_NoInit(l__8) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(bl_count__3), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(bl_count__3), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)))))) }; i__7 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7); continue L1 }
//line :83:1
	break L1 }; var bits__6 int64 = 1; var code__7 int64 = 0; L2: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(bits__6, 16) { var code__8 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(code__7, lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(bl_count__3), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(bits__6)))), 1)

			jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_J__I_NoInit(bits__6), code__8))
			bits__6, code__7 = lang.Numbers_Inc_J__J_NoInit(bits__6), code__8; continue L2 }
//line :83:1
		break L2 }; var n__1927000701__auto____6_2 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7_2 int64 = 0; L3: for {













			if lang.Numbers_Lt_J_J__Z_NoInit(i__7_2, n__1927000701__auto____6_2) { var l__8_2 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lens__0), lang.RT_IntCast_J__I_NoInit(i__7_2))

				if lang.Numbers_IsPos_J__Z_NoInit(l__8_2) {
					var tmp1 *jrt.LongArray = jrt.LongArray_Cast(codes__5); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__7_2); var tmp3 int64; var root_89 any = A_arbace_j2g_zlib_A_const_19.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_89, A_arbace_j2g_zlib_reverse_bits_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2))); var arg_93 int64 = l__8_2; if linked_90 == nil { tmp3 = lang.RT_LongCast_O__J_NoInit(ifn_91.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_92).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_93).Ref())) } else { tmp3 = linked_90.(*A_arbace_j2g_zlib_reverse_bits_A).InvokePrim_O_J_J__J(root_89, arg_92, arg_93) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, tmp2, lang.RT_LongCast_J__J_NoInit(tmp3)))
					jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)))))) }
//line :97:1
				i__7_2 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7_2); continue L3 }
//line :83:1
			break L3 }; return codes__5 }





























func A_arbace_j2g_zlib_code_of_A_New() *A_arbace_j2g_zlib_code_of_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_code_of_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) InvokePrim_O_O_J__J(self, bases__0 any, v__1 int64) int64 { { var i__3 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Alength_J1__I_NoInit(jrt.LongArray_Cast(bases__0)))); L1: for {


	if lang.Numbers_Gt_J_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(bases__0), lang.RT_IntCast_J__I_NoInit(i__3)), v__1) { i__3 = lang.Numbers_Dec_J__J_NoInit(i__3); continue L1 } else { return i__3 } } }; /*line :113:1*/panic("j2g: unreachable") }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Invoke_O_O_O__O(self, bases__0, p_v__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_J__J(self, bases__0, lang.RT_LongCast_O__J_NoInit(p_v__1))).Ref() }













func A_arbace_j2g_zlib_match_length_A_New() *A_arbace_j2g_zlib_match_length_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_match_length_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) InvokePrim_O_O_J_J_J__J(self, b__0 any, i__1, j__2, max__3 int64) int64 { { var k__5 int64 = 0; L1: for {


	var tmp1 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lt_J_J__Z_NoInit(k__5, max__3); if and__1927000168__auto____6 { tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__1, k__5)))).Ref()), lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(j__2, k__5)))).Ref())) } else { tmp1 = and__1927000168__auto____6 }; if tmp1 { k__5 = lang.Numbers_Inc_J__J_NoInit(k__5); continue L1 } else { return k__5 } } }; /*line :127:1*/panic("j2g: unreachable") }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Invoke_O_O_O_O_O__O(self, b__0, p_i__1, p_j__2, p_max__3 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_J_J_J__J(self, b__0, lang.RT_LongCast_O__J_NoInit(p_i__1), lang.RT_LongCast_O__J_NoInit(p_j__2), lang.RT_LongCast_O__J_NoInit(p_max__3))).Ref() }




func A_arbace_j2g_zlib_insert_BANG__A_New() *A_arbace_j2g_zlib_insert_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_insert_BANG__A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) InvokePrim_O_O_O_O_J__O(self, b__0, head__1, prev__2 any, i__3 int64) any {



	if lang.Numbers_Lte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 3), int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0)))) { var h__5 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__3))).Ref()), 255), 8), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 1)))).Ref()), 255), 4)), lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255)), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255), 11)), 65535)





		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.IntArray_Cast(prev__2), lang.RT_IntCast_J__I_NoInit(i__3), lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(head__1), lang.RT_IntCast_J__I_NoInit(h__5))))
		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.IntArray_Cast(head__1), lang.RT_IntCast_J__I_NoInit(h__5), lang.RT_IntCast_J__I_NoInit(i__3))) }
//line :132:1
	return nil }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Invoke_O_O_O_O_O__O(self, b__0, head__1, prev__2, p_i__3 any) any { return t.InvokePrim_O_O_O_O_J__O(self, b__0, head__1, prev__2, lang.RT_LongCast_O__J_NoInit(p_i__3)) }













func A_arbace_j2g_zlib_longest_A_New() *A_arbace_j2g_zlib_longest_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_longest_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) InvokePrim_O_O_O_J__J(self, b__0, prev__1 any, i__2 int64) int64 { { var n__4 int32 = lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0))




	if lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__2, 3), int64(n__4)) { return 0 } else { var maxl__5 int64 = lang.Numbers_Min_J_J__J_NoInit(258, lang.Numbers_Minus_J_J__J_NoInit(int64(n__4), i__2)); var j__6 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(prev__1), lang.RT_IntCast_J__I_NoInit(i__2))); var chain__7 int64 = 0; var best__8 int64 = 0; var bestd__9 int64 = 0; L1: for {



		var tmp1 bool; var or__1927000174__auto____10 bool = lang.Numbers_IsNeg_J__Z_NoInit(j__6); if or__1927000174__auto____10 { tmp1 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 bool = lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6), 32768); if or__1927000174__auto____11 { tmp1 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 bool = lang.Numbers_Gte_J_J__Z_NoInit(chain__7, 64); if or__1927000174__auto____12 { tmp1 = or__1927000174__auto____12 } else { var or__1927000174__auto____13 bool = lang.Numbers_Gte_J_J__Z_NoInit(best__8, 64); if or__1927000174__auto____13 { tmp1 = or__1927000174__auto____13 } else { tmp1 = lang.Numbers_Gte_J_J__Z_NoInit(best__8, maxl__5) } } } }; if tmp1 {
			if lang.Numbers_Gte_J_J__Z_NoInit(best__8, 3) { return lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(best__8, 16), bestd__9) } else { return 0 } } else {
//line :155:1
				var l__10 int64

				if lang.Numbers_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(j__6, best__8)))).Ref()), lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__2, best__8)))).Ref())) {
					var tmp2 int64; var root_94 any = A_arbace_j2g_zlib_A_const_20.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_94, A_arbace_j2g_zlib_match_length_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = b__0; var arg_98 int64 = i__2; var arg_99 int64 = j__6; var arg_100 int64 = maxl__5; if linked_95 == nil { tmp2 = lang.RT_LongCast_O__J_NoInit(ifn_96.Invoke_O_O_O_O__O(arg_97, jrt.Long_ValueOf_J__Long_NoInit(arg_98).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_99).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_100).Ref())) } else { tmp2 = linked_95.(*A_arbace_j2g_zlib_match_length_A).InvokePrim_O_O_J_J_J__J(root_94, arg_97, arg_98, arg_99, arg_100) }; l__10 = lang.RT_LongCast_J__J_NoInit(tmp2) } else {
//line :157:1
						l__10 = 0
					}

				if lang.Numbers_Gt_J_J__Z_NoInit(l__10, best__8) {
					j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(prev__1), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), l__10, lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6); continue L1 } else {
						j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(prev__1), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), best__8, bestd__9; continue L1 } } } } }; /*line :146:1*/panic("j2g: unreachable") }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Invoke_O_O_O_O__O(self, b__0, prev__1, p_i__2 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O_J__J(self, b__0, prev__1, lang.RT_LongCast_O__J_NoInit(p_i__2))).Ref() }

















func A_arbace_j2g_zlib_lz77_A_New() *A_arbace_j2g_zlib_lz77_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_lz77_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Invoke_O_O__O(self, b__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0)); var head__3 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(65536), A_arbace_j2g_zlib_A_const_21).Ref(); var prev__4 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Max_J_J__J_NoInit(int64(n__2), 1)), A_arbace_j2g_zlib_A_const_21).Ref(); var out__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(n__2))).Ref()).Ref(); var flag__6 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(1, 40); var i__7 int64 = 0; var k__8 int64 = 0; var pending__9 int64 = 0; L1: for {











	if lang.Numbers_Gte_J_J__Z_NoInit(i__7, int64(n__2)) {
		if lang.Numbers_IsPos_J__Z_NoInit(pending__9) {
			jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(out__5), lang.RT_IntCast_J__I_NoInit(k__8), lang.Numbers_Or_J_J__J_NoInit(pending__9, flag__6)))
//line :177:1
			return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(k__8)).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(k__8).Ref()) } } else {



				var root_107 any = A_arbace_j2g_zlib_A_const_23.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_107, A_arbace_j2g_zlib_insert_BANG__A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = b__0; var arg_111 any = head__3; var arg_112 any = prev__4; var arg_113 int64 = i__7; if linked_108 == nil { ifn_109.Invoke_O_O_O_O__O(arg_110, arg_111, arg_112, jrt.Long_ValueOf_J__Long_NoInit(arg_113).Ref()) } else { linked_108.(*A_arbace_j2g_zlib_insert_BANG__A).InvokePrim_O_O_O_O_J__O(root_107, arg_110, arg_111, arg_112, arg_113) }
//line :176:1
				var m__10 int64; var tmp1 int64; var root_101 any = A_arbace_j2g_zlib_A_const_22.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_101, A_arbace_j2g_zlib_longest_A_fn_class); var ifn_103 lang.IFn





				if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = b__0; var arg_105 any = prev__4; var arg_106 int64 = i__7; if linked_102 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_103.Invoke_O_O_O__O(arg_104, arg_105, jrt.Long_ValueOf_J__Long_NoInit(arg_106).Ref())) } else { tmp1 = linked_102.(*A_arbace_j2g_zlib_longest_A).InvokePrim_O_O_O_J__J(root_101, arg_104, arg_105, arg_106) }; m__10 = lang.RT_LongCast_J__J_NoInit(tmp1)
				if lang.Numbers_IsPos_J__Z_NoInit(pending__9) {

					if lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(m__10, 16), lang.Numbers_ShiftRight_J_J__J_NoInit(pending__9, 16)) {

						jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(out__5), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(i__7)))).Ref()), 255))))
						i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), m__10; continue L1 } else {
//line :185:1
							var end__11 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Dec_J__J_NoInit(i__7), lang.Numbers_ShiftRight_J_J__J_NoInit(pending__9, 16))





							jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(out__5), lang.RT_IntCast_J__I_NoInit(k__8), lang.Numbers_Or_J_J__J_NoInit(pending__9, flag__6)))
//line :185:1
							var x__12 int64 = lang.Numbers_Inc_J__J_NoInit(i__7); L2: for {






								if lang.Numbers_Lt_J_J__Z_NoInit(x__12, end__11) { var root_114 any = A_arbace_j2g_zlib_A_const_23.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_114, A_arbace_j2g_zlib_insert_BANG__A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = b__0; var arg_118 any = head__3; var arg_119 any = prev__4; var arg_120 int64 = x__12; if linked_115 == nil { ifn_116.Invoke_O_O_O_O__O(arg_117, arg_118, arg_119, jrt.Long_ValueOf_J__Long_NoInit(arg_120).Ref()) } else { linked_115.(*A_arbace_j2g_zlib_insert_BANG__A).InvokePrim_O_O_O_O_J__O(root_114, arg_117, arg_118, arg_119, arg_120) }; x__12 = lang.Numbers_Inc_J__J_NoInit(x__12); continue L2 }
//line :185:1
								break L2
							}






							i__7, k__8, pending__9 = end__11, lang.Numbers_Inc_J__J_NoInit(k__8), 0; continue L1 } } else {
//line :183:1
								if lang.Numbers_IsPos_J__Z_NoInit(m__10) {










									i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), k__8, m__10; continue L1 } else {
//line :183:1
										if A_arbace_j2g_zlib_A_const_10 != nil {











											jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(out__5), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__7))).Ref()), 255))))
											i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), 0; continue L1 } else {
//line :183:1
												return nil } } } } } }; /*line :164:1*/panic("j2g: unreachable") }







































func A_arbace_j2g_zlib_rle_lengths_A_New() *A_arbace_j2g_zlib_rle_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Invoke_O_O__O(self, ls__0 any) any { { var v__2 any; var root_121 any = A_arbace_j2g_zlib_A_const_24.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_123 lang.IFn


	if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = ls__0; if linked_122 == nil { v__2 = ifn_123.Invoke_O__O(arg_124) } else { v__2 = linked_122.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_121, arg_124) }
//line :204:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(v__2); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp1 bool; var na_125 any = i__4; var na_126 int64 = int64(n__3); if jrt.Long_InstanceOf(na_125) { var n0_127 int64 = jrt.NN(jrt.Long_Cast(na_125)).LongValue__J(); var n1_128 int64 = na_126; tmp1 = n0_127 >= n1_128 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_125, na_126) }; if tmp1 { return acc__5 } else { var x__6 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(v__2, lang.RT_IntCast_O__I_NoInit(i__4))); var run__7 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__143 any = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(i__4, n__3, x__6, v__2); var tmp3 *jrt.Class
			var fncls__142 /*line :209:1*/*jrt.Class = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class


			if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__143); A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class = fncls__142d; tmp3 = fncls__142d } else { tmp3 = fncls__142 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__143, tmp3, nil); run__7 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
			var tmp4 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)
			if and__1927000168__auto____8 { var na_144 any = run__7; var na_145 int64 = 11; if jrt.Long_InstanceOf(na_144) { var n0_146 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); var n1_147 int64 = na_145; tmp4 = n0_146 >= n1_147 } else { tmp4 = lang.Numbers_Gte_O_J__Z_NoInit(na_144, na_145) } } else { tmp4 = and__1927000168__auto____8 }
//line :213:1
			if tmp4 { var r__8 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 138); var tmp5 jrt.Number_I; var na_161 any = i__4; var na_162 any = r__8; var tmp6 bool; var tmp7 bool
				tmp7 = jrt.Long_InstanceOf(na_161); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_162) }; tmp6 = tmp7; if tmp6 { var n0_163 int64 = jrt.NN(jrt.Long_Cast(na_161)).LongValue__J(); var n1_164 int64 = jrt.NN(jrt.Long_Cast(na_162)).LongValue__J(); var nr_165 int64 = n0_163 + n1_164; if (n0_163^nr_165)&(n1_164^nr_165) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_165)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_161, na_162) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_161); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_162) }; tmp8 = tmp9; if tmp8 { var n0_163_2 float64 = jrt.NN(jrt.Double_Cast(na_161)).DoubleValue__D(); var n1_164_2 float64 = jrt.NN(jrt.Double_Cast(na_162)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_163_2 + n1_164_2)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_161, na_162) } }; var tmp10 any = tmp5; var tmp11 any; var root_166 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = acc__5; var arg_170 any; var tmp12 any = A_arbace_j2g_zlib_A_const_25; var tmp13 jrt.Number_I; var na_171 any = r__8; var na_172 int64 = 11; if jrt.Long_InstanceOf(na_171) { var n0_173 int64 = jrt.NN(jrt.Long_Cast(na_171)).LongValue__J(); var n1_174 int64 = na_172; var nr_175 int64 = n0_173 - n1_174; var tmp14 bool; var tmp15 bool; tmp15 = !(n1_174 == -9223372036854775808); if tmp15 { tmp15 = (n0_173^n1_174)&(n0_173^nr_175) >= 0 }; tmp14 = tmp15; if tmp14 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_175)) } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_171, na_172) } } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_171, na_172) }; arg_170 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); if linked_167 == nil { tmp11 = ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { tmp11 = linked_167.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) }; i__4, acc__5 = tmp10, tmp11; continue L1 } else {
//line :213:1
					var tmp16 bool; var and__1927000168__auto____8_2 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)

					if and__1927000168__auto____8_2 { var na_149 any = run__7; var na_150 int64 = 3; if jrt.Long_InstanceOf(na_149) { var n0_151 int64 = jrt.NN(jrt.Long_Cast(na_149)).LongValue__J(); var n1_152 int64 = na_150; tmp16 = n0_151 >= n1_152 } else { tmp16 = lang.Numbers_Gte_O_J__Z_NoInit(na_149, na_150) } } else { tmp16 = and__1927000168__auto____8_2 }
//line :213:1
					if tmp16 { var r__8_2 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 10); var tmp17 jrt.Number_I; var na_176 any = i__4; var na_177 any = r__8_2; var tmp18 bool; var tmp19 bool

						tmp19 = jrt.Long_InstanceOf(na_176); if tmp19 { tmp19 = jrt.Long_InstanceOf(na_177) }; tmp18 = tmp19; if tmp18 { var n0_178 int64 = jrt.NN(jrt.Long_Cast(na_176)).LongValue__J(); var n1_179 int64 = jrt.NN(jrt.Long_Cast(na_177)).LongValue__J(); var nr_180 int64 = n0_178 + n1_179; if (n0_178^nr_180)&(n1_179^nr_180) >= 0 { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_180)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_176, na_177) } } else { var tmp20 bool; var tmp21 bool; tmp21 = jrt.Double_InstanceOf(na_176); if tmp21 { tmp21 = jrt.Double_InstanceOf(na_177) }; tmp20 = tmp21; if tmp20 { var n0_178_2 float64 = jrt.NN(jrt.Double_Cast(na_176)).DoubleValue__D(); var n1_179_2 float64 = jrt.NN(jrt.Double_Cast(na_177)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_178_2 + n1_179_2)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_176, na_177) } }; var tmp22 any = tmp17; var tmp23 any; var root_181 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = acc__5; var arg_185 any; var tmp24 any = A_arbace_j2g_zlib_A_const_26; var tmp25 jrt.Number_I; var na_186 any = r__8_2; var na_187 int64 = 3; if jrt.Long_InstanceOf(na_186) { var n0_188 int64 = jrt.NN(jrt.Long_Cast(na_186)).LongValue__J(); var n1_189 int64 = na_187; var nr_190 int64 = n0_188 - n1_189; var tmp26 bool; var tmp27 bool; tmp27 = !(n1_189 == -9223372036854775808); if tmp27 { tmp27 = (n0_188^n1_189)&(n0_188^nr_190) >= 0 }; tmp26 = tmp27; if tmp26 { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_190)) } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_186, na_187) } } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_186, na_187) }; arg_185 = lang.Tuple_Create_O_O__IPersistentVector(tmp24, tmp25); if linked_182 == nil { tmp23 = ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { tmp23 = linked_182.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) }; i__4, acc__5 = tmp22, tmp23; continue L1 } else {
//line :213:1
							var tmp28 bool; var and__1927000168__auto____8_3 bool = lang.Numbers_IsPos_J__Z_NoInit(x__6)


							if and__1927000168__auto____8_3 { var na_154 any = run__7; var na_155 int64 = 4; if jrt.Long_InstanceOf(na_154) { var n0_156 int64 = jrt.NN(jrt.Long_Cast(na_154)).LongValue__J(); var n1_157 int64 = na_155; tmp28 = n0_156 >= n1_157 } else { tmp28 = lang.Numbers_Gte_O_J__Z_NoInit(na_154, na_155) } } else { tmp28 = and__1927000168__auto____8_3 }
//line :213:1
							if tmp28 { var r__8_3 any; var tmp29 jrt.Number_I
								var na_159 any = run__7

								if jrt.Long_InstanceOf(na_159) { var n0_160 int64 = jrt.NN(jrt.Long_Cast(na_159)).LongValue__J(); if n0_160 == -9223372036854775808 { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_159) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_160 - 1)) } } else { if jrt.Double_InstanceOf(na_159) { var n0_160_2 float64 = jrt.NN(jrt.Double_Cast(na_159)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_160_2 - 1.0)) } else { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_159) } }; r__8_3 = lang.Numbers_Min_O_J__O_NoInit(tmp29, 6); var tmp30 jrt.Number_I; var na_191 any; var na_193 any = i__4; var na_194 int64 = 1; if jrt.Long_InstanceOf(na_193) { var n0_195 int64 = jrt.NN(jrt.Long_Cast(na_193)).LongValue__J(); var n1_196 int64 = na_194; var nr_197 int64 = n0_195 + n1_196; if (n0_195^nr_197)&(n1_196^nr_197) >= 0 { na_191 = jrt.Long_ValueOf_J__Long_NoInit(nr_197).Ref() } else { na_191 = lang.Numbers_Add_O_J__Number_NoInit(na_193, na_194) } } else { na_191 = lang.Numbers_Add_O_J__Number_NoInit(na_193, na_194) }; var na_192 any = r__8_3; var tmp31 bool; var tmp32 bool; tmp32 = jrt.Long_InstanceOf(na_191); if tmp32 { tmp32 = jrt.Long_InstanceOf(na_192) }; tmp31 = tmp32; if tmp31 { var n0_198 int64 = jrt.NN(jrt.Long_Cast(na_191)).LongValue__J(); var n1_199 int64 = jrt.NN(jrt.Long_Cast(na_192)).LongValue__J(); var nr_200 int64 = n0_198 + n1_199; if (n0_198^nr_200)&(n1_199^nr_200) >= 0 { tmp30 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_200)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_191, na_192) } } else { var tmp33 bool; var tmp34 bool; tmp34 = jrt.Double_InstanceOf(na_191); if tmp34 { tmp34 = jrt.Double_InstanceOf(na_192) }; tmp33 = tmp34; if tmp33 { var n0_198_2 float64 = jrt.NN(jrt.Double_Cast(na_191)).DoubleValue__D(); var n1_199_2 float64 = jrt.NN(jrt.Double_Cast(na_192)).DoubleValue__D(); tmp30 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_198_2 + n1_199_2)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_191, na_192) } }; var tmp35 any = tmp30; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_5.GetRawRoot__O()); var tmp37 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17); var tmp38 any = A_arbace_j2g_zlib_A_const_18; var tmp39 jrt.Number_I; var na_207 any = r__8_3; var na_208 int64 = 3; if jrt.Long_InstanceOf(na_207) { var n0_209 int64 = jrt.NN(jrt.Long_Cast(na_207)).LongValue__J(); var n1_210 int64 = na_208; var nr_211 int64 = n0_209 - n1_210; var tmp40 bool; var tmp41 bool; tmp41 = !(n1_210 == -9223372036854775808); if tmp41 { tmp41 = (n0_209^n1_210)&(n0_209^nr_211) >= 0 }; tmp40 = tmp41; if tmp40 { tmp39 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_211)) } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_207, na_208) } } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_207, na_208) }; i__4, acc__5 = tmp35, tmp36.Invoke_O_O_O__O(acc__5, tmp37, lang.Tuple_Create_O_O__IPersistentVector(tmp38, tmp39)); continue L1 } else {
//line :213:1
									if A_arbace_j2g_zlib_A_const_10 != nil {



										var tmp42 jrt.Number_I; var na_212 any = i__4; if jrt.Long_InstanceOf(na_212) { var n0_213 int64 = jrt.NN(jrt.Long_Cast(na_212)).LongValue__J(); if n0_213 == 9223372036854775807 { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_212) } else { tmp42 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_213 + 1)) } } else { if jrt.Double_InstanceOf(na_212) { var n0_213_2 float64 = jrt.NN(jrt.Double_Cast(na_212)).DoubleValue__D(); tmp42 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_213_2 + 1.0)) } else { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_212) } }; var tmp43 any = tmp42; var tmp44 any; var root_214 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = acc__5; var arg_218 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17); if linked_215 == nil { tmp44 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { tmp44 = linked_215.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }; i__4, acc__5 = tmp43, tmp44; continue L1 } else {
//line :213:1
											return nil } } } } } } }; /*line :204:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(p0 any, p1 int32, p2 int64, p3 any) *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A{}; t.Ctor_O_I_J_O(p0, p1, p2, p3); return t }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Ctor_O_I_J_O(c__i any, c__n int32, c__x int64, c__v any) { t.F_i = c__i; t.F_n = c__n; t.F_x = c__x; t.F_v = c__v }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Invoke_O__O(self any) any { { var j__1 any = t.F_i; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_130 any = j__1; var na_131 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_130) { var n0_132 int64 = jrt.NN(jrt.Long_Cast(na_130)).LongValue__J(); var n1_133 int64 = na_131; and__1927000168__auto____2 = n0_132 < n1_133 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_130, na_131) }; if and__1927000168__auto____2 { var tmp2 int64 = t.F_x; var tmp3 any = t.F_v; tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(tmp2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(j__1)))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp4 jrt.Number_I; var na_140 any = j__1; if jrt.Long_InstanceOf(na_140) { var n0_141 int64 = jrt.NN(jrt.Long_Cast(na_140)).LongValue__J(); if n0_141 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_140) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_141 + 1)) } } else { if jrt.Double_InstanceOf(na_140) { var n0_141_2 float64 = jrt.NN(jrt.Double_Cast(na_140)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_141_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_140) } }; j__1 = tmp4; continue L1 } else { var na_135 any = j__1; var na_136 any = t.F_i; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_135); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_136) }; tmp5 = tmp6; if tmp5 { var n0_137 int64 = jrt.NN(jrt.Long_Cast(na_135)).LongValue__J(); var n1_138 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); var nr_139 int64 = n0_137 - n1_138; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_138 == -9223372036854775808); if tmp8 { tmp8 = (n0_137^n1_138)&(n0_137^nr_139) >= 0 }; tmp7 = tmp8; if tmp7 { return jrt.Long_ValueOf_J__Long_NoInit(nr_139).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_135, na_136) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_135); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_136) }; tmp9 = tmp10; if tmp9 { var n0_137_2 float64 = jrt.NN(jrt.Double_Cast(na_135)).DoubleValue__D(); var n1_138_2 float64 = jrt.NN(jrt.Double_Cast(na_136)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_137_2 + -n1_138_2).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_135, na_136) } } } } }; panic("j2g: unreachable") }






func A_arbace_j2g_zlib_write_block_BANG__A_New() *A_arbace_j2g_zlib_write_block_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Ctor() {}
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Invoke_O_O_O_O_O_O__O(self, w__0, syms__1, from__2, to__3, last_QMARK___4 any) any { var from__6 int64 = lang.RT_LongCast_O__J_NoInit(from__2); var to__7 int64 = lang.RT_LongCast_O__J_NoInit(to__3); var lf__8 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_27).Ref(); var df__9 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_28).Ref(); var i__10 int64 = from__6; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__10, to__7) { var s__11 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(syms__1), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__10))); var tmp1 any; var root_359 any = A_arbace_j2g_zlib_A_const_48.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_bit_test_A_fn_class); var ifn_361 lang.IFn

		if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = jrt.Long_ValueOf_J__Long_NoInit(s__11).Ref(); var arg_363 any = A_arbace_j2g_zlib_A_const_49; if linked_360 == nil { tmp1 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp1 = linked_360.(*aot_arbace_core.A_arbace_core_bit_test_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if jrt.J2g_Truth(tmp1) { var len__12 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__11, 16), 65535); var d__13 int64 = lang.Numbers_And_J_J__J_NoInit(s__11, 65535); var tmp2 *jrt.LongArray = jrt.LongArray_Cast(lf__8); var tmp3 int64; var root_374 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_374, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_376 lang.IFn

			if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_378 int64 = len__12; if linked_375 == nil { tmp3 = lang.RT_LongCast_O__J_NoInit(ifn_376.Invoke_O_O__O(arg_377, jrt.Long_ValueOf_J__Long_NoInit(arg_378).Ref())) } else { tmp3 = linked_375.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_374, arg_377, arg_378) }; var tmp4 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, lang.RT_LongCast_J__J_NoInit(tmp3))); var tmp5 *jrt.LongArray = jrt.LongArray_Cast(lf__8); var tmp6 int64; var root_379 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_379, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_383 int64 = len__12; if linked_380 == nil { tmp6 = lang.RT_LongCast_O__J_NoInit(ifn_381.Invoke_O_O__O(arg_382, jrt.Long_ValueOf_J__Long_NoInit(arg_383).Ref())) } else { tmp6 = linked_380.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_379, arg_382, arg_383) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, tmp4, lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, lang.RT_LongCast_J__J_NoInit(tmp6)))))))
			var tmp7 *jrt.LongArray = jrt.LongArray_Cast(df__9); var tmp8 int64; var root_364 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_364, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_368 int64 = d__13; if linked_365 == nil { tmp8 = lang.RT_LongCast_O__J_NoInit(ifn_366.Invoke_O_O__O(arg_367, jrt.Long_ValueOf_J__Long_NoInit(arg_368).Ref())) } else { tmp8 = linked_365.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_364, arg_367, arg_368) }; var tmp9 int32 = lang.RT_IntCast_J__I_NoInit(lang.RT_LongCast_J__J_NoInit(tmp8)); var tmp10 *jrt.LongArray = jrt.LongArray_Cast(df__9); var tmp11 int64; var root_369 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_369, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_373 int64 = d__13; if linked_370 == nil { tmp11 = lang.RT_LongCast_O__J_NoInit(ifn_371.Invoke_O_O__O(arg_372, jrt.Long_ValueOf_J__Long_NoInit(arg_373).Ref())) } else { tmp11 = linked_370.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_369, arg_372, arg_373) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp7, tmp9, lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp10, lang.RT_IntCast_J__I_NoInit(lang.RT_LongCast_J__J_NoInit(tmp11)))))) } else {
				jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(lf__8), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lf__8), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)))))) }
		i__10 = lang.Numbers_Inc_J__J_NoInit(i__10); continue L1 }
//line :219:1
	break L1 };












	jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(lf__8), lang.RT_IntCast_J__I_NoInit(256), 1)); var used__10 int32; var tmp12 any; var root_348 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_350 lang.IFn; if














	linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any; var fnbody__354 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(df__9); var tmp13 *jrt.Class; var fncls__353 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class; if fncls__353 == nil { var fncls__353d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__354); A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class = fncls__353d; tmp13 = fncls__353d } else { tmp13 = fncls__353 }; arg_351 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__354, tmp13, nil); var arg_352 any; var root_355 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = A_arbace_j2g_zlib_A_const_28; if linked_356 == nil { arg_352 = ifn_357.Invoke_O__O(arg_358) } else { arg_352 = linked_356.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_355, arg_358) }; if linked_349 == nil { tmp12 = ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { tmp12 = linked_349.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) }; used__10 = lang.RT_Count_O__I_NoInit(tmp12); if
	lang.Numbers_IsZero_J__Z_NoInit(int64(used__10)) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(df__9), lang.RT_IntCast_J__I_NoInit(0), 1)); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(df__9), lang.RT_IntCast_J__I_NoInit(1), 1)) } else { if lang.Numbers_Equiv_J_J__Z_NoInit(1, int64(used__10)) {
		var tmp14 *jrt.LongArray = jrt.LongArray_Cast(df__9); var tmp15 int64; if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(df__9), lang.RT_IntCast_J__I_NoInit(0))) { tmp15 = 1 } else { tmp15 = 0 }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp14, lang.RT_IntCast_J__I_NoInit(tmp15), 1)) } }; var ll__10 any; var root_219 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_219, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_221 lang.IFn; if

















	linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = lf__8; if linked_220 == nil { ll__10 = ifn_221.Invoke_O_O__O(arg_222, A_arbace_j2g_zlib_A_const_30) } else { ll__10 = linked_220.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_219, arg_222, 15) }; var dl__11 any; var root_224 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_224, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_226 lang.IFn; if


















	linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = df__9; if linked_225 == nil { dl__11 = ifn_226.Invoke_O_O__O(arg_227, A_arbace_j2g_zlib_A_const_30) } else { dl__11 = linked_225.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_224, arg_227, 15) }; var lc__12 any; var root_229 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_231 lang.IFn; if



















	linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = ll__10; if linked_230 == nil { lc__12 = ifn_231.Invoke_O__O(arg_232) } else { lc__12 = linked_230.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_229, arg_232) }; var dc__13 any; var root_233 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_235 lang.IFn; if




















	linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = dl__11; if linked_234 == nil { dc__13 = ifn_235.Invoke_O__O(arg_236) } else { dc__13 = linked_234.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_233, arg_236) }; var hlit__14 any; var tmp16 jrt.Number_I; var na_237 any; var or__1927000174__auto____14 any; var root_238 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_32.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_240 lang.IFn; if





















	linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_242 any = A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any; var fnbody__248 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(ll__10); var tmp17 *jrt.Class; var fncls__247 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__248); A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class = fncls__247d; tmp17 = fncls__247d } else { tmp17 = fncls__247 }; arg_245 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__248, tmp17, nil); var arg_246 any; var root_249 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = A_arbace_j2g_zlib_A_const_34; if linked_250 == nil { arg_246 = ifn_251.Invoke_O__O(arg_252) } else { arg_246 = linked_250.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_249, arg_252) }; if linked_243 == nil { arg_241 = ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { arg_241 = linked_243.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) }; if linked_239 == nil { or__1927000174__auto____14 = ifn_240.Invoke_O__O(arg_241) } else { or__1927000174__auto____14 = linked_239.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(or__1927000174__auto____14) { na_237 = or__1927000174__auto____14 } else { na_237 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_237) { var n0_253 int64 = jrt.NN(jrt.Long_Cast(na_237)).LongValue__J(); if n0_253 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_237) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_253 + 1)) } } else { if jrt.Double_InstanceOf(na_237) { var n0_253_2 float64 = jrt.NN(jrt.Double_Cast(na_237)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_253_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_237) } }; hlit__14 = lang.Numbers_Max_J_O__O_NoInit(257, tmp16); var hdist__15 any; var tmp18 jrt.Number_I; var na_254 any; var or__1927000174__auto____15 any; var root_255 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_32.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_257 lang.IFn; if






















	linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any; var root_259 any = A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any; var fnbody__265 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(dl__11); var tmp19 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__265); A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class = fncls__264d; tmp19 = fncls__264d } else { tmp19 = fncls__264 }; arg_262 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__265, tmp19, nil); var arg_263 any; var root_266 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = A_arbace_j2g_zlib_A_const_28; if linked_267 == nil { arg_263 = ifn_268.Invoke_O__O(arg_269) } else { arg_263 = linked_267.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_266, arg_269) }; if linked_260 == nil { arg_258 = ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { arg_258 = linked_260.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) }; if linked_256 == nil { or__1927000174__auto____15 = ifn_257.Invoke_O__O(arg_258) } else { or__1927000174__auto____15 = linked_256.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_255, arg_258) }; if jrt.J2g_Truth(or__1927000174__auto____15) { na_254 = or__1927000174__auto____15 } else { na_254 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_254) { var n0_270 int64 = jrt.NN(jrt.Long_Cast(na_254)).LongValue__J(); if n0_270 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_254) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_270 + 1)) } } else { if jrt.Double_InstanceOf(na_254) { var n0_270_2 float64 = jrt.NN(jrt.Double_Cast(na_254)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_270_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_254) } }; hdist__15 = lang.Numbers_Max_J_O__O_NoInit(1, tmp18); var rle__16 any; var root_271 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_35.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_j2g_zlib_rle_lengths_A_fn_class); var ifn_273 lang.IFn; if























	linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any; var root_275 any = A_arbace_j2g_zlib_A_const_36.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any; var root_280 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = hlit__14; var arg_284 any; var root_285 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = ll__10; if linked_286 == nil { arg_284 = ifn_287.Invoke_O__O(arg_288) } else { arg_284 = linked_286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_285, arg_288) }; if linked_281 == nil { arg_278 = ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { arg_278 = linked_281.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }; var arg_279 any; var root_289 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = hdist__15; var arg_293 any; var root_294 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = dl__11; if linked_295 == nil { arg_293 = ifn_296.Invoke_O__O(arg_297) } else { arg_293 = linked_295.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_294, arg_297) }; if linked_290 == nil { arg_279 = ifn_291.Invoke_O_O__O(arg_292, arg_293) } else { arg_279 = linked_290.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_289, arg_292, arg_293) }; if linked_276 == nil { arg_274 = ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { arg_274 = linked_276.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) }; if linked_272 == nil { rle__16 = ifn_273.Invoke_O__O(arg_274) } else { rle__16 = linked_272.(*A_arbace_j2g_zlib_rle_lengths_A).Invoke_O_O__O(root_271, arg_274) }; var cf__17 any = /*line :219:1*/lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_39).Ref(); var ___18 any; var tmp20 *lang.Compiler_AOTFn; var fnbody__327 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(cf__17, rle__16); var tmp21 *jrt.Class; var fncls__326 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class; _ = ___18; if

























	fncls__326 == nil { var fncls__326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__327); A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class = fncls__326d; tmp21 = fncls__326d } else { tmp21 = fncls__326 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__327, tmp21, nil); ___18 = Up_Compiler_AOTFn_IFn(tmp20).Invoke__O(); var cl__19 any; var root_328 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_328, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_330 lang.IFn; if


























	linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = cf__17; if linked_329 == nil { cl__19 = ifn_330.Invoke_O_O__O(arg_331, A_arbace_j2g_zlib_A_const_44) } else { cl__19 = linked_329.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_328, arg_331, 7) }; var cc__20 any; var root_333 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_335 lang.IFn; if



























	linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = cl__19; if linked_334 == nil { cc__20 = ifn_335.Invoke_O__O(arg_336) } else { cc__20 = linked_334.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_333, arg_336) }; var hclen__21 int64; var tmp22 any; var root_337 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_339 lang.IFn; if




























	linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var fnbody__343 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(cl__19); var tmp23 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class; if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__343); A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class = fncls__342d; tmp23 = fncls__342d } else { tmp23 = fncls__342 }; arg_340 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__343, tmp23, nil); var arg_341 any; var root_344 any = A_arbace_j2g_zlib_A_const_46.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = A_arbace_j2g_zlib_A_const_47.GetRawRoot__O(); if linked_345 == nil { arg_341 = ifn_346.Invoke_O__O(arg_347) } else { arg_341 = linked_345.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_344, arg_347) }; if linked_338 == nil { tmp22 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { tmp22 = linked_338.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; hclen__21 = lang.Numbers_Max_J_J__J_NoInit(4, lang.Numbers_Minus_J_J__J_NoInit(19, int64(lang.RT_Count_O__I_NoInit(tmp22)))); var tmp24 lang.IFn =
	lang.IFn_Cast(w__0); var tmp25 any; if jrt.J2g_Truth(last_QMARK___4) { tmp25 = A_arbace_j2g_zlib_A_const_53 } else { tmp25 = A_arbace_j2g_zlib_A_const_17 }; tmp24.Invoke_O_O__O(tmp25, A_arbace_j2g_zlib_A_const_53);
	lang.IFn_Cast(w__0).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_54, A_arbace_j2g_zlib_A_const_54); var tmp26 lang.IFn =
	lang.IFn_Cast(w__0); var tmp27 jrt.Number_I; var na_429 any = hlit__14; var na_430 int64 = 257; if jrt.Long_InstanceOf(na_429) { var n0_431 int64 = jrt.NN(jrt.Long_Cast(na_429)).LongValue__J(); var n1_432 int64 = na_430; var nr_433 int64 = n0_431 - n1_432; var tmp28 bool; var tmp29 bool; tmp29 = !(n1_432 == -9223372036854775808); if tmp29 { tmp29 = (n0_431^n1_432)&(n0_431^nr_433) >= 0 }; tmp28 = tmp29; if tmp28 { tmp27 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_433)) } else { tmp27 = lang.Numbers_Minus_O_J__Number_NoInit(na_429, na_430) } } else { tmp27 = lang.Numbers_Minus_O_J__Number_NoInit(na_429, na_430) }; tmp26.Invoke_O_O__O(tmp27, A_arbace_j2g_zlib_A_const_55); var tmp30 lang.IFn =
	lang.IFn_Cast(w__0); var tmp31 jrt.Number_I; var na_434 any = hdist__15; var na_435 int64 = 1; if jrt.Long_InstanceOf(na_434) { var n0_436 int64 = jrt.NN(jrt.Long_Cast(na_434)).LongValue__J(); var n1_437 int64 = na_435; var nr_438 int64 = n0_436 - n1_437; var tmp32 bool; var tmp33 bool; tmp33 = !(n1_437 == -9223372036854775808); if tmp33 { tmp33 = (n0_436^n1_437)&(n0_436^nr_438) >= 0 }; tmp32 = tmp33; if tmp32 { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_438)) } else { tmp31 = lang.Numbers_Minus_O_J__Number_NoInit(na_434, na_435) } } else { tmp31 = lang.Numbers_Minus_O_J__Number_NoInit(na_434, na_435) }; tmp30.Invoke_O_O__O(tmp31, A_arbace_j2g_zlib_A_const_55);
	lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(hclen__21, 4)).Ref(), A_arbace_j2g_zlib_A_const_56); var seq_1931000065__22 any; var root_384 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_386 lang.IFn; if


































	linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any; var root_388 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = jrt.Long_ValueOf_J__Long_NoInit(hclen__21).Ref(); var arg_392 any = A_arbace_j2g_zlib_A_const_47.GetRawRoot__O(); if linked_389 == nil { arg_387 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { arg_387 = linked_389.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }; if linked_385 == nil { seq_1931000065__22 = ifn_386.Invoke_O__O(arg_387) } else { seq_1931000065__22 = linked_385.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_384, arg_387) }; var chunk_1931000066__23 any; var count_1931000067__24 int64 = 0; var i_1931000068__25 int64 = 0; L2:
//line :219:1
	for {


































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000068__25, count_1931000067__24) { var s__26 any = lang.Indexed_Cast(chunk_1931000066__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000068__25)); lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__26)))).Ref(), A_arbace_j2g_zlib_A_const_57); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000068__25); continue L2 } else { var temp__1927000414__auto____26 any; var root_393 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = seq_1931000065__22; if linked_394 == nil { temp__1927000414__auto____26 = ifn_395.Invoke_O__O(arg_396) } else { temp__1927000414__auto____26 = linked_394.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_393, arg_396) }; if jrt.J2g_Truth(temp__1927000414__auto____26) { var seq_1931000065__27 any = temp__1927000414__auto____26; var tmp34 any; var root_397 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = seq_1931000065__27; if linked_398 == nil { tmp34 = ifn_399.Invoke_O__O(arg_400) } else { tmp34 = linked_398.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_397, arg_400) }; if jrt.J2g_Truth(tmp34) { var c__1927000678__auto____28 any; var root_401 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = seq_1931000065__27; if linked_402 == nil { c__1927000678__auto____28 = ifn_403.Invoke_O__O(arg_404) } else { c__1927000678__auto____28 = linked_402.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_401, arg_404) }; var tmp35 any; var root_439 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = seq_1931000065__27; if linked_440 == nil { tmp35 = ifn_441.Invoke_O__O(arg_442) } else { tmp35 = linked_440.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_439, arg_442) }; seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = tmp35, c__1927000678__auto____28, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var s__28 any; var root_405 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = seq_1931000065__27; if linked_406 == nil { s__28 = ifn_407.Invoke_O__O(arg_408) } else { s__28 = linked_406.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_405, arg_408) }; lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__28)))).Ref(), A_arbace_j2g_zlib_A_const_57); var tmp36 any; var root_443 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = seq_1931000065__27; if linked_444 == nil { tmp36 = ifn_445.Invoke_O__O(arg_446) } else { tmp36 = linked_444.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_443, arg_446) }; seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = tmp36, nil, 0, 0; continue L2 } } }
//line :219:1
		break L2 }; var seq_1931000069__22 any; var root_409 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_411 lang.IFn; if



































	linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = rle__16; if linked_410 == nil { seq_1931000069__22 = ifn_411.Invoke_O__O(arg_412) } else { seq_1931000069__22 = linked_410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_409, arg_412) }; var chunk_1931000070__23 any; var count_1931000071__24 int64 = 0; var i_1931000072__25 int64 = 0; L3:
//line :219:1
	for {



































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000072__25, count_1931000071__24) { var vec__1931000073__26 any = lang.Indexed_Cast(chunk_1931000070__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000072__25)); var s__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(0), nil); var x__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(1), nil)
			lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cc__20), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref())
//line :255:1
			var G__1931000076__29_ int32 = lang.RT_IntCast_O__I_NoInit(s__27)

		L4: switch { default: switch G__1931000076__29_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_54); break L4; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_57); break L4; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_44); break L4; default:}}
//line :255:1
			seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000072__25); continue L3 } else { var temp__1927000414__auto____26_2 any; var root_413 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = seq_1931000069__22; if linked_414 == nil { temp__1927000414__auto____26_2 = ifn_415.Invoke_O__O(arg_416) } else { temp__1927000414__auto____26_2 = linked_414.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_413, arg_416) }; if jrt.J2g_Truth(temp__1927000414__auto____26_2) { var seq_1931000069__27 any = temp__1927000414__auto____26_2; var tmp37 any; var root_417 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = seq_1931000069__27; if linked_418 == nil { tmp37 = ifn_419.Invoke_O__O(arg_420) } else { tmp37 = linked_418.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(tmp37) { var c__1927000678__auto____28_2 any; var root_421 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = seq_1931000069__27; if linked_422 == nil { c__1927000678__auto____28_2 = ifn_423.Invoke_O__O(arg_424) } else { c__1927000678__auto____28_2 = linked_422.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_421, arg_424) }; var tmp38 any; var root_448 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = seq_1931000069__27; if linked_449 == nil { tmp38 = ifn_450.Invoke_O__O(arg_451) } else { tmp38 = linked_449.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_448, arg_451) }; seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = tmp38, c__1927000678__auto____28_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1931000077__28 any; var root_425 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = seq_1931000069__27; if linked_426 == nil { vec__1931000077__28 = ifn_427.Invoke_O__O(arg_428) } else { vec__1931000077__28 = linked_426.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_425, arg_428) }; var s__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(0), nil); var x__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(1), nil)
				lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cc__20), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref())
//line :255:1
				var G__1931000080__31_ int32 = lang.RT_IntCast_O__I_NoInit(s__29)

			L5: switch { default: switch G__1931000080__31_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_54); break L5; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_57); break L5; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_44); break L5; default:}}
//line :255:1
				var tmp39 any; var root_453 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = seq_1931000069__27; if linked_454 == nil { tmp39 = ifn_455.Invoke_O__O(arg_456) } else { tmp39 = linked_454.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_453, arg_456) }; seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = tmp39, nil, 0, 0; continue L3 } } }
//line :219:1
		break L3 }; var i__22 int64 = from__6; L6: for {







































			if lang.Numbers_Lt_J_J__Z_NoInit(i__22, to__7) { var s__23 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(syms__1), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__22))); var tmp40 any; var root_457 any = A_arbace_j2g_zlib_A_const_48.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_bit_test_A_fn_class); var ifn_459 lang.IFn

				if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = jrt.Long_ValueOf_J__Long_NoInit(s__23).Ref(); var arg_461 any = A_arbace_j2g_zlib_A_const_49; if linked_458 == nil { tmp40 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { tmp40 = linked_458.(*aot_arbace_core.A_arbace_core_bit_test_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }; if jrt.J2g_Truth(tmp40) { var len__24 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__23, 16), 65535); var d__25 int64 = lang.Numbers_And_J_J__J_NoInit(s__23, 65535); var lcode__26 int64; var tmp41 int64; var root_462 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_462, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_464 lang.IFn

					if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_466 int64 = len__24; if linked_463 == nil { tmp41 = lang.RT_LongCast_O__J_NoInit(ifn_464.Invoke_O_O__O(arg_465, jrt.Long_ValueOf_J__Long_NoInit(arg_466).Ref())) } else { tmp41 = linked_463.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_462, arg_465, arg_466) }; lcode__26 = lang.RT_LongCast_J__J_NoInit(tmp41)
//line :261:1
					var dcode__27 int64; var tmp42 int64; var root_467 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_467, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_469 lang.IFn

					if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_471 int64 = d__25; if linked_468 == nil { tmp42 = lang.RT_LongCast_O__J_NoInit(ifn_469.Invoke_O_O__O(arg_470, jrt.Long_ValueOf_J__Long_NoInit(arg_471).Ref())) } else { tmp42 = linked_468.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_467, arg_470, arg_471) }; dcode__27 = lang.RT_LongCast_J__J_NoInit(tmp42)
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lc__12), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(ll__10), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, lcode__26)))).Ref())
					if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_59.GetRawRoot__O()), lang.RT_IntCast_J__I_NoInit(lcode__26))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(len__24, lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_52.GetRawRoot__O()), lang.RT_IntCast_J__I_NoInit(lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_59.GetRawRoot__O()), lang.RT_IntCast_J__I_NoInit(lcode__26))).Ref()) }
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(dc__13), lang.RT_IntCast_J__I_NoInit(dcode__27))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(dl__11), lang.RT_IntCast_J__I_NoInit(dcode__27))).Ref())
					if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_58.GetRawRoot__O()), lang.RT_IntCast_J__I_NoInit(dcode__27))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(d__25, lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_51.GetRawRoot__O()), lang.RT_IntCast_J__I_NoInit(dcode__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_58.GetRawRoot__O()), lang.RT_IntCast_J__I_NoInit(dcode__27))).Ref()) } } else {
						lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lc__12), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(ll__10), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref()) }
				i__22 = lang.Numbers_Inc_J__J_NoInit(i__22); continue L6 }
//line :219:1
			break L6 }; return /*line :270:1*/ lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lc__12), lang.RT_IntCast_J__I_NoInit(256))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(ll__10), lang.RT_IntCast_J__I_NoInit(256))).Ref()) }
//line :234:1
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Ctor_O(c__df any) { t.F_df = c__df }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Invoke_O_O__O(self, p1__1931000041_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_df); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000041_SHARP___1))))).Ref() }






func A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Ctor_O(c__ll any) { t.F_ll = c__ll }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Invoke_O_O__O(self, p1__1931000042_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_ll); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000042_SHARP___1))))).Ref() }
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Ctor_O(c__dl any) { t.F_dl = c__dl }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Invoke_O_O__O(self, p1__1931000043_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_dl); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000043_SHARP___1))))).Ref() }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(p0, p1 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Ctor_O_O(c__cf, c__rle any) { t.F_cf = c__cf; t.F_rle = c__rle }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Invoke_O__O(self any) any { { var seq_1931000051__1 any; var root_298 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any; var t_ any = t.F_rle; t.F_rle = nil; arg_301 = t_; if linked_299 == nil { seq_1931000051__1 = ifn_300.Invoke_O__O(arg_301) } else { seq_1931000051__1 = linked_299.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_298, arg_301) }; var chunk_1931000052__2 any; var count_1931000053__3 int64 = 0; var i_1931000054__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000054__4, count_1931000053__3) { var vec__1931000056__5 any = lang.Indexed_Cast(chunk_1931000052__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000054__4)); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000056__5, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); var tmp2 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)))))); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000054__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_302 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = seq_1931000051__1; if linked_303 == nil { temp__1927000414__auto____5 = ifn_304.Invoke_O__O(arg_305) } else { temp__1927000414__auto____5 = linked_303.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_302, arg_305) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1931000051__6 any = temp__1927000414__auto____5; var tmp3 any; var root_306 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = seq_1931000051__6; if linked_307 == nil { tmp3 = ifn_308.Invoke_O__O(arg_309) } else { tmp3 = linked_307.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_306, arg_309) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____7 any; var root_310 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = seq_1931000051__6; if linked_311 == nil { c__1927000678__auto____7 = ifn_312.Invoke_O__O(arg_313) } else { c__1927000678__auto____7 = linked_311.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_310, arg_313) }; var tmp4 any; var root_318 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = seq_1931000051__6; if linked_319 == nil { tmp4 = ifn_320.Invoke_O__O(arg_321) } else { tmp4 = linked_319.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_318, arg_321) }; seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = tmp4, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1931000059__7 any; var root_314 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = seq_1931000051__6; if linked_315 == nil { vec__1931000059__7 = ifn_316.Invoke_O__O(arg_317) } else { vec__1931000059__7 = linked_315.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_314, arg_317) }; var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000059__7, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp5 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); var tmp6 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp5, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp6, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)))))); var tmp7 any; var root_322 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = seq_1931000051__6; if linked_323 == nil { tmp7 = ifn_324.Invoke_O__O(arg_325) } else { tmp7 = linked_323.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_322, arg_325) }; seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Invoke_O_O__O(self, p1__1931000044_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_cl); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000044_SHARP___1))))).Ref() }























func A_arbace_j2g_zlib_adler32_A_New() *A_arbace_j2g_zlib_adler32_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_adler32_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Ctor() {}
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) InvokePrim_O_O__J(self, b__0 any) int64 { { var i__2 int64 = 0; var a__3 int64 = 1; var s__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__2, int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0)))) { var a__5 int64 = lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(a__3, lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__2))).Ref()), 255)), 65521)

		i__2, a__3, s__4 = lang.Numbers_Inc_J__J_NoInit(i__2), a__5, lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(s__4, a__5), 65521); continue L1 } else {
			return lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(s__4, 16), a__3) } } }; /*line :272:1*/panic("j2g: unreachable") }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Invoke_O_O__O(self, b__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, b__0)).Ref() }






func A_arbace_j2g_zlib_deflate_A_New() *A_arbace_j2g_zlib_deflate_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_deflate_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Invoke_O_O__O(self, b__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var w__3 any = A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__2, 0, 0); var vec__1931000083__4 any; var root_472 any = A_arbace_j2g_zlib_A_const_60.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, A_arbace_j2g_zlib_lz77_A_fn_class); var ifn_474 lang.IFn; if






	linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = b__0; if linked_473 == nil { vec__1931000083__4 = ifn_474.Invoke_O__O(arg_475) } else { vec__1931000083__4 = linked_473.(*A_arbace_j2g_zlib_lz77_A).Invoke_O_O__O(root_472, arg_475) }; var syms__5 any = /*line :279:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 int64 = lang.RT_LongCast_O__J_NoInit(k__6);








	jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(120)); jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(218)); if
	lang.Numbers_IsZero_J__Z_NoInit(k__7) {
		var root_476 any = A_arbace_j2g_zlib_A_const_61.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, A_arbace_j2g_zlib_write_block_BANG__A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = w__3; var arg_480 any = syms__5; var arg_481 any = A_arbace_j2g_zlib_A_const_17; var arg_482 any = A_arbace_j2g_zlib_A_const_17; var arg_483 any = jrt.Boolean_TRUE.Ref(); if linked_477 == nil { ifn_478.Invoke_O_O_O_O_O__O(arg_479, arg_480, arg_481, arg_482, arg_483) } else { linked_477.(*A_arbace_j2g_zlib_write_block_BANG__A).Invoke_O_O_O_O_O_O__O(root_476, arg_479, arg_480, arg_481, arg_482, arg_483) } } else {
//line :289:1
			var from__8 int64 = 0; L1: for { var to__9 int64 = lang.Numbers_Min_J_J__J_NoInit(k__7, lang.Numbers_Add_J_J__J_NoInit(from__8, 16384)); var root_508 any = A_arbace_j2g_zlib_A_const_61.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, A_arbace_j2g_zlib_write_block_BANG__A_fn_class); var ifn_510 lang.IFn



				if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = w__3; var arg_512 any = syms__5; var arg_513 any = jrt.Long_ValueOf_J__Long_NoInit(from__8).Ref(); var arg_514 any = jrt.Long_ValueOf_J__Long_NoInit(to__9).Ref(); var arg_515 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(to__9, k__7)).Ref(); if linked_509 == nil { ifn_510.Invoke_O_O_O_O_O__O(arg_511, arg_512, arg_513, arg_514, arg_515) } else { linked_509.(*A_arbace_j2g_zlib_write_block_BANG__A).Invoke_O_O_O_O_O_O__O(root_508, arg_511, arg_512, arg_513, arg_514, arg_515) }
				if lang.Numbers_Lt_J_J__Z_NoInit(to__9, k__7) { from__8 = to__9; continue L1 }
//line :289:1
				break L1 } };





	lang.IFn_Cast(w__3).Invoke__O(); var a__8 int64; var tmp1 int64; var root_484 any = /*line :279:1*/A_arbace_j2g_zlib_A_const_62.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_484, A_arbace_j2g_zlib_adler32_A_fn_class); var ifn_486 lang.IFn; if
















	linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = b__0; if linked_485 == nil { tmp1 = lang.RT_LongCast_O__J_NoInit(ifn_486.Invoke_O__O(arg_487)) } else { tmp1 = linked_485.(*A_arbace_j2g_zlib_adler32_A).InvokePrim_O_O__J(root_484, arg_487) }; a__8 = lang.RT_LongCast_J__J_NoInit(tmp1); var seq_1931000086__9 any; var root_488 any = /*line :279:1*/A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_490 lang.IFn; if

















	linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = A_arbace_j2g_zlib_A_const_63; if linked_489 == nil { seq_1931000086__9 = ifn_490.Invoke_O__O(arg_491) } else { seq_1931000086__9 = linked_489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_488, arg_491) }; var chunk_1931000087__10 any; var count_1931000088__11 int64 = 0; var i_1931000089__12 int64 = 0; L2:
//line :279:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000089__12, count_1931000088__11) { var sh__13 any = lang.Indexed_Cast(chunk_1931000087__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000089__12)); var tmp2 jrt.ByteArrayOutputStream_I = jrt.ByteArrayOutputStream_Cast(out__2); var tmp3 int64; var na_516 int64 = a__8; var na_517 any = sh__13; if jrt.Long_InstanceOf(na_517) { var n0_518 int64 = na_516; var n1_519 int64 = jrt.NN(jrt.Long_Cast(na_517)).LongValue__J(); tmp3 = n0_518 >> (n1_519 & 63) } else { tmp3 = lang.Numbers_ShiftRight_J_O__J_NoInit(na_516, na_517) }; tmp2.Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp3, 255))); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000089__12); continue L2 } else { var temp__1927000414__auto____13 any; var root_492 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = seq_1931000086__9; if linked_493 == nil { temp__1927000414__auto____13 = ifn_494.Invoke_O__O(arg_495) } else { temp__1927000414__auto____13 = linked_493.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_492, arg_495) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1931000086__14 any = temp__1927000414__auto____13; var tmp4 any; var root_496 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = seq_1931000086__14; if linked_497 == nil { tmp4 = ifn_498.Invoke_O__O(arg_499) } else { tmp4 = linked_497.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_496, arg_499) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____15 any; var root_500 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = seq_1931000086__14; if linked_501 == nil { c__1927000678__auto____15 = ifn_502.Invoke_O__O(arg_503) } else { c__1927000678__auto____15 = linked_501.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_500, arg_503) }; var tmp5 any; var root_521 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = seq_1931000086__14; if linked_522 == nil { tmp5 = ifn_523.Invoke_O__O(arg_524) } else { tmp5 = linked_522.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_521, arg_524) }; seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = tmp5, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var sh__15 any; var root_504 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = seq_1931000086__14; if linked_505 == nil { sh__15 = ifn_506.Invoke_O__O(arg_507) } else { sh__15 = linked_505.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_504, arg_507) }; var tmp6 jrt.ByteArrayOutputStream_I = jrt.ByteArrayOutputStream_Cast(out__2); var tmp7 int64; var na_525 int64 = a__8; var na_526 any = sh__15; if jrt.Long_InstanceOf(na_526) { var n0_527 int64 = na_525; var n1_528 int64 = jrt.NN(jrt.Long_Cast(na_526)).LongValue__J(); tmp7 = n0_527 >> (n1_528 & 63) } else { tmp7 = lang.Numbers_ShiftRight_J_O__J_NoInit(na_525, na_526) }; tmp6.Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp7, 255))); var tmp8 any; var root_530 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = seq_1931000086__14; if linked_531 == nil { tmp8 = ifn_532.Invoke_O__O(arg_533) } else { tmp8 = linked_531.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_530, arg_533) }; seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = tmp8, nil, 0, 0; continue L2 } } }
//line :279:1
		break L2 }; return /*line :298:1*/ jrt.ByteArrayOutputStream_Cast(out__2).ToByteArray__B1().Ref() }
//line :287:1
type A_arbace_j2g_zlib_A struct{ jrt.Object }

var A_arbace_j2g_zlib_A_const_pool *jrt.RefArray

var A_arbace_j2g_zlib_A_const_0 *lang.Var

var A_arbace_j2g_zlib_A_const_1 any

var A_arbace_j2g_zlib_A_const_2 *lang.Var

var A_arbace_j2g_zlib_A_const_3 *lang.Var

var A_arbace_j2g_zlib_A_const_4 *lang.Var

var A_arbace_j2g_zlib_A_const_5 *lang.Var

var A_arbace_j2g_zlib_A_const_6 any

var A_arbace_j2g_zlib_A_const_7 *lang.Var

var A_arbace_j2g_zlib_A_const_8 *lang.Var

var A_arbace_j2g_zlib_A_const_9 *lang.Var

var A_arbace_j2g_zlib_A_const_10 *lang.Keyword

var A_arbace_j2g_zlib_A_const_11 *lang.Var

var A_arbace_j2g_zlib_A_const_12 *lang.Var

var A_arbace_j2g_zlib_A_const_13 *lang.Var

var A_arbace_j2g_zlib_A_const_14 *lang.Var

var A_arbace_j2g_zlib_A_const_15 *lang.Var

var A_arbace_j2g_zlib_A_const_16 *lang.Var

var A_arbace_j2g_zlib_A_const_17 any

var A_arbace_j2g_zlib_A_const_18 any

var A_arbace_j2g_zlib_A_const_19 *lang.Var

var A_arbace_j2g_zlib_A_const_20 *lang.Var

var A_arbace_j2g_zlib_A_const_21 any

var A_arbace_j2g_zlib_A_const_22 *lang.Var

var A_arbace_j2g_zlib_A_const_23 *lang.Var

var A_arbace_j2g_zlib_A_const_24 *lang.Var

var A_arbace_j2g_zlib_A_const_25 any

var A_arbace_j2g_zlib_A_const_26 any

var A_arbace_j2g_zlib_A_const_27 any

var A_arbace_j2g_zlib_A_const_28 any

var A_arbace_j2g_zlib_A_const_29 *lang.Var

var A_arbace_j2g_zlib_A_const_30 any

var A_arbace_j2g_zlib_A_const_31 *lang.Var

var A_arbace_j2g_zlib_A_const_32 *lang.Var

var A_arbace_j2g_zlib_A_const_33 *lang.Var

var A_arbace_j2g_zlib_A_const_34 any

var A_arbace_j2g_zlib_A_const_35 *lang.Var

var A_arbace_j2g_zlib_A_const_36 *lang.Var

var A_arbace_j2g_zlib_A_const_37 *lang.Var

var A_arbace_j2g_zlib_A_const_38 *lang.Var

var A_arbace_j2g_zlib_A_const_39 any

var A_arbace_j2g_zlib_A_const_40 *lang.Var

var A_arbace_j2g_zlib_A_const_41 *lang.Var

var A_arbace_j2g_zlib_A_const_42 *lang.Var

var A_arbace_j2g_zlib_A_const_43 *lang.Var

var A_arbace_j2g_zlib_A_const_44 any

var A_arbace_j2g_zlib_A_const_45 *lang.Var

var A_arbace_j2g_zlib_A_const_46 *lang.Var

var A_arbace_j2g_zlib_A_const_47 *lang.Var

var A_arbace_j2g_zlib_A_const_48 *lang.Var

var A_arbace_j2g_zlib_A_const_49 any

var A_arbace_j2g_zlib_A_const_50 *lang.Var

var A_arbace_j2g_zlib_A_const_51 *lang.Var

var A_arbace_j2g_zlib_A_const_52 *lang.Var

var A_arbace_j2g_zlib_A_const_53 any

var A_arbace_j2g_zlib_A_const_54 any

var A_arbace_j2g_zlib_A_const_55 any

var A_arbace_j2g_zlib_A_const_56 any

var A_arbace_j2g_zlib_A_const_57 any

var A_arbace_j2g_zlib_A_const_58 *lang.Var

var A_arbace_j2g_zlib_A_const_59 *lang.Var

var A_arbace_j2g_zlib_A_const_60 *lang.Var

var A_arbace_j2g_zlib_A_const_61 *lang.Var

var A_arbace_j2g_zlib_A_const_62 *lang.Var

var A_arbace_j2g_zlib_A_const_63 any

var A_arbace_j2g_zlib_A_init jrt.ClassInit

func A_arbace_j2g_zlib_A_Init() { if !A_arbace_j2g_zlib_A_init.Done() { A_arbace_j2g_zlib_A_init.Run(A_arbace_j2g_zlib_A_clinit) } }

func A_arbace_j2g_zlib_A_clinit() { A_arbace_j2g_zlib_A_clinit_p0(); A_arbace_j2g_zlib_A_clinit_p1(); A_arbace_j2g_zlib_A_clinit_p2(); A_arbace_j2g_zlib_A_clinit_p3(); A_arbace_j2g_zlib_A_clinit_p4(); A_arbace_j2g_zlib_A_clinit_p5() }

func A_arbace_j2g_zlib_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_zlib_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 67); A_arbace_j2g_zlib_A_const_0 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[3]); A_arbace_j2g_zlib_A_const_1 = A_arbace_j2g_zlib_A_const_pool.A[4]; A_arbace_j2g_zlib_A_const_2 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[5]); A_arbace_j2g_zlib_A_const_3 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[6]); A_arbace_j2g_zlib_A_const_4 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[7]); A_arbace_j2g_zlib_A_const_5 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[8]); A_arbace_j2g_zlib_A_const_6 = A_arbace_j2g_zlib_A_const_pool.A[9]; A_arbace_j2g_zlib_A_const_7 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[10]); A_arbace_j2g_zlib_A_const_8 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[11]); A_arbace_j2g_zlib_A_const_9 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[12]); A_arbace_j2g_zlib_A_const_10 = lang.Keyword_Cast(A_arbace_j2g_zlib_A_const_pool.A[13]) }

func A_arbace_j2g_zlib_A_clinit_p1() { A_arbace_j2g_zlib_A_const_11 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[14]); A_arbace_j2g_zlib_A_const_12 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[15]); A_arbace_j2g_zlib_A_const_13 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[16]); A_arbace_j2g_zlib_A_const_14 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[17]); A_arbace_j2g_zlib_A_const_15 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[18]); A_arbace_j2g_zlib_A_const_16 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[19]); A_arbace_j2g_zlib_A_const_17 = A_arbace_j2g_zlib_A_const_pool.A[20]; A_arbace_j2g_zlib_A_const_18 = A_arbace_j2g_zlib_A_const_pool.A[21]; A_arbace_j2g_zlib_A_const_19 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[22]); A_arbace_j2g_zlib_A_const_20 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[23]); A_arbace_j2g_zlib_A_const_21 = A_arbace_j2g_zlib_A_const_pool.A[24]; A_arbace_j2g_zlib_A_const_22 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[25]) }

func A_arbace_j2g_zlib_A_clinit_p2() { A_arbace_j2g_zlib_A_const_23 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[26]); A_arbace_j2g_zlib_A_const_24 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[27]); A_arbace_j2g_zlib_A_const_25 = A_arbace_j2g_zlib_A_const_pool.A[28]; A_arbace_j2g_zlib_A_const_26 = A_arbace_j2g_zlib_A_const_pool.A[29]; A_arbace_j2g_zlib_A_const_27 = A_arbace_j2g_zlib_A_const_pool.A[30]; A_arbace_j2g_zlib_A_const_28 = A_arbace_j2g_zlib_A_const_pool.A[31]; A_arbace_j2g_zlib_A_const_29 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[32]); A_arbace_j2g_zlib_A_const_30 = A_arbace_j2g_zlib_A_const_pool.A[33]; A_arbace_j2g_zlib_A_const_31 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[34]); A_arbace_j2g_zlib_A_const_32 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[35]); A_arbace_j2g_zlib_A_const_33 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[36]); A_arbace_j2g_zlib_A_const_34 = A_arbace_j2g_zlib_A_const_pool.A[37]; A_arbace_j2g_zlib_A_const_35 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[38]) }

func A_arbace_j2g_zlib_A_clinit_p3() { A_arbace_j2g_zlib_A_const_36 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[39]); A_arbace_j2g_zlib_A_const_37 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[40]); A_arbace_j2g_zlib_A_const_38 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[41]); A_arbace_j2g_zlib_A_const_39 = A_arbace_j2g_zlib_A_const_pool.A[42]; A_arbace_j2g_zlib_A_const_40 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[43]); A_arbace_j2g_zlib_A_const_41 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[44]); A_arbace_j2g_zlib_A_const_42 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[45]); A_arbace_j2g_zlib_A_const_43 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[46]); A_arbace_j2g_zlib_A_const_44 = A_arbace_j2g_zlib_A_const_pool.A[47]; A_arbace_j2g_zlib_A_const_45 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[48]); A_arbace_j2g_zlib_A_const_46 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[49]); A_arbace_j2g_zlib_A_const_47 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[50]) }

func A_arbace_j2g_zlib_A_clinit_p4() { A_arbace_j2g_zlib_A_const_48 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[51]); A_arbace_j2g_zlib_A_const_49 = A_arbace_j2g_zlib_A_const_pool.A[52]; A_arbace_j2g_zlib_A_const_50 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[53]); A_arbace_j2g_zlib_A_const_51 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[54]); A_arbace_j2g_zlib_A_const_52 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[55]); A_arbace_j2g_zlib_A_const_53 = A_arbace_j2g_zlib_A_const_pool.A[56]; A_arbace_j2g_zlib_A_const_54 = A_arbace_j2g_zlib_A_const_pool.A[57]; A_arbace_j2g_zlib_A_const_55 = A_arbace_j2g_zlib_A_const_pool.A[58]; A_arbace_j2g_zlib_A_const_56 = A_arbace_j2g_zlib_A_const_pool.A[59]; A_arbace_j2g_zlib_A_const_57 = A_arbace_j2g_zlib_A_const_pool.A[60]; A_arbace_j2g_zlib_A_const_58 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[61]); A_arbace_j2g_zlib_A_const_59 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[62]); A_arbace_j2g_zlib_A_const_60 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[63]) }

func A_arbace_j2g_zlib_A_clinit_p5() { A_arbace_j2g_zlib_A_const_61 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[64]); A_arbace_j2g_zlib_A_const_62 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[65]); A_arbace_j2g_zlib_A_const_63 = A_arbace_j2g_zlib_A_const_pool.A[66] }

func A_arbace_j2g_zlib_A_New() *A_arbace_j2g_zlib_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_A) Ctor() {}

func (t *A_arbace_j2g_zlib_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_A_class }

func (t *A_arbace_j2g_zlib_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_A); return ok }

func A_arbace_j2g_zlib_A_Cast(x any) *A_arbace_j2g_zlib_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_A_class)) }; return v }



type A_arbace_j2g_zlib_adler32_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_adler32_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_canonical_codes_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_canonical_codes_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_code_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_code_of_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_deflate_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_deflate_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000004_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000004_A_New() *A_arbace_j2g_zlib_eval1931000004_A { t := &A_arbace_j2g_zlib_eval1931000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000004_A_class }

func (t *A_arbace_j2g_zlib_eval1931000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); return ok }

func A_arbace_j2g_zlib_eval1931000004_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000004_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000008_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000008_A_New() *A_arbace_j2g_zlib_eval1931000008_A { t := &A_arbace_j2g_zlib_eval1931000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000008_A_class }

func (t *A_arbace_j2g_zlib_eval1931000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); return ok }

func A_arbace_j2g_zlib_eval1931000008_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000008_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000012_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000012_A_New() *A_arbace_j2g_zlib_eval1931000012_A { t := &A_arbace_j2g_zlib_eval1931000012_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000012_A_class }

func (t *A_arbace_j2g_zlib_eval1931000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); return ok }

func A_arbace_j2g_zlib_eval1931000012_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000012_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_huffman_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A struct{ j2g_header uint64; F_parent any; F_n int32; F_start any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A struct{ j2g_header uint64; F_parent, F_lens any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A struct{ j2g_header uint64; F_parent, F_s any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_insert_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_insert_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_longest_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_longest_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_lz77_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_lz77_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_match_length_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_match_length_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_reverse_bits_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_reverse_bits_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_rle_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A struct{ j2g_header uint64; F_i any; F_n int32; F_x int64; F_v any }

var A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_write_block_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A struct{ j2g_header uint64; F_df any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A struct{ j2g_header uint64; F_ll any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A struct{ j2g_header uint64; F_dl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A struct{ j2g_header uint64; F_cf, F_rle any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A struct{ j2g_header uint64; F_cl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class *jrt.Class
