//line aot_arbace_j2g_zlib.ae:1
package aot_arbace_j2g_zlib

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_New() *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_zlib_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_New() *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_j2g_zlib_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_j2g_zlib_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(), A_arbace_j2g_zlib_A_const_6) }

















func A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_New() *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Invoke_O_O_O_O__O(self, out__1, acc__2, n__3 any) any { return A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__1, lang.RT_LongCast_O__J_NoInit(acc__2), lang.RT_LongCast_O__J_NoInit(n__3)) }



















func A_arbace_j2g_zlib_reverse_bits_A_New() *A_arbace_j2g_zlib_reverse_bits_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_reverse_bits_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) InvokePrim_O_J_J__J(self any, code__0, len__1 int64) int64 { { var c__3 int64 = code__0; var r__4 int64 = 0; var i__5 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, len__1) { c__3, r__4, i__5 = lang.Numbers_ShiftRight_J_J__J_NoInit(c__3, 1), lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(r__4, 1), lang.Numbers_And_J_J__J_NoInit(c__3, 1)), lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else { return r__4 } } }; /*line :39:1*/panic("j2g: unreachable") }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Invoke_O_O_O__O(self, p_code__0, p_len__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_code__0), lang.RT_LongCast_O__J_NoInit(p_len__1))).Ref() }






func A_arbace_j2g_zlib_huffman_lengths_A_New() *A_arbace_j2g_zlib_huffman_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Ctor() {}
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) InvokePrim_O_O_J__O(self, freqs__0 any, limit__1 int64) any { { var n__3 int32 = lang.RT_Alength_J1__I_NoInit(jrt.LongArray_Cast(freqs__0)); var fs__4 any = lang.RT_Aclone_J1__J1_NoInit(jrt.LongArray_Cast(freqs__0)).Ref(); L1: for { var syms__5 any; var root_15 any = A_arbace_j2g_zlib_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_17 lang.IFn






	if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var fnbody__21 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(fs__4); var tmp1 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__21); A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class = fncls__20d; tmp1 = fncls__20d } else { tmp1 = fncls__20 }; arg_18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__21, tmp1, nil); var arg_19 any; var root_22 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_23 == nil { arg_19 = ifn_24.Invoke_O__O(arg_25) } else { arg_19 = linked_23.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_22, arg_25) }; if linked_16 == nil { syms__5 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { syms__5 = linked_16.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }
//line :46:1
	var lens__6 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var tmp2 any; var root_26 any = A_arbace_j2g_zlib_A_const_9.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_28 lang.IFn









	if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = syms__5; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_26, arg_29) }
//line :55:1
	if jrt.J2g_Truth(tmp2) { return lens__6 } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(syms__5))) {

		var tmp3 *jrt.LongArray = jrt.LongArray_Cast(lens__6); var tmp4 any; var root_85 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = syms__5; if linked_86 == nil { tmp4 = ifn_87.Invoke_O__O(arg_88) } else { tmp4 = linked_86.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_85, arg_88) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp3, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(tmp4)), 1))
//line :55:1
		return lens__6 } else { if A_arbace_j2g_zlib_A_const_10 != nil { var parent__7 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, int64(n__3))).Ref()).Ref(); var start__8 any; var root_30 any = A_arbace_j2g_zlib_A_const_11.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_32 lang.IFn






			if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_12.GetRawRoot__O()).Invoke__O(); var arg_34 any; var root_38 any = A_arbace_j2g_zlib_A_const_13.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var fnbody__44 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(fs__4); var tmp5 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__44); A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class = fncls__43d; tmp5 = fncls__43d } else { tmp5 = fncls__43 }; arg_41 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp5, nil); var arg_42 any = syms__5; if linked_39 == nil { arg_34 = ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { arg_34 = linked_39.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_38, arg_41, arg_42) }; if linked_31 == nil { start__8 = ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { start__8 = linked_31.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) }
//line :55:1
			var ___9 any; var tmp6 *lang.Compiler_AOTFn; var fnbody__69 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(parent__7, n__3, start__8); var tmp7 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class; _ = ___9







			if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__69); A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class = fncls__68d; tmp7 = fncls__68d } else { tmp7 = fncls__68 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp7, nil); ___9 = Up_Compiler_AOTFn_IFn(tmp6).Invoke__O()
//line :55:1
			var root__10 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(n__3), lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(syms__5)))), -1); var maxlen__11 any; var root_70 any = A_arbace_j2g_zlib_A_const_16.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_72 lang.IFn















			if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var fnbody__79 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(parent__7, lens__6, root__10); var tmp8 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__79); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class = fncls__78d; tmp8 = fncls__78d } else { tmp8 = fncls__78 }; arg_73 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp8, nil); var arg_74 any = A_arbace_j2g_zlib_A_const_17; var arg_75 any = syms__5; if linked_71 == nil { maxlen__11 = ifn_72.Invoke_O_O_O__O(arg_73, arg_74, arg_75) } else { maxlen__11 = linked_71.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_70, arg_73, arg_74, arg_75)
			}



			var tmp9 bool; var na_80 any = maxlen__11; var na_81 int64 = limit__1; if jrt.Long_InstanceOf(na_80) { var n0_82 int64 = jrt.NN(jrt.Long_Cast(na_80)).LongValue__J(); var n1_83 int64 = na_81; tmp9 = n0_82 <= n1_83 } else { tmp9 = lang.Numbers_Lte_O_J__Z_NoInit(na_80, na_81) }; if tmp9 { return lens__6 } else { var f2__12 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J_NoInit(n__3); var i__14 int64 = 0; L2: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i__14, n__1927000701__auto____13) { var f__15 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(fs__4), lang.RT_IntCast_J__I_NoInit(i__14))
					if lang.Numbers_IsPos_J__Z_NoInit(f__15) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(f2__12), lang.RT_IntCast_J__I_NoInit(i__14), lang.Numbers_Max_J_J__J_NoInit(1, lang.Numbers_ShiftRight_J_J__J_NoInit(f__15, 1)))) }
//line :79:1
					i__14 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__14); continue L2 }
//line :76:1
				break L2
			}



				fs__4 = f2__12; continue L1 } } else {
//line :55:1
					return nil } } } } }; /*line :46:1*/panic("j2g: unreachable") }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Invoke_O_O_O__O(self, freqs__0, p_limit__1 any) any { return t.InvokePrim_O_O_J__O(self, freqs__0, lang.RT_LongCast_O__J_NoInit(p_limit__1)) }






func A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Invoke_O_O__O(self, p1__1931000018_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_fs); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000018_SHARP___1))))).Ref() }








func A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_fs); return lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__1)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref()) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Ctor_O_I_O(c__parent any, c__n int32, c__start any) { t.F_parent = c__parent; t.F_n = c__n; t.F_start = c__start }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Invoke_O__O(self any) any { { var q__1 any; var t_ any = t.F_start; t.F_start = nil; q__1 = t_; var next_id__2 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); var order__3 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); L1: for {
											if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(q__1)), 1) { var a__4 any; var root_45 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_47 lang.IFn
												if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = q__1; if linked_46 == nil { a__4 = ifn_47.Invoke_O__O(arg_48) } else { a__4 = linked_46.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_45, arg_48) }
//line :64:1
		var q__5 any; var root_49 any = A_arbace_j2g_zlib_A_const_15.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_51 lang.IFn
		if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = q__1; var arg_53 any = a__4; if linked_50 == nil { q__5 = ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { q__5 = linked_50.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }
//line :64:1
		var b__6 any; var root_54 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_56 lang.IFn
		if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = q__5; if linked_55 == nil { b__6 = ifn_56.Invoke_O__O(arg_57) } else { b__6 = linked_55.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_54, arg_57) }
//line :64:1
		var q__7 any; var root_58 any = A_arbace_j2g_zlib_A_const_15.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_60 lang.IFn
		if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = q__5; var arg_62 any = b__6; if linked_59 == nil { q__7 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { q__7 = linked_59.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }
		var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_parent); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		var tmp2 *jrt.LongArray = jrt.LongArray_Cast(t.F_parent); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		var tmp3 any; var root_63 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = q__7; var arg_67 any = lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(0))), lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(0))))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(order__3).Ref(), jrt.Long_ValueOf_J__Long_NoInit(next_id__2).Ref()); if linked_64 == nil { tmp3 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { tmp3 = linked_64.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; q__1, next_id__2, order__3 = tmp3, lang.Numbers_Inc_J__J_NoInit(next_id__2), lang.Numbers_Inc_J__J_NoInit(order__3); continue L1 } else {
//line :64:1
			return nil } } }; /*line :63:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Ctor_O_O_J(c__parent, c__lens any, c__root int64) { t.F_parent = c__parent; t.F_lens = c__lens; t.F_root = c__root }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) InvokePrim_O_J_O__O(self any, m__1 int64, s__2 any) any { var d__3 int64; var tmp1 *lang.Compiler_AOTFn; var fnbody__77 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(t.F_parent, s__2, t.F_root); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class; if
															fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__77); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__77, tmp2, nil); d__3 = lang.RT_LongCast_O__J_NoInit(Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()); var tmp3 /*line :73:1*/*jrt.LongArray = jrt.LongArray_Cast(t.F_lens); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp3, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__2)), d__3)); return /*line :74:1*/ jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(m__1, d__3)).Ref() }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Invoke_O_O_O__O(self, p_m__1, s__2 any) any { return t.InvokePrim_O_J_O__O(self, lang.RT_LongCast_O__J_NoInit(p_m__1), s__2) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Ctor_O_O_J(c__parent, c__s any, c__root int64) { t.F_parent = c__parent; t.F_s = c__s; t.F_root = c__root }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Invoke_O__O(self any) any { { var x__1 int64; var tmp1 any; var t_ any = t.F_s; t.F_s = nil; tmp1 = t_; x__1 = lang.RT_LongCast_O__J_NoInit(tmp1); var d__2 int64 = 0; L1: for { if lang.Numbers_Equiv_J_J__Z_NoInit(x__1, t.F_root) { return jrt.Long_ValueOf_J__Long_NoInit(d__2).Ref() } else { var tmp2 *jrt.LongArray = jrt.LongArray_Cast(t.F_parent); x__1, d__2 = lang.RT_Aget_J1_I__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(x__1))), lang.Numbers_Inc_J__J_NoInit(d__2); continue L1 } } }; panic("j2g: unreachable") }










func A_arbace_j2g_zlib_canonical_codes_A_New() *A_arbace_j2g_zlib_canonical_codes_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_canonical_codes_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Invoke_O_O__O(self, lens__0 any) any { var n__2 int32 = lang.RT_Alength_J1__I_NoInit(jrt.LongArray_Cast(lens__0)); var bl_count__3 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var next_code__4 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var codes__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref()).Ref(); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7 int64 = 0; L1: for {







	if lang.Numbers_Lt_J_J__Z_NoInit(i__7, n__1927000701__auto____6) { var l__8 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lens__0), lang.RT_IntCast_J__I_NoInit(i__7)); if lang.Numbers_IsPos_J__Z_NoInit(l__8) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(bl_count__3), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(bl_count__3), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)))))) }; i__7 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7); continue L1 }
//line :83:1
	break L1 }; var bits__6 int64 = 1; var code__7 int64 = 0; L2: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(bits__6, 16) { var code__8 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(code__7, lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(bl_count__3), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(bits__6)))), 1)

			jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_J__I_NoInit(bits__6), code__8))
			bits__6, code__7 = lang.Numbers_Inc_J__J_NoInit(bits__6), code__8; continue L2 }
//line :83:1
		break L2 }; var n__1927000701__auto____6_2 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7_2 int64 = 0; L3: for {













			if lang.Numbers_Lt_J_J__Z_NoInit(i__7_2, n__1927000701__auto____6_2) { var l__8_2 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lens__0), lang.RT_IntCast_J__I_NoInit(i__7_2))

				if lang.Numbers_IsPos_J__Z_NoInit(l__8_2) {
					var tmp1 *jrt.LongArray = jrt.LongArray_Cast(codes__5); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__7_2); var tmp3 int64; var root_89 any = A_arbace_j2g_zlib_A_const_19.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_89, A_arbace_j2g_zlib_reverse_bits_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2))); var arg_93 int64 = l__8_2; if linked_90 == nil { tmp3 = lang.RT_LongCast_O__J_NoInit(ifn_91.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_92).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_93).Ref())) } else { tmp3 = linked_90.(*A_arbace_j2g_zlib_reverse_bits_A).InvokePrim_O_J_J__J(root_89, arg_92, arg_93) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, tmp2, tmp3))
					jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(next_code__4), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)))))) }
//line :97:1
				i__7_2 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7_2); continue L3 }
//line :83:1
			break L3 }; return codes__5 }





























func A_arbace_j2g_zlib_code_of_A_New() *A_arbace_j2g_zlib_code_of_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_code_of_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) InvokePrim_O_O_J__J(self, bases__0 any, v__1 int64) int64 { { var i__3 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Alength_J1__I_NoInit(jrt.LongArray_Cast(bases__0)))); L1: for {


	if lang.Numbers_Gt_J_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(bases__0), lang.RT_IntCast_J__I_NoInit(i__3)), v__1) { i__3 = lang.Numbers_Dec_J__J_NoInit(i__3); continue L1 } else { return i__3 } } }; /*line :113:1*/panic("j2g: unreachable") }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Invoke_O_O_O__O(self, bases__0, p_v__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_J__J(self, bases__0, lang.RT_LongCast_O__J_NoInit(p_v__1))).Ref() }













func A_arbace_j2g_zlib_match_length_A_New() *A_arbace_j2g_zlib_match_length_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_match_length_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) InvokePrim_O_O_J_J_J__J(self, b__0 any, i__1, j__2, max__3 int64) int64 { { var k__5 int64 = 0; L1: for {


	var tmp1 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lt_J_J__Z_NoInit(k__5, max__3); if and__1927000168__auto____6 { tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__1, k__5)))).Ref()), lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(j__2, k__5)))).Ref())) } else { tmp1 = and__1927000168__auto____6 }; if tmp1 { k__5 = lang.Numbers_Inc_J__J_NoInit(k__5); continue L1 } else { return k__5 } } }; /*line :127:1*/panic("j2g: unreachable") }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Invoke_O_O_O_O_O__O(self, b__0, p_i__1, p_j__2, p_max__3 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_J_J_J__J(self, b__0, lang.RT_LongCast_O__J_NoInit(p_i__1), lang.RT_LongCast_O__J_NoInit(p_j__2), lang.RT_LongCast_O__J_NoInit(p_max__3))).Ref() }




func A_arbace_j2g_zlib_insert_BANG__A_New() *A_arbace_j2g_zlib_insert_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_insert_BANG__A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) InvokePrim_O_O_O_O_J__O(self, b__0, head__1, prev__2 any, i__3 int64) any {



	if lang.Numbers_Lte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 3), int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0)))) { var h__5 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__3))).Ref()), 255), 8), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 1)))).Ref()), 255), 4)), lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255)), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255), 11)), 65535)





		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.IntArray_Cast(prev__2), lang.RT_IntCast_J__I_NoInit(i__3), lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(head__1), lang.RT_IntCast_J__I_NoInit(h__5))))
		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.IntArray_Cast(head__1), lang.RT_IntCast_J__I_NoInit(h__5), lang.RT_IntCast_J__I_NoInit(i__3))) }
//line :132:1
	return nil }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Invoke_O_O_O_O_O__O(self, b__0, head__1, prev__2, p_i__3 any) any { return t.InvokePrim_O_O_O_O_J__O(self, b__0, head__1, prev__2, lang.RT_LongCast_O__J_NoInit(p_i__3)) }













func A_arbace_j2g_zlib_longest_A_New() *A_arbace_j2g_zlib_longest_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_longest_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) InvokePrim_O_O_O_J__J(self, b__0, prev__1 any, i__2 int64) int64 { { var n__4 int32 = lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0))




	if lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__2, 3), int64(n__4)) { return 0 } else { var maxl__5 int64 = lang.Numbers_Min_J_J__J_NoInit(258, lang.Numbers_Minus_J_J__J_NoInit(int64(n__4), i__2)); var j__6 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(prev__1), lang.RT_IntCast_J__I_NoInit(i__2))); var chain__7 int64 = 0; var best__8 any = lang.RT_Box_J__Number_NoInit(0); var bestd__9 int64 = 0; L1: for {



		var tmp1 bool; var or__1927000174__auto____10 bool = lang.Numbers_IsNeg_J__Z_NoInit(j__6); if or__1927000174__auto____10 { tmp1 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 bool = lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6), 32768); if or__1927000174__auto____11 { tmp1 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 bool = lang.Numbers_Gte_J_J__Z_NoInit(chain__7, 64); if or__1927000174__auto____12 { tmp1 = or__1927000174__auto____12 } else { var or__1927000174__auto____13 bool; var na_94 any = best__8; var na_95 int64 = 64; if jrt.Long_InstanceOf(na_94) { var n0_96 int64 = jrt.NN(jrt.Long_Cast(na_94)).LongValue__J(); var n1_97 int64 = na_95; or__1927000174__auto____13 = n0_96 >= n1_97 } else { or__1927000174__auto____13 = lang.Numbers_Gte_O_J__Z_NoInit(na_94, na_95) }; if or__1927000174__auto____13 { tmp1 = or__1927000174__auto____13 } else { var na_99 any = best__8; var na_100 int64 = maxl__5; if jrt.Long_InstanceOf(na_99) { var n0_101 int64 = jrt.NN(jrt.Long_Cast(na_99)).LongValue__J(); var n1_102 int64 = na_100; tmp1 = n0_101 >= n1_102 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_99, na_100) } } } } }; if tmp1 {
			var tmp2 bool; var na_104 any = best__8; var na_105 int64 = 3; if jrt.Long_InstanceOf(na_104) { var n0_106 int64 = jrt.NN(jrt.Long_Cast(na_104)).LongValue__J(); var n1_107 int64 = na_105; tmp2 = n0_106 >= n1_107 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_104, na_105) }; if tmp2 { var tmp3 int64; var na_109 any = best__8; var na_110 int64 = 16; if jrt.Long_InstanceOf(na_109) { var n0_111 int64 = jrt.NN(jrt.Long_Cast(na_109)).LongValue__J(); var n1_112 int64 = na_110; tmp3 = n0_111 << (n1_112 & 63) } else { tmp3 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_109, na_110) }; return lang.Numbers_Or_J_J__J_NoInit(tmp3, bestd__9) } else { return 0 } } else {
//line :155:1
				var l__10 any; var tmp4 *jrt.ByteArray = jrt.ByteArray_Cast(b__0); var tmp5 jrt.Number_I
				var na_114 int64 = j__6; var na_115 any = best__8
				if jrt.Long_InstanceOf(na_115) { var n0_116 int64 = na_114; var n1_117 int64 = jrt.NN(jrt.Long_Cast(na_115)).LongValue__J(); var nr_118 int64 = n0_116 + n1_117; if (n0_116^nr_118)&(n1_117^nr_118) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_118)) } else { tmp5 = lang.Numbers_Add_J_O__Number_NoInit(na_114, na_115) } } else { tmp5 = lang.Numbers_Add_J_O__Number_NoInit(na_114, na_115) }; var tmp6 int64 = lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp4, lang.RT_IntCast_O__I_NoInit(tmp5))).Ref()); var tmp7 *jrt.ByteArray = jrt.ByteArray_Cast(b__0); var tmp8 jrt.Number_I; var na_119 int64 = i__2; var na_120 any = best__8; if jrt.Long_InstanceOf(na_120) { var n0_121 int64 = na_119; var n1_122 int64 = jrt.NN(jrt.Long_Cast(na_120)).LongValue__J(); var nr_123 int64 = n0_121 + n1_122; if (n0_121^nr_123)&(n1_122^nr_123) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_123)) } else { tmp8 = lang.Numbers_Add_J_O__Number_NoInit(na_119, na_120) } } else { tmp8 = lang.Numbers_Add_J_O__Number_NoInit(na_119, na_120) }; if lang.Numbers_Equiv_J_J__Z_NoInit(tmp6, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp7, lang.RT_IntCast_O__I_NoInit(tmp8))).Ref())) {
					var root_124 any = A_arbace_j2g_zlib_A_const_20.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_124, A_arbace_j2g_zlib_match_length_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = b__0; var arg_128 int64 = i__2; var arg_129 int64 = j__6; var arg_130 int64 = maxl__5; if linked_125 == nil { l__10 = ifn_126.Invoke_O_O_O_O__O(arg_127, jrt.Long_ValueOf_J__Long_NoInit(arg_128).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_129).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_130).Ref()) } else { l__10 = jrt.Long_ValueOf_J__Long_NoInit(linked_125.(*A_arbace_j2g_zlib_match_length_A).InvokePrim_O_O_J_J_J__J(root_124, arg_127, arg_128, arg_129, arg_130)).Ref() } } else {
//line :157:1
						l__10 = A_arbace_j2g_zlib_A_const_17
					}

				var tmp9 bool; var na_131 int64 = lang.RT_LongCast_O__J_NoInit(l__10); var na_132 any = best__8; if jrt.Long_InstanceOf(na_132) { var n0_133 int64 = na_131; var n1_134 int64 = jrt.NN(jrt.Long_Cast(na_132)).LongValue__J(); tmp9 = n0_133 > n1_134 } else { tmp9 = lang.Numbers_Gt_J_O__Z_NoInit(na_131, na_132) }; if tmp9 {
					j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(prev__1), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), l__10, lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6); continue L1 } else {
						j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.IntArray_Cast(prev__1), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), best__8, bestd__9; continue L1 } } } } }; /*line :146:1*/panic("j2g: unreachable") }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Invoke_O_O_O_O__O(self, b__0, prev__1, p_i__2 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O_J__J(self, b__0, prev__1, lang.RT_LongCast_O__J_NoInit(p_i__2))).Ref() }

















func A_arbace_j2g_zlib_lz77_A_New() *A_arbace_j2g_zlib_lz77_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_lz77_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Invoke_O_O__O(self, b__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0)); var head__3 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(65536), A_arbace_j2g_zlib_A_const_21).Ref(); var prev__4 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Max_J_J__J_NoInit(int64(n__2), 1)), A_arbace_j2g_zlib_A_const_21).Ref(); var out__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(n__2))).Ref()).Ref(); var flag__6 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(1, 40); var i__7 int64 = 0; var k__8 int64 = 0; var pending__9 any = lang.RT_Box_J__Number_NoInit(0); L1: for {











	if lang.Numbers_Gte_J_J__Z_NoInit(i__7, int64(n__2)) {
		var tmp1 bool; var na_136 any = pending__9; if jrt.Long_InstanceOf(na_136) { var n0_137 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); tmp1 = n0_137 > 0 } else { if jrt.Double_InstanceOf(na_136) { var n0_137_2 float64 = jrt.NN(jrt.Double_Cast(na_136)).DoubleValue__D(); tmp1 = n0_137_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_136) } }; if tmp1 {
			var tmp2 *jrt.LongArray = jrt.LongArray_Cast(out__5); var tmp3 int32 = lang.RT_IntCast_J__I_NoInit(k__8); var tmp4 int64; var na_163 any = pending__9; var na_164 int64 = flag__6; if jrt.Long_InstanceOf(na_163) { var n0_165 int64 = jrt.NN(jrt.Long_Cast(na_163)).LongValue__J(); var n1_166 int64 = na_164; tmp4 = n0_165 | n1_166 } else { tmp4 = lang.Numbers_Or_O_J__J_NoInit(na_163, na_164) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, tmp3, tmp4))
//line :177:1
			return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(k__8)).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(k__8).Ref()) } } else {



				var root_168 any = A_arbace_j2g_zlib_A_const_23.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_168, A_arbace_j2g_zlib_insert_BANG__A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = b__0; var arg_172 any = head__3; var arg_173 any = prev__4; var arg_174 int64 = i__7; if linked_169 == nil { ifn_170.Invoke_O_O_O_O__O(arg_171, arg_172, arg_173, jrt.Long_ValueOf_J__Long_NoInit(arg_174).Ref()) } else { linked_169.(*A_arbace_j2g_zlib_insert_BANG__A).InvokePrim_O_O_O_O_J__O(root_168, arg_171, arg_172, arg_173, arg_174) }
//line :176:1
				var m__10 any; var root_138 any = A_arbace_j2g_zlib_A_const_22.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_138, A_arbace_j2g_zlib_longest_A_fn_class); var ifn_140 lang.IFn





				if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = b__0; var arg_142 any = prev__4; var arg_143 int64 = i__7; if linked_139 == nil { m__10 = ifn_140.Invoke_O_O_O__O(arg_141, arg_142, jrt.Long_ValueOf_J__Long_NoInit(arg_143).Ref()) } else { m__10 = jrt.Long_ValueOf_J__Long_NoInit(linked_139.(*A_arbace_j2g_zlib_longest_A).InvokePrim_O_O_O_J__J(root_138, arg_141, arg_142, arg_143)).Ref() }
				var tmp5 bool; var na_144 any = pending__9
				if jrt.Long_InstanceOf(na_144) { var n0_145 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); tmp5 = n0_145 > 0 } else { if jrt.Double_InstanceOf(na_144) { var n0_145_2 float64 = jrt.NN(jrt.Double_Cast(na_144)).DoubleValue__D(); tmp5 = n0_145_2 > 0.0 } else { tmp5 = lang.Numbers_IsPos_O__Z_NoInit(na_144) } }
//line :183:1
				if tmp5 {

					var tmp6 int64; var na_146 any = m__10; var na_147 int64 = 16; if jrt.Long_InstanceOf(na_146) { var n0_148 int64 = jrt.NN(jrt.Long_Cast(na_146)).LongValue__J(); var n1_149 int64 = na_147; tmp6 = n0_148 >> (n1_149 & 63) } else { tmp6 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_146, na_147) }; var tmp7 int64 = tmp6; var tmp8 int64; var na_151 any = pending__9; var na_152 int64 = 16; if jrt.Long_InstanceOf(na_151) { var n0_153 int64 = jrt.NN(jrt.Long_Cast(na_151)).LongValue__J(); var n1_154 int64 = na_152; tmp8 = n0_153 >> (n1_154 & 63) } else { tmp8 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_151, na_152) }; if lang.Numbers_Gt_J_J__Z_NoInit(tmp7, tmp8) {

						jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(out__5), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(i__7)))).Ref()), 255))))
						i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), m__10; continue L1 } else {
//line :185:1
							var end__11 int64; var tmp9 int64 = lang.Numbers_Dec_J__J_NoInit(i__7); var tmp10 int64
							var na_156 any = pending__9
							var na_157 int64 = 16


							if jrt.Long_InstanceOf(na_156) { var n0_158 int64 = jrt.NN(jrt.Long_Cast(na_156)).LongValue__J(); var n1_159 int64 = na_157; tmp10 = n0_158 >> (n1_159 & 63) } else { tmp10 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_156, na_157) }; end__11 = lang.Numbers_Add_J_J__J_NoInit(tmp9, tmp10)
							var tmp11 *jrt.LongArray = jrt.LongArray_Cast(out__5); var tmp12 int32 = lang.RT_IntCast_J__I_NoInit(k__8); var tmp13 int64; var na_175 any = pending__9; var na_176 int64 = flag__6; if jrt.Long_InstanceOf(na_175) { var n0_177 int64 = jrt.NN(jrt.Long_Cast(na_175)).LongValue__J(); var n1_178 int64 = na_176; tmp13 = n0_177 | n1_178 } else { tmp13 = lang.Numbers_Or_O_J__J_NoInit(na_175, na_176) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp11, tmp12, tmp13))
//line :185:1
							var x__12 int64 = lang.Numbers_Inc_J__J_NoInit(i__7); L2: for {






								if lang.Numbers_Lt_J_J__Z_NoInit(x__12, end__11) { var root_180 any = A_arbace_j2g_zlib_A_const_23.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_180, A_arbace_j2g_zlib_insert_BANG__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = b__0; var arg_184 any = head__3; var arg_185 any = prev__4; var arg_186 int64 = x__12; if linked_181 == nil { ifn_182.Invoke_O_O_O_O__O(arg_183, arg_184, arg_185, jrt.Long_ValueOf_J__Long_NoInit(arg_186).Ref()) } else { linked_181.(*A_arbace_j2g_zlib_insert_BANG__A).InvokePrim_O_O_O_O_J__O(root_180, arg_183, arg_184, arg_185, arg_186) }; x__12 = lang.Numbers_Inc_J__J_NoInit(x__12); continue L2 }
//line :185:1
								break L2
							}






							i__7, k__8, pending__9 = end__11, lang.Numbers_Inc_J__J_NoInit(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } } else {
//line :183:1
								var tmp14 bool
								var na_161 any = m__10









								if jrt.Long_InstanceOf(na_161) { var n0_162 int64 = jrt.NN(jrt.Long_Cast(na_161)).LongValue__J(); tmp14 = n0_162 > 0 } else { if jrt.Double_InstanceOf(na_161) { var n0_162_2 float64 = jrt.NN(jrt.Double_Cast(na_161)).DoubleValue__D(); tmp14 = n0_162_2 > 0.0 } else { tmp14 = lang.Numbers_IsPos_O__Z_NoInit(na_161) } }
//line :183:1
								if tmp14 {










									i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), k__8, m__10; continue L1 } else {
//line :183:1
										if A_arbace_j2g_zlib_A_const_10 != nil {











											jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(out__5), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__7))).Ref()), 255))))
											i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } else {
//line :183:1
												return nil } } } } } }; /*line :164:1*/panic("j2g: unreachable") }







































func A_arbace_j2g_zlib_rle_lengths_A_New() *A_arbace_j2g_zlib_rle_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Invoke_O_O__O(self, ls__0 any) any { { var v__2 any; var root_187 any = A_arbace_j2g_zlib_A_const_24.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_189 lang.IFn


	if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = ls__0; if linked_188 == nil { v__2 = ifn_189.Invoke_O__O(arg_190) } else { v__2 = linked_188.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_187, arg_190) }
//line :204:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(v__2); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp1 bool; var na_191 any = i__4; var na_192 int64 = int64(n__3); if jrt.Long_InstanceOf(na_191) { var n0_193 int64 = jrt.NN(jrt.Long_Cast(na_191)).LongValue__J(); var n1_194 int64 = na_192; tmp1 = n0_193 >= n1_194 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_191, na_192) }; if tmp1 { return acc__5 } else { var x__6 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(v__2, lang.RT_IntCast_O__I_NoInit(i__4))); var run__7 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__209 any = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(i__4, n__3, x__6, v__2); var tmp3 *jrt.Class
			var fncls__208 /*line :209:1*/*jrt.Class = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class


			if fncls__208 == nil { var fncls__208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__209); A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class = fncls__208d; tmp3 = fncls__208d } else { tmp3 = fncls__208 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__209, tmp3, nil); run__7 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
			var tmp4 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)
			if and__1927000168__auto____8 { var na_210 any = run__7; var na_211 int64 = 11; if jrt.Long_InstanceOf(na_210) { var n0_212 int64 = jrt.NN(jrt.Long_Cast(na_210)).LongValue__J(); var n1_213 int64 = na_211; tmp4 = n0_212 >= n1_213 } else { tmp4 = lang.Numbers_Gte_O_J__Z_NoInit(na_210, na_211) } } else { tmp4 = and__1927000168__auto____8 }
//line :213:1
			if tmp4 { var r__8 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 138); var tmp5 jrt.Number_I; var na_227 any = i__4; var na_228 any = r__8; var tmp6 bool; var tmp7 bool
				tmp7 = jrt.Long_InstanceOf(na_227); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_228) }; tmp6 = tmp7; if tmp6 { var n0_229 int64 = jrt.NN(jrt.Long_Cast(na_227)).LongValue__J(); var n1_230 int64 = jrt.NN(jrt.Long_Cast(na_228)).LongValue__J(); var nr_231 int64 = n0_229 + n1_230; if (n0_229^nr_231)&(n1_230^nr_231) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_231)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_227, na_228) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_227); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_228) }; tmp8 = tmp9; if tmp8 { var n0_229_2 float64 = jrt.NN(jrt.Double_Cast(na_227)).DoubleValue__D(); var n1_230_2 float64 = jrt.NN(jrt.Double_Cast(na_228)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_229_2 + n1_230_2)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_227, na_228) } }; var tmp10 any = tmp5; var tmp11 any; var root_232 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = acc__5; var arg_236 any; var tmp12 any = A_arbace_j2g_zlib_A_const_25; var tmp13 jrt.Number_I; var na_237 any = r__8; var na_238 int64 = 11; if jrt.Long_InstanceOf(na_237) { var n0_239 int64 = jrt.NN(jrt.Long_Cast(na_237)).LongValue__J(); var n1_240 int64 = na_238; var nr_241 int64 = n0_239 - n1_240; var tmp14 bool; var tmp15 bool; tmp15 = !(n1_240 == -9223372036854775808); if tmp15 { tmp15 = (n0_239^n1_240)&(n0_239^nr_241) >= 0 }; tmp14 = tmp15; if tmp14 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_241)) } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_237, na_238) } } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_237, na_238) }; arg_236 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); if linked_233 == nil { tmp11 = ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { tmp11 = linked_233.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_232, arg_235, arg_236) }; i__4, acc__5 = tmp10, tmp11; continue L1 } else {
//line :213:1
					var tmp16 bool; var and__1927000168__auto____8_2 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)

					if and__1927000168__auto____8_2 { var na_215 any = run__7; var na_216 int64 = 3; if jrt.Long_InstanceOf(na_215) { var n0_217 int64 = jrt.NN(jrt.Long_Cast(na_215)).LongValue__J(); var n1_218 int64 = na_216; tmp16 = n0_217 >= n1_218 } else { tmp16 = lang.Numbers_Gte_O_J__Z_NoInit(na_215, na_216) } } else { tmp16 = and__1927000168__auto____8_2 }
//line :213:1
					if tmp16 { var r__8_2 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 10); var tmp17 jrt.Number_I; var na_242 any = i__4; var na_243 any = r__8_2; var tmp18 bool; var tmp19 bool

						tmp19 = jrt.Long_InstanceOf(na_242); if tmp19 { tmp19 = jrt.Long_InstanceOf(na_243) }; tmp18 = tmp19; if tmp18 { var n0_244 int64 = jrt.NN(jrt.Long_Cast(na_242)).LongValue__J(); var n1_245 int64 = jrt.NN(jrt.Long_Cast(na_243)).LongValue__J(); var nr_246 int64 = n0_244 + n1_245; if (n0_244^nr_246)&(n1_245^nr_246) >= 0 { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_246)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_242, na_243) } } else { var tmp20 bool; var tmp21 bool; tmp21 = jrt.Double_InstanceOf(na_242); if tmp21 { tmp21 = jrt.Double_InstanceOf(na_243) }; tmp20 = tmp21; if tmp20 { var n0_244_2 float64 = jrt.NN(jrt.Double_Cast(na_242)).DoubleValue__D(); var n1_245_2 float64 = jrt.NN(jrt.Double_Cast(na_243)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_244_2 + n1_245_2)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_242, na_243) } }; var tmp22 any = tmp17; var tmp23 any; var root_247 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = acc__5; var arg_251 any; var tmp24 any = A_arbace_j2g_zlib_A_const_26; var tmp25 jrt.Number_I; var na_252 any = r__8_2; var na_253 int64 = 3; if jrt.Long_InstanceOf(na_252) { var n0_254 int64 = jrt.NN(jrt.Long_Cast(na_252)).LongValue__J(); var n1_255 int64 = na_253; var nr_256 int64 = n0_254 - n1_255; var tmp26 bool; var tmp27 bool; tmp27 = !(n1_255 == -9223372036854775808); if tmp27 { tmp27 = (n0_254^n1_255)&(n0_254^nr_256) >= 0 }; tmp26 = tmp27; if tmp26 { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_256)) } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_252, na_253) } } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_252, na_253) }; arg_251 = lang.Tuple_Create_O_O__IPersistentVector(tmp24, tmp25); if linked_248 == nil { tmp23 = ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { tmp23 = linked_248.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) }; i__4, acc__5 = tmp22, tmp23; continue L1 } else {
//line :213:1
							var tmp28 bool; var and__1927000168__auto____8_3 bool = lang.Numbers_IsPos_J__Z_NoInit(x__6)


							if and__1927000168__auto____8_3 { var na_220 any = run__7; var na_221 int64 = 4; if jrt.Long_InstanceOf(na_220) { var n0_222 int64 = jrt.NN(jrt.Long_Cast(na_220)).LongValue__J(); var n1_223 int64 = na_221; tmp28 = n0_222 >= n1_223 } else { tmp28 = lang.Numbers_Gte_O_J__Z_NoInit(na_220, na_221) } } else { tmp28 = and__1927000168__auto____8_3 }
//line :213:1
							if tmp28 { var r__8_3 any; var tmp29 jrt.Number_I
								var na_225 any = run__7

								if jrt.Long_InstanceOf(na_225) { var n0_226 int64 = jrt.NN(jrt.Long_Cast(na_225)).LongValue__J(); if n0_226 == -9223372036854775808 { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_225) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_226 - 1)) } } else { if jrt.Double_InstanceOf(na_225) { var n0_226_2 float64 = jrt.NN(jrt.Double_Cast(na_225)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_226_2 - 1.0)) } else { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_225) } }; r__8_3 = lang.Numbers_Min_O_J__O_NoInit(tmp29, 6); var tmp30 jrt.Number_I; var na_257 any; var na_259 any = i__4; var na_260 int64 = 1; if jrt.Long_InstanceOf(na_259) { var n0_261 int64 = jrt.NN(jrt.Long_Cast(na_259)).LongValue__J(); var n1_262 int64 = na_260; var nr_263 int64 = n0_261 + n1_262; if (n0_261^nr_263)&(n1_262^nr_263) >= 0 { na_257 = jrt.Long_ValueOf_J__Long_NoInit(nr_263).Ref() } else { na_257 = lang.Numbers_Add_O_J__Number_NoInit(na_259, na_260) } } else { na_257 = lang.Numbers_Add_O_J__Number_NoInit(na_259, na_260) }; var na_258 any = r__8_3; var tmp31 bool; var tmp32 bool; tmp32 = jrt.Long_InstanceOf(na_257); if tmp32 { tmp32 = jrt.Long_InstanceOf(na_258) }; tmp31 = tmp32; if tmp31 { var n0_264 int64 = jrt.NN(jrt.Long_Cast(na_257)).LongValue__J(); var n1_265 int64 = jrt.NN(jrt.Long_Cast(na_258)).LongValue__J(); var nr_266 int64 = n0_264 + n1_265; if (n0_264^nr_266)&(n1_265^nr_266) >= 0 { tmp30 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_266)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_257, na_258) } } else { var tmp33 bool; var tmp34 bool; tmp34 = jrt.Double_InstanceOf(na_257); if tmp34 { tmp34 = jrt.Double_InstanceOf(na_258) }; tmp33 = tmp34; if tmp33 { var n0_264_2 float64 = jrt.NN(jrt.Double_Cast(na_257)).DoubleValue__D(); var n1_265_2 float64 = jrt.NN(jrt.Double_Cast(na_258)).DoubleValue__D(); tmp30 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_264_2 + n1_265_2)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_257, na_258) } }; var tmp35 any = tmp30; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_5.GetRawRoot__O()); var tmp37 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17); var tmp38 any = A_arbace_j2g_zlib_A_const_18; var tmp39 jrt.Number_I; var na_273 any = r__8_3; var na_274 int64 = 3; if jrt.Long_InstanceOf(na_273) { var n0_275 int64 = jrt.NN(jrt.Long_Cast(na_273)).LongValue__J(); var n1_276 int64 = na_274; var nr_277 int64 = n0_275 - n1_276; var tmp40 bool; var tmp41 bool; tmp41 = !(n1_276 == -9223372036854775808); if tmp41 { tmp41 = (n0_275^n1_276)&(n0_275^nr_277) >= 0 }; tmp40 = tmp41; if tmp40 { tmp39 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_277)) } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_273, na_274) } } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_273, na_274) }; i__4, acc__5 = tmp35, tmp36.Invoke_O_O_O__O(acc__5, tmp37, lang.Tuple_Create_O_O__IPersistentVector(tmp38, tmp39)); continue L1 } else {
//line :213:1
									if A_arbace_j2g_zlib_A_const_10 != nil {



										var tmp42 jrt.Number_I; var na_278 any = i__4; if jrt.Long_InstanceOf(na_278) { var n0_279 int64 = jrt.NN(jrt.Long_Cast(na_278)).LongValue__J(); if n0_279 == 9223372036854775807 { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_278) } else { tmp42 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_279 + 1)) } } else { if jrt.Double_InstanceOf(na_278) { var n0_279_2 float64 = jrt.NN(jrt.Double_Cast(na_278)).DoubleValue__D(); tmp42 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_279_2 + 1.0)) } else { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_278) } }; var tmp43 any = tmp42; var tmp44 any; var root_280 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = acc__5; var arg_284 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17); if linked_281 == nil { tmp44 = ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { tmp44 = linked_281.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }; i__4, acc__5 = tmp43, tmp44; continue L1 } else {
//line :213:1
											return nil } } } } } } }; /*line :204:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(p0 any, p1 int32, p2 int64, p3 any) *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A{}; t.Ctor_O_I_J_O(p0, p1, p2, p3); return t }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Ctor_O_I_J_O(c__i any, c__n int32, c__x int64, c__v any) { t.F_i = c__i; t.F_n = c__n; t.F_x = c__x; t.F_v = c__v }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Invoke_O__O(self any) any { { var j__1 any = t.F_i; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_196 any = j__1; var na_197 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_196) { var n0_198 int64 = jrt.NN(jrt.Long_Cast(na_196)).LongValue__J(); var n1_199 int64 = na_197; and__1927000168__auto____2 = n0_198 < n1_199 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_196, na_197) }; if and__1927000168__auto____2 { var tmp2 int64 = t.F_x; var tmp3 any = t.F_v; tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(tmp2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(j__1)))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp4 jrt.Number_I; var na_206 any = j__1; if jrt.Long_InstanceOf(na_206) { var n0_207 int64 = jrt.NN(jrt.Long_Cast(na_206)).LongValue__J(); if n0_207 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_206) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_207 + 1)) } } else { if jrt.Double_InstanceOf(na_206) { var n0_207_2 float64 = jrt.NN(jrt.Double_Cast(na_206)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_207_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_206) } }; j__1 = tmp4; continue L1 } else { var na_201 any = j__1; var na_202 any = t.F_i; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_201); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_202) }; tmp5 = tmp6; if tmp5 { var n0_203 int64 = jrt.NN(jrt.Long_Cast(na_201)).LongValue__J(); var n1_204 int64 = jrt.NN(jrt.Long_Cast(na_202)).LongValue__J(); var nr_205 int64 = n0_203 - n1_204; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_204 == -9223372036854775808); if tmp8 { tmp8 = (n0_203^n1_204)&(n0_203^nr_205) >= 0 }; tmp7 = tmp8; if tmp7 { return jrt.Long_ValueOf_J__Long_NoInit(nr_205).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_201, na_202) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_201); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_202) }; tmp9 = tmp10; if tmp9 { var n0_203_2 float64 = jrt.NN(jrt.Double_Cast(na_201)).DoubleValue__D(); var n1_204_2 float64 = jrt.NN(jrt.Double_Cast(na_202)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_203_2 + -n1_204_2).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_201, na_202) } } } } }; panic("j2g: unreachable") }






func A_arbace_j2g_zlib_write_block_BANG__A_New() *A_arbace_j2g_zlib_write_block_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Ctor() {}
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Invoke_O_O_O_O_O_O__O(self, w__0, syms__1, from__2, to__3, last_QMARK___4 any) any { var from__6 int64 = lang.RT_LongCast_O__J_NoInit(from__2); var to__7 int64 = lang.RT_LongCast_O__J_NoInit(to__3); var lf__8 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_27).Ref(); var df__9 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_28).Ref(); var i__10 int64 = from__6; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__10, to__7) { var s__11 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(syms__1), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__10))); var tmp1 any; var root_425 any = A_arbace_j2g_zlib_A_const_48.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_bit_test_A_fn_class); var ifn_427 lang.IFn

		if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = jrt.Long_ValueOf_J__Long_NoInit(s__11).Ref(); var arg_429 any = A_arbace_j2g_zlib_A_const_49; if linked_426 == nil { tmp1 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { tmp1 = linked_426.(*aot_arbace_core.A_arbace_core_bit_test_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; if jrt.J2g_Truth(tmp1) { var len__12 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__11, 16), 65535); var d__13 int64 = lang.Numbers_And_J_J__J_NoInit(s__11, 65535); var tmp2 *jrt.LongArray = jrt.LongArray_Cast(lf__8); var tmp3 int64; var root_440 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_440, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_442 lang.IFn

			if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_444 int64 = len__12; if linked_441 == nil { tmp3 = lang.RT_LongCast_O__J_NoInit(ifn_442.Invoke_O_O__O(arg_443, jrt.Long_ValueOf_J__Long_NoInit(arg_444).Ref())) } else { tmp3 = linked_441.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_440, arg_443, arg_444) }; var tmp4 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, tmp3)); var tmp5 *jrt.LongArray = jrt.LongArray_Cast(lf__8); var tmp6 int64; var root_445 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_445, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_449 int64 = len__12; if linked_446 == nil { tmp6 = lang.RT_LongCast_O__J_NoInit(ifn_447.Invoke_O_O__O(arg_448, jrt.Long_ValueOf_J__Long_NoInit(arg_449).Ref())) } else { tmp6 = linked_446.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_445, arg_448, arg_449) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, tmp4, lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, tmp6))))))
			var tmp7 *jrt.LongArray = jrt.LongArray_Cast(df__9); var tmp8 int64; var root_430 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_430, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_434 int64 = d__13; if linked_431 == nil { tmp8 = lang.RT_LongCast_O__J_NoInit(ifn_432.Invoke_O_O__O(arg_433, jrt.Long_ValueOf_J__Long_NoInit(arg_434).Ref())) } else { tmp8 = linked_431.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_430, arg_433, arg_434) }; var tmp9 int32 = lang.RT_IntCast_J__I_NoInit(tmp8); var tmp10 *jrt.LongArray = jrt.LongArray_Cast(df__9); var tmp11 int64; var root_435 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_435, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_439 int64 = d__13; if linked_436 == nil { tmp11 = lang.RT_LongCast_O__J_NoInit(ifn_437.Invoke_O_O__O(arg_438, jrt.Long_ValueOf_J__Long_NoInit(arg_439).Ref())) } else { tmp11 = linked_436.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_435, arg_438, arg_439) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp7, tmp9, lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp10, lang.RT_IntCast_J__I_NoInit(tmp11))))) } else {
				jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(lf__8), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lf__8), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)))))) }
		i__10 = lang.Numbers_Inc_J__J_NoInit(i__10); continue L1 }
//line :219:1
	break L1 };












	jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(lf__8), lang.RT_IntCast_J__I_NoInit(256), 1)); var used__10 int32; var tmp12 any; var root_414 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_416 lang.IFn; if














	linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any; var fnbody__420 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(df__9); var tmp13 *jrt.Class; var fncls__419 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class; if fncls__419 == nil { var fncls__419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__420); A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class = fncls__419d; tmp13 = fncls__419d } else { tmp13 = fncls__419 }; arg_417 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__420, tmp13, nil); var arg_418 any; var root_421 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = A_arbace_j2g_zlib_A_const_28; if linked_422 == nil { arg_418 = ifn_423.Invoke_O__O(arg_424) } else { arg_418 = linked_422.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_421, arg_424) }; if linked_415 == nil { tmp12 = ifn_416.Invoke_O_O__O(arg_417, arg_418) } else { tmp12 = linked_415.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_414, arg_417, arg_418) }; used__10 = lang.RT_Count_O__I_NoInit(tmp12); if
	lang.Numbers_IsZero_J__Z_NoInit(int64(used__10)) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(df__9), lang.RT_IntCast_J__I_NoInit(0), 1)); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.LongArray_Cast(df__9), lang.RT_IntCast_J__I_NoInit(1), 1)) } else { if lang.Numbers_Equiv_J_J__Z_NoInit(1, int64(used__10)) {
		var tmp14 *jrt.LongArray = jrt.LongArray_Cast(df__9); var tmp15 int64; if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(df__9), lang.RT_IntCast_J__I_NoInit(0))) { tmp15 = 1 } else { tmp15 = 0 }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp14, lang.RT_IntCast_J__I_NoInit(tmp15), 1)) } }; var ll__10 any; var root_285 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_285, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_287 lang.IFn; if

















	linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = lf__8; if linked_286 == nil { ll__10 = ifn_287.Invoke_O_O__O(arg_288, A_arbace_j2g_zlib_A_const_30) } else { ll__10 = linked_286.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_285, arg_288, 15) }; var dl__11 any; var root_290 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_290, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_292 lang.IFn; if


















	linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = df__9; if linked_291 == nil { dl__11 = ifn_292.Invoke_O_O__O(arg_293, A_arbace_j2g_zlib_A_const_30) } else { dl__11 = linked_291.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_290, arg_293, 15) }; var lc__12 any; var root_295 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_297 lang.IFn; if



















	linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = ll__10; if linked_296 == nil { lc__12 = ifn_297.Invoke_O__O(arg_298) } else { lc__12 = linked_296.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_295, arg_298) }; var dc__13 any; var root_299 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_301 lang.IFn; if




















	linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = dl__11; if linked_300 == nil { dc__13 = ifn_301.Invoke_O__O(arg_302) } else { dc__13 = linked_300.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_299, arg_302) }; var hlit__14 any; var tmp16 jrt.Number_I; var na_303 any; var or__1927000174__auto____14 any; var root_304 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_32.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_306 lang.IFn; if





















	linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any; var root_308 any = A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any; var fnbody__314 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(ll__10); var tmp17 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__314); A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class = fncls__313d; tmp17 = fncls__313d } else { tmp17 = fncls__313 }; arg_311 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__314, tmp17, nil); var arg_312 any; var root_315 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = A_arbace_j2g_zlib_A_const_34; if linked_316 == nil { arg_312 = ifn_317.Invoke_O__O(arg_318) } else { arg_312 = linked_316.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_315, arg_318) }; if linked_309 == nil { arg_307 = ifn_310.Invoke_O_O__O(arg_311, arg_312) } else { arg_307 = linked_309.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_308, arg_311, arg_312) }; if linked_305 == nil { or__1927000174__auto____14 = ifn_306.Invoke_O__O(arg_307) } else { or__1927000174__auto____14 = linked_305.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(or__1927000174__auto____14) { na_303 = or__1927000174__auto____14 } else { na_303 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_303) { var n0_319 int64 = jrt.NN(jrt.Long_Cast(na_303)).LongValue__J(); if n0_319 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_303) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_319 + 1)) } } else { if jrt.Double_InstanceOf(na_303) { var n0_319_2 float64 = jrt.NN(jrt.Double_Cast(na_303)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_319_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_303) } }; hlit__14 = lang.Numbers_Max_J_O__O_NoInit(257, tmp16); var hdist__15 any; var tmp18 jrt.Number_I; var na_320 any; var or__1927000174__auto____15 any; var root_321 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_32.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_323 lang.IFn; if






















	linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any; var root_325 any = A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any; var fnbody__331 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(dl__11); var tmp19 *jrt.Class; var fncls__330 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class; if fncls__330 == nil { var fncls__330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__331); A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class = fncls__330d; tmp19 = fncls__330d } else { tmp19 = fncls__330 }; arg_328 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__331, tmp19, nil); var arg_329 any; var root_332 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = A_arbace_j2g_zlib_A_const_28; if linked_333 == nil { arg_329 = ifn_334.Invoke_O__O(arg_335) } else { arg_329 = linked_333.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_332, arg_335) }; if linked_326 == nil { arg_324 = ifn_327.Invoke_O_O__O(arg_328, arg_329) } else { arg_324 = linked_326.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_325, arg_328, arg_329) }; if linked_322 == nil { or__1927000174__auto____15 = ifn_323.Invoke_O__O(arg_324) } else { or__1927000174__auto____15 = linked_322.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(or__1927000174__auto____15) { na_320 = or__1927000174__auto____15 } else { na_320 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_320) { var n0_336 int64 = jrt.NN(jrt.Long_Cast(na_320)).LongValue__J(); if n0_336 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_320) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_336 + 1)) } } else { if jrt.Double_InstanceOf(na_320) { var n0_336_2 float64 = jrt.NN(jrt.Double_Cast(na_320)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_336_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_320) } }; hdist__15 = lang.Numbers_Max_J_O__O_NoInit(1, tmp18); var rle__16 any; var root_337 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_35.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, A_arbace_j2g_zlib_rle_lengths_A_fn_class); var ifn_339 lang.IFn; if























	linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var root_341 any = A_arbace_j2g_zlib_A_const_36.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any; var root_346 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = hlit__14; var arg_350 any; var root_351 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_353 lang.IFn; if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = ll__10; if linked_352 == nil { arg_350 = ifn_353.Invoke_O__O(arg_354) } else { arg_350 = linked_352.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_351, arg_354) }; if linked_347 == nil { arg_344 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { arg_344 = linked_347.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) }; var arg_345 any; var root_355 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = hdist__15; var arg_359 any; var root_360 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = dl__11; if linked_361 == nil { arg_359 = ifn_362.Invoke_O__O(arg_363) } else { arg_359 = linked_361.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_360, arg_363) }; if linked_356 == nil { arg_345 = ifn_357.Invoke_O_O__O(arg_358, arg_359) } else { arg_345 = linked_356.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_355, arg_358, arg_359) }; if linked_342 == nil { arg_340 = ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { arg_340 = linked_342.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_341, arg_344, arg_345) }; if linked_338 == nil { rle__16 = ifn_339.Invoke_O__O(arg_340) } else { rle__16 = linked_338.(*A_arbace_j2g_zlib_rle_lengths_A).Invoke_O_O__O(root_337, arg_340) }; var cf__17 any = /*line :219:1*/lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_39).Ref(); var ___18 any; var tmp20 *lang.Compiler_AOTFn; var fnbody__393 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(cf__17, rle__16); var tmp21 *jrt.Class; var fncls__392 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class; _ = ___18; if

























	fncls__392 == nil { var fncls__392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__393); A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class = fncls__392d; tmp21 = fncls__392d } else { tmp21 = fncls__392 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__393, tmp21, nil); ___18 = Up_Compiler_AOTFn_IFn(tmp20).Invoke__O(); var cl__19 any; var root_394 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_394, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_396 lang.IFn; if


























	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = cf__17; if linked_395 == nil { cl__19 = ifn_396.Invoke_O_O__O(arg_397, A_arbace_j2g_zlib_A_const_44) } else { cl__19 = linked_395.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_394, arg_397, 7) }; var cc__20 any; var root_399 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_401 lang.IFn; if



























	linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = cl__19; if linked_400 == nil { cc__20 = ifn_401.Invoke_O__O(arg_402) } else { cc__20 = linked_400.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_399, arg_402) }; var hclen__21 int64; var tmp22 any; var root_403 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_405 lang.IFn; if




























	linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var fnbody__409 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(cl__19); var tmp23 *jrt.Class; var fncls__408 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class; if fncls__408 == nil { var fncls__408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__409); A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class = fncls__408d; tmp23 = fncls__408d } else { tmp23 = fncls__408 }; arg_406 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__409, tmp23, nil); var arg_407 any; var root_410 any = A_arbace_j2g_zlib_A_const_46.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = A_arbace_j2g_zlib_A_const_47.GetRawRoot__O(); if linked_411 == nil { arg_407 = ifn_412.Invoke_O__O(arg_413) } else { arg_407 = linked_411.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_410, arg_413) }; if linked_404 == nil { tmp22 = ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { tmp22 = linked_404.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_403, arg_406, arg_407) }; hclen__21 = lang.Numbers_Max_J_J__J_NoInit(4, lang.Numbers_Minus_J_J__J_NoInit(19, int64(lang.RT_Count_O__I_NoInit(tmp22)))); var tmp24 lang.IFn =
	lang.IFn_Cast(w__0); var tmp25 any; if jrt.J2g_Truth(last_QMARK___4) { tmp25 = A_arbace_j2g_zlib_A_const_53 } else { tmp25 = A_arbace_j2g_zlib_A_const_17 }; tmp24.Invoke_O_O__O(tmp25, A_arbace_j2g_zlib_A_const_53);
	lang.IFn_Cast(w__0).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_54, A_arbace_j2g_zlib_A_const_54); var tmp26 lang.IFn =
	lang.IFn_Cast(w__0); var tmp27 jrt.Number_I; var na_495 any = hlit__14; var na_496 int64 = 257; if jrt.Long_InstanceOf(na_495) { var n0_497 int64 = jrt.NN(jrt.Long_Cast(na_495)).LongValue__J(); var n1_498 int64 = na_496; var nr_499 int64 = n0_497 - n1_498; var tmp28 bool; var tmp29 bool; tmp29 = !(n1_498 == -9223372036854775808); if tmp29 { tmp29 = (n0_497^n1_498)&(n0_497^nr_499) >= 0 }; tmp28 = tmp29; if tmp28 { tmp27 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_499)) } else { tmp27 = lang.Numbers_Minus_O_J__Number_NoInit(na_495, na_496) } } else { tmp27 = lang.Numbers_Minus_O_J__Number_NoInit(na_495, na_496) }; tmp26.Invoke_O_O__O(tmp27, A_arbace_j2g_zlib_A_const_55); var tmp30 lang.IFn =
	lang.IFn_Cast(w__0); var tmp31 jrt.Number_I; var na_500 any = hdist__15; var na_501 int64 = 1; if jrt.Long_InstanceOf(na_500) { var n0_502 int64 = jrt.NN(jrt.Long_Cast(na_500)).LongValue__J(); var n1_503 int64 = na_501; var nr_504 int64 = n0_502 - n1_503; var tmp32 bool; var tmp33 bool; tmp33 = !(n1_503 == -9223372036854775808); if tmp33 { tmp33 = (n0_502^n1_503)&(n0_502^nr_504) >= 0 }; tmp32 = tmp33; if tmp32 { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_504)) } else { tmp31 = lang.Numbers_Minus_O_J__Number_NoInit(na_500, na_501) } } else { tmp31 = lang.Numbers_Minus_O_J__Number_NoInit(na_500, na_501) }; tmp30.Invoke_O_O__O(tmp31, A_arbace_j2g_zlib_A_const_55);
	lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(hclen__21, 4)).Ref(), A_arbace_j2g_zlib_A_const_56); var seq_1931000065__22 any; var root_450 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn; if


































	linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var root_454 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = jrt.Long_ValueOf_J__Long_NoInit(hclen__21).Ref(); var arg_458 any = A_arbace_j2g_zlib_A_const_47.GetRawRoot__O(); if linked_455 == nil { arg_453 = ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { arg_453 = linked_455.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_454, arg_457, arg_458) }; if linked_451 == nil { seq_1931000065__22 = ifn_452.Invoke_O__O(arg_453) } else { seq_1931000065__22 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }; var chunk_1931000066__23 any; var count_1931000067__24 int64 = 0; var i_1931000068__25 int64 = 0; L2:
//line :219:1
	for {


































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000068__25, count_1931000067__24) { var s__26 any = lang.Indexed_Cast(chunk_1931000066__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000068__25)); lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__26)))).Ref(), A_arbace_j2g_zlib_A_const_57); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000068__25); continue L2 } else { var temp__1927000414__auto____26 any; var root_459 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = seq_1931000065__22; if linked_460 == nil { temp__1927000414__auto____26 = ifn_461.Invoke_O__O(arg_462) } else { temp__1927000414__auto____26 = linked_460.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_459, arg_462) }; if jrt.J2g_Truth(temp__1927000414__auto____26) { var seq_1931000065__27 any = temp__1927000414__auto____26; var tmp34 any; var root_463 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = seq_1931000065__27; if linked_464 == nil { tmp34 = ifn_465.Invoke_O__O(arg_466) } else { tmp34 = linked_464.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_463, arg_466) }; if jrt.J2g_Truth(tmp34) { var c__1927000678__auto____28 any; var root_467 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = seq_1931000065__27; if linked_468 == nil { c__1927000678__auto____28 = ifn_469.Invoke_O__O(arg_470) } else { c__1927000678__auto____28 = linked_468.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_467, arg_470) }; var tmp35 any; var root_505 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = seq_1931000065__27; if linked_506 == nil { tmp35 = ifn_507.Invoke_O__O(arg_508) } else { tmp35 = linked_506.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_505, arg_508) }; seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = tmp35, c__1927000678__auto____28, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var s__28 any; var root_471 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = seq_1931000065__27; if linked_472 == nil { s__28 = ifn_473.Invoke_O__O(arg_474) } else { s__28 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__28)))).Ref(), A_arbace_j2g_zlib_A_const_57); var tmp36 any; var root_509 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = seq_1931000065__27; if linked_510 == nil { tmp36 = ifn_511.Invoke_O__O(arg_512) } else { tmp36 = linked_510.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_509, arg_512) }; seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = tmp36, nil, 0, 0; continue L2 } } }
//line :219:1
		break L2 }; var seq_1931000069__22 any; var root_475 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_477 lang.IFn; if



































	linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = rle__16; if linked_476 == nil { seq_1931000069__22 = ifn_477.Invoke_O__O(arg_478) } else { seq_1931000069__22 = linked_476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_475, arg_478) }; var chunk_1931000070__23 any; var count_1931000071__24 int64 = 0; var i_1931000072__25 int64 = 0; L3:
//line :219:1
	for {



































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000072__25, count_1931000071__24) { var vec__1931000073__26 any = lang.Indexed_Cast(chunk_1931000070__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000072__25)); var s__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(0), nil); var x__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(1), nil)
			lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cc__20), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref())
//line :255:1
			var G__1931000076__29_ int32 = lang.RT_IntCast_O__I_NoInit(s__27)

		L4: switch { default: switch G__1931000076__29_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_54); break L4; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_57); break L4; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_44); break L4; default:}}
//line :255:1
			seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000072__25); continue L3 } else { var temp__1927000414__auto____26_2 any; var root_479 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = seq_1931000069__22; if linked_480 == nil { temp__1927000414__auto____26_2 = ifn_481.Invoke_O__O(arg_482) } else { temp__1927000414__auto____26_2 = linked_480.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_479, arg_482) }; if jrt.J2g_Truth(temp__1927000414__auto____26_2) { var seq_1931000069__27 any = temp__1927000414__auto____26_2; var tmp37 any; var root_483 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = seq_1931000069__27; if linked_484 == nil { tmp37 = ifn_485.Invoke_O__O(arg_486) } else { tmp37 = linked_484.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_483, arg_486) }; if jrt.J2g_Truth(tmp37) { var c__1927000678__auto____28_2 any; var root_487 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = seq_1931000069__27; if linked_488 == nil { c__1927000678__auto____28_2 = ifn_489.Invoke_O__O(arg_490) } else { c__1927000678__auto____28_2 = linked_488.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_487, arg_490) }; var tmp38 any; var root_514 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = seq_1931000069__27; if linked_515 == nil { tmp38 = ifn_516.Invoke_O__O(arg_517) } else { tmp38 = linked_515.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_514, arg_517) }; seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = tmp38, c__1927000678__auto____28_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1931000077__28 any; var root_491 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = seq_1931000069__27; if linked_492 == nil { vec__1931000077__28 = ifn_493.Invoke_O__O(arg_494) } else { vec__1931000077__28 = linked_492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_491, arg_494) }; var s__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(0), nil); var x__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(1), nil)
				lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cc__20), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(cl__19), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref())
//line :255:1
				var G__1931000080__31_ int32 = lang.RT_IntCast_O__I_NoInit(s__29)

			L5: switch { default: switch G__1931000080__31_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_54); break L5; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_57); break L5; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_44); break L5; default:}}
//line :255:1
				var tmp39 any; var root_519 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = seq_1931000069__27; if linked_520 == nil { tmp39 = ifn_521.Invoke_O__O(arg_522) } else { tmp39 = linked_520.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_519, arg_522) }; seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = tmp39, nil, 0, 0; continue L3 } } }
//line :219:1
		break L3 }; var i__22 int64 = from__6; L6: for {







































			if lang.Numbers_Lt_J_J__Z_NoInit(i__22, to__7) { var s__23 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(syms__1), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__22))); var tmp40 any; var root_523 any = A_arbace_j2g_zlib_A_const_48.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_bit_test_A_fn_class); var ifn_525 lang.IFn

				if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = jrt.Long_ValueOf_J__Long_NoInit(s__23).Ref(); var arg_527 any = A_arbace_j2g_zlib_A_const_49; if linked_524 == nil { tmp40 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp40 = linked_524.(*aot_arbace_core.A_arbace_core_bit_test_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; if jrt.J2g_Truth(tmp40) { var len__24 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__23, 16), 65535); var d__25 int64 = lang.Numbers_And_J_J__J_NoInit(s__23, 65535); var lcode__26 any; var root_528 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_528, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_530 lang.IFn

					if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_532 int64 = len__24; if linked_529 == nil { lcode__26 = ifn_530.Invoke_O_O__O(arg_531, jrt.Long_ValueOf_J__Long_NoInit(arg_532).Ref()) } else { lcode__26 = jrt.Long_ValueOf_J__Long_NoInit(linked_529.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_528, arg_531, arg_532)).Ref() }
//line :261:1
					var dcode__27 any; var root_533 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_533, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_535 lang.IFn

					if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_537 int64 = d__25; if linked_534 == nil { dcode__27 = ifn_535.Invoke_O_O__O(arg_536, jrt.Long_ValueOf_J__Long_NoInit(arg_537).Ref()) } else { dcode__27 = jrt.Long_ValueOf_J__Long_NoInit(linked_534.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_533, arg_536, arg_537)).Ref() }
					var tmp41 lang.IFn = lang.IFn_Cast(w__0); var tmp42 *jrt.LongArray = jrt.LongArray_Cast(lc__12); var tmp43 jrt.Number_I; var na_538 int64 = 257; var na_539 any = lcode__26; if jrt.Long_InstanceOf(na_539) { var n0_540 int64 = na_538; var n1_541 int64 = jrt.NN(jrt.Long_Cast(na_539)).LongValue__J(); var nr_542 int64 = n0_540 + n1_541; if (n0_540^nr_542)&(n1_541^nr_542) >= 0 { tmp43 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_542)) } else { tmp43 = lang.Numbers_Add_J_O__Number_NoInit(na_538, na_539) } } else { tmp43 = lang.Numbers_Add_J_O__Number_NoInit(na_538, na_539) }; var tmp44 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp42, lang.RT_IntCast_O__I_NoInit(tmp43))).Ref(); var tmp45 *jrt.LongArray = jrt.LongArray_Cast(ll__10); var tmp46 jrt.Number_I; var na_543 int64 = 257; var na_544 any = lcode__26; if jrt.Long_InstanceOf(na_544) { var n0_545 int64 = na_543; var n1_546 int64 = jrt.NN(jrt.Long_Cast(na_544)).LongValue__J(); var nr_547 int64 = n0_545 + n1_546; if (n0_545^nr_547)&(n1_546^nr_547) >= 0 { tmp46 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_547)) } else { tmp46 = lang.Numbers_Add_J_O__Number_NoInit(na_543, na_544) } } else { tmp46 = lang.Numbers_Add_J_O__Number_NoInit(na_543, na_544) }; tmp41.Invoke_O_O__O(tmp44, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp45, lang.RT_IntCast_O__I_NoInit(tmp46))).Ref())
					if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_59.GetRawRoot__O()), lang.RT_IntCast_O__I_NoInit(lcode__26))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(len__24, lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_52.GetRawRoot__O()), lang.RT_IntCast_O__I_NoInit(lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_59.GetRawRoot__O()), lang.RT_IntCast_O__I_NoInit(lcode__26))).Ref()) }
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(dc__13), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(dl__11), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref())
					if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_58.GetRawRoot__O()), lang.RT_IntCast_O__I_NoInit(dcode__27))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(d__25, lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_51.GetRawRoot__O()), lang.RT_IntCast_O__I_NoInit(dcode__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(A_arbace_j2g_zlib_A_const_58.GetRawRoot__O()), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref()) } } else {
						lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lc__12), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(ll__10), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref()) }
				i__22 = lang.Numbers_Inc_J__J_NoInit(i__22); continue L6 }
//line :219:1
			break L6 }; return /*line :270:1*/ lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(lc__12), lang.RT_IntCast_J__I_NoInit(256))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.LongArray_Cast(ll__10), lang.RT_IntCast_J__I_NoInit(256))).Ref()) }
//line :234:1
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Ctor_O(c__df any) { t.F_df = c__df }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Invoke_O_O__O(self, p1__1931000041_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_df); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000041_SHARP___1))))).Ref() }






func A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Ctor_O(c__ll any) { t.F_ll = c__ll }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Invoke_O_O__O(self, p1__1931000042_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_ll); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000042_SHARP___1))))).Ref() }
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Ctor_O(c__dl any) { t.F_dl = c__dl }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Invoke_O_O__O(self, p1__1931000043_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_dl); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000043_SHARP___1))))).Ref() }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(p0, p1 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Ctor_O_O(c__cf, c__rle any) { t.F_cf = c__cf; t.F_rle = c__rle }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Invoke_O__O(self any) any { { var seq_1931000051__1 any; var root_364 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any; var t_ any = t.F_rle; t.F_rle = nil; arg_367 = t_; if linked_365 == nil { seq_1931000051__1 = ifn_366.Invoke_O__O(arg_367) } else { seq_1931000051__1 = linked_365.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_364, arg_367) }; var chunk_1931000052__2 any; var count_1931000053__3 int64 = 0; var i_1931000054__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000054__4, count_1931000053__3) { var vec__1931000056__5 any = lang.Indexed_Cast(chunk_1931000052__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000054__4)); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000056__5, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); var tmp2 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)))))); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000054__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_368 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = seq_1931000051__1; if linked_369 == nil { temp__1927000414__auto____5 = ifn_370.Invoke_O__O(arg_371) } else { temp__1927000414__auto____5 = linked_369.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_368, arg_371) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1931000051__6 any = temp__1927000414__auto____5; var tmp3 any; var root_372 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = seq_1931000051__6; if linked_373 == nil { tmp3 = ifn_374.Invoke_O__O(arg_375) } else { tmp3 = linked_373.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_372, arg_375) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____7 any; var root_376 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = seq_1931000051__6; if linked_377 == nil { c__1927000678__auto____7 = ifn_378.Invoke_O__O(arg_379) } else { c__1927000678__auto____7 = linked_377.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_376, arg_379) }; var tmp4 any; var root_384 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = seq_1931000051__6; if linked_385 == nil { tmp4 = ifn_386.Invoke_O__O(arg_387) } else { tmp4 = linked_385.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_384, arg_387) }; seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = tmp4, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1931000059__7 any; var root_380 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = seq_1931000051__6; if linked_381 == nil { vec__1931000059__7 = ifn_382.Invoke_O__O(arg_383) } else { vec__1931000059__7 = linked_381.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_380, arg_383) }; var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000059__7, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp5 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); var tmp6 *jrt.LongArray = jrt.LongArray_Cast(t.F_cf); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp5, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp6, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)))))); var tmp7 any; var root_388 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = seq_1931000051__6; if linked_389 == nil { tmp7 = ifn_390.Invoke_O__O(arg_391) } else { tmp7 = linked_389.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_388, arg_391) }; seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Invoke_O_O__O(self, p1__1931000044_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.LongArray_Cast(t.F_cl); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000044_SHARP___1))))).Ref() }























func A_arbace_j2g_zlib_adler32_A_New() *A_arbace_j2g_zlib_adler32_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_adler32_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Ctor() {}
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) InvokePrim_O_O__J(self, b__0 any) int64 { { var i__2 int64 = 0; var a__3 int64 = 1; var s__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__2, int64(lang.RT_Alength_B1__I_NoInit(jrt.ByteArray_Cast(b__0)))) { var a__5 int64 = lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(a__3, lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.ByteArray_Cast(b__0), lang.RT_IntCast_J__I_NoInit(i__2))).Ref()), 255)), 65521)

		i__2, a__3, s__4 = lang.Numbers_Inc_J__J_NoInit(i__2), a__5, lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(s__4, a__5), 65521); continue L1 } else {
			return lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(s__4, 16), a__3) } } }; /*line :272:1*/panic("j2g: unreachable") }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Invoke_O_O__O(self, b__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, b__0)).Ref() }






func A_arbace_j2g_zlib_deflate_A_New() *A_arbace_j2g_zlib_deflate_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_deflate_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Invoke_O_O__O(self, b__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var w__3 any = A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__2, 0, 0); var vec__1931000083__4 any; var root_548 any = A_arbace_j2g_zlib_A_const_60.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, A_arbace_j2g_zlib_lz77_A_fn_class); var ifn_550 lang.IFn; if






	linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = b__0; if linked_549 == nil { vec__1931000083__4 = ifn_550.Invoke_O__O(arg_551) } else { vec__1931000083__4 = linked_549.(*A_arbace_j2g_zlib_lz77_A).Invoke_O_O__O(root_548, arg_551) }; var syms__5 any = /*line :279:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 int64 = lang.RT_LongCast_O__J_NoInit(k__6);








	jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(120)); jrt.ByteArrayOutputStream_Cast(out__2).Write_I__V(lang.RT_IntCast_J__I_NoInit(218)); if
	lang.Numbers_IsZero_J__Z_NoInit(k__7) {
		var root_552 any = A_arbace_j2g_zlib_A_const_61.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_j2g_zlib_write_block_BANG__A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = w__3; var arg_556 any = syms__5; var arg_557 any = A_arbace_j2g_zlib_A_const_17; var arg_558 any = A_arbace_j2g_zlib_A_const_17; var arg_559 any = jrt.Boolean_TRUE.Ref(); if linked_553 == nil { ifn_554.Invoke_O_O_O_O_O__O(arg_555, arg_556, arg_557, arg_558, arg_559) } else { linked_553.(*A_arbace_j2g_zlib_write_block_BANG__A).Invoke_O_O_O_O_O_O__O(root_552, arg_555, arg_556, arg_557, arg_558, arg_559) } } else {
//line :289:1
			var from__8 int64 = 0; L1: for { var to__9 int64 = lang.Numbers_Min_J_J__J_NoInit(k__7, lang.Numbers_Add_J_J__J_NoInit(from__8, 16384)); var root_584 any = A_arbace_j2g_zlib_A_const_61.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, A_arbace_j2g_zlib_write_block_BANG__A_fn_class); var ifn_586 lang.IFn



				if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = w__3; var arg_588 any = syms__5; var arg_589 any = jrt.Long_ValueOf_J__Long_NoInit(from__8).Ref(); var arg_590 any = jrt.Long_ValueOf_J__Long_NoInit(to__9).Ref(); var arg_591 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(to__9, k__7)).Ref(); if linked_585 == nil { ifn_586.Invoke_O_O_O_O_O__O(arg_587, arg_588, arg_589, arg_590, arg_591) } else { linked_585.(*A_arbace_j2g_zlib_write_block_BANG__A).Invoke_O_O_O_O_O_O__O(root_584, arg_587, arg_588, arg_589, arg_590, arg_591) }
				if lang.Numbers_Lt_J_J__Z_NoInit(to__9, k__7) { from__8 = to__9; continue L1 }
//line :289:1
				break L1 } };





	lang.IFn_Cast(w__3).Invoke__O(); var a__8 any; var root_560 any = /*line :279:1*/A_arbace_j2g_zlib_A_const_62.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_560, A_arbace_j2g_zlib_adler32_A_fn_class); var ifn_562 lang.IFn; if
















	linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = b__0; if linked_561 == nil { a__8 = ifn_562.Invoke_O__O(arg_563) } else { a__8 = jrt.Long_ValueOf_J__Long_NoInit(linked_561.(*A_arbace_j2g_zlib_adler32_A).InvokePrim_O_O__J(root_560, arg_563)).Ref() }; var seq_1931000086__9 any; var root_564 any = /*line :279:1*/A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_566 lang.IFn; if

















	linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = A_arbace_j2g_zlib_A_const_63; if linked_565 == nil { seq_1931000086__9 = ifn_566.Invoke_O__O(arg_567) } else { seq_1931000086__9 = linked_565.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_564, arg_567) }; var chunk_1931000087__10 any; var count_1931000088__11 int64 = 0; var i_1931000089__12 int64 = 0; L2:
//line :279:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000089__12, count_1931000088__11) { var sh__13 any = lang.Indexed_Cast(chunk_1931000087__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000089__12)); var tmp1 jrt.ByteArrayOutputStream_I = jrt.ByteArrayOutputStream_Cast(out__2); var tmp2 int64; var na_592 any = a__8; var na_593 any = sh__13; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_592); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_593) }; tmp3 = tmp4; if tmp3 { var n0_594 int64 = jrt.NN(jrt.Long_Cast(na_592)).LongValue__J(); var n1_595 int64 = jrt.NN(jrt.Long_Cast(na_593)).LongValue__J(); tmp2 = n0_594 >> (n1_595 & 63) } else { tmp2 = lang.Numbers_ShiftRight_O_O__J_NoInit(na_592, na_593) }; tmp1.Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp2, 255))); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000089__12); continue L2 } else { var temp__1927000414__auto____13 any; var root_568 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = seq_1931000086__9; if linked_569 == nil { temp__1927000414__auto____13 = ifn_570.Invoke_O__O(arg_571) } else { temp__1927000414__auto____13 = linked_569.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_568, arg_571) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1931000086__14 any = temp__1927000414__auto____13; var tmp5 any; var root_572 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = seq_1931000086__14; if linked_573 == nil { tmp5 = ifn_574.Invoke_O__O(arg_575) } else { tmp5 = linked_573.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_572, arg_575) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____15 any; var root_576 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = seq_1931000086__14; if linked_577 == nil { c__1927000678__auto____15 = ifn_578.Invoke_O__O(arg_579) } else { c__1927000678__auto____15 = linked_577.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_576, arg_579) }; var tmp6 any; var root_597 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = seq_1931000086__14; if linked_598 == nil { tmp6 = ifn_599.Invoke_O__O(arg_600) } else { tmp6 = linked_598.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_597, arg_600) }; seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = tmp6, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var sh__15 any; var root_580 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = seq_1931000086__14; if linked_581 == nil { sh__15 = ifn_582.Invoke_O__O(arg_583) } else { sh__15 = linked_581.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_580, arg_583) }; var tmp7 jrt.ByteArrayOutputStream_I = jrt.ByteArrayOutputStream_Cast(out__2); var tmp8 int64; var na_601 any = a__8; var na_602 any = sh__15; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_601); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_602) }; tmp9 = tmp10; if tmp9 { var n0_603 int64 = jrt.NN(jrt.Long_Cast(na_601)).LongValue__J(); var n1_604 int64 = jrt.NN(jrt.Long_Cast(na_602)).LongValue__J(); tmp8 = n0_603 >> (n1_604 & 63) } else { tmp8 = lang.Numbers_ShiftRight_O_O__J_NoInit(na_601, na_602) }; tmp7.Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp8, 255))); var tmp11 any; var root_606 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = seq_1931000086__14; if linked_607 == nil { tmp11 = ifn_608.Invoke_O__O(arg_609) } else { tmp11 = linked_607.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_606, arg_609) }; seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = tmp11, nil, 0, 0; continue L2 } } }
//line :279:1
		break L2 }; return /*line :298:1*/ jrt.ByteArrayOutputStream_Cast(out__2).ToByteArray__B1().Ref() }
//line :287:1
type A_arbace_j2g_zlib_A struct{ jrt.Object }

var A_arbace_j2g_zlib_A_const_pool *jrt.RefArray

var A_arbace_j2g_zlib_A_const_0 *lang.Var

var A_arbace_j2g_zlib_A_const_1 any

var A_arbace_j2g_zlib_A_const_2 *lang.Var

var A_arbace_j2g_zlib_A_const_3 *lang.Var

var A_arbace_j2g_zlib_A_const_4 *lang.Var

var A_arbace_j2g_zlib_A_const_5 *lang.Var

var A_arbace_j2g_zlib_A_const_6 any

var A_arbace_j2g_zlib_A_const_7 *lang.Var

var A_arbace_j2g_zlib_A_const_8 *lang.Var

var A_arbace_j2g_zlib_A_const_9 *lang.Var

var A_arbace_j2g_zlib_A_const_10 *lang.Keyword

var A_arbace_j2g_zlib_A_const_11 *lang.Var

var A_arbace_j2g_zlib_A_const_12 *lang.Var

var A_arbace_j2g_zlib_A_const_13 *lang.Var

var A_arbace_j2g_zlib_A_const_14 *lang.Var

var A_arbace_j2g_zlib_A_const_15 *lang.Var

var A_arbace_j2g_zlib_A_const_16 *lang.Var

var A_arbace_j2g_zlib_A_const_17 any

var A_arbace_j2g_zlib_A_const_18 any

var A_arbace_j2g_zlib_A_const_19 *lang.Var

var A_arbace_j2g_zlib_A_const_20 *lang.Var

var A_arbace_j2g_zlib_A_const_21 any

var A_arbace_j2g_zlib_A_const_22 *lang.Var

var A_arbace_j2g_zlib_A_const_23 *lang.Var

var A_arbace_j2g_zlib_A_const_24 *lang.Var

var A_arbace_j2g_zlib_A_const_25 any

var A_arbace_j2g_zlib_A_const_26 any

var A_arbace_j2g_zlib_A_const_27 any

var A_arbace_j2g_zlib_A_const_28 any

var A_arbace_j2g_zlib_A_const_29 *lang.Var

var A_arbace_j2g_zlib_A_const_30 any

var A_arbace_j2g_zlib_A_const_31 *lang.Var

var A_arbace_j2g_zlib_A_const_32 *lang.Var

var A_arbace_j2g_zlib_A_const_33 *lang.Var

var A_arbace_j2g_zlib_A_const_34 any

var A_arbace_j2g_zlib_A_const_35 *lang.Var

var A_arbace_j2g_zlib_A_const_36 *lang.Var

var A_arbace_j2g_zlib_A_const_37 *lang.Var

var A_arbace_j2g_zlib_A_const_38 *lang.Var

var A_arbace_j2g_zlib_A_const_39 any

var A_arbace_j2g_zlib_A_const_40 *lang.Var

var A_arbace_j2g_zlib_A_const_41 *lang.Var

var A_arbace_j2g_zlib_A_const_42 *lang.Var

var A_arbace_j2g_zlib_A_const_43 *lang.Var

var A_arbace_j2g_zlib_A_const_44 any

var A_arbace_j2g_zlib_A_const_45 *lang.Var

var A_arbace_j2g_zlib_A_const_46 *lang.Var

var A_arbace_j2g_zlib_A_const_47 *lang.Var

var A_arbace_j2g_zlib_A_const_48 *lang.Var

var A_arbace_j2g_zlib_A_const_49 any

var A_arbace_j2g_zlib_A_const_50 *lang.Var

var A_arbace_j2g_zlib_A_const_51 *lang.Var

var A_arbace_j2g_zlib_A_const_52 *lang.Var

var A_arbace_j2g_zlib_A_const_53 any

var A_arbace_j2g_zlib_A_const_54 any

var A_arbace_j2g_zlib_A_const_55 any

var A_arbace_j2g_zlib_A_const_56 any

var A_arbace_j2g_zlib_A_const_57 any

var A_arbace_j2g_zlib_A_const_58 *lang.Var

var A_arbace_j2g_zlib_A_const_59 *lang.Var

var A_arbace_j2g_zlib_A_const_60 *lang.Var

var A_arbace_j2g_zlib_A_const_61 *lang.Var

var A_arbace_j2g_zlib_A_const_62 *lang.Var

var A_arbace_j2g_zlib_A_const_63 any

var A_arbace_j2g_zlib_A_init jrt.ClassInit

func A_arbace_j2g_zlib_A_Init() { if !A_arbace_j2g_zlib_A_init.Done() { A_arbace_j2g_zlib_A_init.Run(A_arbace_j2g_zlib_A_clinit) } }

func A_arbace_j2g_zlib_A_clinit() { A_arbace_j2g_zlib_A_clinit_p0(); A_arbace_j2g_zlib_A_clinit_p1(); A_arbace_j2g_zlib_A_clinit_p2(); A_arbace_j2g_zlib_A_clinit_p3(); A_arbace_j2g_zlib_A_clinit_p4(); A_arbace_j2g_zlib_A_clinit_p5() }

func A_arbace_j2g_zlib_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_zlib_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 67); A_arbace_j2g_zlib_A_const_0 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[3]); A_arbace_j2g_zlib_A_const_1 = A_arbace_j2g_zlib_A_const_pool.A[4]; A_arbace_j2g_zlib_A_const_2 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[5]); A_arbace_j2g_zlib_A_const_3 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[6]); A_arbace_j2g_zlib_A_const_4 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[7]); A_arbace_j2g_zlib_A_const_5 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[8]); A_arbace_j2g_zlib_A_const_6 = A_arbace_j2g_zlib_A_const_pool.A[9]; A_arbace_j2g_zlib_A_const_7 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[10]); A_arbace_j2g_zlib_A_const_8 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[11]); A_arbace_j2g_zlib_A_const_9 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[12]); A_arbace_j2g_zlib_A_const_10 = lang.Keyword_Cast(A_arbace_j2g_zlib_A_const_pool.A[13]) }

func A_arbace_j2g_zlib_A_clinit_p1() { A_arbace_j2g_zlib_A_const_11 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[14]); A_arbace_j2g_zlib_A_const_12 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[15]); A_arbace_j2g_zlib_A_const_13 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[16]); A_arbace_j2g_zlib_A_const_14 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[17]); A_arbace_j2g_zlib_A_const_15 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[18]); A_arbace_j2g_zlib_A_const_16 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[19]); A_arbace_j2g_zlib_A_const_17 = A_arbace_j2g_zlib_A_const_pool.A[20]; A_arbace_j2g_zlib_A_const_18 = A_arbace_j2g_zlib_A_const_pool.A[21]; A_arbace_j2g_zlib_A_const_19 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[22]); A_arbace_j2g_zlib_A_const_20 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[23]); A_arbace_j2g_zlib_A_const_21 = A_arbace_j2g_zlib_A_const_pool.A[24]; A_arbace_j2g_zlib_A_const_22 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[25]) }

func A_arbace_j2g_zlib_A_clinit_p2() { A_arbace_j2g_zlib_A_const_23 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[26]); A_arbace_j2g_zlib_A_const_24 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[27]); A_arbace_j2g_zlib_A_const_25 = A_arbace_j2g_zlib_A_const_pool.A[28]; A_arbace_j2g_zlib_A_const_26 = A_arbace_j2g_zlib_A_const_pool.A[29]; A_arbace_j2g_zlib_A_const_27 = A_arbace_j2g_zlib_A_const_pool.A[30]; A_arbace_j2g_zlib_A_const_28 = A_arbace_j2g_zlib_A_const_pool.A[31]; A_arbace_j2g_zlib_A_const_29 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[32]); A_arbace_j2g_zlib_A_const_30 = A_arbace_j2g_zlib_A_const_pool.A[33]; A_arbace_j2g_zlib_A_const_31 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[34]); A_arbace_j2g_zlib_A_const_32 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[35]); A_arbace_j2g_zlib_A_const_33 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[36]); A_arbace_j2g_zlib_A_const_34 = A_arbace_j2g_zlib_A_const_pool.A[37]; A_arbace_j2g_zlib_A_const_35 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[38]) }

func A_arbace_j2g_zlib_A_clinit_p3() { A_arbace_j2g_zlib_A_const_36 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[39]); A_arbace_j2g_zlib_A_const_37 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[40]); A_arbace_j2g_zlib_A_const_38 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[41]); A_arbace_j2g_zlib_A_const_39 = A_arbace_j2g_zlib_A_const_pool.A[42]; A_arbace_j2g_zlib_A_const_40 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[43]); A_arbace_j2g_zlib_A_const_41 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[44]); A_arbace_j2g_zlib_A_const_42 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[45]); A_arbace_j2g_zlib_A_const_43 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[46]); A_arbace_j2g_zlib_A_const_44 = A_arbace_j2g_zlib_A_const_pool.A[47]; A_arbace_j2g_zlib_A_const_45 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[48]); A_arbace_j2g_zlib_A_const_46 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[49]); A_arbace_j2g_zlib_A_const_47 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[50]) }

func A_arbace_j2g_zlib_A_clinit_p4() { A_arbace_j2g_zlib_A_const_48 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[51]); A_arbace_j2g_zlib_A_const_49 = A_arbace_j2g_zlib_A_const_pool.A[52]; A_arbace_j2g_zlib_A_const_50 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[53]); A_arbace_j2g_zlib_A_const_51 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[54]); A_arbace_j2g_zlib_A_const_52 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[55]); A_arbace_j2g_zlib_A_const_53 = A_arbace_j2g_zlib_A_const_pool.A[56]; A_arbace_j2g_zlib_A_const_54 = A_arbace_j2g_zlib_A_const_pool.A[57]; A_arbace_j2g_zlib_A_const_55 = A_arbace_j2g_zlib_A_const_pool.A[58]; A_arbace_j2g_zlib_A_const_56 = A_arbace_j2g_zlib_A_const_pool.A[59]; A_arbace_j2g_zlib_A_const_57 = A_arbace_j2g_zlib_A_const_pool.A[60]; A_arbace_j2g_zlib_A_const_58 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[61]); A_arbace_j2g_zlib_A_const_59 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[62]); A_arbace_j2g_zlib_A_const_60 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[63]) }

func A_arbace_j2g_zlib_A_clinit_p5() { A_arbace_j2g_zlib_A_const_61 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[64]); A_arbace_j2g_zlib_A_const_62 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[65]); A_arbace_j2g_zlib_A_const_63 = A_arbace_j2g_zlib_A_const_pool.A[66] }

func A_arbace_j2g_zlib_A_New() *A_arbace_j2g_zlib_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_A) Ctor() {}

func (t *A_arbace_j2g_zlib_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_A_class }

func (t *A_arbace_j2g_zlib_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_A); return ok }

func A_arbace_j2g_zlib_A_Cast(x any) *A_arbace_j2g_zlib_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_A_class)) }; return v }



type A_arbace_j2g_zlib_adler32_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_adler32_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_canonical_codes_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_canonical_codes_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_code_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_code_of_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_deflate_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_deflate_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000004_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000004_A_New() *A_arbace_j2g_zlib_eval1931000004_A { t := &A_arbace_j2g_zlib_eval1931000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000004_A_class }

func (t *A_arbace_j2g_zlib_eval1931000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); return ok }

func A_arbace_j2g_zlib_eval1931000004_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000004_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000008_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000008_A_New() *A_arbace_j2g_zlib_eval1931000008_A { t := &A_arbace_j2g_zlib_eval1931000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000008_A_class }

func (t *A_arbace_j2g_zlib_eval1931000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); return ok }

func A_arbace_j2g_zlib_eval1931000008_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000008_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000012_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000012_A_New() *A_arbace_j2g_zlib_eval1931000012_A { t := &A_arbace_j2g_zlib_eval1931000012_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000012_A_class }

func (t *A_arbace_j2g_zlib_eval1931000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); return ok }

func A_arbace_j2g_zlib_eval1931000012_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000012_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_huffman_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A struct{ j2g_header uint64; F_parent any; F_n int32; F_start any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A struct{ j2g_header uint64; F_parent, F_lens any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A struct{ j2g_header uint64; F_parent, F_s any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_insert_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_insert_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_longest_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_longest_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_lz77_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_lz77_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_match_length_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_match_length_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_reverse_bits_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_reverse_bits_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_rle_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A struct{ j2g_header uint64; F_i any; F_n int32; F_x int64; F_v any }

var A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_write_block_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A struct{ j2g_header uint64; F_df any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A struct{ j2g_header uint64; F_ll any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A struct{ j2g_header uint64; F_dl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A struct{ j2g_header uint64; F_cf, F_rle any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A struct{ j2g_header uint64; F_cl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class *jrt.Class
