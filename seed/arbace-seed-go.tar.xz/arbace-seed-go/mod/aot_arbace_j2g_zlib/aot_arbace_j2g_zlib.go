//line aot_arbace_j2g_zlib.ae:1
package aot_arbace_j2g_zlib

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_New() *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_zlib_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_New() *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_zlib_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_6), A_arbace_j2g_zlib_A_const_4.GetRawRoot__O(), A_arbace_j2g_zlib_A_const_5) }

















func A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_New() *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Invoke_O_O_O_O__O(self, out__1, acc__2, n__3 any) any { return A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__1, lang.RT_LongCast_O__J_NoInit(acc__2), lang.RT_LongCast_O__J_NoInit(n__3)) }



















func A_arbace_j2g_zlib_reverse_bits_A_New() *A_arbace_j2g_zlib_reverse_bits_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_reverse_bits_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Invoke_O_O_O__O(self, p_code__0, p_len__1 any) any { var code__0 int64 = lang.RT_LongCast_O__J_NoInit(p_code__0); var len__1 int64 = lang.RT_LongCast_O__J_NoInit(p_len__1); var tmp1 int64; var c__3 int64 = code__0; var r__4 int64 = 0; var i__5 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, len__1) { c__3, r__4, i__5 = lang.Numbers_ShiftRight_J_J__J_NoInit(c__3, 1), lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(r__4, 1), lang.Numbers_And_J_J__J_NoInit(c__3, 1)), lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else { tmp1 = r__4 }
//line :39:1
	break L1 }; return jrt.Long_ValueOf_J__Long_NoInit(tmp1).Ref() }






func A_arbace_j2g_zlib_huffman_lengths_A_New() *A_arbace_j2g_zlib_huffman_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Ctor() {}
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Invoke_O_O_O__O(self, freqs__0, p_limit__1 any) any { { var limit__1 int64 = lang.RT_LongCast_O__J_NoInit(p_limit__1); var n__3 int32 = lang.RT_Alength_J1__I_NoInit(jrt.J2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())); var fs__4 any = lang.RT_Aclone_J1__J1_NoInit(jrt.J2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())).Ref(); L1: for { var syms__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(fs__4); var tmp3 *jrt.Class
													var fncls__7 /*line :46:1*/*jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class






	if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; syms__5 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()))
//line :46:1
	var lens__6 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref()








	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_8.GetRawRoot__O()).Invoke_O__O(syms__5)) { return lens__6 } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(syms__5))) {

		jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lens__6, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(syms__5))), 1))
//line :55:1
		return lens__6 } else { if A_arbace_j2g_zlib_A_const_9 != nil { var parent__7 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, int64(n__3))).Ref()).Ref(); var start__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_10.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_15.GetRawRoot__O()).Invoke__O(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_16.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(fs__4); var tmp8 *jrt.Class
			var fncls__8 /*line :55:1*/*jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class






			if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class = fncls__8d; tmp8 = fncls__8d } else { tmp8 = fncls__8 }; start__8 = tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), syms__5))
//line :55:1
			var ___9 any; var tmp9 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(parent__7, n__3, start__8); var tmp10 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class; _ = ___9







			if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class = fncls__1d; tmp10 = fncls__1d } else { tmp10 = fncls__1 }; ___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :55:1
			var root__10 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(n__3), lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(syms__5)))), -1); var maxlen__11 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_13.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(parent__7, lens__6, root__10); var tmp13 *jrt.Class
			var fncls__10 /*line :55:1*/*jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class















			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class = fncls__10d; tmp13 = fncls__10d } else { tmp13 = fncls__10 }; maxlen__11 = tmp11.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_j2g_zlib_A_const_17, syms__5)




			var tmp14 bool; var na_2 any = maxlen__11; var na_3 int64 = limit__1; if jrt.Long_InstanceOf(na_2) { var n0_4 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); var n1_5 int64 = na_3; tmp14 = n0_4 <= n1_5 } else { tmp14 = lang.Numbers_Lte_O_J__Z_NoInit(na_2, na_3) }; if tmp14 { return lens__6 } else { var f2__12 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J_NoInit(n__3); var i__14 int64 = 0; L2: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i__14, n__1927000701__auto____13) { var f__15 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](fs__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__14))
					if lang.Numbers_IsPos_J__Z_NoInit(f__15) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](f2__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__14), lang.Numbers_Max_J_J__J_NoInit(1, lang.Numbers_ShiftRight_J_J__J_NoInit(f__15, 1)))) }
//line :79:1
					i__14 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__14); continue L2 }
//line :76:1
				break L2
			}



				fs__4 = f2__12; continue L1 } } else {
//line :55:1
					return nil } } } } }; /*line :46:1*/panic("j2g: unreachable") }






func A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Invoke_O_O__O(self, p1__1931000018_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000018_SHARP___1))))).Ref() }








func A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__1)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref()) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Ctor_O_I_O(c__parent any, c__n int32, c__start any) { t.F_parent = c__parent; t.F_n = c__n; t.F_start = c__start }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Invoke_O__O(self any) any { { var q__1 any; var t_ any = t.F_start; t.F_start = nil; q__1 = t_; var next_id__2 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); var order__3 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); L1: for {
											if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(q__1)), 1) { var a__4 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(q__1); var q__5 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_12.GetRawRoot__O()).Invoke_O_O__O(q__1, a__4); var b__6 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(q__5); var q__7 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_12.GetRawRoot__O()).Invoke_O_O__O(q__5, b__6); var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass())

		jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		q__1, next_id__2, order__3 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()).Invoke_O_O__O(q__7, lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(0))), lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(0))))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(order__3).Ref(), jrt.Long_ValueOf_J__Long_NoInit(next_id__2).Ref())), lang.Numbers_Inc_J__J_NoInit(next_id__2), lang.Numbers_Inc_J__J_NoInit(order__3); continue L1 } else {
//line :64:1
			return nil } } }; /*line :63:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Ctor_O_O_J(c__parent, c__lens any, c__root int64) { t.F_parent = c__parent; t.F_lens = c__lens; t.F_root = c__root }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Invoke_O_O_O__O(self, p_m__1, s__2 any) any { var m__1 int64 = lang.RT_LongCast_O__J_NoInit(p_m__1); var d__3 int64; var tmp1 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(t.F_parent, s__2, t.F_root); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class; if
														fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; d__3 = lang.RT_LongCast_O__J_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()); var tmp3 /*line :73:1*/*jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_lens, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp3, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__2)), d__3)); return /*line :74:1*/ jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(m__1, d__3)).Ref() }
//line :72:1
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Ctor_O_O_J(c__parent, c__s any, c__root int64) { t.F_parent = c__parent; t.F_s = c__s; t.F_root = c__root }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Invoke_O__O(self any) any { { var x__1 int64; var tmp1 any; var t_ any = t.F_s; t.F_s = nil; tmp1 = t_; x__1 = lang.RT_LongCast_O__J_NoInit(tmp1); var d__2 int64 = 0; L1: for { if lang.Numbers_Equiv_J_J__Z_NoInit(x__1, t.F_root) { return jrt.Long_ValueOf_J__Long_NoInit(d__2).Ref() } else { var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); x__1, d__2 = lang.RT_Aget_J1_I__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(x__1))), lang.Numbers_Inc_J__J_NoInit(d__2); continue L1 } } }; panic("j2g: unreachable") }










func A_arbace_j2g_zlib_canonical_codes_A_New() *A_arbace_j2g_zlib_canonical_codes_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_canonical_codes_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Invoke_O_O__O(self, lens__0 any) any { var n__2 int32 = lang.RT_Alength_J1__I_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass())); var bl_count__3 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var next_code__4 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var codes__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref()).Ref(); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7 int64 = 0; L1: for {







	if lang.Numbers_Lt_J_J__Z_NoInit(i__7, n__1927000701__auto____6) { var l__8 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__7)); if lang.Numbers_IsPos_J__Z_NoInit(l__8) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)))))) }; i__7 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7); continue L1 }
//line :83:1
	break L1 }; var bits__6 int64 = 1; var code__7 int64 = 0; L2: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(bits__6, 16) { var code__8 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(code__7, lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(bits__6)))), 1)

			jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(bits__6), code__8))
			bits__6, code__7 = lang.Numbers_Inc_J__J_NoInit(bits__6), code__8; continue L2 }
//line :83:1
		break L2 }; var n__1927000701__auto____6_2 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7_2 int64 = 0; L3: for {













			if lang.Numbers_Lt_J_J__Z_NoInit(i__7_2, n__1927000701__auto____6_2) { var l__8_2 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__7_2))

				if lang.Numbers_IsPos_J__Z_NoInit(l__8_2) {
					jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](codes__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__7_2), lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(l__8_2).Ref()))))
					jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)))))) }
//line :97:1
				i__7_2 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7_2); continue L3 }
//line :83:1
			break L3 }; return codes__5 }





























func A_arbace_j2g_zlib_code_of_A_New() *A_arbace_j2g_zlib_code_of_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_code_of_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Invoke_O_O_O__O(self, bases__0, p_v__1 any) any { var v__1 int64 = lang.RT_LongCast_O__J_NoInit(p_v__1); var tmp1 int64; var i__3 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Alength_J1__I_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass())))); L1: for {


	if lang.Numbers_Gt_J_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__3)), v__1) { i__3 = lang.Numbers_Dec_J__J_NoInit(i__3); continue L1 } else { tmp1 = i__3 }
//line :113:1
	break L1 }; return jrt.Long_ValueOf_J__Long_NoInit(tmp1).Ref() }













func A_arbace_j2g_zlib_match_length_A_New() *A_arbace_j2g_zlib_match_length_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_match_length_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Invoke_O_O_O_O_O__O(self, b__0, p_i__1, p_j__2, p_max__3 any) any { var i__1 int64 = lang.RT_LongCast_O__J_NoInit(p_i__1); var j__2 int64 = lang.RT_LongCast_O__J_NoInit(p_j__2); var max__3 int64 = lang.RT_LongCast_O__J_NoInit(p_max__3); var tmp1 int64; var k__5 int64 = 0; L1: for {


	var tmp2 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lt_J_J__Z_NoInit(k__5, max__3); if and__1927000168__auto____6 { tmp2 = lang.Numbers_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__1, k__5)))).Ref()), lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(j__2, k__5)))).Ref())) } else { tmp2 = and__1927000168__auto____6 }; if tmp2 { k__5 = lang.Numbers_Inc_J__J_NoInit(k__5); continue L1 } else { tmp1 = k__5 }
//line :127:1
	break L1 }; return jrt.Long_ValueOf_J__Long_NoInit(tmp1).Ref() }




func A_arbace_j2g_zlib_insert_BANG__A_New() *A_arbace_j2g_zlib_insert_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_insert_BANG__A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Invoke_O_O_O_O_O__O(self, b__0, head__1, prev__2, p_i__3 any) any { var i__3 int64 = lang.RT_LongCast_O__J_NoInit(p_i__3); if



	lang.Numbers_Lte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 3), int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var h__5 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__3))).Ref()), 255), 8), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 1)))).Ref()), 255), 4)), lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255)), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255), 11)), 65535)





		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__2, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__3), lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(h__5))))
		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(h__5), lang.RT_IntCast_J__I_NoInit(i__3))) }; return nil }


func A_arbace_j2g_zlib_longest_A_New() *A_arbace_j2g_zlib_longest_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_longest_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Invoke_O_O_O_O__O(self, b__0, prev__1, p_i__2 any) any { var i__2 int64 = lang.RT_LongCast_O__J_NoInit(p_i__2); var tmp1 int64; var n__4 int32 = lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); if




	lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__2, 3), int64(n__4)) { tmp1 = 0 } else { var maxl__5 int64 = lang.Numbers_Min_J_J__J_NoInit(258, lang.Numbers_Minus_J_J__J_NoInit(int64(n__4), i__2)); var j__6 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__2))); var chain__7 int64 = 0; var best__8 any = lang.RT_Box_J__Number_NoInit(0); var bestd__9 int64 = 0; L1: for {



		var tmp2 bool; var or__1927000174__auto____10 bool = lang.Numbers_IsNeg_J__Z_NoInit(j__6); if or__1927000174__auto____10 { tmp2 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 bool = lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6), 32768); if or__1927000174__auto____11 { tmp2 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 bool = lang.Numbers_Gte_J_J__Z_NoInit(chain__7, 64); if or__1927000174__auto____12 { tmp2 = or__1927000174__auto____12 } else { var or__1927000174__auto____13 bool; var na_11 any = best__8; var na_12 int64 = 64; if jrt.Long_InstanceOf(na_11) { var n0_13 int64 = jrt.NN(jrt.Long_Cast(na_11)).LongValue__J(); var n1_14 int64 = na_12; or__1927000174__auto____13 = n0_13 >= n1_14 } else { or__1927000174__auto____13 = lang.Numbers_Gte_O_J__Z_NoInit(na_11, na_12) }; if or__1927000174__auto____13 { tmp2 = or__1927000174__auto____13 } else { var na_16 any = best__8; var na_17 int64 = maxl__5; if jrt.Long_InstanceOf(na_16) { var n0_18 int64 = jrt.NN(jrt.Long_Cast(na_16)).LongValue__J(); var n1_19 int64 = na_17; tmp2 = n0_18 >= n1_19 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_16, na_17) } } } } }; if tmp2 {
			var tmp3 bool; var na_21 any = best__8; var na_22 int64 = 3; if jrt.Long_InstanceOf(na_21) { var n0_23 int64 = jrt.NN(jrt.Long_Cast(na_21)).LongValue__J(); var n1_24 int64 = na_22; tmp3 = n0_23 >= n1_24 } else { tmp3 = lang.Numbers_Gte_O_J__Z_NoInit(na_21, na_22) }; if tmp3 { var tmp4 int64; var na_26 any = best__8; var na_27 int64 = 16; if jrt.Long_InstanceOf(na_26) { var n0_28 int64 = jrt.NN(jrt.Long_Cast(na_26)).LongValue__J(); var n1_29 int64 = na_27; tmp4 = n0_28 << (n1_29 & 63) } else { tmp4 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_26, na_27) }; tmp1 = lang.Numbers_Or_J_J__J_NoInit(tmp4, bestd__9) } else { tmp1 = 0 } } else {
//line :155:1
				var l__10 any; var tmp5 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()); var tmp6 jrt.Number_I
				var na_31 int64 = j__6; var na_32 any = best__8
				if jrt.Long_InstanceOf(na_32) { var n0_33 int64 = na_31; var n1_34 int64 = jrt.NN(jrt.Long_Cast(na_32)).LongValue__J(); var nr_35 int64 = n0_33 + n1_34; if (n0_33^nr_35)&(n1_34^nr_35) >= 0 { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_35)) } else { tmp6 = lang.Numbers_Add_J_O__Number_NoInit(na_31, na_32) } } else { tmp6 = lang.Numbers_Add_J_O__Number_NoInit(na_31, na_32) }; var tmp7 int64 = lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(tmp6))).Ref()); var tmp8 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()); var tmp9 jrt.Number_I; var na_36 int64 = i__2; var na_37 any = best__8; if jrt.Long_InstanceOf(na_37) { var n0_38 int64 = na_36; var n1_39 int64 = jrt.NN(jrt.Long_Cast(na_37)).LongValue__J(); var nr_40 int64 = n0_38 + n1_39; if (n0_38^nr_40)&(n1_39^nr_40) >= 0 { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_40)) } else { tmp9 = lang.Numbers_Add_J_O__Number_NoInit(na_36, na_37) } } else { tmp9 = lang.Numbers_Add_J_O__Number_NoInit(na_36, na_37) }; if lang.Numbers_Equiv_J_J__Z_NoInit(tmp7, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp8, lang.RT_IntCast_O__I_NoInit(tmp9))).Ref())) {
					l__10 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, jrt.Long_ValueOf_J__Long_NoInit(i__2).Ref(), jrt.Long_ValueOf_J__Long_NoInit(j__6).Ref(), jrt.Long_ValueOf_J__Long_NoInit(maxl__5).Ref()) } else {
//line :157:1
						l__10 = A_arbace_j2g_zlib_A_const_17
					}

				var tmp10 bool; var na_41 int64 = lang.RT_LongCast_O__J_NoInit(l__10); var na_42 any = best__8; if jrt.Long_InstanceOf(na_42) { var n0_43 int64 = na_41; var n1_44 int64 = jrt.NN(jrt.Long_Cast(na_42)).LongValue__J(); tmp10 = n0_43 > n1_44 } else { tmp10 = lang.Numbers_Gt_J_O__Z_NoInit(na_41, na_42) }; if tmp10 {
					j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), l__10, lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6); continue L1 } else {
						j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), best__8, bestd__9; continue L1 } }
//line :151:1
		break L1 } }; return /*line :146:1*/ jrt.Long_ValueOf_J__Long_NoInit(tmp1).Ref() }

















func A_arbace_j2g_zlib_lz77_A_New() *A_arbace_j2g_zlib_lz77_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_lz77_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Invoke_O_O__O(self, b__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var head__3 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(65536), A_arbace_j2g_zlib_A_const_21).Ref(); var prev__4 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Max_J_J__J_NoInit(int64(n__2), 1)), A_arbace_j2g_zlib_A_const_21).Ref(); var out__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(n__2))).Ref()).Ref(); var flag__6 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(1, 40); var i__7 int64 = 0; var k__8 int64 = 0; var pending__9 any = lang.RT_Box_J__Number_NoInit(0); L1: for {











	if lang.Numbers_Gte_J_J__Z_NoInit(i__7, int64(n__2)) {
		var tmp1 bool; var na_46 any = pending__9; if jrt.Long_InstanceOf(na_46) { var n0_47 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); tmp1 = n0_47 > 0 } else { if jrt.Double_InstanceOf(na_46) { var n0_47_2 float64 = jrt.NN(jrt.Double_Cast(na_46)).DoubleValue__D(); tmp1 = n0_47_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_46) } }; if tmp1 {
			var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()); var tmp3 int32 = lang.RT_IntCast_J__I_NoInit(k__8); var tmp4 int64; var na_67 any = pending__9; var na_68 int64 = flag__6; if jrt.Long_InstanceOf(na_67) { var n0_69 int64 = jrt.NN(jrt.Long_Cast(na_67)).LongValue__J(); var n1_70 int64 = na_68; tmp4 = n0_69 | n1_70 } else { tmp4 = lang.Numbers_Or_O_J__J_NoInit(na_67, na_68) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, tmp3, tmp4))
//line :177:1
			return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(k__8)).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(k__8).Ref()) } } else {



				lang.IFn_Cast(A_arbace_j2g_zlib_A_const_23.GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, head__3, prev__4, jrt.Long_ValueOf_J__Long_NoInit(i__7).Ref())
//line :176:1
				var m__10 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(b__0, prev__4, jrt.Long_ValueOf_J__Long_NoInit(i__7).Ref()); var tmp5 bool
				var na_48 any = pending__9






				if jrt.Long_InstanceOf(na_48) { var n0_49 int64 = jrt.NN(jrt.Long_Cast(na_48)).LongValue__J(); tmp5 = n0_49 > 0 } else { if jrt.Double_InstanceOf(na_48) { var n0_49_2 float64 = jrt.NN(jrt.Double_Cast(na_48)).DoubleValue__D(); tmp5 = n0_49_2 > 0.0 } else { tmp5 = lang.Numbers_IsPos_O__Z_NoInit(na_48) } }
//line :183:1
				if tmp5 {

					var tmp6 int64; var na_50 any = m__10; var na_51 int64 = 16; if jrt.Long_InstanceOf(na_50) { var n0_52 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var n1_53 int64 = na_51; tmp6 = n0_52 >> (n1_53 & 63) } else { tmp6 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_50, na_51) }; var tmp7 int64 = tmp6; var tmp8 int64; var na_55 any = pending__9; var na_56 int64 = 16; if jrt.Long_InstanceOf(na_55) { var n0_57 int64 = jrt.NN(jrt.Long_Cast(na_55)).LongValue__J(); var n1_58 int64 = na_56; tmp8 = n0_57 >> (n1_58 & 63) } else { tmp8 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_55, na_56) }; if lang.Numbers_Gt_J_J__Z_NoInit(tmp7, tmp8) {

						jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(i__7)))).Ref()), 255))))
						i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), m__10; continue L1 } else {
//line :185:1
							var end__11 int64; var tmp9 int64 = lang.Numbers_Dec_J__J_NoInit(i__7); var tmp10 int64
							var na_60 any = pending__9
							var na_61 int64 = 16


							if jrt.Long_InstanceOf(na_60) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_60)).LongValue__J(); var n1_63 int64 = na_61; tmp10 = n0_62 >> (n1_63 & 63) } else { tmp10 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_60, na_61) }; end__11 = lang.Numbers_Add_J_J__J_NoInit(tmp9, tmp10)
							var tmp11 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()); var tmp12 int32 = lang.RT_IntCast_J__I_NoInit(k__8); var tmp13 int64; var na_72 any = pending__9; var na_73 int64 = flag__6; if jrt.Long_InstanceOf(na_72) { var n0_74 int64 = jrt.NN(jrt.Long_Cast(na_72)).LongValue__J(); var n1_75 int64 = na_73; tmp13 = n0_74 | n1_75 } else { tmp13 = lang.Numbers_Or_O_J__J_NoInit(na_72, na_73) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp11, tmp12, tmp13))
//line :185:1
							var x__12 int64 = lang.Numbers_Inc_J__J_NoInit(i__7); L2: for {






								if lang.Numbers_Lt_J_J__Z_NoInit(x__12, end__11) { lang.IFn_Cast(A_arbace_j2g_zlib_A_const_23.GetRawRoot__O()).Invoke_O_O_O_O__O(b__0, head__3, prev__4, jrt.Long_ValueOf_J__Long_NoInit(x__12).Ref()); x__12 = lang.Numbers_Inc_J__J_NoInit(x__12); continue L2 }
//line :185:1
								break L2
							}






							i__7, k__8, pending__9 = end__11, lang.Numbers_Inc_J__J_NoInit(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } } else {
//line :183:1
								var tmp14 bool
								var na_65 any = m__10









								if jrt.Long_InstanceOf(na_65) { var n0_66 int64 = jrt.NN(jrt.Long_Cast(na_65)).LongValue__J(); tmp14 = n0_66 > 0 } else { if jrt.Double_InstanceOf(na_65) { var n0_66_2 float64 = jrt.NN(jrt.Double_Cast(na_65)).DoubleValue__D(); tmp14 = n0_66_2 > 0.0 } else { tmp14 = lang.Numbers_IsPos_O__Z_NoInit(na_65) } }
//line :183:1
								if tmp14 {










									i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), k__8, m__10; continue L1 } else {
//line :183:1
										if A_arbace_j2g_zlib_A_const_9 != nil {











											jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__7))).Ref()), 255))))
											i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } else {
//line :183:1
												return nil } } } } } }; /*line :164:1*/panic("j2g: unreachable") }







































func A_arbace_j2g_zlib_rle_lengths_A_New() *A_arbace_j2g_zlib_rle_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Invoke_O_O__O(self, ls__0 any) any { { var v__2 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_24.GetRawRoot__O()).Invoke_O__O(ls__0); var n__3 int32 = lang.RT_Count_O__I_NoInit(v__2); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 bool; var na_77 any = i__4; var na_78 int64 = int64(n__3); if jrt.Long_InstanceOf(na_77) { var n0_79 int64 = jrt.NN(jrt.Long_Cast(na_77)).LongValue__J(); var n1_80 int64 = na_78; tmp1 = n0_79 >= n1_80 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_77, na_78) }; if tmp1 { return acc__5 } else { var x__6 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(v__2, lang.RT_IntCast_O__I_NoInit(i__4))); var run__7 any; var tmp2 any = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(i__4, n__3, x__6, v__2); var tmp3 *jrt.Class
		var fncls__94 /*line :209:1*/*jrt.Class = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class


		if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class = fncls__94d; tmp3 = fncls__94d } else { tmp3 = fncls__94 }; run__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
		var tmp4 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)
		if and__1927000168__auto____8 { var na_95 any = run__7; var na_96 int64 = 11; if jrt.Long_InstanceOf(na_95) { var n0_97 int64 = jrt.NN(jrt.Long_Cast(na_95)).LongValue__J(); var n1_98 int64 = na_96; tmp4 = n0_97 >= n1_98 } else { tmp4 = lang.Numbers_Gte_O_J__Z_NoInit(na_95, na_96) } } else { tmp4 = and__1927000168__auto____8 }
//line :213:1
		if tmp4 { var r__8 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 138); var tmp5 jrt.Number_I; var na_112 any = i__4; var na_113 any = r__8; var tmp6 bool; var tmp7 bool
			tmp7 = jrt.Long_InstanceOf(na_112); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_113) }; tmp6 = tmp7; if tmp6 { var n0_114 int64 = jrt.NN(jrt.Long_Cast(na_112)).LongValue__J(); var n1_115 int64 = jrt.NN(jrt.Long_Cast(na_113)).LongValue__J(); var nr_116 int64 = n0_114 + n1_115; if (n0_114^nr_116)&(n1_115^nr_116) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_116)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_112, na_113) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_112); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_113) }; tmp8 = tmp9; if tmp8 { var n0_114_2 float64 = jrt.NN(jrt.Double_Cast(na_112)).DoubleValue__D(); var n1_115_2 float64 = jrt.NN(jrt.Double_Cast(na_113)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_114_2 + n1_115_2)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_112, na_113) } }; var tmp10 any = tmp5; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_zlib_A_const_25; var tmp13 jrt.Number_I; var na_117 any = r__8; var na_118 int64 = 11; if jrt.Long_InstanceOf(na_117) { var n0_119 int64 = jrt.NN(jrt.Long_Cast(na_117)).LongValue__J(); var n1_120 int64 = na_118; var nr_121 int64 = n0_119 - n1_120; var tmp14 bool; var tmp15 bool; tmp15 = !(n1_120 == -9223372036854775808); if tmp15 { tmp15 = (n0_119^n1_120)&(n0_119^nr_121) >= 0 }; tmp14 = tmp15; if tmp14 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_121)) } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_117, na_118) } } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_117, na_118) }; i__4, acc__5 = tmp10, tmp11.Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13)); continue L1 } else {
//line :213:1
				var tmp16 bool; var and__1927000168__auto____8_2 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)

				if and__1927000168__auto____8_2 { var na_100 any = run__7; var na_101 int64 = 3; if jrt.Long_InstanceOf(na_100) { var n0_102 int64 = jrt.NN(jrt.Long_Cast(na_100)).LongValue__J(); var n1_103 int64 = na_101; tmp16 = n0_102 >= n1_103 } else { tmp16 = lang.Numbers_Gte_O_J__Z_NoInit(na_100, na_101) } } else { tmp16 = and__1927000168__auto____8_2 }
//line :213:1
				if tmp16 { var r__8_2 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 10); var tmp17 jrt.Number_I; var na_122 any = i__4; var na_123 any = r__8_2; var tmp18 bool; var tmp19 bool

					tmp19 = jrt.Long_InstanceOf(na_122); if tmp19 { tmp19 = jrt.Long_InstanceOf(na_123) }; tmp18 = tmp19; if tmp18 { var n0_124 int64 = jrt.NN(jrt.Long_Cast(na_122)).LongValue__J(); var n1_125 int64 = jrt.NN(jrt.Long_Cast(na_123)).LongValue__J(); var nr_126 int64 = n0_124 + n1_125; if (n0_124^nr_126)&(n1_125^nr_126) >= 0 { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_126)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_122, na_123) } } else { var tmp20 bool; var tmp21 bool; tmp21 = jrt.Double_InstanceOf(na_122); if tmp21 { tmp21 = jrt.Double_InstanceOf(na_123) }; tmp20 = tmp21; if tmp20 { var n0_124_2 float64 = jrt.NN(jrt.Double_Cast(na_122)).DoubleValue__D(); var n1_125_2 float64 = jrt.NN(jrt.Double_Cast(na_123)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_124_2 + n1_125_2)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_122, na_123) } }; var tmp22 any = tmp17; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_zlib_A_const_26; var tmp25 jrt.Number_I; var na_127 any = r__8_2; var na_128 int64 = 3; if jrt.Long_InstanceOf(na_127) { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var n1_130 int64 = na_128; var nr_131 int64 = n0_129 - n1_130; var tmp26 bool; var tmp27 bool; tmp27 = !(n1_130 == -9223372036854775808); if tmp27 { tmp27 = (n0_129^n1_130)&(n0_129^nr_131) >= 0 }; tmp26 = tmp27; if tmp26 { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_131)) } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_127, na_128) } } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_127, na_128) }; i__4, acc__5 = tmp22, tmp23.Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(tmp24, tmp25)); continue L1 } else {
//line :213:1
						var tmp28 bool; var and__1927000168__auto____8_3 bool = lang.Numbers_IsPos_J__Z_NoInit(x__6)


						if and__1927000168__auto____8_3 { var na_105 any = run__7; var na_106 int64 = 4; if jrt.Long_InstanceOf(na_105) { var n0_107 int64 = jrt.NN(jrt.Long_Cast(na_105)).LongValue__J(); var n1_108 int64 = na_106; tmp28 = n0_107 >= n1_108 } else { tmp28 = lang.Numbers_Gte_O_J__Z_NoInit(na_105, na_106) } } else { tmp28 = and__1927000168__auto____8_3 }
//line :213:1
						if tmp28 { var r__8_3 any; var tmp29 jrt.Number_I
							var na_110 any = run__7

							if jrt.Long_InstanceOf(na_110) { var n0_111 int64 = jrt.NN(jrt.Long_Cast(na_110)).LongValue__J(); if n0_111 == -9223372036854775808 { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_110) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_111 - 1)) } } else { if jrt.Double_InstanceOf(na_110) { var n0_111_2 float64 = jrt.NN(jrt.Double_Cast(na_110)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_111_2 - 1.0)) } else { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_110) } }; r__8_3 = lang.Numbers_Min_O_J__O_NoInit(tmp29, 6); var tmp30 jrt.Number_I; var na_132 any; var na_134 any = i__4; var na_135 int64 = 1; if jrt.Long_InstanceOf(na_134) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); var n1_137 int64 = na_135; var nr_138 int64 = n0_136 + n1_137; if (n0_136^nr_138)&(n1_137^nr_138) >= 0 { na_132 = jrt.Long_ValueOf_J__Long_NoInit(nr_138).Ref() } else { na_132 = lang.Numbers_Add_O_J__Number_NoInit(na_134, na_135) } } else { na_132 = lang.Numbers_Add_O_J__Number_NoInit(na_134, na_135) }; var na_133 any = r__8_3; var tmp31 bool; var tmp32 bool; tmp32 = jrt.Long_InstanceOf(na_132); if tmp32 { tmp32 = jrt.Long_InstanceOf(na_133) }; tmp31 = tmp32; if tmp31 { var n0_139 int64 = jrt.NN(jrt.Long_Cast(na_132)).LongValue__J(); var n1_140 int64 = jrt.NN(jrt.Long_Cast(na_133)).LongValue__J(); var nr_141 int64 = n0_139 + n1_140; if (n0_139^nr_141)&(n1_140^nr_141) >= 0 { tmp30 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_141)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_132, na_133) } } else { var tmp33 bool; var tmp34 bool; tmp34 = jrt.Double_InstanceOf(na_132); if tmp34 { tmp34 = jrt.Double_InstanceOf(na_133) }; tmp33 = tmp34; if tmp33 { var n0_139_2 float64 = jrt.NN(jrt.Double_Cast(na_132)).DoubleValue__D(); var n1_140_2 float64 = jrt.NN(jrt.Double_Cast(na_133)).DoubleValue__D(); tmp30 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_139_2 + n1_140_2)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_132, na_133) } }; var tmp35 any = tmp30; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()); var tmp37 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17); var tmp38 any = A_arbace_j2g_zlib_A_const_18; var tmp39 jrt.Number_I; var na_142 any = r__8_3; var na_143 int64 = 3; if jrt.Long_InstanceOf(na_142) { var n0_144 int64 = jrt.NN(jrt.Long_Cast(na_142)).LongValue__J(); var n1_145 int64 = na_143; var nr_146 int64 = n0_144 - n1_145; var tmp40 bool; var tmp41 bool; tmp41 = !(n1_145 == -9223372036854775808); if tmp41 { tmp41 = (n0_144^n1_145)&(n0_144^nr_146) >= 0 }; tmp40 = tmp41; if tmp40 { tmp39 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_146)) } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_142, na_143) } } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_142, na_143) }; i__4, acc__5 = tmp35, tmp36.Invoke_O_O_O__O(acc__5, tmp37, lang.Tuple_Create_O_O__IPersistentVector(tmp38, tmp39)); continue L1 } else {
//line :213:1
								if A_arbace_j2g_zlib_A_const_9 != nil {



									var tmp42 jrt.Number_I; var na_147 any = i__4; if jrt.Long_InstanceOf(na_147) { var n0_148 int64 = jrt.NN(jrt.Long_Cast(na_147)).LongValue__J(); if n0_148 == 9223372036854775807 { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_147) } else { tmp42 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_148 + 1)) } } else { if jrt.Double_InstanceOf(na_147) { var n0_148_2 float64 = jrt.NN(jrt.Double_Cast(na_147)).DoubleValue__D(); tmp42 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_148_2 + 1.0)) } else { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_147) } }; i__4, acc__5 = tmp42, lang.IFn_Cast(A_arbace_j2g_zlib_A_const_4.GetRawRoot__O()).Invoke_O_O__O(acc__5, lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17)); continue L1 } else {
//line :213:1
										return nil } } } } } } }; /*line :204:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(p0 any, p1 int32, p2 int64, p3 any) *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A{}; t.Ctor_O_I_J_O(p0, p1, p2, p3); return t }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Ctor_O_I_J_O(c__i any, c__n int32, c__x int64, c__v any) { t.F_i = c__i; t.F_n = c__n; t.F_x = c__x; t.F_v = c__v }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Invoke_O__O(self any) any { { var j__1 any = t.F_i; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_82 any = j__1; var na_83 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_82) { var n0_84 int64 = jrt.NN(jrt.Long_Cast(na_82)).LongValue__J(); var n1_85 int64 = na_83; and__1927000168__auto____2 = n0_84 < n1_85 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_82, na_83) }; if and__1927000168__auto____2 { var tmp2 int64 = t.F_x; var tmp3 any = t.F_v; tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(tmp2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(j__1)))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp4 jrt.Number_I; var na_92 any = j__1; if jrt.Long_InstanceOf(na_92) { var n0_93 int64 = jrt.NN(jrt.Long_Cast(na_92)).LongValue__J(); if n0_93 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_92) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_93 + 1)) } } else { if jrt.Double_InstanceOf(na_92) { var n0_93_2 float64 = jrt.NN(jrt.Double_Cast(na_92)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_93_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_92) } }; j__1 = tmp4; continue L1 } else { var na_87 any = j__1; var na_88 any = t.F_i; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_87); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_88) }; tmp5 = tmp6; if tmp5 { var n0_89 int64 = jrt.NN(jrt.Long_Cast(na_87)).LongValue__J(); var n1_90 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); var nr_91 int64 = n0_89 - n1_90; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_90 == -9223372036854775808); if tmp8 { tmp8 = (n0_89^n1_90)&(n0_89^nr_91) >= 0 }; tmp7 = tmp8; if tmp7 { return jrt.Long_ValueOf_J__Long_NoInit(nr_91).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_87, na_88) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_87); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_88) }; tmp9 = tmp10; if tmp9 { var n0_89_2 float64 = jrt.NN(jrt.Double_Cast(na_87)).DoubleValue__D(); var n1_90_2 float64 = jrt.NN(jrt.Double_Cast(na_88)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_89_2 + -n1_90_2).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_87, na_88) } } } } }; panic("j2g: unreachable") }






func A_arbace_j2g_zlib_write_block_BANG__A_New() *A_arbace_j2g_zlib_write_block_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Ctor() {}
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Invoke_O_O_O_O_O_O__O(self, w__0, syms__1, from__2, to__3, last_QMARK___4 any) any { var from__6 int64 = lang.RT_LongCast_O__J_NoInit(from__2); var to__7 int64 = lang.RT_LongCast_O__J_NoInit(to__3); var lf__8 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_27).Ref(); var df__9 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_28).Ref(); var i__10 int64 = from__6; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__10, to__7) { var s__11 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__10)))

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_41.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(s__11).Ref(), A_arbace_j2g_zlib_A_const_43)) { var len__12 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__11, 16), 65535); var d__13 int64 = lang.Numbers_And_J_J__J_NoInit(s__11, 65535)

			jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Long_ValueOf_J__Long_NoInit(len__12).Ref())))), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Long_ValueOf_J__Long_NoInit(len__12).Ref()))))))))
			jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Long_ValueOf_J__Long_NoInit(d__13).Ref()))), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.RT_LongCast_O__J_NoInit(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Long_ValueOf_J__Long_NoInit(d__13).Ref()))))))) } else {
				jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)))))) }
		i__10 = lang.Numbers_Inc_J__J_NoInit(i__10); continue L1 }
//line :219:1
	break L1 };












	jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(256), 1)); var used__10 int32; var tmp1 lang.IFn = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(df__9); var tmp3 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class; if














	fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class = fncls__154d; tmp3 = fncls__154d } else { tmp3 = fncls__154 }; used__10 = lang.RT_Count_O__I_NoInit(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_28))); if
	lang.Numbers_IsZero_J__Z_NoInit(int64(used__10)) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), 1)); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1), 1)) } else { if lang.Numbers_Equiv_J_J__Z_NoInit(1, int64(used__10)) {
		var tmp4 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp5 int64; if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0))) { tmp5 = 1 } else { tmp5 = 0 }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(tmp5), 1)) } }; var ll__10 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_29.GetRawRoot__O()).Invoke_O_O__O(lf__8, A_arbace_j2g_zlib_A_const_46); var dl__11 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_29.GetRawRoot__O()).Invoke_O_O__O(df__9, A_arbace_j2g_zlib_A_const_46); var lc__12 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_30.GetRawRoot__O()).Invoke_O__O(ll__10); var dc__13 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_30.GetRawRoot__O()).Invoke_O__O(dl__11); var hlit__14 any; var tmp6 jrt.Number_I; var na_149 any; var or__1927000174__auto____14 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_31.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_40.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(ll__10); var tmp10 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class; if





















	fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class = fncls__155d; tmp10 = fncls__155d } else { tmp10 = fncls__155 }; or__1927000174__auto____14 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_47))); if jrt.J2g_Truth(or__1927000174__auto____14) { na_149 = or__1927000174__auto____14 } else { na_149 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_149) { var n0_150 int64 = jrt.NN(jrt.Long_Cast(na_149)).LongValue__J(); if n0_150 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_149) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_150 + 1)) } } else { if jrt.Double_InstanceOf(na_149) { var n0_150_2 float64 = jrt.NN(jrt.Double_Cast(na_149)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_150_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_149) } }; hlit__14 = lang.Numbers_Max_J_O__O_NoInit(257, tmp6); var hdist__15 any; var tmp11 jrt.Number_I; var na_151 any; var or__1927000174__auto____15 any; var tmp12 lang.IFn = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_31.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_40.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(dl__11); var tmp15 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class; if






















	fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class = fncls__156d; tmp15 = fncls__156d } else { tmp15 = fncls__156 }; or__1927000174__auto____15 = tmp12.Invoke_O__O(tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_14.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_28))); if jrt.J2g_Truth(or__1927000174__auto____15) { na_151 = or__1927000174__auto____15 } else { na_151 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_151) { var n0_152 int64 = jrt.NN(jrt.Long_Cast(na_151)).LongValue__J(); if n0_152 == 9223372036854775807 { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_151) } else { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_152 + 1)) } } else { if jrt.Double_InstanceOf(na_151) { var n0_152_2 float64 = jrt.NN(jrt.Double_Cast(na_151)).DoubleValue__D(); tmp11 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_152_2 + 1.0)) } else { tmp11 = lang.Numbers_Inc_O__Number_NoInit(na_151) } }; hdist__15 = lang.Numbers_Max_J_O__O_NoInit(1, tmp11); var rle__16 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_48.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_49.GetRawRoot__O()).Invoke_O_O__O(hlit__14, lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(ll__10)), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_49.GetRawRoot__O()).Invoke_O_O__O(hdist__15, lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(dl__11)))); var cf__17 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_33).Ref(); var ___18 any; var tmp16 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(cf__17, rle__16); var tmp17 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class; _ = ___18; if

























	fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class = fncls__153d; tmp17 = fncls__153d } else { tmp17 = fncls__153 }; ___18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O(); var cl__19 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_29.GetRawRoot__O()).Invoke_O_O__O(cf__17, A_arbace_j2g_zlib_A_const_50); var cc__20 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_30.GetRawRoot__O()).Invoke_O__O(cl__19); var hclen__21 int64; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_39.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(cl__19); var tmp20 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class; if




























	fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class = fncls__157d; tmp20 = fncls__157d } else { tmp20 = fncls__157 }; hclen__21 = lang.Numbers_Max_J_J__J_NoInit(4, lang.Numbers_Minus_J_J__J_NoInit(19, int64(lang.RT_Count_O__I_NoInit(tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), lang.IFn_Cast(A_arbace_j2g_zlib_A_const_51.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_52.GetRawRoot__O())))))); var tmp21 lang.IFn =
	lang.IFn_Cast(w__0); var tmp22 any; if jrt.J2g_Truth(last_QMARK___4) { tmp22 = A_arbace_j2g_zlib_A_const_53 } else { tmp22 = A_arbace_j2g_zlib_A_const_17 }; tmp21.Invoke_O_O__O(tmp22, A_arbace_j2g_zlib_A_const_53);
	lang.IFn_Cast(w__0).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_54, A_arbace_j2g_zlib_A_const_54); var tmp23 lang.IFn =
	lang.IFn_Cast(w__0); var tmp24 jrt.Number_I; var na_158 any = hlit__14; var na_159 int64 = 257; if jrt.Long_InstanceOf(na_158) { var n0_160 int64 = jrt.NN(jrt.Long_Cast(na_158)).LongValue__J(); var n1_161 int64 = na_159; var nr_162 int64 = n0_160 - n1_161; var tmp25 bool; var tmp26 bool; tmp26 = !(n1_161 == -9223372036854775808); if tmp26 { tmp26 = (n0_160^n1_161)&(n0_160^nr_162) >= 0 }; tmp25 = tmp26; if tmp25 { tmp24 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_162)) } else { tmp24 = lang.Numbers_Minus_O_J__Number_NoInit(na_158, na_159) } } else { tmp24 = lang.Numbers_Minus_O_J__Number_NoInit(na_158, na_159) }; tmp23.Invoke_O_O__O(tmp24, A_arbace_j2g_zlib_A_const_55); var tmp27 lang.IFn =
	lang.IFn_Cast(w__0); var tmp28 jrt.Number_I; var na_163 any = hdist__15; var na_164 int64 = 1; if jrt.Long_InstanceOf(na_163) { var n0_165 int64 = jrt.NN(jrt.Long_Cast(na_163)).LongValue__J(); var n1_166 int64 = na_164; var nr_167 int64 = n0_165 - n1_166; var tmp29 bool; var tmp30 bool; tmp30 = !(n1_166 == -9223372036854775808); if tmp30 { tmp30 = (n0_165^n1_166)&(n0_165^nr_167) >= 0 }; tmp29 = tmp30; if tmp29 { tmp28 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_167)) } else { tmp28 = lang.Numbers_Minus_O_J__Number_NoInit(na_163, na_164) } } else { tmp28 = lang.Numbers_Minus_O_J__Number_NoInit(na_163, na_164) }; tmp27.Invoke_O_O__O(tmp28, A_arbace_j2g_zlib_A_const_55);
	lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(hclen__21, 4)).Ref(), A_arbace_j2g_zlib_A_const_56); var seq_1931000065__22 any = /*line :219:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_49.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(hclen__21).Ref(), A_arbace_j2g_zlib_A_const_52.GetRawRoot__O())); var chunk_1931000066__23 any; var count_1931000067__24 int64 = 0; var i_1931000068__25 int64 = 0; L2: for {


































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000068__25, count_1931000067__24) { var s__26 any = lang.Indexed_Cast(chunk_1931000066__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000068__25)); lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__26)))).Ref(), A_arbace_j2g_zlib_A_const_57); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000068__25); continue L2 } else { var temp__1927000414__auto____26 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000065__22); if jrt.J2g_Truth(temp__1927000414__auto____26) { var seq_1931000065__27 any = temp__1927000414__auto____26; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27)) { var c__1927000678__auto____28 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27), c__1927000678__auto____28, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var s__28 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27); lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__28)))).Ref(), A_arbace_j2g_zlib_A_const_57); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000065__27), nil, 0, 0; continue L2 } } }
//line :219:1
		break L2 }; var seq_1931000069__22 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(rle__16); var chunk_1931000070__23 any; var count_1931000071__24 int64 = 0; var i_1931000072__25 int64 = 0; L3: for {



































			if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000072__25, count_1931000071__24) { var vec__1931000073__26 any = lang.Indexed_Cast(chunk_1931000070__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000072__25)); var s__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(0), nil); var x__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(1), nil)
				lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref())
//line :255:1
				var G__1931000076__29_ int32 = lang.RT_IntCast_O__I_NoInit(s__27)

			L4: switch { default: switch G__1931000076__29_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_54); break L4; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_57); break L4; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_50); break L4; default:}}
//line :255:1
				seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000072__25); continue L3 } else { var temp__1927000414__auto____26_2 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000069__22); if jrt.J2g_Truth(temp__1927000414__auto____26_2) { var seq_1931000069__27 any = temp__1927000414__auto____26_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27)) { var c__1927000678__auto____28_2 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27); seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27), c__1927000678__auto____28_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1931000077__28 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27); var s__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(0), nil); var x__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(1), nil)
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref())
//line :255:1
					var G__1931000080__31_ int32 = lang.RT_IntCast_O__I_NoInit(s__29)

				L5: switch { default: switch G__1931000080__31_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_54); break L5; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_57); break L5; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_50); break L5; default:}}
//line :255:1
					seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000069__27), nil, 0, 0; continue L3 } } }
//line :219:1
			break L3 }; var i__22 int64 = from__6; L6: for {







































				if lang.Numbers_Lt_J_J__Z_NoInit(i__22, to__7) { var s__23 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__22)))

					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_41.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(s__23).Ref(), A_arbace_j2g_zlib_A_const_43)) { var len__24 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__23, 16), 65535); var d__25 int64 = lang.Numbers_And_J_J__J_NoInit(s__23, 65535); var lcode__26 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Long_ValueOf_J__Long_NoInit(len__24).Ref()); var dcode__27 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_42.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Long_ValueOf_J__Long_NoInit(d__25).Ref()); var tmp31 lang.IFn = lang.IFn_Cast(w__0); var tmp32 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()); var tmp33 jrt.Number_I
						var na_170 int64 = 257
						var na_171 any = lcode__26
						if jrt.Long_InstanceOf(na_171) { var n0_172 int64 = na_170; var n1_173 int64 = jrt.NN(jrt.Long_Cast(na_171)).LongValue__J(); var nr_174 int64 = n0_172 + n1_173; if (n0_172^nr_174)&(n1_173^nr_174) >= 0 { tmp33 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_174)) } else { tmp33 = lang.Numbers_Add_J_O__Number_NoInit(na_170, na_171) } } else { tmp33 = lang.Numbers_Add_J_O__Number_NoInit(na_170, na_171) }; var tmp34 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp32, lang.RT_IntCast_O__I_NoInit(tmp33))).Ref(); var tmp35 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()); var tmp36 jrt.Number_I; var na_175 int64 = 257; var na_176 any = lcode__26; if jrt.Long_InstanceOf(na_176) { var n0_177 int64 = na_175; var n1_178 int64 = jrt.NN(jrt.Long_Cast(na_176)).LongValue__J(); var nr_179 int64 = n0_177 + n1_178; if (n0_177^nr_179)&(n1_178^nr_179) >= 0 { tmp36 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_179)) } else { tmp36 = lang.Numbers_Add_J_O__Number_NoInit(na_175, na_176) } } else { tmp36 = lang.Numbers_Add_J_O__Number_NoInit(na_175, na_176) }; tmp31.Invoke_O_O__O(tmp34, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp35, lang.RT_IntCast_O__I_NoInit(tmp36))).Ref())
						if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_59.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(lcode__26))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(len__24, lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_44.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_59.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(lcode__26))).Ref()) }
						lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](dc__13, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](dl__11, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref())
						if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_58.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(d__25, lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_58.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref()) } } else {
							lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref()) }
					i__22 = lang.Numbers_Inc_J__J_NoInit(i__22); continue L6 }
//line :219:1
				break L6 }; return /*line :270:1*/ lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(256))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(256))).Ref()) }
//line :234:1
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Ctor_O(c__df any) { t.F_df = c__df }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Invoke_O_O__O(self, p1__1931000041_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_df, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000041_SHARP___1))))).Ref() }






func A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Ctor_O(c__ll any) { t.F_ll = c__ll }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Invoke_O_O__O(self, p1__1931000042_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_ll, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000042_SHARP___1))))).Ref() }
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Ctor_O(c__dl any) { t.F_dl = c__dl }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Invoke_O_O__O(self, p1__1931000043_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_dl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000043_SHARP___1))))).Ref() }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(p0, p1 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Ctor_O_O(c__cf, c__rle any) { t.F_cf = c__cf; t.F_rle = c__rle }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Invoke_O__O(self any) any { { var seq_1931000051__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_rle; t.F_rle = nil; tmp2 = t_; seq_1931000051__1 = tmp1.Invoke_O__O(tmp2); var chunk_1931000052__2 any; var count_1931000053__3 int64 = 0; var i_1931000054__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000054__4, count_1931000053__3) { var vec__1931000056__5 any = lang.Indexed_Cast(chunk_1931000052__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000054__4)); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000056__5, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp3 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp4 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp3, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp4, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)))))); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000054__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000051__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1931000051__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1931000059__7 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6); var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000059__7, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp5 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp6 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp5, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp6, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)))))); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000051__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Invoke_O_O__O(self, p1__1931000044_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000044_SHARP___1))))).Ref() }























func A_arbace_j2g_zlib_adler32_A_New() *A_arbace_j2g_zlib_adler32_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_adler32_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Ctor() {}
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Invoke_O_O__O(self, b__0 any) any { var tmp1 int64; var i__2 int64 = 0; var a__3 int64 = 1; var s__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__2, int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var a__5 int64 = lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(a__3, lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__2))).Ref()), 255)), 65521)

		i__2, a__3, s__4 = lang.Numbers_Inc_J__J_NoInit(i__2), a__5, lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(s__4, a__5), 65521); continue L1 } else {
			tmp1 = lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(s__4, 16), a__3) }
//line :272:1
	break L1 }; return jrt.Long_ValueOf_J__Long_NoInit(tmp1).Ref() }






func A_arbace_j2g_zlib_deflate_A_New() *A_arbace_j2g_zlib_deflate_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_deflate_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Invoke_O_O__O(self, b__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var w__3 any = A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__2, 0, 0); var vec__1931000083__4 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_60.GetRawRoot__O()).Invoke_O__O(b__0); var syms__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 int64 = lang.RT_LongCast_O__J_NoInit(k__6);








	jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(120)); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(218)); if
	lang.Numbers_IsZero_J__Z_NoInit(k__7) {
		lang.IFn_Cast(A_arbace_j2g_zlib_A_const_61.GetRawRoot__O()).Invoke_O_O_O_O_O__O(w__3, syms__5, A_arbace_j2g_zlib_A_const_17, A_arbace_j2g_zlib_A_const_17, jrt.Boolean_TRUE.Ref()) } else {
//line :289:1
			var from__8 int64 = 0; L1: for { var to__9 int64 = lang.Numbers_Min_J_J__J_NoInit(k__7, lang.Numbers_Add_J_J__J_NoInit(from__8, 16384))



				lang.IFn_Cast(A_arbace_j2g_zlib_A_const_61.GetRawRoot__O()).Invoke_O_O_O_O_O__O(w__3, syms__5, jrt.Long_ValueOf_J__Long_NoInit(from__8).Ref(), jrt.Long_ValueOf_J__Long_NoInit(to__9).Ref(), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(to__9, k__7)).Ref())
				if lang.Numbers_Lt_J_J__Z_NoInit(to__9, k__7) { from__8 = to__9; continue L1 }
//line :289:1
				break L1 } };





	lang.IFn_Cast(w__3).Invoke__O(); var a__8 any = /*line :279:1*/lang.IFn_Cast(A_arbace_j2g_zlib_A_const_62.GetRawRoot__O()).Invoke_O__O(b__0); var seq_1931000086__9 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_63); var chunk_1931000087__10 any; var count_1931000088__11 int64 = 0; var i_1931000089__12 int64 = 0; L2: for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000089__12, count_1931000088__11) { var sh__13 any = lang.Indexed_Cast(chunk_1931000087__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000089__12)); var tmp1 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp2 int64; var na_180 any = a__8; var na_181 any = sh__13; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_180); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_181) }; tmp3 = tmp4; if tmp3 { var n0_182 int64 = jrt.NN(jrt.Long_Cast(na_180)).LongValue__J(); var n1_183 int64 = jrt.NN(jrt.Long_Cast(na_181)).LongValue__J(); tmp2 = n0_182 >> (n1_183 & 63) } else { tmp2 = lang.Numbers_ShiftRight_O_O__J_NoInit(na_180, na_181) }; jrt.NN(tmp1).Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp2, 255))); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000089__12); continue L2 } else { var temp__1927000414__auto____13 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_34.GetRawRoot__O()).Invoke_O__O(seq_1931000086__9); if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1931000086__14 any = temp__1927000414__auto____13; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_zlib_A_const_35.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14)) { var c__1927000678__auto____15 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_36.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var sh__15 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14); var tmp5 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp6 int64; var na_185 any = a__8; var na_186 any = sh__15; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_185); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_186) }; tmp7 = tmp8; if tmp7 { var n0_187 int64 = jrt.NN(jrt.Long_Cast(na_185)).LongValue__J(); var n1_188 int64 = jrt.NN(jrt.Long_Cast(na_186)).LongValue__J(); tmp6 = n0_187 >> (n1_188 & 63) } else { tmp6 = lang.Numbers_ShiftRight_O_O__J_NoInit(na_185, na_186) }; jrt.NN(tmp5).Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp6, 255))); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1931000086__14), nil, 0, 0; continue L2 } } }
//line :279:1
		break L2 }; return /*line :298:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).ToByteArray__B1().Ref() }
//line :287:1
type A_arbace_j2g_zlib_A struct{ jrt.Object }

var A_arbace_j2g_zlib_A_const_pool *jrt.RefArray

var A_arbace_j2g_zlib_A_const_0 *lang.Var

var A_arbace_j2g_zlib_A_const_1 any

var A_arbace_j2g_zlib_A_const_2 *lang.Var

var A_arbace_j2g_zlib_A_const_3 *lang.Var

var A_arbace_j2g_zlib_A_const_4 *lang.Var

var A_arbace_j2g_zlib_A_const_5 any

var A_arbace_j2g_zlib_A_const_6 *lang.Var

var A_arbace_j2g_zlib_A_const_7 *lang.Var

var A_arbace_j2g_zlib_A_const_8 *lang.Var

var A_arbace_j2g_zlib_A_const_9 *lang.Keyword

var A_arbace_j2g_zlib_A_const_10 *lang.Var

var A_arbace_j2g_zlib_A_const_11 *lang.Var

var A_arbace_j2g_zlib_A_const_12 *lang.Var

var A_arbace_j2g_zlib_A_const_13 *lang.Var

var A_arbace_j2g_zlib_A_const_14 *lang.Var

var A_arbace_j2g_zlib_A_const_15 *lang.Var

var A_arbace_j2g_zlib_A_const_16 *lang.Var

var A_arbace_j2g_zlib_A_const_17 any

var A_arbace_j2g_zlib_A_const_18 any

var A_arbace_j2g_zlib_A_const_19 *lang.Var

var A_arbace_j2g_zlib_A_const_20 *lang.Var

var A_arbace_j2g_zlib_A_const_21 any

var A_arbace_j2g_zlib_A_const_22 *lang.Var

var A_arbace_j2g_zlib_A_const_23 *lang.Var

var A_arbace_j2g_zlib_A_const_24 *lang.Var

var A_arbace_j2g_zlib_A_const_25 any

var A_arbace_j2g_zlib_A_const_26 any

var A_arbace_j2g_zlib_A_const_27 any

var A_arbace_j2g_zlib_A_const_28 any

var A_arbace_j2g_zlib_A_const_29 *lang.Var

var A_arbace_j2g_zlib_A_const_30 *lang.Var

var A_arbace_j2g_zlib_A_const_31 *lang.Var

var A_arbace_j2g_zlib_A_const_32 *lang.Var

var A_arbace_j2g_zlib_A_const_33 any

var A_arbace_j2g_zlib_A_const_34 *lang.Var

var A_arbace_j2g_zlib_A_const_35 *lang.Var

var A_arbace_j2g_zlib_A_const_36 *lang.Var

var A_arbace_j2g_zlib_A_const_37 *lang.Var

var A_arbace_j2g_zlib_A_const_38 *lang.Var

var A_arbace_j2g_zlib_A_const_39 *lang.Var

var A_arbace_j2g_zlib_A_const_40 *lang.Var

var A_arbace_j2g_zlib_A_const_41 *lang.Var

var A_arbace_j2g_zlib_A_const_42 *lang.Var

var A_arbace_j2g_zlib_A_const_43 any

var A_arbace_j2g_zlib_A_const_44 *lang.Var

var A_arbace_j2g_zlib_A_const_45 *lang.Var

var A_arbace_j2g_zlib_A_const_46 any

var A_arbace_j2g_zlib_A_const_47 any

var A_arbace_j2g_zlib_A_const_48 *lang.Var

var A_arbace_j2g_zlib_A_const_49 *lang.Var

var A_arbace_j2g_zlib_A_const_50 any

var A_arbace_j2g_zlib_A_const_51 *lang.Var

var A_arbace_j2g_zlib_A_const_52 *lang.Var

var A_arbace_j2g_zlib_A_const_53 any

var A_arbace_j2g_zlib_A_const_54 any

var A_arbace_j2g_zlib_A_const_55 any

var A_arbace_j2g_zlib_A_const_56 any

var A_arbace_j2g_zlib_A_const_57 any

var A_arbace_j2g_zlib_A_const_58 *lang.Var

var A_arbace_j2g_zlib_A_const_59 *lang.Var

var A_arbace_j2g_zlib_A_const_60 *lang.Var

var A_arbace_j2g_zlib_A_const_61 *lang.Var

var A_arbace_j2g_zlib_A_const_62 *lang.Var

var A_arbace_j2g_zlib_A_const_63 any

var A_arbace_j2g_zlib_A_init jrt.ClassInit

func A_arbace_j2g_zlib_A_Init() { if !A_arbace_j2g_zlib_A_init.Done() { A_arbace_j2g_zlib_A_init.Run(A_arbace_j2g_zlib_A_clinit) } }

func A_arbace_j2g_zlib_A_clinit() { A_arbace_j2g_zlib_A_clinit_p0(); A_arbace_j2g_zlib_A_clinit_p1(); A_arbace_j2g_zlib_A_clinit_p2(); A_arbace_j2g_zlib_A_clinit_p3(); A_arbace_j2g_zlib_A_clinit_p4(); A_arbace_j2g_zlib_A_clinit_p5() }

func A_arbace_j2g_zlib_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_zlib_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 67); A_arbace_j2g_zlib_A_const_0 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[3]); A_arbace_j2g_zlib_A_const_1 = A_arbace_j2g_zlib_A_const_pool.A[4]; A_arbace_j2g_zlib_A_const_2 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[5]); A_arbace_j2g_zlib_A_const_3 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[6]); A_arbace_j2g_zlib_A_const_4 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[7]); A_arbace_j2g_zlib_A_const_5 = A_arbace_j2g_zlib_A_const_pool.A[8]; A_arbace_j2g_zlib_A_const_6 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[9]); A_arbace_j2g_zlib_A_const_7 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[10]); A_arbace_j2g_zlib_A_const_8 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[11]); A_arbace_j2g_zlib_A_const_9 = lang.Keyword_Cast(A_arbace_j2g_zlib_A_const_pool.A[12]); A_arbace_j2g_zlib_A_const_10 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[13]) }

func A_arbace_j2g_zlib_A_clinit_p1() { A_arbace_j2g_zlib_A_const_11 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[14]); A_arbace_j2g_zlib_A_const_12 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[15]); A_arbace_j2g_zlib_A_const_13 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[16]); A_arbace_j2g_zlib_A_const_14 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[17]); A_arbace_j2g_zlib_A_const_15 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[18]); A_arbace_j2g_zlib_A_const_16 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[19]); A_arbace_j2g_zlib_A_const_17 = A_arbace_j2g_zlib_A_const_pool.A[20]; A_arbace_j2g_zlib_A_const_18 = A_arbace_j2g_zlib_A_const_pool.A[21]; A_arbace_j2g_zlib_A_const_19 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[22]); A_arbace_j2g_zlib_A_const_20 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[23]); A_arbace_j2g_zlib_A_const_21 = A_arbace_j2g_zlib_A_const_pool.A[24]; A_arbace_j2g_zlib_A_const_22 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[25]) }

func A_arbace_j2g_zlib_A_clinit_p2() { A_arbace_j2g_zlib_A_const_23 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[26]); A_arbace_j2g_zlib_A_const_24 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[27]); A_arbace_j2g_zlib_A_const_25 = A_arbace_j2g_zlib_A_const_pool.A[28]; A_arbace_j2g_zlib_A_const_26 = A_arbace_j2g_zlib_A_const_pool.A[29]; A_arbace_j2g_zlib_A_const_27 = A_arbace_j2g_zlib_A_const_pool.A[30]; A_arbace_j2g_zlib_A_const_28 = A_arbace_j2g_zlib_A_const_pool.A[31]; A_arbace_j2g_zlib_A_const_29 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[32]); A_arbace_j2g_zlib_A_const_30 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[33]); A_arbace_j2g_zlib_A_const_31 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[34]); A_arbace_j2g_zlib_A_const_32 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[35]); A_arbace_j2g_zlib_A_const_33 = A_arbace_j2g_zlib_A_const_pool.A[36]; A_arbace_j2g_zlib_A_const_34 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[37]); A_arbace_j2g_zlib_A_const_35 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[38]) }

func A_arbace_j2g_zlib_A_clinit_p3() { A_arbace_j2g_zlib_A_const_36 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[39]); A_arbace_j2g_zlib_A_const_37 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[40]); A_arbace_j2g_zlib_A_const_38 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[41]); A_arbace_j2g_zlib_A_const_39 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[42]); A_arbace_j2g_zlib_A_const_40 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[43]); A_arbace_j2g_zlib_A_const_41 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[44]); A_arbace_j2g_zlib_A_const_42 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[45]); A_arbace_j2g_zlib_A_const_43 = A_arbace_j2g_zlib_A_const_pool.A[46]; A_arbace_j2g_zlib_A_const_44 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[47]); A_arbace_j2g_zlib_A_const_45 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[48]); A_arbace_j2g_zlib_A_const_46 = A_arbace_j2g_zlib_A_const_pool.A[49]; A_arbace_j2g_zlib_A_const_47 = A_arbace_j2g_zlib_A_const_pool.A[50] }

func A_arbace_j2g_zlib_A_clinit_p4() { A_arbace_j2g_zlib_A_const_48 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[51]); A_arbace_j2g_zlib_A_const_49 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[52]); A_arbace_j2g_zlib_A_const_50 = A_arbace_j2g_zlib_A_const_pool.A[53]; A_arbace_j2g_zlib_A_const_51 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[54]); A_arbace_j2g_zlib_A_const_52 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[55]); A_arbace_j2g_zlib_A_const_53 = A_arbace_j2g_zlib_A_const_pool.A[56]; A_arbace_j2g_zlib_A_const_54 = A_arbace_j2g_zlib_A_const_pool.A[57]; A_arbace_j2g_zlib_A_const_55 = A_arbace_j2g_zlib_A_const_pool.A[58]; A_arbace_j2g_zlib_A_const_56 = A_arbace_j2g_zlib_A_const_pool.A[59]; A_arbace_j2g_zlib_A_const_57 = A_arbace_j2g_zlib_A_const_pool.A[60]; A_arbace_j2g_zlib_A_const_58 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[61]); A_arbace_j2g_zlib_A_const_59 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[62]); A_arbace_j2g_zlib_A_const_60 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[63]) }

func A_arbace_j2g_zlib_A_clinit_p5() { A_arbace_j2g_zlib_A_const_61 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[64]); A_arbace_j2g_zlib_A_const_62 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[65]); A_arbace_j2g_zlib_A_const_63 = A_arbace_j2g_zlib_A_const_pool.A[66] }

func A_arbace_j2g_zlib_A_New() *A_arbace_j2g_zlib_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_A) Ctor() {}

func (t *A_arbace_j2g_zlib_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_A_class }

func (t *A_arbace_j2g_zlib_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_A); return ok }

func A_arbace_j2g_zlib_A_Cast(x any) *A_arbace_j2g_zlib_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_A_class)) }; return v }



type A_arbace_j2g_zlib_adler32_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_adler32_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_canonical_codes_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_canonical_codes_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_code_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_code_of_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_deflate_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_deflate_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000004_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000004_A_New() *A_arbace_j2g_zlib_eval1931000004_A { t := &A_arbace_j2g_zlib_eval1931000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000004_A_class }

func (t *A_arbace_j2g_zlib_eval1931000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); return ok }

func A_arbace_j2g_zlib_eval1931000004_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000004_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000008_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000008_A_New() *A_arbace_j2g_zlib_eval1931000008_A { t := &A_arbace_j2g_zlib_eval1931000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000008_A_class }

func (t *A_arbace_j2g_zlib_eval1931000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); return ok }

func A_arbace_j2g_zlib_eval1931000008_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000008_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000012_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000012_A_New() *A_arbace_j2g_zlib_eval1931000012_A { t := &A_arbace_j2g_zlib_eval1931000012_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000012_A_class }

func (t *A_arbace_j2g_zlib_eval1931000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); return ok }

func A_arbace_j2g_zlib_eval1931000012_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000012_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_huffman_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A struct{ j2g_header uint64; F_parent any; F_n int32; F_start any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A struct{ j2g_header uint64; F_parent, F_lens any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A struct{ j2g_header uint64; F_parent, F_s any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_insert_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_insert_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_longest_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_longest_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_lz77_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_lz77_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_match_length_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_match_length_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_reverse_bits_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_reverse_bits_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_rle_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A struct{ j2g_header uint64; F_i any; F_n int32; F_x int64; F_v any }

var A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_write_block_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A struct{ j2g_header uint64; F_df any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A struct{ j2g_header uint64; F_ll any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A struct{ j2g_header uint64; F_dl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A struct{ j2g_header uint64; F_cf, F_rle any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A struct{ j2g_header uint64; F_cl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class *jrt.Class
