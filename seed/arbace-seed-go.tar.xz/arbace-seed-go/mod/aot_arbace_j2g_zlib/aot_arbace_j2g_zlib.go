//line aot_arbace_j2g_zlib.ae:1
package aot_arbace_j2g_zlib

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_New() *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_zlib_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_zlib_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_New() *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_j2g_zlib_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_j2g_zlib_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(), A_arbace_j2g_zlib_A_const_6) }

















func A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_New() *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A) Invoke_O_O_O_O__O(self, out__1, acc__2, n__3 any) any { return A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__1, lang.RT_LongCast_O__J_NoInit(acc__2), lang.RT_LongCast_O__J_NoInit(n__3)) }



















func A_arbace_j2g_zlib_reverse_bits_A_New() *A_arbace_j2g_zlib_reverse_bits_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_reverse_bits_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) InvokePrim_O_J_J__J(self any, code__0, len__1 int64) int64 { { var c__3 int64 = code__0; var r__4 int64 = 0; var i__5 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__5, len__1) { c__3, r__4, i__5 = lang.Numbers_ShiftRight_J_J__J_NoInit(c__3, 1), lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(r__4, 1), lang.Numbers_And_J_J__J_NoInit(c__3, 1)), lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else { return r__4 } } }; /*line :39:1*/panic("j2g: unreachable") }
//line :39:1
func (t *A_arbace_j2g_zlib_reverse_bits_A) Invoke_O_O_O__O(self, p_code__0, p_len__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_J_J__J(self, lang.RT_LongCast_O__J_NoInit(p_code__0), lang.RT_LongCast_O__J_NoInit(p_len__1))).Ref() }






func A_arbace_j2g_zlib_huffman_lengths_A_New() *A_arbace_j2g_zlib_huffman_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Ctor() {}
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) InvokePrim_O_O_J__O(self, freqs__0 any, limit__1 int64) any { { var n__3 int32 = lang.RT_Alength_J1__I_NoInit(jrt.J2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())); var fs__4 any = lang.RT_Aclone_J1__J1_NoInit(jrt.J2g_CastArray[*jrt.LongArray](freqs__0, jrt.Prim_long.ArrayClass())).Ref(); L1: for { var syms__5 any; var root_15 any = A_arbace_j2g_zlib_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_17 lang.IFn






	if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var tmp1 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(fs__4); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; arg_18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_19 any; var root_21 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref(); if linked_22 == nil { arg_19 = ifn_23.Invoke_O__O(arg_24) } else { arg_19 = linked_22.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_21, arg_24) }; if linked_16 == nil { syms__5 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { syms__5 = linked_16.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }
//line :46:1
	var lens__6 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var tmp3 any; var root_25 any = A_arbace_j2g_zlib_A_const_9.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_27 lang.IFn









	if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = syms__5; if linked_26 == nil { tmp3 = ifn_27.Invoke_O__O(arg_28) } else { tmp3 = linked_26.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_25, arg_28) }
//line :55:1
	if jrt.J2g_Truth(tmp3) { return lens__6 } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(syms__5))) {

		var tmp4 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](lens__6, jrt.Prim_long.ArrayClass()); var tmp5 any; var root_80 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = syms__5; if linked_81 == nil { tmp5 = ifn_82.Invoke_O__O(arg_83) } else { tmp5 = linked_81.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_80, arg_83) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp4, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(tmp5)), 1))
//line :55:1
		return lens__6 } else { if A_arbace_j2g_zlib_A_const_10 != nil { var parent__7 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, int64(n__3))).Ref()).Ref(); var start__8 any; var root_29 any = A_arbace_j2g_zlib_A_const_11.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_31 lang.IFn






			if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_12.GetRawRoot__O()).Invoke__O(); var arg_33 any; var root_37 any = A_arbace_j2g_zlib_A_const_13.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var tmp6 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(fs__4); var tmp7 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class = fncls__42d; tmp7 = fncls__42d } else { tmp7 = fncls__42 }; arg_40 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_41 any = syms__5; if linked_38 == nil { arg_33 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { arg_33 = linked_38.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) }; if linked_30 == nil { start__8 = ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { start__8 = linked_30.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_29, arg_32, arg_33) }
//line :55:1
			var ___9 any; var tmp8 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(parent__7, n__3, start__8); var tmp9 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class; _ = ___9







			if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class = fncls__66d; tmp9 = fncls__66d } else { tmp9 = fncls__66 }; ___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O()
//line :55:1
			var root__10 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(n__3), lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(syms__5)))), -1); var maxlen__11 any; var root_67 any = A_arbace_j2g_zlib_A_const_16.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_69 lang.IFn















			if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var tmp10 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(parent__7, lens__6, root__10); var tmp11 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class = fncls__74d; tmp11 = fncls__74d } else { tmp11 = fncls__74 }; arg_70 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_71 any = A_arbace_j2g_zlib_A_const_17; var arg_72 any = syms__5; if linked_68 == nil { maxlen__11 = ifn_69.Invoke_O_O_O__O(arg_70, arg_71, arg_72) } else { maxlen__11 = linked_68.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_67, arg_70, arg_71, arg_72)
			}



			var tmp12 bool; var na_75 any = maxlen__11; var na_76 int64 = limit__1; if jrt.Long_InstanceOf(na_75) { var n0_77 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); var n1_78 int64 = na_76; tmp12 = n0_77 <= n1_78 } else { tmp12 = lang.Numbers_Lte_O_J__Z_NoInit(na_75, na_76) }; if tmp12 { return lens__6 } else { var f2__12 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__3).Ref()).Ref(); var n__1927000701__auto____13 int64 = lang.RT_LongCast_I__J_NoInit(n__3); var i__14 int64 = 0; L2: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i__14, n__1927000701__auto____13) { var f__15 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](fs__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__14))
					if lang.Numbers_IsPos_J__Z_NoInit(f__15) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](f2__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__14), lang.Numbers_Max_J_J__J_NoInit(1, lang.Numbers_ShiftRight_J_J__J_NoInit(f__15, 1)))) }
//line :79:1
					i__14 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__14); continue L2 }
//line :76:1
				break L2
			}



				fs__4 = f2__12; continue L1 } } else {
//line :55:1
					return nil } } } } }; /*line :46:1*/panic("j2g: unreachable") }
//line :46:1
func (t *A_arbace_j2g_zlib_huffman_lengths_A) Invoke_O_O_O__O(self, freqs__0, p_limit__1 any) any { return t.InvokePrim_O_O_J__O(self, freqs__0, lang.RT_LongCast_O__J_NoInit(p_limit__1)) }






func A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :53:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A) Invoke_O_O__O(self, p1__1931000018_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000018_SHARP___1))))).Ref() }








func A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_New_O(p0 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A{}; t.Ctor_O(p0); return t }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Ctor_O(c__fs any) { t.F_fs = c__fs }
//line :62:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_fs, jrt.Prim_long.ArrayClass()); return lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__1)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(s__1)).Ref()) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Ctor_O_I_O(c__parent any, c__n int32, c__start any) { t.F_parent = c__parent; t.F_n = c__n; t.F_start = c__start }
//line :63:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A) Invoke_O__O(self any) any { { var q__1 any; var t_ any = t.F_start; t.F_start = nil; q__1 = t_; var next_id__2 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); var order__3 int64 = lang.RT_LongCast_I__J_NoInit(t.F_n); L1: for {
											if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(q__1)), 1) { var a__4 any; var root_43 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_45 lang.IFn
												if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = q__1; if linked_44 == nil { a__4 = ifn_45.Invoke_O__O(arg_46) } else { a__4 = linked_44.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_43, arg_46) }
//line :64:1
		var q__5 any; var root_47 any = A_arbace_j2g_zlib_A_const_15.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_49 lang.IFn
		if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = q__1; var arg_51 any = a__4; if linked_48 == nil { q__5 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { q__5 = linked_48.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }
//line :64:1
		var b__6 any; var root_52 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_54 lang.IFn
		if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = q__5; if linked_53 == nil { b__6 = ifn_54.Invoke_O__O(arg_55) } else { b__6 = linked_53.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_52, arg_55) }
//line :64:1
		var q__7 any; var root_56 any = A_arbace_j2g_zlib_A_const_15.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_58 lang.IFn
		if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = q__5; var arg_60 any = b__6; if linked_57 == nil { q__7 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { q__7 = linked_57.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }
		var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(2)))), next_id__2))
		var tmp3 any; var root_61 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = q__7; var arg_65 any = lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(a__4, lang.RT_IntCast_J__I_NoInit(0))), lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(b__6, lang.RT_IntCast_J__I_NoInit(0))))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(order__3).Ref(), jrt.Long_ValueOf_J__Long_NoInit(next_id__2).Ref()); if linked_62 == nil { tmp3 = ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { tmp3 = linked_62.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_61, arg_64, arg_65) }; q__1, next_id__2, order__3 = tmp3, lang.Numbers_Inc_J__J_NoInit(next_id__2), lang.Numbers_Inc_J__J_NoInit(order__3); continue L1 } else {
//line :64:1
			return nil } } }; /*line :63:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Ctor_O_O_J(c__parent, c__lens any, c__root int64) { t.F_parent = c__parent; t.F_lens = c__lens; t.F_root = c__root }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) InvokePrim_O_J_O__O(self any, m__1 int64, s__2 any) any { var d__3 int64; var tmp1 any = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(t.F_parent, s__2, t.F_root); var tmp2 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class; if
															fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class = fncls__73d; tmp2 = fncls__73d } else { tmp2 = fncls__73 }; d__3 = lang.RT_LongCast_O__J_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()); var tmp3 /*line :73:1*/*jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_lens, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp3, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__2)), d__3)); return /*line :74:1*/ jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Max_J_J__J_NoInit(m__1, d__3)).Ref() }
//line :71:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A) Invoke_O_O_O__O(self, p_m__1, s__2 any) any { return t.InvokePrim_O_J_O__O(self, lang.RT_LongCast_O__J_NoInit(p_m__1), s__2) }
func A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Ctor_O_O_J(c__parent, c__s any, c__root int64) { t.F_parent = c__parent; t.F_s = c__s; t.F_root = c__root }
//line :72:1
func (t *A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A) Invoke_O__O(self any) any { { var x__1 int64; var tmp1 any; var t_ any = t.F_s; t.F_s = nil; tmp1 = t_; x__1 = lang.RT_LongCast_O__J_NoInit(tmp1); var d__2 int64 = 0; L1: for { if lang.Numbers_Equiv_J_J__Z_NoInit(x__1, t.F_root) { return jrt.Long_ValueOf_J__Long_NoInit(d__2).Ref() } else { var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_parent, jrt.Prim_long.ArrayClass()); x__1, d__2 = lang.RT_Aget_J1_I__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(x__1))), lang.Numbers_Inc_J__J_NoInit(d__2); continue L1 } } }; panic("j2g: unreachable") }










func A_arbace_j2g_zlib_canonical_codes_A_New() *A_arbace_j2g_zlib_canonical_codes_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_canonical_codes_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_zlib_canonical_codes_A) Invoke_O_O__O(self, lens__0 any) any { var n__2 int32 = lang.RT_Alength_J1__I_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass())); var bl_count__3 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var next_code__4 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_18).Ref(); var codes__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(n__2).Ref()).Ref(); var n__1927000701__auto____6 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7 int64 = 0; L1: for {







	if lang.Numbers_Lt_J_J__Z_NoInit(i__7, n__1927000701__auto____6) { var l__8 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__7)); if lang.Numbers_IsPos_J__Z_NoInit(l__8) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8)))))) }; i__7 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7); continue L1 }
//line :83:1
	break L1 }; var bits__6 int64 = 1; var code__7 int64 = 0; L2: for {









		if lang.Numbers_Lt_J_J__Z_NoInit(bits__6, 16) { var code__8 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(code__7, lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bl_count__3, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(bits__6)))), 1)

			jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(bits__6), code__8))
			bits__6, code__7 = lang.Numbers_Inc_J__J_NoInit(bits__6), code__8; continue L2 }
//line :83:1
		break L2 }; var n__1927000701__auto____6_2 int64 = lang.RT_LongCast_I__J_NoInit(n__2); var i__7_2 int64 = 0; L3: for {













			if lang.Numbers_Lt_J_J__Z_NoInit(i__7_2, n__1927000701__auto____6_2) { var l__8_2 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lens__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__7_2))

				if lang.Numbers_IsPos_J__Z_NoInit(l__8_2) {
					var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](codes__5, jrt.Prim_long.ArrayClass()); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__7_2); var tmp3 int64; var root_84 any = A_arbace_j2g_zlib_A_const_19.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_84, A_arbace_j2g_zlib_reverse_bits_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2))); var arg_88 int64 = l__8_2; if linked_85 == nil { tmp3 = lang.RT_LongCast_O__J_NoInit(ifn_86.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_87).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_88).Ref())) } else { tmp3 = linked_85.(*A_arbace_j2g_zlib_reverse_bits_A).InvokePrim_O_J_J__J(root_84, arg_87, arg_88) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, tmp2, tmp3))
					jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](next_code__4, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(l__8_2)))))) }
//line :97:1
				i__7_2 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__7_2); continue L3 }
//line :83:1
			break L3 }; return codes__5 }





























func A_arbace_j2g_zlib_code_of_A_New() *A_arbace_j2g_zlib_code_of_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_code_of_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) InvokePrim_O_O_J__J(self, bases__0 any, v__1 int64) int64 { { var i__3 int64 = lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Alength_J1__I_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass())))); L1: for {


	if lang.Numbers_Gt_J_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](bases__0, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__3)), v__1) { i__3 = lang.Numbers_Dec_J__J_NoInit(i__3); continue L1 } else { return i__3 } } }; /*line :113:1*/panic("j2g: unreachable") }
//line :113:1
func (t *A_arbace_j2g_zlib_code_of_A) Invoke_O_O_O__O(self, bases__0, p_v__1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_J__J(self, bases__0, lang.RT_LongCast_O__J_NoInit(p_v__1))).Ref() }













func A_arbace_j2g_zlib_match_length_A_New() *A_arbace_j2g_zlib_match_length_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_match_length_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Ctor() {}
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) InvokePrim_O_O_J_J_J__J(self, b__0 any, i__1, j__2, max__3 int64) int64 { { var k__5 int64 = 0; L1: for {


	var tmp1 bool; var and__1927000168__auto____6 bool = lang.Numbers_Lt_J_J__Z_NoInit(k__5, max__3); if and__1927000168__auto____6 { tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__1, k__5)))).Ref()), lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(j__2, k__5)))).Ref())) } else { tmp1 = and__1927000168__auto____6 }; if tmp1 { k__5 = lang.Numbers_Inc_J__J_NoInit(k__5); continue L1 } else { return k__5 } } }; /*line :127:1*/panic("j2g: unreachable") }
//line :127:1
func (t *A_arbace_j2g_zlib_match_length_A) Invoke_O_O_O_O_O__O(self, b__0, p_i__1, p_j__2, p_max__3 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_J_J_J__J(self, b__0, lang.RT_LongCast_O__J_NoInit(p_i__1), lang.RT_LongCast_O__J_NoInit(p_j__2), lang.RT_LongCast_O__J_NoInit(p_max__3))).Ref() }




func A_arbace_j2g_zlib_insert_BANG__A_New() *A_arbace_j2g_zlib_insert_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_insert_BANG__A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) InvokePrim_O_O_O_O_J__O(self, b__0, head__1, prev__2 any, i__3 int64) any {



	if lang.Numbers_Lte_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 3), int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var h__5 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_Xor_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__3))).Ref()), 255), 8), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 1)))).Ref()), 255), 4)), lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255)), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__3, 2)))).Ref()), 255), 11)), 65535)





		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__2, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__3), lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(h__5))))
		jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Aset_I1_I_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](head__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(h__5), lang.RT_IntCast_J__I_NoInit(i__3))) }
//line :132:1
	return nil }
//line :132:1
func (t *A_arbace_j2g_zlib_insert_BANG__A) Invoke_O_O_O_O_O__O(self, b__0, head__1, prev__2, p_i__3 any) any { return t.InvokePrim_O_O_O_O_J__O(self, b__0, head__1, prev__2, lang.RT_LongCast_O__J_NoInit(p_i__3)) }













func A_arbace_j2g_zlib_longest_A_New() *A_arbace_j2g_zlib_longest_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_longest_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) InvokePrim_O_O_O_J__J(self, b__0, prev__1 any, i__2 int64) int64 { { var n__4 int32 = lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()))




	if lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__2, 3), int64(n__4)) { return 0 } else { var maxl__5 int64 = lang.Numbers_Min_J_J__J_NoInit(258, lang.Numbers_Minus_J_J__J_NoInit(int64(n__4), i__2)); var j__6 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__2))); var chain__7 int64 = 0; var best__8 any = lang.RT_Box_J__Number_NoInit(0); var bestd__9 int64 = 0; L1: for {



		var tmp1 bool; var or__1927000174__auto____10 bool = lang.Numbers_IsNeg_J__Z_NoInit(j__6); if or__1927000174__auto____10 { tmp1 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 bool = lang.Numbers_Gt_J_J__Z_NoInit(lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6), 32768); if or__1927000174__auto____11 { tmp1 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 bool = lang.Numbers_Gte_J_J__Z_NoInit(chain__7, 64); if or__1927000174__auto____12 { tmp1 = or__1927000174__auto____12 } else { var or__1927000174__auto____13 bool; var na_89 any = best__8; var na_90 int64 = 64; if jrt.Long_InstanceOf(na_89) { var n0_91 int64 = jrt.NN(jrt.Long_Cast(na_89)).LongValue__J(); var n1_92 int64 = na_90; or__1927000174__auto____13 = n0_91 >= n1_92 } else { or__1927000174__auto____13 = lang.Numbers_Gte_O_J__Z_NoInit(na_89, na_90) }; if or__1927000174__auto____13 { tmp1 = or__1927000174__auto____13 } else { var na_94 any = best__8; var na_95 int64 = maxl__5; if jrt.Long_InstanceOf(na_94) { var n0_96 int64 = jrt.NN(jrt.Long_Cast(na_94)).LongValue__J(); var n1_97 int64 = na_95; tmp1 = n0_96 >= n1_97 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_94, na_95) } } } } }; if tmp1 {
			var tmp2 bool; var na_99 any = best__8; var na_100 int64 = 3; if jrt.Long_InstanceOf(na_99) { var n0_101 int64 = jrt.NN(jrt.Long_Cast(na_99)).LongValue__J(); var n1_102 int64 = na_100; tmp2 = n0_101 >= n1_102 } else { tmp2 = lang.Numbers_Gte_O_J__Z_NoInit(na_99, na_100) }; if tmp2 { var tmp3 int64; var na_104 any = best__8; var na_105 int64 = 16; if jrt.Long_InstanceOf(na_104) { var n0_106 int64 = jrt.NN(jrt.Long_Cast(na_104)).LongValue__J(); var n1_107 int64 = na_105; tmp3 = n0_106 << (n1_107 & 63) } else { tmp3 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_104, na_105) }; return lang.Numbers_Or_J_J__J_NoInit(tmp3, bestd__9) } else { return 0 } } else {
//line :155:1
				var l__10 any; var tmp4 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()); var tmp5 jrt.Number_I
				var na_109 int64 = j__6; var na_110 any = best__8
				if jrt.Long_InstanceOf(na_110) { var n0_111 int64 = na_109; var n1_112 int64 = jrt.NN(jrt.Long_Cast(na_110)).LongValue__J(); var nr_113 int64 = n0_111 + n1_112; if (n0_111^nr_113)&(n1_112^nr_113) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_113)) } else { tmp5 = lang.Numbers_Add_J_O__Number_NoInit(na_109, na_110) } } else { tmp5 = lang.Numbers_Add_J_O__Number_NoInit(na_109, na_110) }; var tmp6 int64 = lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp4, lang.RT_IntCast_O__I_NoInit(tmp5))).Ref()); var tmp7 *jrt.ByteArray = jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()); var tmp8 jrt.Number_I; var na_114 int64 = i__2; var na_115 any = best__8; if jrt.Long_InstanceOf(na_115) { var n0_116 int64 = na_114; var n1_117 int64 = jrt.NN(jrt.Long_Cast(na_115)).LongValue__J(); var nr_118 int64 = n0_116 + n1_117; if (n0_116^nr_118)&(n1_117^nr_118) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_118)) } else { tmp8 = lang.Numbers_Add_J_O__Number_NoInit(na_114, na_115) } } else { tmp8 = lang.Numbers_Add_J_O__Number_NoInit(na_114, na_115) }; if lang.Numbers_Equiv_J_J__Z_NoInit(tmp6, lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(tmp7, lang.RT_IntCast_O__I_NoInit(tmp8))).Ref())) {
					var root_119 any = A_arbace_j2g_zlib_A_const_20.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_119, A_arbace_j2g_zlib_match_length_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = b__0; var arg_123 int64 = i__2; var arg_124 int64 = j__6; var arg_125 int64 = maxl__5; if linked_120 == nil { l__10 = ifn_121.Invoke_O_O_O_O__O(arg_122, jrt.Long_ValueOf_J__Long_NoInit(arg_123).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_124).Ref(), jrt.Long_ValueOf_J__Long_NoInit(arg_125).Ref()) } else { l__10 = jrt.Long_ValueOf_J__Long_NoInit(linked_120.(*A_arbace_j2g_zlib_match_length_A).InvokePrim_O_O_J_J_J__J(root_119, arg_122, arg_123, arg_124, arg_125)).Ref() } } else {
//line :157:1
						l__10 = A_arbace_j2g_zlib_A_const_17
					}

				var tmp9 bool; var na_126 int64 = lang.RT_LongCast_O__J_NoInit(l__10); var na_127 any = best__8; if jrt.Long_InstanceOf(na_127) { var n0_128 int64 = na_126; var n1_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); tmp9 = n0_128 > n1_129 } else { tmp9 = lang.Numbers_Gt_J_O__Z_NoInit(na_126, na_127) }; if tmp9 {
					j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), l__10, lang.Numbers_Minus_J_J__J_NoInit(i__2, j__6); continue L1 } else {
						j__6, chain__7, best__8, bestd__9 = lang.RT_LongCast_I__J_NoInit(lang.RT_Aget_I1_I__I_NoInit(jrt.J2g_CastArray[*jrt.IntArray](prev__1, jrt.Prim_int.ArrayClass()), lang.RT_IntCast_J__I_NoInit(j__6))), lang.Numbers_Inc_J__J_NoInit(chain__7), best__8, bestd__9; continue L1 } } } } }; /*line :146:1*/panic("j2g: unreachable") }
//line :146:1
func (t *A_arbace_j2g_zlib_longest_A) Invoke_O_O_O_O__O(self, b__0, prev__1, p_i__2 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O_O_J__J(self, b__0, prev__1, lang.RT_LongCast_O__J_NoInit(p_i__2))).Ref() }

















func A_arbace_j2g_zlib_lz77_A_New() *A_arbace_j2g_zlib_lz77_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_lz77_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_zlib_lz77_A) Invoke_O_O__O(self, b__0 any) any { { var n__2 int32 = lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())); var head__3 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(65536), A_arbace_j2g_zlib_A_const_21).Ref(); var prev__4 any = lang.Numbers_Int_array_I_O__I1_NoInit(lang.RT_IntCast_J__I_NoInit(lang.Numbers_Max_J_J__J_NoInit(int64(n__2), 1)), A_arbace_j2g_zlib_A_const_21).Ref(); var out__5 any = lang.Numbers_Long_array_O__J1_NoInit(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(n__2))).Ref()).Ref(); var flag__6 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(1, 40); var i__7 int64 = 0; var k__8 int64 = 0; var pending__9 any = lang.RT_Box_J__Number_NoInit(0); L1: for {











	if lang.Numbers_Gte_J_J__Z_NoInit(i__7, int64(n__2)) {
		var tmp1 bool; var na_131 any = pending__9; if jrt.Long_InstanceOf(na_131) { var n0_132 int64 = jrt.NN(jrt.Long_Cast(na_131)).LongValue__J(); tmp1 = n0_132 > 0 } else { if jrt.Double_InstanceOf(na_131) { var n0_132_2 float64 = jrt.NN(jrt.Double_Cast(na_131)).DoubleValue__D(); tmp1 = n0_132_2 > 0.0 } else { tmp1 = lang.Numbers_IsPos_O__Z_NoInit(na_131) } }; if tmp1 {
			var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()); var tmp3 int32 = lang.RT_IntCast_J__I_NoInit(k__8); var tmp4 int64; var na_158 any = pending__9; var na_159 int64 = flag__6; if jrt.Long_InstanceOf(na_158) { var n0_160 int64 = jrt.NN(jrt.Long_Cast(na_158)).LongValue__J(); var n1_161 int64 = na_159; tmp4 = n0_160 | n1_161 } else { tmp4 = lang.Numbers_Or_O_J__J_NoInit(na_158, na_159) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, tmp3, tmp4))
//line :177:1
			return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(k__8)).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(out__5, jrt.Long_ValueOf_J__Long_NoInit(k__8).Ref()) } } else {



				var root_163 any = A_arbace_j2g_zlib_A_const_23.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_163, A_arbace_j2g_zlib_insert_BANG__A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = b__0; var arg_167 any = head__3; var arg_168 any = prev__4; var arg_169 int64 = i__7; if linked_164 == nil { ifn_165.Invoke_O_O_O_O__O(arg_166, arg_167, arg_168, jrt.Long_ValueOf_J__Long_NoInit(arg_169).Ref()) } else { linked_164.(*A_arbace_j2g_zlib_insert_BANG__A).InvokePrim_O_O_O_O_J__O(root_163, arg_166, arg_167, arg_168, arg_169) }
//line :176:1
				var m__10 any; var root_133 any = A_arbace_j2g_zlib_A_const_22.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_133, A_arbace_j2g_zlib_longest_A_fn_class); var ifn_135 lang.IFn





				if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = b__0; var arg_137 any = prev__4; var arg_138 int64 = i__7; if linked_134 == nil { m__10 = ifn_135.Invoke_O_O_O__O(arg_136, arg_137, jrt.Long_ValueOf_J__Long_NoInit(arg_138).Ref()) } else { m__10 = jrt.Long_ValueOf_J__Long_NoInit(linked_134.(*A_arbace_j2g_zlib_longest_A).InvokePrim_O_O_O_J__J(root_133, arg_136, arg_137, arg_138)).Ref() }
				var tmp5 bool; var na_139 any = pending__9
				if jrt.Long_InstanceOf(na_139) { var n0_140 int64 = jrt.NN(jrt.Long_Cast(na_139)).LongValue__J(); tmp5 = n0_140 > 0 } else { if jrt.Double_InstanceOf(na_139) { var n0_140_2 float64 = jrt.NN(jrt.Double_Cast(na_139)).DoubleValue__D(); tmp5 = n0_140_2 > 0.0 } else { tmp5 = lang.Numbers_IsPos_O__Z_NoInit(na_139) } }
//line :183:1
				if tmp5 {

					var tmp6 int64; var na_141 any = m__10; var na_142 int64 = 16; if jrt.Long_InstanceOf(na_141) { var n0_143 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); var n1_144 int64 = na_142; tmp6 = n0_143 >> (n1_144 & 63) } else { tmp6 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_141, na_142) }; var tmp7 int64 = tmp6; var tmp8 int64; var na_146 any = pending__9; var na_147 int64 = 16; if jrt.Long_InstanceOf(na_146) { var n0_148 int64 = jrt.NN(jrt.Long_Cast(na_146)).LongValue__J(); var n1_149 int64 = na_147; tmp8 = n0_148 >> (n1_149 & 63) } else { tmp8 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_146, na_147) }; if lang.Numbers_Gt_J_J__Z_NoInit(tmp7, tmp8) {

						jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(lang.Numbers_Dec_J__J_NoInit(i__7)))).Ref()), 255))))
						i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), m__10; continue L1 } else {
//line :185:1
							var end__11 int64; var tmp9 int64 = lang.Numbers_Dec_J__J_NoInit(i__7); var tmp10 int64
							var na_151 any = pending__9
							var na_152 int64 = 16


							if jrt.Long_InstanceOf(na_151) { var n0_153 int64 = jrt.NN(jrt.Long_Cast(na_151)).LongValue__J(); var n1_154 int64 = na_152; tmp10 = n0_153 >> (n1_154 & 63) } else { tmp10 = lang.Numbers_ShiftRight_O_J__J_NoInit(na_151, na_152) }; end__11 = lang.Numbers_Add_J_J__J_NoInit(tmp9, tmp10)
							var tmp11 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()); var tmp12 int32 = lang.RT_IntCast_J__I_NoInit(k__8); var tmp13 int64; var na_170 any = pending__9; var na_171 int64 = flag__6; if jrt.Long_InstanceOf(na_170) { var n0_172 int64 = jrt.NN(jrt.Long_Cast(na_170)).LongValue__J(); var n1_173 int64 = na_171; tmp13 = n0_172 | n1_173 } else { tmp13 = lang.Numbers_Or_O_J__J_NoInit(na_170, na_171) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp11, tmp12, tmp13))
//line :185:1
							var x__12 int64 = lang.Numbers_Inc_J__J_NoInit(i__7); L2: for {






								if lang.Numbers_Lt_J_J__Z_NoInit(x__12, end__11) { var root_175 any = A_arbace_j2g_zlib_A_const_23.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_175, A_arbace_j2g_zlib_insert_BANG__A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = b__0; var arg_179 any = head__3; var arg_180 any = prev__4; var arg_181 int64 = x__12; if linked_176 == nil { ifn_177.Invoke_O_O_O_O__O(arg_178, arg_179, arg_180, jrt.Long_ValueOf_J__Long_NoInit(arg_181).Ref()) } else { linked_176.(*A_arbace_j2g_zlib_insert_BANG__A).InvokePrim_O_O_O_O_J__O(root_175, arg_178, arg_179, arg_180, arg_181) }; x__12 = lang.Numbers_Inc_J__J_NoInit(x__12); continue L2 }
//line :185:1
								break L2
							}






							i__7, k__8, pending__9 = end__11, lang.Numbers_Inc_J__J_NoInit(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } } else {
//line :183:1
								var tmp14 bool
								var na_156 any = m__10









								if jrt.Long_InstanceOf(na_156) { var n0_157 int64 = jrt.NN(jrt.Long_Cast(na_156)).LongValue__J(); tmp14 = n0_157 > 0 } else { if jrt.Double_InstanceOf(na_156) { var n0_157_2 float64 = jrt.NN(jrt.Double_Cast(na_156)).DoubleValue__D(); tmp14 = n0_157_2 > 0.0 } else { tmp14 = lang.Numbers_IsPos_O__Z_NoInit(na_156) } }
//line :183:1
								if tmp14 {










									i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), k__8, m__10; continue L1 } else {
//line :183:1
										if A_arbace_j2g_zlib_A_const_10 != nil {











											jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](out__5, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(k__8), lang.RT_LongCast_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__7))).Ref()), 255))))
											i__7, k__8, pending__9 = lang.Numbers_Inc_J__J_NoInit(i__7), lang.Numbers_Inc_J__J_NoInit(k__8), A_arbace_j2g_zlib_A_const_17; continue L1 } else {
//line :183:1
												return nil } } } } } }; /*line :164:1*/panic("j2g: unreachable") }







































func A_arbace_j2g_zlib_rle_lengths_A_New() *A_arbace_j2g_zlib_rle_lengths_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Ctor() {}
//line :204:1
func (t *A_arbace_j2g_zlib_rle_lengths_A) Invoke_O_O__O(self, ls__0 any) any { { var v__2 any; var root_182 any = A_arbace_j2g_zlib_A_const_24.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_184 lang.IFn


	if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = ls__0; if linked_183 == nil { v__2 = ifn_184.Invoke_O__O(arg_185) } else { v__2 = linked_183.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_182, arg_185) }
//line :204:1
	var n__3 int32 = lang.RT_Count_O__I_NoInit(v__2); var i__4 any = lang.RT_Box_J__Number_NoInit(0); var acc__5 any = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp1 bool; var na_186 any = i__4; var na_187 int64 = int64(n__3); if jrt.Long_InstanceOf(na_186) { var n0_188 int64 = jrt.NN(jrt.Long_Cast(na_186)).LongValue__J(); var n1_189 int64 = na_187; tmp1 = n0_188 >= n1_189 } else { tmp1 = lang.Numbers_Gte_O_J__Z_NoInit(na_186, na_187) }; if tmp1 { return acc__5 } else { var x__6 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(v__2, lang.RT_IntCast_O__I_NoInit(i__4))); var run__7 any; var tmp2 any = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(i__4, n__3, x__6, v__2); var tmp3 *jrt.Class
			var fncls__203 /*line :209:1*/*jrt.Class = A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class


			if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class = fncls__203d; tmp3 = fncls__203d } else { tmp3 = fncls__203 }; run__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
			var tmp4 bool; var and__1927000168__auto____8 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)
			if and__1927000168__auto____8 { var na_204 any = run__7; var na_205 int64 = 11; if jrt.Long_InstanceOf(na_204) { var n0_206 int64 = jrt.NN(jrt.Long_Cast(na_204)).LongValue__J(); var n1_207 int64 = na_205; tmp4 = n0_206 >= n1_207 } else { tmp4 = lang.Numbers_Gte_O_J__Z_NoInit(na_204, na_205) } } else { tmp4 = and__1927000168__auto____8 }
//line :213:1
			if tmp4 { var r__8 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 138); var tmp5 jrt.Number_I; var na_221 any = i__4; var na_222 any = r__8; var tmp6 bool; var tmp7 bool
				tmp7 = jrt.Long_InstanceOf(na_221); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_222) }; tmp6 = tmp7; if tmp6 { var n0_223 int64 = jrt.NN(jrt.Long_Cast(na_221)).LongValue__J(); var n1_224 int64 = jrt.NN(jrt.Long_Cast(na_222)).LongValue__J(); var nr_225 int64 = n0_223 + n1_224; if (n0_223^nr_225)&(n1_224^nr_225) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_225)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_221, na_222) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_221); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_222) }; tmp8 = tmp9; if tmp8 { var n0_223_2 float64 = jrt.NN(jrt.Double_Cast(na_221)).DoubleValue__D(); var n1_224_2 float64 = jrt.NN(jrt.Double_Cast(na_222)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_223_2 + n1_224_2)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_221, na_222) } }; var tmp10 any = tmp5; var tmp11 any; var root_226 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = acc__5; var arg_230 any; var tmp12 any = A_arbace_j2g_zlib_A_const_25; var tmp13 jrt.Number_I; var na_231 any = r__8; var na_232 int64 = 11; if jrt.Long_InstanceOf(na_231) { var n0_233 int64 = jrt.NN(jrt.Long_Cast(na_231)).LongValue__J(); var n1_234 int64 = na_232; var nr_235 int64 = n0_233 - n1_234; var tmp14 bool; var tmp15 bool; tmp15 = !(n1_234 == -9223372036854775808); if tmp15 { tmp15 = (n0_233^n1_234)&(n0_233^nr_235) >= 0 }; tmp14 = tmp15; if tmp14 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_235)) } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_231, na_232) } } else { tmp13 = lang.Numbers_Minus_O_J__Number_NoInit(na_231, na_232) }; arg_230 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); if linked_227 == nil { tmp11 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { tmp11 = linked_227.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_226, arg_229, arg_230) }; i__4, acc__5 = tmp10, tmp11; continue L1 } else {
//line :213:1
					var tmp16 bool; var and__1927000168__auto____8_2 bool = lang.Numbers_IsZero_J__Z_NoInit(x__6)

					if and__1927000168__auto____8_2 { var na_209 any = run__7; var na_210 int64 = 3; if jrt.Long_InstanceOf(na_209) { var n0_211 int64 = jrt.NN(jrt.Long_Cast(na_209)).LongValue__J(); var n1_212 int64 = na_210; tmp16 = n0_211 >= n1_212 } else { tmp16 = lang.Numbers_Gte_O_J__Z_NoInit(na_209, na_210) } } else { tmp16 = and__1927000168__auto____8_2 }
//line :213:1
					if tmp16 { var r__8_2 any = lang.Numbers_Min_O_J__O_NoInit(run__7, 10); var tmp17 jrt.Number_I; var na_236 any = i__4; var na_237 any = r__8_2; var tmp18 bool; var tmp19 bool

						tmp19 = jrt.Long_InstanceOf(na_236); if tmp19 { tmp19 = jrt.Long_InstanceOf(na_237) }; tmp18 = tmp19; if tmp18 { var n0_238 int64 = jrt.NN(jrt.Long_Cast(na_236)).LongValue__J(); var n1_239 int64 = jrt.NN(jrt.Long_Cast(na_237)).LongValue__J(); var nr_240 int64 = n0_238 + n1_239; if (n0_238^nr_240)&(n1_239^nr_240) >= 0 { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_240)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_236, na_237) } } else { var tmp20 bool; var tmp21 bool; tmp21 = jrt.Double_InstanceOf(na_236); if tmp21 { tmp21 = jrt.Double_InstanceOf(na_237) }; tmp20 = tmp21; if tmp20 { var n0_238_2 float64 = jrt.NN(jrt.Double_Cast(na_236)).DoubleValue__D(); var n1_239_2 float64 = jrt.NN(jrt.Double_Cast(na_237)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_238_2 + n1_239_2)) } else { tmp17 = lang.Numbers_Add_O_O__Number_NoInit(na_236, na_237) } }; var tmp22 any = tmp17; var tmp23 any; var root_241 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = acc__5; var arg_245 any; var tmp24 any = A_arbace_j2g_zlib_A_const_26; var tmp25 jrt.Number_I; var na_246 any = r__8_2; var na_247 int64 = 3; if jrt.Long_InstanceOf(na_246) { var n0_248 int64 = jrt.NN(jrt.Long_Cast(na_246)).LongValue__J(); var n1_249 int64 = na_247; var nr_250 int64 = n0_248 - n1_249; var tmp26 bool; var tmp27 bool; tmp27 = !(n1_249 == -9223372036854775808); if tmp27 { tmp27 = (n0_248^n1_249)&(n0_248^nr_250) >= 0 }; tmp26 = tmp27; if tmp26 { tmp25 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_250)) } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_246, na_247) } } else { tmp25 = lang.Numbers_Minus_O_J__Number_NoInit(na_246, na_247) }; arg_245 = lang.Tuple_Create_O_O__IPersistentVector(tmp24, tmp25); if linked_242 == nil { tmp23 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { tmp23 = linked_242.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }; i__4, acc__5 = tmp22, tmp23; continue L1 } else {
//line :213:1
							var tmp28 bool; var and__1927000168__auto____8_3 bool = lang.Numbers_IsPos_J__Z_NoInit(x__6)


							if and__1927000168__auto____8_3 { var na_214 any = run__7; var na_215 int64 = 4; if jrt.Long_InstanceOf(na_214) { var n0_216 int64 = jrt.NN(jrt.Long_Cast(na_214)).LongValue__J(); var n1_217 int64 = na_215; tmp28 = n0_216 >= n1_217 } else { tmp28 = lang.Numbers_Gte_O_J__Z_NoInit(na_214, na_215) } } else { tmp28 = and__1927000168__auto____8_3 }
//line :213:1
							if tmp28 { var r__8_3 any; var tmp29 jrt.Number_I
								var na_219 any = run__7

								if jrt.Long_InstanceOf(na_219) { var n0_220 int64 = jrt.NN(jrt.Long_Cast(na_219)).LongValue__J(); if n0_220 == -9223372036854775808 { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_219) } else { tmp29 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_220 - 1)) } } else { if jrt.Double_InstanceOf(na_219) { var n0_220_2 float64 = jrt.NN(jrt.Double_Cast(na_219)).DoubleValue__D(); tmp29 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_220_2 - 1.0)) } else { tmp29 = lang.Numbers_Dec_O__Number_NoInit(na_219) } }; r__8_3 = lang.Numbers_Min_O_J__O_NoInit(tmp29, 6); var tmp30 jrt.Number_I; var na_251 any; var na_253 any = i__4; var na_254 int64 = 1; if jrt.Long_InstanceOf(na_253) { var n0_255 int64 = jrt.NN(jrt.Long_Cast(na_253)).LongValue__J(); var n1_256 int64 = na_254; var nr_257 int64 = n0_255 + n1_256; if (n0_255^nr_257)&(n1_256^nr_257) >= 0 { na_251 = jrt.Long_ValueOf_J__Long_NoInit(nr_257).Ref() } else { na_251 = lang.Numbers_Add_O_J__Number_NoInit(na_253, na_254) } } else { na_251 = lang.Numbers_Add_O_J__Number_NoInit(na_253, na_254) }; var na_252 any = r__8_3; var tmp31 bool; var tmp32 bool; tmp32 = jrt.Long_InstanceOf(na_251); if tmp32 { tmp32 = jrt.Long_InstanceOf(na_252) }; tmp31 = tmp32; if tmp31 { var n0_258 int64 = jrt.NN(jrt.Long_Cast(na_251)).LongValue__J(); var n1_259 int64 = jrt.NN(jrt.Long_Cast(na_252)).LongValue__J(); var nr_260 int64 = n0_258 + n1_259; if (n0_258^nr_260)&(n1_259^nr_260) >= 0 { tmp30 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_260)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_251, na_252) } } else { var tmp33 bool; var tmp34 bool; tmp34 = jrt.Double_InstanceOf(na_251); if tmp34 { tmp34 = jrt.Double_InstanceOf(na_252) }; tmp33 = tmp34; if tmp33 { var n0_258_2 float64 = jrt.NN(jrt.Double_Cast(na_251)).DoubleValue__D(); var n1_259_2 float64 = jrt.NN(jrt.Double_Cast(na_252)).DoubleValue__D(); tmp30 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_258_2 + n1_259_2)) } else { tmp30 = lang.Numbers_Add_O_O__Number_NoInit(na_251, na_252) } }; var tmp35 any = tmp30; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_zlib_A_const_5.GetRawRoot__O()); var tmp37 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17); var tmp38 any = A_arbace_j2g_zlib_A_const_18; var tmp39 jrt.Number_I; var na_267 any = r__8_3; var na_268 int64 = 3; if jrt.Long_InstanceOf(na_267) { var n0_269 int64 = jrt.NN(jrt.Long_Cast(na_267)).LongValue__J(); var n1_270 int64 = na_268; var nr_271 int64 = n0_269 - n1_270; var tmp40 bool; var tmp41 bool; tmp41 = !(n1_270 == -9223372036854775808); if tmp41 { tmp41 = (n0_269^n1_270)&(n0_269^nr_271) >= 0 }; tmp40 = tmp41; if tmp40 { tmp39 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_271)) } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_267, na_268) } } else { tmp39 = lang.Numbers_Minus_O_J__Number_NoInit(na_267, na_268) }; i__4, acc__5 = tmp35, tmp36.Invoke_O_O_O__O(acc__5, tmp37, lang.Tuple_Create_O_O__IPersistentVector(tmp38, tmp39)); continue L1 } else {
//line :213:1
									if A_arbace_j2g_zlib_A_const_10 != nil {



										var tmp42 jrt.Number_I; var na_272 any = i__4; if jrt.Long_InstanceOf(na_272) { var n0_273 int64 = jrt.NN(jrt.Long_Cast(na_272)).LongValue__J(); if n0_273 == 9223372036854775807 { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_272) } else { tmp42 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_273 + 1)) } } else { if jrt.Double_InstanceOf(na_272) { var n0_273_2 float64 = jrt.NN(jrt.Double_Cast(na_272)).DoubleValue__D(); tmp42 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_273_2 + 1.0)) } else { tmp42 = lang.Numbers_Inc_O__Number_NoInit(na_272) } }; var tmp43 any = tmp42; var tmp44 any; var root_274 any = A_arbace_j2g_zlib_A_const_5.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = acc__5; var arg_278 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(x__6).Ref(), A_arbace_j2g_zlib_A_const_17); if linked_275 == nil { tmp44 = ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { tmp44 = linked_275.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_274, arg_277, arg_278) }; i__4, acc__5 = tmp43, tmp44; continue L1 } else {
//line :213:1
											return nil } } } } } } }; /*line :204:1*/panic("j2g: unreachable") }







func A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_New_O_I_J_O(p0 any, p1 int32, p2 int64, p3 any) *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A{}; t.Ctor_O_I_J_O(p0, p1, p2, p3); return t }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Ctor_O_I_J_O(c__i any, c__n int32, c__x int64, c__v any) { t.F_i = c__i; t.F_n = c__n; t.F_x = c__x; t.F_v = c__v }
//line :212:1
func (t *A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A) Invoke_O__O(self any) any { { var j__1 any = t.F_i; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool; var na_191 any = j__1; var na_192 int64 = int64(t.F_n); if jrt.Long_InstanceOf(na_191) { var n0_193 int64 = jrt.NN(jrt.Long_Cast(na_191)).LongValue__J(); var n1_194 int64 = na_192; and__1927000168__auto____2 = n0_193 < n1_194 } else { and__1927000168__auto____2 = lang.Numbers_Lt_O_J__Z_NoInit(na_191, na_192) }; if and__1927000168__auto____2 { var tmp2 int64 = t.F_x; var tmp3 any = t.F_v; tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(tmp2, lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(j__1)))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var tmp4 jrt.Number_I; var na_201 any = j__1; if jrt.Long_InstanceOf(na_201) { var n0_202 int64 = jrt.NN(jrt.Long_Cast(na_201)).LongValue__J(); if n0_202 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_201) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_202 + 1)) } } else { if jrt.Double_InstanceOf(na_201) { var n0_202_2 float64 = jrt.NN(jrt.Double_Cast(na_201)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_202_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_201) } }; j__1 = tmp4; continue L1 } else { var na_196 any = j__1; var na_197 any = t.F_i; var tmp5 bool; var tmp6 bool; tmp6 = jrt.Long_InstanceOf(na_196); if tmp6 { tmp6 = jrt.Long_InstanceOf(na_197) }; tmp5 = tmp6; if tmp5 { var n0_198 int64 = jrt.NN(jrt.Long_Cast(na_196)).LongValue__J(); var n1_199 int64 = jrt.NN(jrt.Long_Cast(na_197)).LongValue__J(); var nr_200 int64 = n0_198 - n1_199; var tmp7 bool; var tmp8 bool; tmp8 = !(n1_199 == -9223372036854775808); if tmp8 { tmp8 = (n0_198^n1_199)&(n0_198^nr_200) >= 0 }; tmp7 = tmp8; if tmp7 { return jrt.Long_ValueOf_J__Long_NoInit(nr_200).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_196, na_197) } } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_196); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_197) }; tmp9 = tmp10; if tmp9 { var n0_198_2 float64 = jrt.NN(jrt.Double_Cast(na_196)).DoubleValue__D(); var n1_199_2 float64 = jrt.NN(jrt.Double_Cast(na_197)).DoubleValue__D(); return jrt.Double_ValueOf_D__Double_NoInit(n0_198_2 + -n1_199_2).Ref() } else { return lang.Numbers_Minus_O_O__Number_NoInit(na_196, na_197) } } } } }; panic("j2g: unreachable") }






func A_arbace_j2g_zlib_write_block_BANG__A_New() *A_arbace_j2g_zlib_write_block_BANG__A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Ctor() {}
//line :219:1
func (t *A_arbace_j2g_zlib_write_block_BANG__A) Invoke_O_O_O_O_O_O__O(self, w__0, syms__1, from__2, to__3, last_QMARK___4 any) any { var from__6 int64 = lang.RT_LongCast_O__J_NoInit(from__2); var to__7 int64 = lang.RT_LongCast_O__J_NoInit(to__3); var lf__8 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_27).Ref(); var df__9 any = lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_28).Ref(); var i__10 int64 = from__6; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__10, to__7) { var s__11 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__10))); var tmp1 any; var root_414 any = A_arbace_j2g_zlib_A_const_48.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_bit_test_A_fn_class); var ifn_416 lang.IFn

		if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = jrt.Long_ValueOf_J__Long_NoInit(s__11).Ref(); var arg_418 any = A_arbace_j2g_zlib_A_const_49; if linked_415 == nil { tmp1 = ifn_416.Invoke_O_O__O(arg_417, arg_418) } else { tmp1 = linked_415.(*aot_arbace_core.A_arbace_core_bit_test_A).Invoke_O_O_O__O(root_414, arg_417, arg_418) }; if jrt.J2g_Truth(tmp1) { var len__12 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__11, 16), 65535); var d__13 int64 = lang.Numbers_And_J_J__J_NoInit(s__11, 65535); var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()); var tmp3 int64; var root_429 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_429, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_431 lang.IFn

			if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_433 int64 = len__12; if linked_430 == nil { tmp3 = lang.RT_LongCast_O__J_NoInit(ifn_431.Invoke_O_O__O(arg_432, jrt.Long_ValueOf_J__Long_NoInit(arg_433).Ref())) } else { tmp3 = linked_430.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_429, arg_432, arg_433) }; var tmp4 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, tmp3)); var tmp5 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()); var tmp6 int64; var root_434 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_434, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_438 int64 = len__12; if linked_435 == nil { tmp6 = lang.RT_LongCast_O__J_NoInit(ifn_436.Invoke_O_O__O(arg_437, jrt.Long_ValueOf_J__Long_NoInit(arg_438).Ref())) } else { tmp6 = linked_435.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_434, arg_437, arg_438) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp2, tmp4, lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp5, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(257, tmp6))))))
			var tmp7 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp8 int64; var root_419 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_419, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_423 int64 = d__13; if linked_420 == nil { tmp8 = lang.RT_LongCast_O__J_NoInit(ifn_421.Invoke_O_O__O(arg_422, jrt.Long_ValueOf_J__Long_NoInit(arg_423).Ref())) } else { tmp8 = linked_420.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_419, arg_422, arg_423) }; var tmp9 int32 = lang.RT_IntCast_J__I_NoInit(tmp8); var tmp10 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp11 int64; var root_424 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_424, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_428 int64 = d__13; if linked_425 == nil { tmp11 = lang.RT_LongCast_O__J_NoInit(ifn_426.Invoke_O_O__O(arg_427, jrt.Long_ValueOf_J__Long_NoInit(arg_428).Ref())) } else { tmp11 = linked_425.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_424, arg_427, arg_428) }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp7, tmp9, lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp10, lang.RT_IntCast_J__I_NoInit(tmp11))))) } else {
				jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__11)))))) }
		i__10 = lang.Numbers_Inc_J__J_NoInit(i__10); continue L1 }
//line :219:1
	break L1 };












	jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lf__8, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(256), 1)); var used__10 int32; var tmp12 any; var root_404 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_406 lang.IFn; if














	linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any; var tmp13 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(df__9); var tmp14 *jrt.Class; var fncls__409 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class; if fncls__409 == nil { var fncls__409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class = fncls__409d; tmp14 = fncls__409d } else { tmp14 = fncls__409 }; arg_407 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_408 any; var root_410 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = A_arbace_j2g_zlib_A_const_28; if linked_411 == nil { arg_408 = ifn_412.Invoke_O__O(arg_413) } else { arg_408 = linked_411.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_410, arg_413) }; if linked_405 == nil { tmp12 = ifn_406.Invoke_O_O__O(arg_407, arg_408) } else { tmp12 = linked_405.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_404, arg_407, arg_408) }; used__10 = lang.RT_Count_O__I_NoInit(tmp12); if
	lang.Numbers_IsZero_J__Z_NoInit(int64(used__10)) { jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), 1)); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1), 1)) } else { if lang.Numbers_Equiv_J_J__Z_NoInit(1, int64(used__10)) {
		var tmp15 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()); var tmp16 int64; if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](df__9, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0))) { tmp16 = 1 } else { tmp16 = 0 }; jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp15, lang.RT_IntCast_J__I_NoInit(tmp16), 1)) } }; var ll__10 any; var root_279 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_279, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_281 lang.IFn; if

















	linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = lf__8; if linked_280 == nil { ll__10 = ifn_281.Invoke_O_O__O(arg_282, A_arbace_j2g_zlib_A_const_30) } else { ll__10 = linked_280.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_279, arg_282, 15) }; var dl__11 any; var root_284 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_284, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_286 lang.IFn; if


















	linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = df__9; if linked_285 == nil { dl__11 = ifn_286.Invoke_O_O__O(arg_287, A_arbace_j2g_zlib_A_const_30) } else { dl__11 = linked_285.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_284, arg_287, 15) }; var lc__12 any; var root_289 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_291 lang.IFn; if



















	linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = ll__10; if linked_290 == nil { lc__12 = ifn_291.Invoke_O__O(arg_292) } else { lc__12 = linked_290.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_289, arg_292) }; var dc__13 any; var root_293 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_295 lang.IFn; if




















	linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = dl__11; if linked_294 == nil { dc__13 = ifn_295.Invoke_O__O(arg_296) } else { dc__13 = linked_294.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_293, arg_296) }; var hlit__14 any; var tmp17 jrt.Number_I; var na_297 any; var or__1927000174__auto____14 any; var root_298 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_32.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_300 lang.IFn; if





















	linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any; var root_302 any = A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var tmp18 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(ll__10); var tmp19 *jrt.Class; var fncls__307 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class; if fncls__307 == nil { var fncls__307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class = fncls__307d; tmp19 = fncls__307d } else { tmp19 = fncls__307 }; arg_305 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var arg_306 any; var root_308 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = A_arbace_j2g_zlib_A_const_34; if linked_309 == nil { arg_306 = ifn_310.Invoke_O__O(arg_311) } else { arg_306 = linked_309.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_308, arg_311) }; if linked_303 == nil { arg_301 = ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { arg_301 = linked_303.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) }; if linked_299 == nil { or__1927000174__auto____14 = ifn_300.Invoke_O__O(arg_301) } else { or__1927000174__auto____14 = linked_299.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_298, arg_301) }; if jrt.J2g_Truth(or__1927000174__auto____14) { na_297 = or__1927000174__auto____14 } else { na_297 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_297) { var n0_312 int64 = jrt.NN(jrt.Long_Cast(na_297)).LongValue__J(); if n0_312 == 9223372036854775807 { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_297) } else { tmp17 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_312 + 1)) } } else { if jrt.Double_InstanceOf(na_297) { var n0_312_2 float64 = jrt.NN(jrt.Double_Cast(na_297)).DoubleValue__D(); tmp17 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_312_2 + 1.0)) } else { tmp17 = lang.Numbers_Inc_O__Number_NoInit(na_297) } }; hlit__14 = lang.Numbers_Max_J_O__O_NoInit(257, tmp17); var hdist__15 any; var tmp20 jrt.Number_I; var na_313 any; var or__1927000174__auto____15 any; var root_314 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_32.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_316 lang.IFn; if






















	linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any; var root_318 any = A_arbace_j2g_zlib_A_const_33.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any; var tmp21 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(dl__11); var tmp22 *jrt.Class; var fncls__323 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class; if fncls__323 == nil { var fncls__323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class = fncls__323d; tmp22 = fncls__323d } else { tmp22 = fncls__323 }; arg_321 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); var arg_322 any; var root_324 any = A_arbace_j2g_zlib_A_const_8.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = A_arbace_j2g_zlib_A_const_28; if linked_325 == nil { arg_322 = ifn_326.Invoke_O__O(arg_327) } else { arg_322 = linked_325.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_324, arg_327) }; if linked_319 == nil { arg_317 = ifn_320.Invoke_O_O__O(arg_321, arg_322) } else { arg_317 = linked_319.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_318, arg_321, arg_322) }; if linked_315 == nil { or__1927000174__auto____15 = ifn_316.Invoke_O__O(arg_317) } else { or__1927000174__auto____15 = linked_315.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_314, arg_317) }; if jrt.J2g_Truth(or__1927000174__auto____15) { na_313 = or__1927000174__auto____15 } else { na_313 = A_arbace_j2g_zlib_A_const_17 }; if jrt.Long_InstanceOf(na_313) { var n0_328 int64 = jrt.NN(jrt.Long_Cast(na_313)).LongValue__J(); if n0_328 == 9223372036854775807 { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_313) } else { tmp20 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_328 + 1)) } } else { if jrt.Double_InstanceOf(na_313) { var n0_328_2 float64 = jrt.NN(jrt.Double_Cast(na_313)).DoubleValue__D(); tmp20 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_328_2 + 1.0)) } else { tmp20 = lang.Numbers_Inc_O__Number_NoInit(na_313) } }; hdist__15 = lang.Numbers_Max_J_O__O_NoInit(1, tmp20); var rle__16 any; var root_329 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_35.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, A_arbace_j2g_zlib_rle_lengths_A_fn_class); var ifn_331 lang.IFn; if























	linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any; var root_333 any = A_arbace_j2g_zlib_A_const_36.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_338 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = hlit__14; var arg_342 any; var root_343 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = ll__10; if linked_344 == nil { arg_342 = ifn_345.Invoke_O__O(arg_346) } else { arg_342 = linked_344.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_343, arg_346) }; if linked_339 == nil { arg_336 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { arg_336 = linked_339.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }; var arg_337 any; var root_347 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = hdist__15; var arg_351 any; var root_352 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = dl__11; if linked_353 == nil { arg_351 = ifn_354.Invoke_O__O(arg_355) } else { arg_351 = linked_353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_352, arg_355) }; if linked_348 == nil { arg_337 = ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { arg_337 = linked_348.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_347, arg_350, arg_351) }; if linked_334 == nil { arg_332 = ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { arg_332 = linked_334.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) }; if linked_330 == nil { rle__16 = ifn_331.Invoke_O__O(arg_332) } else { rle__16 = linked_330.(*A_arbace_j2g_zlib_rle_lengths_A).Invoke_O_O__O(root_329, arg_332) }; var cf__17 any = /*line :219:1*/lang.Numbers_Long_array_O__J1_NoInit(A_arbace_j2g_zlib_A_const_39).Ref(); var ___18 any; var tmp23 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(cf__17, rle__16); var tmp24 *jrt.Class; var fncls__384 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class; _ = ___18; if

























	fncls__384 == nil { var fncls__384d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class = fncls__384d; tmp24 = fncls__384d } else { tmp24 = fncls__384 }; ___18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O(); var cl__19 any; var root_385 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_29.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_385, A_arbace_j2g_zlib_huffman_lengths_A_fn_class); var ifn_387 lang.IFn; if


























	linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = cf__17; if linked_386 == nil { cl__19 = ifn_387.Invoke_O_O__O(arg_388, A_arbace_j2g_zlib_A_const_44) } else { cl__19 = linked_386.(*A_arbace_j2g_zlib_huffman_lengths_A).InvokePrim_O_O_J__O(root_385, arg_388, 7) }; var cc__20 any; var root_390 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_31.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_j2g_zlib_canonical_codes_A_fn_class); var ifn_392 lang.IFn; if



























	linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = cl__19; if linked_391 == nil { cc__20 = ifn_392.Invoke_O__O(arg_393) } else { cc__20 = linked_391.(*A_arbace_j2g_zlib_canonical_codes_A).Invoke_O_O__O(root_390, arg_393) }; var hclen__21 int64; var tmp25 any; var root_394 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_45.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_396 lang.IFn; if




























	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any; var tmp26 any = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(cl__19); var tmp27 *jrt.Class; var fncls__399 *jrt.Class = A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class; if fncls__399 == nil { var fncls__399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class = fncls__399d; tmp27 = fncls__399d } else { tmp27 = fncls__399 }; arg_397 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_398 any; var root_400 any = A_arbace_j2g_zlib_A_const_46.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = A_arbace_j2g_zlib_A_const_47.GetRawRoot__O(); if linked_401 == nil { arg_398 = ifn_402.Invoke_O__O(arg_403) } else { arg_398 = linked_401.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_400, arg_403) }; if linked_395 == nil { tmp25 = ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { tmp25 = linked_395.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_394, arg_397, arg_398) }; hclen__21 = lang.Numbers_Max_J_J__J_NoInit(4, lang.Numbers_Minus_J_J__J_NoInit(19, int64(lang.RT_Count_O__I_NoInit(tmp25)))); var tmp28 lang.IFn =
	lang.IFn_Cast(w__0); var tmp29 any; if jrt.J2g_Truth(last_QMARK___4) { tmp29 = A_arbace_j2g_zlib_A_const_53 } else { tmp29 = A_arbace_j2g_zlib_A_const_17 }; tmp28.Invoke_O_O__O(tmp29, A_arbace_j2g_zlib_A_const_53);
	lang.IFn_Cast(w__0).Invoke_O_O__O(A_arbace_j2g_zlib_A_const_54, A_arbace_j2g_zlib_A_const_54); var tmp30 lang.IFn =
	lang.IFn_Cast(w__0); var tmp31 jrt.Number_I; var na_484 any = hlit__14; var na_485 int64 = 257; if jrt.Long_InstanceOf(na_484) { var n0_486 int64 = jrt.NN(jrt.Long_Cast(na_484)).LongValue__J(); var n1_487 int64 = na_485; var nr_488 int64 = n0_486 - n1_487; var tmp32 bool; var tmp33 bool; tmp33 = !(n1_487 == -9223372036854775808); if tmp33 { tmp33 = (n0_486^n1_487)&(n0_486^nr_488) >= 0 }; tmp32 = tmp33; if tmp32 { tmp31 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_488)) } else { tmp31 = lang.Numbers_Minus_O_J__Number_NoInit(na_484, na_485) } } else { tmp31 = lang.Numbers_Minus_O_J__Number_NoInit(na_484, na_485) }; tmp30.Invoke_O_O__O(tmp31, A_arbace_j2g_zlib_A_const_55); var tmp34 lang.IFn =
	lang.IFn_Cast(w__0); var tmp35 jrt.Number_I; var na_489 any = hdist__15; var na_490 int64 = 1; if jrt.Long_InstanceOf(na_489) { var n0_491 int64 = jrt.NN(jrt.Long_Cast(na_489)).LongValue__J(); var n1_492 int64 = na_490; var nr_493 int64 = n0_491 - n1_492; var tmp36 bool; var tmp37 bool; tmp37 = !(n1_492 == -9223372036854775808); if tmp37 { tmp37 = (n0_491^n1_492)&(n0_491^nr_493) >= 0 }; tmp36 = tmp37; if tmp36 { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_493)) } else { tmp35 = lang.Numbers_Minus_O_J__Number_NoInit(na_489, na_490) } } else { tmp35 = lang.Numbers_Minus_O_J__Number_NoInit(na_489, na_490) }; tmp34.Invoke_O_O__O(tmp35, A_arbace_j2g_zlib_A_const_55);
	lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(hclen__21, 4)).Ref(), A_arbace_j2g_zlib_A_const_56); var seq_1931000065__22 any; var root_439 any = /*line :219:1*/A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_441 lang.IFn; if


































	linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var root_443 any = A_arbace_j2g_zlib_A_const_37.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = jrt.Long_ValueOf_J__Long_NoInit(hclen__21).Ref(); var arg_447 any = A_arbace_j2g_zlib_A_const_47.GetRawRoot__O(); if linked_444 == nil { arg_442 = ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { arg_442 = linked_444.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; if linked_440 == nil { seq_1931000065__22 = ifn_441.Invoke_O__O(arg_442) } else { seq_1931000065__22 = linked_440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_439, arg_442) }; var chunk_1931000066__23 any; var count_1931000067__24 int64 = 0; var i_1931000068__25 int64 = 0; L2:
//line :219:1
	for {


































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000068__25, count_1931000067__24) { var s__26 any = lang.Indexed_Cast(chunk_1931000066__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000068__25)); lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__26)))).Ref(), A_arbace_j2g_zlib_A_const_57); seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000068__25); continue L2 } else { var temp__1927000414__auto____26 any; var root_448 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = seq_1931000065__22; if linked_449 == nil { temp__1927000414__auto____26 = ifn_450.Invoke_O__O(arg_451) } else { temp__1927000414__auto____26 = linked_449.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_448, arg_451) }; if jrt.J2g_Truth(temp__1927000414__auto____26) { var seq_1931000065__27 any = temp__1927000414__auto____26; var tmp38 any; var root_452 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1931000065__27; if linked_453 == nil { tmp38 = ifn_454.Invoke_O__O(arg_455) } else { tmp38 = linked_453.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_452, arg_455) }; if jrt.J2g_Truth(tmp38) { var c__1927000678__auto____28 any; var root_456 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = seq_1931000065__27; if linked_457 == nil { c__1927000678__auto____28 = ifn_458.Invoke_O__O(arg_459) } else { c__1927000678__auto____28 = linked_457.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_456, arg_459) }; var tmp39 any; var root_494 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1931000065__27; if linked_495 == nil { tmp39 = ifn_496.Invoke_O__O(arg_497) } else { tmp39 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = tmp39, c__1927000678__auto____28, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var s__28 any; var root_460 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = seq_1931000065__27; if linked_461 == nil { s__28 = ifn_462.Invoke_O__O(arg_463) } else { s__28 = linked_461.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_460, arg_463) }; lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__28)))).Ref(), A_arbace_j2g_zlib_A_const_57); var tmp40 any; var root_498 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1931000065__27; if linked_499 == nil { tmp40 = ifn_500.Invoke_O__O(arg_501) } else { tmp40 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1931000065__22, chunk_1931000066__23, count_1931000067__24, i_1931000068__25 = tmp40, nil, 0, 0; continue L2 } } }
//line :219:1
		break L2 }; var seq_1931000069__22 any; var root_464 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_466 lang.IFn; if



































	linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = rle__16; if linked_465 == nil { seq_1931000069__22 = ifn_466.Invoke_O__O(arg_467) } else { seq_1931000069__22 = linked_465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_464, arg_467) }; var chunk_1931000070__23 any; var count_1931000071__24 int64 = 0; var i_1931000072__25 int64 = 0; L3:
//line :219:1
	for {



































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000072__25, count_1931000071__24) { var vec__1931000073__26 any = lang.Indexed_Cast(chunk_1931000070__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000072__25)); var s__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(0), nil); var x__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000073__26, lang.RT_IntCast_J__I_NoInit(1), nil)
			lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__27)))).Ref())
//line :255:1
			var G__1931000076__29_ int32 = lang.RT_IntCast_O__I_NoInit(s__27)

		L4: switch { default: switch G__1931000076__29_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_54); break L4; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_57); break L4; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__28, A_arbace_j2g_zlib_A_const_44); break L4; default:}}
//line :255:1
			seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000072__25); continue L3 } else { var temp__1927000414__auto____26_2 any; var root_468 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = seq_1931000069__22; if linked_469 == nil { temp__1927000414__auto____26_2 = ifn_470.Invoke_O__O(arg_471) } else { temp__1927000414__auto____26_2 = linked_469.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_468, arg_471) }; if jrt.J2g_Truth(temp__1927000414__auto____26_2) { var seq_1931000069__27 any = temp__1927000414__auto____26_2; var tmp41 any; var root_472 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = seq_1931000069__27; if linked_473 == nil { tmp41 = ifn_474.Invoke_O__O(arg_475) } else { tmp41 = linked_473.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_472, arg_475) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____28_2 any; var root_476 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = seq_1931000069__27; if linked_477 == nil { c__1927000678__auto____28_2 = ifn_478.Invoke_O__O(arg_479) } else { c__1927000678__auto____28_2 = linked_477.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_476, arg_479) }; var tmp42 any; var root_503 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = seq_1931000069__27; if linked_504 == nil { tmp42 = ifn_505.Invoke_O__O(arg_506) } else { tmp42 = linked_504.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_503, arg_506) }; seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = tmp42, c__1927000678__auto____28_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1931000077__28 any; var root_480 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = seq_1931000069__27; if linked_481 == nil { vec__1931000077__28 = ifn_482.Invoke_O__O(arg_483) } else { vec__1931000077__28 = linked_481.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_480, arg_483) }; var s__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(0), nil); var x__30 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000077__28, lang.RT_IntCast_J__I_NoInit(1), nil)
				lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cc__20, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](cl__19, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__29)))).Ref())
//line :255:1
				var G__1931000080__31_ int32 = lang.RT_IntCast_O__I_NoInit(s__29)

			L5: switch { default: switch G__1931000080__31_ { case 16: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_54); break L5; case 17: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_57); break L5; case 18: lang.IFn_Cast(w__0).Invoke_O_O__O(x__30, A_arbace_j2g_zlib_A_const_44); break L5; default:}}
//line :255:1
				var tmp43 any; var root_508 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seq_1931000069__27; if linked_509 == nil { tmp43 = ifn_510.Invoke_O__O(arg_511) } else { tmp43 = linked_509.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_508, arg_511) }; seq_1931000069__22, chunk_1931000070__23, count_1931000071__24, i_1931000072__25 = tmp43, nil, 0, 0; continue L3 } } }
//line :219:1
		break L3 }; var i__22 int64 = from__6; L6: for {







































			if lang.Numbers_Lt_J_J__Z_NoInit(i__22, to__7) { var s__23 int64 = lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](syms__1, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(i__22))); var tmp44 any; var root_512 any = A_arbace_j2g_zlib_A_const_48.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_bit_test_A_fn_class); var ifn_514 lang.IFn

				if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = jrt.Long_ValueOf_J__Long_NoInit(s__23).Ref(); var arg_516 any = A_arbace_j2g_zlib_A_const_49; if linked_513 == nil { tmp44 = ifn_514.Invoke_O_O__O(arg_515, arg_516) } else { tmp44 = linked_513.(*aot_arbace_core.A_arbace_core_bit_test_A).Invoke_O_O_O__O(root_512, arg_515, arg_516) }; if jrt.J2g_Truth(tmp44) { var len__24 int64 = lang.Numbers_And_J_J__J_NoInit(lang.Numbers_ShiftRight_J_J__J_NoInit(s__23, 16), 65535); var d__25 int64 = lang.Numbers_And_J_J__J_NoInit(s__23, 65535); var lcode__26 any; var root_517 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_517, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_519 lang.IFn

					if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(); var arg_521 int64 = len__24; if linked_518 == nil { lcode__26 = ifn_519.Invoke_O_O__O(arg_520, jrt.Long_ValueOf_J__Long_NoInit(arg_521).Ref()) } else { lcode__26 = jrt.Long_ValueOf_J__Long_NoInit(linked_518.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_517, arg_520, arg_521)).Ref() }
//line :261:1
					var dcode__27 any; var root_522 any = A_arbace_j2g_zlib_A_const_50.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_522, A_arbace_j2g_zlib_code_of_A_fn_class); var ifn_524 lang.IFn

					if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(); var arg_526 int64 = d__25; if linked_523 == nil { dcode__27 = ifn_524.Invoke_O_O__O(arg_525, jrt.Long_ValueOf_J__Long_NoInit(arg_526).Ref()) } else { dcode__27 = jrt.Long_ValueOf_J__Long_NoInit(linked_523.(*A_arbace_j2g_zlib_code_of_A).InvokePrim_O_O_J__J(root_522, arg_525, arg_526)).Ref() }
					var tmp45 lang.IFn = lang.IFn_Cast(w__0); var tmp46 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()); var tmp47 jrt.Number_I; var na_527 int64 = 257; var na_528 any = lcode__26; if jrt.Long_InstanceOf(na_528) { var n0_529 int64 = na_527; var n1_530 int64 = jrt.NN(jrt.Long_Cast(na_528)).LongValue__J(); var nr_531 int64 = n0_529 + n1_530; if (n0_529^nr_531)&(n1_530^nr_531) >= 0 { tmp47 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_531)) } else { tmp47 = lang.Numbers_Add_J_O__Number_NoInit(na_527, na_528) } } else { tmp47 = lang.Numbers_Add_J_O__Number_NoInit(na_527, na_528) }; var tmp48 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp46, lang.RT_IntCast_O__I_NoInit(tmp47))).Ref(); var tmp49 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()); var tmp50 jrt.Number_I; var na_532 int64 = 257; var na_533 any = lcode__26; if jrt.Long_InstanceOf(na_533) { var n0_534 int64 = na_532; var n1_535 int64 = jrt.NN(jrt.Long_Cast(na_533)).LongValue__J(); var nr_536 int64 = n0_534 + n1_535; if (n0_534^nr_536)&(n1_535^nr_536) >= 0 { tmp50 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_536)) } else { tmp50 = lang.Numbers_Add_J_O__Number_NoInit(na_532, na_533) } } else { tmp50 = lang.Numbers_Add_J_O__Number_NoInit(na_532, na_533) }; tmp45.Invoke_O_O__O(tmp48, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp49, lang.RT_IntCast_O__I_NoInit(tmp50))).Ref())
					if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_59.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(lcode__26))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(len__24, lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_52.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(lcode__26)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_59.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(lcode__26))).Ref()) }
					lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](dc__13, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](dl__11, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref())
					if lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_58.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))) { lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(d__25, lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_51.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](A_arbace_j2g_zlib_A_const_58.GetRawRoot__O(), jrt.Prim_long.ArrayClass()), lang.RT_IntCast_O__I_NoInit(dcode__27))).Ref()) } } else {
						lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(s__23)))).Ref()) }
				i__22 = lang.Numbers_Inc_J__J_NoInit(i__22); continue L6 }
//line :219:1
			break L6 }; return /*line :270:1*/ lang.IFn_Cast(w__0).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](lc__12, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(256))).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aget_J1_I__J_NoInit(jrt.J2g_CastArray[*jrt.LongArray](ll__10, jrt.Prim_long.ArrayClass()), lang.RT_IntCast_J__I_NoInit(256))).Ref()) }
//line :234:1
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Ctor_O(c__df any) { t.F_df = c__df }
//line :234:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A) Invoke_O_O__O(self, p1__1931000041_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_df, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000041_SHARP___1))))).Ref() }






func A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Ctor_O(c__ll any) { t.F_ll = c__ll }
//line :241:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A) Invoke_O_O__O(self, p1__1931000042_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_ll, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000042_SHARP___1))))).Ref() }
func A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A{}; t.Ctor_O(p0); return t }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Ctor_O(c__dl any) { t.F_dl = c__dl }
//line :242:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A) Invoke_O_O__O(self, p1__1931000043_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_dl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000043_SHARP___1))))).Ref() }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_New_O_O(p0, p1 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Ctor_O_O(c__cf, c__rle any) { t.F_cf = c__cf; t.F_rle = c__rle }
//line :245:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A) Invoke_O__O(self any) any { { var seq_1931000051__1 any; var root_356 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any; var t_ any = t.F_rle; t.F_rle = nil; arg_359 = t_; if linked_357 == nil { seq_1931000051__1 = ifn_358.Invoke_O__O(arg_359) } else { seq_1931000051__1 = linked_357.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_356, arg_359) }; var chunk_1931000052__2 any; var count_1931000053__3 int64 = 0; var i_1931000054__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000054__4, count_1931000053__3) { var vec__1931000056__5 any = lang.Indexed_Cast(chunk_1931000052__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000054__4)); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000056__5, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp2 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp2, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__6)))))); seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000054__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_360 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = seq_1931000051__1; if linked_361 == nil { temp__1927000414__auto____5 = ifn_362.Invoke_O__O(arg_363) } else { temp__1927000414__auto____5 = linked_361.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_360, arg_363) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1931000051__6 any = temp__1927000414__auto____5; var tmp3 any; var root_364 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = seq_1931000051__6; if linked_365 == nil { tmp3 = ifn_366.Invoke_O__O(arg_367) } else { tmp3 = linked_365.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_364, arg_367) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____7 any; var root_368 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = seq_1931000051__6; if linked_369 == nil { c__1927000678__auto____7 = ifn_370.Invoke_O__O(arg_371) } else { c__1927000678__auto____7 = linked_369.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_368, arg_371) }; var tmp4 any; var root_376 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = seq_1931000051__6; if linked_377 == nil { tmp4 = ifn_378.Invoke_O__O(arg_379) } else { tmp4 = linked_377.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_376, arg_379) }; seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = tmp4, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1931000059__7 any; var root_372 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = seq_1931000051__6; if linked_373 == nil { vec__1931000059__7 = ifn_374.Invoke_O__O(arg_375) } else { vec__1931000059__7 = linked_373.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_372, arg_375) }; var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000059__7, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp5 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); var tmp6 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cf, jrt.Prim_long.ArrayClass()); jrt.Long_ValueOf_J__Long_NoInit(lang.RT_Aset_J1_I_J__J_NoInit(tmp5, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)), lang.Numbers_Inc_J__J_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp6, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(s__8)))))); var tmp7 any; var root_380 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = seq_1931000051__6; if linked_381 == nil { tmp7 = ifn_382.Invoke_O__O(arg_383) } else { tmp7 = linked_381.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_380, arg_383) }; seq_1931000051__1, chunk_1931000052__2, count_1931000053__3, i_1931000054__4 = tmp7, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_New_O(p0 any) *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A{}; t.Ctor_O(p0); return t }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Ctor_O(c__cl any) { t.F_cl = c__cl }
//line :248:1
func (t *A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A) Invoke_O_O__O(self, p1__1931000044_SHARP___1 any) any { var tmp1 *jrt.LongArray = jrt.J2g_CastArray[*jrt.LongArray](t.F_cl, jrt.Prim_long.ArrayClass()); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_Aget_J1_I__J_NoInit(tmp1, lang.RT_IntCast_I__I_NoInit(lang.RT_IntCast_O__I_NoInit(p1__1931000044_SHARP___1))))).Ref() }























func A_arbace_j2g_zlib_adler32_A_New() *A_arbace_j2g_zlib_adler32_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_adler32_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Ctor() {}
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) InvokePrim_O_O__J(self, b__0 any) int64 { { var i__2 int64 = 0; var a__3 int64 = 1; var s__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__2, int64(lang.RT_Alength_B1__I_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass())))) { var a__5 int64 = lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(a__3, lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_Aget_B1_I__B_NoInit(jrt.J2g_CastArray[*jrt.ByteArray](b__0, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__2))).Ref()), 255)), 65521)

		i__2, a__3, s__4 = lang.Numbers_Inc_J__J_NoInit(i__2), a__5, lang.Numbers_Remainder_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(s__4, a__5), 65521); continue L1 } else {
			return lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(s__4, 16), a__3) } } }; /*line :272:1*/panic("j2g: unreachable") }
//line :272:1
func (t *A_arbace_j2g_zlib_adler32_A) Invoke_O_O__O(self, b__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, b__0)).Ref() }






func A_arbace_j2g_zlib_deflate_A_New() *A_arbace_j2g_zlib_deflate_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_deflate_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_zlib_deflate_A) Invoke_O_O__O(self, b__0 any) any { var out__2 any = jrt.ByteArrayOutputStream_New(); var w__3 any = A_arbace_j2g_zlib_Bits_A_New_O_J_J(out__2, 0, 0); var vec__1931000083__4 any; var root_537 any = A_arbace_j2g_zlib_A_const_60.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_j2g_zlib_lz77_A_fn_class); var ifn_539 lang.IFn; if






	linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = b__0; if linked_538 == nil { vec__1931000083__4 = ifn_539.Invoke_O__O(arg_540) } else { vec__1931000083__4 = linked_538.(*A_arbace_j2g_zlib_lz77_A).Invoke_O_O__O(root_537, arg_540) }; var syms__5 any = /*line :279:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(0), nil); var k__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1931000083__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 int64 = lang.RT_LongCast_O__J_NoInit(k__6);








	jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(120)); jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).Write_I__V(lang.RT_IntCast_J__I_NoInit(218)); if
	lang.Numbers_IsZero_J__Z_NoInit(k__7) {
		var root_541 any = A_arbace_j2g_zlib_A_const_61.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, A_arbace_j2g_zlib_write_block_BANG__A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = w__3; var arg_545 any = syms__5; var arg_546 any = A_arbace_j2g_zlib_A_const_17; var arg_547 any = A_arbace_j2g_zlib_A_const_17; var arg_548 any = jrt.Boolean_TRUE.Ref(); if linked_542 == nil { ifn_543.Invoke_O_O_O_O_O__O(arg_544, arg_545, arg_546, arg_547, arg_548) } else { linked_542.(*A_arbace_j2g_zlib_write_block_BANG__A).Invoke_O_O_O_O_O_O__O(root_541, arg_544, arg_545, arg_546, arg_547, arg_548) } } else {
//line :289:1
			var from__8 int64 = 0; L1: for { var to__9 int64 = lang.Numbers_Min_J_J__J_NoInit(k__7, lang.Numbers_Add_J_J__J_NoInit(from__8, 16384)); var root_573 any = A_arbace_j2g_zlib_A_const_61.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_j2g_zlib_write_block_BANG__A_fn_class); var ifn_575 lang.IFn



				if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = w__3; var arg_577 any = syms__5; var arg_578 any = jrt.Long_ValueOf_J__Long_NoInit(from__8).Ref(); var arg_579 any = jrt.Long_ValueOf_J__Long_NoInit(to__9).Ref(); var arg_580 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(to__9, k__7)).Ref(); if linked_574 == nil { ifn_575.Invoke_O_O_O_O_O__O(arg_576, arg_577, arg_578, arg_579, arg_580) } else { linked_574.(*A_arbace_j2g_zlib_write_block_BANG__A).Invoke_O_O_O_O_O_O__O(root_573, arg_576, arg_577, arg_578, arg_579, arg_580) }
				if lang.Numbers_Lt_J_J__Z_NoInit(to__9, k__7) { from__8 = to__9; continue L1 }
//line :289:1
				break L1 } };





	lang.IFn_Cast(w__3).Invoke__O(); var a__8 any; var root_549 any = /*line :279:1*/A_arbace_j2g_zlib_A_const_62.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_549, A_arbace_j2g_zlib_adler32_A_fn_class); var ifn_551 lang.IFn; if
















	linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = b__0; if linked_550 == nil { a__8 = ifn_551.Invoke_O__O(arg_552) } else { a__8 = jrt.Long_ValueOf_J__Long_NoInit(linked_550.(*A_arbace_j2g_zlib_adler32_A).InvokePrim_O_O__J(root_549, arg_552)).Ref() }; var seq_1931000086__9 any; var root_553 any = /*line :279:1*/A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_555 lang.IFn; if

















	linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = A_arbace_j2g_zlib_A_const_63; if linked_554 == nil { seq_1931000086__9 = ifn_555.Invoke_O__O(arg_556) } else { seq_1931000086__9 = linked_554.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_553, arg_556) }; var chunk_1931000087__10 any; var count_1931000088__11 int64 = 0; var i_1931000089__12 int64 = 0; L2:
//line :279:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1931000089__12, count_1931000088__11) { var sh__13 any = lang.Indexed_Cast(chunk_1931000087__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1931000089__12)); var tmp1 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp2 int64; var na_581 any = a__8; var na_582 any = sh__13; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_581); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_582) }; tmp3 = tmp4; if tmp3 { var n0_583 int64 = jrt.NN(jrt.Long_Cast(na_581)).LongValue__J(); var n1_584 int64 = jrt.NN(jrt.Long_Cast(na_582)).LongValue__J(); tmp2 = n0_583 >> (n1_584 & 63) } else { tmp2 = lang.Numbers_ShiftRight_O_O__J_NoInit(na_581, na_582) }; jrt.NN(tmp1).Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp2, 255))); seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1931000089__12); continue L2 } else { var temp__1927000414__auto____13 any; var root_557 any = A_arbace_j2g_zlib_A_const_38.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = seq_1931000086__9; if linked_558 == nil { temp__1927000414__auto____13 = ifn_559.Invoke_O__O(arg_560) } else { temp__1927000414__auto____13 = linked_558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_557, arg_560) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1931000086__14 any = temp__1927000414__auto____13; var tmp5 any; var root_561 any = A_arbace_j2g_zlib_A_const_40.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = seq_1931000086__14; if linked_562 == nil { tmp5 = ifn_563.Invoke_O__O(arg_564) } else { tmp5 = linked_562.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_561, arg_564) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____15 any; var root_565 any = A_arbace_j2g_zlib_A_const_41.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = seq_1931000086__14; if linked_566 == nil { c__1927000678__auto____15 = ifn_567.Invoke_O__O(arg_568) } else { c__1927000678__auto____15 = linked_566.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_565, arg_568) }; var tmp6 any; var root_586 any = A_arbace_j2g_zlib_A_const_42.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = seq_1931000086__14; if linked_587 == nil { tmp6 = ifn_588.Invoke_O__O(arg_589) } else { tmp6 = linked_587.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_586, arg_589) }; seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = tmp6, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var sh__15 any; var root_569 any = A_arbace_j2g_zlib_A_const_14.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = seq_1931000086__14; if linked_570 == nil { sh__15 = ifn_571.Invoke_O__O(arg_572) } else { sh__15 = linked_570.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_569, arg_572) }; var tmp7 *jrt.ByteArrayOutputStream = jrt.ByteArrayOutputStream_Cast(out__2); var tmp8 int64; var na_590 any = a__8; var na_591 any = sh__15; var tmp9 bool; var tmp10 bool; tmp10 = jrt.Long_InstanceOf(na_590); if tmp10 { tmp10 = jrt.Long_InstanceOf(na_591) }; tmp9 = tmp10; if tmp9 { var n0_592 int64 = jrt.NN(jrt.Long_Cast(na_590)).LongValue__J(); var n1_593 int64 = jrt.NN(jrt.Long_Cast(na_591)).LongValue__J(); tmp8 = n0_592 >> (n1_593 & 63) } else { tmp8 = lang.Numbers_ShiftRight_O_O__J_NoInit(na_590, na_591) }; jrt.NN(tmp7).Write_I__V(lang.RT_IntCast_J__I_NoInit(lang.Numbers_And_J_J__J_NoInit(tmp8, 255))); var tmp11 any; var root_595 any = A_arbace_j2g_zlib_A_const_43.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = seq_1931000086__14; if linked_596 == nil { tmp11 = ifn_597.Invoke_O__O(arg_598) } else { tmp11 = linked_596.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_595, arg_598) }; seq_1931000086__9, chunk_1931000087__10, count_1931000088__11, i_1931000089__12 = tmp11, nil, 0, 0; continue L2 } } }
//line :279:1
		break L2 }; return /*line :298:1*/ jrt.NN(jrt.ByteArrayOutputStream_Cast(out__2)).ToByteArray__B1().Ref() }
//line :287:1
type A_arbace_j2g_zlib_A struct{ jrt.Object }

var A_arbace_j2g_zlib_A_const_pool *jrt.RefArray

var A_arbace_j2g_zlib_A_const_0 *lang.Var

var A_arbace_j2g_zlib_A_const_1 any

var A_arbace_j2g_zlib_A_const_2 *lang.Var

var A_arbace_j2g_zlib_A_const_3 *lang.Var

var A_arbace_j2g_zlib_A_const_4 *lang.Var

var A_arbace_j2g_zlib_A_const_5 *lang.Var

var A_arbace_j2g_zlib_A_const_6 any

var A_arbace_j2g_zlib_A_const_7 *lang.Var

var A_arbace_j2g_zlib_A_const_8 *lang.Var

var A_arbace_j2g_zlib_A_const_9 *lang.Var

var A_arbace_j2g_zlib_A_const_10 *lang.Keyword

var A_arbace_j2g_zlib_A_const_11 *lang.Var

var A_arbace_j2g_zlib_A_const_12 *lang.Var

var A_arbace_j2g_zlib_A_const_13 *lang.Var

var A_arbace_j2g_zlib_A_const_14 *lang.Var

var A_arbace_j2g_zlib_A_const_15 *lang.Var

var A_arbace_j2g_zlib_A_const_16 *lang.Var

var A_arbace_j2g_zlib_A_const_17 any

var A_arbace_j2g_zlib_A_const_18 any

var A_arbace_j2g_zlib_A_const_19 *lang.Var

var A_arbace_j2g_zlib_A_const_20 *lang.Var

var A_arbace_j2g_zlib_A_const_21 any

var A_arbace_j2g_zlib_A_const_22 *lang.Var

var A_arbace_j2g_zlib_A_const_23 *lang.Var

var A_arbace_j2g_zlib_A_const_24 *lang.Var

var A_arbace_j2g_zlib_A_const_25 any

var A_arbace_j2g_zlib_A_const_26 any

var A_arbace_j2g_zlib_A_const_27 any

var A_arbace_j2g_zlib_A_const_28 any

var A_arbace_j2g_zlib_A_const_29 *lang.Var

var A_arbace_j2g_zlib_A_const_30 any

var A_arbace_j2g_zlib_A_const_31 *lang.Var

var A_arbace_j2g_zlib_A_const_32 *lang.Var

var A_arbace_j2g_zlib_A_const_33 *lang.Var

var A_arbace_j2g_zlib_A_const_34 any

var A_arbace_j2g_zlib_A_const_35 *lang.Var

var A_arbace_j2g_zlib_A_const_36 *lang.Var

var A_arbace_j2g_zlib_A_const_37 *lang.Var

var A_arbace_j2g_zlib_A_const_38 *lang.Var

var A_arbace_j2g_zlib_A_const_39 any

var A_arbace_j2g_zlib_A_const_40 *lang.Var

var A_arbace_j2g_zlib_A_const_41 *lang.Var

var A_arbace_j2g_zlib_A_const_42 *lang.Var

var A_arbace_j2g_zlib_A_const_43 *lang.Var

var A_arbace_j2g_zlib_A_const_44 any

var A_arbace_j2g_zlib_A_const_45 *lang.Var

var A_arbace_j2g_zlib_A_const_46 *lang.Var

var A_arbace_j2g_zlib_A_const_47 *lang.Var

var A_arbace_j2g_zlib_A_const_48 *lang.Var

var A_arbace_j2g_zlib_A_const_49 any

var A_arbace_j2g_zlib_A_const_50 *lang.Var

var A_arbace_j2g_zlib_A_const_51 *lang.Var

var A_arbace_j2g_zlib_A_const_52 *lang.Var

var A_arbace_j2g_zlib_A_const_53 any

var A_arbace_j2g_zlib_A_const_54 any

var A_arbace_j2g_zlib_A_const_55 any

var A_arbace_j2g_zlib_A_const_56 any

var A_arbace_j2g_zlib_A_const_57 any

var A_arbace_j2g_zlib_A_const_58 *lang.Var

var A_arbace_j2g_zlib_A_const_59 *lang.Var

var A_arbace_j2g_zlib_A_const_60 *lang.Var

var A_arbace_j2g_zlib_A_const_61 *lang.Var

var A_arbace_j2g_zlib_A_const_62 *lang.Var

var A_arbace_j2g_zlib_A_const_63 any

var A_arbace_j2g_zlib_A_init jrt.ClassInit

func A_arbace_j2g_zlib_A_Init() { if !A_arbace_j2g_zlib_A_init.Done() { A_arbace_j2g_zlib_A_init.Run(A_arbace_j2g_zlib_A_clinit) } }

func A_arbace_j2g_zlib_A_clinit() { A_arbace_j2g_zlib_A_clinit_p0(); A_arbace_j2g_zlib_A_clinit_p1(); A_arbace_j2g_zlib_A_clinit_p2(); A_arbace_j2g_zlib_A_clinit_p3(); A_arbace_j2g_zlib_A_clinit_p4(); A_arbace_j2g_zlib_A_clinit_p5() }

func A_arbace_j2g_zlib_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_zlib_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 67); A_arbace_j2g_zlib_A_const_0 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[3]); A_arbace_j2g_zlib_A_const_1 = A_arbace_j2g_zlib_A_const_pool.A[4]; A_arbace_j2g_zlib_A_const_2 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[5]); A_arbace_j2g_zlib_A_const_3 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[6]); A_arbace_j2g_zlib_A_const_4 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[7]); A_arbace_j2g_zlib_A_const_5 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[8]); A_arbace_j2g_zlib_A_const_6 = A_arbace_j2g_zlib_A_const_pool.A[9]; A_arbace_j2g_zlib_A_const_7 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[10]); A_arbace_j2g_zlib_A_const_8 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[11]); A_arbace_j2g_zlib_A_const_9 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[12]); A_arbace_j2g_zlib_A_const_10 = lang.Keyword_Cast(A_arbace_j2g_zlib_A_const_pool.A[13]) }

func A_arbace_j2g_zlib_A_clinit_p1() { A_arbace_j2g_zlib_A_const_11 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[14]); A_arbace_j2g_zlib_A_const_12 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[15]); A_arbace_j2g_zlib_A_const_13 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[16]); A_arbace_j2g_zlib_A_const_14 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[17]); A_arbace_j2g_zlib_A_const_15 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[18]); A_arbace_j2g_zlib_A_const_16 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[19]); A_arbace_j2g_zlib_A_const_17 = A_arbace_j2g_zlib_A_const_pool.A[20]; A_arbace_j2g_zlib_A_const_18 = A_arbace_j2g_zlib_A_const_pool.A[21]; A_arbace_j2g_zlib_A_const_19 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[22]); A_arbace_j2g_zlib_A_const_20 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[23]); A_arbace_j2g_zlib_A_const_21 = A_arbace_j2g_zlib_A_const_pool.A[24]; A_arbace_j2g_zlib_A_const_22 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[25]) }

func A_arbace_j2g_zlib_A_clinit_p2() { A_arbace_j2g_zlib_A_const_23 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[26]); A_arbace_j2g_zlib_A_const_24 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[27]); A_arbace_j2g_zlib_A_const_25 = A_arbace_j2g_zlib_A_const_pool.A[28]; A_arbace_j2g_zlib_A_const_26 = A_arbace_j2g_zlib_A_const_pool.A[29]; A_arbace_j2g_zlib_A_const_27 = A_arbace_j2g_zlib_A_const_pool.A[30]; A_arbace_j2g_zlib_A_const_28 = A_arbace_j2g_zlib_A_const_pool.A[31]; A_arbace_j2g_zlib_A_const_29 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[32]); A_arbace_j2g_zlib_A_const_30 = A_arbace_j2g_zlib_A_const_pool.A[33]; A_arbace_j2g_zlib_A_const_31 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[34]); A_arbace_j2g_zlib_A_const_32 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[35]); A_arbace_j2g_zlib_A_const_33 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[36]); A_arbace_j2g_zlib_A_const_34 = A_arbace_j2g_zlib_A_const_pool.A[37]; A_arbace_j2g_zlib_A_const_35 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[38]) }

func A_arbace_j2g_zlib_A_clinit_p3() { A_arbace_j2g_zlib_A_const_36 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[39]); A_arbace_j2g_zlib_A_const_37 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[40]); A_arbace_j2g_zlib_A_const_38 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[41]); A_arbace_j2g_zlib_A_const_39 = A_arbace_j2g_zlib_A_const_pool.A[42]; A_arbace_j2g_zlib_A_const_40 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[43]); A_arbace_j2g_zlib_A_const_41 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[44]); A_arbace_j2g_zlib_A_const_42 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[45]); A_arbace_j2g_zlib_A_const_43 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[46]); A_arbace_j2g_zlib_A_const_44 = A_arbace_j2g_zlib_A_const_pool.A[47]; A_arbace_j2g_zlib_A_const_45 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[48]); A_arbace_j2g_zlib_A_const_46 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[49]); A_arbace_j2g_zlib_A_const_47 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[50]) }

func A_arbace_j2g_zlib_A_clinit_p4() { A_arbace_j2g_zlib_A_const_48 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[51]); A_arbace_j2g_zlib_A_const_49 = A_arbace_j2g_zlib_A_const_pool.A[52]; A_arbace_j2g_zlib_A_const_50 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[53]); A_arbace_j2g_zlib_A_const_51 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[54]); A_arbace_j2g_zlib_A_const_52 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[55]); A_arbace_j2g_zlib_A_const_53 = A_arbace_j2g_zlib_A_const_pool.A[56]; A_arbace_j2g_zlib_A_const_54 = A_arbace_j2g_zlib_A_const_pool.A[57]; A_arbace_j2g_zlib_A_const_55 = A_arbace_j2g_zlib_A_const_pool.A[58]; A_arbace_j2g_zlib_A_const_56 = A_arbace_j2g_zlib_A_const_pool.A[59]; A_arbace_j2g_zlib_A_const_57 = A_arbace_j2g_zlib_A_const_pool.A[60]; A_arbace_j2g_zlib_A_const_58 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[61]); A_arbace_j2g_zlib_A_const_59 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[62]); A_arbace_j2g_zlib_A_const_60 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[63]) }

func A_arbace_j2g_zlib_A_clinit_p5() { A_arbace_j2g_zlib_A_const_61 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[64]); A_arbace_j2g_zlib_A_const_62 = lang.Var_Cast(A_arbace_j2g_zlib_A_const_pool.A[65]); A_arbace_j2g_zlib_A_const_63 = A_arbace_j2g_zlib_A_const_pool.A[66] }

func A_arbace_j2g_zlib_A_New() *A_arbace_j2g_zlib_A { A_arbace_j2g_zlib_A_Init(); t := &A_arbace_j2g_zlib_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_A) Ctor() {}

func (t *A_arbace_j2g_zlib_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_A_class }

func (t *A_arbace_j2g_zlib_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_A); return ok }

func A_arbace_j2g_zlib_A_Cast(x any) *A_arbace_j2g_zlib_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_A_class)) }; return v }



type A_arbace_j2g_zlib_adler32_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_adler32_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_canonical_codes_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_canonical_codes_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_code_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_code_of_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_deflate_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_deflate_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000004_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000004_A_New() *A_arbace_j2g_zlib_eval1931000004_A { t := &A_arbace_j2g_zlib_eval1931000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000004_A_class }

func (t *A_arbace_j2g_zlib_eval1931000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); return ok }

func A_arbace_j2g_zlib_eval1931000004_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000004_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000004_loading__1927001464__auto____1931000005_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000008_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000008_A_New() *A_arbace_j2g_zlib_eval1931000008_A { t := &A_arbace_j2g_zlib_eval1931000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000008_A_class }

func (t *A_arbace_j2g_zlib_eval1931000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); return ok }

func A_arbace_j2g_zlib_eval1931000008_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000008_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000008_fn__1931000009_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_eval1931000012_A struct{ jrt.Object }

func A_arbace_j2g_zlib_eval1931000012_A_New() *A_arbace_j2g_zlib_eval1931000012_A { t := &A_arbace_j2g_zlib_eval1931000012_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ctor() {}

func (t *A_arbace_j2g_zlib_eval1931000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_zlib_eval1931000012_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_zlib_eval1931000012_A_class }

func (t *A_arbace_j2g_zlib_eval1931000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_zlib_eval1931000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_zlib_eval1931000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); return ok }

func A_arbace_j2g_zlib_eval1931000012_A_Cast(x any) *A_arbace_j2g_zlib_eval1931000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_zlib_eval1931000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_zlib_eval1931000012_A_class)) }; return v }



type A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_eval1931000012___GT_Bits__1931000014_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_huffman_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000019_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A struct{ j2g_header uint64; F_fs any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000021_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A struct{ j2g_header uint64; F_parent any; F_n int32; F_start any }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000023_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A struct{ j2g_header uint64; F_parent, F_lens any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A struct{ j2g_header uint64; F_parent, F_s any; F_root int64 }

var A_arbace_j2g_zlib_huffman_lengths_fn__1931000025_fn__1931000026_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_insert_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_insert_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_longest_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_longest_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_lz77_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_lz77_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_match_length_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_match_length_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_reverse_bits_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_reverse_bits_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_rle_lengths_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A struct{ j2g_header uint64; F_i any; F_n int32; F_x int64; F_v any }

var A_arbace_j2g_zlib_rle_lengths_fn__1931000038_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__A struct{ j2g_header uint64 }

var A_arbace_j2g_zlib_write_block_BANG__A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A struct{ j2g_header uint64; F_df any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000045_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A struct{ j2g_header uint64; F_ll any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000047_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A struct{ j2g_header uint64; F_dl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000049_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A struct{ j2g_header uint64; F_cf, F_rle any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000055_A_fn_class *jrt.Class



type A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A struct{ j2g_header uint64; F_cl any }

var A_arbace_j2g_zlib_write_block_BANG__fn__1931000063_A_fn_class *jrt.Class
