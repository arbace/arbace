//line j2g_strings.ae:1
package aot_arbace_j2g_zlib

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn4,elsev11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.j2g.zlibm2,R1,s948,A zlib stream (RFC 1950) of DEFLATE data (RFC 1951) written in Arbace, for the resources\n  bin/j2g --program embeds compressed (amendment SZ2): the same bytes on every host, the JVM's\n  and the Go executable's (doc/STANDALONE-NOTES.md, S3, SA21), where the JVM's\n  java.util.zip.Deflater (zlib's C code) exists on the JVM only and Go's compress/flate writes\n  other bytes. jrt's InflaterInputStream (Go's compress/zlib) and the JDK's read it.\n\n  The compressor: LZ77 over the whole input (a 32 KB window, matches of 3 to 258 bytes, hash\n  chains of 3-byte prefixes searched to a fixed depth, one step of lazy matching, as zlib's\n  deflate_slow), then blocks of at most 16,384 symbols, each with its own Huffman codes\n  (dynamic blocks; lengths limited to 15 bits, 7 for the code length code, by halving the\n  frequencies until the code fits). Every choice is integer arithmetic and ties broken by\n  symbol, so the output depends on the input alone.v11,arbace.core7,filtervv11,arbace.core5,rangev11,arbace.core6,empty?R2,v11,arbace.core4,intov11,arbace.core10,sorted-setv11,arbace.core3,mapv11,arbace.core5,firstv11,arbace.core4,disjv11,arbace.core6,reducel0,l16,v15,arbace.j2g.zlib12,reverse-bitsv15,arbace.j2g.zlib12,match-lengthl-1,v15,arbace.j2g.zlib7,longestv15,arbace.j2g.zlib7,insert!v11,arbace.core3,vecl18,l17,l286,l30,v15,arbace.j2g.zlib15,huffman-lengthsl15,v15,arbace.j2g.zlib15,canonical-codesv11,arbace.core4,lastv11,arbace.core6,filterl286,v15,arbace.j2g.zlib11,rle-lengthsv11,arbace.core6,concatv11,arbace.core4,takev11,arbace.core3,seql19,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core10,chunk-restv11,arbace.core4,nextl7,v11,arbace.core10,take-whilev11,arbace.core7,reversev15,arbace.j2g.zlib8,cl-orderv11,arbace.core8,bit-testl40,v15,arbace.j2g.zlib7,code-ofv15,arbace.j2g.zlib9,dist-basev15,arbace.j2g.zlib8,len-basel1,l2,l5,l4,l3,v15,arbace.j2g.zlib10,dist-extrav15,arbace.j2g.zlib9,len-extrav15,arbace.j2g.zlib4,lz77v15,arbace.j2g.zlib12,write-block!v15,arbace.j2g.zlib7,adler32V4,l24,l16,l8,l0,")

var Lit_1 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.zlib$huffman_lengths$fn__1931000019")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.zlib$huffman_lengths$fn__1931000021")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.zlib$huffman_lengths$fn__1931000023")

var Lit_5 *jrt.String = jrt.Intern("arbace.j2g.zlib$huffman_lengths$fn__1931000025")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.zlib$huffman_lengths$fn__1931000025$fn__1931000026")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.zlib$rle_lengths$fn__1931000038")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.zlib$write_block_BANG_$fn__1931000045")

var Lit_9 *jrt.String = jrt.Intern("arbace.j2g.zlib$write_block_BANG_$fn__1931000047")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.zlib$write_block_BANG_$fn__1931000049")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.zlib$write_block_BANG_$fn__1931000055")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.zlib$write_block_BANG_$fn__1931000063")

var Lit_13 *jrt.String = jrt.Intern("out")

var Lit_14 *jrt.String = jrt.Intern("tag")

var Lit_15 *jrt.String = jrt.Intern("ByteArrayOutputStream")

var Lit_16 *jrt.String = jrt.Intern("acc")

var Lit_17 *jrt.String = jrt.Intern("long")

var Lit_18 *jrt.String = jrt.Intern("unsynchronized-mutable")

var Lit_19 *jrt.String = jrt.Intern("n")

var Lit_20 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn3,outyn3,accyn1,nkn4,linekn6,columnkn4,filekn7,privatekn3,tagyn4,longyn5,longskn5,constyn5,bytesyn4,intsyn2,lsyn4,Bitsyn4,fromyn2,toyn5,last?v11,arbace.core5,in-nsMyn15,arbace.j2g.zlibm2,R0,s948,A zlib stream (RFC 1950) of DEFLATE data (RFC 1951) written in Arbace, for the resources\n  bin/j2g --program embeds compressed (amendment SZ2): the same bytes on every host, the JVM's\n  and the Go executable's (doc/STANDALONE-NOTES.md, S3, SA21), where the JVM's\n  java.util.zip.Deflater (zlib's C code) exists on the JVM only and Go's compress/flate writes\n  other bytes. jrt's InflaterInputStream (Go's compress/zlib) and the JDK's read it.\n\n  The compressor: LZ77 over the whole input (a 32 KB window, matches of 3 to 258 bytes, hash\n  chains of 3-byte prefixes searched to a fixed depth, one step of lazy matching, as zlib's\n  deflate_slow), then blocks of at most 16,384 symbols, each with its own Huffman codes\n  (dynamic blocks; lengths limited to 15 bits, 7 for the code length code, by halving the\n  frequencies until the code fits). Every choice is integer arithmetic and ties broken by\n  symbol, so the output depends on the input alone.m2,R0,s948,A zlib stream (RFC 1950) of DEFLATE data (RFC 1951) written in Arbace, for the resources\n  bin/j2g --program embeds compressed (amendment SZ2): the same bytes on every host, the JVM's\n  and the Go executable's (doc/STANDALONE-NOTES.md, S3, SA21), where the JVM's\n  java.util.zip.Deflater (zlib's C code) exists on the JVM only and Go's compress/flate writes\n  other bytes. jrt's InflaterInputStream (Go's compress/zlib) and the JDK's read it.\n\n  The compressor: LZ77 over the whole input (a 32 KB window, matches of 3 to 258 bytes, hash\n  chains of 3-byte prefixes searched to a fixed depth, one step of lazy matching, as zlib's\n  deflate_slow), then blocks of at most 16,384 symbols, each with its own Huffman codes\n  (dynamic blocks; lengths limited to 15 bits, 7 for the code length code, by halving the\n  frequencies until the code fits). Every choice is integer arithmetic and ties broken by\n  symbol, so the output depends on the input alone.R1,C20,arbace.j2g.zlib.Bitsv15,arbace.j2g.zlib6,->Bitsm10,R2,L1,V3,R3,R4,R5,R0,s59,Positional factory function for class arbace.j2g.zlib.Bits.R6,i19,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib12,reverse-bitsm10,R9,TR2,L1,MV2,Myn4,codem2,R10,R11,Myn3,lenm2,R10,R11,m2,R10,R11,R6,i39,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib15,huffman-lengthsm12,R9,TR2,L1,MV2,Myn5,freqsm2,R10,R12,Myn5,limitm2,R10,R11,m2,R10,R12,R0,s213,The code lengths (a long array) of a Huffman code for the frequencies freqs (a long array),\n  at most limit bits each; 0 for an absent symbol. Ties are broken by symbol order. A single\n  used symbol gets length 1.R6,i46,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib15,canonical-codesm12,R9,TR2,L1,MV1,Myn4,lensm2,R10,R12,m2,R10,R12,R0,s96,The codes (a long array, bit-reversed for writing) of the code lengths lens (RFC 1951\n  §3.2.2).R6,i83,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib8,len-baseV29,l3,l4,l5,l6,l7,l8,l9,l10,l11,l13,l15,l17,l19,l23,l27,l31,l35,l43,l51,l59,l67,l83,l99,l115,l131,l163,l195,l227,l258,m10,R10,s2,[JR9,TR6,i107,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib9,len-extraV29,l0,l0,l0,l0,l0,l0,l0,l0,l1,l1,l1,l1,l2,l2,l2,l2,l3,l3,l3,l3,l4,l4,l4,l4,l5,l5,l5,l5,l0,m10,R10,s2,[JR9,TR6,i108,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib9,dist-baseV30,l1,l2,l3,l4,l5,l7,l9,l13,l17,l25,l33,l49,l65,l97,l129,l193,l257,l385,l513,l769,l1025,l1537,l2049,l3073,l4097,l6145,l8193,l12289,l16385,l24577,m10,R10,s2,[JR9,TR6,i109,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib10,dist-extraV30,l0,l0,l0,l0,l1,l1,l2,l2,l3,l3,l4,l4,l5,l5,l6,l6,l7,l7,l8,l8,l9,l9,l10,l10,l11,l11,l12,l12,l13,l13,m10,R10,s2,[JR9,TR6,i111,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib7,code-ofm12,R9,TR2,L1,MV2,Myn5,basesm2,R10,R12,Myn1,vm2,R10,R11,m2,R10,R11,R0,s61,The index of the last base in bases (a long array) at most v.R6,i113,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib6,windowl32768,m10,R13,TR9,TR6,i123,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib9,max-chainl64,m10,R13,TR9,TR6,i124,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib11,nice-lengthm10,R13,TR9,TR6,i125,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib12,match-lengthm12,R9,TR2,L1,MV4,Myn1,bm2,R10,R14,Myn1,im2,R10,R11,Myn1,jm2,R10,R11,Myn3,maxm2,R10,R11,m2,R10,R11,R0,s70,The length of the common prefix of b at i and at j (< i), at most max.R6,i127,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib7,insert!m12,R9,TR2,L1,V4,Myn1,bm2,R10,R14,Myn4,headm2,R10,R15,Myn4,prevm2,R10,R15,Myn1,im2,R10,R11,R0,s158,Enters position i of b (n bytes) into the hash chains: prev[i] is the last position before i\n  whose 3 bytes hash as i's, head[h] the last position of hash h.R6,i132,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib7,longestm12,R9,TR2,L1,MV3,Myn1,bm2,R10,R14,Myn4,prevm2,R10,R15,Myn1,im2,R10,R11,m2,R10,R11,R0,s120,The longest match for position i of b along its hash chain: (length << 16 | distance), or\n  0 when none is 3 bytes long.R6,i146,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib4,lz77m12,R9,TR2,L1,V1,Myn1,bm2,R10,R14,R0,s138,The symbols of b: a long array of entries, a literal byte v as v, a match as\n  (length << 16 | distance) with bit 40 set; and their count.R6,i164,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib13,block-symbolsl16384,m10,R13,TR9,TR6,i201,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib8,cl-orderV19,l16,l17,l18,l0,l8,l7,l9,l6,l10,l5,l11,l4,l12,l3,l13,l2,l14,l1,l15,m8,R9,TR6,i202,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib11,rle-lengthsm12,R9,TR2,L1,V1,R16,R0,s90,The code length code's symbols for the lengths ls (RFC 1951 §3.2.7): [symbol extra-value].R6,i204,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib12,write-block!m12,R9,TR2,L1,V5,Myn1,wm2,R10,R17,Myn4,symsm2,R10,R12,R18,R19,R20,R0,s75,Writes the symbols syms[from, to) as one dynamic block (last? sets BFINAL).R6,i219,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib7,adler32m10,R9,TR2,L1,MV1,Myn1,bm2,R10,R14,m2,R10,R11,R6,i272,R7,i1,R8,s18,arbace/j2g/zlib.aev15,arbace.j2g.zlib7,deflatem10,R2,L1,MV1,Myn1,bm2,R10,R14,m2,R10,R14,R0,s185,bytes b as a zlib stream (RFC 1950): the header (deflate, a 32 KB window, the maximum\n  compression level's flag, as the JDK's Deflater at level 9), DEFLATE blocks, the Adler-32 of\n  b.R6,i279,R7,i1,R8,s18,arbace/j2g/zlib.ae")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.zlib$eval1931000004$loading__1927001464__auto____1931000005")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.zlib$eval1931000008$fn__1931000009")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.zlib.Bits")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.zlib$eval1931000012$__GT_Bits__1931000014")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.zlib$reverse_bits")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.zlib$huffman_lengths")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.zlib$canonical_codes")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.zlib$code_of")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.zlib$match_length")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.zlib$insert_BANG_")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.zlib$longest")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.zlib$lz77")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.zlib$rle_lengths")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.zlib$write_block_BANG_")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.zlib$adler32")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.zlib$deflate")
