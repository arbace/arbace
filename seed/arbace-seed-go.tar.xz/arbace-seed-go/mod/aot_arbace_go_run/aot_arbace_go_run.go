//line aot_arbace_go_run.ae:1
package aot_arbace_go_run

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_New() *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_1); lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_go_run_A_const_3, A_arbace_go_run_A_const_4, A_arbace_go_run_A_const_5, A_arbace_go_run_A_const_6, A_arbace_go_run_A_const_7, A_arbace_go_run_A_const_8); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_52)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_53)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_run_eval1938000008_fn__1938000009_A_New() *A_arbace_go_run_eval1938000008_fn__1938000009_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000008_fn__1938000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_go_run_A_const_11; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_20, arg_23) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_run_A_const_12.GetRawRoot__O(), A_arbace_go_run_A_const_13) }



















func A_arbace_go_run_fail_A_New() *A_arbace_go_run_fail_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_go_run_fail_A) Ctor() {}
//line :21:1
func (t *A_arbace_go_run_fail_A) Invoke_O_O_O_O__O(self, status__0, kind__1, msg__2 any) any {
	var root_48 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_22; var arg_51 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_23.Get__O()); if linked_49 == nil { ifn_50.Invoke_O__O(arg_51) } else { linked_49.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_48, arg_51) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__47 any = A_arbace_go_run_fail_fn__1938000012_A_New_O_O(kind__1, msg__2); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_go_run_fail_fn__1938000012_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__47); A_arbace_go_run_fail_fn__1938000012_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp4, nil); Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()


	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__0)); return nil }
//line :22:1
func A_arbace_go_run_fail_fn__1938000012_A_New_O_O(p0, p1 any) *A_arbace_go_run_fail_fn__1938000012_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_fn__1938000012_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Ctor_O_O(c__kind, c__msg any) { t.F_kind = c__kind; t.F_msg = c__msg }
//line :22:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_15, nil); var tmp4 any; var t_ any = t.F_kind; t.F_kind = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var root_34 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var root_38 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var root_42 any = A_arbace_go_run_A_const_19.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any; var t__2 any = t.F_msg; t.F_msg = nil; arg_45 = t__2; if linked_43 == nil { arg_41 = ifn_44.Invoke_O__O(arg_45) } else { arg_41 = linked_43.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_42, arg_45) }; if linked_39 == nil { arg_37 = ifn_40.Invoke_O__O(arg_41) } else { arg_37 = linked_39.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_38, arg_41) }; if linked_35 == nil { tmp6 = ifn_36.Invoke_O__O(arg_37) } else { tmp6 = linked_35.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_34, arg_37) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref())
											var root_24 any = A_arbace_go_run_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; if linked_25 == nil { tmp1 = ifn_26.Invoke__O() } else { tmp1 = linked_25.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_24) } }
//line :22:1
	return nil }(); var root_27 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; if linked_28 == nil { ifn_29.Invoke__O() } else { linked_28.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_27) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_go_run_package_file_QMARK__A_New() *A_arbace_go_run_package_file_QMARK__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_go_run_package_file_QMARK__A) Ctor() {}
//line :27:1
func (t *A_arbace_go_run_package_file_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 bool = jrt.File_Cast(f__0).IsFile__Z(); if and__1927000168__auto____2 {
											var and__1927000168__auto____3 any; var root_57 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = jrt.File_Cast(f__0).GetName__String().Ref(); var arg_61 any = Lit_73; if linked_58 == nil { and__1927000168__auto____3 = ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { and__1927000168__auto____3 = linked_58.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_57, arg_60, arg_61) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var r__4 any = jrt.BufferedReader_New_Reader(jrt.FileReader_New_File(jrt.File_Cast(f__0))); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__7 any; var root_62 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_64 lang.IFn

		if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var root_66 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var fnbody__81 any = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New(); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; arg_69 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp2, nil); var arg_70 any; var root_82 any = A_arbace_go_run_A_const_28.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = r__4; if linked_83 == nil { arg_70 = ifn_84.Invoke_O__O(arg_85) } else { arg_70 = linked_83.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_82, arg_85) }; if linked_67 == nil { arg_65 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { arg_65 = linked_67.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }; if linked_63 == nil { l__7 = ifn_64.Invoke_O__O(arg_65) } else { l__7 = linked_63.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_62, arg_65) }
		var tmp3 any; var and__1927000168__auto____8 any = l__7; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_86 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = l__7; var arg_90 any = Lit_75; if linked_87 == nil { tmp3 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { tmp3 = linked_87.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_86, arg_89, arg_90) } } else { tmp3 = and__1927000168__auto____8 }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() }; return nil }()
//line :29:1
		jrt.BufferedReader_Cast(r__4).Close__V()
//line :28:1
		if tmp4 != nil { panic(tmp4) }; return tmp1 } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New() *A_arbace_go_run_package_file_QMARK__fn__1938000016_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__fn__1938000016_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Ctor() {}
//line :30:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Invoke_O_O__O(self, p1__1938000015_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_71 any = A_arbace_go_run_A_const_26.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = p1__1938000015_SHARP___1; if linked_72 == nil { or__1927000174__auto____2 = ifn_73.Invoke_O__O(arg_74) } else { or__1927000174__auto____2 = linked_72.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_71, arg_74) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_75 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = p1__1938000015_SHARP___1; var arg_79 any = Lit_76; if linked_76 == nil { return ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { return linked_76.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_75, arg_78, arg_79) } } }


func A_arbace_go_run_dir_test_root_A_New() *A_arbace_go_run_dir_test_root_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_root_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_go_run_dir_test_root_A) Ctor() {}
//line :33:1
func (t *A_arbace_go_run_dir_test_root_A) Invoke_O_O__O(self, pf__0 any) any { { var n__2 any = jrt.File_Cast(pf__0).GetName__String().Ref(); var sib__3 any; var tmp1 jrt.File_I = jrt.File_Cast(pf__0).GetParentFile__File(); var tmp2 any; var root_91 any = A_arbace_go_run_A_const_29.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_93 lang.IFn




	if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = n__2; var arg_95 any = A_arbace_go_run_A_const_30; var arg_96 any = Lit_22; if linked_92 == nil { tmp2 = ifn_93.Invoke_O_O_O__O(arg_94, arg_95, arg_96) } else { tmp2 = linked_92.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_91, arg_94, arg_95, arg_96) }
//line :33:1
	sib__3 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2))





	var tmp3 any; var and__1927000168__auto____4 any; var root_97 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = n__2; var arg_101 any = Lit_23; if linked_98 == nil { and__1927000168__auto____4 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { and__1927000168__auto____4 = linked_98.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(sib__3).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { return sib__3 } else { var d__4 any = jrt.File_Cast(pf__0).GetParentFile__File(); L1: for {


		if lang.Util_Identical_O_O__Z_NoInit(d__4, nil) { return nil } else { var tmp4 any; var root_102 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_104 lang.IFn

			if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = jrt.File_Cast(d__4).GetName__String().Ref(); var arg_106 any = Lit_24; if linked_103 == nil { tmp4 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { tmp4 = linked_103.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }
//line :42:1
			if jrt.J2g_Truth(tmp4) { return d__4 } else { if A_arbace_go_run_A_const_31 != nil {


				d__4 = jrt.File_Cast(d__4).GetParentFile__File(); continue L1 } else {
//line :42:1
					return nil } } } } } }; /*line :33:1*/panic("j2g: unreachable") }













func A_arbace_go_run_dir_test_index_A_New() *A_arbace_go_run_dir_test_index_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_go_run_dir_test_index_A) Ctor() {}
//line :47:1
func (t *A_arbace_go_run_dir_test_index_A) Invoke_O_O__O(self, pf__0 any) any { var temp__1927000408__auto____2 any; var root_107 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_go_run_dir_test_root_A_fn_class); var ifn_109 lang.IFn; if



	linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = pf__0; if linked_108 == nil { temp__1927000408__auto____2 = ifn_109.Invoke_O__O(arg_110) } else { temp__1927000408__auto____2 = linked_108.(*A_arbace_go_run_dir_test_root_A).Invoke_O_O__O(root_107, arg_110) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var root_111 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_113 lang.IFn
		if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_115 any; var iter__1927001039__auto____4 any; var fnbody__201 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New(); var tmp1 *jrt.Class; var fncls__200 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class
		if fncls__200 == nil { var fncls__200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class = fncls__200d; tmp1 = fncls__200d } else { tmp1 = fncls__200 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__201, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp3 any; var root_202 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = pf__0; var arg_206 any; var root_207 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = d__3; if linked_208 == nil { arg_206 = ifn_209.Invoke_O__O(arg_210) } else { arg_206 = linked_208.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_207, arg_210) }; if linked_203 == nil { tmp3 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { tmp3 = linked_203.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }; arg_115 = tmp2.Invoke_O__O(tmp3)
//line :52:1
		if linked_112 == nil { return ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { return linked_112.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) } } else {
//line :51:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }

func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New() *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Ctor() {}
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Invoke_O_O__O(self, s__1938000021__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__199 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(self, s__1938000021__1); var tmp2 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__199); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class = fncls__198d; tmp2 = fncls__198d } else { tmp2 = fncls__198 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__199, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :53:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(p0, p1 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Ctor_O_O(c__iter__1938000020, c__s__1938000021 any) { t.F_iter__1938000020 = c__iter__1938000020; t.F_s__1938000021 = c__s__1938000021 }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Invoke_O__O(self any) any { { var s__1938000021__1 any; var t_ any = t.F_s__1938000021; t.F_s__1938000021 = nil; s__1938000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_116 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__1938000021__1; if linked_117 == nil { temp__1927000414__auto____2 = ifn_118.Invoke_O__O(arg_119) } else { temp__1927000414__auto____2 = linked_117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_120 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__1938000021__3; if linked_121 == nil { tmp1 = ifn_122.Invoke_O__O(arg_123) } else { tmp1 = linked_121.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_124 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__1938000021__3; if linked_125 == nil { c__1927001037__auto____4 = ifn_126.Invoke_O__O(arg_127) } else { c__1927001037__auto____4 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_124, arg_127) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000023__6 any; var root_128 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_129 == nil { b__1938000023__6 = ifn_130.Invoke_O__O(arg_131) } else { b__1938000023__6 = linked_129.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_128, arg_131) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(b__1938000023__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__146); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_147 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var root_152 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = b__1938000023__6; if linked_153 == nil { arg_150 = ifn_154.Invoke_O__O(arg_155) } else { arg_150 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_152, arg_155) }; var arg_151 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp5 any; var root_156 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = s__1938000021__3; if linked_157 == nil { tmp5 = ifn_158.Invoke_O__O(arg_159) } else { tmp5 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_156, arg_159) }; arg_151 = tmp4.Invoke_O__O(tmp5); if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } } else { var root_160 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_165 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = b__1938000023__6; if linked_166 == nil { arg_163 = ifn_167.Invoke_O__O(arg_168) } else { arg_163 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_165, arg_168) }; var arg_164 any; if linked_161 == nil { return ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { return linked_161.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) } } } else { var f__4 any; var root_169 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__1938000021__3; if linked_170 == nil { f__4 = ifn_171.Invoke_O__O(arg_172) } else { f__4 = linked_170.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_169, arg_172) }; var tmp6 any; var root_173 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_175 lang.IFn
															if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = f__4; if linked_174 == nil { tmp6 = ifn_175.Invoke_O__O(arg_176) } else { tmp6 = linked_174.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_173, arg_176) }
//line :53:1
	if jrt.J2g_Truth(tmp6) { var p__5 any; var root_177 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_179 lang.IFn

		if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = f__4; if linked_178 == nil { p__5 = ifn_179.Invoke_O__O(arg_180) } else { p__5 = linked_178.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_177, arg_180) }
//line :53:1
		if jrt.J2g_Truth(p__5) { var root_181 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = lang.Tuple_Create_O_O__IPersistentVector(p__5, f__4); var arg_185 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp8 any; var root_186 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__1938000021__3; if linked_187 == nil { tmp8 = ifn_188.Invoke_O__O(arg_189) } else { tmp8 = linked_187.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_186, arg_189) }; arg_185 = tmp7.Invoke_O__O(tmp8); if linked_182 == nil { return ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { return linked_182.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) } } else { var tmp9 any; var root_190 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__1938000021__3; if linked_191 == nil { tmp9 = ifn_192.Invoke_O__O(arg_193) } else { tmp9 = linked_191.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_190, arg_193) }; s__1938000021__1 = tmp9; continue L1 } } else { var tmp10 any; var root_194 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = s__1938000021__3; if linked_195 == nil { tmp10 = ifn_196.Invoke_O__O(arg_197) } else { tmp10 = linked_195.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_194, arg_197) }; s__1938000021__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :53:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Ctor_O_I_O(c__b__1938000023 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000023 = c__b__1938000023; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Invoke_O__O(self any) any { { var i__1938000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000022__1)); var tmp2 any; var root_132 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_134 lang.IFn
																if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__2; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_132, arg_135) }
//line :53:1
	if jrt.J2g_Truth(tmp2) { var p__3 any; var root_136 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_138 lang.IFn

		if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = f__2; if linked_137 == nil { p__3 = ifn_138.Invoke_O__O(arg_139) } else { p__3 = linked_137.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_136, arg_139) }
//line :53:1
		if jrt.J2g_Truth(p__3) { var root_140 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = t.F_b__1938000023; var arg_144 any = lang.Tuple_Create_O_O__IPersistentVector(p__3, f__2); if linked_141 == nil { ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { linked_141.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }; i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_run_no_assembly_BANG__A_New() *A_arbace_go_run_no_assembly_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Ctor() {}
//line :60:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Invoke_O_O__O(self, src__0 any) any { var temp__1927000414__auto____2 any; var root_211 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_213 lang.IFn; if
											linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var fnbody__226 any = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New(); var tmp1 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class = fncls__225d; tmp1 = fncls__225d } else { tmp1 = fncls__225 }; arg_214 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__226, tmp1, nil); var arg_215 any; var root_227 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = src__0; var arg_231 any = A_arbace_go_run_A_const_49; if linked_228 == nil { arg_215 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { arg_215 = linked_228.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) }; if linked_212 == nil { temp__1927000414__auto____2 = ifn_213.Invoke_O_O__O(arg_214, arg_215) } else { temp__1927000414__auto____2 = linked_212.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_211, arg_214, arg_215) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; var root_232 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_go_run_fail_A_fn_class); var ifn_234 lang.IFn
												if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_go_run_A_const_51; var arg_236 any = Lit_14; var arg_237 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_69, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, s__3, nil)).Ref(); if linked_233 == nil { return ifn_234.Invoke_O_O_O__O(arg_235, arg_236, arg_237) } else { return linked_233.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_232, arg_235, arg_236, arg_237) } } else {
//line :61:1
			return nil } }
//line :61:1
func A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New() *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Ctor() {}
//line :61:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Invoke_O_O__O(self, p1__1938000031_SHARP___1 any) any { var tmp1 any; var root_216 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any; var root_221 any = A_arbace_go_run_A_const_19.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = p1__1938000031_SHARP___1; if linked_222 == nil { arg_219 = ifn_223.Invoke_O__O(arg_224) } else { arg_219 = linked_222.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_221, arg_224) }; var arg_220 any = Lit_71; if linked_217 == nil { tmp1 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { tmp1 = linked_217.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; if jrt.J2g_Truth(tmp1) { return p1__1938000031_SHARP___1 } else { return nil } }


func A_arbace_go_run_no_linkname_BANG__A_New() *A_arbace_go_run_no_linkname_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_linkname_BANG__A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Ctor() {}
//line :64:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Invoke_O_O__O(self, src__0 any) any { { var seq_1938000035__2 any; var root_238 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn
											if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__0); if linked_239 == nil { seq_1938000035__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1938000035__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :64:1
	var chunk_1938000036__3 any; var count_1938000037__4 int64 = 0; var i_1938000038__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000038__5, count_1938000037__4) { var fi__6 any = lang.Indexed_Cast(chunk_1938000036__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000038__5)); var seq_1938000051__7 any; var root_258 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = A_arbace_go_run_A_const_54.Invoke_O__O(fi__6); if linked_259 == nil { seq_1938000051__7 = ifn_260.Invoke_O__O(arg_261) } else { seq_1938000051__7 = linked_259.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_258, arg_261) }; var chunk_1938000052__8 any; var count_1938000053__9 int64 = 0; var i_1938000054__10 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000054__10, count_1938000053__9) { var d__11 any = lang.Indexed_Cast(chunk_1938000052__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000054__10)); var seq_1938000059__12 any; var root_278 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_284 lang.IFn
			if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_286 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_287 any = d__11; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O_O__O(arg_285, arg_286, arg_287) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_282, arg_285, arg_286, arg_287) }
//line :65:1
			if linked_279 == nil { seq_1938000059__12 = ifn_280.Invoke_O__O(arg_281) } else { seq_1938000059__12 = linked_279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_278, arg_281) }; var chunk_1938000060__13 any; var count_1938000061__14 int64 = 0; var i_1938000062__15 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000062__15, count_1938000061__14) { var x__16 any = lang.Indexed_Cast(chunk_1938000060__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000062__15)); var tmp1 any; var and__1927000168__auto____17 bool = lang.IObj_InstanceOf(x__16)

				if and__1927000168__auto____17 { var tmp2 *lang.Keyword = A_arbace_go_run_A_const_57; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() }
//line :65:1
				if jrt.J2g_Truth(tmp1) {


					var root_304 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_go_run_fail_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_go_run_A_const_51; var arg_308 any = Lit_14; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_309 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)), nil)).Ref(); if linked_305 == nil { ifn_306.Invoke_O_O_O__O(arg_307, arg_308, arg_309) } else { linked_305.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_304, arg_307, arg_308, arg_309) }
//line :65:1
					seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } else { seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } } else { var temp__1927000414__auto____16 any; var root_288 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = seq_1938000059__12; if linked_289 == nil { temp__1927000414__auto____16 = ifn_290.Invoke_O__O(arg_291) } else { temp__1927000414__auto____16 = linked_289.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_288, arg_291) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1938000059__17 any = temp__1927000414__auto____16; var tmp4 any; var root_292 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1938000059__17; if linked_293 == nil { tmp4 = ifn_294.Invoke_O__O(arg_295) } else { tmp4 = linked_293.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_292, arg_295) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_296 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = seq_1938000059__17; if linked_297 == nil { c__1927000678__auto____18 = ifn_298.Invoke_O__O(arg_299) } else { c__1927000678__auto____18 = linked_297.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_296, arg_299) }; var tmp5 any; var root_310 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = seq_1938000059__17; if linked_311 == nil { tmp5 = ifn_312.Invoke_O__O(arg_313) } else { tmp5 = linked_311.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_310, arg_313) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var x__18 any; var root_300 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = seq_1938000059__17; if linked_301 == nil { x__18 = ifn_302.Invoke_O__O(arg_303) } else { x__18 = linked_301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_300, arg_303) }; var tmp6 any; var and__1927000168__auto____19 bool = lang.IObj_InstanceOf(x__18)

						if and__1927000168__auto____19 { var tmp7 *lang.Keyword = A_arbace_go_run_A_const_57; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }
//line :65:1
						if jrt.J2g_Truth(tmp6) {


							var root_314 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, A_arbace_go_run_fail_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = A_arbace_go_run_A_const_51; var arg_318 any = Lit_14; var tmp8 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_319 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)), nil)).Ref(); if linked_315 == nil { ifn_316.Invoke_O_O_O__O(arg_317, arg_318, arg_319) } else { linked_315.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_314, arg_317, arg_318, arg_319) }
//line :65:1
							var tmp9 any; var root_320 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1938000059__17; if linked_321 == nil { tmp9 = ifn_322.Invoke_O__O(arg_323) } else { tmp9 = linked_321.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_320, arg_323) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp9, nil, 0, 0; continue L3 } else { var tmp10 any; var root_324 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = seq_1938000059__17; if linked_325 == nil { tmp10 = ifn_326.Invoke_O__O(arg_327) } else { tmp10 = linked_325.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_324, arg_327) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp10, nil, 0, 0; continue L3 } } } }; break L3 }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000054__10); continue L2 } else { var temp__1927000414__auto____11 any; var root_262 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = seq_1938000051__7; if linked_263 == nil { temp__1927000414__auto____11 = ifn_264.Invoke_O__O(arg_265) } else { temp__1927000414__auto____11 = linked_263.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_262, arg_265) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1938000051__12 any = temp__1927000414__auto____11; var tmp11 any; var root_266 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = seq_1938000051__12; if linked_267 == nil { tmp11 = ifn_268.Invoke_O__O(arg_269) } else { tmp11 = linked_267.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_266, arg_269) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_270 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = seq_1938000051__12; if linked_271 == nil { c__1927000678__auto____13 = ifn_272.Invoke_O__O(arg_273) } else { c__1927000678__auto____13 = linked_271.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_270, arg_273) }; var tmp12 any; var root_328 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = seq_1938000051__12; if linked_329 == nil { tmp12 = ifn_330.Invoke_O__O(arg_331) } else { tmp12 = linked_329.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_328, arg_331) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__13 any; var root_274 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = seq_1938000051__12; if linked_275 == nil { d__13 = ifn_276.Invoke_O__O(arg_277) } else { d__13 = linked_275.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_274, arg_277) }; var seq_1938000055__14 any; var root_332 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any; var root_336 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_338 lang.IFn
								if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_340 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_341 any = d__13; if linked_337 == nil { arg_335 = ifn_338.Invoke_O_O_O__O(arg_339, arg_340, arg_341) } else { arg_335 = linked_337.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_336, arg_339, arg_340, arg_341) }
//line :65:1
								if linked_333 == nil { seq_1938000055__14 = ifn_334.Invoke_O__O(arg_335) } else { seq_1938000055__14 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) }; var chunk_1938000056__15 any; var count_1938000057__16 int64 = 0; var i_1938000058__17 int64 = 0; L4: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000058__17, count_1938000057__16) { var x__18_2 any = lang.Indexed_Cast(chunk_1938000056__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000058__17)); var tmp13 any; var and__1927000168__auto____19_2 bool = lang.IObj_InstanceOf(x__18_2)

									if and__1927000168__auto____19_2 { var tmp14 *lang.Keyword = A_arbace_go_run_A_const_57; tmp13 = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_2).Ref() }
//line :65:1
									if jrt.J2g_Truth(tmp13) {


										var root_358 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_go_run_fail_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_run_A_const_51; var arg_362 any = Lit_14; var tmp15 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_363 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp15.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)), nil)).Ref(); if linked_359 == nil { ifn_360.Invoke_O_O_O__O(arg_361, arg_362, arg_363) } else { linked_359.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_358, arg_361, arg_362, arg_363) }
//line :65:1
										seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } else { seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } } else { var temp__1927000414__auto____18 any; var root_342 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = seq_1938000055__14; if linked_343 == nil { temp__1927000414__auto____18 = ifn_344.Invoke_O__O(arg_345) } else { temp__1927000414__auto____18 = linked_343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_342, arg_345) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000055__19 any = temp__1927000414__auto____18; var tmp16 any; var root_346 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = seq_1938000055__19; if linked_347 == nil { tmp16 = ifn_348.Invoke_O__O(arg_349) } else { tmp16 = linked_347.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____20 any; var root_350 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = seq_1938000055__19; if linked_351 == nil { c__1927000678__auto____20 = ifn_352.Invoke_O__O(arg_353) } else { c__1927000678__auto____20 = linked_351.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_350, arg_353) }; var tmp17 any; var root_364 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = seq_1938000055__19; if linked_365 == nil { tmp17 = ifn_366.Invoke_O__O(arg_367) } else { tmp17 = linked_365.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_364, arg_367) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp17, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__20 any; var root_354 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = seq_1938000055__19; if linked_355 == nil { x__20 = ifn_356.Invoke_O__O(arg_357) } else { x__20 = linked_355.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_354, arg_357) }; var tmp18 any; var and__1927000168__auto____21 bool = lang.IObj_InstanceOf(x__20)

											if and__1927000168__auto____21 { var tmp19 *lang.Keyword = A_arbace_go_run_A_const_57; tmp18 = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)) } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }
//line :65:1
											if jrt.J2g_Truth(tmp18) {


												var root_368 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_go_run_fail_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = A_arbace_go_run_A_const_51; var arg_372 any = Lit_14; var tmp20 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_373 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)), nil)).Ref(); if linked_369 == nil { ifn_370.Invoke_O_O_O__O(arg_371, arg_372, arg_373) } else { linked_369.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_368, arg_371, arg_372, arg_373) }
//line :65:1
												var tmp21 any; var root_374 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1938000055__19; if linked_375 == nil { tmp21 = ifn_376.Invoke_O__O(arg_377) } else { tmp21 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp21, nil, 0, 0; continue L4 } else { var tmp22 any; var root_378 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = seq_1938000055__19; if linked_379 == nil { tmp22 = ifn_380.Invoke_O__O(arg_381) } else { tmp22 = linked_379.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_378, arg_381) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp22, nil, 0, 0; continue L4 } } } }; break L4 }; var tmp23 any; var root_382 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = seq_1938000051__12; if linked_383 == nil { tmp23 = ifn_384.Invoke_O__O(arg_385) } else { tmp23 = linked_383.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_382, arg_385) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp23, nil, 0, 0; continue L2 } } }; break L2 }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000038__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_242 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = seq_1938000035__2; if linked_243 == nil { temp__1927000414__auto____6 = ifn_244.Invoke_O__O(arg_245) } else { temp__1927000414__auto____6 = linked_243.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_242, arg_245) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1938000035__7 any = temp__1927000414__auto____6; var tmp24 any; var root_246 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1938000035__7; if linked_247 == nil { tmp24 = ifn_248.Invoke_O__O(arg_249) } else { tmp24 = linked_247.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____8 any; var root_250 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1938000035__7; if linked_251 == nil { c__1927000678__auto____8 = ifn_252.Invoke_O__O(arg_253) } else { c__1927000678__auto____8 = linked_251.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_250, arg_253) }; var tmp25 any; var root_386 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = seq_1938000035__7; if linked_387 == nil { tmp25 = ifn_388.Invoke_O__O(arg_389) } else { tmp25 = linked_387.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_386, arg_389) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp25, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__8 any; var root_254 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1938000035__7; if linked_255 == nil { fi__8 = ifn_256.Invoke_O__O(arg_257) } else { fi__8 = linked_255.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_254, arg_257) }; var seq_1938000039__9 any; var root_390 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = A_arbace_go_run_A_const_54.Invoke_O__O(fi__8); if linked_391 == nil { seq_1938000039__9 = ifn_392.Invoke_O__O(arg_393) } else { seq_1938000039__9 = linked_391.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_390, arg_393) }; var chunk_1938000040__10 any; var count_1938000041__11 int64 = 0; var i_1938000042__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000042__12, count_1938000041__11) { var d__13_2 any = lang.Indexed_Cast(chunk_1938000040__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000042__12)); var seq_1938000047__14 any; var root_410 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var root_414 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_416 lang.IFn
													if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_418 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_419 any = d__13_2; if linked_415 == nil { arg_413 = ifn_416.Invoke_O_O_O__O(arg_417, arg_418, arg_419) } else { arg_413 = linked_415.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_414, arg_417, arg_418, arg_419) }
//line :65:1
													if linked_411 == nil { seq_1938000047__14 = ifn_412.Invoke_O__O(arg_413) } else { seq_1938000047__14 = linked_411.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_410, arg_413) }; var chunk_1938000048__15 any; var count_1938000049__16 int64 = 0; var i_1938000050__17 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000050__17, count_1938000049__16) { var x__18_3 any = lang.Indexed_Cast(chunk_1938000048__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000050__17)); var tmp26 any; var and__1927000168__auto____19_3 bool = lang.IObj_InstanceOf(x__18_3)

														if and__1927000168__auto____19_3 { var tmp27 *lang.Keyword = A_arbace_go_run_A_const_57; tmp26 = tmp27.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)) } else { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_3).Ref() }
//line :65:1
														if jrt.J2g_Truth(tmp26) {


															var root_436 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_go_run_fail_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = A_arbace_go_run_A_const_51; var arg_440 any = Lit_14; var tmp28 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_441 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp28.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)), nil)).Ref(); if linked_437 == nil { ifn_438.Invoke_O_O_O__O(arg_439, arg_440, arg_441) } else { linked_437.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_436, arg_439, arg_440, arg_441) }
//line :65:1
															seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } else { seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } } else { var temp__1927000414__auto____18_2 any; var root_420 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = seq_1938000047__14; if linked_421 == nil { temp__1927000414__auto____18_2 = ifn_422.Invoke_O__O(arg_423) } else { temp__1927000414__auto____18_2 = linked_421.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_420, arg_423) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1938000047__19 any = temp__1927000414__auto____18_2; var tmp29 any; var root_424 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = seq_1938000047__19; if linked_425 == nil { tmp29 = ifn_426.Invoke_O__O(arg_427) } else { tmp29 = linked_425.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_424, arg_427) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____20_2 any; var root_428 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = seq_1938000047__19; if linked_429 == nil { c__1927000678__auto____20_2 = ifn_430.Invoke_O__O(arg_431) } else { c__1927000678__auto____20_2 = linked_429.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_428, arg_431) }; var tmp30 any; var root_442 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1938000047__19; if linked_443 == nil { tmp30 = ifn_444.Invoke_O__O(arg_445) } else { tmp30 = linked_443.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_442, arg_445) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp30, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__20_2 any; var root_432 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seq_1938000047__19; if linked_433 == nil { x__20_2 = ifn_434.Invoke_O__O(arg_435) } else { x__20_2 = linked_433.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_432, arg_435) }; var tmp31 any; var and__1927000168__auto____21_2 bool = lang.IObj_InstanceOf(x__20_2)

																if and__1927000168__auto____21_2 { var tmp32 *lang.Keyword = A_arbace_go_run_A_const_57; tmp31 = tmp32.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }
//line :65:1
																if jrt.J2g_Truth(tmp31) {


																	var root_446 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_run_fail_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = A_arbace_go_run_A_const_51; var arg_450 any = Lit_14; var tmp33 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_451 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp33.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)), nil)).Ref(); if linked_447 == nil { ifn_448.Invoke_O_O_O__O(arg_449, arg_450, arg_451) } else { linked_447.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_446, arg_449, arg_450, arg_451) }
//line :65:1
																	var tmp34 any; var root_452 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1938000047__19; if linked_453 == nil { tmp34 = ifn_454.Invoke_O__O(arg_455) } else { tmp34 = linked_453.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_452, arg_455) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp34, nil, 0, 0; continue L6 } else { var tmp35 any; var root_456 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = seq_1938000047__19; if linked_457 == nil { tmp35 = ifn_458.Invoke_O__O(arg_459) } else { tmp35 = linked_457.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_456, arg_459) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp35, nil, 0, 0; continue L6 } } } }; break L6 }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000042__12); continue L5 } else { var temp__1927000414__auto____13 any; var root_394 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_1938000039__9; if linked_395 == nil { temp__1927000414__auto____13 = ifn_396.Invoke_O__O(arg_397) } else { temp__1927000414__auto____13 = linked_395.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_394, arg_397) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1938000039__14 any = temp__1927000414__auto____13; var tmp36 any; var root_398 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_1938000039__14; if linked_399 == nil { tmp36 = ifn_400.Invoke_O__O(arg_401) } else { tmp36 = linked_399.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_398, arg_401) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____15 any; var root_402 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = seq_1938000039__14; if linked_403 == nil { c__1927000678__auto____15 = ifn_404.Invoke_O__O(arg_405) } else { c__1927000678__auto____15 = linked_403.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_402, arg_405) }; var tmp37 any; var root_460 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = seq_1938000039__14; if linked_461 == nil { tmp37 = ifn_462.Invoke_O__O(arg_463) } else { tmp37 = linked_461.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_460, arg_463) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp37, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var d__15 any; var root_406 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = seq_1938000039__14; if linked_407 == nil { d__15 = ifn_408.Invoke_O__O(arg_409) } else { d__15 = linked_407.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_406, arg_409) }; var seq_1938000043__16 any; var root_464 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any; var root_468 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_470 lang.IFn
																		if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_472 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_473 any = d__15; if linked_469 == nil { arg_467 = ifn_470.Invoke_O_O_O__O(arg_471, arg_472, arg_473) } else { arg_467 = linked_469.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_468, arg_471, arg_472, arg_473) }
//line :65:1
																		if linked_465 == nil { seq_1938000043__16 = ifn_466.Invoke_O__O(arg_467) } else { seq_1938000043__16 = linked_465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_464, arg_467) }; var chunk_1938000044__17 any; var count_1938000045__18 int64 = 0; var i_1938000046__19 int64 = 0; L7: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000046__19, count_1938000045__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1938000044__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000046__19)); var tmp38 any; var and__1927000168__auto____21_3 bool = lang.IObj_InstanceOf(x__20_3)

																			if and__1927000168__auto____21_3 { var tmp39 *lang.Keyword = A_arbace_go_run_A_const_57; tmp38 = tmp39.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)) } else { tmp38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_3).Ref() }
//line :65:1
																			if jrt.J2g_Truth(tmp38) {


																				var root_490 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, A_arbace_go_run_fail_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = A_arbace_go_run_A_const_51; var arg_494 any = Lit_14; var tmp40 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_495 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp40.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)), nil)).Ref(); if linked_491 == nil { ifn_492.Invoke_O_O_O__O(arg_493, arg_494, arg_495) } else { linked_491.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_490, arg_493, arg_494, arg_495) }
//line :65:1
																				seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } else { seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } } else { var temp__1927000414__auto____20 any; var root_474 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = seq_1938000043__16; if linked_475 == nil { temp__1927000414__auto____20 = ifn_476.Invoke_O__O(arg_477) } else { temp__1927000414__auto____20 = linked_475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_474, arg_477) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1938000043__21 any = temp__1927000414__auto____20; var tmp41 any; var root_478 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = seq_1938000043__21; if linked_479 == nil { tmp41 = ifn_480.Invoke_O__O(arg_481) } else { tmp41 = linked_479.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_478, arg_481) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____22 any; var root_482 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = seq_1938000043__21; if linked_483 == nil { c__1927000678__auto____22 = ifn_484.Invoke_O__O(arg_485) } else { c__1927000678__auto____22 = linked_483.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_482, arg_485) }; var tmp42 any; var root_496 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = seq_1938000043__21; if linked_497 == nil { tmp42 = ifn_498.Invoke_O__O(arg_499) } else { tmp42 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_496, arg_499) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp42, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22 any; var root_486 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1938000043__21; if linked_487 == nil { x__22 = ifn_488.Invoke_O__O(arg_489) } else { x__22 = linked_487.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_486, arg_489) }; var tmp43 any; var and__1927000168__auto____23 bool = lang.IObj_InstanceOf(x__22)

																					if and__1927000168__auto____23 { var tmp44 *lang.Keyword = A_arbace_go_run_A_const_57; tmp43 = tmp44.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)) } else { tmp43 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }
//line :65:1
																					if jrt.J2g_Truth(tmp43) {


																						var root_500 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_go_run_fail_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = A_arbace_go_run_A_const_51; var arg_504 any = Lit_14; var tmp45 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_505 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_15, nil, Lit_70), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)), nil)).Ref(); if linked_501 == nil { ifn_502.Invoke_O_O_O__O(arg_503, arg_504, arg_505) } else { linked_501.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_500, arg_503, arg_504, arg_505) }
//line :65:1
																						var tmp46 any; var root_506 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = seq_1938000043__21; if linked_507 == nil { tmp46 = ifn_508.Invoke_O__O(arg_509) } else { tmp46 = linked_507.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_506, arg_509) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp46, nil, 0, 0; continue L7 } else { var tmp47 any; var root_510 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = seq_1938000043__21; if linked_511 == nil { tmp47 = ifn_512.Invoke_O__O(arg_513) } else { tmp47 = linked_511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_510, arg_513) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp47, nil, 0, 0; continue L7 } } } }; break L7 }; var tmp48 any; var root_514 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = seq_1938000039__14; if linked_515 == nil { tmp48 = ifn_516.Invoke_O__O(arg_517) } else { tmp48 = linked_515.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_514, arg_517) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp48, nil, 0, 0; continue L5 } } }; break L5 }; var tmp49 any; var root_518 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = seq_1938000035__7; if linked_519 == nil { tmp49 = ifn_520.Invoke_O__O(arg_521) } else { tmp49 = linked_519.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_518, arg_521) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp49, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :64:1*/panic("j2g: unreachable") }





func A_arbace_go_run_check_BANG__A_New() *A_arbace_go_run_check_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_go_run_check_BANG__A) Ctor() {}
//line :70:1
func (t *A_arbace_go_run_check_BANG__A) Invoke_O_O_O__O(self, src__0, extra__1 any) any {
	var root_527 any = A_arbace_go_run_A_const_61.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = src__0; if linked_528 == nil { ifn_529.Invoke_O__O(arg_530) } else { linked_528.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_527, arg_530) }
	var root_531 any = A_arbace_go_run_A_const_62.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, A_arbace_go_run_no_linkname_BANG__A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = src__0; if linked_532 == nil { ifn_533.Invoke_O__O(arg_534) } else { linked_532.(*A_arbace_go_run_no_linkname_BANG__A).Invoke_O_O__O(root_531, arg_534) }
//line :70:1
	var r__3 any; var root_522 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_524 lang.IFn


	if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = src__0; var arg_526 any = extra__1; if linked_523 == nil { r__3 = ifn_524.Invoke_O_O__O(arg_525, arg_526) } else { r__3 = linked_523.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_522, arg_525, arg_526) }
//line :70:1
	var errs__4 any = A_arbace_go_run_A_const_60.Invoke_O__O(r__3); var temp__1927000414__auto____5 any; var root_535 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_537 lang.IFn




	if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any; var fnbody__541 any = A_arbace_go_run_check_BANG__fn__1938000065_A_New(); var tmp1 *jrt.Class; var fncls__540 *jrt.Class = A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class; if fncls__540 == nil { var fncls__540d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class = fncls__540d; tmp1 = fncls__540d } else { tmp1 = fncls__540 }; arg_538 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__541, tmp1, nil); var arg_539 any = errs__4; if linked_536 == nil { temp__1927000414__auto____5 = ifn_537.Invoke_O_O__O(arg_538, arg_539) } else { temp__1927000414__auto____5 = linked_536.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_535, arg_538, arg_539) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var bi__6 any = temp__1927000414__auto____5; var root_542 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, A_arbace_go_run_fail_A_fn_class); var ifn_544 lang.IFn
		if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = A_arbace_go_run_A_const_51; var arg_546 any = Lit_14; var arg_547 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_65.Invoke_O__O(bi__6))).Ref(); if linked_543 == nil { ifn_544.Invoke_O_O_O__O(arg_545, arg_546, arg_547) } else { linked_543.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_542, arg_545, arg_546, arg_547) } }
	var tmp2 any; var root_548 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = errs__4; if linked_549 == nil { tmp2 = ifn_550.Invoke_O__O(arg_551) } else { tmp2 = linked_549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_548, arg_551) }; if jrt.J2g_Truth(tmp2) {
		var root_552 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_go_run_fail_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = A_arbace_go_run_A_const_66; var arg_556 any = Lit_4; var arg_557 any; var tmp3 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp4 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__0); var tmp5 *lang.Keyword = A_arbace_go_run_A_const_67; var tmp6 any; var root_558 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = errs__4; if linked_559 == nil { tmp6 = ifn_560.Invoke_O__O(arg_561) } else { tmp6 = linked_559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_558, arg_561) }; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 *lang.Keyword = A_arbace_go_run_A_const_68; var tmp9 any; var root_562 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = errs__4; if linked_563 == nil { tmp9 = ifn_564.Invoke_O__O(arg_565) } else { tmp9 = linked_563.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_562, arg_565) }; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 *lang.Keyword = A_arbace_go_run_A_const_65; var tmp12 any; var root_566 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = errs__4; if linked_567 == nil { tmp12 = ifn_568.Invoke_O__O(arg_569) } else { tmp12 = linked_567.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_566, arg_569) }; arg_557 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp7, nil, tmp10, nil, tmp11.Invoke_O__O(tmp12))).Ref(); if linked_553 == nil { ifn_554.Invoke_O_O_O__O(arg_555, arg_556, arg_557) } else { linked_553.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_552, arg_555, arg_556, arg_557) } }
//line :70:1
	return r__3
}



func A_arbace_go_run_check_BANG__fn__1938000065_A_New() *A_arbace_go_run_check_BANG__fn__1938000065_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__fn__1938000065_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Ctor() {}
//line :75:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Invoke_O_O__O(self, p1__1938000064_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_63; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000064_SHARP___1)) { return p1__1938000064_SHARP___1 } else { return nil } }





func A_arbace_go_run_imports_of_A_New() *A_arbace_go_run_imports_of_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_run_imports_of_A) Ctor() {}
//line :81:1
func (t *A_arbace_go_run_imports_of_A) Invoke_O_O__O(self, src__0 any) any { var li__2 any; var root_570 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_572 lang.IFn; if


	linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = src__0; var arg_574 any = A_arbace_go_run_A_const_69; if linked_571 == nil { li__2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { li__2 = linked_571.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; var root_575 any =
	A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var iter__1927001039__auto____3 any; var fnbody__702 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(li__2); var tmp1 *jrt.Class; var fncls__701 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class; if
	fncls__701 == nil { var fncls__701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__702); A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class = fncls__701d; tmp1 = fncls__701d } else { tmp1 = fncls__701 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__702, tmp1, nil); arg_578 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_run_A_const_53.Invoke_O__O(src__0)); if /*line :85:1*/ linked_576 == nil { return ifn_577.Invoke_O__O(arg_578) } else { return linked_576.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_575, arg_578) } }
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A{}; t.Ctor_O(p0); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Invoke_O_O__O(self, s__1938000069__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__700 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(s__1938000069__1, self, t.F_li); var tmp2 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class; if fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__700); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class = fncls__699d; tmp2 = fncls__699d } else { tmp2 = fncls__699 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__700, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Ctor_O_O_O(c__s__1938000069, c__iter__1938000068, c__li any) { t.F_s__1938000069 = c__s__1938000069; t.F_iter__1938000068 = c__iter__1938000068; t.F_li = c__li }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Invoke_O__O(self any) any { { var s__1938000069__1 any; var t_ any = t.F_s__1938000069; t.F_s__1938000069 = nil; s__1938000069__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_579 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = s__1938000069__1; if linked_580 == nil { temp__1927000414__auto____2 = ifn_581.Invoke_O__O(arg_582) } else { temp__1927000414__auto____2 = linked_580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_579, arg_582) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var fi__4 any; var root_583 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = xs__1927001018__auto____3; if linked_584 == nil { fi__4 = ifn_585.Invoke_O__O(arg_586) } else { fi__4 = linked_584.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_583, arg_586) }; var iterys__1927001035__auto____5 any; var fnbody__676 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(t.F_li); var tmp1 *jrt.Class; var fncls__675 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class; if fncls__675 == nil { var fncls__675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__676); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class = fncls__675d; tmp1 = fncls__675d } else { tmp1 = fncls__675 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__676, tmp1, nil); var fs__1927001036__auto____6 any; var root_677 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_681 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_683 lang.IFn
														if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = fi__4; var arg_685 any = A_arbace_go_run_A_const_74; if linked_682 == nil { tmp3 = ifn_683.Invoke_O_O__O(arg_684, arg_685) } else { tmp3 = linked_682.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_681, arg_684, arg_685) }
//line :86:1
	arg_680 = tmp2.Invoke_O__O(tmp3); if linked_678 == nil { fs__1927001036__auto____6 = ifn_679.Invoke_O__O(arg_680) } else { fs__1927001036__auto____6 = linked_678.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_677, arg_680) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_686 any = A_arbace_go_run_A_const_75.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = fs__1927001036__auto____6; var arg_690 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000068); var tmp5 any; var root_691 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = s__1938000069__1; if linked_692 == nil { tmp5 = ifn_693.Invoke_O__O(arg_694) } else { tmp5 = linked_692.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_691, arg_694) }; arg_690 = tmp4.Invoke_O__O(tmp5); if linked_687 == nil { return ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { return linked_687.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) } } else { var tmp6 any; var root_695 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__1938000069__1; if linked_696 == nil { tmp6 = ifn_697.Invoke_O__O(arg_698) } else { tmp6 = linked_696.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_695, arg_698) }; s__1938000069__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A{}; t.Ctor_O(p0); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Invoke_O_O__O(self, s__1938000071__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__674 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(s__1938000071__1, t.F_li, self); var tmp2 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__674); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class = fncls__673d; tmp2 = fncls__673d } else { tmp2 = fncls__673 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__674, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Ctor_O_O_O(c__s__1938000071, c__li, c__iter__1938000070 any) { t.F_s__1938000071 = c__s__1938000071; t.F_li = c__li; t.F_iter__1938000070 = c__iter__1938000070 }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Invoke_O__O(self any) any { { var s__1938000071__1 any; var t_ any = t.F_s__1938000071; t.F_s__1938000071 = nil; s__1938000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_587 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = s__1938000071__1; if linked_588 == nil { temp__1927000414__auto____2 = ifn_589.Invoke_O__O(arg_590) } else { temp__1927000414__auto____2 = linked_588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_587, arg_590) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_591 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = s__1938000071__3; if linked_592 == nil { tmp1 = ifn_593.Invoke_O__O(arg_594) } else { tmp1 = linked_592.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_591, arg_594) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_595 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = s__1938000071__3; if linked_596 == nil { c__1927001037__auto____4 = ifn_597.Invoke_O__O(arg_598) } else { c__1927001037__auto____4 = linked_596.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_595, arg_598) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000073__6 any; var root_599 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_600 == nil { b__1938000073__6 = ifn_601.Invoke_O__O(arg_602) } else { b__1938000073__6 = linked_600.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_599, arg_602) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__621 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(b__1938000073__6, t.F_li, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__621); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class = fncls__620d; tmp3 = fncls__620d } else { tmp3 = fncls__620 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__621, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_622 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var root_627 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = b__1938000073__6; if linked_628 == nil { arg_625 = ifn_629.Invoke_O__O(arg_630) } else { arg_625 = linked_628.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_627, arg_630) }; var arg_626 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp5 any; var root_631 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = s__1938000071__3; if linked_632 == nil { tmp5 = ifn_633.Invoke_O__O(arg_634) } else { tmp5 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_631, arg_634) }; arg_626 = tmp4.Invoke_O__O(tmp5); if linked_623 == nil { return ifn_624.Invoke_O_O__O(arg_625, arg_626) } else { return linked_623.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_622, arg_625, arg_626) } } else { var root_635 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any; var root_640 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = b__1938000073__6; if linked_641 == nil { arg_638 = ifn_642.Invoke_O__O(arg_643) } else { arg_638 = linked_641.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_640, arg_643) }; var arg_639 any; if linked_636 == nil { return ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { return linked_636.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } } } else { var spec__4 any; var root_644 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = s__1938000071__3; if linked_645 == nil { spec__4 = ifn_646.Invoke_O__O(arg_647) } else { spec__4 = linked_645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_644, arg_647) }; var p__5 any; var tmp6 any; var root_648 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_650 lang.IFn

	if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = spec__4; if linked_649 == nil { tmp6 = ifn_650.Invoke_O__O(arg_651) } else { tmp6 = linked_649.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(tmp6) { var root_652 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = spec__4; if linked_653 == nil { p__5 = ifn_654.Invoke_O__O(arg_655) } else { p__5 = linked_653.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_652, arg_655) } } else { p__5 = spec__4 }
//line :86:1
	var tmp7 any; var root_656 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_658 lang.IFn


	if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = p__5; if linked_657 == nil { tmp7 = ifn_658.Invoke_O__O(arg_659) } else { tmp7 = linked_657.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_656, arg_659) }
//line :86:1
	if jrt.J2g_Truth(tmp7) { var root_660 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__5, p__5); var arg_664 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp9 any; var root_665 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = s__1938000071__3; if linked_666 == nil { tmp9 = ifn_667.Invoke_O__O(arg_668) } else { tmp9 = linked_666.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_665, arg_668) }; arg_664 = tmp8.Invoke_O__O(tmp9); if linked_661 == nil { return ifn_662.Invoke_O_O__O(arg_663, arg_664) } else { return linked_661.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_660, arg_663, arg_664) } } else { var tmp10 any; var root_669 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = s__1938000071__3; if linked_670 == nil { tmp10 = ifn_671.Invoke_O__O(arg_672) } else { tmp10 = linked_670.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_669, arg_672) }; s__1938000071__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Ctor_O_O_I_O(c__b__1938000073, c__li any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000073 = c__b__1938000073; t.F_li = c__li; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Invoke_O__O(self any) any { { var i__1938000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000072__1)); var p__3 any; var tmp2 any; var root_603 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_605 lang.IFn

	if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = spec__2; if linked_604 == nil { tmp2 = ifn_605.Invoke_O__O(arg_606) } else { tmp2 = linked_604.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_603, arg_606) }; if jrt.J2g_Truth(tmp2) { var root_607 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = spec__2; if linked_608 == nil { p__3 = ifn_609.Invoke_O__O(arg_610) } else { p__3 = linked_608.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_607, arg_610) } } else { p__3 = spec__2 }
//line :86:1
	var tmp3 any; var root_611 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_613 lang.IFn


	if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = p__3; if linked_612 == nil { tmp3 = ifn_613.Invoke_O__O(arg_614) } else { tmp3 = linked_612.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_611, arg_614) }
//line :86:1
	if jrt.J2g_Truth(tmp3) { var root_615 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = t.F_b__1938000073; var arg_619 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__3, p__3); if linked_616 == nil { ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { linked_616.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_615, arg_618, arg_619) }; i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } else { i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_run_A_New() *A_arbace_go_run_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_go_run_run_A) Ctor() {}
//line :92:1
func (t *A_arbace_go_run_run_A) Invoke_O_O_O_O__O(self, root__0, pf__1, args__2 any) any {




	var root_947 any = A_arbace_go_run_A_const_115.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var arg_951 any = jrt.Boolean_TRUE.Ref(); if linked_948 == nil { ifn_949.Invoke_O_O__O(arg_950, arg_951) } else { linked_948.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_947, arg_950, arg_951)
	}
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_113.GetRawRoot__O()); var tmp2 any; var root_957 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any; var root_962 any = A_arbace_go_run_A_const_19.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = jrt.File_Cast(pf__1).GetName__String().Ref(); if linked_963 == nil { arg_960 = ifn_964.Invoke_O__O(arg_965) } else { arg_960 = linked_963.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_962, arg_965) }; var arg_961 any = args__2; if linked_958 == nil { tmp2 = ifn_959.Invoke_O_O__O(arg_960, arg_961) } else { tmp2 = linked_958.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_957, arg_960, arg_961) }; tmp1.Invoke_O_O__O(Lit_86, lang.RT_Object_array_O__O1_NoInit(tmp2).Ref())
//line :92:1
	var src__4 any; var root_703 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_705 lang.IFn







	if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_77, root__0)); var arg_707 any; var arg_708 any; var root_710 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_711 == nil { arg_708 = ifn_712.Invoke_O__O(arg_713) } else { arg_708 = linked_711.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_710, arg_713) }; var arg_709 any = pf__1; if linked_704 == nil { src__4 = ifn_705.Invoke_O_O_O_O__O(arg_706, arg_707, arg_708, arg_709) } else { src__4 = linked_704.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_703, arg_706, arg_707, arg_708, arg_709) }
//line :92:1
	var ___5 any; var tmp3 any; var root_714 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_716 lang.IFn; _ = ___5








	if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__4); if linked_715 == nil { tmp3 = ifn_716.Invoke_O__O(arg_717) } else { tmp3 = linked_715.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_714, arg_717) }; if jrt.J2g_Truth(tmp3) { var root_718 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, A_arbace_go_run_fail_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = A_arbace_go_run_A_const_51; var arg_722 any = Lit_14; var arg_723 any = Lit_26; if linked_719 == nil { ___5 = ifn_720.Invoke_O_O_O__O(arg_721, arg_722, arg_723) } else { ___5 = linked_719.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_718, arg_721, arg_722, arg_723) } } else { ___5 = nil }
//line :92:1
	var index__6 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__729 any = A_arbace_go_run_run_fn__1938000087_A_New_O(pf__1); var tmp5 *jrt.Class
	var fncls__728 /*line :92:1*/*jrt.Class = A_arbace_go_run_run_fn__1938000087_A_fn_class









	if fncls__728 == nil { var fncls__728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__729); A_arbace_go_run_run_fn__1938000087_A_fn_class = fncls__728d; tmp5 = fncls__728d } else { tmp5 = fncls__728 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__729, tmp5, nil)
//line :92:1
	index__6 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp4)); var srcs__7 any; var root_730 any = A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_732 lang.IFn










	if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_731 == nil { srcs__7 = ifn_732.Invoke_O__O(arg_733) } else { srcs__7 = linked_731.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_730, arg_733) }
//line :92:1
	var inits__8 any; var root_734 any = A_arbace_go_run_A_const_82.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_736 lang.IFn











	if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_735 == nil { inits__8 = ifn_736.Invoke_O__O(arg_737) } else { inits__8 = linked_735.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_734, arg_737) }
//line :92:1
	var deps__9 any; var root_738 any = A_arbace_go_run_A_const_82.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_740 lang.IFn












	if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_739 == nil { deps__9 = ifn_740.Invoke_O__O(arg_741) } else { deps__9 = linked_739.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_738, arg_741) }
//line :92:1
	var extra__10 any; var fnbody__747 any = A_arbace_go_run_run_extra__1938000089_A_New_O(srcs__7); var tmp6 *jrt.Class
	var fncls__746 /*line :92:1*/*jrt.Class = A_arbace_go_run_run_extra__1938000089_A_fn_class













	if fncls__746 == nil { var fncls__746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__747); A_arbace_go_run_run_extra__1938000089_A_fn_class = fncls__746d; tmp6 = fncls__746d } else { tmp6 = fncls__746 }; extra__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__747, tmp6, nil)
//line :92:1
	var define__11 any; var fnbody__831 any = A_arbace_go_run_run_define__1938000091_A_New_O_O_O(srcs__7, inits__8, deps__9); var tmp7 *jrt.Class
	var fncls__830 /*line :92:1*/*jrt.Class = A_arbace_go_run_run_define__1938000091_A_fn_class














	if fncls__830 == nil { var fncls__830d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__831); A_arbace_go_run_run_define__1938000091_A_fn_class = fncls__830d; tmp7 = fncls__830d } else { tmp7 = fncls__830 }; define__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__831, tmp7, nil)
//line :92:1
	var init_order__12 any; var fnbody__903 any = A_arbace_go_run_run_init_order__1938000097_A_New_O_O(inits__8, deps__9); var tmp8 *jrt.Class
	var fncls__902 /*line :92:1*/*jrt.Class = A_arbace_go_run_run_init_order__1938000097_A_fn_class




























	if fncls__902 == nil { var fncls__902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__903); A_arbace_go_run_run_init_order__1938000097_A_fn_class = fncls__902d; tmp8 = fncls__902d } else { tmp8 = fncls__902 }; init_order__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__903, tmp8, nil)
//line :92:1
	var body_load_BANG___13 *A_arbace_go_run_run_load_BANG___1938000101_A = A_arbace_go_run_run_load_BANG___1938000101_A_New_O_O_O_O_O(root__0, extra__10, srcs__7, index__6, define__11); var load_BANG___13 any; var fnbody__1063 any = any(body_load_BANG___13); var tmp9 *jrt.Class; var fncls__1062 *jrt.Class = A_arbace_go_run_run_load_BANG___1938000101_A_fn_class; if fncls__1062 == nil { var fncls__1062d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__1063); A_arbace_go_run_run_load_BANG___1938000101_A_fn_class = fncls__1062d; tmp9 = fncls__1062d } else { tmp9 = fncls__1062 }; load_BANG___13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1063, tmp9, nil); var seq_1938000107__14 any; var root_1064 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1066 lang.IFn












































	if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any; var root_1068 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, A_arbace_go_run_imports_of_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = src__4; if linked_1069 == nil { arg_1067 = ifn_1070.Invoke_O__O(arg_1071) } else { arg_1067 = linked_1069.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1068, arg_1071) }; if linked_1065 == nil { seq_1938000107__14 = ifn_1066.Invoke_O__O(arg_1067) } else { seq_1938000107__14 = linked_1065.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1064, arg_1067) }
//line :92:1
	var chunk_1938000108__15 any; var count_1938000109__16 int64 = 0; var i_1938000110__17 int64 = 0; L1: for {












































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000110__17, count_1938000109__16) { var p__18 any = lang.Indexed_Cast(chunk_1938000108__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000110__17)); lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__18, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_52.Invoke_O__O(src__4)))); seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000110__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1072 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any = seq_1938000107__14; if linked_1073 == nil { temp__1927000414__auto____18 = ifn_1074.Invoke_O__O(arg_1075) } else { temp__1927000414__auto____18 = linked_1073.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1072, arg_1075) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000107__19 any = temp__1927000414__auto____18; var tmp10 any; var root_1076 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = seq_1938000107__19; if linked_1077 == nil { tmp10 = ifn_1078.Invoke_O__O(arg_1079) } else { tmp10 = linked_1077.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1076, arg_1079) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____20 any; var root_1080 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = seq_1938000107__19; if linked_1081 == nil { c__1927000678__auto____20 = ifn_1082.Invoke_O__O(arg_1083) } else { c__1927000678__auto____20 = linked_1081.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1080, arg_1083) }; var tmp11 any; var root_1088 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = seq_1938000107__19; if linked_1089 == nil { tmp11 = ifn_1090.Invoke_O__O(arg_1091) } else { tmp11 = linked_1089.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1088, arg_1091) }; seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = tmp11, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__20 any; var root_1084 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = seq_1938000107__19; if linked_1085 == nil { p__20 = ifn_1086.Invoke_O__O(arg_1087) } else { p__20 = linked_1085.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1084, arg_1087) }; lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__20, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_52.Invoke_O__O(src__4)))); var tmp12 any; var root_1092 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = seq_1938000107__19; if linked_1093 == nil { tmp12 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp12 = linked_1093.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1092, arg_1095) }; seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = tmp12, nil, 0, 0; continue L1 } } }
//line :92:1
		break L1 }; var r__13 any; var root_904 any = A_arbace_go_run_A_const_110.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_go_run_check_BANG__A_fn_class); var ifn_906 lang.IFn













































	if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = src__4; var arg_908 any = extra__10; if linked_905 == nil { r__13 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { r__13 = linked_905.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }
//line :92:1
	var ___14 any; var root_909 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_911 lang.IFn; _ = ___14














































	if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = srcs__7; var arg_913 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var arg_914 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__4); var arg_915 any = src__4; if linked_910 == nil { ___14 = ifn_911.Invoke_O_O_O_O__O(arg_912, arg_913, arg_914, arg_915) } else { ___14 = linked_910.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_909, arg_912, arg_913, arg_914, arg_915) }
//line :92:1
	var map__1938000111__15 any = lang.IFn_Cast(define__11).Invoke_O_O__O(src__4, r__13); var map__1938000111__16 any













































	if lang.ISeq_InstanceOf(map__1938000111__15) { var tmp13 any; var root_916 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = map__1938000111__15; if linked_917 == nil { tmp13 = ifn_918.Invoke_O__O(arg_919) } else { tmp13 = linked_917.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_916, arg_919) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_920 any = A_arbace_go_run_A_const_111.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = map__1938000111__15; if linked_921 == nil { tmp14 = ifn_922.Invoke_O__O(arg_923) } else { tmp14 = linked_921.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_920, arg_923) }; map__1938000111__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp14)).Ref() } else { var tmp15 any; var root_924 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = map__1938000111__15; if linked_925 == nil { tmp15 = ifn_926.Invoke_O__O(arg_927) } else { tmp15 = linked_925.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_924, arg_927) }; if jrt.J2g_Truth(tmp15) { var root_928 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = map__1938000111__15; if linked_929 == nil { map__1938000111__16 = ifn_930.Invoke_O__O(arg_931) } else { map__1938000111__16 = linked_929.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_928, arg_931) } } else { map__1938000111__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1938000111__16 = map__1938000111__15 }
//line :92:1
	var main__17 any = lang.RT_Get_O_O__O_NoInit(map__1938000111__16, A_arbace_go_run_A_const_112)
















































	if jrt.J2g_Truth(main__17) { } else {
		var root_1096 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_go_run_fail_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = A_arbace_go_run_A_const_66; var arg_1100 any = Lit_4; var arg_1101 any = Lit_92; if linked_1097 == nil { ifn_1098.Invoke_O_O_O__O(arg_1099, arg_1100, arg_1101) } else { linked_1097.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1096, arg_1099, arg_1100, arg_1101) } }
	var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_113.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_114.GetRawRoot__O()); var tmp18 any; var root_943 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = inits__8; if linked_944 == nil { tmp18 = ifn_945.Invoke_O__O(arg_946) } else { tmp18 = linked_944.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_943, arg_946) }; return tmp16.Invoke_O_O_O__O(Lit_93, lang.RT_Object_array_O__O1_NoInit(tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(init_order__12).Invoke__O())).Ref(), main__17) }
//line :102:1
func A_arbace_go_run_run_fn__1938000087_A_New_O(p0 any) *A_arbace_go_run_run_fn__1938000087_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_fn__1938000087_A{}; t.Ctor_O(p0); return t }
//line :102:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Ctor_O(c__pf any) { t.F_pf = c__pf }
//line :102:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Invoke_O__O(self any) any { var root_724 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, A_arbace_go_run_dir_test_index_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any; var t_ any = t.F_pf; t.F_pf = nil; arg_727 = t_; if linked_725 == nil { return ifn_726.Invoke_O__O(arg_727) } else { return linked_725.(*A_arbace_go_run_dir_test_index_A).Invoke_O_O__O(root_724, arg_727) } }



func A_arbace_go_run_run_extra__1938000089_A_New_O(p0 any) *A_arbace_go_run_run_extra__1938000089_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_extra__1938000089_A{}; t.Ctor_O(p0); return t }
//line :106:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :106:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_742 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = t.F_srcs; if linked_743 == nil { tmp1 = ifn_744.Invoke_O__O(arg_745) } else { tmp1 = linked_743.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_742, arg_745) }; return lang.RT_Get_O_O__O_NoInit(tmp1, path__1) }
func A_arbace_go_run_run_define__1938000091_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :107:1
func (t *A_arbace_go_run_run_define__1938000091_A) Ctor_O_O_O(c__srcs, c__inits, c__deps any) { t.F_srcs = c__srcs; t.F_inits = c__inits; t.F_deps = c__deps }
//line :107:1
func (t *A_arbace_go_run_run_define__1938000091_A) Invoke_O_O_O__O(self, src__1, r__2 any) any { var st__3 any; var root_748 any = A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_750 lang.IFn; if
												linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any; var tmp1 any = A_arbace_go_run_A_const_52; var tmp2 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var tmp3 any = A_arbace_go_run_A_const_83; var tmp4 any = A_arbace_go_run_A_const_83.Invoke_O__O(src__1); var tmp5 any = A_arbace_go_run_A_const_84; var tmp6 any; var root_752 any = A_arbace_go_run_A_const_85.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_83.Invoke_O__O(src__1))).Ref(); if linked_753 == nil { tmp6 = ifn_754.Invoke_O__O(arg_755) } else { tmp6 = linked_753.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_752, arg_755) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_run_A_const_86; var tmp9 any = A_arbace_go_run_A_const_86.Invoke_O__O(src__1); var tmp10 any = A_arbace_go_run_A_const_87; var tmp11 any = A_arbace_go_run_A_const_87.Invoke_O__O(src__1); var tmp12 any = A_arbace_go_run_A_const_88; var tmp13 any = A_arbace_go_run_A_const_88.Invoke_O__O(src__1); var tmp14 any = A_arbace_go_run_A_const_53; var tmp15 any; var root_756 any = A_arbace_go_run_A_const_89.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_758 lang.IFn; if
												linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__1); if linked_757 == nil { tmp15 = ifn_758.Invoke_O__O(arg_759) } else { tmp15 = linked_757.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_756, arg_759) }; arg_751 = /*line :108:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, A_arbace_go_run_A_const_90, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_91, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_92, lang.PersistentArrayMap_EMPTY.Ref())); if linked_749 == nil { st__3 = ifn_750.Invoke_O__O(arg_751) } else { st__3 = linked_749.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_748, arg_751) }; var root_782 any =

	A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_782, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var arg_786 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var arg_787 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var arg_788 any = st__3; if linked_783 == nil { ifn_784.Invoke_O_O_O_O__O(arg_785, arg_786, arg_787, arg_788) } else { linked_783.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_782, arg_785, arg_786, arg_787, arg_788) }; var d__4 any; var tmp16 /*line :107:1*/*lang.Compiler_AOTFn; var fnbody__781 any = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O_O_O(src__1, r__2, st__3); var tmp17 *jrt.Class; var fncls__780 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class; if



	fncls__780 == nil { var fncls__780d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__781); A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class = fncls__780d; tmp17 = fncls__780d } else { tmp17 = fncls__780 }; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__781, tmp17, nil); d__4 = Up_Compiler_AOTFn_IFn(tmp16).Invoke__O(); var tmp18 /*line :117:1*/*lang.Volatile = lang.Volatile_Cast(t.F_inits); var tmp19 any; var root_789 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = jrt.NN(lang.Volatile_Cast(t.F_inits)).Deref__O(); var arg_793 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var arg_794 any; var root_795 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = A_arbace_go_run_A_const_100.Invoke_O__O(d__4); var arg_799 any = A_arbace_go_run_A_const_101.Invoke_O__O(d__4); if linked_796 == nil { arg_794 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { arg_794 = linked_796.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }; if linked_790 == nil { tmp19 = ifn_791.Invoke_O_O_O__O(arg_792, arg_793, arg_794) } else { tmp19 = linked_790.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_789, arg_792, arg_793, arg_794) }; jrt.NN(tmp18).Reset_O__O(tmp19); var tmp20 /*line :118:1*/*lang.Volatile = lang.Volatile_Cast(t.F_deps); var tmp21 any; var root_800 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = jrt.NN(lang.Volatile_Cast(t.F_deps)).Deref__O(); var arg_804 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var arg_805 any; var root_806 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any; var root_810 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any; var fnbody__825 any = A_arbace_go_run_run_define__1938000091_fn__1938000094_A_New_O(t.F_srcs); var tmp22 *jrt.Class; var fncls__824 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class; if fncls__824 == nil { var fncls__824d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__825); A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class = fncls__824d; tmp22 = fncls__824d } else { tmp22 = fncls__824 }; arg_813 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__825, tmp22, nil); var arg_814 any; var root_826 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_go_run_imports_of_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = src__1; if linked_827 == nil { arg_814 = ifn_828.Invoke_O__O(arg_829) } else { arg_814 = linked_827.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_826, arg_829) }; if linked_811 == nil { arg_809 = ifn_812.Invoke_O_O__O(arg_813, arg_814) } else { arg_809 = linked_811.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_810, arg_813, arg_814) }; if linked_807 == nil { arg_805 = ifn_808.Invoke_O__O(arg_809) } else { arg_805 = linked_807.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_806, arg_809) }; if linked_801 == nil { tmp21 = ifn_802.Invoke_O_O_O__O(arg_803, arg_804, arg_805) } else { tmp21 = linked_801.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_800, arg_803, arg_804, arg_805) }; jrt.NN(tmp20).Reset_O__O(tmp21); return d__4 }
//line :111:1
func A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_fn__1938000092_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :111:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Ctor_O_O_O(c__src, c__r, c__st any) { t.F_src = c__src; t.F_r = c__r; t.F_st = c__st }
//line :111:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_760 any = A_arbace_go_run_A_const_93.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var t_ any = t.F_st; t.F_st = nil; arg_763 = t_; var arg_764 any; var t__2 any = t.F_r; t.F_r = nil; arg_764 = t__2; var arg_765 any = A_arbace_go_run_A_const_94; if linked_761 == nil { tmp1 = ifn_762.Invoke_O_O_O__O(arg_763, arg_764, arg_765) } else { tmp1 = linked_761.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_760, arg_763, arg_764, arg_765) } }; return nil }(); if tmp2 != nil { if lang.ExceptionInfo_InstanceOf(tmp2) { var ex__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp2); var temp__1927000408__auto____4 any; var root_766 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_768 lang.IFn


	if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_95; var tmp4 any; var root_770 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = ex__3; if linked_771 == nil { tmp4 = ifn_772.Invoke_O__O(arg_773) } else { tmp4 = linked_771.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_770, arg_773) }; arg_769 = tmp3.Invoke_O__O(tmp4); if linked_767 == nil { temp__1927000408__auto____4 = ifn_768.Invoke_O__O(arg_769) } else { temp__1927000408__auto____4 = linked_767.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_766, arg_769) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var er__5 any = temp__1927000408__auto____4; var root_774 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, A_arbace_go_run_fail_A_fn_class); var ifn_776 lang.IFn
		if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = A_arbace_go_run_A_const_66; var arg_778 any = Lit_4; var arg_779 any; var tmp5 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_52; var tmp7 any; var t__3 any = t.F_src; t.F_src = nil; tmp7 = t__3; arg_779 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O__O(tmp7), nil, A_arbace_go_run_A_const_67.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_68.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_65.Invoke_O__O(er__5))).Ref(); if linked_775 == nil { tmp1 = ifn_776.Invoke_O_O_O__O(arg_777, arg_778, arg_779) } else { tmp1 = linked_775.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_774, arg_777, arg_778, arg_779) } } else {
//line :114:1
			panic(jrt.Thrown(ex__3)) } } else {
//line :111:1
				panic(tmp2) } }; return tmp1 }






func A_arbace_go_run_run_define__1938000091_fn__1938000094_A_New_O(p0 any) *A_arbace_go_run_run_define__1938000091_fn__1938000094_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000094_A{}; t.Ctor_O(p0); return t }
//line :118:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000094_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :118:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000094_A) Invoke_O_O__O(self, p1__1938000085_SHARP___1 any) any { var root_815 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any; var root_820 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = t.F_srcs; if linked_821 == nil { arg_818 = ifn_822.Invoke_O__O(arg_823) } else { arg_818 = linked_821.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_820, arg_823) }; var arg_819 any = p1__1938000085_SHARP___1; if linked_816 == nil { return ifn_817.Invoke_O_O__O(arg_818, arg_819) } else { return linked_816.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_815, arg_818, arg_819) } }


func A_arbace_go_run_run_init_order__1938000097_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000097_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :121:1
func (t *A_arbace_go_run_run_init_order__1938000097_A) Ctor_O_O(c__inits, c__deps any) { t.F_inits = c__inits; t.F_deps = c__deps }
//line :121:1
func (t *A_arbace_go_run_run_init_order__1938000097_A) Invoke_O__O(self any) any { { var done__1 any = lang.PersistentVector_EMPTY.Ref(); var left__2 any; var root_832 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_834 lang.IFn
											if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any; var root_836 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any; var root_840 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = t.F_inits; if linked_841 == nil { arg_839 = ifn_842.Invoke_O__O(arg_843) } else { arg_839 = linked_841.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_840, arg_843) }; if linked_837 == nil { arg_835 = ifn_838.Invoke_O__O(arg_839) } else { arg_835 = linked_837.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_836, arg_839) }; if linked_833 == nil { left__2 = ifn_834.Invoke_O__O(arg_835) } else { left__2 = linked_833.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_832, arg_835) }
//line :121:1
L1: for {

	var tmp1 any; var root_844 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = left__2; if linked_845 == nil { tmp1 = ifn_846.Invoke_O__O(arg_847) } else { tmp1 = linked_845.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_844, arg_847) }; if jrt.J2g_Truth(tmp1) { return done__1 } else { var p__3 any; var root_848 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_850 lang.IFn

		if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var root_852 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var root_856 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any; var fnbody__875 any = A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_New_O_O(done__1, t.F_deps); var tmp2 *jrt.Class; var fncls__874 *jrt.Class = A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class; if fncls__874 == nil { var fncls__874d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__875); A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class = fncls__874d; tmp2 = fncls__874d } else { tmp2 = fncls__874 }; arg_859 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__875, tmp2, nil); var arg_860 any = left__2; if linked_857 == nil { arg_855 = ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { arg_855 = linked_857.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_856, arg_859, arg_860) }; if linked_853 == nil { arg_851 = ifn_854.Invoke_O__O(arg_855) } else { arg_851 = linked_853.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_852, arg_855) }; if linked_849 == nil { p__3 = ifn_850.Invoke_O__O(arg_851) } else { p__3 = linked_849.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_848, arg_851) }
		var tmp3 any; var root_876 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = done__1; var arg_880 any; var or__1927000174__auto____4 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_880 = or__1927000174__auto____4 } else { var root_881 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_885 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = left__2; if linked_886 == nil { arg_884 = ifn_887.Invoke_O__O(arg_888) } else { arg_884 = linked_886.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_885, arg_888) }; if linked_882 == nil { arg_880 = ifn_883.Invoke_O__O(arg_884) } else { arg_880 = linked_882.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_881, arg_884) } }; if linked_877 == nil { tmp3 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { tmp3 = linked_877.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }; var tmp4 any = tmp3; var tmp5 any; var root_889 any = A_arbace_go_run_A_const_109.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = left__2; var arg_893 any; var or__1927000174__auto____4_2 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4_2) { arg_893 = or__1927000174__auto____4_2 } else { var root_894 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any; var root_898 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = left__2; if linked_899 == nil { arg_897 = ifn_900.Invoke_O__O(arg_901) } else { arg_897 = linked_899.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_898, arg_901) }; if linked_895 == nil { arg_893 = ifn_896.Invoke_O__O(arg_897) } else { arg_893 = linked_895.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_894, arg_897) } }; if linked_890 == nil { tmp5 = ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { tmp5 = linked_890.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }; done__1, left__2 = tmp4, tmp5; continue L1 } } }; /*line :121:1*/panic("j2g: unreachable") }



func A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A) Ctor_O_O(c__done, c__deps any) { t.F_done = c__done; t.F_deps = c__deps }
//line :125:1
func (t *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A) Invoke_O_O__O(self, p1__1938000086_SHARP___1 any) any { var root_861 any = A_arbace_go_run_A_const_108.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any; var root_866 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = t.F_done; if linked_867 == nil { arg_864 = ifn_868.Invoke_O__O(arg_869) } else { arg_864 = linked_867.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_866, arg_869) }; var arg_865 any; var tmp1 any; var root_870 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = t.F_deps; if linked_871 == nil { tmp1 = ifn_872.Invoke_O__O(arg_873) } else { tmp1 = linked_871.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_870, arg_873) }; arg_865 = lang.RT_Get_O_O__O_NoInit(tmp1, p1__1938000086_SHARP___1); if linked_862 == nil { return ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { return linked_862.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_861, arg_864, arg_865) } }


func A_arbace_go_run_run_load_BANG___1938000101_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_run_run_load_BANG___1938000101_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_load_BANG___1938000101_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :128:1
func (t *A_arbace_go_run_run_load_BANG___1938000101_A) Ctor_O_O_O_O_O(c__root, c__extra, c__srcs, c__index, c__define any) { t.F_root = c__root; t.F_extra = c__extra; t.F_srcs = c__srcs; t.F_index = c__index; t.F_define = c__define }
//line :128:1
func (t *A_arbace_go_run_run_load_BANG___1938000101_A) Invoke_O_O_O__O(self, path__1, seen__2 any) any {
	var tmp1 any; var or__1927000174__auto____3 any; var root_966 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any; var root_971 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = t.F_srcs; if linked_972 == nil { arg_969 = ifn_973.Invoke_O__O(arg_974) } else { arg_969 = linked_972.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_971, arg_974) }; var arg_970 any = path__1; if linked_967 == nil { or__1927000174__auto____3 = ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { or__1927000174__auto____3 = linked_967.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_975 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = path__1; if linked_976 == nil { or__1927000174__auto____4 = ifn_977.Invoke_O__O(arg_978) } else { or__1927000174__auto____4 = linked_976.(*aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_975, arg_978) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_979 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = seen__2; var arg_983 any = path__1; if linked_980 == nil { tmp1 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp1 = linked_980.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_979, arg_982, arg_983) } } }; if jrt.J2g_Truth(tmp1) { return nil } else { var temp__1927000414__auto____3 any; var tmp2 any; var root_984 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_986 lang.IFn
		if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = t.F_index; if linked_985 == nil { tmp2 = ifn_986.Invoke_O__O(arg_987) } else { tmp2 = linked_985.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_984, arg_987) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, path__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var f__4 any = temp__1927000414__auto____3; var s__5 any; var root_988 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_990 lang.IFn
			if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_77, t.F_root)); var arg_992 any = path__1; var arg_993 any; var root_995 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_996 == nil { arg_993 = ifn_997.Invoke_O__O(arg_998) } else { arg_993 = linked_996.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_995, arg_998) }; var arg_994 any = f__4; if linked_989 == nil { s__5 = ifn_990.Invoke_O_O_O_O__O(arg_991, arg_992, arg_993, arg_994) } else { s__5 = linked_989.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_988, arg_991, arg_992, arg_993, arg_994) }
//line :130:1
			var seq_1938000102__6 any; var root_1013 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1015 lang.IFn

			if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any; var root_1017 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, A_arbace_go_run_imports_of_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = s__5; if linked_1018 == nil { arg_1016 = ifn_1019.Invoke_O__O(arg_1020) } else { arg_1016 = linked_1018.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1017, arg_1020) }; if linked_1014 == nil { seq_1938000102__6 = ifn_1015.Invoke_O__O(arg_1016) } else { seq_1938000102__6 = linked_1014.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1013, arg_1016) }
//line :130:1
			var chunk_1938000103__7 any; var count_1938000104__8 int64 = 0; var i_1938000105__9 int64 = 0; L1: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000105__9, count_1938000104__8) { var p__10 any = lang.Indexed_Cast(chunk_1938000103__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000105__9)); var tmp3 lang.IFn = lang.IFn_Cast(self); var tmp4 any; var root_1037 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = seen__2; var arg_1041 any = path__1; if linked_1038 == nil { tmp4 = ifn_1039.Invoke_O_O__O(arg_1040, arg_1041) } else { tmp4 = linked_1038.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1037, arg_1040, arg_1041) }; tmp3.Invoke_O_O__O(p__10, tmp4); seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000105__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_1021 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = seq_1938000102__6; if linked_1022 == nil { temp__1927000414__auto____10 = ifn_1023.Invoke_O__O(arg_1024) } else { temp__1927000414__auto____10 = linked_1022.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1021, arg_1024) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1938000102__11 any = temp__1927000414__auto____10; var tmp5 any; var root_1025 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = seq_1938000102__11; if linked_1026 == nil { tmp5 = ifn_1027.Invoke_O__O(arg_1028) } else { tmp5 = linked_1026.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1025, arg_1028) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_1029 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = seq_1938000102__11; if linked_1030 == nil { c__1927000678__auto____12 = ifn_1031.Invoke_O__O(arg_1032) } else { c__1927000678__auto____12 = linked_1030.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1029, arg_1032) }; var tmp6 any; var root_1042 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = seq_1938000102__11; if linked_1043 == nil { tmp6 = ifn_1044.Invoke_O__O(arg_1045) } else { tmp6 = linked_1043.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1042, arg_1045) }; seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__12 any; var root_1033 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = seq_1938000102__11; if linked_1034 == nil { p__12 = ifn_1035.Invoke_O__O(arg_1036) } else { p__12 = linked_1034.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1033, arg_1036) }; var tmp7 lang.IFn = lang.IFn_Cast(self); var tmp8 any; var root_1046 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = seen__2; var arg_1050 any = path__1; if linked_1047 == nil { tmp8 = ifn_1048.Invoke_O_O__O(arg_1049, arg_1050) } else { tmp8 = linked_1047.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1046, arg_1049, arg_1050) }; tmp7.Invoke_O_O__O(p__12, tmp8); var tmp9 any; var root_1051 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = seq_1938000102__11; if linked_1052 == nil { tmp9 = ifn_1053.Invoke_O__O(arg_1054) } else { tmp9 = linked_1052.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1051, arg_1054) }; seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = tmp9, nil, 0, 0; continue L1 } } }
//line :130:1
				break L1
			}

			var tmp10 any; var root_999 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any; var root_1004 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = t.F_srcs; if linked_1005 == nil { arg_1002 = ifn_1006.Invoke_O__O(arg_1007) } else { arg_1002 = linked_1005.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1004, arg_1007) }; var arg_1003 any = path__1; if linked_1000 == nil { tmp10 = ifn_1001.Invoke_O_O__O(arg_1002, arg_1003) } else { tmp10 = linked_1000.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_999, arg_1002, arg_1003) }; if jrt.J2g_Truth(tmp10) { return nil } else { var r__6 any; var root_1008 any = A_arbace_go_run_A_const_110.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, A_arbace_go_run_check_BANG__A_fn_class); var ifn_1010 lang.IFn
				if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = s__5; var arg_1012 any = t.F_extra; if linked_1009 == nil { r__6 = ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { r__6 = linked_1009.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) }
				var root_1055 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = t.F_srcs; var arg_1059 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var arg_1060 any = path__1; var arg_1061 any = s__5; if linked_1056 == nil { ifn_1057.Invoke_O_O_O_O__O(arg_1058, arg_1059, arg_1060, arg_1061) } else { linked_1056.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1055, arg_1058, arg_1059, arg_1060, arg_1061) }
				return lang.IFn_Cast(t.F_define).Invoke_O_O__O(s__5, r__6) } } else {
//line :130:1
					return nil
				}
	}
}











func A_arbace_go_run_raw_lines_A_New() *A_arbace_go_run_raw_lines_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_go_run_raw_lines_A) Ctor() {}
//line :145:1
func (t *A_arbace_go_run_raw_lines_A) Invoke_O_O__O(self, x__0 any) any { var walk_meta__2 any; var fnbody__1114 any = A_arbace_go_run_raw_lines_walk_meta__1938000116_A_New(); var tmp1 *jrt.Class; var fncls__1113 *jrt.Class = A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class; if






	fncls__1113 == nil { var fncls__1113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, nil); A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class = fncls__1113d; tmp1 = fncls__1113d } else { tmp1 = fncls__1113 }; walk_meta__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1114, tmp1, nil); var x_SINGLEQUOTE___3 any; var tmp2 any; var root_1115 any = /*line :145:1*/A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1117 lang.IFn; if








	linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = x__0; if linked_1116 == nil { tmp2 = ifn_1117.Invoke_O__O(arg_1118) } else { tmp2 = linked_1116.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1115, arg_1118) }; if /*line :153:1*/ jrt.J2g_Truth(tmp2) {
		var root_1119 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any; var root_1124 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var arg_1128 any; var root_1129 any = A_arbace_go_run_A_const_125.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var arg_1133 any = x__0; if linked_1130 == nil { arg_1128 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { arg_1128 = linked_1130.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }; if linked_1125 == nil { arg_1122 = ifn_1126.Invoke_O_O__O(arg_1127, arg_1128) } else { arg_1122 = linked_1125.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1124, arg_1127, arg_1128) }; var arg_1123 any; var G__1938000119__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000119__3_, nil) { arg_1123 = nil } else { arg_1123 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000119__3_) }; if linked_1120 == nil { x_SINGLEQUOTE___3 = ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { x_SINGLEQUOTE___3 = linked_1120.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) } } else {
//line :153:1
			var tmp3 any; var root_1134 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1136 lang.IFn

			if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = x__0; if linked_1135 == nil { tmp3 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp3 = linked_1135.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1134, arg_1137) }
//line :153:1
			if jrt.J2g_Truth(tmp3) {

				var root_1138 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any; var root_1143 any = A_arbace_go_run_A_const_126.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var arg_1147 any = x__0; if linked_1144 == nil { arg_1141 = ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { arg_1141 = linked_1144.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) }; var arg_1142 any; var G__1938000120__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000120__3_, nil) { arg_1142 = nil } else { arg_1142 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000120__3_) }; if linked_1139 == nil { x_SINGLEQUOTE___3 = ifn_1140.Invoke_O_O__O(arg_1141, arg_1142) } else { x_SINGLEQUOTE___3 = linked_1139.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1138, arg_1141, arg_1142) } } else {
//line :153:1
					var tmp4 any; var root_1148 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1150 lang.IFn


					if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = x__0; if linked_1149 == nil { tmp4 = ifn_1150.Invoke_O__O(arg_1151) } else { tmp4 = linked_1149.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1148, arg_1151) }
//line :153:1
					if jrt.J2g_Truth(tmp4) {


						var root_1152 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any; var root_1157 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1161 any; var root_1163 any = A_arbace_go_run_A_const_125.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var fnbody__1176 any = A_arbace_go_run_raw_lines_fn__1938000122_A_New(); var tmp5 *jrt.Class; var fncls__1175 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class; if fncls__1175 == nil { var fncls__1175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class = fncls__1175d; tmp5 = fncls__1175d } else { tmp5 = fncls__1175 }; arg_1166 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1176, tmp5, nil); if linked_1164 == nil { arg_1161 = ifn_1165.Invoke_O__O(arg_1166) } else { arg_1161 = linked_1164.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1163, arg_1166) }; var arg_1162 any = x__0; if linked_1158 == nil { arg_1155 = ifn_1159.Invoke_O_O_O__O(arg_1160, arg_1161, arg_1162) } else { arg_1155 = linked_1158.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1157, arg_1160, arg_1161, arg_1162) }; var arg_1156 any; var G__1938000127__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000127__3_, nil) { arg_1156 = nil } else { arg_1156 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000127__3_) }; if linked_1153 == nil { x_SINGLEQUOTE___3 = ifn_1154.Invoke_O_O__O(arg_1155, arg_1156) } else { x_SINGLEQUOTE___3 = linked_1153.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1152, arg_1155, arg_1156) } } else {
//line :153:1
							var tmp6 any; var root_1177 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1179 lang.IFn



							if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = x__0; if linked_1178 == nil { tmp6 = ifn_1179.Invoke_O__O(arg_1180) } else { tmp6 = linked_1178.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1177, arg_1180) }
//line :153:1
							if jrt.J2g_Truth(tmp6) {



								var root_1181 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = x__0; var arg_1185 any; var G__1938000128__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000128__3_, nil) { arg_1185 = nil } else { arg_1185 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000128__3_) }; if linked_1182 == nil { x_SINGLEQUOTE___3 = ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { x_SINGLEQUOTE___3 = linked_1182.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) } } else {
//line :153:1
									if A_arbace_go_run_A_const_31 != nil { x_SINGLEQUOTE___3 = x__0 } else { x_SINGLEQUOTE___3 = nil } } } } }; var m__4 any; if





	lang.IObj_InstanceOf(x_SINGLEQUOTE___3) { m__4 = lang.RT_Meta_O__IPersistentMap_NoInit(x_SINGLEQUOTE___3) } else { m__4 = nil }; var pos__5 any = /*line :145:1*/A_arbace_go_run_A_const_129.Invoke_O__O(m__4); var lines__6 any; var fnbody__1202 any = A_arbace_go_run_raw_lines_lines__1938000129_A_New(); var tmp7 *jrt.Class; var fncls__1201 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class; if


















	fncls__1201 == nil { var fncls__1201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class = fncls__1201d; tmp7 = fncls__1201d } else { tmp7 = fncls__1201 }; lines__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1202, tmp7, nil); var l__7 any; var or__1927000174__auto____7 any; var tmp8 any; var root_1203 any = /*line :145:1*/A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1205 lang.IFn; if



















	linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = x_SINGLEQUOTE___3; if linked_1204 == nil { tmp8 = ifn_1205.Invoke_O__O(arg_1206) } else { tmp8 = linked_1204.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1203, arg_1206) }; if jrt.J2g_Truth(tmp8) { var G__1938000133__7_ any; var root_1207 any = A_arbace_go_run_A_const_75.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1209 lang.IFn
		if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any; var tmp9 lang.IFn = lang.IFn_Cast(lines__6); var tmp10 any; var root_1212 any = A_arbace_go_run_A_const_131.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = A_arbace_go_run_A_const_132.Invoke_O__O(m__4); if linked_1213 == nil { tmp10 = ifn_1214.Invoke_O__O(arg_1215) } else { tmp10 = linked_1213.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1212, arg_1215) }; arg_1210 = tmp9.Invoke_O__O(tmp10); var arg_1211 any; var root_1216 any = A_arbace_go_run_A_const_130.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1218 lang.IFn
		if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any; var fnbody__1222 any = A_arbace_go_run_raw_lines_fn__1938000134_A_New(); var tmp11 *jrt.Class; var fncls__1221 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class; if fncls__1221 == nil { var fncls__1221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class = fncls__1221d; tmp11 = fncls__1221d } else { tmp11 = fncls__1221 }; arg_1219 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1222, tmp11, nil); var arg_1220 any = x_SINGLEQUOTE___3; if linked_1217 == nil { arg_1211 = ifn_1218.Invoke_O_O__O(arg_1219, arg_1220) } else { arg_1211 = linked_1217.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1216, arg_1219, arg_1220) }
//line :166:1
		if linked_1208 == nil { G__1938000133__7_ = ifn_1209.Invoke_O_O__O(arg_1210, arg_1211) } else { G__1938000133__7_ = linked_1208.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1207, arg_1210, arg_1211) }
//line :165:1
		var G__1938000133__8_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__1938000133__7_, nil) { G__1938000133__8_ = nil } else { var root_1223 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any = G__1938000133__7_; if linked_1224 == nil { G__1938000133__8_ = ifn_1225.Invoke_O__O(arg_1226) } else { G__1938000133__8_ = linked_1224.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1223, arg_1226) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000133__8_, nil) { or__1927000174__auto____7 = nil } else {

			var root_1227 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = A_arbace_go_run_A_const_133.GetRawRoot__O(); var arg_1231 any = G__1938000133__8_; if linked_1228 == nil { or__1927000174__auto____7 = ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { or__1927000174__auto____7 = linked_1228.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) } } } else {
//line :165:1
				or__1927000174__auto____7 = nil }; if jrt.J2g_Truth(or__1927000174__auto____7) { l__7 = or__1927000174__auto____7 } else {



					var tmp12 any; var root_1232 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = pos__5; if linked_1233 == nil { tmp12 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp12 = linked_1233.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1232, arg_1235) }; if jrt.J2g_Truth(tmp12) { var G__1938000136__8_ any; var root_1236 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = A_arbace_go_run_A_const_134.GetRawRoot__O(); var arg_1240 any = pos__5; var arg_1241 any = A_arbace_go_run_A_const_135; if linked_1237 == nil { G__1938000136__8_ = ifn_1238.Invoke_O_O_O__O(arg_1239, arg_1240, arg_1241) } else { G__1938000136__8_ = linked_1237.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1236, arg_1239, arg_1240, arg_1241) }; var G__1938000136__9_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__8_, nil) { G__1938000136__9_ = nil } else { var root_1242 any = A_arbace_go_run_A_const_131.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = G__1938000136__8_; if linked_1243 == nil { G__1938000136__9_ = ifn_1244.Invoke_O__O(arg_1245) } else { G__1938000136__9_ = linked_1243.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1242, arg_1245) } }; var G__1938000136__10_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__9_, nil) { G__1938000136__10_ = nil } else { G__1938000136__10_ = lang.IFn_Cast(lines__6).Invoke_O__O(G__1938000136__9_) }; var G__1938000136__11_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__10_, nil) { G__1938000136__11_ = nil } else { var root_1246 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = G__1938000136__10_; if linked_1247 == nil { G__1938000136__11_ = ifn_1248.Invoke_O__O(arg_1249) } else { G__1938000136__11_ = linked_1247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1246, arg_1249) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__11_, nil) { l__7 = nil } else { var root_1250 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = A_arbace_go_run_A_const_133.GetRawRoot__O(); var arg_1254 any = G__1938000136__11_; if linked_1251 == nil { l__7 = ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { l__7 = linked_1251.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) } } } else { l__7 = nil } }; var end__8 any; var tmp13 any; var root_1255 any = /*line :145:1*/A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1257 lang.IFn; if


























	linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = pos__5; if linked_1256 == nil { tmp13 = ifn_1257.Invoke_O__O(arg_1258) } else { tmp13 = linked_1256.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1255, arg_1258) }; if jrt.J2g_Truth(tmp13) { var root_1259 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = A_arbace_go_run_A_const_136.Invoke_O__O(pos__5); if linked_1260 == nil { end__8 = ifn_1261.Invoke_O__O(arg_1262) } else { end__8 = linked_1260.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1259, arg_1262) } } else { end__8 = nil }; var apos__9 any = /*line :145:1*/A_arbace_go_run_A_const_132.Invoke_O__O(m__4); var tmp14 any; var or__1927000174__auto____10 any = l__7; if




























	jrt.J2g_Truth(or__1927000174__auto____10) { tmp14 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 any = end__8; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp14 = or__1927000174__auto____11 } else { var root_1263 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = apos__9; if linked_1264 == nil { tmp14 = ifn_1265.Invoke_O__O(arg_1266) } else { tmp14 = linked_1264.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1263, arg_1266) } } }; if jrt.J2g_Truth(tmp14) {
		var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_137.GetRawRoot__O()); var tmp16 *lang.Compiler_AOTFn; var fnbody__1385 any = A_arbace_go_run_raw_lines_fn__1938000137_A_New_O_O_O(l__7, apos__9, end__8); var tmp17 *jrt.Class; var fncls__1384 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class; if fncls__1384 == nil { var fncls__1384d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1385); A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class = fncls__1384d; tmp17 = fncls__1384d } else { tmp17 = fncls__1384 }; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1385, tmp17, nil); return tmp15.Invoke_O_O__O(x_SINGLEQUOTE___3, tmp16.Ref()) } else {
//line :174:1
			return x_SINGLEQUOTE___3 } }
//line :152:1
func A_arbace_go_run_raw_lines_walk_meta__1938000116_A_New() *A_arbace_go_run_raw_lines_walk_meta__1938000116_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_walk_meta__1938000116_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000116_A) Ctor() {}
//line :152:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000116_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000117__2_ any = m__1; var tmp1 any; var root_1102 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = m__1; var arg_1106 any = A_arbace_go_run_A_const_118; if linked_1103 == nil { tmp1 = ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { tmp1 = linked_1103.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) }; if jrt.J2g_Truth(tmp1) { var root_1107 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = G__1938000117__2_; var arg_1111 any = A_arbace_go_run_A_const_118; var arg_1112 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); if linked_1108 == nil { return ifn_1109.Invoke_O_O_O__O(arg_1110, arg_1111, arg_1112) } else { return linked_1108.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1107, arg_1110, arg_1111, arg_1112) } } else { return G__1938000117__2_ } }



func A_arbace_go_run_raw_lines_fn__1938000122_A_New() *A_arbace_go_run_raw_lines_fn__1938000122_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000122_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_go_run_raw_lines_fn__1938000122_A) Ctor() {}
//line :156:1
func (t *A_arbace_go_run_raw_lines_fn__1938000122_A) Invoke_O_O__O(self, p__1938000121__1 any) any { var vec__1938000123__2 any = p__1938000121__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000123__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000123__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1167 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = k__3; if linked_1168 == nil { tmp1 = ifn_1169.Invoke_O__O(arg_1170) } else { tmp1 = linked_1168.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1167, arg_1170) }; var tmp2 any = tmp1; var tmp3 any; var root_1171 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = v__4; if linked_1172 == nil { tmp3 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp3 = linked_1172.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1171, arg_1174) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }







func A_arbace_go_run_raw_lines_lines__1938000129_A_New() *A_arbace_go_run_raw_lines_lines__1938000129_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000129_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_A) Ctor() {}
//line :164:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_A) Invoke_O_O__O(self, ps__1 any) any { var root_1186 any = A_arbace_go_run_A_const_130.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var fnbody__1200 any = A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_New(); var tmp1 *jrt.Class; var fncls__1199 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class; if fncls__1199 == nil { var fncls__1199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class = fncls__1199d; tmp1 = fncls__1199d } else { tmp1 = fncls__1199 }; arg_1189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1200, tmp1, nil); var arg_1190 any = ps__1; if linked_1187 == nil { return ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { return linked_1187.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) } }
//line :164:1
func A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_New() *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A) Ctor() {}
//line :164:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A) Invoke_O_O__O(self, p1__1938000114_SHARP___1 any) any { var tmp1 any; var root_1191 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = p1__1938000114_SHARP___1; if linked_1192 == nil { tmp1 = ifn_1193.Invoke_O__O(arg_1194) } else { tmp1 = linked_1192.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1191, arg_1194) }; if jrt.J2g_Truth(tmp1) { var root_1195 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = p1__1938000114_SHARP___1; if linked_1196 == nil { return ifn_1197.Invoke_O__O(arg_1198) } else { return linked_1196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1195, arg_1198) } } else { return nil } }


func A_arbace_go_run_raw_lines_fn__1938000134_A_New() *A_arbace_go_run_raw_lines_fn__1938000134_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000134_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_go_run_raw_lines_fn__1938000134_A) Ctor() {}
//line :167:1
func (t *A_arbace_go_run_raw_lines_fn__1938000134_A) Invoke_O_O__O(self, p1__1938000115_SHARP___1 any) any { if lang.IMeta_InstanceOf(p1__1938000115_SHARP___1) { var tmp1 *lang.Keyword = A_arbace_go_run_A_const_68; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1938000115_SHARP___1)) } else { return nil } }







func A_arbace_go_run_raw_lines_fn__1938000137_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_raw_lines_fn__1938000137_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :175:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_A) Ctor_O_O_O(c__l, c__apos, c__end any) { t.F_l = c__l; t.F_apos = c__apos; t.F_end = c__end }
//line :175:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000138__2_ any = m__1; var G__1938000138__3_ any; if jrt.J2g_Truth(t.F_l) {
											var root_1272 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = G__1938000138__2_; var arg_1276 any = A_arbace_go_run_A_const_68; var arg_1277 any = t.F_l; if linked_1273 == nil { G__1938000138__3_ = ifn_1274.Invoke_O_O_O__O(arg_1275, arg_1276, arg_1277) } else { G__1938000138__3_ = linked_1273.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1272, arg_1275, arg_1276, arg_1277) } } else {
//line :175:1
		G__1938000138__3_ = G__1938000138__2_ }; var G__1938000138__4_ any; if jrt.J2g_Truth(t.F_end) {

			var root_1278 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = G__1938000138__3_; var arg_1282 any = A_arbace_go_run_A_const_138; var arg_1283 any = t.F_end; if linked_1279 == nil { G__1938000138__4_ = ifn_1280.Invoke_O_O_O__O(arg_1281, arg_1282, arg_1283) } else { G__1938000138__4_ = linked_1279.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1278, arg_1281, arg_1282, arg_1283) } } else {
//line :175:1
				G__1938000138__4_ = G__1938000138__3_ }; var tmp1 any; var root_1284 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1286 lang.IFn; if


	linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = t.F_apos; if linked_1285 == nil { tmp1 = ifn_1286.Invoke_O__O(arg_1287) } else { tmp1 = linked_1285.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1284, arg_1287) }; if /*line :175:1*/ jrt.J2g_Truth(tmp1) {


		var root_1288 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = G__1938000138__4_; var arg_1292 any = A_arbace_go_run_A_const_139; var arg_1293 any; var root_1294 any = A_arbace_go_run_A_const_89.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any; var iter__1927001039__auto____5 any; var fnbody__1379 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_New(); var tmp2 *jrt.Class; var fncls__1378 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class; if fncls__1378 == nil { var fncls__1378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class = fncls__1378d; tmp2 = fncls__1378d } else { tmp2 = fncls__1378 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1379, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp4 any; var root_1380 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = t.F_apos; if linked_1381 == nil { tmp4 = ifn_1382.Invoke_O__O(arg_1383) } else { tmp4 = linked_1381.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1380, arg_1383) }; arg_1297 = tmp3.Invoke_O__O(tmp4); if linked_1295 == nil { arg_1293 = ifn_1296.Invoke_O__O(arg_1297) } else { arg_1293 = linked_1295.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1294, arg_1297) }; if linked_1289 == nil { return ifn_1290.Invoke_O_O_O__O(arg_1291, arg_1292, arg_1293) } else { return linked_1289.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1288, arg_1291, arg_1292, arg_1293) } } else {
//line :175:1
			return G__1938000138__4_ } }


func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_New() *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A) Ctor() {}
//line :178:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A) Invoke_O_O__O(self, s__1938000140__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1377 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_New_O_O(self, s__1938000140__1); var tmp2 *jrt.Class; var fncls__1376 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class; if fncls__1376 == nil { var fncls__1376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1377); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class = fncls__1376d; tmp2 = fncls__1376d } else { tmp2 = fncls__1376 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1377, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :178:1
func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_New_O_O(p0, p1 any) *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A) Ctor_O_O(c__iter__1938000139, c__s__1938000140 any) { t.F_iter__1938000139 = c__iter__1938000139; t.F_s__1938000140 = c__s__1938000140 }
//line :178:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A) Invoke_O__O(self any) any { { var s__1938000140__1 any; var t_ any = t.F_s__1938000140; t.F_s__1938000140 = nil; s__1938000140__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1298 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = s__1938000140__1; if linked_1299 == nil { temp__1927000414__auto____2 = ifn_1300.Invoke_O__O(arg_1301) } else { temp__1927000414__auto____2 = linked_1299.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1298, arg_1301) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000140__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1302 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = s__1938000140__3; if linked_1303 == nil { tmp1 = ifn_1304.Invoke_O__O(arg_1305) } else { tmp1 = linked_1303.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1302, arg_1305) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1306 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = s__1938000140__3; if linked_1307 == nil { c__1927001037__auto____4 = ifn_1308.Invoke_O__O(arg_1309) } else { c__1927001037__auto____4 = linked_1307.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1306, arg_1309) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000142__6 any; var root_1310 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1311 == nil { b__1938000142__6 = ifn_1312.Invoke_O__O(arg_1313) } else { b__1938000142__6 = linked_1311.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1310, arg_1313) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1328 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_New_O_I_O(b__1938000142__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1327 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class; if fncls__1327 == nil { var fncls__1327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__1328); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class = fncls__1327d; tmp3 = fncls__1327d } else { tmp3 = fncls__1327 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1328, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1329 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any; var root_1334 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = b__1938000142__6; if linked_1335 == nil { arg_1332 = ifn_1336.Invoke_O__O(arg_1337) } else { arg_1332 = linked_1335.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1334, arg_1337) }; var arg_1333 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000139); var tmp5 any; var root_1338 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = s__1938000140__3; if linked_1339 == nil { tmp5 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp5 = linked_1339.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1338, arg_1341) }; arg_1333 = tmp4.Invoke_O__O(tmp5); if linked_1330 == nil { return ifn_1331.Invoke_O_O__O(arg_1332, arg_1333) } else { return linked_1330.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1329, arg_1332, arg_1333) } } else { var root_1342 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any; var root_1347 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = b__1938000142__6; if linked_1348 == nil { arg_1345 = ifn_1349.Invoke_O__O(arg_1350) } else { arg_1345 = linked_1348.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1347, arg_1350) }; var arg_1346 any; if linked_1343 == nil { return ifn_1344.Invoke_O_O__O(arg_1345, arg_1346) } else { return linked_1343.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1342, arg_1345, arg_1346) } } } else { var vec__1938000150__4 any; var root_1351 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = s__1938000140__3; if linked_1352 == nil { vec__1938000150__4 = ifn_1353.Invoke_O__O(arg_1354) } else { vec__1938000150__4 = linked_1352.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1351, arg_1354) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000150__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000150__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_1355 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = p__6; if linked_1356 == nil { tmp6 = ifn_1357.Invoke_O__O(arg_1358) } else { tmp6 = linked_1356.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1355, arg_1358) }; if jrt.J2g_Truth(tmp6) { var root_1359 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var tmp7 any; var root_1364 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = p__6; if linked_1365 == nil { tmp7 = ifn_1366.Invoke_O__O(arg_1367) } else { tmp7 = linked_1365.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1364, arg_1367) }; arg_1362 = lang.Tuple_Create_O_O__IPersistentVector(i__5, tmp7); var arg_1363 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000139); var tmp9 any; var root_1368 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = s__1938000140__3; if linked_1369 == nil { tmp9 = ifn_1370.Invoke_O__O(arg_1371) } else { tmp9 = linked_1369.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1368, arg_1371) }; arg_1363 = tmp8.Invoke_O__O(tmp9); if linked_1360 == nil { return ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { return linked_1360.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) } } else { var tmp10 any; var root_1372 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = s__1938000140__3; if linked_1373 == nil { tmp10 = ifn_1374.Invoke_O__O(arg_1375) } else { tmp10 = linked_1373.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1372, arg_1375) }; s__1938000140__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :178:1
func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :178:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A) Ctor_O_I_O(c__b__1938000142 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000142 = c__b__1938000142; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :178:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A) Invoke_O__O(self any) any { { var i__1938000141__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000141__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1938000146__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000141__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000146__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000146__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_1314 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = p__4; if linked_1315 == nil { tmp2 = ifn_1316.Invoke_O__O(arg_1317) } else { tmp2 = linked_1315.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1314, arg_1317) }; if jrt.J2g_Truth(tmp2) { var root_1318 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = t.F_b__1938000142; var arg_1322 any; var tmp3 any; var root_1323 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = p__4; if linked_1324 == nil { tmp3 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp3 = linked_1324.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1323, arg_1326) }; arg_1322 = lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp3); if linked_1319 == nil { ifn_1320.Invoke_O_O__O(arg_1321, arg_1322) } else { linked_1319.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1318, arg_1321, arg_1322) }; i__1938000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000141__1); continue L1 } else { i__1938000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000141__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_run_line_map_A_New() *A_arbace_go_run_line_map_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_run_line_map_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_run_line_map_A) Invoke_O_O__O(self, path__0 any) any { var ls__2 any; var root_1386 any = A_arbace_go_run_A_const_89.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1388 lang.IFn; if








	linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any; var root_1390 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = lang.IFn_Cast(A_arbace_go_run_A_const_140.GetRawRoot__O()).Invoke_O__O(path__0); if linked_1391 == nil { arg_1389 = ifn_1392.Invoke_O__O(arg_1393) } else { arg_1389 = linked_1391.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_1390, arg_1393) }; if linked_1387 == nil { ls__2 = ifn_1388.Invoke_O__O(arg_1389) } else { ls__2 = linked_1387.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1386, arg_1389) }; var tmp1 any; var and__1927000168__auto____3 any; var root_1398 any =
	A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any; var fnbody__1409 any = A_arbace_go_run_line_map_fn__1938000160_A_New(); var tmp2 *jrt.Class; var fncls__1408 *jrt.Class = A_arbace_go_run_line_map_fn__1938000160_A_fn_class; if fncls__1408 == nil { var fncls__1408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); A_arbace_go_run_line_map_fn__1938000160_A_fn_class = fncls__1408d; tmp2 = fncls__1408d } else { tmp2 = fncls__1408 }; arg_1401 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1409, tmp2, nil); var arg_1402 any = ls__2; if linked_1399 == nil { and__1927000168__auto____3 = ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { and__1927000168__auto____3 = linked_1399.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
		var root_1410 any = A_arbace_go_run_A_const_141.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any; var root_1414 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any; var fnbody__1425 any = A_arbace_go_run_line_map_fn__1938000162_A_New(); var tmp3 *jrt.Class; var fncls__1424 *jrt.Class = A_arbace_go_run_line_map_fn__1938000162_A_fn_class; if fncls__1424 == nil { var fncls__1424d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_go_run_line_map_fn__1938000162_A_fn_class = fncls__1424d; tmp3 = fncls__1424d } else { tmp3 = fncls__1424 }; arg_1417 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1425, tmp3, nil); var arg_1418 any = ls__2; if linked_1415 == nil { arg_1413 = ifn_1416.Invoke_O_O__O(arg_1417, arg_1418) } else { arg_1413 = linked_1415.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1414, arg_1417, arg_1418) }; if linked_1411 == nil { tmp1 = ifn_1412.Invoke_O__O(arg_1413) } else { tmp1 = linked_1411.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1410, arg_1413) } } else {
//line :191:1
			tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var ds__3 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__1468 any = A_arbace_go_run_line_map_fn__1938000164_A_New_O(ls__2); var tmp5 *jrt.Class
				var fncls__1467 /*line :191:1*/*jrt.Class = A_arbace_go_run_line_map_fn__1938000164_A_fn_class


				if fncls__1467 == nil { var fncls__1467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__1468); A_arbace_go_run_line_map_fn__1938000164_A_fn_class = fncls__1467d; tmp5 = fncls__1467d } else { tmp5 = fncls__1467 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1468, tmp5, nil); ds__3 = Up_Compiler_AOTFn_IFn(tmp4).Invoke__O()












				var tmp6 any; var root_1469 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = ds__3; if linked_1470 == nil { tmp6 = ifn_1471.Invoke_O__O(arg_1472) } else { tmp6 = linked_1470.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1469, arg_1472) }; if jrt.J2g_Truth(tmp6) {
					var fnbody__1489 any = A_arbace_go_run_line_map_fn__1938000172_A_New_O(ds__3); var tmp7 *jrt.Class; var fncls__1488 *jrt.Class = A_arbace_go_run_line_map_fn__1938000172_A_fn_class; if fncls__1488 == nil { var fncls__1488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__1489); A_arbace_go_run_line_map_fn__1938000172_A_fn_class = fncls__1488d; tmp7 = fncls__1488d } else { tmp7 = fncls__1488 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1489, tmp7, nil) } else {
//line :207:1
						return nil } } else {
//line :191:1
							return nil } }
//line :191:1
func A_arbace_go_run_line_map_fn__1938000160_A_New() *A_arbace_go_run_line_map_fn__1938000160_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000160_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_go_run_line_map_fn__1938000160_A) Ctor() {}
//line :191:1
func (t *A_arbace_go_run_line_map_fn__1938000160_A) Invoke_O_O__O(self, p1__1938000157_SHARP___1 any) any { var root_1403 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = p1__1938000157_SHARP___1; var arg_1407 any = Lit_65; if linked_1404 == nil { return ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { return linked_1404.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) } }
func A_arbace_go_run_line_map_fn__1938000162_A_New() *A_arbace_go_run_line_map_fn__1938000162_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000162_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_go_run_line_map_fn__1938000162_A) Ctor() {}
//line :192:1
func (t *A_arbace_go_run_line_map_fn__1938000162_A) Invoke_O_O__O(self, p1__1938000158_SHARP___1 any) any { var root_1419 any = A_arbace_go_run_A_const_142.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = p1__1938000158_SHARP___1; var arg_1423 any = Lit_66; if linked_1420 == nil { return ifn_1421.Invoke_O_O__O(arg_1422, arg_1423) } else { return linked_1420.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1419, arg_1422, arg_1423) } }

func A_arbace_go_run_line_map_fn__1938000164_A_New_O(p0 any) *A_arbace_go_run_line_map_fn__1938000164_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000164_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_go_run_line_map_fn__1938000164_A) Ctor_O(c__ls any) { t.F_ls = c__ls }
//line :194:1
func (t *A_arbace_go_run_line_map_fn__1938000164_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var prev__2 any; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										if lang.Util_Equiv_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_ls))) { return acc__3 } else { var tmp1 any = t.F_ls; var l__4 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)); var d__5 any; var tmp2 any; var root_1426 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1428 lang.IFn


		if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = l__4; var arg_1430 any = Lit_65; if linked_1427 == nil { tmp2 = ifn_1428.Invoke_O_O__O(arg_1429, arg_1430) } else { tmp2 = linked_1427.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1426, arg_1429, arg_1430) }; if jrt.J2g_Truth(tmp2) { var text__5 any; var root_1431 any = A_arbace_go_run_A_const_143.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1433 lang.IFn
			if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = l__4; var arg_1435 any = A_arbace_go_run_A_const_144; if linked_1432 == nil { text__5 = ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { text__5 = linked_1432.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) }
//line :198:1
			var or__1927000174__auto____6 any; var temp__1927000414__auto____6 any; var root_1436 any = A_arbace_go_run_A_const_145.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1438 lang.IFn

			if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = A_arbace_go_run_A_const_146; var arg_1440 any = text__5; if linked_1437 == nil { temp__1927000414__auto____6 = ifn_1438.Invoke_O_O__O(arg_1439, arg_1440) } else { temp__1927000414__auto____6 = linked_1437.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1436, arg_1439, arg_1440) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var vec__1938000165__7 any = temp__1927000414__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000165__7, lang.RT_IntCast_J__I_NoInit(0), nil); var f__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000165__7, lang.RT_IntCast_J__I_NoInit(1), nil); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000165__7, lang.RT_IntCast_J__I_NoInit(2), nil); var _c__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000165__7, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp3 any; _ = ___8; _ = _c__11
				if lang.Util_Equiv_O_O__Z_NoInit(Lit_22, f__9) { tmp3 = prev__2 } else { tmp3 = f__9 }
//line :200:1
				or__1927000174__auto____6 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__10))).Ref()) } else { or__1927000174__auto____6 = nil }; if jrt.J2g_Truth(or__1927000174__auto____6) { d__5 = or__1927000174__auto____6 } else { var temp__1927000414__auto____7 any; var root_1441 any = A_arbace_go_run_A_const_145.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1443 lang.IFn

					if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = A_arbace_go_run_A_const_147; var arg_1445 any = text__5; if linked_1442 == nil { temp__1927000414__auto____7 = ifn_1443.Invoke_O_O__O(arg_1444, arg_1445) } else { temp__1927000414__auto____7 = linked_1442.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1441, arg_1444, arg_1445) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var vec__1938000168__8 any = temp__1927000414__auto____7; var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000168__8, lang.RT_IntCast_J__I_NoInit(0), nil); var f__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000168__8, lang.RT_IntCast_J__I_NoInit(1), nil); var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000168__8, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___9; d__5 = lang.Tuple_Create_O_O__IPersistentVector(f__10, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__11))).Ref()) } else { d__5 = nil } } } else {
//line :198:1
						d__5 = nil
					}




		var tmp4 any; var and__1927000168__auto____6 any = d__5; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp5 any; var root_1446 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = d__5; if linked_1447 == nil { tmp5 = ifn_1448.Invoke_O__O(arg_1449) } else { tmp5 = linked_1447.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1446, arg_1449) }; tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp5))).Ref() } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) {
			var tmp6 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp7 any; var root_1450 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = d__5; if linked_1451 == nil { tmp7 = ifn_1452.Invoke_O__O(arg_1453) } else { tmp7 = linked_1451.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1450, arg_1453) }; var tmp8 any = tmp7; var tmp9 any; var root_1454 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = acc__3; var arg_1458 any; var tmp10 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(i__1)).Ref(); var tmp11 any; var root_1459 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = d__5; if linked_1460 == nil { tmp11 = ifn_1461.Invoke_O__O(arg_1462) } else { tmp11 = linked_1460.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1459, arg_1462) }; var tmp12 any = tmp11; var tmp13 any; var root_1463 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = d__5; if linked_1464 == nil { tmp13 = ifn_1465.Invoke_O__O(arg_1466) } else { tmp13 = linked_1464.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1463, arg_1466) }; arg_1458 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, tmp12, tmp13); if linked_1455 == nil { tmp9 = ifn_1456.Invoke_O_O__O(arg_1457, arg_1458) } else { tmp9 = linked_1455.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1454, arg_1457, arg_1458) }; i__1, prev__2, acc__3 = tmp6, tmp8, tmp9; continue L1 } else {
				i__1, prev__2, acc__3 = lang.Numbers_Inc_J__J_NoInit(i__1), prev__2, acc__3; continue L1 } } } }; /*line :194:1*/panic("j2g: unreachable") }













func A_arbace_go_run_line_map_fn__1938000172_A_New_O(p0 any) *A_arbace_go_run_line_map_fn__1938000172_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000172_A{}; t.Ctor_O(p0); return t }
//line :208:1
func (t *A_arbace_go_run_line_map_fn__1938000172_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :208:1
func (t *A_arbace_go_run_line_map_fn__1938000172_A) InvokePrim_O_O_J__O(self, file__1 any, line__2 int64) any { var temp__1927000408__auto____3 any; var root_1473 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_1475 lang.IFn; if
														linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any; var root_1477 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any; var fnbody__1487 any = A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A_New_J(line__2); var tmp1 *jrt.Class; var fncls__1486 *jrt.Class = A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A_fn_class; if fncls__1486 == nil { var fncls__1486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__1487); A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A_fn_class = fncls__1486d; tmp1 = fncls__1486d } else { tmp1 = fncls__1486 }; arg_1480 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1487, tmp1, nil); var arg_1481 any = t.F_ds; if linked_1478 == nil { arg_1476 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { arg_1476 = linked_1478.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) }; if linked_1474 == nil { temp__1927000408__auto____3 = ifn_1475.Invoke_O__O(arg_1476) } else { temp__1927000408__auto____3 = linked_1474.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_1473, arg_1476) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1938000175__4 any = temp__1927000408__auto____3; var dl__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000175__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000175__4, lang.RT_IntCast_J__I_NoInit(1), nil); var n__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000175__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 any; var or__1927000174__auto____8 any = f__6
															if jrt.J2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else { tmp2 = file__1 }
//line :209:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(n__7), lang.Numbers_Minus_J_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(line__2, lang.RT_LongCast_O__J_NoInit(dl__5)), 1))).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(file__1, jrt.Long_ValueOf_J__Long_NoInit(line__2).Ref()) } }
//line :208:1
func (t *A_arbace_go_run_line_map_fn__1938000172_A) Invoke_O_O_O__O(self, file__1, p_line__2 any) any { return t.InvokePrim_O_O_J__O(self, file__1, lang.RT_LongCast_O__J_NoInit(p_line__2)) }
func A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A_New_J(p0 int64) *A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A{}; t.Ctor_J(p0); return t }
//line :209:1
func (t *A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A) Ctor_J(c__line int64) { t.F_line = c__line }
//line :209:1
func (t *A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A) Invoke_O_O__O(self, p1__1938000159_SHARP___1 any) any { var tmp1 int64 = t.F_line; var tmp2 any; var root_1482 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = p1__1938000159_SHARP___1; if linked_1483 == nil { tmp2 = ifn_1484.Invoke_O__O(arg_1485) } else { tmp2 = linked_1483.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1482, arg_1485) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gt_J_J__Z_NoInit(tmp1, lang.RT_LongCast_O__J_NoInit(tmp2))).Ref() }



func A_arbace_go_run_errorcheck_A_New() *A_arbace_go_run_errorcheck_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_go_run_errorcheck_A) Ctor() {}
//line :213:1
func (t *A_arbace_go_run_errorcheck_A) Invoke_O_O_O_O_O_O_O__O(self, root__0, pf__1, lang__2, max_errors__3, raw__4, front__5 any) any { var src__7 any; var G__1938000185__7_ any; var root_1490 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_1492 lang.IFn; if
















	linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_77, root__0)); var arg_1494 any; var arg_1495 any; var root_1497 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_1498 == nil { arg_1495 = ifn_1499.Invoke_O__O(arg_1500) } else { arg_1495 = linked_1498.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1497, arg_1500) }; var arg_1496 any = pf__1; if linked_1491 == nil { G__1938000185__7_ = ifn_1492.Invoke_O_O_O_O__O(arg_1493, arg_1494, arg_1495, arg_1496) } else { G__1938000185__7_ = linked_1491.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_1490, arg_1493, arg_1494, arg_1495, arg_1496) }; var G__1938000185__8_ any; if jrt.J2g_Truth(lang__2) {
		var root_1501 any = A_arbace_go_run_A_const_149.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = G__1938000185__7_; var arg_1505 any = A_arbace_go_run_A_const_150; var arg_1506 any = lang__2; if linked_1502 == nil { G__1938000185__8_ = ifn_1503.Invoke_O_O_O__O(arg_1504, arg_1505, arg_1506) } else { G__1938000185__8_ = linked_1502.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1501, arg_1504, arg_1505, arg_1506) } } else {
//line :230:1
			G__1938000185__8_ = G__1938000185__7_ }; if jrt.J2g_Truth(raw__4) {





				var root_1507 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any; var root_1513 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1515 lang.IFn
//line :232:1
				if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = G__1938000185__8_; var arg_1517 any = A_arbace_go_run_A_const_53; var arg_1518 any; var fnbody__1557 any = A_arbace_go_run_errorcheck_fn__1938000186_A_New(); var tmp1 *jrt.Class; var fncls__1556 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000186_A_fn_class; if fncls__1556 == nil { var fncls__1556d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_go_run_errorcheck_fn__1938000186_A_fn_class = fncls__1556d; tmp1 = fncls__1556d } else { tmp1 = fncls__1556 }; arg_1518 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1557, tmp1, nil); if linked_1514 == nil { arg_1510 = ifn_1515.Invoke_O_O_O__O(arg_1516, arg_1517, arg_1518) } else { arg_1510 = linked_1514.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1513, arg_1516, arg_1517, arg_1518)
				}


				var arg_1511 any = A_arbace_go_run_A_const_154; var arg_1512 any = jrt.HashMap_New(); if linked_1508 == nil { src__7 = ifn_1509.Invoke_O_O_O__O(arg_1510, arg_1511, arg_1512) } else { src__7 = linked_1508.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1507, arg_1510, arg_1511, arg_1512) } } else {
//line :230:1
					src__7 = G__1938000185__8_ }; var ___8 any; var tmp2 any; var root_1558 any = /*line :213:1*/A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1560 lang.IFn; _ = ___8; if























	linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__7); if linked_1559 == nil { tmp2 = ifn_1560.Invoke_O__O(arg_1561) } else { tmp2 = linked_1559.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1558, arg_1561) }; if jrt.J2g_Truth(tmp2) { var root_1562 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, A_arbace_go_run_fail_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = A_arbace_go_run_A_const_51; var arg_1566 any = Lit_14; var arg_1567 any = Lit_26; if linked_1563 == nil { ___8 = ifn_1564.Invoke_O_O_O__O(arg_1565, arg_1566, arg_1567) } else { ___8 = linked_1563.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1562, arg_1565, arg_1566, arg_1567) } } else { ___8 = nil }; var ___9 any; var root_1568 any = /*line :213:1*/A_arbace_go_run_A_const_61.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_1570 lang.IFn; _ = ___9; if
























	linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = src__7; if linked_1569 == nil { ___9 = ifn_1570.Invoke_O__O(arg_1571) } else { ___9 = linked_1569.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_1568, arg_1571) }; var sizes__10 any; if

	jrt.J2g_Truth(front__5) { var root_1572 any = A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = lang.PersistentVector_EMPTY.Ref(); if linked_1573 == nil { sizes__10 = ifn_1574.Invoke_O__O(arg_1575) } else { sizes__10 = linked_1573.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1572, arg_1575) } } else { sizes__10 = nil }; var r__11 any; var root_1851 any = /*line :213:1*/A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1853 lang.IFn; if



























	linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_run_A_const_177, sizes__10); if linked_1852 == nil { ifn_1853.Invoke_O__O(arg_1854) } else { linked_1852.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1851, arg_1854) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__1588 any = A_arbace_go_run_errorcheck_fn__1938000193_A_New_O(src__7); var tmp4 *jrt.Class; var fncls__1587 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000193_A_fn_class; if fncls__1587 == nil { var fncls__1587d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__1588); A_arbace_go_run_errorcheck_fn__1938000193_A_fn_class = fncls__1587d; tmp4 = fncls__1587d } else { tmp4 = fncls__1587 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1588, tmp4, nil); r__11 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); var errs__12 any = /*line :213:1*/A_arbace_go_run_A_const_60.Invoke_O__O(r__11); var temp__1927000414__auto____13 any; var root_1860 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1862 lang.IFn; if





























	linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any; var fnbody__1866 any = A_arbace_go_run_errorcheck_fn__1938000197_A_New(); var tmp5 *jrt.Class; var fncls__1865 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000197_A_fn_class; if fncls__1865 == nil { var fncls__1865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_go_run_errorcheck_fn__1938000197_A_fn_class = fncls__1865d; tmp5 = fncls__1865d } else { tmp5 = fncls__1865 }; arg_1863 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1866, tmp5, nil); var arg_1864 any = errs__12; if linked_1861 == nil { temp__1927000414__auto____13 = ifn_1862.Invoke_O_O__O(arg_1863, arg_1864) } else { temp__1927000414__auto____13 = linked_1861.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1860, arg_1863, arg_1864) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var bi__14 any = temp__1927000414__auto____13; var root_1867 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, A_arbace_go_run_fail_A_fn_class); var ifn_1869 lang.IFn
		if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = A_arbace_go_run_A_const_51; var arg_1871 any = Lit_14; var arg_1872 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_65.Invoke_O__O(bi__14))).Ref(); if linked_1868 == nil { ifn_1869.Invoke_O_O_O__O(arg_1870, arg_1871, arg_1872) } else { linked_1868.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1867, arg_1870, arg_1871, arg_1872) } }; var temp__1927000414__auto____13_2 any; var root_1873 any = /*line :213:1*/A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1875 lang.IFn; if































	linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any; var fnbody__1879 any = A_arbace_go_run_errorcheck_fn__1938000199_A_New(); var tmp6 *jrt.Class; var fncls__1878 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000199_A_fn_class; if fncls__1878 == nil { var fncls__1878d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_go_run_errorcheck_fn__1938000199_A_fn_class = fncls__1878d; tmp6 = fncls__1878d } else { tmp6 = fncls__1878 }; arg_1876 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1879, tmp6, nil); var arg_1877 any = A_arbace_go_run_A_const_179.Invoke_O__O(r__11); if linked_1874 == nil { temp__1927000414__auto____13_2 = ifn_1875.Invoke_O_O__O(arg_1876, arg_1877) } else { temp__1927000414__auto____13_2 = linked_1874.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1873, arg_1876, arg_1877) }; if jrt.J2g_Truth(temp__1927000414__auto____13_2) { var u__14 any = temp__1927000414__auto____13_2; var root_1880 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, A_arbace_go_run_fail_A_fn_class); var ifn_1882 lang.IFn
		if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = A_arbace_go_run_A_const_51; var arg_1884 any = Lit_14; var arg_1885 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31, nil); var tmp8 *lang.Keyword = A_arbace_go_run_A_const_83; var tmp9 any; var root_1886 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any = u__14; if linked_1887 == nil { tmp9 = ifn_1888.Invoke_O__O(arg_1889) } else { tmp9 = linked_1887.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1886, arg_1889) }; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 any; var root_1890 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1892 lang.IFn; if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = u__14; if linked_1891 == nil { tmp11 = ifn_1892.Invoke_O__O(arg_1893) } else { tmp11 = linked_1891.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1890, arg_1893) }; arg_1885 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp11)).Ref(); if linked_1881 == nil { ifn_1882.Invoke_O_O_O__O(arg_1883, arg_1884, arg_1885) } else { linked_1881.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1880, arg_1883, arg_1884, arg_1885) } }; var errs__13 any; var G__1938000201__13_ any; var root_1589 any = /*line :213:1*/A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1591 lang.IFn; if




































	linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any; var fnbody__1595 any = A_arbace_go_run_errorcheck_fn__1938000202_A_New(); var tmp12 *jrt.Class; var fncls__1594 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000202_A_fn_class; if fncls__1594 == nil { var fncls__1594d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_go_run_errorcheck_fn__1938000202_A_fn_class = fncls__1594d; tmp12 = fncls__1594d } else { tmp12 = fncls__1594 }; arg_1592 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1595, tmp12, nil); var arg_1593 any = errs__12; if linked_1590 == nil { G__1938000201__13_ = ifn_1591.Invoke_O_O__O(arg_1592, arg_1593) } else { G__1938000201__13_ = linked_1590.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1589, arg_1592, arg_1593) }; if jrt.J2g_Truth(front__5) {
		var root_1596 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any; var fnbody__1602 any = A_arbace_go_run_errorcheck_fn__1938000204_A_New(); var tmp13 *jrt.Class; var fncls__1601 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000204_A_fn_class; if fncls__1601 == nil { var fncls__1601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_run_errorcheck_fn__1938000204_A_fn_class = fncls__1601d; tmp13 = fncls__1601d } else { tmp13 = fncls__1601 }; arg_1599 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1602, tmp13, nil); var arg_1600 any = G__1938000201__13_; if linked_1597 == nil { errs__13 = ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { errs__13 = linked_1597.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) } } else {
//line :250:1
			errs__13 = G__1938000201__13_ }; var file_lang__14 any; var root_1603 any = /*line :213:1*/A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1605 lang.IFn; if







































	linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1607 any; var iter__1927001039__auto____14 any; var fnbody__1679 any = A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A_New(); var tmp14 *jrt.Class; var fncls__1678 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A_fn_class; if fncls__1678 == nil { var fncls__1678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A_fn_class = fncls__1678d; tmp14 = fncls__1678d } else { tmp14 = fncls__1678 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1679, tmp14, nil); arg_1607 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(A_arbace_go_run_A_const_53.Invoke_O__O(src__7)); if linked_1604 == nil { file_lang__14 = ifn_1605.Invoke_O_O__O(arg_1606, arg_1607) } else { file_lang__14 = linked_1604.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1603, arg_1606, arg_1607) }; var vmsg__15 any; var fnbody__1691 any = /*line :213:1*/A_arbace_go_run_errorcheck_vmsg__1938000216_A_New_O_O_O(file_lang__14, lang__2, src__7); var tmp15 *jrt.Class; var fncls__1690 *jrt.Class = A_arbace_go_run_errorcheck_vmsg__1938000216_A_fn_class; if








































	fncls__1690 == nil { var fncls__1690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__1691); A_arbace_go_run_errorcheck_vmsg__1938000216_A_fn_class = fncls__1690d; tmp15 = fncls__1690d } else { tmp15 = fncls__1690 }; vmsg__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1691, tmp15, nil); var lmap__16 any; if








	jrt.J2g_Truth(front__5) { var root_1692 any = A_arbace_go_run_A_const_161.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, A_arbace_go_run_line_map_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = front__5; if linked_1693 == nil { lmap__16 = ifn_1694.Invoke_O__O(arg_1695) } else { lmap__16 = linked_1693.(*A_arbace_go_run_line_map_A).Invoke_O_O__O(root_1692, arg_1695) } } else { lmap__16 = nil }; var relocate__17 any; var fnbody__1702 any = /*line :213:1*/A_arbace_go_run_errorcheck_relocate__1938000218_A_New_O(lmap__16); var tmp16 *jrt.Class; var fncls__1701 *jrt.Class = A_arbace_go_run_errorcheck_relocate__1938000218_A_fn_class; if


















































	fncls__1701 == nil { var fncls__1701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__1702); A_arbace_go_run_errorcheck_relocate__1938000218_A_fn_class = fncls__1701d; tmp16 = fncls__1701d } else { tmp16 = fncls__1701 }; relocate__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1702, tmp16, nil); var lines__18 any; var iter__1927001039__auto____18 any; var fnbody__1764 any = /*line :213:1*/A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A_New_O_O(relocate__17, vmsg__15); var tmp17 *jrt.Class; var fncls__1763 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A_fn_class; if






















































	fncls__1763 == nil { var fncls__1763d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__1764); A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A_fn_class = fncls__1763d; tmp17 = fncls__1763d } else { tmp17 = fncls__1763 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1764, tmp17, nil); lines__18 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(errs__13); var lines__19 any; if
	jrt.J2g_Truth(front__5) { var ___19 any = lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_163); var name__20 any = jrt.File_New_String(jrt.String_Cast(front__5)).GetName__String().Ref(); var noder__21 any; var tmp18 *lang.Keyword = A_arbace_go_run_A_const_164; var tmp19 any; var root_1769 any = A_arbace_go_run_A_const_165.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1771 lang.IFn; _ = ___19


		if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = A_arbace_go_run_A_const_166; if linked_1770 == nil { tmp19 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp19 = linked_1770.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1769, arg_1772) }; noder__21 = tmp18.Invoke_O__O(lang.IFn_Cast(tmp19).Invoke_O_O__O(front__5, name__20))
//line :269:1
		var pos__22 any; var fnbody__1779 any = A_arbace_go_run_errorcheck_pos__1938000236_A_New(); var tmp20 *jrt.Class
		var fncls__1778 /*line :269:1*/*jrt.Class = A_arbace_go_run_errorcheck_pos__1938000236_A_fn_class




		if fncls__1778 == nil { var fncls__1778d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_go_run_errorcheck_pos__1938000236_A_fn_class = fncls__1778d; tmp20 = fncls__1778d } else { tmp20 = fncls__1778 }; pos__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1779, tmp20, nil)
//line :269:1
		var merged__23 any; var root_1780 any = A_arbace_go_run_A_const_169.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1782 lang.IFn






		if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = pos__22; var arg_1784 any; var root_1785 any = A_arbace_go_run_A_const_75.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = lines__18; var arg_1789 any = noder__21; if linked_1786 == nil { arg_1784 = ifn_1787.Invoke_O_O__O(arg_1788, arg_1789) } else { arg_1784 = linked_1786.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1785, arg_1788, arg_1789) }; if linked_1781 == nil { merged__23 = ifn_1782.Invoke_O_O__O(arg_1783, arg_1784) } else { merged__23 = linked_1781.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1780, arg_1783, arg_1784) }
		var tmp21 any; var root_1790 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = merged__23; if linked_1791 == nil { tmp21 = ifn_1792.Invoke_O__O(arg_1793) } else { tmp21 = linked_1791.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1790, arg_1793) }; if jrt.J2g_Truth(tmp21) { lines__19 = merged__23 } else { var d__24 any; var tmp22 any; var root_1794 any = A_arbace_go_run_A_const_165.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1796 lang.IFn

			if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = A_arbace_go_run_A_const_170; if linked_1795 == nil { tmp22 = ifn_1796.Invoke_O__O(arg_1797) } else { tmp22 = linked_1795.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1794, arg_1797) }; d__24 = lang.IFn_Cast(tmp22).Invoke_O_O_O__O(front__5, name__20, lang__2)


			var tmp23 any; var root_1798 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = d__24; if linked_1799 == nil { tmp23 = ifn_1800.Invoke_O__O(arg_1801) } else { tmp23 = linked_1799.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1798, arg_1801) }; if jrt.J2g_Truth(tmp23) { lines__19 = d__24 } else { var root_1802 any = A_arbace_go_run_A_const_125.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = relocate__17; var arg_1806 any; var root_1807 any = A_arbace_go_run_A_const_171.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_go_check_code.A_arbace_go_check_code_size_errors_A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any; var root_1811 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = sizes__10; if linked_1812 == nil { arg_1810 = ifn_1813.Invoke_O__O(arg_1814) } else { arg_1810 = linked_1812.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1811, arg_1814) }; if linked_1808 == nil { arg_1806 = ifn_1809.Invoke_O__O(arg_1810) } else { arg_1806 = linked_1808.(*aot_arbace_go_check_code.A_arbace_go_check_code_size_errors_A).Invoke_O_O__O(root_1807, arg_1810) }; if linked_1803 == nil { lines__19 = ifn_1804.Invoke_O_O__O(arg_1805, arg_1806) } else { lines__19 = linked_1803.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1802, arg_1805, arg_1806) } } } } else {
//line :269:1
				lines__19 = lines__18 }; var lines__20 any; var root_1815 any = /*line :213:1*/A_arbace_go_run_A_const_172.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_dedupe_A_fn_class); var ifn_1817 lang.IFn; if






































































	linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = lines__19; if linked_1816 == nil { lines__20 = ifn_1817.Invoke_O__O(arg_1818) } else { lines__20 = linked_1816.(*aot_arbace_core.A_arbace_core_dedupe_A).Invoke_O_O__O(root_1815, arg_1818) }; var lines__21 any; var tmp24 any; var and__1927000168__auto____21 any = max_errors__3; if


	jrt.J2g_Truth(and__1927000168__auto____21) { var tmp25 bool; var na_1819 int64 = int64(lang.RT_Count_O__I_NoInit(lines__20)); var na_1820 any = max_errors__3; if jrt.Long_InstanceOf(na_1820) { var n0_1821 int64 = na_1819; var n1_1822 int64 = jrt.NN(jrt.Long_Cast(na_1820)).LongValue__J(); tmp25 = n0_1821 >= n1_1822 } else { tmp25 = lang.Numbers_Gte_J_O__Z_NoInit(na_1819, na_1820) }; tmp24 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp25).Ref() } else { tmp24 = and__1927000168__auto____21 }; if jrt.J2g_Truth(tmp24) { var ls__21 any; var root_1824 any = A_arbace_go_run_A_const_89.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1826 lang.IFn
		if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any; var root_1828 any = A_arbace_go_run_A_const_173.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = max_errors__3; var arg_1832 any = lines__20; if linked_1829 == nil { arg_1827 = ifn_1830.Invoke_O_O__O(arg_1831, arg_1832) } else { arg_1827 = linked_1829.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1828, arg_1831, arg_1832) }; if linked_1825 == nil { ls__21 = ifn_1826.Invoke_O__O(arg_1827) } else { ls__21 = linked_1825.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1824, arg_1827) }
//line :287:1
		var pos__22_2 any; var root_1833 any = A_arbace_go_run_A_const_145.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1835 lang.IFn

		if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = A_arbace_go_run_A_const_174; var arg_1837 any; var root_1838 any = A_arbace_go_run_A_const_175.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1840 lang.IFn; if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = ls__21; if linked_1839 == nil { arg_1837 = ifn_1840.Invoke_O__O(arg_1841) } else { arg_1837 = linked_1839.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1838, arg_1841) }; if linked_1834 == nil { pos__22_2 = ifn_1835.Invoke_O_O__O(arg_1836, arg_1837) } else { pos__22_2 = linked_1834.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1833, arg_1836, arg_1837) }
		var root_1842 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = ls__21; var arg_1846 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_39), jrt.RefArrayOf(jrt.Object_class, pos__22_2, nil)).Ref(); if linked_1843 == nil { lines__21 = ifn_1844.Invoke_O_O__O(arg_1845, arg_1846) } else { lines__21 = linked_1843.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1842, arg_1845, arg_1846) } } else {
//line :287:1
			lines__21 = lines__20 }; var seq_1938000241__22 any; var root_1894 any = /*line :213:1*/A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1896 lang.IFn; if














































































	linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = lines__21; if linked_1895 == nil { seq_1938000241__22 = ifn_1896.Invoke_O__O(arg_1897) } else { seq_1938000241__22 = linked_1895.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1894, arg_1897) }; var chunk_1938000242__23 any; var count_1938000243__24 int64 = 0; var i_1938000244__25 int64 = 0; L1:
//line :213:1
	for {














































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000244__25, count_1938000243__24) { var l__26 any = lang.Indexed_Cast(chunk_1938000242__23).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000244__25)); lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(l__26); seq_1938000241__22, chunk_1938000242__23, count_1938000243__24, i_1938000244__25 = seq_1938000241__22, chunk_1938000242__23, count_1938000243__24, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000244__25); continue L1 } else { var temp__1927000414__auto____26 any; var root_1898 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = seq_1938000241__22; if linked_1899 == nil { temp__1927000414__auto____26 = ifn_1900.Invoke_O__O(arg_1901) } else { temp__1927000414__auto____26 = linked_1899.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1898, arg_1901) }; if jrt.J2g_Truth(temp__1927000414__auto____26) { var seq_1938000241__27 any = temp__1927000414__auto____26; var tmp26 any; var root_1902 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = seq_1938000241__27; if linked_1903 == nil { tmp26 = ifn_1904.Invoke_O__O(arg_1905) } else { tmp26 = linked_1903.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1902, arg_1905) }; if jrt.J2g_Truth(tmp26) { var c__1927000678__auto____28 any; var root_1906 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = seq_1938000241__27; if linked_1907 == nil { c__1927000678__auto____28 = ifn_1908.Invoke_O__O(arg_1909) } else { c__1927000678__auto____28 = linked_1907.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1906, arg_1909) }; var tmp27 any; var root_1921 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = seq_1938000241__27; if linked_1922 == nil { tmp27 = ifn_1923.Invoke_O__O(arg_1924) } else { tmp27 = linked_1922.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1921, arg_1924) }; seq_1938000241__22, chunk_1938000242__23, count_1938000243__24, i_1938000244__25 = tmp27, c__1927000678__auto____28, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____28))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__28 any; var root_1910 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = seq_1938000241__27; if linked_1911 == nil { l__28 = ifn_1912.Invoke_O__O(arg_1913) } else { l__28 = linked_1911.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1910, arg_1913) }; lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(l__28); var tmp28 any; var root_1929 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = seq_1938000241__27; if linked_1930 == nil { tmp28 = ifn_1931.Invoke_O__O(arg_1932) } else { tmp28 = linked_1930.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1929, arg_1932) }; seq_1938000241__22, chunk_1938000242__23, count_1938000243__24, i_1938000244__25 = tmp28, nil, 0, 0; continue L1 } } }
//line :213:1
		break L1 }; var root_1914 any =















































































	A_arbace_go_run_A_const_14.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; if linked_1915 == nil { ifn_1916.Invoke__O() } else { linked_1915.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_1914) }; var tmp29 any; var root_1847 any =
	A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = lines__21; if linked_1848 == nil { tmp29 = ifn_1849.Invoke_O__O(arg_1850) } else { tmp29 = linked_1848.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1847, arg_1850) }; if jrt.J2g_Truth(tmp29) { return A_arbace_go_run_A_const_176 } else { return A_arbace_go_run_A_const_168 } }
//line :232:1
func A_arbace_go_run_errorcheck_fn__1938000186_A_New() *A_arbace_go_run_errorcheck_fn__1938000186_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000186_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_go_run_errorcheck_fn__1938000186_A) Ctor() {}
//line :232:1
func (t *A_arbace_go_run_errorcheck_fn__1938000186_A) Invoke_O_O__O(self, fs__1 any) any { var root_1519 any = A_arbace_go_run_A_const_126.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any; var fnbody__1555 any = A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A_New(); var tmp1 *jrt.Class; var fncls__1554 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A_fn_class; if fncls__1554 == nil { var fncls__1554d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A_fn_class = fncls__1554d; tmp1 = fncls__1554d } else { tmp1 = fncls__1554 }; arg_1522 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1555, tmp1, nil); var arg_1523 any = fs__1; if linked_1520 == nil { return ifn_1521.Invoke_O_O__O(arg_1522, arg_1523) } else { return linked_1520.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1519, arg_1522, arg_1523) } }
//line :232:1
func A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A_New() *A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A) Ctor() {}
//line :232:1
func (t *A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A) Invoke_O_O__O(self, p1__1938000180_SHARP___1 any) any { var G__1938000188__2_ any; var root_1524 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = p1__1938000180_SHARP___1; var arg_1528 any = A_arbace_go_run_A_const_54; var arg_1529 any; var fnbody__1536 any = A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A_New(); var tmp1 *jrt.Class; var fncls__1535 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A_fn_class; if fncls__1535 == nil { var fncls__1535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A_fn_class = fncls__1535d; tmp1 = fncls__1535d } else { tmp1 = fncls__1535 }; arg_1529 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1536, tmp1, nil); if linked_1525 == nil { G__1938000188__2_ = ifn_1526.Invoke_O_O_O__O(arg_1527, arg_1528, arg_1529) } else { G__1938000188__2_ = linked_1525.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1524, arg_1527, arg_1528, arg_1529) }; var G__1938000188__3_ any; if jrt.J2g_Truth(A_arbace_go_run_A_const_67.Invoke_O__O(p1__1938000180_SHARP___1)) {
																var root_1537 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = G__1938000188__2_; var arg_1541 any = A_arbace_go_run_A_const_67; var arg_1542 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); if linked_1538 == nil { G__1938000188__3_ = ifn_1539.Invoke_O_O_O__O(arg_1540, arg_1541, arg_1542) } else { G__1938000188__3_ = linked_1538.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1537, arg_1540, arg_1541, arg_1542) } } else {
//line :232:1
		G__1938000188__3_ = G__1938000188__2_ }; var tmp2 any; var root_1543 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1545 lang.IFn; if

	linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = p1__1938000180_SHARP___1; var arg_1547 any = A_arbace_go_run_A_const_151; if linked_1544 == nil { tmp2 = ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { tmp2 = linked_1544.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) }; if /*line :232:1*/ jrt.J2g_Truth(tmp2) {

		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_152.GetRawRoot__O()); var tmp4 any = A_arbace_go_run_A_const_153; return tmp3.Invoke_O_O_O__O(G__1938000188__3_, tmp4, A_arbace_go_run_A_const_120.GetRawRoot__O()) } else {
//line :232:1
			return G__1938000188__3_ } }
//line :232:1
func A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A_New() *A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A) Ctor() {}
//line :232:1
func (t *A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A) Invoke_O_O__O(self, ds__1 any) any { var root_1530 any = A_arbace_go_run_A_const_126.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var arg_1534 any = ds__1; if linked_1531 == nil { return ifn_1532.Invoke_O_O__O(arg_1533, arg_1534) } else { return linked_1531.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1530, arg_1533, arg_1534) } }








func A_arbace_go_run_errorcheck_fn__1938000193_A_New_O(p0 any) *A_arbace_go_run_errorcheck_fn__1938000193_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000193_A{}; t.Ctor_O(p0); return t }
//line :241:1
func (t *A_arbace_go_run_errorcheck_fn__1938000193_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :241:1
func (t *A_arbace_go_run_errorcheck_fn__1938000193_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1576 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any; var t_ any = t.F_src; t.F_src = nil; arg_1579 = t_; var arg_1580 any; var fnbody__1583 any = A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A_New(); var tmp2 *jrt.Class; var fncls__1582 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A_fn_class; if fncls__1582 == nil { var fncls__1582d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A_fn_class = fncls__1582d; tmp2 = fncls__1582d } else { tmp2 = fncls__1582 }; arg_1580 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1583, tmp2, nil); var arg_1581 any = jrt.Boolean_FALSE.Ref(); if linked_1577 == nil { tmp1 = ifn_1578.Invoke_O_O_O__O(arg_1579, arg_1580, arg_1581) } else { tmp1 = linked_1577.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O_O__O(root_1576, arg_1579, arg_1580, arg_1581) } }; return nil }(); var root_1584 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; if linked_1585 == nil { ifn_1586.Invoke__O() } else { linked_1585.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1584) }; if tmp3 != nil { panic(tmp3) }; return tmp1 }
//line :241:1
func A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A_New() *A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A) Ctor() {}
//line :241:1
func (t *A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_go_run_errorcheck_fn__1938000197_A_New() *A_arbace_go_run_errorcheck_fn__1938000197_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000197_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_go_run_errorcheck_fn__1938000197_A) Ctor() {}
//line :243:1
func (t *A_arbace_go_run_errorcheck_fn__1938000197_A) Invoke_O_O__O(self, p1__1938000181_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_63; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000181_SHARP___1)) { return p1__1938000181_SHARP___1 } else { return nil } }

func A_arbace_go_run_errorcheck_fn__1938000199_A_New() *A_arbace_go_run_errorcheck_fn__1938000199_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000199_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_go_run_errorcheck_fn__1938000199_A) Ctor() {}
//line :245:1
func (t *A_arbace_go_run_errorcheck_fn__1938000199_A) Invoke_O_O__O(self, p1__1938000182_SHARP___1 any) any { var temp__1927000414__auto____2 any = A_arbace_go_run_A_const_178.Invoke_O__O(p1__1938000182_SHARP___1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var u__3 any = temp__1927000414__auto____2; return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_run_A_const_67.Invoke_O__O(p1__1938000182_SHARP___1), u__3) } else { return nil } }




func A_arbace_go_run_errorcheck_fn__1938000202_A_New() *A_arbace_go_run_errorcheck_fn__1938000202_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000202_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_go_run_errorcheck_fn__1938000202_A) Ctor() {}
//line :250:1
func (t *A_arbace_go_run_errorcheck_fn__1938000202_A) Invoke_O_O__O(self, p1__1938000183_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_155; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000183_SHARP___1))).Ref() }
func A_arbace_go_run_errorcheck_fn__1938000204_A_New() *A_arbace_go_run_errorcheck_fn__1938000204_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000204_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_go_run_errorcheck_fn__1938000204_A) Ctor() {}
//line :251:1
func (t *A_arbace_go_run_errorcheck_fn__1938000204_A) Invoke_O_O__O(self, p1__1938000184_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_156; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000184_SHARP___1))).Ref() }

func A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A_New() *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A) Ctor() {}
//line :253:1
func (t *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A) Invoke_O_O__O(self, s__1938000207__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1677 any = A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A_New_O_O(s__1938000207__1, self); var tmp2 *jrt.Class; var fncls__1676 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A_fn_class; if fncls__1676 == nil { var fncls__1676d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__1677); A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A_fn_class = fncls__1676d; tmp2 = fncls__1676d } else { tmp2 = fncls__1676 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1677, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :253:1
func A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A_New_O_O(p0, p1 any) *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A{}; t.Ctor_O_O(p0, p1); return t }
//line :253:1
func (t *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A) Ctor_O_O(c__s__1938000207, c__iter__1938000206 any) { t.F_s__1938000207 = c__s__1938000207; t.F_iter__1938000206 = c__iter__1938000206 }
//line :253:1
func (t *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A) Invoke_O__O(self any) any { { var s__1938000207__1 any; var t_ any = t.F_s__1938000207; t.F_s__1938000207 = nil; s__1938000207__1 = t_; for { var temp__1927000414__auto____2 any; var root_1608 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = s__1938000207__1; if linked_1609 == nil { temp__1927000414__auto____2 = ifn_1610.Invoke_O__O(arg_1611) } else { temp__1927000414__auto____2 = linked_1609.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1608, arg_1611) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000207__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1612 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = s__1938000207__3; if linked_1613 == nil { tmp1 = ifn_1614.Invoke_O__O(arg_1615) } else { tmp1 = linked_1613.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1612, arg_1615) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1616 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = s__1938000207__3; if linked_1617 == nil { c__1927001037__auto____4 = ifn_1618.Invoke_O__O(arg_1619) } else { c__1927001037__auto____4 = linked_1617.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1616, arg_1619) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000209__6 any; var root_1620 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1621 == nil { b__1938000209__6 = ifn_1622.Invoke_O__O(arg_1623) } else { b__1938000209__6 = linked_1621.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1620, arg_1623) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1635 any = A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A_New_O_I_O(b__1938000209__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1634 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A_fn_class; if fncls__1634 == nil { var fncls__1634d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__1635); A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A_fn_class = fncls__1634d; tmp3 = fncls__1634d } else { tmp3 = fncls__1634 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1635, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1636 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any; var root_1641 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = b__1938000209__6; if linked_1642 == nil { arg_1639 = ifn_1643.Invoke_O__O(arg_1644) } else { arg_1639 = linked_1642.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1641, arg_1644) }; var arg_1640 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000206); var tmp5 any; var root_1645 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = s__1938000207__3; if linked_1646 == nil { tmp5 = ifn_1647.Invoke_O__O(arg_1648) } else { tmp5 = linked_1646.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1645, arg_1648) }; arg_1640 = tmp4.Invoke_O__O(tmp5); if linked_1637 == nil { return ifn_1638.Invoke_O_O__O(arg_1639, arg_1640) } else { return linked_1637.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1636, arg_1639, arg_1640) } } else { var root_1649 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any; var root_1654 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = b__1938000209__6; if linked_1655 == nil { arg_1652 = ifn_1656.Invoke_O__O(arg_1657) } else { arg_1652 = linked_1655.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1654, arg_1657) }; var arg_1653 any; if linked_1650 == nil { return ifn_1651.Invoke_O_O__O(arg_1652, arg_1653) } else { return linked_1650.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1649, arg_1652, arg_1653) } } } else { var fi__4 any; var root_1658 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = s__1938000207__3; if linked_1659 == nil { fi__4 = ifn_1660.Invoke_O__O(arg_1661) } else { fi__4 = linked_1659.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1658, arg_1661) }; var root_1662 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var tmp6 any = A_arbace_go_run_A_const_83.Invoke_O__O(fi__4); var tmp7 any; var root_1667 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = fi__4; var arg_1671 any = A_arbace_go_run_A_const_158; if linked_1668 == nil { tmp7 = ifn_1669.Invoke_O_O__O(arg_1670, arg_1671) } else { tmp7 = linked_1668.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1667, arg_1670, arg_1671) }; arg_1665 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_1666 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000206); var tmp9 any; var root_1672 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = s__1938000207__3; if linked_1673 == nil { tmp9 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp9 = linked_1673.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1672, arg_1675) }; arg_1666 = tmp8.Invoke_O__O(tmp9); if linked_1663 == nil { return ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { return linked_1663.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :253:1
func A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :253:1
func (t *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A) Ctor_O_I_O(c__b__1938000209 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000209 = c__b__1938000209; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :253:1
func (t *A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A) Invoke_O__O(self any) any { { var i__1938000208__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000208__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000208__1)); var root_1624 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = t.F_b__1938000209; var arg_1628 any; var tmp2 any = A_arbace_go_run_A_const_83.Invoke_O__O(fi__2); var tmp3 any; var root_1629 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = fi__2; var arg_1633 any = A_arbace_go_run_A_const_157; if linked_1630 == nil { tmp3 = ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { tmp3 = linked_1630.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) }; arg_1628 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_1625 == nil { ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { linked_1625.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) }; i__1938000208__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000208__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_run_errorcheck_vmsg__1938000216_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_vmsg__1938000216_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_vmsg__1938000216_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :254:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000216_A) Ctor_O_O_O(c__file_lang, c__lang, c__src any) { t.F_file_lang = c__file_lang; t.F_lang = c__lang; t.F_src = c__src }
//line :254:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000216_A) Invoke_O_O__O(self, e__1 any) any { var m__2 any = A_arbace_go_run_A_const_65.Invoke_O__O(e__1); var tmp1 any; var root_1680 any = A_arbace_go_run_A_const_145.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1682 lang.IFn; if

	linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = A_arbace_go_run_A_const_159; var arg_1684 any = m__2; if linked_1681 == nil { tmp1 = ifn_1682.Invoke_O_O__O(arg_1683, arg_1684) } else { tmp1 = linked_1681.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1680, arg_1683, arg_1684) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_file_lang); var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(A_arbace_go_run_A_const_67.Invoke_O__O(e__1))
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var fl__4 any = temp__1927000408__auto____3
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_49), jrt.RefArrayOf(jrt.Object_class, m__2, nil, fl__4, nil)).Ref() } else {
				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_50, nil, Lit_51); var tmp4 any; var or__1927000174__auto____8 any = t.F_lang; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var root_1685 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1685, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1687 lang.IFn; if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any = t.F_src; var arg_1689 any = A_arbace_go_run_A_const_160; if linked_1686 == nil { tmp4 = ifn_1687.Invoke_O_O__O(arg_1688, arg_1689) } else { tmp4 = linked_1686.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1685, arg_1688, arg_1689) } }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, m__2, nil, tmp4, nil)).Ref() } } else {
//line :256:1
					return m__2 } }







func A_arbace_go_run_errorcheck_relocate__1938000218_A_New_O(p0 any) *A_arbace_go_run_errorcheck_relocate__1938000218_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_relocate__1938000218_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_go_run_errorcheck_relocate__1938000218_A) Ctor_O(c__lmap any) { t.F_lmap = c__lmap }
//line :264:1
func (t *A_arbace_go_run_errorcheck_relocate__1938000218_A) Invoke_O_O__O(self, l__1 any) any { var temp__1927000408__auto____2 any; if
												jrt.J2g_Truth(t.F_lmap) { var root_1696 any = A_arbace_go_run_A_const_145.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = A_arbace_go_run_A_const_162; var arg_1700 any = l__1; if linked_1697 == nil { temp__1927000408__auto____2 = ifn_1698.Invoke_O_O__O(arg_1699, arg_1700) } else { temp__1927000408__auto____2 = linked_1697.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1696, arg_1699, arg_1700) } } else { temp__1927000408__auto____2 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__1938000219__3 any = temp__1927000408__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000219__3, lang.RT_IntCast_J__I_NoInit(0), nil); var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000219__3, lang.RT_IntCast_J__I_NoInit(1), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000219__3, lang.RT_IntCast_J__I_NoInit(2), nil); var m__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000219__3, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_lmap); var vec__1938000222__8 any = tmp1.Invoke_O_O__O(f__5, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__6))).Ref()); var f__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000222__8, lang.RT_IntCast_J__I_NoInit(0), nil); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000222__8, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4
													return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, f__9, nil, n__10, nil, m__7)).Ref() } else {
//line :265:1
			return l__1 } }


func A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A_New_O_O(p0, p1 any) *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A{}; t.Ctor_O_O(p0, p1); return t }
//line :268:1
func (t *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A) Ctor_O_O(c__relocate, c__vmsg any) { t.F_relocate = c__relocate; t.F_vmsg = c__vmsg }
//line :268:1
func (t *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A) Invoke_O_O__O(self, s__1938000227__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1762 any = A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A_New_O_O_O_O(s__1938000227__1, self, t.F_relocate, t.F_vmsg); var tmp2 *jrt.Class; var fncls__1761 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A_fn_class; if fncls__1761 == nil { var fncls__1761d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__1762); A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A_fn_class = fncls__1761d; tmp2 = fncls__1761d } else { tmp2 = fncls__1761 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1762, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :268:1
func A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :268:1
func (t *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A) Ctor_O_O_O_O(c__s__1938000227, c__iter__1938000226, c__relocate, c__vmsg any) { t.F_s__1938000227 = c__s__1938000227; t.F_iter__1938000226 = c__iter__1938000226; t.F_relocate = c__relocate; t.F_vmsg = c__vmsg }
//line :268:1
func (t *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A) Invoke_O__O(self any) any { { var s__1938000227__1 any; var t_ any = t.F_s__1938000227; t.F_s__1938000227 = nil; s__1938000227__1 = t_; for { var temp__1927000414__auto____2 any; var root_1703 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = s__1938000227__1; if linked_1704 == nil { temp__1927000414__auto____2 = ifn_1705.Invoke_O__O(arg_1706) } else { temp__1927000414__auto____2 = linked_1704.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1703, arg_1706) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000227__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1707 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = s__1938000227__3; if linked_1708 == nil { tmp1 = ifn_1709.Invoke_O__O(arg_1710) } else { tmp1 = linked_1708.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1707, arg_1710) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1711 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = s__1938000227__3; if linked_1712 == nil { c__1927001037__auto____4 = ifn_1713.Invoke_O__O(arg_1714) } else { c__1927001037__auto____4 = linked_1712.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1711, arg_1714) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000229__6 any; var root_1715 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1716 == nil { b__1938000229__6 = ifn_1717.Invoke_O__O(arg_1718) } else { b__1938000229__6 = linked_1716.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1715, arg_1718) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1725 any = A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A_New_O_O_O_I_O(b__1938000229__6, t.F_relocate, t.F_vmsg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1724 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A_fn_class; if fncls__1724 == nil { var fncls__1724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1725); A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A_fn_class = fncls__1724d; tmp3 = fncls__1724d } else { tmp3 = fncls__1724 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1725, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1726 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any; var root_1731 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = b__1938000229__6; if linked_1732 == nil { arg_1729 = ifn_1733.Invoke_O__O(arg_1734) } else { arg_1729 = linked_1732.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1731, arg_1734) }; var arg_1730 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000226); var tmp5 any; var root_1735 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = s__1938000227__3; if linked_1736 == nil { tmp5 = ifn_1737.Invoke_O__O(arg_1738) } else { tmp5 = linked_1736.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1735, arg_1738) }; arg_1730 = tmp4.Invoke_O__O(tmp5); if linked_1727 == nil { return ifn_1728.Invoke_O_O__O(arg_1729, arg_1730) } else { return linked_1727.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1726, arg_1729, arg_1730) } } else { var root_1739 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any; var root_1744 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = b__1938000229__6; if linked_1745 == nil { arg_1742 = ifn_1746.Invoke_O__O(arg_1747) } else { arg_1742 = linked_1745.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1744, arg_1747) }; var arg_1743 any; if linked_1740 == nil { return ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { return linked_1740.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) } } } else { var e__4 any; var root_1748 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = s__1938000227__3; if linked_1749 == nil { e__4 = ifn_1750.Invoke_O__O(arg_1751) } else { e__4 = linked_1749.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1748, arg_1751) }; var root_1752 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_relocate); var arg_1755 any = tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_67.Invoke_O__O(e__4), nil, A_arbace_go_run_A_const_68.Invoke_O__O(e__4), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__4))).Ref()); var arg_1756 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000226); var tmp8 any; var root_1757 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = s__1938000227__3; if linked_1758 == nil { tmp8 = ifn_1759.Invoke_O__O(arg_1760) } else { tmp8 = linked_1758.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1757, arg_1760) }; arg_1756 = tmp7.Invoke_O__O(tmp8); if linked_1753 == nil { return ifn_1754.Invoke_O_O__O(arg_1755, arg_1756) } else { return linked_1753.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1752, arg_1755, arg_1756) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :268:1
func A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :268:1
func (t *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A) Ctor_O_O_O_I_O(c__b__1938000229, c__relocate, c__vmsg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000229 = c__b__1938000229; t.F_relocate = c__relocate; t.F_vmsg = c__vmsg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :268:1
func (t *A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A) Invoke_O__O(self any) any { { var i__1938000228__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000228__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000228__1)); var root_1719 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = t.F_b__1938000229; var tmp2 lang.IFn = lang.IFn_Cast(t.F_relocate); var arg_1723 any = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_67.Invoke_O__O(e__2), nil, A_arbace_go_run_A_const_68.Invoke_O__O(e__2), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__2))).Ref()); if linked_1720 == nil { ifn_1721.Invoke_O_O__O(arg_1722, arg_1723) } else { linked_1720.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1719, arg_1722, arg_1723) }; i__1938000228__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000228__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_errorcheck_pos__1938000236_A_New() *A_arbace_go_run_errorcheck_pos__1938000236_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_pos__1938000236_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_go_run_errorcheck_pos__1938000236_A) Ctor() {}
//line :274:1
func (t *A_arbace_go_run_errorcheck_pos__1938000236_A) Invoke_O_O__O(self, l__1 any) any { var vec__1938000237__2 any; var root_1773 any = A_arbace_go_run_A_const_145.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = A_arbace_go_run_A_const_167; var arg_1777 any = l__1; if linked_1774 == nil { vec__1938000237__2 = ifn_1775.Invoke_O_O__O(arg_1776, arg_1777) } else { vec__1938000237__2 = linked_1774.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1773, arg_1776, arg_1777) }; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000237__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000237__2, lang.RT_IntCast_J__I_NoInit(1), nil); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000237__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any; var or__1927000174__auto____6 any = f__4; _ = ___3; if
												jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = Lit_22 }; var tmp2 any = tmp1; var tmp3 any; if jrt.J2g_Truth(n__5) { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__5))).Ref() } else { tmp3 = A_arbace_go_run_A_const_168 }; return /*line :274:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }





















func A_arbace_go_run__main_A_New() *A_arbace_go_run__main_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_go_run__main_A) Ctor() {}
//line :296:1
func (t *A_arbace_go_run__main_A) DoInvoke_O_O__O(self, args__0 any) any {






	var tmp1 any; var root_1990 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = args__0; if linked_1991 == nil { tmp1 = ifn_1992.Invoke_O__O(arg_1993) } else { tmp1 = linked_1991.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1990, arg_1993) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_1, tmp1) { var vec__1938000246__2 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__2059 any = A_arbace_go_run__main_fn__1938000252_A_New_O(args__0); var tmp3 *jrt.Class; var fncls__2058 *jrt.Class = A_arbace_go_run__main_fn__1938000252_A_fn_class
		if fncls__2058 == nil { var fncls__2058d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__2059); A_arbace_go_run__main_fn__1938000252_A_fn_class = fncls__2058d; tmp3 = fncls__2058d } else { tmp3 = fncls__2058 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2059, tmp3, nil); vec__1938000246__2 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :303:1
		var opts__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000246__2, lang.RT_IntCast_J__I_NoInit(0), nil); var args__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000246__2, lang.RT_IntCast_J__I_NoInit(1), nil); var lang__5 any = A_arbace_go_run_A_const_185.Invoke_O__O(opts__3); var vec__1938000249__6 any = args__4; var root__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000249__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_name__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000249__6, lang.RT_IntCast_J__I_NoInit(1), nil); var pf__9 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp5 any; var root_2060 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_2062 lang.IFn









		if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = ns_name__8; if linked_2061 == nil { tmp5 = ifn_2062.Invoke_O__O(arg_2063) } else { tmp5 = linked_2061.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_2060, arg_2063) }
//line :303:1
		pf__9 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, root__7, nil, tmp5)))










		if jrt.File_Cast(pf__9).IsFile__Z() { } else { var root_2100 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, A_arbace_go_run_fail_A_fn_class); var ifn_2102 lang.IFn; if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = A_arbace_go_run_A_const_66; var arg_2104 any = Lit_4; var arg_2105 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__9)).Ref(); if linked_2101 == nil { ifn_2102.Invoke_O_O_O__O(arg_2103, arg_2104, arg_2105) } else { linked_2101.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2100, arg_2103, arg_2104, arg_2105) } }
		var tmp6 *lang.Compiler_AOTFn; var fnbody__2099 any = A_arbace_go_run__main_fn__1938000255_A_New_O_O_O_O(lang__5, pf__9, root__7, opts__3); var tmp7 *jrt.Class; var fncls__2098 *jrt.Class = A_arbace_go_run__main_fn__1938000255_A_fn_class; if fncls__2098 == nil { var fncls__2098d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__2099); A_arbace_go_run__main_fn__1938000255_A_fn_class = fncls__2098d; tmp7 = fncls__2098d } else { tmp7 = fncls__2098 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2099, tmp7, nil); jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(Up_Compiler_AOTFn_IFn(tmp6).Invoke__O())) }
//line :296:1
	var vec__1938000257__2 any = args__0; var seq__1938000258__3 any; var root_1933 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1935 lang.IFn


























	if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = vec__1938000257__2; if linked_1934 == nil { seq__1938000258__3 = ifn_1935.Invoke_O__O(arg_1936) } else { seq__1938000258__3 = linked_1934.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1933, arg_1936) }
//line :296:1
	var first__1938000259__4 any; var root_1937 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1939 lang.IFn


























	if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = seq__1938000258__3; if linked_1938 == nil { first__1938000259__4 = ifn_1939.Invoke_O__O(arg_1940) } else { first__1938000259__4 = linked_1938.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1937, arg_1940) }
//line :296:1
	var seq__1938000258__5 any; var root_1941 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1943 lang.IFn


























	if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = seq__1938000258__3; if linked_1942 == nil { seq__1938000258__5 = ifn_1943.Invoke_O__O(arg_1944) } else { seq__1938000258__5 = linked_1942.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1941, arg_1944) }
//line :296:1
	var root__6 any = first__1938000259__4; var first__1938000259__7 any; var root_1945 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1947 lang.IFn


























	if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = seq__1938000258__5; if linked_1946 == nil { first__1938000259__7 = ifn_1947.Invoke_O__O(arg_1948) } else { first__1938000259__7 = linked_1946.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1945, arg_1948) }
//line :296:1
	var seq__1938000258__8 any; var root_1949 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_1950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1949, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1951 lang.IFn


























	if linked_1950 == nil { ifn_1951 = lang.IFn_Cast(root_1949) } else { ifn_1951 = nil }; var arg_1952 any = seq__1938000258__5; if linked_1950 == nil { seq__1938000258__8 = ifn_1951.Invoke_O__O(arg_1952) } else { seq__1938000258__8 = linked_1950.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1949, arg_1952) }
//line :296:1
	var ns_name__9 any = first__1938000259__7; var pargs__10 any = seq__1938000258__8; var tmp8 any
	var and__1927000168__auto____11 any = root__6


























	if jrt.J2g_Truth(and__1927000168__auto____11) { tmp8 = ns_name__9 } else { tmp8 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp8) { } else {
		var root_2115 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()); var tmp10 any = A_arbace_go_run_A_const_22; var arg_2118 any = tmp9.Invoke_O_O__O(tmp10, A_arbace_go_run_A_const_23.Get__O()); if linked_2116 == nil { ifn_2117.Invoke_O__O(arg_2118) } else { linked_2116.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2115, arg_2118) }; var tmp11 *lang.Compiler_AOTFn; var fnbody__2114 any = A_arbace_go_run__main_fn__1938000260_A_New(); var tmp12 *jrt.Class; var fncls__2113 *jrt.Class = A_arbace_go_run__main_fn__1938000260_A_fn_class; if fncls__2113 == nil { var fncls__2113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); A_arbace_go_run__main_fn__1938000260_A_fn_class = fncls__2113d; tmp12 = fncls__2113d } else { tmp12 = fncls__2113 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2114, tmp12, nil); Up_Compiler_AOTFn_IFn(tmp11).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :296:1
	var pf__11 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp14 any; var root_1953 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1955 lang.IFn






























	if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = ns_name__9; if linked_1954 == nil { tmp14 = ifn_1955.Invoke_O__O(arg_1956) } else { tmp14 = linked_1954.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1953, arg_1956) }
//line :296:1
	pf__11 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, root__6, nil, tmp14)))































	if jrt.File_Cast(pf__11).IsFile__Z() { } else {
		var root_2124 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2124, A_arbace_go_run_fail_A_fn_class); var ifn_2126 lang.IFn; if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = A_arbace_go_run_A_const_66; var arg_2128 any = Lit_4; var arg_2129 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__11)).Ref(); if linked_2125 == nil { ifn_2126.Invoke_O_O_O__O(arg_2127, arg_2128, arg_2129) } else { linked_2125.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2124, arg_2127, arg_2128, arg_2129) } }
//line :296:1
	var status__12 any; var tmp15 *lang.Compiler_AOTFn; var fnbody__1989 any = A_arbace_go_run__main_fn__1938000262_A_New_O_O_O(pargs__10, pf__11, root__6); var tmp16 *jrt.Class
	var fncls__1988 /*line :296:1*/*jrt.Class = A_arbace_go_run__main_fn__1938000262_A_fn_class

































	if fncls__1988 == nil { var fncls__1988d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__1989); A_arbace_go_run__main_fn__1938000262_A_fn_class = fncls__1988d; tmp16 = fncls__1988d } else { tmp16 = fncls__1988 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1989, tmp16, nil); status__12 = Up_Compiler_AOTFn_IFn(tmp15).Invoke__O()








	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__12)); return nil }
//line :304:1
func A_arbace_go_run__main_fn__1938000252_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000252_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000252_A{}; t.Ctor_O(p0); return t }
//line :304:1
func (t *A_arbace_go_run__main_fn__1938000252_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :304:1
func (t *A_arbace_go_run__main_fn__1938000252_A) Invoke_O__O(self any) any { { var opts__1 any = lang.PersistentArrayMap_EMPTY.Ref(); var as__2 any; var root_1994 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any; var t_ any = t.F_args; t.F_args = nil; arg_1997 = t_; if linked_1995 == nil { as__2 = ifn_1996.Invoke_O__O(arg_1997) } else { as__2 = linked_1995.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1994, arg_1997) }; L1: for { var G__1938000253__3_ any; var root_1998 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2000 lang.IFn
										if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = as__2; if linked_1999 == nil { G__1938000253__3_ = ifn_2000.Invoke_O__O(arg_2001) } else { G__1938000253__3_ = linked_1999.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1998, arg_2001) }; switch lang.Util_Hash_O__I_NoInit(G__1938000253__3_) >> 15 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000253__3_, Lit_9) {


		var tmp1 any; var root_2003 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2005 lang.IFn; if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = opts__1; var arg_2007 any = A_arbace_go_run_A_const_184; var arg_2008 any = jrt.Boolean_TRUE.Ref(); if linked_2004 == nil { tmp1 = ifn_2005.Invoke_O_O_O__O(arg_2006, arg_2007, arg_2008) } else { tmp1 = linked_2004.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2003, arg_2006, arg_2007, arg_2008) }; var tmp2 any = tmp1; var tmp3 any; var root_2009 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = as__2; if linked_2010 == nil { tmp3 = ifn_2011.Invoke_O__O(arg_2012) } else { tmp3 = linked_2010.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2009, arg_2012) }; opts__1, as__2 = tmp2, tmp3; continue L1 }
//line :305:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000253__3_, Lit_10) {
		var tmp4 any; var root_2013 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = opts__1; var arg_2017 any = A_arbace_go_run_A_const_185; var arg_2018 any; var root_2019 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2021 lang.IFn; if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var arg_2022 any = as__2; if linked_2020 == nil { arg_2018 = ifn_2021.Invoke_O__O(arg_2022) } else { arg_2018 = linked_2020.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2019, arg_2022) }; if linked_2014 == nil { tmp4 = ifn_2015.Invoke_O_O_O__O(arg_2016, arg_2017, arg_2018) } else { tmp4 = linked_2014.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2013, arg_2016, arg_2017, arg_2018) }; var tmp5 any = tmp4; var tmp6 any; var root_2023 any = A_arbace_go_run_A_const_186.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2023, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2025 lang.IFn; if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2027 any = as__2; if linked_2024 == nil { tmp6 = ifn_2025.Invoke_O_O__O(A_arbace_go_run_A_const_187, arg_2027) } else { tmp6 = linked_2024.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2023, 2, A_arbace_go_run_A_const_187, arg_2027) }; opts__1, as__2 = tmp5, tmp6; continue L1 }
//line :305:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000253__3_, Lit_11) {



		var tmp7 any; var root_2028 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = opts__1; var arg_2032 any = A_arbace_go_run_A_const_188; var arg_2033 any; var root_2034 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2034, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2036 lang.IFn; if linked_2035 == nil { ifn_2036 = lang.IFn_Cast(root_2034) } else { ifn_2036 = nil }; var arg_2037 any = as__2; if linked_2035 == nil { arg_2033 = ifn_2036.Invoke_O__O(arg_2037) } else { arg_2033 = linked_2035.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2034, arg_2037) }; if linked_2029 == nil { tmp7 = ifn_2030.Invoke_O_O_O__O(arg_2031, arg_2032, arg_2033) } else { tmp7 = linked_2029.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2028, arg_2031, arg_2032, arg_2033) }; var tmp8 any = tmp7; var tmp9 any; var root_2038 any = A_arbace_go_run_A_const_186.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2042 any = as__2; if linked_2039 == nil { tmp9 = ifn_2040.Invoke_O_O__O(A_arbace_go_run_A_const_187, arg_2042) } else { tmp9 = linked_2039.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2038, 2, A_arbace_go_run_A_const_187, arg_2042) }; opts__1, as__2 = tmp8, tmp9; continue L1 }
//line :305:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000253__3_, Lit_12) {

		var tmp10 any; var root_2043 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = opts__1; var arg_2047 any = A_arbace_go_run_A_const_189; var arg_2048 any; var tmp11 any; var root_2049 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any = as__2; if linked_2050 == nil { tmp11 = ifn_2051.Invoke_O__O(arg_2052) } else { tmp11 = linked_2050.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2049, arg_2052) }; arg_2048 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp11))).Ref(); if linked_2044 == nil { tmp10 = ifn_2045.Invoke_O_O_O__O(arg_2046, arg_2047, arg_2048) } else { tmp10 = linked_2044.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2043, arg_2046, arg_2047, arg_2048) }; var tmp12 any = tmp10; var tmp13 any; var root_2053 any = A_arbace_go_run_A_const_186.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2057 any = as__2; if linked_2054 == nil { tmp13 = ifn_2055.Invoke_O_O__O(A_arbace_go_run_A_const_187, arg_2057) } else { tmp13 = linked_2054.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2053, 2, A_arbace_go_run_A_const_187, arg_2057) }; opts__1, as__2 = tmp12, tmp13; continue L1 }
//line :305:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__1, as__2) } }; /*line :304:1*/panic("j2g: unreachable") }










func A_arbace_go_run__main_fn__1938000255_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run__main_fn__1938000255_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000255_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :315:1
func (t *A_arbace_go_run__main_fn__1938000255_A) Ctor_O_O_O_O(c__lang, c__pf, c__root, c__opts any) { t.F_lang = c__lang; t.F_pf = c__pf; t.F_root = c__root; t.F_opts = c__opts }
//line :315:1
func (t *A_arbace_go_run__main_fn__1938000255_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2064 any = A_arbace_go_run_A_const_190.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, A_arbace_go_run_errorcheck_A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any; var t_ any = t.F_root; t.F_root = nil; arg_2067 = t_; var arg_2068 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_2068 = t__2; var arg_2069 any; var t__3 any = t.F_lang; t.F_lang = nil; arg_2069 = t__3; var arg_2070 any = A_arbace_go_run_A_const_189.Invoke_O__O(t.F_opts); var arg_2071 any = A_arbace_go_run_A_const_184.Invoke_O__O(t.F_opts); var arg_2072 any; var tmp2 *lang.Keyword = A_arbace_go_run_A_const_188; var tmp3 any; var t__4 any = t.F_opts; t.F_opts = nil; tmp3 = t__4; arg_2072 = tmp2.Invoke_O__O(tmp3); if linked_2065 == nil { tmp1 = ifn_2066.Invoke_O_O_O_O_O_O__O(arg_2067, arg_2068, arg_2069, arg_2070, arg_2071, arg_2072) } else { tmp1 = linked_2065.(*A_arbace_go_run_errorcheck_A).Invoke_O_O_O_O_O_O_O__O(root_2064, arg_2067, arg_2068, arg_2069, arg_2070, arg_2071, arg_2072) } }; return nil }(); if tmp4 != nil { if true { var ex__3 jrt.Throwable_I = tmp4; var d__4 any; var root_2073 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2075 lang.IFn

	if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = ex__3; if linked_2074 == nil { d__4 = ifn_2075.Invoke_O__O(arg_2076) } else { d__4 = linked_2074.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2073, arg_2076) }
//line :315:1
	var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_182.Invoke_O__O(d__4)


	if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
		if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp5 any; var root_2077 any = A_arbace_go_run_A_const_142.GetRawRoot__O(); var linked_2078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2077, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2079 lang.IFn; if linked_2078 == nil { ifn_2079 = lang.IFn_Cast(root_2077) } else { ifn_2079 = nil }; var arg_2080 any = m__7; var arg_2081 any = Lit_13; if linked_2078 == nil { tmp5 = ifn_2079.Invoke_O_O__O(arg_2080, arg_2081) } else { tmp5 = linked_2078.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2077, arg_2080, arg_2081) }; if jrt.J2g_Truth(tmp5) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
	if jrt.J2g_Truth(u__5) {
		var root_2082 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, A_arbace_go_run_fail_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = A_arbace_go_run_A_const_51; var arg_2086 any = Lit_14; var arg_2087 any = u__5; if linked_2083 == nil { tmp1 = ifn_2084.Invoke_O_O_O__O(arg_2085, arg_2086, arg_2087) } else { tmp1 = linked_2083.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2082, arg_2085, arg_2086, arg_2087) } } else {
			var root_2088 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, A_arbace_go_run_fail_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = A_arbace_go_run_A_const_66; var arg_2092 any = Lit_4; var arg_2093 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil); var tmp7 any; var root_2094 any = A_arbace_go_run_A_const_183.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = ex__3; if linked_2095 == nil { tmp7 = ifn_2096.Invoke_O__O(arg_2097) } else { tmp7 = linked_2095.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2094, arg_2097) }; arg_2093 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp7)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_2089 == nil { tmp1 = ifn_2090.Invoke_O_O_O__O(arg_2091, arg_2092, arg_2093) } else { tmp1 = linked_2089.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2088, arg_2091, arg_2092, arg_2093) } } } }; return tmp1 }


func A_arbace_go_run__main_fn__1938000260_A_New() *A_arbace_go_run__main_fn__1938000260_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000260_A{}; t.Ctor(); return t }
//line :325:1
func (t *A_arbace_go_run__main_fn__1938000260_A) Ctor() {}
//line :325:1
func (t *A_arbace_go_run__main_fn__1938000260_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(Lit_16); return nil }(); var root_2110 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2112 lang.IFn; if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; if linked_2111 == nil { ifn_2112.Invoke__O() } else { linked_2111.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2110) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_go_run__main_fn__1938000262_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run__main_fn__1938000262_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000262_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :330:1
func (t *A_arbace_go_run__main_fn__1938000262_A) Ctor_O_O_O(c__pargs, c__pf, c__root any) { t.F_pargs = c__pargs; t.F_pf = c__pf; t.F_root = c__root }
//line :330:1
func (t *A_arbace_go_run__main_fn__1938000262_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_1957 any = A_arbace_go_run_A_const_181.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, A_arbace_go_run_run_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any; var t_ any = t.F_root; t.F_root = nil; arg_1960 = t_; var arg_1961 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1961 = t__2; var arg_1962 any; var t__3 any = t.F_pargs; t.F_pargs = nil; arg_1962 = t__3; if linked_1958 == nil { tmp1 = ifn_1959.Invoke_O_O_O__O(arg_1960, arg_1961, arg_1962) } else { tmp1 = linked_1958.(*A_arbace_go_run_run_A).Invoke_O_O_O_O__O(root_1957, arg_1960, arg_1961, arg_1962) } }
//line :330:1
	return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var d__4 any; var root_1963 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1965 lang.IFn


		if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = ex__3; if linked_1964 == nil { d__4 = ifn_1965.Invoke_O__O(arg_1966) } else { d__4 = linked_1964.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1963, arg_1966) }
//line :330:1
		var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_182.Invoke_O__O(d__4)



		if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp3 any; var root_1967 any = A_arbace_go_run_A_const_142.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1967, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1969 lang.IFn; if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any = m__7; var arg_1971 any = Lit_13; if linked_1968 == nil { tmp3 = ifn_1969.Invoke_O_O__O(arg_1970, arg_1971) } else { tmp3 = linked_1968.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1967, arg_1970, arg_1971) }; if jrt.J2g_Truth(tmp3) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
		if jrt.J2g_Truth(u__5) {
			var root_1972 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, A_arbace_go_run_fail_A_fn_class); var ifn_1974 lang.IFn; if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any = A_arbace_go_run_A_const_51; var arg_1976 any = Lit_14; var arg_1977 any = u__5; if linked_1973 == nil { tmp1 = ifn_1974.Invoke_O_O_O__O(arg_1975, arg_1976, arg_1977) } else { tmp1 = linked_1973.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1972, arg_1975, arg_1976, arg_1977) } } else {
				var root_1978 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, A_arbace_go_run_fail_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = A_arbace_go_run_A_const_66; var arg_1982 any = Lit_4; var arg_1983 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil); var tmp5 any; var root_1984 any = A_arbace_go_run_A_const_183.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = ex__3; if linked_1985 == nil { tmp5 = ifn_1986.Invoke_O__O(arg_1987) } else { tmp5 = linked_1985.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1984, arg_1987) }; arg_1983 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp5)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1979 == nil { tmp1 = ifn_1980.Invoke_O_O_O__O(arg_1981, arg_1982, arg_1983) } else { tmp1 = linked_1979.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1978, arg_1981, arg_1982, arg_1983) } } } }; return tmp1 }




































































































type A_arbace_go_run_A struct{ jrt.Object }

var A_arbace_go_run_A_const_pool *jrt.RefArray

var A_arbace_go_run_A_const_0 *lang.Var

var A_arbace_go_run_A_const_1 any

var A_arbace_go_run_A_const_2 *lang.Var

var A_arbace_go_run_A_const_3 any

var A_arbace_go_run_A_const_4 any

var A_arbace_go_run_A_const_5 any

var A_arbace_go_run_A_const_6 any

var A_arbace_go_run_A_const_7 any

var A_arbace_go_run_A_const_8 any

var A_arbace_go_run_A_const_9 *lang.Var

var A_arbace_go_run_A_const_10 *lang.Var

var A_arbace_go_run_A_const_11 *lang.Var

var A_arbace_go_run_A_const_12 *lang.Var

var A_arbace_go_run_A_const_13 any

var A_arbace_go_run_A_const_14 *lang.Var

var A_arbace_go_run_A_const_15 *lang.Var

var A_arbace_go_run_A_const_16 *lang.Var

var A_arbace_go_run_A_const_17 *lang.Var

var A_arbace_go_run_A_const_18 *lang.Var

var A_arbace_go_run_A_const_19 *lang.Var

var A_arbace_go_run_A_const_20 *lang.Var

var A_arbace_go_run_A_const_21 *lang.Var

var A_arbace_go_run_A_const_22 *lang.Var

var A_arbace_go_run_A_const_23 *lang.Var

var A_arbace_go_run_A_const_24 *lang.Var

var A_arbace_go_run_A_const_25 *lang.Var

var A_arbace_go_run_A_const_26 *lang.Var

var A_arbace_go_run_A_const_27 *lang.Var

var A_arbace_go_run_A_const_28 *lang.Var

var A_arbace_go_run_A_const_29 *lang.Var

var A_arbace_go_run_A_const_30 any

var A_arbace_go_run_A_const_31 *lang.Keyword

var A_arbace_go_run_A_const_32 *lang.Var

var A_arbace_go_run_A_const_33 *lang.Var

var A_arbace_go_run_A_const_34 *lang.Var

var A_arbace_go_run_A_const_35 *lang.Var

var A_arbace_go_run_A_const_36 *lang.Var

var A_arbace_go_run_A_const_37 *lang.Var

var A_arbace_go_run_A_const_38 *lang.Var

var A_arbace_go_run_A_const_39 *lang.Var

var A_arbace_go_run_A_const_40 *lang.Var

var A_arbace_go_run_A_const_41 *lang.Var

var A_arbace_go_run_A_const_42 *lang.Var

var A_arbace_go_run_A_const_43 *lang.Var

var A_arbace_go_run_A_const_44 *lang.Var

var A_arbace_go_run_A_const_45 *lang.Var

var A_arbace_go_run_A_const_46 *lang.Var

var A_arbace_go_run_A_const_47 *lang.Var

var A_arbace_go_run_A_const_48 *lang.Var

var A_arbace_go_run_A_const_49 any

var A_arbace_go_run_A_const_50 *lang.Var

var A_arbace_go_run_A_const_51 any

var A_arbace_go_run_A_const_52 *lang.Keyword

var A_arbace_go_run_A_const_53 *lang.Keyword

var A_arbace_go_run_A_const_54 *lang.Keyword

var A_arbace_go_run_A_const_55 *lang.Var

var A_arbace_go_run_A_const_56 *lang.Var

var A_arbace_go_run_A_const_57 *lang.Keyword

var A_arbace_go_run_A_const_58 *lang.Var

var A_arbace_go_run_A_const_59 *lang.Var

var A_arbace_go_run_A_const_60 *lang.Keyword

var A_arbace_go_run_A_const_61 *lang.Var

var A_arbace_go_run_A_const_62 *lang.Var

var A_arbace_go_run_A_const_63 *lang.Keyword

var A_arbace_go_run_A_const_64 *lang.Keyword

var A_arbace_go_run_A_const_65 *lang.Keyword

var A_arbace_go_run_A_const_66 any

var A_arbace_go_run_A_const_67 *lang.Keyword

var A_arbace_go_run_A_const_68 *lang.Keyword

var A_arbace_go_run_A_const_69 any

var A_arbace_go_run_A_const_70 *lang.Var

var A_arbace_go_run_A_const_71 *lang.Var

var A_arbace_go_run_A_const_72 *lang.Var

var A_arbace_go_run_A_const_73 *lang.Var

var A_arbace_go_run_A_const_74 any

var A_arbace_go_run_A_const_75 *lang.Var

var A_arbace_go_run_A_const_76 *lang.Var

var A_arbace_go_run_A_const_77 *lang.Keyword

var A_arbace_go_run_A_const_78 *lang.Var

var A_arbace_go_run_A_const_79 *lang.Var

var A_arbace_go_run_A_const_80 *lang.Var

var A_arbace_go_run_A_const_81 *lang.Var

var A_arbace_go_run_A_const_82 *lang.Var

var A_arbace_go_run_A_const_83 *lang.Keyword

var A_arbace_go_run_A_const_84 *lang.Keyword

var A_arbace_go_run_A_const_85 *lang.Var

var A_arbace_go_run_A_const_86 *lang.Keyword

var A_arbace_go_run_A_const_87 *lang.Keyword

var A_arbace_go_run_A_const_88 *lang.Keyword

var A_arbace_go_run_A_const_89 *lang.Var

var A_arbace_go_run_A_const_90 *lang.Keyword

var A_arbace_go_run_A_const_91 *lang.Keyword

var A_arbace_go_run_A_const_92 *lang.Keyword

var A_arbace_go_run_A_const_93 *lang.Var

var A_arbace_go_run_A_const_94 any

var A_arbace_go_run_A_const_95 *lang.Keyword

var A_arbace_go_run_A_const_96 *lang.Var

var A_arbace_go_run_A_const_97 *lang.Var

var A_arbace_go_run_A_const_98 *lang.Var

var A_arbace_go_run_A_const_99 *lang.Var

var A_arbace_go_run_A_const_100 *lang.Keyword

var A_arbace_go_run_A_const_101 *lang.Keyword

var A_arbace_go_run_A_const_102 *lang.Var

var A_arbace_go_run_A_const_103 *lang.Var

var A_arbace_go_run_A_const_104 *lang.Var

var A_arbace_go_run_A_const_105 *lang.Var

var A_arbace_go_run_A_const_106 *lang.Var

var A_arbace_go_run_A_const_107 *lang.Var

var A_arbace_go_run_A_const_108 *lang.Var

var A_arbace_go_run_A_const_109 *lang.Var

var A_arbace_go_run_A_const_110 *lang.Var

var A_arbace_go_run_A_const_111 *lang.Var

var A_arbace_go_run_A_const_112 *lang.Keyword

var A_arbace_go_run_A_const_113 *lang.Var

var A_arbace_go_run_A_const_114 *lang.Var

var A_arbace_go_run_A_const_115 *lang.Var

var A_arbace_go_run_A_const_116 *lang.Var

var A_arbace_go_run_A_const_117 *lang.Var

var A_arbace_go_run_A_const_118 *lang.Keyword

var A_arbace_go_run_A_const_119 *lang.Var

var A_arbace_go_run_A_const_120 *lang.Var

var A_arbace_go_run_A_const_121 *lang.Var

var A_arbace_go_run_A_const_122 *lang.Var

var A_arbace_go_run_A_const_123 *lang.Var

var A_arbace_go_run_A_const_124 *lang.Var

var A_arbace_go_run_A_const_125 *lang.Var

var A_arbace_go_run_A_const_126 *lang.Var

var A_arbace_go_run_A_const_127 *lang.Var

var A_arbace_go_run_A_const_128 *lang.Var

var A_arbace_go_run_A_const_129 *lang.Keyword

var A_arbace_go_run_A_const_130 *lang.Var

var A_arbace_go_run_A_const_131 *lang.Var

var A_arbace_go_run_A_const_132 *lang.Keyword

var A_arbace_go_run_A_const_133 *lang.Var

var A_arbace_go_run_A_const_134 *lang.Var

var A_arbace_go_run_A_const_135 any

var A_arbace_go_run_A_const_136 *lang.Keyword

var A_arbace_go_run_A_const_137 *lang.Var

var A_arbace_go_run_A_const_138 *lang.Keyword

var A_arbace_go_run_A_const_139 *lang.Keyword

var A_arbace_go_run_A_const_140 *lang.Var

var A_arbace_go_run_A_const_141 *lang.Var

var A_arbace_go_run_A_const_142 *lang.Var

var A_arbace_go_run_A_const_143 *lang.Var

var A_arbace_go_run_A_const_144 any

var A_arbace_go_run_A_const_145 *lang.Var

var A_arbace_go_run_A_const_146 any

var A_arbace_go_run_A_const_147 any

var A_arbace_go_run_A_const_148 *lang.Var

var A_arbace_go_run_A_const_149 *lang.Var

var A_arbace_go_run_A_const_150 any

var A_arbace_go_run_A_const_151 any

var A_arbace_go_run_A_const_152 *lang.Var

var A_arbace_go_run_A_const_153 any

var A_arbace_go_run_A_const_154 *lang.Keyword

var A_arbace_go_run_A_const_155 *lang.Keyword

var A_arbace_go_run_A_const_156 *lang.Keyword

var A_arbace_go_run_A_const_157 any

var A_arbace_go_run_A_const_158 any

var A_arbace_go_run_A_const_159 any

var A_arbace_go_run_A_const_160 any

var A_arbace_go_run_A_const_161 *lang.Var

var A_arbace_go_run_A_const_162 any

var A_arbace_go_run_A_const_163 any

var A_arbace_go_run_A_const_164 *lang.Keyword

var A_arbace_go_run_A_const_165 *lang.Var

var A_arbace_go_run_A_const_166 any

var A_arbace_go_run_A_const_167 any

var A_arbace_go_run_A_const_168 any

var A_arbace_go_run_A_const_169 *lang.Var

var A_arbace_go_run_A_const_170 any

var A_arbace_go_run_A_const_171 *lang.Var

var A_arbace_go_run_A_const_172 *lang.Var

var A_arbace_go_run_A_const_173 *lang.Var

var A_arbace_go_run_A_const_174 any

var A_arbace_go_run_A_const_175 *lang.Var

var A_arbace_go_run_A_const_176 any

var A_arbace_go_run_A_const_177 *lang.Var

var A_arbace_go_run_A_const_178 *lang.Keyword

var A_arbace_go_run_A_const_179 *lang.Keyword

var A_arbace_go_run_A_const_180 *lang.Var

var A_arbace_go_run_A_const_181 *lang.Var

var A_arbace_go_run_A_const_182 *lang.Keyword

var A_arbace_go_run_A_const_183 *lang.Var

var A_arbace_go_run_A_const_184 *lang.Keyword

var A_arbace_go_run_A_const_185 *lang.Keyword

var A_arbace_go_run_A_const_186 *lang.Var

var A_arbace_go_run_A_const_187 any

var A_arbace_go_run_A_const_188 *lang.Keyword

var A_arbace_go_run_A_const_189 *lang.Keyword

var A_arbace_go_run_A_const_190 *lang.Var

var A_arbace_go_run_A_init jrt.ClassInit

func A_arbace_go_run_A_Init() { if !A_arbace_go_run_A_init.Done() { A_arbace_go_run_A_init.Run(A_arbace_go_run_A_clinit) } }

func A_arbace_go_run_A_clinit() { A_arbace_go_run_A_clinit_p0(); A_arbace_go_run_A_clinit_p1(); A_arbace_go_run_A_clinit_p2(); A_arbace_go_run_A_clinit_p3(); A_arbace_go_run_A_clinit_p4(); A_arbace_go_run_A_clinit_p5(); A_arbace_go_run_A_clinit_p6(); A_arbace_go_run_A_clinit_p7(); A_arbace_go_run_A_clinit_p8(); A_arbace_go_run_A_clinit_p9(); A_arbace_go_run_A_clinit_p10(); A_arbace_go_run_A_clinit_p11(); A_arbace_go_run_A_clinit_p12(); A_arbace_go_run_A_clinit_p13(); A_arbace_go_run_A_clinit_p14(); A_arbace_go_run_A_clinit_p15() }

func A_arbace_go_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 256); A_arbace_go_run_A_const_0 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[65]); A_arbace_go_run_A_const_1 = A_arbace_go_run_A_const_pool.A[66]; A_arbace_go_run_A_const_2 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[67]); A_arbace_go_run_A_const_3 = A_arbace_go_run_A_const_pool.A[68]; A_arbace_go_run_A_const_4 = A_arbace_go_run_A_const_pool.A[69]; A_arbace_go_run_A_const_5 = A_arbace_go_run_A_const_pool.A[70]; A_arbace_go_run_A_const_6 = A_arbace_go_run_A_const_pool.A[71]; A_arbace_go_run_A_const_7 = A_arbace_go_run_A_const_pool.A[72]; A_arbace_go_run_A_const_8 = A_arbace_go_run_A_const_pool.A[73]; A_arbace_go_run_A_const_9 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[74]); A_arbace_go_run_A_const_10 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[75]); A_arbace_go_run_A_const_11 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[76]); A_arbace_go_run_A_const_12 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[77]) }

func A_arbace_go_run_A_clinit_p1() { A_arbace_go_run_A_const_13 = A_arbace_go_run_A_const_pool.A[78]; A_arbace_go_run_A_const_14 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[79]); A_arbace_go_run_A_const_15 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[80]); A_arbace_go_run_A_const_16 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[81]); A_arbace_go_run_A_const_17 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[82]); A_arbace_go_run_A_const_18 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[83]); A_arbace_go_run_A_const_19 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[84]); A_arbace_go_run_A_const_20 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[85]); A_arbace_go_run_A_const_21 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[86]); A_arbace_go_run_A_const_22 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[87]); A_arbace_go_run_A_const_23 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[88]); A_arbace_go_run_A_const_24 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[89]) }

func A_arbace_go_run_A_clinit_p2() { A_arbace_go_run_A_const_25 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[90]); A_arbace_go_run_A_const_26 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[91]); A_arbace_go_run_A_const_27 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[92]); A_arbace_go_run_A_const_28 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[93]); A_arbace_go_run_A_const_29 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[94]); A_arbace_go_run_A_const_30 = A_arbace_go_run_A_const_pool.A[95]; A_arbace_go_run_A_const_31 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[96]); A_arbace_go_run_A_const_32 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[97]); A_arbace_go_run_A_const_33 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[98]); A_arbace_go_run_A_const_34 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[99]); A_arbace_go_run_A_const_35 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[100]); A_arbace_go_run_A_const_36 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[101]) }

func A_arbace_go_run_A_clinit_p3() { A_arbace_go_run_A_const_37 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[102]); A_arbace_go_run_A_const_38 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[103]); A_arbace_go_run_A_const_39 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[104]); A_arbace_go_run_A_const_40 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[105]); A_arbace_go_run_A_const_41 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[106]); A_arbace_go_run_A_const_42 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[107]); A_arbace_go_run_A_const_43 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[108]); A_arbace_go_run_A_const_44 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[109]); A_arbace_go_run_A_const_45 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[110]); A_arbace_go_run_A_const_46 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[111]); A_arbace_go_run_A_const_47 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[112]); A_arbace_go_run_A_const_48 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[113]) }

func A_arbace_go_run_A_clinit_p4() { A_arbace_go_run_A_const_49 = A_arbace_go_run_A_const_pool.A[114]; A_arbace_go_run_A_const_50 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[115]); A_arbace_go_run_A_const_51 = A_arbace_go_run_A_const_pool.A[116]; A_arbace_go_run_A_const_52 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[117]); A_arbace_go_run_A_const_53 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[118]); A_arbace_go_run_A_const_54 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[119]); A_arbace_go_run_A_const_55 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[120]); A_arbace_go_run_A_const_56 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[121]); A_arbace_go_run_A_const_57 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[122]); A_arbace_go_run_A_const_58 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[123]); A_arbace_go_run_A_const_59 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[124]); A_arbace_go_run_A_const_60 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[125]) }

func A_arbace_go_run_A_clinit_p5() { A_arbace_go_run_A_const_61 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[126]); A_arbace_go_run_A_const_62 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[127]); A_arbace_go_run_A_const_63 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[128]); A_arbace_go_run_A_const_64 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[129]); A_arbace_go_run_A_const_65 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[130]); A_arbace_go_run_A_const_66 = A_arbace_go_run_A_const_pool.A[131]; A_arbace_go_run_A_const_67 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[132]); A_arbace_go_run_A_const_68 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[133]); A_arbace_go_run_A_const_69 = A_arbace_go_run_A_const_pool.A[134]; A_arbace_go_run_A_const_70 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[135]); A_arbace_go_run_A_const_71 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[136]); A_arbace_go_run_A_const_72 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[137]) }

func A_arbace_go_run_A_clinit_p6() { A_arbace_go_run_A_const_73 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[138]); A_arbace_go_run_A_const_74 = A_arbace_go_run_A_const_pool.A[139]; A_arbace_go_run_A_const_75 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[140]); A_arbace_go_run_A_const_76 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[141]); A_arbace_go_run_A_const_77 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[142]); A_arbace_go_run_A_const_78 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[143]); A_arbace_go_run_A_const_79 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[144]); A_arbace_go_run_A_const_80 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[145]); A_arbace_go_run_A_const_81 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[146]); A_arbace_go_run_A_const_82 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[147]); A_arbace_go_run_A_const_83 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[148]); A_arbace_go_run_A_const_84 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[149]) }

func A_arbace_go_run_A_clinit_p7() { A_arbace_go_run_A_const_85 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[150]); A_arbace_go_run_A_const_86 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[151]); A_arbace_go_run_A_const_87 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[152]); A_arbace_go_run_A_const_88 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[153]); A_arbace_go_run_A_const_89 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[154]); A_arbace_go_run_A_const_90 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[155]); A_arbace_go_run_A_const_91 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[156]); A_arbace_go_run_A_const_92 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[157]); A_arbace_go_run_A_const_93 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[158]); A_arbace_go_run_A_const_94 = A_arbace_go_run_A_const_pool.A[159]; A_arbace_go_run_A_const_95 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[160]); A_arbace_go_run_A_const_96 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[161]) }

func A_arbace_go_run_A_clinit_p8() { A_arbace_go_run_A_const_97 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[162]); A_arbace_go_run_A_const_98 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[163]); A_arbace_go_run_A_const_99 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[164]); A_arbace_go_run_A_const_100 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[165]); A_arbace_go_run_A_const_101 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[166]); A_arbace_go_run_A_const_102 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[167]); A_arbace_go_run_A_const_103 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[168]); A_arbace_go_run_A_const_104 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[169]); A_arbace_go_run_A_const_105 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[170]); A_arbace_go_run_A_const_106 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[171]); A_arbace_go_run_A_const_107 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[172]); A_arbace_go_run_A_const_108 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[173]) }

func A_arbace_go_run_A_clinit_p9() { A_arbace_go_run_A_const_109 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[174]); A_arbace_go_run_A_const_110 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[175]); A_arbace_go_run_A_const_111 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[176]); A_arbace_go_run_A_const_112 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[177]); A_arbace_go_run_A_const_113 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[178]); A_arbace_go_run_A_const_114 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[179]); A_arbace_go_run_A_const_115 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[180]); A_arbace_go_run_A_const_116 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[181]); A_arbace_go_run_A_const_117 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[182]); A_arbace_go_run_A_const_118 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[183]); A_arbace_go_run_A_const_119 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[184]); A_arbace_go_run_A_const_120 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[185]) }

func A_arbace_go_run_A_clinit_p10() { A_arbace_go_run_A_const_121 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[186]); A_arbace_go_run_A_const_122 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[187]); A_arbace_go_run_A_const_123 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[188]); A_arbace_go_run_A_const_124 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[189]); A_arbace_go_run_A_const_125 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[190]); A_arbace_go_run_A_const_126 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[191]); A_arbace_go_run_A_const_127 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[192]); A_arbace_go_run_A_const_128 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[193]); A_arbace_go_run_A_const_129 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[194]); A_arbace_go_run_A_const_130 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[195]); A_arbace_go_run_A_const_131 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[196]); A_arbace_go_run_A_const_132 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[197]) }

func A_arbace_go_run_A_clinit_p11() { A_arbace_go_run_A_const_133 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[198]); A_arbace_go_run_A_const_134 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[199]); A_arbace_go_run_A_const_135 = A_arbace_go_run_A_const_pool.A[200]; A_arbace_go_run_A_const_136 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[201]); A_arbace_go_run_A_const_137 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[202]); A_arbace_go_run_A_const_138 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[203]); A_arbace_go_run_A_const_139 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[204]); A_arbace_go_run_A_const_140 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[205]); A_arbace_go_run_A_const_141 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[206]); A_arbace_go_run_A_const_142 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[207]); A_arbace_go_run_A_const_143 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[208]); A_arbace_go_run_A_const_144 = A_arbace_go_run_A_const_pool.A[209] }

func A_arbace_go_run_A_clinit_p12() { A_arbace_go_run_A_const_145 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[210]); A_arbace_go_run_A_const_146 = A_arbace_go_run_A_const_pool.A[211]; A_arbace_go_run_A_const_147 = A_arbace_go_run_A_const_pool.A[212]; A_arbace_go_run_A_const_148 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[213]); A_arbace_go_run_A_const_149 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[214]); A_arbace_go_run_A_const_150 = A_arbace_go_run_A_const_pool.A[215]; A_arbace_go_run_A_const_151 = A_arbace_go_run_A_const_pool.A[216]; A_arbace_go_run_A_const_152 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[217]); A_arbace_go_run_A_const_153 = A_arbace_go_run_A_const_pool.A[218]; A_arbace_go_run_A_const_154 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[219]); A_arbace_go_run_A_const_155 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[220]); A_arbace_go_run_A_const_156 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[221]); A_arbace_go_run_A_const_157 = A_arbace_go_run_A_const_pool.A[222] }

func A_arbace_go_run_A_clinit_p13() { A_arbace_go_run_A_const_158 = A_arbace_go_run_A_const_pool.A[223]; A_arbace_go_run_A_const_159 = A_arbace_go_run_A_const_pool.A[224]; A_arbace_go_run_A_const_160 = A_arbace_go_run_A_const_pool.A[225]; A_arbace_go_run_A_const_161 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[226]); A_arbace_go_run_A_const_162 = A_arbace_go_run_A_const_pool.A[227]; A_arbace_go_run_A_const_163 = A_arbace_go_run_A_const_pool.A[228]; A_arbace_go_run_A_const_164 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[229]); A_arbace_go_run_A_const_165 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[230]); A_arbace_go_run_A_const_166 = A_arbace_go_run_A_const_pool.A[231]; A_arbace_go_run_A_const_167 = A_arbace_go_run_A_const_pool.A[232]; A_arbace_go_run_A_const_168 = A_arbace_go_run_A_const_pool.A[233]; A_arbace_go_run_A_const_169 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[234]); A_arbace_go_run_A_const_170 = A_arbace_go_run_A_const_pool.A[235]; A_arbace_go_run_A_const_171 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[236]) }

func A_arbace_go_run_A_clinit_p14() { A_arbace_go_run_A_const_172 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[237]); A_arbace_go_run_A_const_173 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[238]); A_arbace_go_run_A_const_174 = A_arbace_go_run_A_const_pool.A[239]; A_arbace_go_run_A_const_175 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[240]); A_arbace_go_run_A_const_176 = A_arbace_go_run_A_const_pool.A[241]; A_arbace_go_run_A_const_177 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[242]); A_arbace_go_run_A_const_178 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[243]); A_arbace_go_run_A_const_179 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[244]); A_arbace_go_run_A_const_180 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[245]); A_arbace_go_run_A_const_181 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[246]); A_arbace_go_run_A_const_182 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[247]); A_arbace_go_run_A_const_183 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[248]) }

func A_arbace_go_run_A_clinit_p15() { A_arbace_go_run_A_const_184 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[249]); A_arbace_go_run_A_const_185 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[250]); A_arbace_go_run_A_const_186 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[251]); A_arbace_go_run_A_const_187 = A_arbace_go_run_A_const_pool.A[252]; A_arbace_go_run_A_const_188 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[253]); A_arbace_go_run_A_const_189 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[254]); A_arbace_go_run_A_const_190 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[255]) }

func A_arbace_go_run_A_New() *A_arbace_go_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_A) Ctor() {}

func (t *A_arbace_go_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_A_class }

func (t *A_arbace_go_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_A); return ok }

func A_arbace_go_run_A_Cast(x any) *A_arbace_go_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_A_class)) }; return v }



type A_arbace_go_run__main_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000252_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_run__main_fn__1938000252_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000255_A struct{ j2g_header uint64; F_lang, F_pf, F_root, F_opts any }

var A_arbace_go_run__main_fn__1938000255_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000260_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000260_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000262_A struct{ j2g_header uint64; F_pargs, F_pf, F_root any }

var A_arbace_go_run__main_fn__1938000262_A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__fn__1938000065_A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A struct{ j2g_header uint64; F_iter__1938000020, F_s__1938000021 any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A struct{ j2g_header uint64; F_b__1938000023 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_root_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_root_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000186_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000186_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000186_fn__1938000187_fn__1938000189_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000193_A struct{ j2g_header uint64; F_src any }

var A_arbace_go_run_errorcheck_fn__1938000193_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000193_fn__1938000194_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000197_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000197_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000199_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000199_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000202_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000202_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000204_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000204_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_iter__1938000206__1938000210_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A struct{ j2g_header uint64; F_s__1938000207, F_iter__1938000206 any }

var A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A struct{ j2g_header uint64; F_b__1938000209 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000206__1938000210_fn__1938000211_fn__1938000212_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A struct{ j2g_header uint64; F_relocate, F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000226__1938000230_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A struct{ j2g_header uint64; F_s__1938000227, F_iter__1938000226, F_relocate, F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A struct{ j2g_header uint64; F_b__1938000229, F_relocate, F_vmsg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000226__1938000230_fn__1938000231_fn__1938000232_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_pos__1938000236_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_pos__1938000236_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_relocate__1938000218_A struct{ j2g_header uint64; F_lmap any }

var A_arbace_go_run_errorcheck_relocate__1938000218_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_vmsg__1938000216_A struct{ j2g_header uint64; F_file_lang, F_lang, F_src any }

var A_arbace_go_run_errorcheck_vmsg__1938000216_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000004_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000004_A_New() *A_arbace_go_run_eval1938000004_A { t := &A_arbace_go_run_eval1938000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000004_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000004_A_class }

func (t *A_arbace_go_run_eval1938000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000004_A); return ok }

func A_arbace_go_run_eval1938000004_A_Cast(x any) *A_arbace_go_run_eval1938000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000004_A_class)) }; return v }



type A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000008_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000008_A_New() *A_arbace_go_run_eval1938000008_A { t := &A_arbace_go_run_eval1938000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000008_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000008_A_class }

func (t *A_arbace_go_run_eval1938000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000008_A); return ok }

func A_arbace_go_run_eval1938000008_A_Cast(x any) *A_arbace_go_run_eval1938000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000008_A_class)) }; return v }



type A_arbace_go_run_eval1938000008_fn__1938000009_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_fn_class *jrt.Class



type A_arbace_go_run_fail_A struct{ j2g_header uint64 }

var A_arbace_go_run_fail_A_fn_class *jrt.Class



type A_arbace_go_run_fail_fn__1938000012_A struct{ j2g_header uint64; F_kind, F_msg any }

var A_arbace_go_run_fail_fn__1938000012_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_A struct{ j2g_header uint64 }

var A_arbace_go_run_imports_of_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A struct{ j2g_header uint64; F_s__1938000069, F_iter__1938000068, F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A struct{ j2g_header uint64; F_s__1938000071, F_li, F_iter__1938000070 any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A struct{ j2g_header uint64; F_b__1938000073, F_li any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_A struct{ j2g_header uint64 }

var A_arbace_go_run_line_map_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000160_A struct{ j2g_header uint64 }

var A_arbace_go_run_line_map_fn__1938000160_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000162_A struct{ j2g_header uint64 }

var A_arbace_go_run_line_map_fn__1938000162_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000164_A struct{ j2g_header uint64; F_ls any }

var A_arbace_go_run_line_map_fn__1938000164_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000172_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_run_line_map_fn__1938000172_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A struct{ j2g_header uint64; F_line int64 }

var A_arbace_go_run_line_map_fn__1938000172_fn__1938000173_A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__fn__1938000032_A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class *jrt.Class



type A_arbace_go_run_no_linkname_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_linkname_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__fn__1938000016_A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000122_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000134_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_A struct{ j2g_header uint64; F_l, F_apos, F_end any }

var A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A struct{ j2g_header uint64; F_iter__1938000139, F_s__1938000140 any }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A struct{ j2g_header uint64; F_b__1938000142 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000129_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_walk_meta__1938000116_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class *jrt.Class



type A_arbace_go_run_run_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_A struct{ j2g_header uint64; F_srcs, F_inits, F_deps any }

var A_arbace_go_run_run_define__1938000091_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000092_A struct{ j2g_header uint64; F_src, F_r, F_st any }

var A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000094_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class *jrt.Class



type A_arbace_go_run_run_extra__1938000089_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_extra__1938000089_A_fn_class *jrt.Class



type A_arbace_go_run_run_fn__1938000087_A struct{ j2g_header uint64; F_pf any }

var A_arbace_go_run_run_fn__1938000087_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000097_A struct{ j2g_header uint64; F_inits, F_deps any }

var A_arbace_go_run_run_init_order__1938000097_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A struct{ j2g_header uint64; F_done, F_deps any }

var A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class *jrt.Class



type A_arbace_go_run_run_load_BANG___1938000101_A struct{ j2g_header uint64; F_root, F_extra, F_srcs, F_index, F_define any }

var A_arbace_go_run_run_load_BANG___1938000101_A_fn_class *jrt.Class
