//line aot_arbace_go_run.ae:1
package aot_arbace_go_run

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_New() *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_1); lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_go_run_A_const_3, A_arbace_go_run_A_const_4, A_arbace_go_run_A_const_5, A_arbace_go_run_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_run_eval1938000008_fn__1938000009_A_New() *A_arbace_go_run_eval1938000008_fn__1938000009_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000008_fn__1938000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_go_run_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_run_A_const_10.GetRawRoot__O(), A_arbace_go_run_A_const_11) }

















func A_arbace_go_run_fail_A_New() *A_arbace_go_run_fail_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_run_fail_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_run_fail_A) Invoke_O_O_O_O__O(self, status__0, kind__1, msg__2 any) any {
	var root_45 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_20; var arg_48 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_21.Get__O()); if linked_46 == nil { ifn_47.Invoke_O__O(arg_48) } else { linked_46.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_45, arg_48) }; var tmp3 any = A_arbace_go_run_fail_fn__1938000012_A_New_O_O(kind__1, msg__2); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_run_fail_fn__1938000012_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_run_fail_fn__1938000012_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__0)); return nil }
//line :20:1
func A_arbace_go_run_fail_fn__1938000012_A_New_O_O(p0, p1 any) *A_arbace_go_run_fail_fn__1938000012_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_fn__1938000012_A{}; t.Ctor_O_O(p0, p1); return t }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Ctor_O_O(c__kind, c__msg any) { t.F_kind = c__kind; t.F_msg = c__msg }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_9, nil); var tmp4 any; var t_ any = t.F_kind; t.F_kind = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var root_32 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_36 any = A_arbace_go_run_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var root_40 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var t__2 any = t.F_msg; t.F_msg = nil; arg_43 = t__2; if linked_41 == nil { arg_39 = ifn_42.Invoke_O__O(arg_43) } else { arg_39 = linked_41.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_40, arg_43) }; if linked_37 == nil { arg_35 = ifn_38.Invoke_O__O(arg_39) } else { arg_35 = linked_37.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_36, arg_39) }; if linked_33 == nil { tmp6 = ifn_34.Invoke_O__O(arg_35) } else { tmp6 = linked_33.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_32, arg_35) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref())
											var root_22 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; if linked_23 == nil { tmp1 = ifn_24.Invoke__O() } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_22) } }
//line :20:1
	return nil }(); var root_25 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; if linked_26 == nil { ifn_27.Invoke__O() } else { linked_26.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_25) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_go_run_package_file_QMARK__A_New() *A_arbace_go_run_package_file_QMARK__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(f__0)).IsFile__Z(); if and__1927000168__auto____2 {
											var and__1927000168__auto____3 any; var root_54 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(); var arg_58 any = Lit_32; if linked_55 == nil { and__1927000168__auto____3 = ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { and__1927000168__auto____3 = linked_55.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_54, arg_57, arg_58) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var r__4 any = jrt.BufferedReader_New_Reader(jrt.FileReader_New_File(jrt.File_Cast(f__0))); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__7 any; var root_59 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_61 lang.IFn

		if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_63 any = A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var tmp2 any = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; arg_66 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_67 any; var root_78 any = A_arbace_go_run_A_const_26.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = r__4; if linked_79 == nil { arg_67 = ifn_80.Invoke_O__O(arg_81) } else { arg_67 = linked_79.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_78, arg_81) }; if linked_64 == nil { arg_62 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { arg_62 = linked_64.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if linked_60 == nil { l__7 = ifn_61.Invoke_O__O(arg_62) } else { l__7 = linked_60.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_59, arg_62) }
		var tmp4 any; var and__1927000168__auto____8 any = l__7; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_82 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = l__7; var arg_86 any = Lit_34; if linked_83 == nil { tmp4 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { tmp4 = linked_83.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_82, arg_85, arg_86) } } else { tmp4 = and__1927000168__auto____8 }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref() }; return nil }()
//line :27:1
		jrt.BufferedReader_Cast(r__4).Close__V()
//line :26:1
		if tmp5 != nil { panic(tmp5) }; return tmp1 } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New() *A_arbace_go_run_package_file_QMARK__fn__1938000016_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__fn__1938000016_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Ctor() {}
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Invoke_O_O__O(self, p1__1938000015_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_68 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = p1__1938000015_SHARP___1; if linked_69 == nil { or__1927000174__auto____2 = ifn_70.Invoke_O__O(arg_71) } else { or__1927000174__auto____2 = linked_69.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_72 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = p1__1938000015_SHARP___1; var arg_76 any = Lit_35; if linked_73 == nil { return ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { return linked_73.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_72, arg_75, arg_76) } } }


func A_arbace_go_run_dir_test_root_A_New() *A_arbace_go_run_dir_test_root_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_root_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Invoke_O_O__O(self, pf__0 any) any { { var n__2 any = jrt.NN(jrt.File_Cast(pf__0)).GetName__String().Ref(); var sib__3 any; var tmp1 *jrt.File = jrt.NN(jrt.File_Cast(pf__0)).GetParentFile__File(); var tmp2 any; var root_87 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_89 lang.IFn




	if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = n__2; var arg_91 any = A_arbace_go_run_A_const_28; var arg_92 any = Lit_15; if linked_88 == nil { tmp2 = ifn_89.Invoke_O_O_O__O(arg_90, arg_91, arg_92) } else { tmp2 = linked_88.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_87, arg_90, arg_91, arg_92) }
//line :31:1
	sib__3 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2))





	var tmp3 any; var and__1927000168__auto____4 any; var root_93 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = n__2; var arg_97 any = Lit_16; if linked_94 == nil { and__1927000168__auto____4 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { and__1927000168__auto____4 = linked_94.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(sib__3)).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { return sib__3 } else { var d__4 any = jrt.NN(jrt.File_Cast(pf__0)).GetParentFile__File().Ref(); L1: for {


		if lang.Util_Identical_O_O__Z_NoInit(d__4, nil) { return nil } else { var tmp4 any; var root_98 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_100 lang.IFn

			if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = jrt.NN(jrt.File_Cast(d__4)).GetName__String().Ref(); var arg_102 any = Lit_17; if linked_99 == nil { tmp4 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { tmp4 = linked_99.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }
//line :40:1
			if jrt.J2g_Truth(tmp4) { return d__4 } else { if A_arbace_go_run_A_const_29 != nil {


				d__4 = jrt.NN(jrt.File_Cast(d__4)).GetParentFile__File().Ref(); continue L1 } else {
//line :40:1
					return nil } } } } } }; /*line :31:1*/panic("j2g: unreachable") }













func A_arbace_go_run_dir_test_index_A_New() *A_arbace_go_run_dir_test_index_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Ctor() {}
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Invoke_O_O__O(self, pf__0 any) any { var temp__1927000408__auto____2 any; var root_103 any = A_arbace_go_run_A_const_30.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, A_arbace_go_run_dir_test_root_A_fn_class); var ifn_105 lang.IFn; if



	linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = pf__0; if linked_104 == nil { temp__1927000408__auto____2 = ifn_105.Invoke_O__O(arg_106) } else { temp__1927000408__auto____2 = linked_104.(*A_arbace_go_run_dir_test_root_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var root_107 any = A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_109 lang.IFn
		if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_111 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New(); var tmp2 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class
		if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class = fncls__194d; tmp2 = fncls__194d } else { tmp2 = fncls__194 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_195 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = pf__0; var arg_199 any; var root_200 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = d__3; if linked_201 == nil { arg_199 = ifn_202.Invoke_O__O(arg_203) } else { arg_199 = linked_201.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_200, arg_203) }; if linked_196 == nil { tmp4 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { tmp4 = linked_196.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }; arg_111 = tmp3.Invoke_O__O(tmp4)
//line :50:1
		if linked_108 == nil { return ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { return linked_108.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } } else {
//line :49:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }

func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New() *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Invoke_O_O__O(self, s__1938000021__1 any) any { var tmp1 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(self, s__1938000021__1); var tmp2 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class = fncls__193d; tmp2 = fncls__193d } else { tmp2 = fncls__193 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(p0, p1 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Ctor_O_O(c__iter__1938000020, c__s__1938000021 any) { t.F_iter__1938000020 = c__iter__1938000020; t.F_s__1938000021 = c__s__1938000021 }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Invoke_O__O(self any) any { { var s__1938000021__1 any; var t_ any = t.F_s__1938000021; t.F_s__1938000021 = nil; s__1938000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_112 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = s__1938000021__1; if linked_113 == nil { temp__1927000414__auto____2 = ifn_114.Invoke_O__O(arg_115) } else { temp__1927000414__auto____2 = linked_113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_116 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__1938000021__3; if linked_117 == nil { tmp1 = ifn_118.Invoke_O__O(arg_119) } else { tmp1 = linked_117.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_120 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__1938000021__3; if linked_121 == nil { c__1927001037__auto____4 = ifn_122.Invoke_O__O(arg_123) } else { c__1927001037__auto____4 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_120, arg_123) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000023__6 any; var root_124 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_125 == nil { b__1938000023__6 = ifn_126.Invoke_O__O(arg_127) } else { b__1938000023__6 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_124, arg_127) }; var tmp2 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(b__1938000023__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_142 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_147 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = b__1938000023__6; if linked_148 == nil { arg_145 = ifn_149.Invoke_O__O(arg_150) } else { arg_145 = linked_148.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_147, arg_150) }; var arg_146 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp5 any; var root_151 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__1938000021__3; if linked_152 == nil { tmp5 = ifn_153.Invoke_O__O(arg_154) } else { tmp5 = linked_152.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_151, arg_154) }; arg_146 = tmp4.Invoke_O__O(tmp5); if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } } else { var root_155 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_160 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = b__1938000023__6; if linked_161 == nil { arg_158 = ifn_162.Invoke_O__O(arg_163) } else { arg_158 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_160, arg_163) }; var arg_159 any; if linked_156 == nil { return ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { return linked_156.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) } } } else { var f__4 any; var root_164 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__1938000021__3; if linked_165 == nil { f__4 = ifn_166.Invoke_O__O(arg_167) } else { f__4 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; var tmp6 any; var root_168 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_170 lang.IFn
															if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = f__4; if linked_169 == nil { tmp6 = ifn_170.Invoke_O__O(arg_171) } else { tmp6 = linked_169.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_168, arg_171) }
//line :51:1
	if jrt.J2g_Truth(tmp6) { var p__5 any; var root_172 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_174 lang.IFn

		if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = f__4; if linked_173 == nil { p__5 = ifn_174.Invoke_O__O(arg_175) } else { p__5 = linked_173.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_172, arg_175) }
//line :51:1
		if jrt.J2g_Truth(p__5) { var root_176 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = lang.Tuple_Create_O_O__IPersistentVector(p__5, f__4); var arg_180 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp8 any; var root_181 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = s__1938000021__3; if linked_182 == nil { tmp8 = ifn_183.Invoke_O__O(arg_184) } else { tmp8 = linked_182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_181, arg_184) }; arg_180 = tmp7.Invoke_O__O(tmp8); if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) } } else { var tmp9 any; var root_185 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = s__1938000021__3; if linked_186 == nil { tmp9 = ifn_187.Invoke_O__O(arg_188) } else { tmp9 = linked_186.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_185, arg_188) }; s__1938000021__1 = tmp9; continue L1 } } else { var tmp10 any; var root_189 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__1938000021__3; if linked_190 == nil { tmp10 = ifn_191.Invoke_O__O(arg_192) } else { tmp10 = linked_190.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_189, arg_192) }; s__1938000021__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Ctor_O_I_O(c__b__1938000023 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000023 = c__b__1938000023; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Invoke_O__O(self any) any { { var i__1938000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000022__1)); var tmp2 any; var root_128 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_130 lang.IFn
																if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = f__2; if linked_129 == nil { tmp2 = ifn_130.Invoke_O__O(arg_131) } else { tmp2 = linked_129.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_128, arg_131) }
//line :51:1
	if jrt.J2g_Truth(tmp2) { var p__3 any; var root_132 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_134 lang.IFn

		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__2; if linked_133 == nil { p__3 = ifn_134.Invoke_O__O(arg_135) } else { p__3 = linked_133.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_132, arg_135) }
//line :51:1
		if jrt.J2g_Truth(p__3) { var root_136 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t.F_b__1938000023; var arg_140 any = lang.Tuple_Create_O_O__IPersistentVector(p__3, f__2); if linked_137 == nil { ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { linked_137.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_run_no_assembly_BANG__A_New() *A_arbace_go_run_no_assembly_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Ctor() {}
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Invoke_O_O__O(self, src__0 any) any { var temp__1927000414__auto____2 any; var root_204 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_206 lang.IFn; if
											linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var tmp1 any = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New(); var tmp2 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class = fncls__218d; tmp2 = fncls__218d } else { tmp2 = fncls__218 }; arg_207 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_208 any; var root_219 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = src__0; var arg_223 any = A_arbace_go_run_A_const_47; if linked_220 == nil { arg_208 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { arg_208 = linked_220.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; if linked_205 == nil { temp__1927000414__auto____2 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { temp__1927000414__auto____2 = linked_205.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; var root_224 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_run_fail_A_fn_class); var ifn_226 lang.IFn
												if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = A_arbace_go_run_A_const_49; var arg_228 any = Lit_8; var arg_229 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, s__3, nil)).Ref(); if linked_225 == nil { return ifn_226.Invoke_O_O_O__O(arg_227, arg_228, arg_229) } else { return linked_225.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_224, arg_227, arg_228, arg_229) } } else {
//line :59:1
			return nil } }
//line :59:1
func A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New() *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Ctor() {}
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Invoke_O_O__O(self, p1__1938000031_SHARP___1 any) any { var tmp1 any; var root_209 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var root_214 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = p1__1938000031_SHARP___1; if linked_215 == nil { arg_212 = ifn_216.Invoke_O__O(arg_217) } else { arg_212 = linked_215.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_214, arg_217) }; var arg_213 any = Lit_30; if linked_210 == nil { tmp1 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp1 = linked_210.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(tmp1) { return p1__1938000031_SHARP___1 } else { return nil } }


func A_arbace_go_run_no_linkname_BANG__A_New() *A_arbace_go_run_no_linkname_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_linkname_BANG__A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Ctor() {}
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Invoke_O_O__O(self, src__0 any) any { { var seq_1938000035__2 any; var root_230 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_232 lang.IFn
											if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__0); if linked_231 == nil { seq_1938000035__2 = ifn_232.Invoke_O__O(arg_233) } else { seq_1938000035__2 = linked_231.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_230, arg_233) }
//line :62:1
	var chunk_1938000036__3 any; var count_1938000037__4 int64 = 0; var i_1938000038__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000038__5, count_1938000037__4) { var fi__6 any = lang.Indexed_Cast(chunk_1938000036__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000038__5)); var seq_1938000051__7 any; var root_250 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__6); if linked_251 == nil { seq_1938000051__7 = ifn_252.Invoke_O__O(arg_253) } else { seq_1938000051__7 = linked_251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_250, arg_253) }; var chunk_1938000052__8 any; var count_1938000053__9 int64 = 0; var i_1938000054__10 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000054__10, count_1938000053__9) { var d__11 any = lang.Indexed_Cast(chunk_1938000052__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000054__10)); var seq_1938000059__12 any; var root_270 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any; var root_274 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_276 lang.IFn
			if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_278 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_279 any = d__11; if linked_275 == nil { arg_273 = ifn_276.Invoke_O_O_O__O(arg_277, arg_278, arg_279) } else { arg_273 = linked_275.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_274, arg_277, arg_278, arg_279) }
//line :63:1
			if linked_271 == nil { seq_1938000059__12 = ifn_272.Invoke_O__O(arg_273) } else { seq_1938000059__12 = linked_271.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_270, arg_273) }; var chunk_1938000060__13 any; var count_1938000061__14 int64 = 0; var i_1938000062__15 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000062__15, count_1938000061__14) { var x__16 any = lang.Indexed_Cast(chunk_1938000060__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000062__15)); var tmp1 any; var and__1927000168__auto____17 bool = lang.IObj_InstanceOf(x__16)

				if and__1927000168__auto____17 { var tmp2 *lang.Keyword = A_arbace_go_run_A_const_55; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() }
//line :63:1
				if jrt.J2g_Truth(tmp1) {


					var root_296 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_go_run_fail_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = A_arbace_go_run_A_const_49; var arg_300 any = Lit_8; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_301 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)), nil)).Ref(); if linked_297 == nil { ifn_298.Invoke_O_O_O__O(arg_299, arg_300, arg_301) } else { linked_297.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_296, arg_299, arg_300, arg_301) }
//line :63:1
					seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } else { seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } } else { var temp__1927000414__auto____16 any; var root_280 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = seq_1938000059__12; if linked_281 == nil { temp__1927000414__auto____16 = ifn_282.Invoke_O__O(arg_283) } else { temp__1927000414__auto____16 = linked_281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_280, arg_283) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1938000059__17 any = temp__1927000414__auto____16; var tmp4 any; var root_284 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = seq_1938000059__17; if linked_285 == nil { tmp4 = ifn_286.Invoke_O__O(arg_287) } else { tmp4 = linked_285.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_284, arg_287) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_288 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = seq_1938000059__17; if linked_289 == nil { c__1927000678__auto____18 = ifn_290.Invoke_O__O(arg_291) } else { c__1927000678__auto____18 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_288, arg_291) }; var tmp5 any; var root_302 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = seq_1938000059__17; if linked_303 == nil { tmp5 = ifn_304.Invoke_O__O(arg_305) } else { tmp5 = linked_303.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_302, arg_305) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var x__18 any; var root_292 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1938000059__17; if linked_293 == nil { x__18 = ifn_294.Invoke_O__O(arg_295) } else { x__18 = linked_293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_292, arg_295) }; var tmp6 any; var and__1927000168__auto____19 bool = lang.IObj_InstanceOf(x__18)

						if and__1927000168__auto____19 { var tmp7 *lang.Keyword = A_arbace_go_run_A_const_55; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }
//line :63:1
						if jrt.J2g_Truth(tmp6) {


							var root_306 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, A_arbace_go_run_fail_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = A_arbace_go_run_A_const_49; var arg_310 any = Lit_8; var tmp8 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_311 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)), nil)).Ref(); if linked_307 == nil { ifn_308.Invoke_O_O_O__O(arg_309, arg_310, arg_311) } else { linked_307.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_306, arg_309, arg_310, arg_311) }
//line :63:1
							var tmp9 any; var root_312 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = seq_1938000059__17; if linked_313 == nil { tmp9 = ifn_314.Invoke_O__O(arg_315) } else { tmp9 = linked_313.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_312, arg_315) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp9, nil, 0, 0; continue L3 } else { var tmp10 any; var root_316 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1938000059__17; if linked_317 == nil { tmp10 = ifn_318.Invoke_O__O(arg_319) } else { tmp10 = linked_317.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_316, arg_319) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp10, nil, 0, 0; continue L3 } } } }; break L3 }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000054__10); continue L2 } else { var temp__1927000414__auto____11 any; var root_254 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1938000051__7; if linked_255 == nil { temp__1927000414__auto____11 = ifn_256.Invoke_O__O(arg_257) } else { temp__1927000414__auto____11 = linked_255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1938000051__12 any = temp__1927000414__auto____11; var tmp11 any; var root_258 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1938000051__12; if linked_259 == nil { tmp11 = ifn_260.Invoke_O__O(arg_261) } else { tmp11 = linked_259.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_262 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = seq_1938000051__12; if linked_263 == nil { c__1927000678__auto____13 = ifn_264.Invoke_O__O(arg_265) } else { c__1927000678__auto____13 = linked_263.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_262, arg_265) }; var tmp12 any; var root_320 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1938000051__12; if linked_321 == nil { tmp12 = ifn_322.Invoke_O__O(arg_323) } else { tmp12 = linked_321.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_320, arg_323) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__13 any; var root_266 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = seq_1938000051__12; if linked_267 == nil { d__13 = ifn_268.Invoke_O__O(arg_269) } else { d__13 = linked_267.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_266, arg_269) }; var seq_1938000055__14 any; var root_324 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_328 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_330 lang.IFn
								if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_332 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_333 any = d__13; if linked_329 == nil { arg_327 = ifn_330.Invoke_O_O_O__O(arg_331, arg_332, arg_333) } else { arg_327 = linked_329.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_328, arg_331, arg_332, arg_333) }
//line :63:1
								if linked_325 == nil { seq_1938000055__14 = ifn_326.Invoke_O__O(arg_327) } else { seq_1938000055__14 = linked_325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_324, arg_327) }; var chunk_1938000056__15 any; var count_1938000057__16 int64 = 0; var i_1938000058__17 int64 = 0; L4: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000058__17, count_1938000057__16) { var x__18_2 any = lang.Indexed_Cast(chunk_1938000056__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000058__17)); var tmp13 any; var and__1927000168__auto____19_2 bool = lang.IObj_InstanceOf(x__18_2)

									if and__1927000168__auto____19_2 { var tmp14 *lang.Keyword = A_arbace_go_run_A_const_55; tmp13 = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_2).Ref() }
//line :63:1
									if jrt.J2g_Truth(tmp13) {


										var root_350 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_run_fail_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = A_arbace_go_run_A_const_49; var arg_354 any = Lit_8; var tmp15 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_355 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp15.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)), nil)).Ref(); if linked_351 == nil { ifn_352.Invoke_O_O_O__O(arg_353, arg_354, arg_355) } else { linked_351.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_350, arg_353, arg_354, arg_355) }
//line :63:1
										seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } else { seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } } else { var temp__1927000414__auto____18 any; var root_334 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = seq_1938000055__14; if linked_335 == nil { temp__1927000414__auto____18 = ifn_336.Invoke_O__O(arg_337) } else { temp__1927000414__auto____18 = linked_335.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000055__19 any = temp__1927000414__auto____18; var tmp16 any; var root_338 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = seq_1938000055__19; if linked_339 == nil { tmp16 = ifn_340.Invoke_O__O(arg_341) } else { tmp16 = linked_339.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____20 any; var root_342 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = seq_1938000055__19; if linked_343 == nil { c__1927000678__auto____20 = ifn_344.Invoke_O__O(arg_345) } else { c__1927000678__auto____20 = linked_343.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_342, arg_345) }; var tmp17 any; var root_356 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = seq_1938000055__19; if linked_357 == nil { tmp17 = ifn_358.Invoke_O__O(arg_359) } else { tmp17 = linked_357.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_356, arg_359) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp17, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__20 any; var root_346 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = seq_1938000055__19; if linked_347 == nil { x__20 = ifn_348.Invoke_O__O(arg_349) } else { x__20 = linked_347.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_346, arg_349) }; var tmp18 any; var and__1927000168__auto____21 bool = lang.IObj_InstanceOf(x__20)

											if and__1927000168__auto____21 { var tmp19 *lang.Keyword = A_arbace_go_run_A_const_55; tmp18 = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)) } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }
//line :63:1
											if jrt.J2g_Truth(tmp18) {


												var root_360 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, A_arbace_go_run_fail_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = A_arbace_go_run_A_const_49; var arg_364 any = Lit_8; var tmp20 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_365 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)), nil)).Ref(); if linked_361 == nil { ifn_362.Invoke_O_O_O__O(arg_363, arg_364, arg_365) } else { linked_361.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_360, arg_363, arg_364, arg_365) }
//line :63:1
												var tmp21 any; var root_366 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = seq_1938000055__19; if linked_367 == nil { tmp21 = ifn_368.Invoke_O__O(arg_369) } else { tmp21 = linked_367.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_366, arg_369) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp21, nil, 0, 0; continue L4 } else { var tmp22 any; var root_370 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = seq_1938000055__19; if linked_371 == nil { tmp22 = ifn_372.Invoke_O__O(arg_373) } else { tmp22 = linked_371.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_370, arg_373) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp22, nil, 0, 0; continue L4 } } } }; break L4 }; var tmp23 any; var root_374 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1938000051__12; if linked_375 == nil { tmp23 = ifn_376.Invoke_O__O(arg_377) } else { tmp23 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp23, nil, 0, 0; continue L2 } } }; break L2 }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000038__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_234 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = seq_1938000035__2; if linked_235 == nil { temp__1927000414__auto____6 = ifn_236.Invoke_O__O(arg_237) } else { temp__1927000414__auto____6 = linked_235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1938000035__7 any = temp__1927000414__auto____6; var tmp24 any; var root_238 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = seq_1938000035__7; if linked_239 == nil { tmp24 = ifn_240.Invoke_O__O(arg_241) } else { tmp24 = linked_239.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____8 any; var root_242 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = seq_1938000035__7; if linked_243 == nil { c__1927000678__auto____8 = ifn_244.Invoke_O__O(arg_245) } else { c__1927000678__auto____8 = linked_243.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_242, arg_245) }; var tmp25 any; var root_378 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = seq_1938000035__7; if linked_379 == nil { tmp25 = ifn_380.Invoke_O__O(arg_381) } else { tmp25 = linked_379.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_378, arg_381) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp25, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__8 any; var root_246 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1938000035__7; if linked_247 == nil { fi__8 = ifn_248.Invoke_O__O(arg_249) } else { fi__8 = linked_247.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_246, arg_249) }; var seq_1938000039__9 any; var root_382 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__8); if linked_383 == nil { seq_1938000039__9 = ifn_384.Invoke_O__O(arg_385) } else { seq_1938000039__9 = linked_383.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_382, arg_385) }; var chunk_1938000040__10 any; var count_1938000041__11 int64 = 0; var i_1938000042__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000042__12, count_1938000041__11) { var d__13_2 any = lang.Indexed_Cast(chunk_1938000040__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000042__12)); var seq_1938000047__14 any; var root_402 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_406 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_408 lang.IFn
													if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_410 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_411 any = d__13_2; if linked_407 == nil { arg_405 = ifn_408.Invoke_O_O_O__O(arg_409, arg_410, arg_411) } else { arg_405 = linked_407.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_406, arg_409, arg_410, arg_411) }
//line :63:1
													if linked_403 == nil { seq_1938000047__14 = ifn_404.Invoke_O__O(arg_405) } else { seq_1938000047__14 = linked_403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_402, arg_405) }; var chunk_1938000048__15 any; var count_1938000049__16 int64 = 0; var i_1938000050__17 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000050__17, count_1938000049__16) { var x__18_3 any = lang.Indexed_Cast(chunk_1938000048__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000050__17)); var tmp26 any; var and__1927000168__auto____19_3 bool = lang.IObj_InstanceOf(x__18_3)

														if and__1927000168__auto____19_3 { var tmp27 *lang.Keyword = A_arbace_go_run_A_const_55; tmp26 = tmp27.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)) } else { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_3).Ref() }
//line :63:1
														if jrt.J2g_Truth(tmp26) {


															var root_428 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, A_arbace_go_run_fail_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = A_arbace_go_run_A_const_49; var arg_432 any = Lit_8; var tmp28 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_433 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp28.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)), nil)).Ref(); if linked_429 == nil { ifn_430.Invoke_O_O_O__O(arg_431, arg_432, arg_433) } else { linked_429.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_428, arg_431, arg_432, arg_433) }
//line :63:1
															seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } else { seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } } else { var temp__1927000414__auto____18_2 any; var root_412 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = seq_1938000047__14; if linked_413 == nil { temp__1927000414__auto____18_2 = ifn_414.Invoke_O__O(arg_415) } else { temp__1927000414__auto____18_2 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1938000047__19 any = temp__1927000414__auto____18_2; var tmp29 any; var root_416 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = seq_1938000047__19; if linked_417 == nil { tmp29 = ifn_418.Invoke_O__O(arg_419) } else { tmp29 = linked_417.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_416, arg_419) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____20_2 any; var root_420 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = seq_1938000047__19; if linked_421 == nil { c__1927000678__auto____20_2 = ifn_422.Invoke_O__O(arg_423) } else { c__1927000678__auto____20_2 = linked_421.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_420, arg_423) }; var tmp30 any; var root_434 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1938000047__19; if linked_435 == nil { tmp30 = ifn_436.Invoke_O__O(arg_437) } else { tmp30 = linked_435.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_434, arg_437) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp30, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__20_2 any; var root_424 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = seq_1938000047__19; if linked_425 == nil { x__20_2 = ifn_426.Invoke_O__O(arg_427) } else { x__20_2 = linked_425.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_424, arg_427) }; var tmp31 any; var and__1927000168__auto____21_2 bool = lang.IObj_InstanceOf(x__20_2)

																if and__1927000168__auto____21_2 { var tmp32 *lang.Keyword = A_arbace_go_run_A_const_55; tmp31 = tmp32.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }
//line :63:1
																if jrt.J2g_Truth(tmp31) {


																	var root_438 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_go_run_fail_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_go_run_A_const_49; var arg_442 any = Lit_8; var tmp33 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_443 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp33.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)), nil)).Ref(); if linked_439 == nil { ifn_440.Invoke_O_O_O__O(arg_441, arg_442, arg_443) } else { linked_439.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_438, arg_441, arg_442, arg_443) }
//line :63:1
																	var tmp34 any; var root_444 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = seq_1938000047__19; if linked_445 == nil { tmp34 = ifn_446.Invoke_O__O(arg_447) } else { tmp34 = linked_445.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_444, arg_447) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp34, nil, 0, 0; continue L6 } else { var tmp35 any; var root_448 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = seq_1938000047__19; if linked_449 == nil { tmp35 = ifn_450.Invoke_O__O(arg_451) } else { tmp35 = linked_449.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_448, arg_451) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp35, nil, 0, 0; continue L6 } } } }; break L6 }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000042__12); continue L5 } else { var temp__1927000414__auto____13 any; var root_386 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = seq_1938000039__9; if linked_387 == nil { temp__1927000414__auto____13 = ifn_388.Invoke_O__O(arg_389) } else { temp__1927000414__auto____13 = linked_387.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1938000039__14 any = temp__1927000414__auto____13; var tmp36 any; var root_390 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = seq_1938000039__14; if linked_391 == nil { tmp36 = ifn_392.Invoke_O__O(arg_393) } else { tmp36 = linked_391.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_390, arg_393) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____15 any; var root_394 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_1938000039__14; if linked_395 == nil { c__1927000678__auto____15 = ifn_396.Invoke_O__O(arg_397) } else { c__1927000678__auto____15 = linked_395.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_394, arg_397) }; var tmp37 any; var root_452 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1938000039__14; if linked_453 == nil { tmp37 = ifn_454.Invoke_O__O(arg_455) } else { tmp37 = linked_453.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_452, arg_455) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp37, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var d__15 any; var root_398 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_1938000039__14; if linked_399 == nil { d__15 = ifn_400.Invoke_O__O(arg_401) } else { d__15 = linked_399.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_398, arg_401) }; var seq_1938000043__16 any; var root_456 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var root_460 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_462 lang.IFn
																		if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_464 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_465 any = d__15; if linked_461 == nil { arg_459 = ifn_462.Invoke_O_O_O__O(arg_463, arg_464, arg_465) } else { arg_459 = linked_461.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_460, arg_463, arg_464, arg_465) }
//line :63:1
																		if linked_457 == nil { seq_1938000043__16 = ifn_458.Invoke_O__O(arg_459) } else { seq_1938000043__16 = linked_457.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_456, arg_459) }; var chunk_1938000044__17 any; var count_1938000045__18 int64 = 0; var i_1938000046__19 int64 = 0; L7: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000046__19, count_1938000045__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1938000044__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000046__19)); var tmp38 any; var and__1927000168__auto____21_3 bool = lang.IObj_InstanceOf(x__20_3)

																			if and__1927000168__auto____21_3 { var tmp39 *lang.Keyword = A_arbace_go_run_A_const_55; tmp38 = tmp39.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)) } else { tmp38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_3).Ref() }
//line :63:1
																			if jrt.J2g_Truth(tmp38) {


																				var root_482 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_go_run_fail_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = A_arbace_go_run_A_const_49; var arg_486 any = Lit_8; var tmp40 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_487 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp40.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)), nil)).Ref(); if linked_483 == nil { ifn_484.Invoke_O_O_O__O(arg_485, arg_486, arg_487) } else { linked_483.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_482, arg_485, arg_486, arg_487) }
//line :63:1
																				seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } else { seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } } else { var temp__1927000414__auto____20 any; var root_466 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1938000043__16; if linked_467 == nil { temp__1927000414__auto____20 = ifn_468.Invoke_O__O(arg_469) } else { temp__1927000414__auto____20 = linked_467.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_466, arg_469) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1938000043__21 any = temp__1927000414__auto____20; var tmp41 any; var root_470 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = seq_1938000043__21; if linked_471 == nil { tmp41 = ifn_472.Invoke_O__O(arg_473) } else { tmp41 = linked_471.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_470, arg_473) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____22 any; var root_474 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = seq_1938000043__21; if linked_475 == nil { c__1927000678__auto____22 = ifn_476.Invoke_O__O(arg_477) } else { c__1927000678__auto____22 = linked_475.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_474, arg_477) }; var tmp42 any; var root_488 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = seq_1938000043__21; if linked_489 == nil { tmp42 = ifn_490.Invoke_O__O(arg_491) } else { tmp42 = linked_489.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_488, arg_491) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp42, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22 any; var root_478 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = seq_1938000043__21; if linked_479 == nil { x__22 = ifn_480.Invoke_O__O(arg_481) } else { x__22 = linked_479.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_478, arg_481) }; var tmp43 any; var and__1927000168__auto____23 bool = lang.IObj_InstanceOf(x__22)

																					if and__1927000168__auto____23 { var tmp44 *lang.Keyword = A_arbace_go_run_A_const_55; tmp43 = tmp44.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)) } else { tmp43 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }
//line :63:1
																					if jrt.J2g_Truth(tmp43) {


																						var root_492 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, A_arbace_go_run_fail_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = A_arbace_go_run_A_const_49; var arg_496 any = Lit_8; var tmp45 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_497 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil, Lit_9, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)), nil)).Ref(); if linked_493 == nil { ifn_494.Invoke_O_O_O__O(arg_495, arg_496, arg_497) } else { linked_493.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_492, arg_495, arg_496, arg_497) }
//line :63:1
																						var tmp46 any; var root_498 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1938000043__21; if linked_499 == nil { tmp46 = ifn_500.Invoke_O__O(arg_501) } else { tmp46 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp46, nil, 0, 0; continue L7 } else { var tmp47 any; var root_502 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = seq_1938000043__21; if linked_503 == nil { tmp47 = ifn_504.Invoke_O__O(arg_505) } else { tmp47 = linked_503.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_502, arg_505) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp47, nil, 0, 0; continue L7 } } } }; break L7 }; var tmp48 any; var root_506 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = seq_1938000039__14; if linked_507 == nil { tmp48 = ifn_508.Invoke_O__O(arg_509) } else { tmp48 = linked_507.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_506, arg_509) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp48, nil, 0, 0; continue L5 } } }; break L5 }; var tmp49 any; var root_510 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = seq_1938000035__7; if linked_511 == nil { tmp49 = ifn_512.Invoke_O__O(arg_513) } else { tmp49 = linked_511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_510, arg_513) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp49, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :62:1*/panic("j2g: unreachable") }





func A_arbace_go_run_check_BANG__A_New() *A_arbace_go_run_check_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Ctor() {}
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Invoke_O_O_O__O(self, src__0, extra__1 any) any {
	var root_519 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = src__0; if linked_520 == nil { ifn_521.Invoke_O__O(arg_522) } else { linked_520.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_519, arg_522) }
	var root_523 any = A_arbace_go_run_A_const_60.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_go_run_no_linkname_BANG__A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = src__0; if linked_524 == nil { ifn_525.Invoke_O__O(arg_526) } else { linked_524.(*A_arbace_go_run_no_linkname_BANG__A).Invoke_O_O__O(root_523, arg_526) }
//line :68:1
	var r__3 any; var root_514 any = A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_516 lang.IFn


	if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = src__0; var arg_518 any = extra__1; if linked_515 == nil { r__3 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { r__3 = linked_515.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }
//line :68:1
	var errs__4 any = A_arbace_go_run_A_const_58.Invoke_O__O(r__3); var temp__1927000414__auto____5 any; var root_527 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_529 lang.IFn




	if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var tmp1 any = A_arbace_go_run_check_BANG__fn__1938000065_A_New(); var tmp2 *jrt.Class; var fncls__532 *jrt.Class = A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class; if fncls__532 == nil { var fncls__532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class = fncls__532d; tmp2 = fncls__532d } else { tmp2 = fncls__532 }; arg_530 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_531 any = errs__4; if linked_528 == nil { temp__1927000414__auto____5 = ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { temp__1927000414__auto____5 = linked_528.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var bi__6 any = temp__1927000414__auto____5; var root_533 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_go_run_fail_A_fn_class); var ifn_535 lang.IFn
		if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = A_arbace_go_run_A_const_49; var arg_537 any = Lit_8; var arg_538 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_63.Invoke_O__O(bi__6))).Ref(); if linked_534 == nil { ifn_535.Invoke_O_O_O__O(arg_536, arg_537, arg_538) } else { linked_534.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_533, arg_536, arg_537, arg_538) } }
	var tmp3 any; var root_539 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = errs__4; if linked_540 == nil { tmp3 = ifn_541.Invoke_O__O(arg_542) } else { tmp3 = linked_540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_539, arg_542) }; if jrt.J2g_Truth(tmp3) {
		var root_543 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_go_run_fail_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = A_arbace_go_run_A_const_64; var arg_547 any = Lit_3; var arg_548 any; var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp5 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__0); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_65; var tmp7 any; var root_549 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = errs__4; if linked_550 == nil { tmp7 = ifn_551.Invoke_O__O(arg_552) } else { tmp7 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Keyword = A_arbace_go_run_A_const_66; var tmp10 any; var root_553 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = errs__4; if linked_554 == nil { tmp10 = ifn_555.Invoke_O__O(arg_556) } else { tmp10 = linked_554.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_553, arg_556) }; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Keyword = A_arbace_go_run_A_const_63; var tmp13 any; var root_557 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = errs__4; if linked_558 == nil { tmp13 = ifn_559.Invoke_O__O(arg_560) } else { tmp13 = linked_558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_557, arg_560) }; arg_548 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp8, nil, tmp11, nil, tmp12.Invoke_O__O(tmp13))).Ref(); if linked_544 == nil { ifn_545.Invoke_O_O_O__O(arg_546, arg_547, arg_548) } else { linked_544.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_543, arg_546, arg_547, arg_548) } }
//line :68:1
	return r__3
}



func A_arbace_go_run_check_BANG__fn__1938000065_A_New() *A_arbace_go_run_check_BANG__fn__1938000065_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__fn__1938000065_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Ctor() {}
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Invoke_O_O__O(self, p1__1938000064_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_61; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000064_SHARP___1)) { return p1__1938000064_SHARP___1 } else { return nil } }





func A_arbace_go_run_imports_of_A_New() *A_arbace_go_run_imports_of_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Invoke_O_O__O(self, src__0 any) any { var li__2 any; var root_561 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_563 lang.IFn; if


	linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = src__0; var arg_565 any = A_arbace_go_run_A_const_67; if linked_562 == nil { li__2 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { li__2 = linked_562.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; var root_566 any =
	A_arbace_go_run_A_const_68.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(li__2); var tmp2 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class; if
	fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class = fncls__688d; tmp2 = fncls__688d } else { tmp2 = fncls__688 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_569 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_run_A_const_51.Invoke_O__O(src__0)); if /*line :83:1*/ linked_567 == nil { return ifn_568.Invoke_O__O(arg_569) } else { return linked_567.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_566, arg_569) } }
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Invoke_O_O__O(self, s__1938000069__1 any) any { var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(s__1938000069__1, self, t.F_li); var tmp2 *jrt.Class; var fncls__687 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class; if fncls__687 == nil { var fncls__687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class = fncls__687d; tmp2 = fncls__687d } else { tmp2 = fncls__687 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Ctor_O_O_O(c__s__1938000069, c__iter__1938000068, c__li any) { t.F_s__1938000069 = c__s__1938000069; t.F_iter__1938000068 = c__iter__1938000068; t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Invoke_O__O(self any) any { { var s__1938000069__1 any; var t_ any = t.F_s__1938000069; t.F_s__1938000069 = nil; s__1938000069__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = s__1938000069__1; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O__O(arg_573) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_570, arg_573) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var fi__4 any; var root_574 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = xs__1927001018__auto____3; if linked_575 == nil { fi__4 = ifn_576.Invoke_O__O(arg_577) } else { fi__4 = linked_575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_574, arg_577) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(t.F_li); var tmp2 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class = fncls__664d; tmp2 = fncls__664d } else { tmp2 = fncls__664 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_665 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_669 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_671 lang.IFn
														if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = fi__4; var arg_673 any = A_arbace_go_run_A_const_72; if linked_670 == nil { tmp4 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp4 = linked_670.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }
//line :84:1
	arg_668 = tmp3.Invoke_O__O(tmp4); if linked_666 == nil { fs__1927001036__auto____6 = ifn_667.Invoke_O__O(arg_668) } else { fs__1927001036__auto____6 = linked_666.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_665, arg_668) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_674 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = fs__1927001036__auto____6; var arg_678 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1938000068); var tmp6 any; var root_679 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__1938000069__1; if linked_680 == nil { tmp6 = ifn_681.Invoke_O__O(arg_682) } else { tmp6 = linked_680.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_679, arg_682) }; arg_678 = tmp5.Invoke_O__O(tmp6); if linked_675 == nil { return ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { return linked_675.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) } } else { var tmp7 any; var root_683 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = s__1938000069__1; if linked_684 == nil { tmp7 = ifn_685.Invoke_O__O(arg_686) } else { tmp7 = linked_684.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_683, arg_686) }; s__1938000069__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Invoke_O_O__O(self, s__1938000071__1 any) any { var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(s__1938000071__1, t.F_li, self); var tmp2 *jrt.Class; var fncls__663 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class; if fncls__663 == nil { var fncls__663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class = fncls__663d; tmp2 = fncls__663d } else { tmp2 = fncls__663 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Ctor_O_O_O(c__s__1938000071, c__li, c__iter__1938000070 any) { t.F_s__1938000071 = c__s__1938000071; t.F_li = c__li; t.F_iter__1938000070 = c__iter__1938000070 }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Invoke_O__O(self any) any { { var s__1938000071__1 any; var t_ any = t.F_s__1938000071; t.F_s__1938000071 = nil; s__1938000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_578 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = s__1938000071__1; if linked_579 == nil { temp__1927000414__auto____2 = ifn_580.Invoke_O__O(arg_581) } else { temp__1927000414__auto____2 = linked_579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_582 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = s__1938000071__3; if linked_583 == nil { tmp1 = ifn_584.Invoke_O__O(arg_585) } else { tmp1 = linked_583.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_582, arg_585) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_586 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = s__1938000071__3; if linked_587 == nil { c__1927001037__auto____4 = ifn_588.Invoke_O__O(arg_589) } else { c__1927001037__auto____4 = linked_587.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_586, arg_589) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000073__6 any; var root_590 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_591 == nil { b__1938000073__6 = ifn_592.Invoke_O__O(arg_593) } else { b__1938000073__6 = linked_591.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_590, arg_593) }; var tmp2 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(b__1938000073__6, t.F_li, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__611 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class; if fncls__611 == nil { var fncls__611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class = fncls__611d; tmp3 = fncls__611d } else { tmp3 = fncls__611 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_612 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var root_617 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = b__1938000073__6; if linked_618 == nil { arg_615 = ifn_619.Invoke_O__O(arg_620) } else { arg_615 = linked_618.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_617, arg_620) }; var arg_616 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp5 any; var root_621 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = s__1938000071__3; if linked_622 == nil { tmp5 = ifn_623.Invoke_O__O(arg_624) } else { tmp5 = linked_622.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_621, arg_624) }; arg_616 = tmp4.Invoke_O__O(tmp5); if linked_613 == nil { return ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { return linked_613.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) } } else { var root_625 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var root_630 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = b__1938000073__6; if linked_631 == nil { arg_628 = ifn_632.Invoke_O__O(arg_633) } else { arg_628 = linked_631.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_630, arg_633) }; var arg_629 any; if linked_626 == nil { return ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { return linked_626.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) } } } else { var spec__4 any; var root_634 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = s__1938000071__3; if linked_635 == nil { spec__4 = ifn_636.Invoke_O__O(arg_637) } else { spec__4 = linked_635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_634, arg_637) }; var p__5 any; var tmp6 any; var root_638 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_640 lang.IFn

	if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = spec__4; if linked_639 == nil { tmp6 = ifn_640.Invoke_O__O(arg_641) } else { tmp6 = linked_639.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_638, arg_641) }; if jrt.J2g_Truth(tmp6) { var root_642 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = spec__4; if linked_643 == nil { p__5 = ifn_644.Invoke_O__O(arg_645) } else { p__5 = linked_643.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_642, arg_645) } } else { p__5 = spec__4 }
//line :84:1
	var tmp7 any; var root_646 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_648 lang.IFn


	if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = p__5; if linked_647 == nil { tmp7 = ifn_648.Invoke_O__O(arg_649) } else { tmp7 = linked_647.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_646, arg_649) }
//line :84:1
	if jrt.J2g_Truth(tmp7) { var root_650 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__5, p__5); var arg_654 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp9 any; var root_655 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = s__1938000071__3; if linked_656 == nil { tmp9 = ifn_657.Invoke_O__O(arg_658) } else { tmp9 = linked_656.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_655, arg_658) }; arg_654 = tmp8.Invoke_O__O(tmp9); if linked_651 == nil { return ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { return linked_651.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) } } else { var tmp10 any; var root_659 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = s__1938000071__3; if linked_660 == nil { tmp10 = ifn_661.Invoke_O__O(arg_662) } else { tmp10 = linked_660.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_659, arg_662) }; s__1938000071__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Ctor_O_O_I_O(c__b__1938000073, c__li any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000073 = c__b__1938000073; t.F_li = c__li; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Invoke_O__O(self any) any { { var i__1938000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000072__1)); var p__3 any; var tmp2 any; var root_594 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_596 lang.IFn

	if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = spec__2; if linked_595 == nil { tmp2 = ifn_596.Invoke_O__O(arg_597) } else { tmp2 = linked_595.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(tmp2) { var root_598 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = spec__2; if linked_599 == nil { p__3 = ifn_600.Invoke_O__O(arg_601) } else { p__3 = linked_599.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_598, arg_601) } } else { p__3 = spec__2 }
//line :84:1
	var tmp3 any; var root_602 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_604 lang.IFn


	if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = p__3; if linked_603 == nil { tmp3 = ifn_604.Invoke_O__O(arg_605) } else { tmp3 = linked_603.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_602, arg_605) }
//line :84:1
	if jrt.J2g_Truth(tmp3) { var root_606 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = t.F_b__1938000073; var arg_610 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__3, p__3); if linked_607 == nil { ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { linked_607.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) }; i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } else { i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_run_A_New() *A_arbace_go_run_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_run_run_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_run_run_A) Invoke_O_O_O_O__O(self, root__0, pf__1, args__2 any) any {




	var root_907 any = A_arbace_go_run_A_const_108.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = A_arbace_go_run_A_const_109.GetRawRoot__O(); var arg_911 any = jrt.Boolean_TRUE.Ref(); if linked_908 == nil { ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { linked_908.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_907, arg_910, arg_911) }
//line :90:1
	var src__4 any; var root_689 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_691 lang.IFn





	if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, root__0)); var arg_693 any; var arg_694 any; var root_696 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_697 == nil { arg_694 = ifn_698.Invoke_O__O(arg_699) } else { arg_694 = linked_697.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_696, arg_699) }; var arg_695 any = pf__1; if linked_690 == nil { src__4 = ifn_691.Invoke_O_O_O_O__O(arg_692, arg_693, arg_694, arg_695) } else { src__4 = linked_690.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_689, arg_692, arg_693, arg_694, arg_695) }
//line :90:1
	var ___5 any; var tmp1 any; var root_700 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_702 lang.IFn; _ = ___5






	if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__4); if linked_701 == nil { tmp1 = ifn_702.Invoke_O__O(arg_703) } else { tmp1 = linked_701.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_700, arg_703) }; if jrt.J2g_Truth(tmp1) { var root_704 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, A_arbace_go_run_fail_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = A_arbace_go_run_A_const_49; var arg_708 any = Lit_8; var arg_709 any = Lit_36; if linked_705 == nil { ___5 = ifn_706.Invoke_O_O_O__O(arg_707, arg_708, arg_709) } else { ___5 = linked_705.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_704, arg_707, arg_708, arg_709) } } else { ___5 = nil }
//line :90:1
	var index__6 any; var tmp2 any = A_arbace_go_run_run_fn__1938000087_A_New_O(pf__1); var tmp3 *jrt.Class
	var fncls__714 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_fn__1938000087_A_fn_class







	if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_run_run_fn__1938000087_A_fn_class = fncls__714d; tmp3 = fncls__714d } else { tmp3 = fncls__714 }
//line :90:1
	index__6 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var srcs__7 any; var root_715 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_717 lang.IFn








	if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_716 == nil { srcs__7 = ifn_717.Invoke_O__O(arg_718) } else { srcs__7 = linked_716.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_715, arg_718) }
//line :90:1
	var inits__8 any; var root_719 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_721 lang.IFn









	if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_720 == nil { inits__8 = ifn_721.Invoke_O__O(arg_722) } else { inits__8 = linked_720.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_719, arg_722) }
//line :90:1
	var deps__9 any; var root_723 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_725 lang.IFn










	if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_724 == nil { deps__9 = ifn_725.Invoke_O__O(arg_726) } else { deps__9 = linked_724.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_723, arg_726) }
//line :90:1
	var extra__10 any; var tmp4 any = A_arbace_go_run_run_extra__1938000089_A_New_O(srcs__7); var tmp5 *jrt.Class
	var fncls__731 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_extra__1938000089_A_fn_class











	if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_run_run_extra__1938000089_A_fn_class = fncls__731d; tmp5 = fncls__731d } else { tmp5 = fncls__731 }; extra__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :90:1
	var define__11 any; var tmp6 any = A_arbace_go_run_run_define__1938000091_A_New_O_O_O(srcs__7, inits__8, deps__9); var tmp7 *jrt.Class
	var fncls__793 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_define__1938000091_A_fn_class












	if fncls__793 == nil { var fncls__793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_run_run_define__1938000091_A_fn_class = fncls__793d; tmp7 = fncls__793d } else { tmp7 = fncls__793 }; define__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :90:1
	var init_order__12 any; var tmp8 any = A_arbace_go_run_run_init_order__1938000095_A_New_O_O(inits__8, deps__9); var tmp9 *jrt.Class
	var fncls__863 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_init_order__1938000095_A_fn_class





















	if fncls__863 == nil { var fncls__863d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_run_run_init_order__1938000095_A_fn_class = fncls__863d; tmp9 = fncls__863d } else { tmp9 = fncls__863 }; init_order__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :90:1
	var body_load_BANG___13 *A_arbace_go_run_run_load_BANG___1938000099_A = A_arbace_go_run_run_load_BANG___1938000099_A_New_O_O_O_O_O(root__0, extra__10, srcs__7, index__6, define__11); var load_BANG___13 any; var tmp10 *jrt.Class; var fncls__1008 *jrt.Class = A_arbace_go_run_run_load_BANG___1938000099_A_fn_class; if fncls__1008 == nil { var fncls__1008d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_run_run_load_BANG___1938000099_A_fn_class = fncls__1008d; tmp10 = fncls__1008d } else { tmp10 = fncls__1008 }; load_BANG___13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_load_BANG___13), tmp10, nil); var seq_1938000105__14 any; var root_1009 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1011 lang.IFn





































	if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any; var root_1013 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, A_arbace_go_run_imports_of_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = src__4; if linked_1014 == nil { arg_1012 = ifn_1015.Invoke_O__O(arg_1016) } else { arg_1012 = linked_1014.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1013, arg_1016) }; if linked_1010 == nil { seq_1938000105__14 = ifn_1011.Invoke_O__O(arg_1012) } else { seq_1938000105__14 = linked_1010.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1009, arg_1012) }
//line :90:1
	var chunk_1938000106__15 any; var count_1938000107__16 int64 = 0; var i_1938000108__17 int64 = 0; L1: for {





































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000108__17, count_1938000107__16) { var p__18 any = lang.Indexed_Cast(chunk_1938000106__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000108__17)); lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__18, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, i_1938000108__17 = seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000108__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1017 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = seq_1938000105__14; if linked_1018 == nil { temp__1927000414__auto____18 = ifn_1019.Invoke_O__O(arg_1020) } else { temp__1927000414__auto____18 = linked_1018.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1017, arg_1020) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000105__19 any = temp__1927000414__auto____18; var tmp11 any; var root_1021 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = seq_1938000105__19; if linked_1022 == nil { tmp11 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp11 = linked_1022.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1021, arg_1024) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____20 any; var root_1025 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = seq_1938000105__19; if linked_1026 == nil { c__1927000678__auto____20 = ifn_1027.Invoke_O__O(arg_1028) } else { c__1927000678__auto____20 = linked_1026.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1025, arg_1028) }; var tmp12 any; var root_1033 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = seq_1938000105__19; if linked_1034 == nil { tmp12 = ifn_1035.Invoke_O__O(arg_1036) } else { tmp12 = linked_1034.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1033, arg_1036) }; seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, i_1938000108__17 = tmp12, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__20 any; var root_1029 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = seq_1938000105__19; if linked_1030 == nil { p__20 = ifn_1031.Invoke_O__O(arg_1032) } else { p__20 = linked_1030.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1029, arg_1032) }; lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__20, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); var tmp13 any; var root_1037 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = seq_1938000105__19; if linked_1038 == nil { tmp13 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp13 = linked_1038.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1037, arg_1040) }; seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, i_1938000108__17 = tmp13, nil, 0, 0; continue L1 } } }
//line :90:1
		break L1 }; var r__13 any; var root_864 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_go_run_check_BANG__A_fn_class); var ifn_866 lang.IFn






































	if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = src__4; var arg_868 any = extra__10; if linked_865 == nil { r__13 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { r__13 = linked_865.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }
//line :90:1
	var ___14 any; var root_869 any = A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_871 lang.IFn; _ = ___14







































	if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = srcs__7; var arg_873 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var arg_874 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__4); var arg_875 any = src__4; if linked_870 == nil { ___14 = ifn_871.Invoke_O_O_O_O__O(arg_872, arg_873, arg_874, arg_875) } else { ___14 = linked_870.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_869, arg_872, arg_873, arg_874, arg_875) }
//line :90:1
	var map__1938000109__15 any = lang.IFn_Cast(define__11).Invoke_O_O__O(src__4, r__13); var map__1938000109__16 any






































	if lang.ISeq_InstanceOf(map__1938000109__15) { var tmp14 any; var root_876 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = map__1938000109__15; if linked_877 == nil { tmp14 = ifn_878.Invoke_O__O(arg_879) } else { tmp14 = linked_877.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_876, arg_879) }; if jrt.J2g_Truth(tmp14) { var tmp15 any; var root_880 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = map__1938000109__15; if linked_881 == nil { tmp15 = ifn_882.Invoke_O__O(arg_883) } else { tmp15 = linked_881.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_880, arg_883) }; map__1938000109__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp15, jrt.Object_class.ArrayClass())).Ref() } else { var tmp16 any; var root_884 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = map__1938000109__15; if linked_885 == nil { tmp16 = ifn_886.Invoke_O__O(arg_887) } else { tmp16 = linked_885.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_884, arg_887) }; if jrt.J2g_Truth(tmp16) { var root_888 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = map__1938000109__15; if linked_889 == nil { map__1938000109__16 = ifn_890.Invoke_O__O(arg_891) } else { map__1938000109__16 = linked_889.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_888, arg_891) } } else { map__1938000109__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1938000109__16 = map__1938000109__15 }
//line :90:1
	var main__17 any = lang.RT_Get_O_O__O_NoInit(map__1938000109__16, A_arbace_go_run_A_const_105)









































	if jrt.J2g_Truth(main__17) { } else {
		var root_1041 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, A_arbace_go_run_fail_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = A_arbace_go_run_A_const_64; var arg_1045 any = Lit_3; var arg_1046 any = Lit_42; if linked_1042 == nil { ifn_1043.Invoke_O_O_O__O(arg_1044, arg_1045, arg_1046) } else { linked_1042.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1041, arg_1044, arg_1045, arg_1046) } }
	var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_106.GetRawRoot__O()); var tmp18 any; var root_1052 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any; var root_1057 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = jrt.NN(jrt.File_Cast(pf__1)).GetName__String().Ref(); if linked_1058 == nil { arg_1055 = ifn_1059.Invoke_O__O(arg_1060) } else { arg_1055 = linked_1058.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1057, arg_1060) }; var arg_1056 any = args__2; if linked_1053 == nil { tmp18 = ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { tmp18 = linked_1053.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) }; tmp17.Invoke_O_O__O(Lit_43, lang.RT_Object_array_O__O1_NoInit(tmp18).Ref())
	var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_106.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_107.GetRawRoot__O()); var tmp21 any; var root_903 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = inits__8; if linked_904 == nil { tmp21 = ifn_905.Invoke_O__O(arg_906) } else { tmp21 = linked_904.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_903, arg_906) }; return tmp19.Invoke_O_O_O__O(Lit_44, lang.RT_Object_array_O__O1_NoInit(tmp20.Invoke_O_O__O(tmp21, lang.IFn_Cast(init_order__12).Invoke__O())).Ref(), main__17) }
//line :98:1
func A_arbace_go_run_run_fn__1938000087_A_New_O(p0 any) *A_arbace_go_run_run_fn__1938000087_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_fn__1938000087_A{}; t.Ctor_O(p0); return t }
//line :98:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Ctor_O(c__pf any) { t.F_pf = c__pf }
//line :98:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Invoke_O__O(self any) any { var root_710 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_go_run_dir_test_index_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any; var t_ any = t.F_pf; t.F_pf = nil; arg_713 = t_; if linked_711 == nil { return ifn_712.Invoke_O__O(arg_713) } else { return linked_711.(*A_arbace_go_run_dir_test_index_A).Invoke_O_O__O(root_710, arg_713) } }



func A_arbace_go_run_run_extra__1938000089_A_New_O(p0 any) *A_arbace_go_run_run_extra__1938000089_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_extra__1938000089_A{}; t.Ctor_O(p0); return t }
//line :102:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :102:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_727 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = t.F_srcs; if linked_728 == nil { tmp1 = ifn_729.Invoke_O__O(arg_730) } else { tmp1 = linked_728.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_727, arg_730) }; return lang.RT_Get_O_O__O_NoInit(tmp1, path__1) }
func A_arbace_go_run_run_define__1938000091_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :103:1
func (t *A_arbace_go_run_run_define__1938000091_A) Ctor_O_O_O(c__srcs, c__inits, c__deps any) { t.F_srcs = c__srcs; t.F_inits = c__inits; t.F_deps = c__deps }
//line :103:1
func (t *A_arbace_go_run_run_define__1938000091_A) Invoke_O_O_O__O(self, src__1, r__2 any) any { var st__3 any; var root_732 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_734 lang.IFn; if
												linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any; var tmp1 any = A_arbace_go_run_A_const_50; var tmp2 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var tmp3 any = A_arbace_go_run_A_const_81; var tmp4 any = A_arbace_go_run_A_const_81.Invoke_O__O(src__1); var tmp5 any = A_arbace_go_run_A_const_82; var tmp6 any; var root_736 any = A_arbace_go_run_A_const_83.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_81.Invoke_O__O(src__1))).Ref(); if linked_737 == nil { tmp6 = ifn_738.Invoke_O__O(arg_739) } else { tmp6 = linked_737.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_736, arg_739) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_run_A_const_84; arg_735 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp7, tmp8, A_arbace_go_run_A_const_84.Invoke_O__O(src__1), A_arbace_go_run_A_const_51, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_run_A_const_85, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_86, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_87, lang.PersistentArrayMap_EMPTY.Ref())); if linked_733 == nil { st__3 = ifn_734.Invoke_O__O(arg_735) } else { st__3 = linked_733.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_732, arg_735) }; var root_746 any =

	A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var arg_750 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var arg_751 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_752 any = st__3; if linked_747 == nil { ifn_748.Invoke_O_O_O_O__O(arg_749, arg_750, arg_751, arg_752) } else { linked_747.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_746, arg_749, arg_750, arg_751, arg_752) }; var d__4 any; var root_740 any = /*line :103:1*/A_arbace_go_run_A_const_88.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_742 lang.IFn; if



	linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = st__3; var arg_744 any = r__2; var arg_745 any = A_arbace_go_run_A_const_89; if linked_741 == nil { d__4 = ifn_742.Invoke_O_O_O__O(arg_743, arg_744, arg_745) } else { d__4 = linked_741.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_740, arg_743, arg_744, arg_745) }; var tmp9 /*line :108:1*/*lang.Volatile = lang.Volatile_Cast(t.F_inits); var tmp10 any; var root_753 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = jrt.NN(lang.Volatile_Cast(t.F_inits)).Deref__O(); var arg_757 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_758 any; var root_759 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = A_arbace_go_run_A_const_93.Invoke_O__O(d__4); var arg_763 any = A_arbace_go_run_A_const_94.Invoke_O__O(d__4); if linked_760 == nil { arg_758 = ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { arg_758 = linked_760.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; if linked_754 == nil { tmp10 = ifn_755.Invoke_O_O_O__O(arg_756, arg_757, arg_758) } else { tmp10 = linked_754.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_753, arg_756, arg_757, arg_758) }; jrt.NN(tmp9).Reset_O__O(tmp10); var tmp11 /*line :109:1*/*lang.Volatile = lang.Volatile_Cast(t.F_deps); var tmp12 any; var root_764 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = jrt.NN(lang.Volatile_Cast(t.F_deps)).Deref__O(); var arg_768 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_769 any; var root_770 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var root_774 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var tmp13 any = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O(t.F_srcs); var tmp14 *jrt.Class; var fncls__788 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class; if fncls__788 == nil { var fncls__788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class = fncls__788d; tmp14 = fncls__788d } else { tmp14 = fncls__788 }; arg_777 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_778 any; var root_789 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, A_arbace_go_run_imports_of_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = src__1; if linked_790 == nil { arg_778 = ifn_791.Invoke_O__O(arg_792) } else { arg_778 = linked_790.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_789, arg_792) }; if linked_775 == nil { arg_773 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { arg_773 = linked_775.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) }; if linked_771 == nil { arg_769 = ifn_772.Invoke_O__O(arg_773) } else { arg_769 = linked_771.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_770, arg_773) }; if linked_765 == nil { tmp12 = ifn_766.Invoke_O_O_O__O(arg_767, arg_768, arg_769) } else { tmp12 = linked_765.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_764, arg_767, arg_768, arg_769) }; jrt.NN(tmp11).Reset_O__O(tmp12); return d__4 }
//line :109:1
func A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O(p0 any) *A_arbace_go_run_run_define__1938000091_fn__1938000092_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000092_A{}; t.Ctor_O(p0); return t }
//line :109:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :109:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Invoke_O_O__O(self, p1__1938000085_SHARP___1 any) any { var root_779 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any; var root_784 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = t.F_srcs; if linked_785 == nil { arg_782 = ifn_786.Invoke_O__O(arg_787) } else { arg_782 = linked_785.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_784, arg_787) }; var arg_783 any = p1__1938000085_SHARP___1; if linked_780 == nil { return ifn_781.Invoke_O_O__O(arg_782, arg_783) } else { return linked_780.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_779, arg_782, arg_783) } }


func A_arbace_go_run_run_init_order__1938000095_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000095_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :112:1
func (t *A_arbace_go_run_run_init_order__1938000095_A) Ctor_O_O(c__inits, c__deps any) { t.F_inits = c__inits; t.F_deps = c__deps }
//line :112:1
func (t *A_arbace_go_run_run_init_order__1938000095_A) Invoke_O__O(self any) any { { var done__1 any = lang.PersistentVector_EMPTY.Ref(); var left__2 any; var root_794 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_796 lang.IFn
											if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any; var root_798 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var root_802 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = t.F_inits; if linked_803 == nil { arg_801 = ifn_804.Invoke_O__O(arg_805) } else { arg_801 = linked_803.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_802, arg_805) }; if linked_799 == nil { arg_797 = ifn_800.Invoke_O__O(arg_801) } else { arg_797 = linked_799.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_798, arg_801) }; if linked_795 == nil { left__2 = ifn_796.Invoke_O__O(arg_797) } else { left__2 = linked_795.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_794, arg_797) }
//line :112:1
L1: for {

	var tmp1 any; var root_806 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = left__2; if linked_807 == nil { tmp1 = ifn_808.Invoke_O__O(arg_809) } else { tmp1 = linked_807.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_806, arg_809) }; if jrt.J2g_Truth(tmp1) { return done__1 } else { var p__3 any; var root_810 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_812 lang.IFn

		if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any; var root_814 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any; var root_818 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var tmp2 any = A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_New_O_O(done__1, t.F_deps); var tmp3 *jrt.Class; var fncls__836 *jrt.Class = A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_fn_class; if fncls__836 == nil { var fncls__836d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_fn_class = fncls__836d; tmp3 = fncls__836d } else { tmp3 = fncls__836 }; arg_821 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_822 any = left__2; if linked_819 == nil { arg_817 = ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { arg_817 = linked_819.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) }; if linked_815 == nil { arg_813 = ifn_816.Invoke_O__O(arg_817) } else { arg_813 = linked_815.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_814, arg_817) }; if linked_811 == nil { p__3 = ifn_812.Invoke_O__O(arg_813) } else { p__3 = linked_811.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_810, arg_813) }
		var tmp4 any; var root_837 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = done__1; var arg_841 any; var or__1927000174__auto____4 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_841 = or__1927000174__auto____4 } else { var root_842 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var root_846 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = left__2; if linked_847 == nil { arg_845 = ifn_848.Invoke_O__O(arg_849) } else { arg_845 = linked_847.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_846, arg_849) }; if linked_843 == nil { arg_841 = ifn_844.Invoke_O__O(arg_845) } else { arg_841 = linked_843.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_842, arg_845) } }; if linked_838 == nil { tmp4 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { tmp4 = linked_838.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) }; var tmp5 any = tmp4; var tmp6 any; var root_850 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = left__2; var arg_854 any; var or__1927000174__auto____4_2 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4_2) { arg_854 = or__1927000174__auto____4_2 } else { var root_855 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any; var root_859 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = left__2; if linked_860 == nil { arg_858 = ifn_861.Invoke_O__O(arg_862) } else { arg_858 = linked_860.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_859, arg_862) }; if linked_856 == nil { arg_854 = ifn_857.Invoke_O__O(arg_858) } else { arg_854 = linked_856.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_855, arg_858) } }; if linked_851 == nil { tmp6 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { tmp6 = linked_851.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; done__1, left__2 = tmp5, tmp6; continue L1 } } }; /*line :112:1*/panic("j2g: unreachable") }



func A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A{}; t.Ctor_O_O(p0, p1); return t }
//line :116:1
func (t *A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A) Ctor_O_O(c__done, c__deps any) { t.F_done = c__done; t.F_deps = c__deps }
//line :116:1
func (t *A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A) Invoke_O_O__O(self, p1__1938000086_SHARP___1 any) any { var root_823 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; var root_828 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = t.F_done; if linked_829 == nil { arg_826 = ifn_830.Invoke_O__O(arg_831) } else { arg_826 = linked_829.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_828, arg_831) }; var arg_827 any; var tmp1 any; var root_832 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = t.F_deps; if linked_833 == nil { tmp1 = ifn_834.Invoke_O__O(arg_835) } else { tmp1 = linked_833.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_832, arg_835) }; arg_827 = lang.RT_Get_O_O__O_NoInit(tmp1, p1__1938000086_SHARP___1); if linked_824 == nil { return ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { return linked_824.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_823, arg_826, arg_827) } }


func A_arbace_go_run_run_load_BANG___1938000099_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_run_run_load_BANG___1938000099_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_load_BANG___1938000099_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :119:1
func (t *A_arbace_go_run_run_load_BANG___1938000099_A) Ctor_O_O_O_O_O(c__root, c__extra, c__srcs, c__index, c__define any) { t.F_root = c__root; t.F_extra = c__extra; t.F_srcs = c__srcs; t.F_index = c__index; t.F_define = c__define }
//line :119:1
func (t *A_arbace_go_run_run_load_BANG___1938000099_A) Invoke_O_O_O__O(self, path__1, seen__2 any) any {
	var tmp1 any; var or__1927000174__auto____3 any; var root_912 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any; var root_917 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = t.F_srcs; if linked_918 == nil { arg_915 = ifn_919.Invoke_O__O(arg_920) } else { arg_915 = linked_918.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_917, arg_920) }; var arg_916 any = path__1; if linked_913 == nil { or__1927000174__auto____3 = ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { or__1927000174__auto____3 = linked_913.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_912, arg_915, arg_916) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_921 any = A_arbace_go_run_A_const_110.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = path__1; if linked_922 == nil { or__1927000174__auto____4 = ifn_923.Invoke_O__O(arg_924) } else { or__1927000174__auto____4 = linked_922.(*aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_921, arg_924) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_925 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = seen__2; var arg_929 any = path__1; if linked_926 == nil { tmp1 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { tmp1 = linked_926.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_925, arg_928, arg_929) } } }; if jrt.J2g_Truth(tmp1) { return nil } else { var temp__1927000414__auto____3 any; var tmp2 any; var root_930 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_932 lang.IFn
		if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = t.F_index; if linked_931 == nil { tmp2 = ifn_932.Invoke_O__O(arg_933) } else { tmp2 = linked_931.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_930, arg_933) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, path__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var f__4 any = temp__1927000414__auto____3; var s__5 any; var root_934 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_936 lang.IFn
			if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, t.F_root)); var arg_938 any = path__1; var arg_939 any; var root_941 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_942 == nil { arg_939 = ifn_943.Invoke_O__O(arg_944) } else { arg_939 = linked_942.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_941, arg_944) }; var arg_940 any = f__4; if linked_935 == nil { s__5 = ifn_936.Invoke_O_O_O_O__O(arg_937, arg_938, arg_939, arg_940) } else { s__5 = linked_935.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_934, arg_937, arg_938, arg_939, arg_940) }
//line :121:1
			var seq_1938000100__6 any; var root_959 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_961 lang.IFn

			if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any; var root_963 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, A_arbace_go_run_imports_of_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = s__5; if linked_964 == nil { arg_962 = ifn_965.Invoke_O__O(arg_966) } else { arg_962 = linked_964.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_963, arg_966) }; if linked_960 == nil { seq_1938000100__6 = ifn_961.Invoke_O__O(arg_962) } else { seq_1938000100__6 = linked_960.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_959, arg_962) }
//line :121:1
			var chunk_1938000101__7 any; var count_1938000102__8 int64 = 0; var i_1938000103__9 int64 = 0; L1: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000103__9, count_1938000102__8) { var p__10 any = lang.Indexed_Cast(chunk_1938000101__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000103__9)); var tmp3 lang.IFn = lang.IFn_Cast(self); var tmp4 any; var root_983 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = seen__2; var arg_987 any = path__1; if linked_984 == nil { tmp4 = ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { tmp4 = linked_984.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_983, arg_986, arg_987) }; tmp3.Invoke_O_O__O(p__10, tmp4); seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, i_1938000103__9 = seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000103__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_967 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = seq_1938000100__6; if linked_968 == nil { temp__1927000414__auto____10 = ifn_969.Invoke_O__O(arg_970) } else { temp__1927000414__auto____10 = linked_968.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_967, arg_970) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1938000100__11 any = temp__1927000414__auto____10; var tmp5 any; var root_971 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = seq_1938000100__11; if linked_972 == nil { tmp5 = ifn_973.Invoke_O__O(arg_974) } else { tmp5 = linked_972.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_971, arg_974) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_975 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = seq_1938000100__11; if linked_976 == nil { c__1927000678__auto____12 = ifn_977.Invoke_O__O(arg_978) } else { c__1927000678__auto____12 = linked_976.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_975, arg_978) }; var tmp6 any; var root_988 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = seq_1938000100__11; if linked_989 == nil { tmp6 = ifn_990.Invoke_O__O(arg_991) } else { tmp6 = linked_989.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_988, arg_991) }; seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, i_1938000103__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__12 any; var root_979 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = seq_1938000100__11; if linked_980 == nil { p__12 = ifn_981.Invoke_O__O(arg_982) } else { p__12 = linked_980.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_979, arg_982) }; var tmp7 lang.IFn = lang.IFn_Cast(self); var tmp8 any; var root_992 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = seen__2; var arg_996 any = path__1; if linked_993 == nil { tmp8 = ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { tmp8 = linked_993.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) }; tmp7.Invoke_O_O__O(p__12, tmp8); var tmp9 any; var root_997 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = seq_1938000100__11; if linked_998 == nil { tmp9 = ifn_999.Invoke_O__O(arg_1000) } else { tmp9 = linked_998.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_997, arg_1000) }; seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, i_1938000103__9 = tmp9, nil, 0, 0; continue L1 } } }
//line :121:1
				break L1
			}

			var tmp10 any; var root_945 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any; var root_950 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = t.F_srcs; if linked_951 == nil { arg_948 = ifn_952.Invoke_O__O(arg_953) } else { arg_948 = linked_951.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_950, arg_953) }; var arg_949 any = path__1; if linked_946 == nil { tmp10 = ifn_947.Invoke_O_O__O(arg_948, arg_949) } else { tmp10 = linked_946.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_945, arg_948, arg_949) }; if jrt.J2g_Truth(tmp10) { return nil } else { var r__6 any; var root_954 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_go_run_check_BANG__A_fn_class); var ifn_956 lang.IFn
				if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = s__5; var arg_958 any = t.F_extra; if linked_955 == nil { r__6 = ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { r__6 = linked_955.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_954, arg_957, arg_958) }
				var root_1001 any = A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = t.F_srcs; var arg_1005 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var arg_1006 any = path__1; var arg_1007 any = s__5; if linked_1002 == nil { ifn_1003.Invoke_O_O_O_O__O(arg_1004, arg_1005, arg_1006, arg_1007) } else { linked_1002.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1001, arg_1004, arg_1005, arg_1006, arg_1007) }
				return lang.IFn_Cast(t.F_define).Invoke_O_O__O(s__5, r__6) } } else {
//line :121:1
					return nil
				}
	}
}












func A_arbace_go_run__main_A_New() *A_arbace_go_run__main_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_go_run__main_A) Ctor() {}
//line :137:1
func (t *A_arbace_go_run__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1938000112__2 any = args__0; var seq__1938000113__3 any; var root_1061 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1063 lang.IFn; if


	linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = vec__1938000112__2; if linked_1062 == nil { seq__1938000113__3 = ifn_1063.Invoke_O__O(arg_1064) } else { seq__1938000113__3 = linked_1062.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1061, arg_1064) }; var first__1938000114__4 any; var root_1065 any = /*line :137:1*/A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1067 lang.IFn; if


	linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = seq__1938000113__3; if linked_1066 == nil { first__1938000114__4 = ifn_1067.Invoke_O__O(arg_1068) } else { first__1938000114__4 = linked_1066.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1065, arg_1068) }; var seq__1938000113__5 any; var root_1069 any = /*line :137:1*/A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1071 lang.IFn; if


	linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = seq__1938000113__3; if linked_1070 == nil { seq__1938000113__5 = ifn_1071.Invoke_O__O(arg_1072) } else { seq__1938000113__5 = linked_1070.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1069, arg_1072) }; var root__6 any = first__1938000114__4; var first__1938000114__7 any; var root_1073 any = /*line :137:1*/A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1075 lang.IFn; if


	linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = seq__1938000113__5; if linked_1074 == nil { first__1938000114__7 = ifn_1075.Invoke_O__O(arg_1076) } else { first__1938000114__7 = linked_1074.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1073, arg_1076) }; var seq__1938000113__8 any; var root_1077 any = /*line :137:1*/A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1079 lang.IFn; if


	linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = seq__1938000113__5; if linked_1078 == nil { seq__1938000113__8 = ifn_1079.Invoke_O__O(arg_1080) } else { seq__1938000113__8 = linked_1078.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1077, arg_1080) }; var ns_name__9 any = first__1938000114__7; var pargs__10 any = seq__1938000113__8; var tmp1 any; var and__1927000168__auto____11 any = root__6; if
	jrt.J2g_Truth(and__1927000168__auto____11) { tmp1 = ns_name__9 } else { tmp1 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp1) { } else {
		var root_1125 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp3 any = A_arbace_go_run_A_const_20; var arg_1128 any = tmp2.Invoke_O_O__O(tmp3, A_arbace_go_run_A_const_21.Get__O()); if linked_1126 == nil { ifn_1127.Invoke_O__O(arg_1128) } else { linked_1126.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp4 any = A_arbace_go_run__main_fn__1938000115_A_New(); var tmp5 *jrt.Class; var fncls__1124 *jrt.Class = A_arbace_go_run__main_fn__1938000115_A_fn_class; if fncls__1124 == nil { var fncls__1124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_run__main_fn__1938000115_A_fn_class = fncls__1124d; tmp5 = fncls__1124d } else { tmp5 = fncls__1124 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }; var pf__11 any; var tmp6 /*line :137:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp7 any; var root_1081 any = A_arbace_go_run_A_const_111.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1083 lang.IFn; if






	linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = ns_name__9; if linked_1082 == nil { tmp7 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp7 = linked_1082.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1081, arg_1084) }; pf__11 = /*line :137:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, root__6, nil, tmp7))); if







	jrt.NN(jrt.File_Cast(pf__11)).IsFile__Z() { } else {
		var root_1134 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, A_arbace_go_run_fail_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = A_arbace_go_run_A_const_64; var arg_1138 any = Lit_3; var arg_1139 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__11)).Ref(); if linked_1135 == nil { ifn_1136.Invoke_O_O_O__O(arg_1137, arg_1138, arg_1139) } else { linked_1135.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1134, arg_1137, arg_1138, arg_1139) } }; var status__12 any; var tmp8 any = /*line :137:1*/A_arbace_go_run__main_fn__1938000117_A_New_O_O_O(pargs__10, pf__11, root__6); var tmp9 *jrt.Class; var fncls__1116 *jrt.Class = A_arbace_go_run__main_fn__1938000117_A_fn_class; if









	fncls__1116 == nil { var fncls__1116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_run__main_fn__1938000117_A_fn_class = fncls__1116d; tmp9 = fncls__1116d } else { tmp9 = fncls__1116 }; status__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O();








	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__12)); return nil }
//line :142:1
func A_arbace_go_run__main_fn__1938000115_A_New() *A_arbace_go_run__main_fn__1938000115_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000115_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_go_run__main_fn__1938000115_A) Ctor() {}
//line :142:1
func (t *A_arbace_go_run__main_fn__1938000115_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_6); return nil }(); var root_1121 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; if linked_1122 == nil { ifn_1123.Invoke__O() } else { linked_1122.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1121) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_go_run__main_fn__1938000117_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run__main_fn__1938000117_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000117_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :147:1
func (t *A_arbace_go_run__main_fn__1938000117_A) Ctor_O_O_O(c__pargs, c__pf, c__root any) { t.F_pargs = c__pargs; t.F_pf = c__pf; t.F_root = c__root }
//line :147:1
func (t *A_arbace_go_run__main_fn__1938000117_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_1085 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, A_arbace_go_run_run_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var t_ any = t.F_root; t.F_root = nil; arg_1088 = t_; var arg_1089 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1089 = t__2; var arg_1090 any; var t__3 any = t.F_pargs; t.F_pargs = nil; arg_1090 = t__3; if linked_1086 == nil { tmp1 = ifn_1087.Invoke_O_O_O__O(arg_1088, arg_1089, arg_1090) } else { tmp1 = linked_1086.(*A_arbace_go_run_run_A).Invoke_O_O_O_O__O(root_1085, arg_1088, arg_1089, arg_1090) } }
//line :147:1
	return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var d__4 any; var root_1091 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1093 lang.IFn


		if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = ex__3; if linked_1092 == nil { d__4 = ifn_1093.Invoke_O__O(arg_1094) } else { d__4 = linked_1092.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1091, arg_1094) }
//line :147:1
		var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_114.Invoke_O__O(d__4)



		if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp3 any; var root_1095 any = A_arbace_go_run_A_const_115.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = m__7; var arg_1099 any = Lit_7; if linked_1096 == nil { tmp3 = ifn_1097.Invoke_O_O__O(arg_1098, arg_1099) } else { tmp3 = linked_1096.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1095, arg_1098, arg_1099) }; if jrt.J2g_Truth(tmp3) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
		if jrt.J2g_Truth(u__5) {
			var root_1100 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, A_arbace_go_run_fail_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = A_arbace_go_run_A_const_49; var arg_1104 any = Lit_8; var arg_1105 any = u__5; if linked_1101 == nil { tmp1 = ifn_1102.Invoke_O_O_O__O(arg_1103, arg_1104, arg_1105) } else { tmp1 = linked_1101.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1100, arg_1103, arg_1104, arg_1105) } } else {
				var root_1106 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, A_arbace_go_run_fail_A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = A_arbace_go_run_A_const_64; var arg_1110 any = Lit_3; var arg_1111 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp5 any; var root_1112 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = ex__3; if linked_1113 == nil { tmp5 = ifn_1114.Invoke_O__O(arg_1115) } else { tmp5 = linked_1113.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1112, arg_1115) }; arg_1111 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp5)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1107 == nil { tmp1 = ifn_1108.Invoke_O_O_O__O(arg_1109, arg_1110, arg_1111) } else { tmp1 = linked_1107.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1106, arg_1109, arg_1110, arg_1111) } } } }; return tmp1 }



















































type A_arbace_go_run_A struct{ jrt.Object }

var A_arbace_go_run_A_const_pool *jrt.RefArray

var A_arbace_go_run_A_const_0 *lang.Var

var A_arbace_go_run_A_const_1 any

var A_arbace_go_run_A_const_2 *lang.Var

var A_arbace_go_run_A_const_3 any

var A_arbace_go_run_A_const_4 any

var A_arbace_go_run_A_const_5 any

var A_arbace_go_run_A_const_6 any

var A_arbace_go_run_A_const_7 *lang.Var

var A_arbace_go_run_A_const_8 *lang.Var

var A_arbace_go_run_A_const_9 *lang.Var

var A_arbace_go_run_A_const_10 *lang.Var

var A_arbace_go_run_A_const_11 any

var A_arbace_go_run_A_const_12 *lang.Var

var A_arbace_go_run_A_const_13 *lang.Var

var A_arbace_go_run_A_const_14 *lang.Var

var A_arbace_go_run_A_const_15 *lang.Var

var A_arbace_go_run_A_const_16 *lang.Var

var A_arbace_go_run_A_const_17 *lang.Var

var A_arbace_go_run_A_const_18 *lang.Var

var A_arbace_go_run_A_const_19 *lang.Var

var A_arbace_go_run_A_const_20 *lang.Var

var A_arbace_go_run_A_const_21 *lang.Var

var A_arbace_go_run_A_const_22 *lang.Var

var A_arbace_go_run_A_const_23 *lang.Var

var A_arbace_go_run_A_const_24 *lang.Var

var A_arbace_go_run_A_const_25 *lang.Var

var A_arbace_go_run_A_const_26 *lang.Var

var A_arbace_go_run_A_const_27 *lang.Var

var A_arbace_go_run_A_const_28 any

var A_arbace_go_run_A_const_29 *lang.Keyword

var A_arbace_go_run_A_const_30 *lang.Var

var A_arbace_go_run_A_const_31 *lang.Var

var A_arbace_go_run_A_const_32 *lang.Var

var A_arbace_go_run_A_const_33 *lang.Var

var A_arbace_go_run_A_const_34 *lang.Var

var A_arbace_go_run_A_const_35 *lang.Var

var A_arbace_go_run_A_const_36 *lang.Var

var A_arbace_go_run_A_const_37 *lang.Var

var A_arbace_go_run_A_const_38 *lang.Var

var A_arbace_go_run_A_const_39 *lang.Var

var A_arbace_go_run_A_const_40 *lang.Var

var A_arbace_go_run_A_const_41 *lang.Var

var A_arbace_go_run_A_const_42 *lang.Var

var A_arbace_go_run_A_const_43 *lang.Var

var A_arbace_go_run_A_const_44 *lang.Var

var A_arbace_go_run_A_const_45 *lang.Var

var A_arbace_go_run_A_const_46 *lang.Var

var A_arbace_go_run_A_const_47 any

var A_arbace_go_run_A_const_48 *lang.Var

var A_arbace_go_run_A_const_49 any

var A_arbace_go_run_A_const_50 *lang.Keyword

var A_arbace_go_run_A_const_51 *lang.Keyword

var A_arbace_go_run_A_const_52 *lang.Keyword

var A_arbace_go_run_A_const_53 *lang.Var

var A_arbace_go_run_A_const_54 *lang.Var

var A_arbace_go_run_A_const_55 *lang.Keyword

var A_arbace_go_run_A_const_56 *lang.Var

var A_arbace_go_run_A_const_57 *lang.Var

var A_arbace_go_run_A_const_58 *lang.Keyword

var A_arbace_go_run_A_const_59 *lang.Var

var A_arbace_go_run_A_const_60 *lang.Var

var A_arbace_go_run_A_const_61 *lang.Keyword

var A_arbace_go_run_A_const_62 *lang.Keyword

var A_arbace_go_run_A_const_63 *lang.Keyword

var A_arbace_go_run_A_const_64 any

var A_arbace_go_run_A_const_65 *lang.Keyword

var A_arbace_go_run_A_const_66 *lang.Keyword

var A_arbace_go_run_A_const_67 any

var A_arbace_go_run_A_const_68 *lang.Var

var A_arbace_go_run_A_const_69 *lang.Var

var A_arbace_go_run_A_const_70 *lang.Var

var A_arbace_go_run_A_const_71 *lang.Var

var A_arbace_go_run_A_const_72 any

var A_arbace_go_run_A_const_73 *lang.Var

var A_arbace_go_run_A_const_74 *lang.Var

var A_arbace_go_run_A_const_75 *lang.Keyword

var A_arbace_go_run_A_const_76 *lang.Var

var A_arbace_go_run_A_const_77 *lang.Var

var A_arbace_go_run_A_const_78 *lang.Var

var A_arbace_go_run_A_const_79 *lang.Var

var A_arbace_go_run_A_const_80 *lang.Var

var A_arbace_go_run_A_const_81 *lang.Keyword

var A_arbace_go_run_A_const_82 *lang.Keyword

var A_arbace_go_run_A_const_83 *lang.Var

var A_arbace_go_run_A_const_84 *lang.Keyword

var A_arbace_go_run_A_const_85 *lang.Keyword

var A_arbace_go_run_A_const_86 *lang.Keyword

var A_arbace_go_run_A_const_87 *lang.Keyword

var A_arbace_go_run_A_const_88 *lang.Var

var A_arbace_go_run_A_const_89 any

var A_arbace_go_run_A_const_90 *lang.Var

var A_arbace_go_run_A_const_91 *lang.Var

var A_arbace_go_run_A_const_92 *lang.Var

var A_arbace_go_run_A_const_93 *lang.Keyword

var A_arbace_go_run_A_const_94 *lang.Keyword

var A_arbace_go_run_A_const_95 *lang.Var

var A_arbace_go_run_A_const_96 *lang.Var

var A_arbace_go_run_A_const_97 *lang.Var

var A_arbace_go_run_A_const_98 *lang.Var

var A_arbace_go_run_A_const_99 *lang.Var

var A_arbace_go_run_A_const_100 *lang.Var

var A_arbace_go_run_A_const_101 *lang.Var

var A_arbace_go_run_A_const_102 *lang.Var

var A_arbace_go_run_A_const_103 *lang.Var

var A_arbace_go_run_A_const_104 *lang.Var

var A_arbace_go_run_A_const_105 *lang.Keyword

var A_arbace_go_run_A_const_106 *lang.Var

var A_arbace_go_run_A_const_107 *lang.Var

var A_arbace_go_run_A_const_108 *lang.Var

var A_arbace_go_run_A_const_109 *lang.Var

var A_arbace_go_run_A_const_110 *lang.Var

var A_arbace_go_run_A_const_111 *lang.Var

var A_arbace_go_run_A_const_112 *lang.Var

var A_arbace_go_run_A_const_113 *lang.Var

var A_arbace_go_run_A_const_114 *lang.Keyword

var A_arbace_go_run_A_const_115 *lang.Var

var A_arbace_go_run_A_const_116 *lang.Var

var A_arbace_go_run_A_init jrt.ClassInit

func A_arbace_go_run_A_Init() { if !A_arbace_go_run_A_init.Done() { A_arbace_go_run_A_init.Run(A_arbace_go_run_A_clinit) } }

func A_arbace_go_run_A_clinit() { A_arbace_go_run_A_clinit_p0(); A_arbace_go_run_A_clinit_p1(); A_arbace_go_run_A_clinit_p2(); A_arbace_go_run_A_clinit_p3(); A_arbace_go_run_A_clinit_p4(); A_arbace_go_run_A_clinit_p5(); A_arbace_go_run_A_clinit_p6(); A_arbace_go_run_A_clinit_p7(); A_arbace_go_run_A_clinit_p8(); A_arbace_go_run_A_clinit_p9() }

func A_arbace_go_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 156); A_arbace_go_run_A_const_0 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[39]); A_arbace_go_run_A_const_1 = A_arbace_go_run_A_const_pool.A[40]; A_arbace_go_run_A_const_2 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[41]); A_arbace_go_run_A_const_3 = A_arbace_go_run_A_const_pool.A[42]; A_arbace_go_run_A_const_4 = A_arbace_go_run_A_const_pool.A[43]; A_arbace_go_run_A_const_5 = A_arbace_go_run_A_const_pool.A[44]; A_arbace_go_run_A_const_6 = A_arbace_go_run_A_const_pool.A[45]; A_arbace_go_run_A_const_7 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[46]); A_arbace_go_run_A_const_8 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[47]); A_arbace_go_run_A_const_9 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[48]); A_arbace_go_run_A_const_10 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[49]); A_arbace_go_run_A_const_11 = A_arbace_go_run_A_const_pool.A[50] }

func A_arbace_go_run_A_clinit_p1() { A_arbace_go_run_A_const_12 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[51]); A_arbace_go_run_A_const_13 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[52]); A_arbace_go_run_A_const_14 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[53]); A_arbace_go_run_A_const_15 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[54]); A_arbace_go_run_A_const_16 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[55]); A_arbace_go_run_A_const_17 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[56]); A_arbace_go_run_A_const_18 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[57]); A_arbace_go_run_A_const_19 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[58]); A_arbace_go_run_A_const_20 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[59]); A_arbace_go_run_A_const_21 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[60]); A_arbace_go_run_A_const_22 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[61]); A_arbace_go_run_A_const_23 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[62]) }

func A_arbace_go_run_A_clinit_p2() { A_arbace_go_run_A_const_24 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[63]); A_arbace_go_run_A_const_25 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[64]); A_arbace_go_run_A_const_26 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[65]); A_arbace_go_run_A_const_27 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[66]); A_arbace_go_run_A_const_28 = A_arbace_go_run_A_const_pool.A[67]; A_arbace_go_run_A_const_29 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[68]); A_arbace_go_run_A_const_30 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[69]); A_arbace_go_run_A_const_31 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[70]); A_arbace_go_run_A_const_32 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[71]); A_arbace_go_run_A_const_33 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[72]); A_arbace_go_run_A_const_34 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[73]); A_arbace_go_run_A_const_35 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[74]) }

func A_arbace_go_run_A_clinit_p3() { A_arbace_go_run_A_const_36 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[75]); A_arbace_go_run_A_const_37 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[76]); A_arbace_go_run_A_const_38 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[77]); A_arbace_go_run_A_const_39 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[78]); A_arbace_go_run_A_const_40 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[79]); A_arbace_go_run_A_const_41 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[80]); A_arbace_go_run_A_const_42 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[81]); A_arbace_go_run_A_const_43 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[82]); A_arbace_go_run_A_const_44 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[83]); A_arbace_go_run_A_const_45 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[84]); A_arbace_go_run_A_const_46 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[85]); A_arbace_go_run_A_const_47 = A_arbace_go_run_A_const_pool.A[86] }

func A_arbace_go_run_A_clinit_p4() { A_arbace_go_run_A_const_48 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[87]); A_arbace_go_run_A_const_49 = A_arbace_go_run_A_const_pool.A[88]; A_arbace_go_run_A_const_50 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[89]); A_arbace_go_run_A_const_51 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[90]); A_arbace_go_run_A_const_52 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[91]); A_arbace_go_run_A_const_53 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[92]); A_arbace_go_run_A_const_54 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[93]); A_arbace_go_run_A_const_55 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[94]); A_arbace_go_run_A_const_56 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[95]); A_arbace_go_run_A_const_57 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[96]); A_arbace_go_run_A_const_58 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[97]); A_arbace_go_run_A_const_59 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[98]) }

func A_arbace_go_run_A_clinit_p5() { A_arbace_go_run_A_const_60 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[99]); A_arbace_go_run_A_const_61 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[100]); A_arbace_go_run_A_const_62 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[101]); A_arbace_go_run_A_const_63 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[102]); A_arbace_go_run_A_const_64 = A_arbace_go_run_A_const_pool.A[103]; A_arbace_go_run_A_const_65 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[104]); A_arbace_go_run_A_const_66 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[105]); A_arbace_go_run_A_const_67 = A_arbace_go_run_A_const_pool.A[106]; A_arbace_go_run_A_const_68 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[107]); A_arbace_go_run_A_const_69 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[108]); A_arbace_go_run_A_const_70 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[109]); A_arbace_go_run_A_const_71 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[110]) }

func A_arbace_go_run_A_clinit_p6() { A_arbace_go_run_A_const_72 = A_arbace_go_run_A_const_pool.A[111]; A_arbace_go_run_A_const_73 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[112]); A_arbace_go_run_A_const_74 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[113]); A_arbace_go_run_A_const_75 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[114]); A_arbace_go_run_A_const_76 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[115]); A_arbace_go_run_A_const_77 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[116]); A_arbace_go_run_A_const_78 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[117]); A_arbace_go_run_A_const_79 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[118]); A_arbace_go_run_A_const_80 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[119]); A_arbace_go_run_A_const_81 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[120]); A_arbace_go_run_A_const_82 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[121]); A_arbace_go_run_A_const_83 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[122]) }

func A_arbace_go_run_A_clinit_p7() { A_arbace_go_run_A_const_84 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[123]); A_arbace_go_run_A_const_85 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[124]); A_arbace_go_run_A_const_86 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[125]); A_arbace_go_run_A_const_87 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[126]); A_arbace_go_run_A_const_88 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[127]); A_arbace_go_run_A_const_89 = A_arbace_go_run_A_const_pool.A[128]; A_arbace_go_run_A_const_90 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[129]); A_arbace_go_run_A_const_91 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[130]); A_arbace_go_run_A_const_92 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[131]); A_arbace_go_run_A_const_93 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[132]); A_arbace_go_run_A_const_94 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[133]); A_arbace_go_run_A_const_95 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[134]) }

func A_arbace_go_run_A_clinit_p8() { A_arbace_go_run_A_const_96 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[135]); A_arbace_go_run_A_const_97 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[136]); A_arbace_go_run_A_const_98 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[137]); A_arbace_go_run_A_const_99 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[138]); A_arbace_go_run_A_const_100 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[139]); A_arbace_go_run_A_const_101 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[140]); A_arbace_go_run_A_const_102 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[141]); A_arbace_go_run_A_const_103 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[142]); A_arbace_go_run_A_const_104 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[143]); A_arbace_go_run_A_const_105 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[144]); A_arbace_go_run_A_const_106 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[145]); A_arbace_go_run_A_const_107 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[146]) }

func A_arbace_go_run_A_clinit_p9() { A_arbace_go_run_A_const_108 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[147]); A_arbace_go_run_A_const_109 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[148]); A_arbace_go_run_A_const_110 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[149]); A_arbace_go_run_A_const_111 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[150]); A_arbace_go_run_A_const_112 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[151]); A_arbace_go_run_A_const_113 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[152]); A_arbace_go_run_A_const_114 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[153]); A_arbace_go_run_A_const_115 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[154]); A_arbace_go_run_A_const_116 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[155]) }

func A_arbace_go_run_A_New() *A_arbace_go_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_A) Ctor() {}

func (t *A_arbace_go_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_A_class }

func (t *A_arbace_go_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_A); return ok }

func A_arbace_go_run_A_Cast(x any) *A_arbace_go_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_A_class)) }; return v }



type A_arbace_go_run__main_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000115_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000115_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000117_A struct{ j2g_header uint64; F_pargs, F_pf, F_root any }

var A_arbace_go_run__main_fn__1938000117_A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__fn__1938000065_A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A struct{ j2g_header uint64; F_iter__1938000020, F_s__1938000021 any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A struct{ j2g_header uint64; F_b__1938000023 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_root_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_root_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000004_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000004_A_New() *A_arbace_go_run_eval1938000004_A { t := &A_arbace_go_run_eval1938000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000004_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000004_A_class }

func (t *A_arbace_go_run_eval1938000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000004_A); return ok }

func A_arbace_go_run_eval1938000004_A_Cast(x any) *A_arbace_go_run_eval1938000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000004_A_class)) }; return v }



type A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000008_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000008_A_New() *A_arbace_go_run_eval1938000008_A { t := &A_arbace_go_run_eval1938000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000008_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000008_A_class }

func (t *A_arbace_go_run_eval1938000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000008_A); return ok }

func A_arbace_go_run_eval1938000008_A_Cast(x any) *A_arbace_go_run_eval1938000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000008_A_class)) }; return v }



type A_arbace_go_run_eval1938000008_fn__1938000009_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_fn_class *jrt.Class



type A_arbace_go_run_fail_A struct{ j2g_header uint64 }

var A_arbace_go_run_fail_A_fn_class *jrt.Class



type A_arbace_go_run_fail_fn__1938000012_A struct{ j2g_header uint64; F_kind, F_msg any }

var A_arbace_go_run_fail_fn__1938000012_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_A struct{ j2g_header uint64 }

var A_arbace_go_run_imports_of_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A struct{ j2g_header uint64; F_s__1938000069, F_iter__1938000068, F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A struct{ j2g_header uint64; F_s__1938000071, F_li, F_iter__1938000070 any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A struct{ j2g_header uint64; F_b__1938000073, F_li any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__fn__1938000032_A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class *jrt.Class



type A_arbace_go_run_no_linkname_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_linkname_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__fn__1938000016_A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class *jrt.Class



type A_arbace_go_run_run_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_A struct{ j2g_header uint64; F_srcs, F_inits, F_deps any }

var A_arbace_go_run_run_define__1938000091_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000092_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class *jrt.Class



type A_arbace_go_run_run_extra__1938000089_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_extra__1938000089_A_fn_class *jrt.Class



type A_arbace_go_run_run_fn__1938000087_A struct{ j2g_header uint64; F_pf any }

var A_arbace_go_run_run_fn__1938000087_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000095_A struct{ j2g_header uint64; F_inits, F_deps any }

var A_arbace_go_run_run_init_order__1938000095_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A struct{ j2g_header uint64; F_done, F_deps any }

var A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_fn_class *jrt.Class



type A_arbace_go_run_run_load_BANG___1938000099_A struct{ j2g_header uint64; F_root, F_extra, F_srcs, F_index, F_define any }

var A_arbace_go_run_run_load_BANG___1938000099_A_fn_class *jrt.Class
