//line aot_arbace_go_run.ae:1
package aot_arbace_go_run

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_New() *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_1); lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_go_run_A_const_3, A_arbace_go_run_A_const_4, A_arbace_go_run_A_const_5, A_arbace_go_run_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_run_eval1938000008_fn__1938000009_A_New() *A_arbace_go_run_eval1938000008_fn__1938000009_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000008_fn__1938000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_go_run_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_run_A_const_10.GetRawRoot__O(), A_arbace_go_run_A_const_11) }

















func A_arbace_go_run_fail_A_New() *A_arbace_go_run_fail_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_run_fail_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_run_fail_A) Invoke_O_O_O_O__O(self, status__0, kind__1, msg__2 any) any {
	var root_45 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_20; var arg_48 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_21.Get__O()); if linked_46 == nil { ifn_47.Invoke_O__O(arg_48) } else { linked_46.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_45, arg_48) }; var tmp3 any = A_arbace_go_run_fail_fn__1938000012_A_New_O_O(kind__1, msg__2); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_run_fail_fn__1938000012_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_go_run_fail_fn__1938000012_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__0)); return nil }
//line :20:1
func A_arbace_go_run_fail_fn__1938000012_A_New_O_O(p0, p1 any) *A_arbace_go_run_fail_fn__1938000012_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_fn__1938000012_A{}; t.Ctor_O_O(p0, p1); return t }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Ctor_O_O(c__kind, c__msg any) { t.F_kind = c__kind; t.F_msg = c__msg }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil, Lit_9, nil); var tmp4 any; var t_ any = t.F_kind; t.F_kind = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var root_32 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_36 any = A_arbace_go_run_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var root_40 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var t__2 any = t.F_msg; t.F_msg = nil; arg_43 = t__2; if linked_41 == nil { arg_39 = ifn_42.Invoke_O__O(arg_43) } else { arg_39 = linked_41.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_40, arg_43) }; if linked_37 == nil { arg_35 = ifn_38.Invoke_O__O(arg_39) } else { arg_35 = linked_37.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_36, arg_39) }; if linked_33 == nil { tmp6 = ifn_34.Invoke_O__O(arg_35) } else { tmp6 = linked_33.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_32, arg_35) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref())
											var root_22 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; if linked_23 == nil { tmp1 = ifn_24.Invoke__O() } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_22) } }
//line :20:1
	return nil }(); var root_25 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; if linked_26 == nil { ifn_27.Invoke__O() } else { linked_26.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_25) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_go_run_run_A_New() *A_arbace_go_run_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_go_run_run_A) Ctor() {}
//line :25:1
func (t *A_arbace_go_run_run_A) Invoke_O_O_O_O__O(self, root__0, pf__1, args__2 any) any { var src__4 any; var root_54 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_56 lang.IFn; if


	linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_23, root__0)); var arg_58 any; var arg_59 any; var root_61 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); if linked_62 == nil { arg_59 = ifn_63.Invoke_O__O(arg_64) } else { arg_59 = linked_62.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_61, arg_64) }; var arg_60 any = pf__1; if linked_55 == nil { src__4 = ifn_56.Invoke_O_O_O_O__O(arg_57, arg_58, arg_59, arg_60) } else { src__4 = linked_55.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_54, arg_57, arg_58, arg_59, arg_60) }; var ___5 any; var tmp1 any; var root_65 any = /*line :25:1*/A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_67 lang.IFn; _ = ___5; if



	linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_go_run_A_const_26.Invoke_O__O(src__4); if linked_66 == nil { tmp1 = ifn_67.Invoke_O__O(arg_68) } else { tmp1 = linked_66.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_65, arg_68) }; if jrt.J2g_Truth(tmp1) { var root_69 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, A_arbace_go_run_fail_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = A_arbace_go_run_A_const_28; var arg_73 any = Lit_8; var arg_74 any = Lit_14; if linked_70 == nil { ___5 = ifn_71.Invoke_O_O_O__O(arg_72, arg_73, arg_74) } else { ___5 = linked_70.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_69, arg_72, arg_73, arg_74) } } else { ___5 = nil }; var r__6 any; var root_75 any = /*line :25:1*/A_arbace_go_run_A_const_29.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_77 lang.IFn; if




	linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = src__4; var arg_79 any; if linked_76 == nil { r__6 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { r__6 = linked_76.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; var errs__7 any = /*line :25:1*/A_arbace_go_run_A_const_30.Invoke_O__O(r__6); var temp__1927000414__auto____8 any; var root_121 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_123 lang.IFn; if






	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var tmp2 any = A_arbace_go_run_run_fn__1938000016_A_New(); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_go_run_run_fn__1938000016_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_run_run_fn__1938000016_A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; arg_124 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_125 any = errs__7; if linked_122 == nil { temp__1927000414__auto____8 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { temp__1927000414__auto____8 = linked_122.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var bi__9 any = temp__1927000414__auto____8; var root_127 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_go_run_fail_A_fn_class); var ifn_129 lang.IFn
		if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = A_arbace_go_run_A_const_28; var arg_131 any = Lit_8; var arg_132 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_53.Invoke_O__O(bi__9))).Ref(); if linked_128 == nil { ifn_129.Invoke_O_O_O__O(arg_130, arg_131, arg_132) } else { linked_128.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_127, arg_130, arg_131, arg_132) } }; var tmp4 any; var root_133 any =
	A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = errs__7; if linked_134 == nil { tmp4 = ifn_135.Invoke_O__O(arg_136) } else { tmp4 = linked_134.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(tmp4) {
		var root_137 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_go_run_fail_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = A_arbace_go_run_A_const_54; var arg_141 any = Lit_3; var arg_142 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_17, nil, Lit_18, nil, Lit_9, nil); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_55; var tmp7 any; var root_143 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = errs__7; if linked_144 == nil { tmp7 = ifn_145.Invoke_O__O(arg_146) } else { tmp7 = linked_144.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_143, arg_146) }; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Keyword = A_arbace_go_run_A_const_56; var tmp10 any; var root_147 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = errs__7; if linked_148 == nil { tmp10 = ifn_149.Invoke_O__O(arg_150) } else { tmp10 = linked_148.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_147, arg_150) }; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Keyword = A_arbace_go_run_A_const_53; var tmp13 any; var root_151 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = errs__7; if linked_152 == nil { tmp13 = ifn_153.Invoke_O__O(arg_154) } else { tmp13 = linked_152.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_151, arg_154) }; arg_142 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, nil, tmp11, nil, tmp12.Invoke_O__O(tmp13))).Ref(); if linked_138 == nil { ifn_139.Invoke_O_O_O__O(arg_140, arg_141, arg_142) } else { linked_138.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_137, arg_140, arg_141, arg_142) } }; var st__8 any; var root_80 any = /*line :25:1*/A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_82 lang.IFn; if










	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var tmp14 any = A_arbace_go_run_A_const_32; var tmp15 any = A_arbace_go_run_A_const_32.Invoke_O__O(src__4); var tmp16 any = A_arbace_go_run_A_const_33; var tmp17 any = A_arbace_go_run_A_const_33.Invoke_O__O(src__4); var tmp18 any = A_arbace_go_run_A_const_34; var tmp19 any; var root_84 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_33.Invoke_O__O(src__4))).Ref(); if linked_85 == nil { tmp19 = ifn_86.Invoke_O__O(arg_87) } else { tmp19 = linked_85.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_84, arg_87) }; var tmp20 any = tmp19; var tmp21 any = A_arbace_go_run_A_const_36; arg_83 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15, tmp16, tmp17, tmp18, tmp20, tmp21, A_arbace_go_run_A_const_36.Invoke_O__O(src__4), A_arbace_go_run_A_const_26, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_run_A_const_37, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_38, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_39, lang.PersistentArrayMap_EMPTY.Ref())); if linked_81 == nil { st__8 = ifn_82.Invoke_O__O(arg_83) } else { st__8 = linked_81.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_80, arg_83) }; var root_155 any =

	A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var arg_159 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var arg_160 any = A_arbace_go_run_A_const_32.Invoke_O__O(src__4); var arg_161 any = st__8; if linked_156 == nil { ifn_157.Invoke_O_O_O_O__O(arg_158, arg_159, arg_160, arg_161) } else { linked_156.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_155, arg_158, arg_159, arg_160, arg_161) }; var map__1938000018__9 any; var root_88 any = /*line :25:1*/A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_90 lang.IFn; if













	linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = st__8; var arg_92 any = r__6; var arg_93 any = A_arbace_go_run_A_const_41; if linked_89 == nil { map__1938000018__9 = ifn_90.Invoke_O_O_O__O(arg_91, arg_92, arg_93) } else { map__1938000018__9 = linked_89.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_88, arg_91, arg_92, arg_93) }; var map__1938000018__10 any; if lang.ISeq_InstanceOf(map__1938000018__9) { var tmp22 any; var root_94 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = map__1938000018__9; if linked_95 == nil { tmp22 = ifn_96.Invoke_O__O(arg_97) } else { tmp22 = linked_95.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_94, arg_97) }; if jrt.J2g_Truth(tmp22) { var tmp23 any; var root_98 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = map__1938000018__9; if linked_99 == nil { tmp23 = ifn_100.Invoke_O__O(arg_101) } else { tmp23 = linked_99.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_98, arg_101) }; map__1938000018__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp23, jrt.Object_class.ArrayClass())).Ref() } else { var tmp24 any; var root_102 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = map__1938000018__9; if linked_103 == nil { tmp24 = ifn_104.Invoke_O__O(arg_105) } else { tmp24 = linked_103.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_102, arg_105) }; if jrt.J2g_Truth(tmp24) { var root_106 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = map__1938000018__9; if linked_107 == nil { map__1938000018__10 = ifn_108.Invoke_O__O(arg_109) } else { map__1938000018__10 = linked_107.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_106, arg_109) } } else { map__1938000018__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1938000018__10 = map__1938000018__9 }; var inits__11 any = /*line :25:1*/lang.RT_Get_O_O__O_NoInit(map__1938000018__10, A_arbace_go_run_A_const_45); var init_funcs__12 any = lang.RT_Get_O_O__O_NoInit(map__1938000018__10, A_arbace_go_run_A_const_46); var main__13 any = lang.RT_Get_O_O__O_NoInit(map__1938000018__10, A_arbace_go_run_A_const_47); if














	jrt.J2g_Truth(main__13) { } else {
		var root_162 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, A_arbace_go_run_fail_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_go_run_A_const_54; var arg_166 any = Lit_3; var arg_167 any = Lit_20; if linked_163 == nil { ifn_164.Invoke_O_O_O__O(arg_165, arg_166, arg_167) } else { linked_163.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_162, arg_165, arg_166, arg_167) } }; var tmp25 lang.IFn =
	lang.IFn_Cast(A_arbace_go_run_A_const_48.GetRawRoot__O()); var tmp26 any; var root_173 any = A_arbace_go_run_A_const_49.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_178 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = jrt.NN(jrt.File_Cast(pf__1)).GetName__String().Ref(); if linked_179 == nil { arg_176 = ifn_180.Invoke_O__O(arg_181) } else { arg_176 = linked_179.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_178, arg_181) }; var arg_177 any = args__2; if linked_174 == nil { tmp26 = ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { tmp26 = linked_174.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) }; tmp25.Invoke_O_O__O(Lit_21, lang.RT_Object_array_O__O1_NoInit(tmp26).Ref()); var tmp27 lang.IFn =
	lang.IFn_Cast(A_arbace_go_run_A_const_48.GetRawRoot__O()); var tmp28 any; var root_116 any = A_arbace_go_run_A_const_49.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = inits__11; var arg_120 any = init_funcs__12; if linked_117 == nil { tmp28 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp28 = linked_117.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) }; return tmp27.Invoke_O_O_O__O(Lit_22, lang.RT_Object_array_O__O1_NoInit(tmp28).Ref(), main__13) }
//line :32:1
func A_arbace_go_run_run_fn__1938000016_A_New() *A_arbace_go_run_run_fn__1938000016_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_fn__1938000016_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_go_run_run_fn__1938000016_A) Ctor() {}
//line :32:1
func (t *A_arbace_go_run_run_fn__1938000016_A) Invoke_O_O__O(self, p1__1938000015_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_51; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_52.Invoke_O__O(p1__1938000015_SHARP___1)) { return p1__1938000015_SHARP___1 } else { return nil } }












func A_arbace_go_run__main_A_New() *A_arbace_go_run__main_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_go_run__main_A) Ctor() {}
//line :45:1
func (t *A_arbace_go_run__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1938000021__2 any = args__0; var seq__1938000022__3 any; var root_182 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_184 lang.IFn; if


	linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = vec__1938000021__2; if linked_183 == nil { seq__1938000022__3 = ifn_184.Invoke_O__O(arg_185) } else { seq__1938000022__3 = linked_183.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_182, arg_185) }; var first__1938000023__4 any; var root_186 any = /*line :45:1*/A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_188 lang.IFn; if


	linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = seq__1938000022__3; if linked_187 == nil { first__1938000023__4 = ifn_188.Invoke_O__O(arg_189) } else { first__1938000023__4 = linked_187.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_186, arg_189) }; var seq__1938000022__5 any; var root_190 any = /*line :45:1*/A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_192 lang.IFn; if


	linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = seq__1938000022__3; if linked_191 == nil { seq__1938000022__5 = ifn_192.Invoke_O__O(arg_193) } else { seq__1938000022__5 = linked_191.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_190, arg_193) }; var root__6 any = first__1938000023__4; var first__1938000023__7 any; var root_194 any = /*line :45:1*/A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_196 lang.IFn; if


	linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = seq__1938000022__5; if linked_195 == nil { first__1938000023__7 = ifn_196.Invoke_O__O(arg_197) } else { first__1938000023__7 = linked_195.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_194, arg_197) }; var seq__1938000022__8 any; var root_198 any = /*line :45:1*/A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_200 lang.IFn; if


	linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = seq__1938000022__5; if linked_199 == nil { seq__1938000022__8 = ifn_200.Invoke_O__O(arg_201) } else { seq__1938000022__8 = linked_199.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_198, arg_201) }; var ns_name__9 any = first__1938000023__7; var pargs__10 any = seq__1938000022__8; var tmp1 any; var and__1927000168__auto____11 any = root__6; if
	jrt.J2g_Truth(and__1927000168__auto____11) { tmp1 = ns_name__9 } else { tmp1 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp1) { } else {
		var root_246 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp3 any = A_arbace_go_run_A_const_20; var arg_249 any = tmp2.Invoke_O_O__O(tmp3, A_arbace_go_run_A_const_21.Get__O()); if linked_247 == nil { ifn_248.Invoke_O__O(arg_249) } else { linked_247.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_246, arg_249) }; var tmp4 any = A_arbace_go_run__main_fn__1938000024_A_New(); var tmp5 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_go_run__main_fn__1938000024_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_go_run__main_fn__1938000024_A_fn_class = fncls__245d; tmp5 = fncls__245d } else { tmp5 = fncls__245 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }; var pf__11 any; var tmp6 /*line :45:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp7 any; var root_202 any = A_arbace_go_run_A_const_60.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_204 lang.IFn; if






	linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = ns_name__9; if linked_203 == nil { tmp7 = ifn_204.Invoke_O__O(arg_205) } else { tmp7 = linked_203.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_202, arg_205) }; pf__11 = /*line :45:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, root__6, nil, tmp7))); if







	jrt.NN(jrt.File_Cast(pf__11)).IsFile__Z() { } else {
		var root_255 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, A_arbace_go_run_fail_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = A_arbace_go_run_A_const_54; var arg_259 any = Lit_3; var arg_260 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__11)).Ref(); if linked_256 == nil { ifn_257.Invoke_O_O_O__O(arg_258, arg_259, arg_260) } else { linked_256.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_255, arg_258, arg_259, arg_260) } }; var status__12 any; var tmp8 any = /*line :45:1*/A_arbace_go_run__main_fn__1938000026_A_New_O_O_O(pargs__10, pf__11, root__6); var tmp9 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_go_run__main_fn__1938000026_A_fn_class; if









	fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_run__main_fn__1938000026_A_fn_class = fncls__237d; tmp9 = fncls__237d } else { tmp9 = fncls__237 }; status__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O();








	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__12)); return nil }
//line :50:1
func A_arbace_go_run__main_fn__1938000024_A_New() *A_arbace_go_run__main_fn__1938000024_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000024_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_run__main_fn__1938000024_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_run__main_fn__1938000024_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_6); return nil }(); var root_242 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; if linked_243 == nil { ifn_244.Invoke__O() } else { linked_243.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_242) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_go_run__main_fn__1938000026_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run__main_fn__1938000026_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000026_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :55:1
func (t *A_arbace_go_run__main_fn__1938000026_A) Ctor_O_O_O(c__pargs, c__pf, c__root any) { t.F_pargs = c__pargs; t.F_pf = c__pf; t.F_root = c__root }
//line :55:1
func (t *A_arbace_go_run__main_fn__1938000026_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_206 any = A_arbace_go_run_A_const_61.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_go_run_run_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var t_ any = t.F_root; t.F_root = nil; arg_209 = t_; var arg_210 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_210 = t__2; var arg_211 any; var t__3 any = t.F_pargs; t.F_pargs = nil; arg_211 = t__3; if linked_207 == nil { tmp1 = ifn_208.Invoke_O_O_O__O(arg_209, arg_210, arg_211) } else { tmp1 = linked_207.(*A_arbace_go_run_run_A).Invoke_O_O_O_O__O(root_206, arg_209, arg_210, arg_211) } }
//line :55:1
	return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var d__4 any; var root_212 any = A_arbace_go_run_A_const_62.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_214 lang.IFn


		if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = ex__3; if linked_213 == nil { d__4 = ifn_214.Invoke_O__O(arg_215) } else { d__4 = linked_213.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_212, arg_215) }
//line :55:1
		var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_63.Invoke_O__O(d__4)



		if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp3 any; var root_216 any = A_arbace_go_run_A_const_64.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = m__7; var arg_220 any = Lit_7; if linked_217 == nil { tmp3 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { tmp3 = linked_217.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; if jrt.J2g_Truth(tmp3) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
		if jrt.J2g_Truth(u__5) {
			var root_221 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, A_arbace_go_run_fail_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = A_arbace_go_run_A_const_28; var arg_225 any = Lit_8; var arg_226 any = u__5; if linked_222 == nil { tmp1 = ifn_223.Invoke_O_O_O__O(arg_224, arg_225, arg_226) } else { tmp1 = linked_222.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_221, arg_224, arg_225, arg_226) } } else {
				var root_227 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_go_run_fail_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_go_run_A_const_54; var arg_231 any = Lit_3; var arg_232 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp5 any; var root_233 any = A_arbace_go_run_A_const_65.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = ex__3; if linked_234 == nil { tmp5 = ifn_235.Invoke_O__O(arg_236) } else { tmp5 = linked_234.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_233, arg_236) }; arg_232 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp5)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_228 == nil { tmp1 = ifn_229.Invoke_O_O_O__O(arg_230, arg_231, arg_232) } else { tmp1 = linked_228.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_227, arg_230, arg_231, arg_232) } } } }; return tmp1 }
//line :63:1
type A_arbace_go_run_A struct{ jrt.Object }

var A_arbace_go_run_A_const_pool *jrt.RefArray

var A_arbace_go_run_A_const_0 *lang.Var

var A_arbace_go_run_A_const_1 any

var A_arbace_go_run_A_const_2 *lang.Var

var A_arbace_go_run_A_const_3 any

var A_arbace_go_run_A_const_4 any

var A_arbace_go_run_A_const_5 any

var A_arbace_go_run_A_const_6 any

var A_arbace_go_run_A_const_7 *lang.Var

var A_arbace_go_run_A_const_8 *lang.Var

var A_arbace_go_run_A_const_9 *lang.Var

var A_arbace_go_run_A_const_10 *lang.Var

var A_arbace_go_run_A_const_11 any

var A_arbace_go_run_A_const_12 *lang.Var

var A_arbace_go_run_A_const_13 *lang.Var

var A_arbace_go_run_A_const_14 *lang.Var

var A_arbace_go_run_A_const_15 *lang.Var

var A_arbace_go_run_A_const_16 *lang.Var

var A_arbace_go_run_A_const_17 *lang.Var

var A_arbace_go_run_A_const_18 *lang.Var

var A_arbace_go_run_A_const_19 *lang.Var

var A_arbace_go_run_A_const_20 *lang.Var

var A_arbace_go_run_A_const_21 *lang.Var

var A_arbace_go_run_A_const_22 *lang.Var

var A_arbace_go_run_A_const_23 *lang.Keyword

var A_arbace_go_run_A_const_24 *lang.Var

var A_arbace_go_run_A_const_25 *lang.Var

var A_arbace_go_run_A_const_26 *lang.Keyword

var A_arbace_go_run_A_const_27 *lang.Var

var A_arbace_go_run_A_const_28 any

var A_arbace_go_run_A_const_29 *lang.Var

var A_arbace_go_run_A_const_30 *lang.Keyword

var A_arbace_go_run_A_const_31 *lang.Var

var A_arbace_go_run_A_const_32 *lang.Keyword

var A_arbace_go_run_A_const_33 *lang.Keyword

var A_arbace_go_run_A_const_34 *lang.Keyword

var A_arbace_go_run_A_const_35 *lang.Var

var A_arbace_go_run_A_const_36 *lang.Keyword

var A_arbace_go_run_A_const_37 *lang.Keyword

var A_arbace_go_run_A_const_38 *lang.Keyword

var A_arbace_go_run_A_const_39 *lang.Keyword

var A_arbace_go_run_A_const_40 *lang.Var

var A_arbace_go_run_A_const_41 any

var A_arbace_go_run_A_const_42 *lang.Var

var A_arbace_go_run_A_const_43 *lang.Var

var A_arbace_go_run_A_const_44 *lang.Var

var A_arbace_go_run_A_const_45 *lang.Keyword

var A_arbace_go_run_A_const_46 *lang.Keyword

var A_arbace_go_run_A_const_47 *lang.Keyword

var A_arbace_go_run_A_const_48 *lang.Var

var A_arbace_go_run_A_const_49 *lang.Var

var A_arbace_go_run_A_const_50 *lang.Var

var A_arbace_go_run_A_const_51 *lang.Keyword

var A_arbace_go_run_A_const_52 *lang.Keyword

var A_arbace_go_run_A_const_53 *lang.Keyword

var A_arbace_go_run_A_const_54 any

var A_arbace_go_run_A_const_55 *lang.Keyword

var A_arbace_go_run_A_const_56 *lang.Keyword

var A_arbace_go_run_A_const_57 *lang.Var

var A_arbace_go_run_A_const_58 *lang.Var

var A_arbace_go_run_A_const_59 *lang.Var

var A_arbace_go_run_A_const_60 *lang.Var

var A_arbace_go_run_A_const_61 *lang.Var

var A_arbace_go_run_A_const_62 *lang.Var

var A_arbace_go_run_A_const_63 *lang.Keyword

var A_arbace_go_run_A_const_64 *lang.Var

var A_arbace_go_run_A_const_65 *lang.Var

var A_arbace_go_run_A_init jrt.ClassInit

func A_arbace_go_run_A_Init() { if !A_arbace_go_run_A_init.Done() { A_arbace_go_run_A_init.Run(A_arbace_go_run_A_clinit) } }

func A_arbace_go_run_A_clinit() { A_arbace_go_run_A_clinit_p0(); A_arbace_go_run_A_clinit_p1(); A_arbace_go_run_A_clinit_p2(); A_arbace_go_run_A_clinit_p3(); A_arbace_go_run_A_clinit_p4(); A_arbace_go_run_A_clinit_p5() }

func A_arbace_go_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 98); A_arbace_go_run_A_const_0 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[32]); A_arbace_go_run_A_const_1 = A_arbace_go_run_A_const_pool.A[33]; A_arbace_go_run_A_const_2 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[34]); A_arbace_go_run_A_const_3 = A_arbace_go_run_A_const_pool.A[35]; A_arbace_go_run_A_const_4 = A_arbace_go_run_A_const_pool.A[36]; A_arbace_go_run_A_const_5 = A_arbace_go_run_A_const_pool.A[37]; A_arbace_go_run_A_const_6 = A_arbace_go_run_A_const_pool.A[38]; A_arbace_go_run_A_const_7 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[39]); A_arbace_go_run_A_const_8 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[40]); A_arbace_go_run_A_const_9 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[41]); A_arbace_go_run_A_const_10 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[42]); A_arbace_go_run_A_const_11 = A_arbace_go_run_A_const_pool.A[43] }

func A_arbace_go_run_A_clinit_p1() { A_arbace_go_run_A_const_12 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[44]); A_arbace_go_run_A_const_13 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[45]); A_arbace_go_run_A_const_14 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[46]); A_arbace_go_run_A_const_15 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[47]); A_arbace_go_run_A_const_16 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[48]); A_arbace_go_run_A_const_17 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[49]); A_arbace_go_run_A_const_18 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[50]); A_arbace_go_run_A_const_19 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[51]); A_arbace_go_run_A_const_20 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[52]); A_arbace_go_run_A_const_21 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[53]); A_arbace_go_run_A_const_22 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[54]); A_arbace_go_run_A_const_23 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[55]) }

func A_arbace_go_run_A_clinit_p2() { A_arbace_go_run_A_const_24 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[56]); A_arbace_go_run_A_const_25 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[57]); A_arbace_go_run_A_const_26 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[58]); A_arbace_go_run_A_const_27 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[59]); A_arbace_go_run_A_const_28 = A_arbace_go_run_A_const_pool.A[60]; A_arbace_go_run_A_const_29 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[61]); A_arbace_go_run_A_const_30 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[62]); A_arbace_go_run_A_const_31 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[63]); A_arbace_go_run_A_const_32 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[64]); A_arbace_go_run_A_const_33 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[65]); A_arbace_go_run_A_const_34 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[66]); A_arbace_go_run_A_const_35 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[67]) }

func A_arbace_go_run_A_clinit_p3() { A_arbace_go_run_A_const_36 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[68]); A_arbace_go_run_A_const_37 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[69]); A_arbace_go_run_A_const_38 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[70]); A_arbace_go_run_A_const_39 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[71]); A_arbace_go_run_A_const_40 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[72]); A_arbace_go_run_A_const_41 = A_arbace_go_run_A_const_pool.A[73]; A_arbace_go_run_A_const_42 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[74]); A_arbace_go_run_A_const_43 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[75]); A_arbace_go_run_A_const_44 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[76]); A_arbace_go_run_A_const_45 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[77]); A_arbace_go_run_A_const_46 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[78]); A_arbace_go_run_A_const_47 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[79]) }

func A_arbace_go_run_A_clinit_p4() { A_arbace_go_run_A_const_48 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[80]); A_arbace_go_run_A_const_49 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[81]); A_arbace_go_run_A_const_50 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[82]); A_arbace_go_run_A_const_51 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[83]); A_arbace_go_run_A_const_52 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[84]); A_arbace_go_run_A_const_53 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[85]); A_arbace_go_run_A_const_54 = A_arbace_go_run_A_const_pool.A[86]; A_arbace_go_run_A_const_55 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[87]); A_arbace_go_run_A_const_56 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[88]); A_arbace_go_run_A_const_57 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[89]); A_arbace_go_run_A_const_58 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[90]); A_arbace_go_run_A_const_59 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[91]) }

func A_arbace_go_run_A_clinit_p5() { A_arbace_go_run_A_const_60 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[92]); A_arbace_go_run_A_const_61 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[93]); A_arbace_go_run_A_const_62 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[94]); A_arbace_go_run_A_const_63 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[95]); A_arbace_go_run_A_const_64 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[96]); A_arbace_go_run_A_const_65 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[97]) }

func A_arbace_go_run_A_New() *A_arbace_go_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_A) Ctor() {}

func (t *A_arbace_go_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_A_class }

func (t *A_arbace_go_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_A); return ok }

func A_arbace_go_run_A_Cast(x any) *A_arbace_go_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_A_class)) }; return v }



type A_arbace_go_run__main_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000024_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000024_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000026_A struct{ j2g_header uint64; F_pargs, F_pf, F_root any }

var A_arbace_go_run__main_fn__1938000026_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000004_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000004_A_New() *A_arbace_go_run_eval1938000004_A { t := &A_arbace_go_run_eval1938000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000004_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000004_A_class }

func (t *A_arbace_go_run_eval1938000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000004_A); return ok }

func A_arbace_go_run_eval1938000004_A_Cast(x any) *A_arbace_go_run_eval1938000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000004_A_class)) }; return v }



type A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000008_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000008_A_New() *A_arbace_go_run_eval1938000008_A { t := &A_arbace_go_run_eval1938000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000008_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000008_A_class }

func (t *A_arbace_go_run_eval1938000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000008_A); return ok }

func A_arbace_go_run_eval1938000008_A_Cast(x any) *A_arbace_go_run_eval1938000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000008_A_class)) }; return v }



type A_arbace_go_run_eval1938000008_fn__1938000009_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_fn_class *jrt.Class



type A_arbace_go_run_fail_A struct{ j2g_header uint64 }

var A_arbace_go_run_fail_A_fn_class *jrt.Class



type A_arbace_go_run_fail_fn__1938000012_A struct{ j2g_header uint64; F_kind, F_msg any }

var A_arbace_go_run_fail_fn__1938000012_A_fn_class *jrt.Class



type A_arbace_go_run_run_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_A_fn_class *jrt.Class



type A_arbace_go_run_run_fn__1938000016_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_fn__1938000016_A_fn_class *jrt.Class
