//line aot_arbace_go_run.ae:1
package aot_arbace_go_run

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_New() *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_1); lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_go_run_A_const_3, A_arbace_go_run_A_const_4, A_arbace_go_run_A_const_5, A_arbace_go_run_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_50)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_51)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_run_eval1938000008_fn__1938000009_A_New() *A_arbace_go_run_eval1938000008_fn__1938000009_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000008_fn__1938000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_go_run_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_run_A_const_10.GetRawRoot__O(), A_arbace_go_run_A_const_11) }

















func A_arbace_go_run_fail_A_New() *A_arbace_go_run_fail_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_run_fail_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_run_fail_A) Invoke_O_O_O_O__O(self, status__0, kind__1, msg__2 any) any {
	var root_46 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_20; var arg_49 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_21.Get__O()); if linked_47 == nil { ifn_48.Invoke_O__O(arg_49) } else { linked_47.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_46, arg_49) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__45 any = A_arbace_go_run_fail_fn__1938000012_A_New_O_O(kind__1, msg__2); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_run_fail_fn__1938000012_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__45); A_arbace_go_run_fail_fn__1938000012_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__45, tmp4, nil); Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()


	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__0)); return nil }
//line :20:1
func A_arbace_go_run_fail_fn__1938000012_A_New_O_O(p0, p1 any) *A_arbace_go_run_fail_fn__1938000012_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_fn__1938000012_A{}; t.Ctor_O_O(p0, p1); return t }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Ctor_O_O(c__kind, c__msg any) { t.F_kind = c__kind; t.F_msg = c__msg }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_15, nil); var tmp4 any; var t_ any = t.F_kind; t.F_kind = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var root_32 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_36 any = A_arbace_go_run_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var root_40 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var t__2 any = t.F_msg; t.F_msg = nil; arg_43 = t__2; if linked_41 == nil { arg_39 = ifn_42.Invoke_O__O(arg_43) } else { arg_39 = linked_41.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_40, arg_43) }; if linked_37 == nil { arg_35 = ifn_38.Invoke_O__O(arg_39) } else { arg_35 = linked_37.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_36, arg_39) }; if linked_33 == nil { tmp6 = ifn_34.Invoke_O__O(arg_35) } else { tmp6 = linked_33.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_32, arg_35) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref())
											var root_22 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; if linked_23 == nil { tmp1 = ifn_24.Invoke__O() } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_22) } }
//line :20:1
	return nil }(); var root_25 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; if linked_26 == nil { ifn_27.Invoke__O() } else { linked_26.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_25) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_go_run_package_file_QMARK__A_New() *A_arbace_go_run_package_file_QMARK__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 bool = jrt.File_Cast(f__0).IsFile__Z(); if and__1927000168__auto____2 {
											var and__1927000168__auto____3 any; var root_55 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = jrt.File_Cast(f__0).GetName__String().Ref(); var arg_59 any = Lit_64; if linked_56 == nil { and__1927000168__auto____3 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { and__1927000168__auto____3 = linked_56.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var r__4 any = jrt.BufferedReader_New_Reader(jrt.FileReader_New_File(jrt.File_Cast(f__0))); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__7 any; var root_60 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_62 lang.IFn

		if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_64 any = A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var fnbody__79 any = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New(); var tmp2 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class = fncls__78d; tmp2 = fncls__78d } else { tmp2 = fncls__78 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp2, nil); var arg_68 any; var root_80 any = A_arbace_go_run_A_const_26.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = r__4; if linked_81 == nil { arg_68 = ifn_82.Invoke_O__O(arg_83) } else { arg_68 = linked_81.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_80, arg_83) }; if linked_65 == nil { arg_63 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { arg_63 = linked_65.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if linked_61 == nil { l__7 = ifn_62.Invoke_O__O(arg_63) } else { l__7 = linked_61.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_60, arg_63) }
		var tmp3 any; var and__1927000168__auto____8 any = l__7; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_84 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = l__7; var arg_88 any = Lit_66; if linked_85 == nil { tmp3 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { tmp3 = linked_85.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_84, arg_87, arg_88) } } else { tmp3 = and__1927000168__auto____8 }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() }; return nil }()
//line :27:1
		jrt.BufferedReader_Cast(r__4).Close__V()
//line :26:1
		if tmp4 != nil { panic(tmp4) }; return tmp1 } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New() *A_arbace_go_run_package_file_QMARK__fn__1938000016_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__fn__1938000016_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Ctor() {}
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Invoke_O_O__O(self, p1__1938000015_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_69 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = p1__1938000015_SHARP___1; if linked_70 == nil { or__1927000174__auto____2 = ifn_71.Invoke_O__O(arg_72) } else { or__1927000174__auto____2 = linked_70.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_73 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = p1__1938000015_SHARP___1; var arg_77 any = Lit_67; if linked_74 == nil { return ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { return linked_74.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_73, arg_76, arg_77) } } }


func A_arbace_go_run_dir_test_root_A_New() *A_arbace_go_run_dir_test_root_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_root_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Invoke_O_O__O(self, pf__0 any) any { { var n__2 any = jrt.File_Cast(pf__0).GetName__String().Ref(); var sib__3 any; var tmp1 jrt.File_I = jrt.File_Cast(pf__0).GetParentFile__File(); var tmp2 any; var root_89 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_91 lang.IFn




	if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = n__2; var arg_93 any = A_arbace_go_run_A_const_28; var arg_94 any = Lit_22; if linked_90 == nil { tmp2 = ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { tmp2 = linked_90.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) }
//line :31:1
	sib__3 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2))





	var tmp3 any; var and__1927000168__auto____4 any; var root_95 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = n__2; var arg_99 any = Lit_23; if linked_96 == nil { and__1927000168__auto____4 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { and__1927000168__auto____4 = linked_96.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(sib__3).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { return sib__3 } else { var d__4 any = jrt.File_Cast(pf__0).GetParentFile__File(); L1: for {


		if lang.Util_Identical_O_O__Z_NoInit(d__4, nil) { return nil } else { var tmp4 any; var root_100 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_102 lang.IFn

			if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = jrt.File_Cast(d__4).GetName__String().Ref(); var arg_104 any = Lit_24; if linked_101 == nil { tmp4 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp4 = linked_101.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }
//line :40:1
			if jrt.J2g_Truth(tmp4) { return d__4 } else { if A_arbace_go_run_A_const_29 != nil {


				d__4 = jrt.File_Cast(d__4).GetParentFile__File(); continue L1 } else {
//line :40:1
					return nil } } } } } }; /*line :31:1*/panic("j2g: unreachable") }













func A_arbace_go_run_dir_test_index_A_New() *A_arbace_go_run_dir_test_index_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Ctor() {}
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Invoke_O_O__O(self, pf__0 any) any { var temp__1927000408__auto____2 any; var root_105 any = A_arbace_go_run_A_const_30.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_go_run_dir_test_root_A_fn_class); var ifn_107 lang.IFn; if



	linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = pf__0; if linked_106 == nil { temp__1927000408__auto____2 = ifn_107.Invoke_O__O(arg_108) } else { temp__1927000408__auto____2 = linked_106.(*A_arbace_go_run_dir_test_root_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var root_109 any = A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_111 lang.IFn
		if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_113 any; var iter__1927001039__auto____4 any; var fnbody__199 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New(); var tmp1 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class
		if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class = fncls__198d; tmp1 = fncls__198d } else { tmp1 = fncls__198 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__199, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp3 any; var root_200 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = pf__0; var arg_204 any; var root_205 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = d__3; if linked_206 == nil { arg_204 = ifn_207.Invoke_O__O(arg_208) } else { arg_204 = linked_206.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_205, arg_208) }; if linked_201 == nil { tmp3 = ifn_202.Invoke_O_O__O(arg_203, arg_204) } else { tmp3 = linked_201.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_200, arg_203, arg_204) }; arg_113 = tmp2.Invoke_O__O(tmp3)
//line :50:1
		if linked_110 == nil { return ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { return linked_110.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) } } else {
//line :49:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }

func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New() *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Invoke_O_O__O(self, s__1938000021__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__197 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(self, s__1938000021__1); var tmp2 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__197); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class = fncls__196d; tmp2 = fncls__196d } else { tmp2 = fncls__196 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__197, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(p0, p1 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Ctor_O_O(c__iter__1938000020, c__s__1938000021 any) { t.F_iter__1938000020 = c__iter__1938000020; t.F_s__1938000021 = c__s__1938000021 }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Invoke_O__O(self any) any { { var s__1938000021__1 any; var t_ any = t.F_s__1938000021; t.F_s__1938000021 = nil; s__1938000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_114 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = s__1938000021__1; if linked_115 == nil { temp__1927000414__auto____2 = ifn_116.Invoke_O__O(arg_117) } else { temp__1927000414__auto____2 = linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_118 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = s__1938000021__3; if linked_119 == nil { tmp1 = ifn_120.Invoke_O__O(arg_121) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_118, arg_121) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_122 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = s__1938000021__3; if linked_123 == nil { c__1927001037__auto____4 = ifn_124.Invoke_O__O(arg_125) } else { c__1927001037__auto____4 = linked_123.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_122, arg_125) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000023__6 any; var root_126 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_127 == nil { b__1938000023__6 = ifn_128.Invoke_O__O(arg_129) } else { b__1938000023__6 = linked_127.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_126, arg_129) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(b__1938000023__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__144); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_145 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any; var root_150 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = b__1938000023__6; if linked_151 == nil { arg_148 = ifn_152.Invoke_O__O(arg_153) } else { arg_148 = linked_151.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_150, arg_153) }; var arg_149 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp5 any; var root_154 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__1938000021__3; if linked_155 == nil { tmp5 = ifn_156.Invoke_O__O(arg_157) } else { tmp5 = linked_155.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_154, arg_157) }; arg_149 = tmp4.Invoke_O__O(tmp5); if linked_146 == nil { return ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { return linked_146.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) } } else { var root_158 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var root_163 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = b__1938000023__6; if linked_164 == nil { arg_161 = ifn_165.Invoke_O__O(arg_166) } else { arg_161 = linked_164.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_163, arg_166) }; var arg_162 any; if linked_159 == nil { return ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { return linked_159.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_158, arg_161, arg_162) } } } else { var f__4 any; var root_167 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = s__1938000021__3; if linked_168 == nil { f__4 = ifn_169.Invoke_O__O(arg_170) } else { f__4 = linked_168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_167, arg_170) }; var tmp6 any; var root_171 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_173 lang.IFn
															if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = f__4; if linked_172 == nil { tmp6 = ifn_173.Invoke_O__O(arg_174) } else { tmp6 = linked_172.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_171, arg_174) }
//line :51:1
	if jrt.J2g_Truth(tmp6) { var p__5 any; var root_175 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_177 lang.IFn

		if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = f__4; if linked_176 == nil { p__5 = ifn_177.Invoke_O__O(arg_178) } else { p__5 = linked_176.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_175, arg_178) }
//line :51:1
		if jrt.J2g_Truth(p__5) { var root_179 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = lang.Tuple_Create_O_O__IPersistentVector(p__5, f__4); var arg_183 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp8 any; var root_184 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__1938000021__3; if linked_185 == nil { tmp8 = ifn_186.Invoke_O__O(arg_187) } else { tmp8 = linked_185.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_184, arg_187) }; arg_183 = tmp7.Invoke_O__O(tmp8); if linked_180 == nil { return ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { return linked_180.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_179, arg_182, arg_183) } } else { var tmp9 any; var root_188 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = s__1938000021__3; if linked_189 == nil { tmp9 = ifn_190.Invoke_O__O(arg_191) } else { tmp9 = linked_189.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_188, arg_191) }; s__1938000021__1 = tmp9; continue L1 } } else { var tmp10 any; var root_192 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = s__1938000021__3; if linked_193 == nil { tmp10 = ifn_194.Invoke_O__O(arg_195) } else { tmp10 = linked_193.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_192, arg_195) }; s__1938000021__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Ctor_O_I_O(c__b__1938000023 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000023 = c__b__1938000023; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Invoke_O__O(self any) any { { var i__1938000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000022__1)); var tmp2 any; var root_130 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_132 lang.IFn
																if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = f__2; if linked_131 == nil { tmp2 = ifn_132.Invoke_O__O(arg_133) } else { tmp2 = linked_131.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_130, arg_133) }
//line :51:1
	if jrt.J2g_Truth(tmp2) { var p__3 any; var root_134 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_136 lang.IFn

		if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = f__2; if linked_135 == nil { p__3 = ifn_136.Invoke_O__O(arg_137) } else { p__3 = linked_135.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_134, arg_137) }
//line :51:1
		if jrt.J2g_Truth(p__3) { var root_138 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = t.F_b__1938000023; var arg_142 any = lang.Tuple_Create_O_O__IPersistentVector(p__3, f__2); if linked_139 == nil { ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { linked_139.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) }; i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_run_no_assembly_BANG__A_New() *A_arbace_go_run_no_assembly_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Ctor() {}
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Invoke_O_O__O(self, src__0 any) any { var temp__1927000414__auto____2 any; var root_209 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_211 lang.IFn; if
											linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var fnbody__224 any = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New(); var tmp1 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class = fncls__223d; tmp1 = fncls__223d } else { tmp1 = fncls__223 }; arg_212 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__224, tmp1, nil); var arg_213 any; var root_225 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = src__0; var arg_229 any = A_arbace_go_run_A_const_47; if linked_226 == nil { arg_213 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { arg_213 = linked_226.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) }; if linked_210 == nil { temp__1927000414__auto____2 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { temp__1927000414__auto____2 = linked_210.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; var root_230 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, A_arbace_go_run_fail_A_fn_class); var ifn_232 lang.IFn
												if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = A_arbace_go_run_A_const_49; var arg_234 any = Lit_14; var arg_235 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, s__3, nil)).Ref(); if linked_231 == nil { return ifn_232.Invoke_O_O_O__O(arg_233, arg_234, arg_235) } else { return linked_231.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_230, arg_233, arg_234, arg_235) } } else {
//line :59:1
			return nil } }
//line :59:1
func A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New() *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Ctor() {}
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Invoke_O_O__O(self, p1__1938000031_SHARP___1 any) any { var tmp1 any; var root_214 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any; var root_219 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = p1__1938000031_SHARP___1; if linked_220 == nil { arg_217 = ifn_221.Invoke_O__O(arg_222) } else { arg_217 = linked_220.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_219, arg_222) }; var arg_218 any = Lit_62; if linked_215 == nil { tmp1 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { tmp1 = linked_215.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }; if jrt.J2g_Truth(tmp1) { return p1__1938000031_SHARP___1 } else { return nil } }


func A_arbace_go_run_no_linkname_BANG__A_New() *A_arbace_go_run_no_linkname_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_linkname_BANG__A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Ctor() {}
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Invoke_O_O__O(self, src__0 any) any { { var seq_1938000035__2 any; var root_236 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_238 lang.IFn
											if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__0); if linked_237 == nil { seq_1938000035__2 = ifn_238.Invoke_O__O(arg_239) } else { seq_1938000035__2 = linked_237.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_236, arg_239) }
//line :62:1
	var chunk_1938000036__3 any; var count_1938000037__4 int64 = 0; var i_1938000038__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000038__5, count_1938000037__4) { var fi__6 any = lang.Indexed_Cast(chunk_1938000036__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000038__5)); var seq_1938000051__7 any; var root_256 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__6); if linked_257 == nil { seq_1938000051__7 = ifn_258.Invoke_O__O(arg_259) } else { seq_1938000051__7 = linked_257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_256, arg_259) }; var chunk_1938000052__8 any; var count_1938000053__9 int64 = 0; var i_1938000054__10 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000054__10, count_1938000053__9) { var d__11 any = lang.Indexed_Cast(chunk_1938000052__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000054__10)); var seq_1938000059__12 any; var root_276 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any; var root_280 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_282 lang.IFn
			if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_284 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_285 any = d__11; if linked_281 == nil { arg_279 = ifn_282.Invoke_O_O_O__O(arg_283, arg_284, arg_285) } else { arg_279 = linked_281.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_280, arg_283, arg_284, arg_285) }
//line :63:1
			if linked_277 == nil { seq_1938000059__12 = ifn_278.Invoke_O__O(arg_279) } else { seq_1938000059__12 = linked_277.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_276, arg_279) }; var chunk_1938000060__13 any; var count_1938000061__14 int64 = 0; var i_1938000062__15 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000062__15, count_1938000061__14) { var x__16 any = lang.Indexed_Cast(chunk_1938000060__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000062__15)); var tmp1 any; var and__1927000168__auto____17 bool = lang.IObj_InstanceOf(x__16)

				if and__1927000168__auto____17 { var tmp2 *lang.Keyword = A_arbace_go_run_A_const_55; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() }
//line :63:1
				if jrt.J2g_Truth(tmp1) {


					var root_302 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, A_arbace_go_run_fail_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = A_arbace_go_run_A_const_49; var arg_306 any = Lit_14; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_307 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)), nil)).Ref(); if linked_303 == nil { ifn_304.Invoke_O_O_O__O(arg_305, arg_306, arg_307) } else { linked_303.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_302, arg_305, arg_306, arg_307) }
//line :63:1
					seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } else { seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } } else { var temp__1927000414__auto____16 any; var root_286 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = seq_1938000059__12; if linked_287 == nil { temp__1927000414__auto____16 = ifn_288.Invoke_O__O(arg_289) } else { temp__1927000414__auto____16 = linked_287.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1938000059__17 any = temp__1927000414__auto____16; var tmp4 any; var root_290 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = seq_1938000059__17; if linked_291 == nil { tmp4 = ifn_292.Invoke_O__O(arg_293) } else { tmp4 = linked_291.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_290, arg_293) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_294 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = seq_1938000059__17; if linked_295 == nil { c__1927000678__auto____18 = ifn_296.Invoke_O__O(arg_297) } else { c__1927000678__auto____18 = linked_295.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_294, arg_297) }; var tmp5 any; var root_308 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = seq_1938000059__17; if linked_309 == nil { tmp5 = ifn_310.Invoke_O__O(arg_311) } else { tmp5 = linked_309.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_308, arg_311) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var x__18 any; var root_298 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = seq_1938000059__17; if linked_299 == nil { x__18 = ifn_300.Invoke_O__O(arg_301) } else { x__18 = linked_299.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_298, arg_301) }; var tmp6 any; var and__1927000168__auto____19 bool = lang.IObj_InstanceOf(x__18)

						if and__1927000168__auto____19 { var tmp7 *lang.Keyword = A_arbace_go_run_A_const_55; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }
//line :63:1
						if jrt.J2g_Truth(tmp6) {


							var root_312 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, A_arbace_go_run_fail_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = A_arbace_go_run_A_const_49; var arg_316 any = Lit_14; var tmp8 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_317 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)), nil)).Ref(); if linked_313 == nil { ifn_314.Invoke_O_O_O__O(arg_315, arg_316, arg_317) } else { linked_313.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_312, arg_315, arg_316, arg_317) }
//line :63:1
							var tmp9 any; var root_318 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = seq_1938000059__17; if linked_319 == nil { tmp9 = ifn_320.Invoke_O__O(arg_321) } else { tmp9 = linked_319.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_318, arg_321) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp9, nil, 0, 0; continue L3 } else { var tmp10 any; var root_322 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = seq_1938000059__17; if linked_323 == nil { tmp10 = ifn_324.Invoke_O__O(arg_325) } else { tmp10 = linked_323.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_322, arg_325) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp10, nil, 0, 0; continue L3 } } } }; break L3 }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000054__10); continue L2 } else { var temp__1927000414__auto____11 any; var root_260 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = seq_1938000051__7; if linked_261 == nil { temp__1927000414__auto____11 = ifn_262.Invoke_O__O(arg_263) } else { temp__1927000414__auto____11 = linked_261.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_260, arg_263) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1938000051__12 any = temp__1927000414__auto____11; var tmp11 any; var root_264 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = seq_1938000051__12; if linked_265 == nil { tmp11 = ifn_266.Invoke_O__O(arg_267) } else { tmp11 = linked_265.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_264, arg_267) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_268 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = seq_1938000051__12; if linked_269 == nil { c__1927000678__auto____13 = ifn_270.Invoke_O__O(arg_271) } else { c__1927000678__auto____13 = linked_269.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_268, arg_271) }; var tmp12 any; var root_326 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = seq_1938000051__12; if linked_327 == nil { tmp12 = ifn_328.Invoke_O__O(arg_329) } else { tmp12 = linked_327.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_326, arg_329) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__13 any; var root_272 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = seq_1938000051__12; if linked_273 == nil { d__13 = ifn_274.Invoke_O__O(arg_275) } else { d__13 = linked_273.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_272, arg_275) }; var seq_1938000055__14 any; var root_330 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any; var root_334 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_336 lang.IFn
								if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_338 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_339 any = d__13; if linked_335 == nil { arg_333 = ifn_336.Invoke_O_O_O__O(arg_337, arg_338, arg_339) } else { arg_333 = linked_335.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_334, arg_337, arg_338, arg_339) }
//line :63:1
								if linked_331 == nil { seq_1938000055__14 = ifn_332.Invoke_O__O(arg_333) } else { seq_1938000055__14 = linked_331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_330, arg_333) }; var chunk_1938000056__15 any; var count_1938000057__16 int64 = 0; var i_1938000058__17 int64 = 0; L4: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000058__17, count_1938000057__16) { var x__18_2 any = lang.Indexed_Cast(chunk_1938000056__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000058__17)); var tmp13 any; var and__1927000168__auto____19_2 bool = lang.IObj_InstanceOf(x__18_2)

									if and__1927000168__auto____19_2 { var tmp14 *lang.Keyword = A_arbace_go_run_A_const_55; tmp13 = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_2).Ref() }
//line :63:1
									if jrt.J2g_Truth(tmp13) {


										var root_356 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, A_arbace_go_run_fail_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = A_arbace_go_run_A_const_49; var arg_360 any = Lit_14; var tmp15 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_361 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp15.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)), nil)).Ref(); if linked_357 == nil { ifn_358.Invoke_O_O_O__O(arg_359, arg_360, arg_361) } else { linked_357.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_356, arg_359, arg_360, arg_361) }
//line :63:1
										seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } else { seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } } else { var temp__1927000414__auto____18 any; var root_340 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = seq_1938000055__14; if linked_341 == nil { temp__1927000414__auto____18 = ifn_342.Invoke_O__O(arg_343) } else { temp__1927000414__auto____18 = linked_341.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_340, arg_343) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000055__19 any = temp__1927000414__auto____18; var tmp16 any; var root_344 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = seq_1938000055__19; if linked_345 == nil { tmp16 = ifn_346.Invoke_O__O(arg_347) } else { tmp16 = linked_345.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_344, arg_347) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____20 any; var root_348 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = seq_1938000055__19; if linked_349 == nil { c__1927000678__auto____20 = ifn_350.Invoke_O__O(arg_351) } else { c__1927000678__auto____20 = linked_349.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_348, arg_351) }; var tmp17 any; var root_362 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = seq_1938000055__19; if linked_363 == nil { tmp17 = ifn_364.Invoke_O__O(arg_365) } else { tmp17 = linked_363.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_362, arg_365) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp17, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__20 any; var root_352 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = seq_1938000055__19; if linked_353 == nil { x__20 = ifn_354.Invoke_O__O(arg_355) } else { x__20 = linked_353.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_352, arg_355) }; var tmp18 any; var and__1927000168__auto____21 bool = lang.IObj_InstanceOf(x__20)

											if and__1927000168__auto____21 { var tmp19 *lang.Keyword = A_arbace_go_run_A_const_55; tmp18 = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)) } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }
//line :63:1
											if jrt.J2g_Truth(tmp18) {


												var root_366 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_go_run_fail_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_go_run_A_const_49; var arg_370 any = Lit_14; var tmp20 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_371 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)), nil)).Ref(); if linked_367 == nil { ifn_368.Invoke_O_O_O__O(arg_369, arg_370, arg_371) } else { linked_367.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_366, arg_369, arg_370, arg_371) }
//line :63:1
												var tmp21 any; var root_372 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = seq_1938000055__19; if linked_373 == nil { tmp21 = ifn_374.Invoke_O__O(arg_375) } else { tmp21 = linked_373.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_372, arg_375) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp21, nil, 0, 0; continue L4 } else { var tmp22 any; var root_376 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = seq_1938000055__19; if linked_377 == nil { tmp22 = ifn_378.Invoke_O__O(arg_379) } else { tmp22 = linked_377.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_376, arg_379) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp22, nil, 0, 0; continue L4 } } } }; break L4 }; var tmp23 any; var root_380 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = seq_1938000051__12; if linked_381 == nil { tmp23 = ifn_382.Invoke_O__O(arg_383) } else { tmp23 = linked_381.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_380, arg_383) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp23, nil, 0, 0; continue L2 } } }; break L2 }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000038__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_240 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = seq_1938000035__2; if linked_241 == nil { temp__1927000414__auto____6 = ifn_242.Invoke_O__O(arg_243) } else { temp__1927000414__auto____6 = linked_241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_240, arg_243) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1938000035__7 any = temp__1927000414__auto____6; var tmp24 any; var root_244 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = seq_1938000035__7; if linked_245 == nil { tmp24 = ifn_246.Invoke_O__O(arg_247) } else { tmp24 = linked_245.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_244, arg_247) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____8 any; var root_248 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = seq_1938000035__7; if linked_249 == nil { c__1927000678__auto____8 = ifn_250.Invoke_O__O(arg_251) } else { c__1927000678__auto____8 = linked_249.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_248, arg_251) }; var tmp25 any; var root_384 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = seq_1938000035__7; if linked_385 == nil { tmp25 = ifn_386.Invoke_O__O(arg_387) } else { tmp25 = linked_385.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_384, arg_387) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp25, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__8 any; var root_252 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = seq_1938000035__7; if linked_253 == nil { fi__8 = ifn_254.Invoke_O__O(arg_255) } else { fi__8 = linked_253.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_252, arg_255) }; var seq_1938000039__9 any; var root_388 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__8); if linked_389 == nil { seq_1938000039__9 = ifn_390.Invoke_O__O(arg_391) } else { seq_1938000039__9 = linked_389.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_388, arg_391) }; var chunk_1938000040__10 any; var count_1938000041__11 int64 = 0; var i_1938000042__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000042__12, count_1938000041__11) { var d__13_2 any = lang.Indexed_Cast(chunk_1938000040__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000042__12)); var seq_1938000047__14 any; var root_408 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var root_412 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_414 lang.IFn
													if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_416 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_417 any = d__13_2; if linked_413 == nil { arg_411 = ifn_414.Invoke_O_O_O__O(arg_415, arg_416, arg_417) } else { arg_411 = linked_413.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_412, arg_415, arg_416, arg_417) }
//line :63:1
													if linked_409 == nil { seq_1938000047__14 = ifn_410.Invoke_O__O(arg_411) } else { seq_1938000047__14 = linked_409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_408, arg_411) }; var chunk_1938000048__15 any; var count_1938000049__16 int64 = 0; var i_1938000050__17 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000050__17, count_1938000049__16) { var x__18_3 any = lang.Indexed_Cast(chunk_1938000048__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000050__17)); var tmp26 any; var and__1927000168__auto____19_3 bool = lang.IObj_InstanceOf(x__18_3)

														if and__1927000168__auto____19_3 { var tmp27 *lang.Keyword = A_arbace_go_run_A_const_55; tmp26 = tmp27.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)) } else { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_3).Ref() }
//line :63:1
														if jrt.J2g_Truth(tmp26) {


															var root_434 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, A_arbace_go_run_fail_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = A_arbace_go_run_A_const_49; var arg_438 any = Lit_14; var tmp28 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_439 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp28.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)), nil)).Ref(); if linked_435 == nil { ifn_436.Invoke_O_O_O__O(arg_437, arg_438, arg_439) } else { linked_435.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_434, arg_437, arg_438, arg_439) }
//line :63:1
															seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } else { seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } } else { var temp__1927000414__auto____18_2 any; var root_418 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = seq_1938000047__14; if linked_419 == nil { temp__1927000414__auto____18_2 = ifn_420.Invoke_O__O(arg_421) } else { temp__1927000414__auto____18_2 = linked_419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_418, arg_421) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1938000047__19 any = temp__1927000414__auto____18_2; var tmp29 any; var root_422 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = seq_1938000047__19; if linked_423 == nil { tmp29 = ifn_424.Invoke_O__O(arg_425) } else { tmp29 = linked_423.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____20_2 any; var root_426 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = seq_1938000047__19; if linked_427 == nil { c__1927000678__auto____20_2 = ifn_428.Invoke_O__O(arg_429) } else { c__1927000678__auto____20_2 = linked_427.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_426, arg_429) }; var tmp30 any; var root_440 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = seq_1938000047__19; if linked_441 == nil { tmp30 = ifn_442.Invoke_O__O(arg_443) } else { tmp30 = linked_441.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_440, arg_443) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp30, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__20_2 any; var root_430 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1938000047__19; if linked_431 == nil { x__20_2 = ifn_432.Invoke_O__O(arg_433) } else { x__20_2 = linked_431.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_430, arg_433) }; var tmp31 any; var and__1927000168__auto____21_2 bool = lang.IObj_InstanceOf(x__20_2)

																if and__1927000168__auto____21_2 { var tmp32 *lang.Keyword = A_arbace_go_run_A_const_55; tmp31 = tmp32.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }
//line :63:1
																if jrt.J2g_Truth(tmp31) {


																	var root_444 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, A_arbace_go_run_fail_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = A_arbace_go_run_A_const_49; var arg_448 any = Lit_14; var tmp33 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_449 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp33.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)), nil)).Ref(); if linked_445 == nil { ifn_446.Invoke_O_O_O__O(arg_447, arg_448, arg_449) } else { linked_445.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_444, arg_447, arg_448, arg_449) }
//line :63:1
																	var tmp34 any; var root_450 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = seq_1938000047__19; if linked_451 == nil { tmp34 = ifn_452.Invoke_O__O(arg_453) } else { tmp34 = linked_451.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_450, arg_453) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp34, nil, 0, 0; continue L6 } else { var tmp35 any; var root_454 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1938000047__19; if linked_455 == nil { tmp35 = ifn_456.Invoke_O__O(arg_457) } else { tmp35 = linked_455.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_454, arg_457) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp35, nil, 0, 0; continue L6 } } } }; break L6 }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000042__12); continue L5 } else { var temp__1927000414__auto____13 any; var root_392 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = seq_1938000039__9; if linked_393 == nil { temp__1927000414__auto____13 = ifn_394.Invoke_O__O(arg_395) } else { temp__1927000414__auto____13 = linked_393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_392, arg_395) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1938000039__14 any = temp__1927000414__auto____13; var tmp36 any; var root_396 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = seq_1938000039__14; if linked_397 == nil { tmp36 = ifn_398.Invoke_O__O(arg_399) } else { tmp36 = linked_397.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_396, arg_399) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____15 any; var root_400 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = seq_1938000039__14; if linked_401 == nil { c__1927000678__auto____15 = ifn_402.Invoke_O__O(arg_403) } else { c__1927000678__auto____15 = linked_401.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_400, arg_403) }; var tmp37 any; var root_458 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = seq_1938000039__14; if linked_459 == nil { tmp37 = ifn_460.Invoke_O__O(arg_461) } else { tmp37 = linked_459.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_458, arg_461) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp37, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var d__15 any; var root_404 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = seq_1938000039__14; if linked_405 == nil { d__15 = ifn_406.Invoke_O__O(arg_407) } else { d__15 = linked_405.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_404, arg_407) }; var seq_1938000043__16 any; var root_462 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any; var root_466 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_468 lang.IFn
																		if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_470 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_471 any = d__15; if linked_467 == nil { arg_465 = ifn_468.Invoke_O_O_O__O(arg_469, arg_470, arg_471) } else { arg_465 = linked_467.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_466, arg_469, arg_470, arg_471) }
//line :63:1
																		if linked_463 == nil { seq_1938000043__16 = ifn_464.Invoke_O__O(arg_465) } else { seq_1938000043__16 = linked_463.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_462, arg_465) }; var chunk_1938000044__17 any; var count_1938000045__18 int64 = 0; var i_1938000046__19 int64 = 0; L7: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000046__19, count_1938000045__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1938000044__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000046__19)); var tmp38 any; var and__1927000168__auto____21_3 bool = lang.IObj_InstanceOf(x__20_3)

																			if and__1927000168__auto____21_3 { var tmp39 *lang.Keyword = A_arbace_go_run_A_const_55; tmp38 = tmp39.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)) } else { tmp38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_3).Ref() }
//line :63:1
																			if jrt.J2g_Truth(tmp38) {


																				var root_488 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, A_arbace_go_run_fail_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = A_arbace_go_run_A_const_49; var arg_492 any = Lit_14; var tmp40 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_493 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp40.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)), nil)).Ref(); if linked_489 == nil { ifn_490.Invoke_O_O_O__O(arg_491, arg_492, arg_493) } else { linked_489.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_488, arg_491, arg_492, arg_493) }
//line :63:1
																				seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } else { seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } } else { var temp__1927000414__auto____20 any; var root_472 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = seq_1938000043__16; if linked_473 == nil { temp__1927000414__auto____20 = ifn_474.Invoke_O__O(arg_475) } else { temp__1927000414__auto____20 = linked_473.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_472, arg_475) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1938000043__21 any = temp__1927000414__auto____20; var tmp41 any; var root_476 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = seq_1938000043__21; if linked_477 == nil { tmp41 = ifn_478.Invoke_O__O(arg_479) } else { tmp41 = linked_477.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_476, arg_479) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____22 any; var root_480 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = seq_1938000043__21; if linked_481 == nil { c__1927000678__auto____22 = ifn_482.Invoke_O__O(arg_483) } else { c__1927000678__auto____22 = linked_481.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_480, arg_483) }; var tmp42 any; var root_494 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = seq_1938000043__21; if linked_495 == nil { tmp42 = ifn_496.Invoke_O__O(arg_497) } else { tmp42 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp42, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22 any; var root_484 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = seq_1938000043__21; if linked_485 == nil { x__22 = ifn_486.Invoke_O__O(arg_487) } else { x__22 = linked_485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_484, arg_487) }; var tmp43 any; var and__1927000168__auto____23 bool = lang.IObj_InstanceOf(x__22)

																					if and__1927000168__auto____23 { var tmp44 *lang.Keyword = A_arbace_go_run_A_const_55; tmp43 = tmp44.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)) } else { tmp43 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }
//line :63:1
																					if jrt.J2g_Truth(tmp43) {


																						var root_498 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, A_arbace_go_run_fail_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = A_arbace_go_run_A_const_49; var arg_502 any = Lit_14; var tmp45 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_503 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)), nil)).Ref(); if linked_499 == nil { ifn_500.Invoke_O_O_O__O(arg_501, arg_502, arg_503) } else { linked_499.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_498, arg_501, arg_502, arg_503) }
//line :63:1
																						var tmp46 any; var root_504 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = seq_1938000043__21; if linked_505 == nil { tmp46 = ifn_506.Invoke_O__O(arg_507) } else { tmp46 = linked_505.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_504, arg_507) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp46, nil, 0, 0; continue L7 } else { var tmp47 any; var root_508 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seq_1938000043__21; if linked_509 == nil { tmp47 = ifn_510.Invoke_O__O(arg_511) } else { tmp47 = linked_509.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_508, arg_511) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp47, nil, 0, 0; continue L7 } } } }; break L7 }; var tmp48 any; var root_512 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = seq_1938000039__14; if linked_513 == nil { tmp48 = ifn_514.Invoke_O__O(arg_515) } else { tmp48 = linked_513.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_512, arg_515) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp48, nil, 0, 0; continue L5 } } }; break L5 }; var tmp49 any; var root_516 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = seq_1938000035__7; if linked_517 == nil { tmp49 = ifn_518.Invoke_O__O(arg_519) } else { tmp49 = linked_517.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_516, arg_519) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp49, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :62:1*/panic("j2g: unreachable") }





func A_arbace_go_run_check_BANG__A_New() *A_arbace_go_run_check_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Ctor() {}
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Invoke_O_O_O__O(self, src__0, extra__1 any) any {
	var root_525 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = src__0; if linked_526 == nil { ifn_527.Invoke_O__O(arg_528) } else { linked_526.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_525, arg_528) }
	var root_529 any = A_arbace_go_run_A_const_60.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, A_arbace_go_run_no_linkname_BANG__A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = src__0; if linked_530 == nil { ifn_531.Invoke_O__O(arg_532) } else { linked_530.(*A_arbace_go_run_no_linkname_BANG__A).Invoke_O_O__O(root_529, arg_532) }
//line :68:1
	var r__3 any; var root_520 any = A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_522 lang.IFn


	if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = src__0; var arg_524 any = extra__1; if linked_521 == nil { r__3 = ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { r__3 = linked_521.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) }
//line :68:1
	var errs__4 any = A_arbace_go_run_A_const_58.Invoke_O__O(r__3); var temp__1927000414__auto____5 any; var root_533 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_535 lang.IFn




	if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any; var fnbody__539 any = A_arbace_go_run_check_BANG__fn__1938000065_A_New(); var tmp1 *jrt.Class; var fncls__538 *jrt.Class = A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class; if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class = fncls__538d; tmp1 = fncls__538d } else { tmp1 = fncls__538 }; arg_536 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__539, tmp1, nil); var arg_537 any = errs__4; if linked_534 == nil { temp__1927000414__auto____5 = ifn_535.Invoke_O_O__O(arg_536, arg_537) } else { temp__1927000414__auto____5 = linked_534.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_533, arg_536, arg_537) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var bi__6 any = temp__1927000414__auto____5; var root_540 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, A_arbace_go_run_fail_A_fn_class); var ifn_542 lang.IFn
		if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = A_arbace_go_run_A_const_49; var arg_544 any = Lit_14; var arg_545 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_63.Invoke_O__O(bi__6))).Ref(); if linked_541 == nil { ifn_542.Invoke_O_O_O__O(arg_543, arg_544, arg_545) } else { linked_541.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_540, arg_543, arg_544, arg_545) } }
	var tmp2 any; var root_546 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = errs__4; if linked_547 == nil { tmp2 = ifn_548.Invoke_O__O(arg_549) } else { tmp2 = linked_547.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_546, arg_549) }; if jrt.J2g_Truth(tmp2) {
		var root_550 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, A_arbace_go_run_fail_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = A_arbace_go_run_A_const_64; var arg_554 any = Lit_4; var arg_555 any; var tmp3 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp4 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__0); var tmp5 *lang.Keyword = A_arbace_go_run_A_const_65; var tmp6 any; var root_556 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = errs__4; if linked_557 == nil { tmp6 = ifn_558.Invoke_O__O(arg_559) } else { tmp6 = linked_557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_556, arg_559) }; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 *lang.Keyword = A_arbace_go_run_A_const_66; var tmp9 any; var root_560 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = errs__4; if linked_561 == nil { tmp9 = ifn_562.Invoke_O__O(arg_563) } else { tmp9 = linked_561.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_560, arg_563) }; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 *lang.Keyword = A_arbace_go_run_A_const_63; var tmp12 any; var root_564 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = errs__4; if linked_565 == nil { tmp12 = ifn_566.Invoke_O__O(arg_567) } else { tmp12 = linked_565.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_564, arg_567) }; arg_555 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp7, nil, tmp10, nil, tmp11.Invoke_O__O(tmp12))).Ref(); if linked_551 == nil { ifn_552.Invoke_O_O_O__O(arg_553, arg_554, arg_555) } else { linked_551.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_550, arg_553, arg_554, arg_555) } }
//line :68:1
	return r__3
}



func A_arbace_go_run_check_BANG__fn__1938000065_A_New() *A_arbace_go_run_check_BANG__fn__1938000065_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__fn__1938000065_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Ctor() {}
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Invoke_O_O__O(self, p1__1938000064_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_61; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000064_SHARP___1)) { return p1__1938000064_SHARP___1 } else { return nil } }





func A_arbace_go_run_imports_of_A_New() *A_arbace_go_run_imports_of_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Invoke_O_O__O(self, src__0 any) any { var li__2 any; var root_568 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_570 lang.IFn; if


	linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = src__0; var arg_572 any = A_arbace_go_run_A_const_67; if linked_569 == nil { li__2 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { li__2 = linked_569.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; var root_573 any =
	A_arbace_go_run_A_const_68.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var iter__1927001039__auto____3 any; var fnbody__700 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(li__2); var tmp1 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class; if
	fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__700); A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class = fncls__699d; tmp1 = fncls__699d } else { tmp1 = fncls__699 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__700, tmp1, nil); arg_576 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_run_A_const_51.Invoke_O__O(src__0)); if /*line :83:1*/ linked_574 == nil { return ifn_575.Invoke_O__O(arg_576) } else { return linked_574.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_573, arg_576) } }
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Invoke_O_O__O(self, s__1938000069__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__698 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(s__1938000069__1, self, t.F_li); var tmp2 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__698); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class = fncls__697d; tmp2 = fncls__697d } else { tmp2 = fncls__697 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__698, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Ctor_O_O_O(c__s__1938000069, c__iter__1938000068, c__li any) { t.F_s__1938000069 = c__s__1938000069; t.F_iter__1938000068 = c__iter__1938000068; t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Invoke_O__O(self any) any { { var s__1938000069__1 any; var t_ any = t.F_s__1938000069; t.F_s__1938000069 = nil; s__1938000069__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_577 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = s__1938000069__1; if linked_578 == nil { temp__1927000414__auto____2 = ifn_579.Invoke_O__O(arg_580) } else { temp__1927000414__auto____2 = linked_578.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_577, arg_580) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var fi__4 any; var root_581 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = xs__1927001018__auto____3; if linked_582 == nil { fi__4 = ifn_583.Invoke_O__O(arg_584) } else { fi__4 = linked_582.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_581, arg_584) }; var iterys__1927001035__auto____5 any; var fnbody__674 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(t.F_li); var tmp1 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__674); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class = fncls__673d; tmp1 = fncls__673d } else { tmp1 = fncls__673 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__674, tmp1, nil); var fs__1927001036__auto____6 any; var root_675 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_679 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_681 lang.IFn
														if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = fi__4; var arg_683 any = A_arbace_go_run_A_const_72; if linked_680 == nil { tmp3 = ifn_681.Invoke_O_O__O(arg_682, arg_683) } else { tmp3 = linked_680.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_679, arg_682, arg_683) }
//line :84:1
	arg_678 = tmp2.Invoke_O__O(tmp3); if linked_676 == nil { fs__1927001036__auto____6 = ifn_677.Invoke_O__O(arg_678) } else { fs__1927001036__auto____6 = linked_676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_675, arg_678) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_684 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = fs__1927001036__auto____6; var arg_688 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000068); var tmp5 any; var root_689 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = s__1938000069__1; if linked_690 == nil { tmp5 = ifn_691.Invoke_O__O(arg_692) } else { tmp5 = linked_690.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_689, arg_692) }; arg_688 = tmp4.Invoke_O__O(tmp5); if linked_685 == nil { return ifn_686.Invoke_O_O__O(arg_687, arg_688) } else { return linked_685.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_684, arg_687, arg_688) } } else { var tmp6 any; var root_693 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = s__1938000069__1; if linked_694 == nil { tmp6 = ifn_695.Invoke_O__O(arg_696) } else { tmp6 = linked_694.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_693, arg_696) }; s__1938000069__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Invoke_O_O__O(self, s__1938000071__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__672 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(s__1938000071__1, t.F_li, self); var tmp2 *jrt.Class; var fncls__671 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class; if fncls__671 == nil { var fncls__671d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__672); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class = fncls__671d; tmp2 = fncls__671d } else { tmp2 = fncls__671 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__672, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Ctor_O_O_O(c__s__1938000071, c__li, c__iter__1938000070 any) { t.F_s__1938000071 = c__s__1938000071; t.F_li = c__li; t.F_iter__1938000070 = c__iter__1938000070 }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Invoke_O__O(self any) any { { var s__1938000071__1 any; var t_ any = t.F_s__1938000071; t.F_s__1938000071 = nil; s__1938000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_585 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = s__1938000071__1; if linked_586 == nil { temp__1927000414__auto____2 = ifn_587.Invoke_O__O(arg_588) } else { temp__1927000414__auto____2 = linked_586.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_589 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = s__1938000071__3; if linked_590 == nil { tmp1 = ifn_591.Invoke_O__O(arg_592) } else { tmp1 = linked_590.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_589, arg_592) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_593 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = s__1938000071__3; if linked_594 == nil { c__1927001037__auto____4 = ifn_595.Invoke_O__O(arg_596) } else { c__1927001037__auto____4 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_593, arg_596) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000073__6 any; var root_597 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_598 == nil { b__1938000073__6 = ifn_599.Invoke_O__O(arg_600) } else { b__1938000073__6 = linked_598.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_597, arg_600) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__619 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(b__1938000073__6, t.F_li, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__618 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class; if fncls__618 == nil { var fncls__618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__619); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class = fncls__618d; tmp3 = fncls__618d } else { tmp3 = fncls__618 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__619, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_620 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any; var root_625 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = b__1938000073__6; if linked_626 == nil { arg_623 = ifn_627.Invoke_O__O(arg_628) } else { arg_623 = linked_626.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_625, arg_628) }; var arg_624 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp5 any; var root_629 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = s__1938000071__3; if linked_630 == nil { tmp5 = ifn_631.Invoke_O__O(arg_632) } else { tmp5 = linked_630.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_629, arg_632) }; arg_624 = tmp4.Invoke_O__O(tmp5); if linked_621 == nil { return ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { return linked_621.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) } } else { var root_633 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any; var root_638 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = b__1938000073__6; if linked_639 == nil { arg_636 = ifn_640.Invoke_O__O(arg_641) } else { arg_636 = linked_639.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_638, arg_641) }; var arg_637 any; if linked_634 == nil { return ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { return linked_634.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_633, arg_636, arg_637) } } } else { var spec__4 any; var root_642 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = s__1938000071__3; if linked_643 == nil { spec__4 = ifn_644.Invoke_O__O(arg_645) } else { spec__4 = linked_643.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_642, arg_645) }; var p__5 any; var tmp6 any; var root_646 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_648 lang.IFn

	if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = spec__4; if linked_647 == nil { tmp6 = ifn_648.Invoke_O__O(arg_649) } else { tmp6 = linked_647.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(tmp6) { var root_650 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = spec__4; if linked_651 == nil { p__5 = ifn_652.Invoke_O__O(arg_653) } else { p__5 = linked_651.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_650, arg_653) } } else { p__5 = spec__4 }
//line :84:1
	var tmp7 any; var root_654 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_656 lang.IFn


	if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = p__5; if linked_655 == nil { tmp7 = ifn_656.Invoke_O__O(arg_657) } else { tmp7 = linked_655.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_654, arg_657) }
//line :84:1
	if jrt.J2g_Truth(tmp7) { var root_658 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__5, p__5); var arg_662 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp9 any; var root_663 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = s__1938000071__3; if linked_664 == nil { tmp9 = ifn_665.Invoke_O__O(arg_666) } else { tmp9 = linked_664.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_663, arg_666) }; arg_662 = tmp8.Invoke_O__O(tmp9); if linked_659 == nil { return ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { return linked_659.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) } } else { var tmp10 any; var root_667 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = s__1938000071__3; if linked_668 == nil { tmp10 = ifn_669.Invoke_O__O(arg_670) } else { tmp10 = linked_668.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_667, arg_670) }; s__1938000071__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Ctor_O_O_I_O(c__b__1938000073, c__li any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000073 = c__b__1938000073; t.F_li = c__li; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Invoke_O__O(self any) any { { var i__1938000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000072__1)); var p__3 any; var tmp2 any; var root_601 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_603 lang.IFn

	if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = spec__2; if linked_602 == nil { tmp2 = ifn_603.Invoke_O__O(arg_604) } else { tmp2 = linked_602.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_601, arg_604) }; if jrt.J2g_Truth(tmp2) { var root_605 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = spec__2; if linked_606 == nil { p__3 = ifn_607.Invoke_O__O(arg_608) } else { p__3 = linked_606.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_605, arg_608) } } else { p__3 = spec__2 }
//line :84:1
	var tmp3 any; var root_609 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_611 lang.IFn


	if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = p__3; if linked_610 == nil { tmp3 = ifn_611.Invoke_O__O(arg_612) } else { tmp3 = linked_610.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_609, arg_612) }
//line :84:1
	if jrt.J2g_Truth(tmp3) { var root_613 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = t.F_b__1938000073; var arg_617 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__3, p__3); if linked_614 == nil { ifn_615.Invoke_O_O__O(arg_616, arg_617) } else { linked_614.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_613, arg_616, arg_617) }; i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } else { i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_run_A_New() *A_arbace_go_run_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_run_run_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_run_run_A) Invoke_O_O_O_O__O(self, root__0, pf__1, args__2 any) any {




	var root_941 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var arg_945 any = jrt.Boolean_TRUE.Ref(); if linked_942 == nil { ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { linked_942.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_941, arg_944, arg_945)
	}
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_110.GetRawRoot__O()); var tmp2 any; var root_951 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any; var root_956 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = jrt.File_Cast(pf__1).GetName__String().Ref(); if linked_957 == nil { arg_954 = ifn_958.Invoke_O__O(arg_959) } else { arg_954 = linked_957.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_956, arg_959) }; var arg_955 any = args__2; if linked_952 == nil { tmp2 = ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { tmp2 = linked_952.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }; tmp1.Invoke_O_O__O(Lit_77, lang.RT_Object_array_O__O1_NoInit(tmp2).Ref())
//line :90:1
	var src__4 any; var root_701 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_703 lang.IFn







	if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, root__0)); var arg_705 any; var arg_706 any; var root_708 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_709 == nil { arg_706 = ifn_710.Invoke_O__O(arg_711) } else { arg_706 = linked_709.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_708, arg_711) }; var arg_707 any = pf__1; if linked_702 == nil { src__4 = ifn_703.Invoke_O_O_O_O__O(arg_704, arg_705, arg_706, arg_707) } else { src__4 = linked_702.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_701, arg_704, arg_705, arg_706, arg_707) }
//line :90:1
	var ___5 any; var tmp3 any; var root_712 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_714 lang.IFn; _ = ___5








	if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__4); if linked_713 == nil { tmp3 = ifn_714.Invoke_O__O(arg_715) } else { tmp3 = linked_713.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_712, arg_715) }; if jrt.J2g_Truth(tmp3) { var root_716 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, A_arbace_go_run_fail_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = A_arbace_go_run_A_const_49; var arg_720 any = Lit_14; var arg_721 any = Lit_26; if linked_717 == nil { ___5 = ifn_718.Invoke_O_O_O__O(arg_719, arg_720, arg_721) } else { ___5 = linked_717.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_716, arg_719, arg_720, arg_721) } } else { ___5 = nil }
//line :90:1
	var index__6 any; var tmp4 *lang.Compiler_AOTFn; var fnbody__727 any = A_arbace_go_run_run_fn__1938000087_A_New_O(pf__1); var tmp5 *jrt.Class
	var fncls__726 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_fn__1938000087_A_fn_class









	if fncls__726 == nil { var fncls__726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__727); A_arbace_go_run_run_fn__1938000087_A_fn_class = fncls__726d; tmp5 = fncls__726d } else { tmp5 = fncls__726 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__727, tmp5, nil)
//line :90:1
	index__6 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp4)); var srcs__7 any; var root_728 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_730 lang.IFn










	if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_729 == nil { srcs__7 = ifn_730.Invoke_O__O(arg_731) } else { srcs__7 = linked_729.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_728, arg_731) }
//line :90:1
	var inits__8 any; var root_732 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_734 lang.IFn











	if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_733 == nil { inits__8 = ifn_734.Invoke_O__O(arg_735) } else { inits__8 = linked_733.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_732, arg_735) }
//line :90:1
	var deps__9 any; var root_736 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_738 lang.IFn












	if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_737 == nil { deps__9 = ifn_738.Invoke_O__O(arg_739) } else { deps__9 = linked_737.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_736, arg_739) }
//line :90:1
	var extra__10 any; var fnbody__745 any = A_arbace_go_run_run_extra__1938000089_A_New_O(srcs__7); var tmp6 *jrt.Class
	var fncls__744 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_extra__1938000089_A_fn_class













	if fncls__744 == nil { var fncls__744d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__745); A_arbace_go_run_run_extra__1938000089_A_fn_class = fncls__744d; tmp6 = fncls__744d } else { tmp6 = fncls__744 }; extra__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__745, tmp6, nil)
//line :90:1
	var define__11 any; var fnbody__825 any = A_arbace_go_run_run_define__1938000091_A_New_O_O_O(srcs__7, inits__8, deps__9); var tmp7 *jrt.Class
	var fncls__824 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_define__1938000091_A_fn_class














	if fncls__824 == nil { var fncls__824d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__825); A_arbace_go_run_run_define__1938000091_A_fn_class = fncls__824d; tmp7 = fncls__824d } else { tmp7 = fncls__824 }; define__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__825, tmp7, nil)
//line :90:1
	var init_order__12 any; var fnbody__897 any = A_arbace_go_run_run_init_order__1938000097_A_New_O_O(inits__8, deps__9); var tmp8 *jrt.Class
	var fncls__896 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_init_order__1938000097_A_fn_class




























	if fncls__896 == nil { var fncls__896d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__897); A_arbace_go_run_run_init_order__1938000097_A_fn_class = fncls__896d; tmp8 = fncls__896d } else { tmp8 = fncls__896 }; init_order__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__897, tmp8, nil)
//line :90:1
	var body_load_BANG___13 *A_arbace_go_run_run_load_BANG___1938000101_A = A_arbace_go_run_run_load_BANG___1938000101_A_New_O_O_O_O_O(root__0, extra__10, srcs__7, index__6, define__11); var load_BANG___13 any; var fnbody__1057 any = any(body_load_BANG___13); var tmp9 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_go_run_run_load_BANG___1938000101_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1057); A_arbace_go_run_run_load_BANG___1938000101_A_fn_class = fncls__1056d; tmp9 = fncls__1056d } else { tmp9 = fncls__1056 }; load_BANG___13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1057, tmp9, nil); var seq_1938000107__14 any; var root_1058 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1060 lang.IFn












































	if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any; var root_1062 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, A_arbace_go_run_imports_of_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = src__4; if linked_1063 == nil { arg_1061 = ifn_1064.Invoke_O__O(arg_1065) } else { arg_1061 = linked_1063.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1062, arg_1065) }; if linked_1059 == nil { seq_1938000107__14 = ifn_1060.Invoke_O__O(arg_1061) } else { seq_1938000107__14 = linked_1059.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1058, arg_1061) }
//line :90:1
	var chunk_1938000108__15 any; var count_1938000109__16 int64 = 0; var i_1938000110__17 int64 = 0; L1: for {












































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000110__17, count_1938000109__16) { var p__18 any = lang.Indexed_Cast(chunk_1938000108__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000110__17)); lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__18, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000110__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1066 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = seq_1938000107__14; if linked_1067 == nil { temp__1927000414__auto____18 = ifn_1068.Invoke_O__O(arg_1069) } else { temp__1927000414__auto____18 = linked_1067.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1066, arg_1069) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000107__19 any = temp__1927000414__auto____18; var tmp10 any; var root_1070 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = seq_1938000107__19; if linked_1071 == nil { tmp10 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp10 = linked_1071.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1070, arg_1073) }; if jrt.J2g_Truth(tmp10) { var c__1927000678__auto____20 any; var root_1074 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = seq_1938000107__19; if linked_1075 == nil { c__1927000678__auto____20 = ifn_1076.Invoke_O__O(arg_1077) } else { c__1927000678__auto____20 = linked_1075.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1074, arg_1077) }; var tmp11 any; var root_1082 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = seq_1938000107__19; if linked_1083 == nil { tmp11 = ifn_1084.Invoke_O__O(arg_1085) } else { tmp11 = linked_1083.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1082, arg_1085) }; seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = tmp11, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__20 any; var root_1078 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = seq_1938000107__19; if linked_1079 == nil { p__20 = ifn_1080.Invoke_O__O(arg_1081) } else { p__20 = linked_1079.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1078, arg_1081) }; lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__20, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); var tmp12 any; var root_1086 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = seq_1938000107__19; if linked_1087 == nil { tmp12 = ifn_1088.Invoke_O__O(arg_1089) } else { tmp12 = linked_1087.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1086, arg_1089) }; seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = tmp12, nil, 0, 0; continue L1 } } }
//line :90:1
		break L1 }; var r__13 any; var root_898 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, A_arbace_go_run_check_BANG__A_fn_class); var ifn_900 lang.IFn













































	if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = src__4; var arg_902 any = extra__10; if linked_899 == nil { r__13 = ifn_900.Invoke_O_O__O(arg_901, arg_902) } else { r__13 = linked_899.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_898, arg_901, arg_902) }
//line :90:1
	var ___14 any; var root_903 any = A_arbace_go_run_A_const_94.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_905 lang.IFn; _ = ___14














































	if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = srcs__7; var arg_907 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var arg_908 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__4); var arg_909 any = src__4; if linked_904 == nil { ___14 = ifn_905.Invoke_O_O_O_O__O(arg_906, arg_907, arg_908, arg_909) } else { ___14 = linked_904.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_903, arg_906, arg_907, arg_908, arg_909) }
//line :90:1
	var map__1938000111__15 any = lang.IFn_Cast(define__11).Invoke_O_O__O(src__4, r__13); var map__1938000111__16 any













































	if lang.ISeq_InstanceOf(map__1938000111__15) { var tmp13 any; var root_910 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = map__1938000111__15; if linked_911 == nil { tmp13 = ifn_912.Invoke_O__O(arg_913) } else { tmp13 = linked_911.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_910, arg_913) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_914 any = A_arbace_go_run_A_const_108.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = map__1938000111__15; if linked_915 == nil { tmp14 = ifn_916.Invoke_O__O(arg_917) } else { tmp14 = linked_915.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_914, arg_917) }; map__1938000111__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp14)).Ref() } else { var tmp15 any; var root_918 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = map__1938000111__15; if linked_919 == nil { tmp15 = ifn_920.Invoke_O__O(arg_921) } else { tmp15 = linked_919.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_918, arg_921) }; if jrt.J2g_Truth(tmp15) { var root_922 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = map__1938000111__15; if linked_923 == nil { map__1938000111__16 = ifn_924.Invoke_O__O(arg_925) } else { map__1938000111__16 = linked_923.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_922, arg_925) } } else { map__1938000111__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1938000111__16 = map__1938000111__15 }
//line :90:1
	var main__17 any = lang.RT_Get_O_O__O_NoInit(map__1938000111__16, A_arbace_go_run_A_const_109)
















































	if jrt.J2g_Truth(main__17) { } else {
		var root_1090 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, A_arbace_go_run_fail_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = A_arbace_go_run_A_const_64; var arg_1094 any = Lit_4; var arg_1095 any = Lit_83; if linked_1091 == nil { ifn_1092.Invoke_O_O_O__O(arg_1093, arg_1094, arg_1095) } else { linked_1091.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1090, arg_1093, arg_1094, arg_1095) } }
	var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_110.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_111.GetRawRoot__O()); var tmp18 any; var root_937 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = inits__8; if linked_938 == nil { tmp18 = ifn_939.Invoke_O__O(arg_940) } else { tmp18 = linked_938.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_937, arg_940) }; return tmp16.Invoke_O_O_O__O(Lit_84, lang.RT_Object_array_O__O1_NoInit(tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(init_order__12).Invoke__O())).Ref(), main__17) }
//line :100:1
func A_arbace_go_run_run_fn__1938000087_A_New_O(p0 any) *A_arbace_go_run_run_fn__1938000087_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_fn__1938000087_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Ctor_O(c__pf any) { t.F_pf = c__pf }
//line :100:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Invoke_O__O(self any) any { var root_722 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, A_arbace_go_run_dir_test_index_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any; var t_ any = t.F_pf; t.F_pf = nil; arg_725 = t_; if linked_723 == nil { return ifn_724.Invoke_O__O(arg_725) } else { return linked_723.(*A_arbace_go_run_dir_test_index_A).Invoke_O_O__O(root_722, arg_725) } }



func A_arbace_go_run_run_extra__1938000089_A_New_O(p0 any) *A_arbace_go_run_run_extra__1938000089_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_extra__1938000089_A{}; t.Ctor_O(p0); return t }
//line :104:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :104:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_740 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = t.F_srcs; if linked_741 == nil { tmp1 = ifn_742.Invoke_O__O(arg_743) } else { tmp1 = linked_741.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_740, arg_743) }; return lang.RT_Get_O_O__O_NoInit(tmp1, path__1) }
func A_arbace_go_run_run_define__1938000091_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :105:1
func (t *A_arbace_go_run_run_define__1938000091_A) Ctor_O_O_O(c__srcs, c__inits, c__deps any) { t.F_srcs = c__srcs; t.F_inits = c__inits; t.F_deps = c__deps }
//line :105:1
func (t *A_arbace_go_run_run_define__1938000091_A) Invoke_O_O_O__O(self, src__1, r__2 any) any { var st__3 any; var root_746 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_748 lang.IFn; if
												linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var tmp1 any = A_arbace_go_run_A_const_50; var tmp2 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var tmp3 any = A_arbace_go_run_A_const_81; var tmp4 any = A_arbace_go_run_A_const_81.Invoke_O__O(src__1); var tmp5 any = A_arbace_go_run_A_const_82; var tmp6 any; var root_750 any = A_arbace_go_run_A_const_83.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_81.Invoke_O__O(src__1))).Ref(); if linked_751 == nil { tmp6 = ifn_752.Invoke_O__O(arg_753) } else { tmp6 = linked_751.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_750, arg_753) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_run_A_const_84; var tmp9 any = A_arbace_go_run_A_const_84.Invoke_O__O(src__1); var tmp10 any = A_arbace_go_run_A_const_85; var tmp11 any = A_arbace_go_run_A_const_85.Invoke_O__O(src__1); var tmp12 any = A_arbace_go_run_A_const_86; arg_749 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, A_arbace_go_run_A_const_86.Invoke_O__O(src__1), A_arbace_go_run_A_const_51, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_run_A_const_87, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_88, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_89, lang.PersistentArrayMap_EMPTY.Ref())); if linked_747 == nil { st__3 = ifn_748.Invoke_O__O(arg_749) } else { st__3 = linked_747.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_746, arg_749) }; var root_776 any =

	A_arbace_go_run_A_const_94.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var arg_780 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var arg_781 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_782 any = st__3; if linked_777 == nil { ifn_778.Invoke_O_O_O_O__O(arg_779, arg_780, arg_781, arg_782) } else { linked_777.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_776, arg_779, arg_780, arg_781, arg_782) }; var d__4 any; var tmp13 /*line :105:1*/*lang.Compiler_AOTFn; var fnbody__775 any = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O_O_O(src__1, r__2, st__3); var tmp14 *jrt.Class; var fncls__774 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class; if



	fncls__774 == nil { var fncls__774d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__775); A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class = fncls__774d; tmp14 = fncls__774d } else { tmp14 = fncls__774 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__775, tmp14, nil); d__4 = Up_Compiler_AOTFn_IFn(tmp13).Invoke__O(); var tmp15 /*line :115:1*/*lang.Volatile = lang.Volatile_Cast(t.F_inits); var tmp16 any; var root_783 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = jrt.NN(lang.Volatile_Cast(t.F_inits)).Deref__O(); var arg_787 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_788 any; var root_789 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = A_arbace_go_run_A_const_97.Invoke_O__O(d__4); var arg_793 any = A_arbace_go_run_A_const_98.Invoke_O__O(d__4); if linked_790 == nil { arg_788 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { arg_788 = linked_790.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }; if linked_784 == nil { tmp16 = ifn_785.Invoke_O_O_O__O(arg_786, arg_787, arg_788) } else { tmp16 = linked_784.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_783, arg_786, arg_787, arg_788) }; jrt.NN(tmp15).Reset_O__O(tmp16); var tmp17 /*line :116:1*/*lang.Volatile = lang.Volatile_Cast(t.F_deps); var tmp18 any; var root_794 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any = jrt.NN(lang.Volatile_Cast(t.F_deps)).Deref__O(); var arg_798 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_799 any; var root_800 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any; var root_804 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any; var fnbody__819 any = A_arbace_go_run_run_define__1938000091_fn__1938000094_A_New_O(t.F_srcs); var tmp19 *jrt.Class; var fncls__818 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class; if fncls__818 == nil { var fncls__818d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__819); A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class = fncls__818d; tmp19 = fncls__818d } else { tmp19 = fncls__818 }; arg_807 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__819, tmp19, nil); var arg_808 any; var root_820 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, A_arbace_go_run_imports_of_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = src__1; if linked_821 == nil { arg_808 = ifn_822.Invoke_O__O(arg_823) } else { arg_808 = linked_821.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_820, arg_823) }; if linked_805 == nil { arg_803 = ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { arg_803 = linked_805.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_804, arg_807, arg_808) }; if linked_801 == nil { arg_799 = ifn_802.Invoke_O__O(arg_803) } else { arg_799 = linked_801.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_800, arg_803) }; if linked_795 == nil { tmp18 = ifn_796.Invoke_O_O_O__O(arg_797, arg_798, arg_799) } else { tmp18 = linked_795.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_794, arg_797, arg_798, arg_799) }; jrt.NN(tmp17).Reset_O__O(tmp18); return d__4 }
//line :109:1
func A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_fn__1938000092_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Ctor_O_O_O(c__src, c__r, c__st any) { t.F_src = c__src; t.F_r = c__r; t.F_st = c__st }
//line :109:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_754 any = A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any; var t_ any = t.F_st; t.F_st = nil; arg_757 = t_; var arg_758 any; var t__2 any = t.F_r; t.F_r = nil; arg_758 = t__2; var arg_759 any = A_arbace_go_run_A_const_91; if linked_755 == nil { tmp1 = ifn_756.Invoke_O_O_O__O(arg_757, arg_758, arg_759) } else { tmp1 = linked_755.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_754, arg_757, arg_758, arg_759) } }; return nil }(); if tmp2 != nil { if lang.ExceptionInfo_InstanceOf(tmp2) { var ex__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp2); var temp__1927000408__auto____4 any; var root_760 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_762 lang.IFn


	if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_92; var tmp4 any; var root_764 any = A_arbace_go_run_A_const_93.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = ex__3; if linked_765 == nil { tmp4 = ifn_766.Invoke_O__O(arg_767) } else { tmp4 = linked_765.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_764, arg_767) }; arg_763 = tmp3.Invoke_O__O(tmp4); if linked_761 == nil { temp__1927000408__auto____4 = ifn_762.Invoke_O__O(arg_763) } else { temp__1927000408__auto____4 = linked_761.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_760, arg_763) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var er__5 any = temp__1927000408__auto____4; var root_768 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, A_arbace_go_run_fail_A_fn_class); var ifn_770 lang.IFn
		if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = A_arbace_go_run_A_const_64; var arg_772 any = Lit_4; var arg_773 any; var tmp5 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_50; var tmp7 any; var t__3 any = t.F_src; t.F_src = nil; tmp7 = t__3; arg_773 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O__O(tmp7), nil, A_arbace_go_run_A_const_65.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_66.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_63.Invoke_O__O(er__5))).Ref(); if linked_769 == nil { tmp1 = ifn_770.Invoke_O_O_O__O(arg_771, arg_772, arg_773) } else { tmp1 = linked_769.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_768, arg_771, arg_772, arg_773) } } else {
//line :112:1
			panic(jrt.Thrown(ex__3)) } } else {
//line :109:1
				panic(tmp2) } }; return tmp1 }






func A_arbace_go_run_run_define__1938000091_fn__1938000094_A_New_O(p0 any) *A_arbace_go_run_run_define__1938000091_fn__1938000094_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000094_A{}; t.Ctor_O(p0); return t }
//line :116:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000094_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :116:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000094_A) Invoke_O_O__O(self, p1__1938000085_SHARP___1 any) any { var root_809 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_814 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = t.F_srcs; if linked_815 == nil { arg_812 = ifn_816.Invoke_O__O(arg_817) } else { arg_812 = linked_815.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_814, arg_817) }; var arg_813 any = p1__1938000085_SHARP___1; if linked_810 == nil { return ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { return linked_810.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_809, arg_812, arg_813) } }


func A_arbace_go_run_run_init_order__1938000097_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000097_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :119:1
func (t *A_arbace_go_run_run_init_order__1938000097_A) Ctor_O_O(c__inits, c__deps any) { t.F_inits = c__inits; t.F_deps = c__deps }
//line :119:1
func (t *A_arbace_go_run_run_init_order__1938000097_A) Invoke_O__O(self any) any { { var done__1 any = lang.PersistentVector_EMPTY.Ref(); var left__2 any; var root_826 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_828 lang.IFn
											if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any; var root_830 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any; var root_834 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = t.F_inits; if linked_835 == nil { arg_833 = ifn_836.Invoke_O__O(arg_837) } else { arg_833 = linked_835.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_834, arg_837) }; if linked_831 == nil { arg_829 = ifn_832.Invoke_O__O(arg_833) } else { arg_829 = linked_831.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_830, arg_833) }; if linked_827 == nil { left__2 = ifn_828.Invoke_O__O(arg_829) } else { left__2 = linked_827.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_826, arg_829) }
//line :119:1
L1: for {

	var tmp1 any; var root_838 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = left__2; if linked_839 == nil { tmp1 = ifn_840.Invoke_O__O(arg_841) } else { tmp1 = linked_839.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_838, arg_841) }; if jrt.J2g_Truth(tmp1) { return done__1 } else { var p__3 any; var root_842 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_844 lang.IFn

		if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var root_846 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var fnbody__869 any = A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_New_O_O(done__1, t.F_deps); var tmp2 *jrt.Class; var fncls__868 *jrt.Class = A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class; if fncls__868 == nil { var fncls__868d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__869); A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class = fncls__868d; tmp2 = fncls__868d } else { tmp2 = fncls__868 }; arg_853 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__869, tmp2, nil); var arg_854 any = left__2; if linked_851 == nil { arg_849 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; if linked_847 == nil { arg_845 = ifn_848.Invoke_O__O(arg_849) } else { arg_845 = linked_847.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_846, arg_849) }; if linked_843 == nil { p__3 = ifn_844.Invoke_O__O(arg_845) } else { p__3 = linked_843.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_842, arg_845) }
		var tmp3 any; var root_870 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = done__1; var arg_874 any; var or__1927000174__auto____4 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_874 = or__1927000174__auto____4 } else { var root_875 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any; var root_879 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = left__2; if linked_880 == nil { arg_878 = ifn_881.Invoke_O__O(arg_882) } else { arg_878 = linked_880.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_879, arg_882) }; if linked_876 == nil { arg_874 = ifn_877.Invoke_O__O(arg_878) } else { arg_874 = linked_876.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_875, arg_878) } }; if linked_871 == nil { tmp3 = ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { tmp3 = linked_871.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) }; var tmp4 any = tmp3; var tmp5 any; var root_883 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = left__2; var arg_887 any; var or__1927000174__auto____4_2 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4_2) { arg_887 = or__1927000174__auto____4_2 } else { var root_888 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var root_892 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = left__2; if linked_893 == nil { arg_891 = ifn_894.Invoke_O__O(arg_895) } else { arg_891 = linked_893.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_892, arg_895) }; if linked_889 == nil { arg_887 = ifn_890.Invoke_O__O(arg_891) } else { arg_887 = linked_889.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_888, arg_891) } }; if linked_884 == nil { tmp5 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { tmp5 = linked_884.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }; done__1, left__2 = tmp4, tmp5; continue L1 } } }; /*line :119:1*/panic("j2g: unreachable") }



func A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A{}; t.Ctor_O_O(p0, p1); return t }
//line :123:1
func (t *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A) Ctor_O_O(c__done, c__deps any) { t.F_done = c__done; t.F_deps = c__deps }
//line :123:1
func (t *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A) Invoke_O_O__O(self, p1__1938000086_SHARP___1 any) any { var root_855 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any; var root_860 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = t.F_done; if linked_861 == nil { arg_858 = ifn_862.Invoke_O__O(arg_863) } else { arg_858 = linked_861.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_860, arg_863) }; var arg_859 any; var tmp1 any; var root_864 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = t.F_deps; if linked_865 == nil { tmp1 = ifn_866.Invoke_O__O(arg_867) } else { tmp1 = linked_865.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_864, arg_867) }; arg_859 = lang.RT_Get_O_O__O_NoInit(tmp1, p1__1938000086_SHARP___1); if linked_856 == nil { return ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { return linked_856.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_855, arg_858, arg_859) } }


func A_arbace_go_run_run_load_BANG___1938000101_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_run_run_load_BANG___1938000101_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_load_BANG___1938000101_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :126:1
func (t *A_arbace_go_run_run_load_BANG___1938000101_A) Ctor_O_O_O_O_O(c__root, c__extra, c__srcs, c__index, c__define any) { t.F_root = c__root; t.F_extra = c__extra; t.F_srcs = c__srcs; t.F_index = c__index; t.F_define = c__define }
//line :126:1
func (t *A_arbace_go_run_run_load_BANG___1938000101_A) Invoke_O_O_O__O(self, path__1, seen__2 any) any {
	var tmp1 any; var or__1927000174__auto____3 any; var root_960 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any; var root_965 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = t.F_srcs; if linked_966 == nil { arg_963 = ifn_967.Invoke_O__O(arg_968) } else { arg_963 = linked_966.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_965, arg_968) }; var arg_964 any = path__1; if linked_961 == nil { or__1927000174__auto____3 = ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { or__1927000174__auto____3 = linked_961.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_960, arg_963, arg_964) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_969 any = A_arbace_go_run_A_const_114.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = path__1; if linked_970 == nil { or__1927000174__auto____4 = ifn_971.Invoke_O__O(arg_972) } else { or__1927000174__auto____4 = linked_970.(*aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_969, arg_972) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_973 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = seen__2; var arg_977 any = path__1; if linked_974 == nil { tmp1 = ifn_975.Invoke_O_O__O(arg_976, arg_977) } else { tmp1 = linked_974.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_973, arg_976, arg_977) } } }; if jrt.J2g_Truth(tmp1) { return nil } else { var temp__1927000414__auto____3 any; var tmp2 any; var root_978 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_980 lang.IFn
		if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = t.F_index; if linked_979 == nil { tmp2 = ifn_980.Invoke_O__O(arg_981) } else { tmp2 = linked_979.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_978, arg_981) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, path__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var f__4 any = temp__1927000414__auto____3; var s__5 any; var root_982 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_984 lang.IFn
			if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, t.F_root)); var arg_986 any = path__1; var arg_987 any; var root_989 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_990 == nil { arg_987 = ifn_991.Invoke_O__O(arg_992) } else { arg_987 = linked_990.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_989, arg_992) }; var arg_988 any = f__4; if linked_983 == nil { s__5 = ifn_984.Invoke_O_O_O_O__O(arg_985, arg_986, arg_987, arg_988) } else { s__5 = linked_983.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_982, arg_985, arg_986, arg_987, arg_988) }
//line :128:1
			var seq_1938000102__6 any; var root_1007 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1009 lang.IFn

			if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any; var root_1011 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, A_arbace_go_run_imports_of_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = s__5; if linked_1012 == nil { arg_1010 = ifn_1013.Invoke_O__O(arg_1014) } else { arg_1010 = linked_1012.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1011, arg_1014) }; if linked_1008 == nil { seq_1938000102__6 = ifn_1009.Invoke_O__O(arg_1010) } else { seq_1938000102__6 = linked_1008.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1007, arg_1010) }
//line :128:1
			var chunk_1938000103__7 any; var count_1938000104__8 int64 = 0; var i_1938000105__9 int64 = 0; L1: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000105__9, count_1938000104__8) { var p__10 any = lang.Indexed_Cast(chunk_1938000103__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000105__9)); var tmp3 lang.IFn = lang.IFn_Cast(self); var tmp4 any; var root_1031 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = seen__2; var arg_1035 any = path__1; if linked_1032 == nil { tmp4 = ifn_1033.Invoke_O_O__O(arg_1034, arg_1035) } else { tmp4 = linked_1032.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1031, arg_1034, arg_1035) }; tmp3.Invoke_O_O__O(p__10, tmp4); seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000105__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_1015 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = seq_1938000102__6; if linked_1016 == nil { temp__1927000414__auto____10 = ifn_1017.Invoke_O__O(arg_1018) } else { temp__1927000414__auto____10 = linked_1016.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1015, arg_1018) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1938000102__11 any = temp__1927000414__auto____10; var tmp5 any; var root_1019 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = seq_1938000102__11; if linked_1020 == nil { tmp5 = ifn_1021.Invoke_O__O(arg_1022) } else { tmp5 = linked_1020.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1019, arg_1022) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_1023 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = seq_1938000102__11; if linked_1024 == nil { c__1927000678__auto____12 = ifn_1025.Invoke_O__O(arg_1026) } else { c__1927000678__auto____12 = linked_1024.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1023, arg_1026) }; var tmp6 any; var root_1036 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = seq_1938000102__11; if linked_1037 == nil { tmp6 = ifn_1038.Invoke_O__O(arg_1039) } else { tmp6 = linked_1037.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1036, arg_1039) }; seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__12 any; var root_1027 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = seq_1938000102__11; if linked_1028 == nil { p__12 = ifn_1029.Invoke_O__O(arg_1030) } else { p__12 = linked_1028.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1027, arg_1030) }; var tmp7 lang.IFn = lang.IFn_Cast(self); var tmp8 any; var root_1040 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = seen__2; var arg_1044 any = path__1; if linked_1041 == nil { tmp8 = ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { tmp8 = linked_1041.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) }; tmp7.Invoke_O_O__O(p__12, tmp8); var tmp9 any; var root_1045 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = seq_1938000102__11; if linked_1046 == nil { tmp9 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp9 = linked_1046.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1045, arg_1048) }; seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = tmp9, nil, 0, 0; continue L1 } } }
//line :128:1
				break L1
			}

			var tmp10 any; var root_993 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any; var root_998 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = t.F_srcs; if linked_999 == nil { arg_996 = ifn_1000.Invoke_O__O(arg_1001) } else { arg_996 = linked_999.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_998, arg_1001) }; var arg_997 any = path__1; if linked_994 == nil { tmp10 = ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { tmp10 = linked_994.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_993, arg_996, arg_997) }; if jrt.J2g_Truth(tmp10) { return nil } else { var r__6 any; var root_1002 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, A_arbace_go_run_check_BANG__A_fn_class); var ifn_1004 lang.IFn
				if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = s__5; var arg_1006 any = t.F_extra; if linked_1003 == nil { r__6 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { r__6 = linked_1003.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }
				var root_1049 any = A_arbace_go_run_A_const_94.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = t.F_srcs; var arg_1053 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var arg_1054 any = path__1; var arg_1055 any = s__5; if linked_1050 == nil { ifn_1051.Invoke_O_O_O_O__O(arg_1052, arg_1053, arg_1054, arg_1055) } else { linked_1050.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1049, arg_1052, arg_1053, arg_1054, arg_1055) }
				return lang.IFn_Cast(t.F_define).Invoke_O_O__O(s__5, r__6) } } else {
//line :128:1
					return nil
				}
	}
}











func A_arbace_go_run_raw_lines_A_New() *A_arbace_go_run_raw_lines_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_go_run_raw_lines_A) Ctor() {}
//line :143:1
func (t *A_arbace_go_run_raw_lines_A) Invoke_O_O__O(self, x__0 any) any { var walk_meta__2 any; var fnbody__1108 any = A_arbace_go_run_raw_lines_walk_meta__1938000116_A_New(); var tmp1 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class; if






	fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class = fncls__1107d; tmp1 = fncls__1107d } else { tmp1 = fncls__1107 }; walk_meta__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1108, tmp1, nil); var x_SINGLEQUOTE___3 any; var tmp2 any; var root_1109 any = /*line :143:1*/A_arbace_go_run_A_const_118.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1111 lang.IFn; if








	linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = x__0; if linked_1110 == nil { tmp2 = ifn_1111.Invoke_O__O(arg_1112) } else { tmp2 = linked_1110.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1109, arg_1112) }; if /*line :151:1*/ jrt.J2g_Truth(tmp2) {
		var root_1113 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var root_1118 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var arg_1122 any; var root_1123 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var arg_1127 any = x__0; if linked_1124 == nil { arg_1122 = ifn_1125.Invoke_O_O__O(arg_1126, arg_1127) } else { arg_1122 = linked_1124.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1123, arg_1126, arg_1127) }; if linked_1119 == nil { arg_1116 = ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { arg_1116 = linked_1119.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122) }; var arg_1117 any; var G__1938000119__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000119__3_, nil) { arg_1117 = nil } else { arg_1117 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000119__3_) }; if linked_1114 == nil { x_SINGLEQUOTE___3 = ifn_1115.Invoke_O_O__O(arg_1116, arg_1117) } else { x_SINGLEQUOTE___3 = linked_1114.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1113, arg_1116, arg_1117) } } else {
//line :151:1
			var tmp3 any; var root_1128 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1130 lang.IFn

			if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = x__0; if linked_1129 == nil { tmp3 = ifn_1130.Invoke_O__O(arg_1131) } else { tmp3 = linked_1129.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1128, arg_1131) }
//line :151:1
			if jrt.J2g_Truth(tmp3) {

				var root_1132 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any; var root_1137 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var arg_1141 any = x__0; if linked_1138 == nil { arg_1135 = ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { arg_1135 = linked_1138.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) }; var arg_1136 any; var G__1938000120__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000120__3_, nil) { arg_1136 = nil } else { arg_1136 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000120__3_) }; if linked_1133 == nil { x_SINGLEQUOTE___3 = ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { x_SINGLEQUOTE___3 = linked_1133.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) } } else {
//line :151:1
					var tmp4 any; var root_1142 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1144 lang.IFn


					if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = x__0; if linked_1143 == nil { tmp4 = ifn_1144.Invoke_O__O(arg_1145) } else { tmp4 = linked_1143.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1142, arg_1145) }
//line :151:1
					if jrt.J2g_Truth(tmp4) {


						var root_1146 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var root_1151 any = A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1155 any; var root_1157 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any; var fnbody__1170 any = A_arbace_go_run_raw_lines_fn__1938000122_A_New(); var tmp5 *jrt.Class; var fncls__1169 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class; if fncls__1169 == nil { var fncls__1169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class = fncls__1169d; tmp5 = fncls__1169d } else { tmp5 = fncls__1169 }; arg_1160 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1170, tmp5, nil); if linked_1158 == nil { arg_1155 = ifn_1159.Invoke_O__O(arg_1160) } else { arg_1155 = linked_1158.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1157, arg_1160) }; var arg_1156 any = x__0; if linked_1152 == nil { arg_1149 = ifn_1153.Invoke_O_O_O__O(arg_1154, arg_1155, arg_1156) } else { arg_1149 = linked_1152.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1151, arg_1154, arg_1155, arg_1156) }; var arg_1150 any; var G__1938000127__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000127__3_, nil) { arg_1150 = nil } else { arg_1150 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000127__3_) }; if linked_1147 == nil { x_SINGLEQUOTE___3 = ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { x_SINGLEQUOTE___3 = linked_1147.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) } } else {
//line :151:1
							var tmp6 any; var root_1171 any = A_arbace_go_run_A_const_125.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1173 lang.IFn



							if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = x__0; if linked_1172 == nil { tmp6 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp6 = linked_1172.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1171, arg_1174) }
//line :151:1
							if jrt.J2g_Truth(tmp6) {



								var root_1175 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = x__0; var arg_1179 any; var G__1938000128__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000128__3_, nil) { arg_1179 = nil } else { arg_1179 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000128__3_) }; if linked_1176 == nil { x_SINGLEQUOTE___3 = ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { x_SINGLEQUOTE___3 = linked_1176.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) } } else {
//line :151:1
									if A_arbace_go_run_A_const_29 != nil { x_SINGLEQUOTE___3 = x__0 } else { x_SINGLEQUOTE___3 = nil } } } } }; var m__4 any; if





	lang.IObj_InstanceOf(x_SINGLEQUOTE___3) { m__4 = lang.RT_Meta_O__IPersistentMap_NoInit(x_SINGLEQUOTE___3) } else { m__4 = nil }; var pos__5 any = /*line :143:1*/A_arbace_go_run_A_const_126.Invoke_O__O(m__4); var lines__6 any; var fnbody__1196 any = A_arbace_go_run_raw_lines_lines__1938000129_A_New(); var tmp7 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class; if


















	fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class = fncls__1195d; tmp7 = fncls__1195d } else { tmp7 = fncls__1195 }; lines__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1196, tmp7, nil); var l__7 any; var or__1927000174__auto____7 any; var tmp8 any; var root_1197 any = /*line :143:1*/A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1199 lang.IFn; if



















	linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = x_SINGLEQUOTE___3; if linked_1198 == nil { tmp8 = ifn_1199.Invoke_O__O(arg_1200) } else { tmp8 = linked_1198.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1197, arg_1200) }; if jrt.J2g_Truth(tmp8) { var G__1938000133__7_ any; var root_1201 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1203 lang.IFn
		if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any; var tmp9 lang.IFn = lang.IFn_Cast(lines__6); var tmp10 any; var root_1206 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = A_arbace_go_run_A_const_129.Invoke_O__O(m__4); if linked_1207 == nil { tmp10 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp10 = linked_1207.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1206, arg_1209) }; arg_1204 = tmp9.Invoke_O__O(tmp10); var arg_1205 any; var root_1210 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1212 lang.IFn
		if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var fnbody__1216 any = A_arbace_go_run_raw_lines_fn__1938000134_A_New(); var tmp11 *jrt.Class; var fncls__1215 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class; if fncls__1215 == nil { var fncls__1215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class = fncls__1215d; tmp11 = fncls__1215d } else { tmp11 = fncls__1215 }; arg_1213 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1216, tmp11, nil); var arg_1214 any = x_SINGLEQUOTE___3; if linked_1211 == nil { arg_1205 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { arg_1205 = linked_1211.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }
//line :164:1
		if linked_1202 == nil { G__1938000133__7_ = ifn_1203.Invoke_O_O__O(arg_1204, arg_1205) } else { G__1938000133__7_ = linked_1202.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1201, arg_1204, arg_1205) }
//line :163:1
		var G__1938000133__8_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__1938000133__7_, nil) { G__1938000133__8_ = nil } else { var root_1217 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = G__1938000133__7_; if linked_1218 == nil { G__1938000133__8_ = ifn_1219.Invoke_O__O(arg_1220) } else { G__1938000133__8_ = linked_1218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1217, arg_1220) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000133__8_, nil) { or__1927000174__auto____7 = nil } else {

			var root_1221 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = A_arbace_go_run_A_const_130.GetRawRoot__O(); var arg_1225 any = G__1938000133__8_; if linked_1222 == nil { or__1927000174__auto____7 = ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { or__1927000174__auto____7 = linked_1222.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) } } } else {
//line :163:1
				or__1927000174__auto____7 = nil }; if jrt.J2g_Truth(or__1927000174__auto____7) { l__7 = or__1927000174__auto____7 } else {



					var tmp12 any; var root_1226 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = pos__5; if linked_1227 == nil { tmp12 = ifn_1228.Invoke_O__O(arg_1229) } else { tmp12 = linked_1227.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1226, arg_1229) }; if jrt.J2g_Truth(tmp12) { var G__1938000136__8_ any; var root_1230 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = A_arbace_go_run_A_const_131.GetRawRoot__O(); var arg_1234 any = pos__5; var arg_1235 any = A_arbace_go_run_A_const_132; if linked_1231 == nil { G__1938000136__8_ = ifn_1232.Invoke_O_O_O__O(arg_1233, arg_1234, arg_1235) } else { G__1938000136__8_ = linked_1231.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1230, arg_1233, arg_1234, arg_1235) }; var G__1938000136__9_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__8_, nil) { G__1938000136__9_ = nil } else { var root_1236 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = G__1938000136__8_; if linked_1237 == nil { G__1938000136__9_ = ifn_1238.Invoke_O__O(arg_1239) } else { G__1938000136__9_ = linked_1237.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1236, arg_1239) } }; var G__1938000136__10_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__9_, nil) { G__1938000136__10_ = nil } else { G__1938000136__10_ = lang.IFn_Cast(lines__6).Invoke_O__O(G__1938000136__9_) }; var G__1938000136__11_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__10_, nil) { G__1938000136__11_ = nil } else { var root_1240 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = G__1938000136__10_; if linked_1241 == nil { G__1938000136__11_ = ifn_1242.Invoke_O__O(arg_1243) } else { G__1938000136__11_ = linked_1241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1240, arg_1243) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__11_, nil) { l__7 = nil } else { var root_1244 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = A_arbace_go_run_A_const_130.GetRawRoot__O(); var arg_1248 any = G__1938000136__11_; if linked_1245 == nil { l__7 = ifn_1246.Invoke_O_O__O(arg_1247, arg_1248) } else { l__7 = linked_1245.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1244, arg_1247, arg_1248) } } } else { l__7 = nil } }; var end__8 any; var tmp13 any; var root_1249 any = /*line :143:1*/A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1251 lang.IFn; if


























	linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = pos__5; if linked_1250 == nil { tmp13 = ifn_1251.Invoke_O__O(arg_1252) } else { tmp13 = linked_1250.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1249, arg_1252) }; if jrt.J2g_Truth(tmp13) { var root_1253 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = A_arbace_go_run_A_const_133.Invoke_O__O(pos__5); if linked_1254 == nil { end__8 = ifn_1255.Invoke_O__O(arg_1256) } else { end__8 = linked_1254.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1253, arg_1256) } } else { end__8 = nil }; var apos__9 any = /*line :143:1*/A_arbace_go_run_A_const_129.Invoke_O__O(m__4); var tmp14 any; var or__1927000174__auto____10 any = l__7; if




























	jrt.J2g_Truth(or__1927000174__auto____10) { tmp14 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 any = end__8; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp14 = or__1927000174__auto____11 } else { var root_1257 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = apos__9; if linked_1258 == nil { tmp14 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp14 = linked_1258.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1257, arg_1260) } } }; if jrt.J2g_Truth(tmp14) {
		var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_134.GetRawRoot__O()); var tmp16 *lang.Compiler_AOTFn; var fnbody__1379 any = A_arbace_go_run_raw_lines_fn__1938000137_A_New_O_O_O(l__7, apos__9, end__8); var tmp17 *jrt.Class; var fncls__1378 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class; if fncls__1378 == nil { var fncls__1378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__1379); A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class = fncls__1378d; tmp17 = fncls__1378d } else { tmp17 = fncls__1378 }; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1379, tmp17, nil); return tmp15.Invoke_O_O__O(x_SINGLEQUOTE___3, tmp16.Ref()) } else {
//line :172:1
			return x_SINGLEQUOTE___3 } }
//line :150:1
func A_arbace_go_run_raw_lines_walk_meta__1938000116_A_New() *A_arbace_go_run_raw_lines_walk_meta__1938000116_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_walk_meta__1938000116_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000116_A) Ctor() {}
//line :150:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000116_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000117__2_ any = m__1; var tmp1 any; var root_1096 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = m__1; var arg_1100 any = A_arbace_go_run_A_const_115; if linked_1097 == nil { tmp1 = ifn_1098.Invoke_O_O__O(arg_1099, arg_1100) } else { tmp1 = linked_1097.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1096, arg_1099, arg_1100) }; if jrt.J2g_Truth(tmp1) { var root_1101 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = G__1938000117__2_; var arg_1105 any = A_arbace_go_run_A_const_115; var arg_1106 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); if linked_1102 == nil { return ifn_1103.Invoke_O_O_O__O(arg_1104, arg_1105, arg_1106) } else { return linked_1102.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1101, arg_1104, arg_1105, arg_1106) } } else { return G__1938000117__2_ } }



func A_arbace_go_run_raw_lines_fn__1938000122_A_New() *A_arbace_go_run_raw_lines_fn__1938000122_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000122_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_run_raw_lines_fn__1938000122_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_run_raw_lines_fn__1938000122_A) Invoke_O_O__O(self, p__1938000121__1 any) any { var vec__1938000123__2 any = p__1938000121__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000123__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000123__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1161 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = k__3; if linked_1162 == nil { tmp1 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp1 = linked_1162.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1161, arg_1164) }; var tmp2 any = tmp1; var tmp3 any; var root_1165 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = v__4; if linked_1166 == nil { tmp3 = ifn_1167.Invoke_O__O(arg_1168) } else { tmp3 = linked_1166.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1165, arg_1168) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }







func A_arbace_go_run_raw_lines_lines__1938000129_A_New() *A_arbace_go_run_raw_lines_lines__1938000129_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000129_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_A) Ctor() {}
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_A) Invoke_O_O__O(self, ps__1 any) any { var root_1180 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any; var fnbody__1194 any = A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_New(); var tmp1 *jrt.Class; var fncls__1193 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class; if fncls__1193 == nil { var fncls__1193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class = fncls__1193d; tmp1 = fncls__1193d } else { tmp1 = fncls__1193 }; arg_1183 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1194, tmp1, nil); var arg_1184 any = ps__1; if linked_1181 == nil { return ifn_1182.Invoke_O_O__O(arg_1183, arg_1184) } else { return linked_1181.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1180, arg_1183, arg_1184) } }
//line :162:1
func A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_New() *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A) Ctor() {}
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A) Invoke_O_O__O(self, p1__1938000114_SHARP___1 any) any { var tmp1 any; var root_1185 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = p1__1938000114_SHARP___1; if linked_1186 == nil { tmp1 = ifn_1187.Invoke_O__O(arg_1188) } else { tmp1 = linked_1186.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1185, arg_1188) }; if jrt.J2g_Truth(tmp1) { var root_1189 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = p1__1938000114_SHARP___1; if linked_1190 == nil { return ifn_1191.Invoke_O__O(arg_1192) } else { return linked_1190.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1189, arg_1192) } } else { return nil } }


func A_arbace_go_run_raw_lines_fn__1938000134_A_New() *A_arbace_go_run_raw_lines_fn__1938000134_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000134_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_run_raw_lines_fn__1938000134_A) Ctor() {}
//line :165:1
func (t *A_arbace_go_run_raw_lines_fn__1938000134_A) Invoke_O_O__O(self, p1__1938000115_SHARP___1 any) any { if lang.IMeta_InstanceOf(p1__1938000115_SHARP___1) { var tmp1 *lang.Keyword = A_arbace_go_run_A_const_66; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1938000115_SHARP___1)) } else { return nil } }







func A_arbace_go_run_raw_lines_fn__1938000137_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_raw_lines_fn__1938000137_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :173:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_A) Ctor_O_O_O(c__l, c__apos, c__end any) { t.F_l = c__l; t.F_apos = c__apos; t.F_end = c__end }
//line :173:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000138__2_ any = m__1; var G__1938000138__3_ any; if jrt.J2g_Truth(t.F_l) {
											var root_1266 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = G__1938000138__2_; var arg_1270 any = A_arbace_go_run_A_const_66; var arg_1271 any = t.F_l; if linked_1267 == nil { G__1938000138__3_ = ifn_1268.Invoke_O_O_O__O(arg_1269, arg_1270, arg_1271) } else { G__1938000138__3_ = linked_1267.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1266, arg_1269, arg_1270, arg_1271) } } else {
//line :173:1
		G__1938000138__3_ = G__1938000138__2_ }; var G__1938000138__4_ any; if jrt.J2g_Truth(t.F_end) {

			var root_1272 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = G__1938000138__3_; var arg_1276 any = A_arbace_go_run_A_const_135; var arg_1277 any = t.F_end; if linked_1273 == nil { G__1938000138__4_ = ifn_1274.Invoke_O_O_O__O(arg_1275, arg_1276, arg_1277) } else { G__1938000138__4_ = linked_1273.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1272, arg_1275, arg_1276, arg_1277) } } else {
//line :173:1
				G__1938000138__4_ = G__1938000138__3_ }; var tmp1 any; var root_1278 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1280 lang.IFn; if


	linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = t.F_apos; if linked_1279 == nil { tmp1 = ifn_1280.Invoke_O__O(arg_1281) } else { tmp1 = linked_1279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1278, arg_1281) }; if /*line :173:1*/ jrt.J2g_Truth(tmp1) {


		var root_1282 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = G__1938000138__4_; var arg_1286 any = A_arbace_go_run_A_const_136; var arg_1287 any; var root_1288 any = A_arbace_go_run_A_const_137.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any; var iter__1927001039__auto____5 any; var fnbody__1373 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_New(); var tmp2 *jrt.Class; var fncls__1372 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class; if fncls__1372 == nil { var fncls__1372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class = fncls__1372d; tmp2 = fncls__1372d } else { tmp2 = fncls__1372 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1373, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp4 any; var root_1374 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = t.F_apos; if linked_1375 == nil { tmp4 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp4 = linked_1375.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1374, arg_1377) }; arg_1291 = tmp3.Invoke_O__O(tmp4); if linked_1289 == nil { arg_1287 = ifn_1290.Invoke_O__O(arg_1291) } else { arg_1287 = linked_1289.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1288, arg_1291) }; if linked_1283 == nil { return ifn_1284.Invoke_O_O_O__O(arg_1285, arg_1286, arg_1287) } else { return linked_1283.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1282, arg_1285, arg_1286, arg_1287) } } else {
//line :173:1
			return G__1938000138__4_ } }


func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_New() *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A) Ctor() {}
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A) Invoke_O_O__O(self, s__1938000140__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1371 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_New_O_O(self, s__1938000140__1); var tmp2 *jrt.Class; var fncls__1370 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class; if fncls__1370 == nil { var fncls__1370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__1371); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class = fncls__1370d; tmp2 = fncls__1370d } else { tmp2 = fncls__1370 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1371, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :176:1
func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_New_O_O(p0, p1 any) *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A) Ctor_O_O(c__iter__1938000139, c__s__1938000140 any) { t.F_iter__1938000139 = c__iter__1938000139; t.F_s__1938000140 = c__s__1938000140 }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A) Invoke_O__O(self any) any { { var s__1938000140__1 any; var t_ any = t.F_s__1938000140; t.F_s__1938000140 = nil; s__1938000140__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1292 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = s__1938000140__1; if linked_1293 == nil { temp__1927000414__auto____2 = ifn_1294.Invoke_O__O(arg_1295) } else { temp__1927000414__auto____2 = linked_1293.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1292, arg_1295) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000140__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1296 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = s__1938000140__3; if linked_1297 == nil { tmp1 = ifn_1298.Invoke_O__O(arg_1299) } else { tmp1 = linked_1297.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1296, arg_1299) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1300 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = s__1938000140__3; if linked_1301 == nil { c__1927001037__auto____4 = ifn_1302.Invoke_O__O(arg_1303) } else { c__1927001037__auto____4 = linked_1301.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1300, arg_1303) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000142__6 any; var root_1304 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1305 == nil { b__1938000142__6 = ifn_1306.Invoke_O__O(arg_1307) } else { b__1938000142__6 = linked_1305.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1304, arg_1307) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1322 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_New_O_I_O(b__1938000142__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1321 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class; if fncls__1321 == nil { var fncls__1321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__1322); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class = fncls__1321d; tmp3 = fncls__1321d } else { tmp3 = fncls__1321 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1322, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1323 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any; var root_1328 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = b__1938000142__6; if linked_1329 == nil { arg_1326 = ifn_1330.Invoke_O__O(arg_1331) } else { arg_1326 = linked_1329.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1328, arg_1331) }; var arg_1327 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000139); var tmp5 any; var root_1332 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = s__1938000140__3; if linked_1333 == nil { tmp5 = ifn_1334.Invoke_O__O(arg_1335) } else { tmp5 = linked_1333.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1332, arg_1335) }; arg_1327 = tmp4.Invoke_O__O(tmp5); if linked_1324 == nil { return ifn_1325.Invoke_O_O__O(arg_1326, arg_1327) } else { return linked_1324.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1323, arg_1326, arg_1327) } } else { var root_1336 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any; var root_1341 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = b__1938000142__6; if linked_1342 == nil { arg_1339 = ifn_1343.Invoke_O__O(arg_1344) } else { arg_1339 = linked_1342.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1341, arg_1344) }; var arg_1340 any; if linked_1337 == nil { return ifn_1338.Invoke_O_O__O(arg_1339, arg_1340) } else { return linked_1337.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1336, arg_1339, arg_1340) } } } else { var vec__1938000150__4 any; var root_1345 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = s__1938000140__3; if linked_1346 == nil { vec__1938000150__4 = ifn_1347.Invoke_O__O(arg_1348) } else { vec__1938000150__4 = linked_1346.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1345, arg_1348) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000150__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000150__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_1349 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = p__6; if linked_1350 == nil { tmp6 = ifn_1351.Invoke_O__O(arg_1352) } else { tmp6 = linked_1350.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1349, arg_1352) }; if jrt.J2g_Truth(tmp6) { var root_1353 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var tmp7 any; var root_1358 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = p__6; if linked_1359 == nil { tmp7 = ifn_1360.Invoke_O__O(arg_1361) } else { tmp7 = linked_1359.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1358, arg_1361) }; arg_1356 = lang.Tuple_Create_O_O__IPersistentVector(i__5, tmp7); var arg_1357 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000139); var tmp9 any; var root_1362 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = s__1938000140__3; if linked_1363 == nil { tmp9 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp9 = linked_1363.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1362, arg_1365) }; arg_1357 = tmp8.Invoke_O__O(tmp9); if linked_1354 == nil { return ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { return linked_1354.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) } } else { var tmp10 any; var root_1366 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = s__1938000140__3; if linked_1367 == nil { tmp10 = ifn_1368.Invoke_O__O(arg_1369) } else { tmp10 = linked_1367.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1366, arg_1369) }; s__1938000140__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :176:1
func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A) Ctor_O_I_O(c__b__1938000142 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000142 = c__b__1938000142; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A) Invoke_O__O(self any) any { { var i__1938000141__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000141__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1938000146__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000141__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000146__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000146__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_1308 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = p__4; if linked_1309 == nil { tmp2 = ifn_1310.Invoke_O__O(arg_1311) } else { tmp2 = linked_1309.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1308, arg_1311) }; if jrt.J2g_Truth(tmp2) { var root_1312 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = t.F_b__1938000142; var arg_1316 any; var tmp3 any; var root_1317 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = p__4; if linked_1318 == nil { tmp3 = ifn_1319.Invoke_O__O(arg_1320) } else { tmp3 = linked_1318.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1317, arg_1320) }; arg_1316 = lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp3); if linked_1313 == nil { ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { linked_1313.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) }; i__1938000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000141__1); continue L1 } else { i__1938000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000141__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_run_errorcheck_A_New() *A_arbace_go_run_errorcheck_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_go_run_errorcheck_A) Ctor() {}
//line :179:1
func (t *A_arbace_go_run_errorcheck_A) Invoke_O_O_O_O_O_O_O__O(self, root__0, pf__1, lang__2, max_errors__3, raw__4, front__5 any) any { var src__7 any; var G__1938000162__7_ any; var root_1380 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_1382 lang.IFn; if















	linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, root__0)); var arg_1384 any; var arg_1385 any; var root_1387 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_1388 == nil { arg_1385 = ifn_1389.Invoke_O__O(arg_1390) } else { arg_1385 = linked_1388.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1387, arg_1390) }; var arg_1386 any = pf__1; if linked_1381 == nil { G__1938000162__7_ = ifn_1382.Invoke_O_O_O_O__O(arg_1383, arg_1384, arg_1385, arg_1386) } else { G__1938000162__7_ = linked_1381.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_1380, arg_1383, arg_1384, arg_1385, arg_1386) }; var G__1938000162__8_ any; if jrt.J2g_Truth(lang__2) {
		var root_1391 any = A_arbace_go_run_A_const_138.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = G__1938000162__7_; var arg_1395 any = A_arbace_go_run_A_const_139; var arg_1396 any = lang__2; if linked_1392 == nil { G__1938000162__8_ = ifn_1393.Invoke_O_O_O__O(arg_1394, arg_1395, arg_1396) } else { G__1938000162__8_ = linked_1392.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1391, arg_1394, arg_1395, arg_1396) } } else {
//line :195:1
			G__1938000162__8_ = G__1938000162__7_ }; if jrt.J2g_Truth(raw__4) {





				var root_1397 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any; var root_1403 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1405 lang.IFn
//line :197:1
				if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = G__1938000162__8_; var arg_1407 any = A_arbace_go_run_A_const_51; var arg_1408 any; var fnbody__1447 any = A_arbace_go_run_errorcheck_fn__1938000163_A_New(); var tmp1 *jrt.Class; var fncls__1446 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000163_A_fn_class; if fncls__1446 == nil { var fncls__1446d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_go_run_errorcheck_fn__1938000163_A_fn_class = fncls__1446d; tmp1 = fncls__1446d } else { tmp1 = fncls__1446 }; arg_1408 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1447, tmp1, nil); if linked_1404 == nil { arg_1400 = ifn_1405.Invoke_O_O_O__O(arg_1406, arg_1407, arg_1408) } else { arg_1400 = linked_1404.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1403, arg_1406, arg_1407, arg_1408)
				}


				var arg_1401 any = A_arbace_go_run_A_const_143; var arg_1402 any = jrt.HashMap_New(); if linked_1398 == nil { src__7 = ifn_1399.Invoke_O_O_O__O(arg_1400, arg_1401, arg_1402) } else { src__7 = linked_1398.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1397, arg_1400, arg_1401, arg_1402) } } else {
//line :195:1
					src__7 = G__1938000162__8_ }; var ___8 any; var tmp2 any; var root_1448 any = /*line :179:1*/A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1450 lang.IFn; _ = ___8; if






















	linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__7); if linked_1449 == nil { tmp2 = ifn_1450.Invoke_O__O(arg_1451) } else { tmp2 = linked_1449.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1448, arg_1451) }; if jrt.J2g_Truth(tmp2) { var root_1452 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, A_arbace_go_run_fail_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = A_arbace_go_run_A_const_49; var arg_1456 any = Lit_14; var arg_1457 any = Lit_26; if linked_1453 == nil { ___8 = ifn_1454.Invoke_O_O_O__O(arg_1455, arg_1456, arg_1457) } else { ___8 = linked_1453.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1452, arg_1455, arg_1456, arg_1457) } } else { ___8 = nil }; var ___9 any; var root_1458 any = /*line :179:1*/A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_1460 lang.IFn; _ = ___9; if























	linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = src__7; if linked_1459 == nil { ___9 = ifn_1460.Invoke_O__O(arg_1461) } else { ___9 = linked_1459.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_1458, arg_1461) }; var r__10 any; var root_1462 any = /*line :179:1*/A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_1464 lang.IFn; if
























	linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = src__7; var arg_1466 any; var fnbody__1469 any = A_arbace_go_run_errorcheck_fn__1938000170_A_New(); var tmp3 *jrt.Class; var fncls__1468 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000170_A_fn_class; if fncls__1468 == nil { var fncls__1468d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_go_run_errorcheck_fn__1938000170_A_fn_class = fncls__1468d; tmp3 = fncls__1468d } else { tmp3 = fncls__1468 }; arg_1466 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1469, tmp3, nil); var arg_1467 any = jrt.Boolean_FALSE.Ref(); if linked_1463 == nil { r__10 = ifn_1464.Invoke_O_O_O__O(arg_1465, arg_1466, arg_1467) } else { r__10 = linked_1463.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O_O__O(root_1462, arg_1465, arg_1466, arg_1467) }; var errs__11 any = /*line :179:1*/A_arbace_go_run_A_const_58.Invoke_O__O(r__10); var temp__1927000414__auto____12 any; var root_1704 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1706 lang.IFn; if


























	linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any; var fnbody__1710 any = A_arbace_go_run_errorcheck_fn__1938000172_A_New(); var tmp4 *jrt.Class; var fncls__1709 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000172_A_fn_class; if fncls__1709 == nil { var fncls__1709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_go_run_errorcheck_fn__1938000172_A_fn_class = fncls__1709d; tmp4 = fncls__1709d } else { tmp4 = fncls__1709 }; arg_1707 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1710, tmp4, nil); var arg_1708 any = errs__11; if linked_1705 == nil { temp__1927000414__auto____12 = ifn_1706.Invoke_O_O__O(arg_1707, arg_1708) } else { temp__1927000414__auto____12 = linked_1705.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1704, arg_1707, arg_1708) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var bi__13 any = temp__1927000414__auto____12; var root_1711 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, A_arbace_go_run_fail_A_fn_class); var ifn_1713 lang.IFn
		if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = A_arbace_go_run_A_const_49; var arg_1715 any = Lit_14; var arg_1716 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_63.Invoke_O__O(bi__13))).Ref(); if linked_1712 == nil { ifn_1713.Invoke_O_O_O__O(arg_1714, arg_1715, arg_1716) } else { linked_1712.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1711, arg_1714, arg_1715, arg_1716) } }; var temp__1927000414__auto____12_2 any; var root_1717 any = /*line :179:1*/A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1719 lang.IFn; if




























	linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any; var fnbody__1723 any = A_arbace_go_run_errorcheck_fn__1938000174_A_New(); var tmp5 *jrt.Class; var fncls__1722 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000174_A_fn_class; if fncls__1722 == nil { var fncls__1722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_go_run_errorcheck_fn__1938000174_A_fn_class = fncls__1722d; tmp5 = fncls__1722d } else { tmp5 = fncls__1722 }; arg_1720 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1723, tmp5, nil); var arg_1721 any = A_arbace_go_run_A_const_165.Invoke_O__O(r__10); if linked_1718 == nil { temp__1927000414__auto____12_2 = ifn_1719.Invoke_O_O__O(arg_1720, arg_1721) } else { temp__1927000414__auto____12_2 = linked_1718.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1717, arg_1720, arg_1721) }; if jrt.J2g_Truth(temp__1927000414__auto____12_2) { var u__13 any = temp__1927000414__auto____12_2; var root_1724 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, A_arbace_go_run_fail_A_fn_class); var ifn_1726 lang.IFn
		if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = A_arbace_go_run_A_const_49; var arg_1728 any = Lit_14; var arg_1729 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31, nil); var tmp7 *lang.Keyword = A_arbace_go_run_A_const_81; var tmp8 any; var root_1730 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = u__13; if linked_1731 == nil { tmp8 = ifn_1732.Invoke_O__O(arg_1733) } else { tmp8 = linked_1731.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1730, arg_1733) }; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 any; var root_1734 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = u__13; if linked_1735 == nil { tmp10 = ifn_1736.Invoke_O__O(arg_1737) } else { tmp10 = linked_1735.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1734, arg_1737) }; arg_1729 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, tmp10)).Ref(); if linked_1725 == nil { ifn_1726.Invoke_O_O_O__O(arg_1727, arg_1728, arg_1729) } else { linked_1725.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1724, arg_1727, arg_1728, arg_1729) } }; var errs__12 any; var G__1938000176__12_ any; var root_1470 any = /*line :179:1*/A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1472 lang.IFn; if

































	linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any; var fnbody__1476 any = A_arbace_go_run_errorcheck_fn__1938000177_A_New(); var tmp11 *jrt.Class; var fncls__1475 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000177_A_fn_class; if fncls__1475 == nil { var fncls__1475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_go_run_errorcheck_fn__1938000177_A_fn_class = fncls__1475d; tmp11 = fncls__1475d } else { tmp11 = fncls__1475 }; arg_1473 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1476, tmp11, nil); var arg_1474 any = errs__11; if linked_1471 == nil { G__1938000176__12_ = ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { G__1938000176__12_ = linked_1471.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) }; if jrt.J2g_Truth(front__5) {
		var root_1477 any = A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any; var fnbody__1483 any = A_arbace_go_run_errorcheck_fn__1938000179_A_New(); var tmp12 *jrt.Class; var fncls__1482 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000179_A_fn_class; if fncls__1482 == nil { var fncls__1482d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_run_errorcheck_fn__1938000179_A_fn_class = fncls__1482d; tmp12 = fncls__1482d } else { tmp12 = fncls__1482 }; arg_1480 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1483, tmp12, nil); var arg_1481 any = G__1938000176__12_; if linked_1478 == nil { errs__12 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { errs__12 = linked_1478.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) } } else {
//line :213:1
			errs__12 = G__1938000176__12_ }; var file_lang__13 any; var root_1484 any = /*line :179:1*/A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1486 lang.IFn; if




































	linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1488 any; var iter__1927001039__auto____13 any; var fnbody__1560 any = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_New(); var tmp13 *jrt.Class; var fncls__1559 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_fn_class; if fncls__1559 == nil { var fncls__1559d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_fn_class = fncls__1559d; tmp13 = fncls__1559d } else { tmp13 = fncls__1559 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1560, tmp13, nil); arg_1488 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(A_arbace_go_run_A_const_51.Invoke_O__O(src__7)); if linked_1485 == nil { file_lang__13 = ifn_1486.Invoke_O_O__O(arg_1487, arg_1488) } else { file_lang__13 = linked_1485.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1484, arg_1487, arg_1488) }; var vmsg__14 any; var fnbody__1572 any = /*line :179:1*/A_arbace_go_run_errorcheck_vmsg__1938000191_A_New_O_O_O(file_lang__13, lang__2, src__7); var tmp14 *jrt.Class; var fncls__1571 *jrt.Class = A_arbace_go_run_errorcheck_vmsg__1938000191_A_fn_class; if





































	fncls__1571 == nil { var fncls__1571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__1572); A_arbace_go_run_errorcheck_vmsg__1938000191_A_fn_class = fncls__1571d; tmp14 = fncls__1571d } else { tmp14 = fncls__1571 }; vmsg__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1572, tmp14, nil); var lines__15 any; var iter__1927001039__auto____15 any; var fnbody__1634 any = /*line :179:1*/A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_New_O(vmsg__14); var tmp15 *jrt.Class; var fncls__1633 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_fn_class; if












































	fncls__1633 == nil { var fncls__1633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__1634); A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_fn_class = fncls__1633d; tmp15 = fncls__1633d } else { tmp15 = fncls__1633 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1634, tmp15, nil); lines__15 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(errs__12); var lines__16 any; if
	jrt.J2g_Truth(front__5) { var ___16 any = lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_151); var name__17 any = jrt.File_New_String(jrt.String_Cast(front__5)).GetName__String().Ref(); var noder__18 any; var tmp16 *lang.Keyword = A_arbace_go_run_A_const_152; var tmp17 any; var root_1639 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1641 lang.IFn; _ = ___16


		if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = A_arbace_go_run_A_const_154; if linked_1640 == nil { tmp17 = ifn_1641.Invoke_O__O(arg_1642) } else { tmp17 = linked_1640.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1639, arg_1642) }; noder__18 = tmp16.Invoke_O__O(lang.IFn_Cast(tmp17).Invoke_O_O__O(front__5, name__17))
//line :225:1
		var pos__19 any; var fnbody__1649 any = A_arbace_go_run_errorcheck_pos__1938000203_A_New(); var tmp18 *jrt.Class
		var fncls__1648 /*line :225:1*/*jrt.Class = A_arbace_go_run_errorcheck_pos__1938000203_A_fn_class




		if fncls__1648 == nil { var fncls__1648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_go_run_errorcheck_pos__1938000203_A_fn_class = fncls__1648d; tmp18 = fncls__1648d } else { tmp18 = fncls__1648 }; pos__19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1649, tmp18, nil)
//line :225:1
		var merged__20 any; var root_1650 any = A_arbace_go_run_A_const_157.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1652 lang.IFn






		if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = pos__19; var arg_1654 any; var root_1655 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any = lines__15; var arg_1659 any = noder__18; if linked_1656 == nil { arg_1654 = ifn_1657.Invoke_O_O__O(arg_1658, arg_1659) } else { arg_1654 = linked_1656.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1655, arg_1658, arg_1659) }; if linked_1651 == nil { merged__20 = ifn_1652.Invoke_O_O__O(arg_1653, arg_1654) } else { merged__20 = linked_1651.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1650, arg_1653, arg_1654) }
		var tmp19 any; var root_1660 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = merged__20; if linked_1661 == nil { tmp19 = ifn_1662.Invoke_O__O(arg_1663) } else { tmp19 = linked_1661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1660, arg_1663) }; if jrt.J2g_Truth(tmp19) { lines__16 = merged__20 } else {

			var tmp20 any; var root_1664 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = A_arbace_go_run_A_const_158; if linked_1665 == nil { tmp20 = ifn_1666.Invoke_O__O(arg_1667) } else { tmp20 = linked_1665.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1664, arg_1667) }; lines__16 = lang.IFn_Cast(tmp20).Invoke_O_O_O__O(front__5, name__17, lang__2) } } else {
//line :225:1
				lines__16 = lines__15 }; var lines__17 any; var root_1668 any = /*line :179:1*/A_arbace_go_run_A_const_159.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_dedupe_A_fn_class); var ifn_1670 lang.IFn; if

























































	linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = lines__16; if linked_1669 == nil { lines__17 = ifn_1670.Invoke_O__O(arg_1671) } else { lines__17 = linked_1669.(*aot_arbace_core.A_arbace_core_dedupe_A).Invoke_O_O__O(root_1668, arg_1671) }; var lines__18 any; var tmp21 any; var and__1927000168__auto____18 any = max_errors__3; if


	jrt.J2g_Truth(and__1927000168__auto____18) { var tmp22 bool; var na_1672 int64 = int64(lang.RT_Count_O__I_NoInit(lines__17)); var na_1673 any = max_errors__3; if jrt.Long_InstanceOf(na_1673) { var n0_1674 int64 = na_1672; var n1_1675 int64 = jrt.NN(jrt.Long_Cast(na_1673)).LongValue__J(); tmp22 = n0_1674 >= n1_1675 } else { tmp22 = lang.Numbers_Gte_J_O__Z_NoInit(na_1672, na_1673) }; tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp22).Ref() } else { tmp21 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp21) { var ls__18 any; var root_1677 any = A_arbace_go_run_A_const_137.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1679 lang.IFn
		if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any; var root_1681 any = A_arbace_go_run_A_const_160.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = max_errors__3; var arg_1685 any = lines__17; if linked_1682 == nil { arg_1680 = ifn_1683.Invoke_O_O__O(arg_1684, arg_1685) } else { arg_1680 = linked_1682.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1681, arg_1684, arg_1685) }; if linked_1678 == nil { ls__18 = ifn_1679.Invoke_O__O(arg_1680) } else { ls__18 = linked_1678.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1677, arg_1680) }
//line :240:1
		var pos__19_2 any; var root_1686 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1688 lang.IFn

		if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = A_arbace_go_run_A_const_161; var arg_1690 any; var root_1691 any = A_arbace_go_run_A_const_162.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = ls__18; if linked_1692 == nil { arg_1690 = ifn_1693.Invoke_O__O(arg_1694) } else { arg_1690 = linked_1692.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1691, arg_1694) }; if linked_1687 == nil { pos__19_2 = ifn_1688.Invoke_O_O__O(arg_1689, arg_1690) } else { pos__19_2 = linked_1687.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1686, arg_1689, arg_1690) }
		var root_1695 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = ls__18; var arg_1699 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, pos__19_2, nil)).Ref(); if linked_1696 == nil { lines__18 = ifn_1697.Invoke_O_O__O(arg_1698, arg_1699) } else { lines__18 = linked_1696.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1695, arg_1698, arg_1699) } } else {
//line :240:1
			lines__18 = lines__17 }; var seq_1938000208__19 any; var root_1738 any = /*line :179:1*/A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1740 lang.IFn; if

































































	linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = lines__18; if linked_1739 == nil { seq_1938000208__19 = ifn_1740.Invoke_O__O(arg_1741) } else { seq_1938000208__19 = linked_1739.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1738, arg_1741) }; var chunk_1938000209__20 any; var count_1938000210__21 int64 = 0; var i_1938000211__22 int64 = 0; L1:
//line :179:1
	for {

































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000211__22, count_1938000210__21) { var l__23 any = lang.Indexed_Cast(chunk_1938000209__20).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000211__22)); lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(l__23); seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, i_1938000211__22 = seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000211__22); continue L1 } else { var temp__1927000414__auto____23 any; var root_1742 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = seq_1938000208__19; if linked_1743 == nil { temp__1927000414__auto____23 = ifn_1744.Invoke_O__O(arg_1745) } else { temp__1927000414__auto____23 = linked_1743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1742, arg_1745) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var seq_1938000208__24 any = temp__1927000414__auto____23; var tmp23 any; var root_1746 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = seq_1938000208__24; if linked_1747 == nil { tmp23 = ifn_1748.Invoke_O__O(arg_1749) } else { tmp23 = linked_1747.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1746, arg_1749) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____25 any; var root_1750 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = seq_1938000208__24; if linked_1751 == nil { c__1927000678__auto____25 = ifn_1752.Invoke_O__O(arg_1753) } else { c__1927000678__auto____25 = linked_1751.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1750, arg_1753) }; var tmp24 any; var root_1765 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = seq_1938000208__24; if linked_1766 == nil { tmp24 = ifn_1767.Invoke_O__O(arg_1768) } else { tmp24 = linked_1766.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1765, arg_1768) }; seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, i_1938000211__22 = tmp24, c__1927000678__auto____25, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____25))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__25 any; var root_1754 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = seq_1938000208__24; if linked_1755 == nil { l__25 = ifn_1756.Invoke_O__O(arg_1757) } else { l__25 = linked_1755.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1754, arg_1757) }; lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(l__25); var tmp25 any; var root_1773 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = seq_1938000208__24; if linked_1774 == nil { tmp25 = ifn_1775.Invoke_O__O(arg_1776) } else { tmp25 = linked_1774.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1773, arg_1776) }; seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, i_1938000211__22 = tmp25, nil, 0, 0; continue L1 } } }
//line :179:1
		break L1 }; var root_1758 any =


































































	A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; if linked_1759 == nil { ifn_1760.Invoke__O() } else { linked_1759.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_1758) }; var tmp26 any; var root_1700 any =
	A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = lines__18; if linked_1701 == nil { tmp26 = ifn_1702.Invoke_O__O(arg_1703) } else { tmp26 = linked_1701.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1700, arg_1703) }; if jrt.J2g_Truth(tmp26) { return A_arbace_go_run_A_const_163 } else { return A_arbace_go_run_A_const_156 } }
//line :197:1
func A_arbace_go_run_errorcheck_fn__1938000163_A_New() *A_arbace_go_run_errorcheck_fn__1938000163_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000163_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_A) Invoke_O_O__O(self, fs__1 any) any { var root_1409 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any; var fnbody__1445 any = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_New(); var tmp1 *jrt.Class; var fncls__1444 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_fn_class; if fncls__1444 == nil { var fncls__1444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_fn_class = fncls__1444d; tmp1 = fncls__1444d } else { tmp1 = fncls__1444 }; arg_1412 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1445, tmp1, nil); var arg_1413 any = fs__1; if linked_1410 == nil { return ifn_1411.Invoke_O_O__O(arg_1412, arg_1413) } else { return linked_1410.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1409, arg_1412, arg_1413) } }
//line :197:1
func A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_New() *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A) Invoke_O_O__O(self, p1__1938000157_SHARP___1 any) any { var G__1938000165__2_ any; var root_1414 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = p1__1938000157_SHARP___1; var arg_1418 any = A_arbace_go_run_A_const_52; var arg_1419 any; var fnbody__1426 any = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_New(); var tmp1 *jrt.Class; var fncls__1425 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_fn_class; if fncls__1425 == nil { var fncls__1425d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_fn_class = fncls__1425d; tmp1 = fncls__1425d } else { tmp1 = fncls__1425 }; arg_1419 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1426, tmp1, nil); if linked_1415 == nil { G__1938000165__2_ = ifn_1416.Invoke_O_O_O__O(arg_1417, arg_1418, arg_1419) } else { G__1938000165__2_ = linked_1415.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1414, arg_1417, arg_1418, arg_1419) }; var G__1938000165__3_ any; if jrt.J2g_Truth(A_arbace_go_run_A_const_65.Invoke_O__O(p1__1938000157_SHARP___1)) {
																var root_1427 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = G__1938000165__2_; var arg_1431 any = A_arbace_go_run_A_const_65; var arg_1432 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); if linked_1428 == nil { G__1938000165__3_ = ifn_1429.Invoke_O_O_O__O(arg_1430, arg_1431, arg_1432) } else { G__1938000165__3_ = linked_1428.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1427, arg_1430, arg_1431, arg_1432) } } else {
//line :197:1
		G__1938000165__3_ = G__1938000165__2_ }; var tmp2 any; var root_1433 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1435 lang.IFn; if

	linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = p1__1938000157_SHARP___1; var arg_1437 any = A_arbace_go_run_A_const_140; if linked_1434 == nil { tmp2 = ifn_1435.Invoke_O_O__O(arg_1436, arg_1437) } else { tmp2 = linked_1434.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1433, arg_1436, arg_1437) }; if /*line :197:1*/ jrt.J2g_Truth(tmp2) {

		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_141.GetRawRoot__O()); var tmp4 any = A_arbace_go_run_A_const_142; return tmp3.Invoke_O_O_O__O(G__1938000165__3_, tmp4, A_arbace_go_run_A_const_117.GetRawRoot__O()) } else {
//line :197:1
			return G__1938000165__3_ } }
//line :197:1
func A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_New() *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A) Invoke_O_O__O(self, ds__1 any) any { var root_1420 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var arg_1424 any = ds__1; if linked_1421 == nil { return ifn_1422.Invoke_O_O__O(arg_1423, arg_1424) } else { return linked_1421.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1420, arg_1423, arg_1424) } }






func A_arbace_go_run_errorcheck_fn__1938000170_A_New() *A_arbace_go_run_errorcheck_fn__1938000170_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000170_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_go_run_errorcheck_fn__1938000170_A) Ctor() {}
//line :204:1
func (t *A_arbace_go_run_errorcheck_fn__1938000170_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_go_run_errorcheck_fn__1938000172_A_New() *A_arbace_go_run_errorcheck_fn__1938000172_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000172_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_go_run_errorcheck_fn__1938000172_A) Ctor() {}
//line :206:1
func (t *A_arbace_go_run_errorcheck_fn__1938000172_A) Invoke_O_O__O(self, p1__1938000158_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_61; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000158_SHARP___1)) { return p1__1938000158_SHARP___1 } else { return nil } }

func A_arbace_go_run_errorcheck_fn__1938000174_A_New() *A_arbace_go_run_errorcheck_fn__1938000174_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000174_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_run_errorcheck_fn__1938000174_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_run_errorcheck_fn__1938000174_A) Invoke_O_O__O(self, p1__1938000159_SHARP___1 any) any { var temp__1927000414__auto____2 any = A_arbace_go_run_A_const_164.Invoke_O__O(p1__1938000159_SHARP___1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var u__3 any = temp__1927000414__auto____2; return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_run_A_const_65.Invoke_O__O(p1__1938000159_SHARP___1), u__3) } else { return nil } }




func A_arbace_go_run_errorcheck_fn__1938000177_A_New() *A_arbace_go_run_errorcheck_fn__1938000177_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000177_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_go_run_errorcheck_fn__1938000177_A) Ctor() {}
//line :213:1
func (t *A_arbace_go_run_errorcheck_fn__1938000177_A) Invoke_O_O__O(self, p1__1938000160_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_144; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000160_SHARP___1))).Ref() }
func A_arbace_go_run_errorcheck_fn__1938000179_A_New() *A_arbace_go_run_errorcheck_fn__1938000179_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000179_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_run_errorcheck_fn__1938000179_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_run_errorcheck_fn__1938000179_A) Invoke_O_O__O(self, p1__1938000161_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_145; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000161_SHARP___1))).Ref() }

func A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_New() *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A) Ctor() {}
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A) Invoke_O_O__O(self, s__1938000182__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1558 any = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_New_O_O(s__1938000182__1, self); var tmp2 *jrt.Class; var fncls__1557 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_fn_class; if fncls__1557 == nil { var fncls__1557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1558); A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_fn_class = fncls__1557d; tmp2 = fncls__1557d } else { tmp2 = fncls__1557 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1558, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :216:1
func A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_New_O_O(p0, p1 any) *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A) Ctor_O_O(c__s__1938000182, c__iter__1938000181 any) { t.F_s__1938000182 = c__s__1938000182; t.F_iter__1938000181 = c__iter__1938000181 }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A) Invoke_O__O(self any) any { { var s__1938000182__1 any; var t_ any = t.F_s__1938000182; t.F_s__1938000182 = nil; s__1938000182__1 = t_; for { var temp__1927000414__auto____2 any; var root_1489 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = s__1938000182__1; if linked_1490 == nil { temp__1927000414__auto____2 = ifn_1491.Invoke_O__O(arg_1492) } else { temp__1927000414__auto____2 = linked_1490.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1489, arg_1492) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000182__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1493 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = s__1938000182__3; if linked_1494 == nil { tmp1 = ifn_1495.Invoke_O__O(arg_1496) } else { tmp1 = linked_1494.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1493, arg_1496) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1497 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = s__1938000182__3; if linked_1498 == nil { c__1927001037__auto____4 = ifn_1499.Invoke_O__O(arg_1500) } else { c__1927001037__auto____4 = linked_1498.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1497, arg_1500) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000184__6 any; var root_1501 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1502 == nil { b__1938000184__6 = ifn_1503.Invoke_O__O(arg_1504) } else { b__1938000184__6 = linked_1502.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1501, arg_1504) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1516 any = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_New_O_I_O(b__1938000184__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1515 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_fn_class; if fncls__1515 == nil { var fncls__1515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__1516); A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_fn_class = fncls__1515d; tmp3 = fncls__1515d } else { tmp3 = fncls__1515 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1516, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1517 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any; var root_1522 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = b__1938000184__6; if linked_1523 == nil { arg_1520 = ifn_1524.Invoke_O__O(arg_1525) } else { arg_1520 = linked_1523.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1522, arg_1525) }; var arg_1521 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000181); var tmp5 any; var root_1526 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = s__1938000182__3; if linked_1527 == nil { tmp5 = ifn_1528.Invoke_O__O(arg_1529) } else { tmp5 = linked_1527.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1526, arg_1529) }; arg_1521 = tmp4.Invoke_O__O(tmp5); if linked_1518 == nil { return ifn_1519.Invoke_O_O__O(arg_1520, arg_1521) } else { return linked_1518.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1517, arg_1520, arg_1521) } } else { var root_1530 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any; var root_1535 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = b__1938000184__6; if linked_1536 == nil { arg_1533 = ifn_1537.Invoke_O__O(arg_1538) } else { arg_1533 = linked_1536.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1535, arg_1538) }; var arg_1534 any; if linked_1531 == nil { return ifn_1532.Invoke_O_O__O(arg_1533, arg_1534) } else { return linked_1531.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1530, arg_1533, arg_1534) } } } else { var fi__4 any; var root_1539 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = s__1938000182__3; if linked_1540 == nil { fi__4 = ifn_1541.Invoke_O__O(arg_1542) } else { fi__4 = linked_1540.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1539, arg_1542) }; var root_1543 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any; var tmp6 any = A_arbace_go_run_A_const_81.Invoke_O__O(fi__4); var tmp7 any; var root_1548 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = fi__4; var arg_1552 any = A_arbace_go_run_A_const_147; if linked_1549 == nil { tmp7 = ifn_1550.Invoke_O_O__O(arg_1551, arg_1552) } else { tmp7 = linked_1549.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1548, arg_1551, arg_1552) }; arg_1546 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_1547 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000181); var tmp9 any; var root_1553 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = s__1938000182__3; if linked_1554 == nil { tmp9 = ifn_1555.Invoke_O__O(arg_1556) } else { tmp9 = linked_1554.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1553, arg_1556) }; arg_1547 = tmp8.Invoke_O__O(tmp9); if linked_1544 == nil { return ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { return linked_1544.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :216:1
func A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A) Ctor_O_I_O(c__b__1938000184 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000184 = c__b__1938000184; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A) Invoke_O__O(self any) any { { var i__1938000183__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000183__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000183__1)); var root_1505 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = t.F_b__1938000184; var arg_1509 any; var tmp2 any = A_arbace_go_run_A_const_81.Invoke_O__O(fi__2); var tmp3 any; var root_1510 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = fi__2; var arg_1514 any = A_arbace_go_run_A_const_146; if linked_1511 == nil { tmp3 = ifn_1512.Invoke_O_O__O(arg_1513, arg_1514) } else { tmp3 = linked_1511.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1510, arg_1513, arg_1514) }; arg_1509 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_1506 == nil { ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { linked_1506.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) }; i__1938000183__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000183__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_run_errorcheck_vmsg__1938000191_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_vmsg__1938000191_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_vmsg__1938000191_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :217:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000191_A) Ctor_O_O_O(c__file_lang, c__lang, c__src any) { t.F_file_lang = c__file_lang; t.F_lang = c__lang; t.F_src = c__src }
//line :217:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000191_A) Invoke_O_O__O(self, e__1 any) any { var m__2 any = A_arbace_go_run_A_const_63.Invoke_O__O(e__1); var tmp1 any; var root_1561 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1563 lang.IFn; if

	linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = A_arbace_go_run_A_const_149; var arg_1565 any = m__2; if linked_1562 == nil { tmp1 = ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { tmp1 = linked_1562.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_file_lang); var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(A_arbace_go_run_A_const_65.Invoke_O__O(e__1))
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var fl__4 any = temp__1927000408__auto____3
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, m__2, nil, fl__4, nil)).Ref() } else {
				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_49); var tmp4 any; var or__1927000174__auto____8 any = t.F_lang; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var root_1566 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = t.F_src; var arg_1570 any = A_arbace_go_run_A_const_150; if linked_1567 == nil { tmp4 = ifn_1568.Invoke_O_O__O(arg_1569, arg_1570) } else { tmp4 = linked_1567.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1566, arg_1569, arg_1570) } }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, m__2, nil, tmp4, nil)).Ref() } } else {
//line :219:1
					return m__2 } }




func A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_New_O(p0 any) *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A) Ctor_O(c__vmsg any) { t.F_vmsg = c__vmsg }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A) Invoke_O_O__O(self, s__1938000194__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1632 any = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_New_O_O_O(self, s__1938000194__1, t.F_vmsg); var tmp2 *jrt.Class; var fncls__1631 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_fn_class; if fncls__1631 == nil { var fncls__1631d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__1632); A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_fn_class = fncls__1631d; tmp2 = fncls__1631d } else { tmp2 = fncls__1631 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1632, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :224:1
func A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A) Ctor_O_O_O(c__iter__1938000193, c__s__1938000194, c__vmsg any) { t.F_iter__1938000193 = c__iter__1938000193; t.F_s__1938000194 = c__s__1938000194; t.F_vmsg = c__vmsg }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A) Invoke_O__O(self any) any { { var s__1938000194__1 any; var t_ any = t.F_s__1938000194; t.F_s__1938000194 = nil; s__1938000194__1 = t_; for { var temp__1927000414__auto____2 any; var root_1573 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = s__1938000194__1; if linked_1574 == nil { temp__1927000414__auto____2 = ifn_1575.Invoke_O__O(arg_1576) } else { temp__1927000414__auto____2 = linked_1574.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1573, arg_1576) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000194__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1577 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = s__1938000194__3; if linked_1578 == nil { tmp1 = ifn_1579.Invoke_O__O(arg_1580) } else { tmp1 = linked_1578.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1577, arg_1580) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1581 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = s__1938000194__3; if linked_1582 == nil { c__1927001037__auto____4 = ifn_1583.Invoke_O__O(arg_1584) } else { c__1927001037__auto____4 = linked_1582.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1581, arg_1584) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000196__6 any; var root_1585 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1586 == nil { b__1938000196__6 = ifn_1587.Invoke_O__O(arg_1588) } else { b__1938000196__6 = linked_1586.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1585, arg_1588) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1595 any = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_New_O_I_O_O(b__1938000196__6, size__1927001038__auto____5, t.F_vmsg, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1594 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_fn_class; if fncls__1594 == nil { var fncls__1594d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__1595); A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_fn_class = fncls__1594d; tmp3 = fncls__1594d } else { tmp3 = fncls__1594 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1595, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1596 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any; var root_1601 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = b__1938000196__6; if linked_1602 == nil { arg_1599 = ifn_1603.Invoke_O__O(arg_1604) } else { arg_1599 = linked_1602.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1601, arg_1604) }; var arg_1600 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000193); var tmp5 any; var root_1605 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = s__1938000194__3; if linked_1606 == nil { tmp5 = ifn_1607.Invoke_O__O(arg_1608) } else { tmp5 = linked_1606.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1605, arg_1608) }; arg_1600 = tmp4.Invoke_O__O(tmp5); if linked_1597 == nil { return ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { return linked_1597.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) } } else { var root_1609 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any; var root_1614 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1616 lang.IFn; if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = b__1938000196__6; if linked_1615 == nil { arg_1612 = ifn_1616.Invoke_O__O(arg_1617) } else { arg_1612 = linked_1615.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1614, arg_1617) }; var arg_1613 any; if linked_1610 == nil { return ifn_1611.Invoke_O_O__O(arg_1612, arg_1613) } else { return linked_1610.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1609, arg_1612, arg_1613) } } } else { var e__4 any; var root_1618 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = s__1938000194__3; if linked_1619 == nil { e__4 = ifn_1620.Invoke_O__O(arg_1621) } else { e__4 = linked_1619.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1618, arg_1621) }; var root_1622 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_65.Invoke_O__O(e__4), nil, A_arbace_go_run_A_const_66.Invoke_O__O(e__4), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__4))).Ref(); var arg_1626 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1938000193); var tmp7 any; var root_1627 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = s__1938000194__3; if linked_1628 == nil { tmp7 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp7 = linked_1628.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1627, arg_1630) }; arg_1626 = tmp6.Invoke_O__O(tmp7); if linked_1623 == nil { return ifn_1624.Invoke_O_O__O(arg_1625, arg_1626) } else { return linked_1623.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1622, arg_1625, arg_1626) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :224:1
func A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A) Ctor_O_I_O_O(c__b__1938000196 any, c__size__1927001038__auto__ int32, c__vmsg, c__c__1927001037__auto__ any) { t.F_b__1938000196 = c__b__1938000196; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_vmsg = c__vmsg; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A) Invoke_O__O(self any) any { { var i__1938000195__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000195__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000195__1)); var root_1589 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = t.F_b__1938000196; var arg_1593 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_65.Invoke_O__O(e__2), nil, A_arbace_go_run_A_const_66.Invoke_O__O(e__2), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__2))).Ref(); if linked_1590 == nil { ifn_1591.Invoke_O_O__O(arg_1592, arg_1593) } else { linked_1590.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1589, arg_1592, arg_1593) }; i__1938000195__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000195__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_errorcheck_pos__1938000203_A_New() *A_arbace_go_run_errorcheck_pos__1938000203_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_pos__1938000203_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_go_run_errorcheck_pos__1938000203_A) Ctor() {}
//line :230:1
func (t *A_arbace_go_run_errorcheck_pos__1938000203_A) Invoke_O_O__O(self, l__1 any) any { var vec__1938000204__2 any; var root_1643 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = A_arbace_go_run_A_const_155; var arg_1647 any = l__1; if linked_1644 == nil { vec__1938000204__2 = ifn_1645.Invoke_O_O__O(arg_1646, arg_1647) } else { vec__1938000204__2 = linked_1644.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1643, arg_1646, arg_1647) }; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000204__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000204__2, lang.RT_IntCast_J__I_NoInit(1), nil); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000204__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any; var or__1927000174__auto____6 any = f__4; _ = ___3; if
												jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = Lit_22 }; var tmp2 any = tmp1; var tmp3 any; if jrt.J2g_Truth(n__5) { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__5))).Ref() } else { tmp3 = A_arbace_go_run_A_const_156 }; return /*line :230:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }


















func A_arbace_go_run__main_A_New() *A_arbace_go_run__main_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_go_run__main_A) Ctor() {}
//line :249:1
func (t *A_arbace_go_run__main_A) DoInvoke_O_O__O(self, args__0 any) any {






	var tmp1 any; var root_1834 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = args__0; if linked_1835 == nil { tmp1 = ifn_1836.Invoke_O__O(arg_1837) } else { tmp1 = linked_1835.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1834, arg_1837) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_1, tmp1) { var vec__1938000213__2 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__1903 any = A_arbace_go_run__main_fn__1938000219_A_New_O(args__0); var tmp3 *jrt.Class; var fncls__1902 *jrt.Class = A_arbace_go_run__main_fn__1938000219_A_fn_class
		if fncls__1902 == nil { var fncls__1902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__1903); A_arbace_go_run__main_fn__1938000219_A_fn_class = fncls__1902d; tmp3 = fncls__1902d } else { tmp3 = fncls__1902 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1903, tmp3, nil); vec__1938000213__2 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()
//line :256:1
		var opts__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000213__2, lang.RT_IntCast_J__I_NoInit(0), nil); var args__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000213__2, lang.RT_IntCast_J__I_NoInit(1), nil); var lang__5 any = A_arbace_go_run_A_const_172.Invoke_O__O(opts__3); var vec__1938000216__6 any = args__4; var root__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000216__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_name__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000216__6, lang.RT_IntCast_J__I_NoInit(1), nil); var pf__9 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp5 any; var root_1904 any = A_arbace_go_run_A_const_166.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1906 lang.IFn









		if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = ns_name__8; if linked_1905 == nil { tmp5 = ifn_1906.Invoke_O__O(arg_1907) } else { tmp5 = linked_1905.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1904, arg_1907) }
//line :256:1
		pf__9 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, root__7, nil, tmp5)))










		if jrt.File_Cast(pf__9).IsFile__Z() { } else { var root_1944 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, A_arbace_go_run_fail_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = A_arbace_go_run_A_const_64; var arg_1948 any = Lit_4; var arg_1949 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__9)).Ref(); if linked_1945 == nil { ifn_1946.Invoke_O_O_O__O(arg_1947, arg_1948, arg_1949) } else { linked_1945.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1944, arg_1947, arg_1948, arg_1949) } }
		var tmp6 *lang.Compiler_AOTFn; var fnbody__1943 any = A_arbace_go_run__main_fn__1938000222_A_New_O_O_O_O(lang__5, pf__9, root__7, opts__3); var tmp7 *jrt.Class; var fncls__1942 *jrt.Class = A_arbace_go_run__main_fn__1938000222_A_fn_class; if fncls__1942 == nil { var fncls__1942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__1943); A_arbace_go_run__main_fn__1938000222_A_fn_class = fncls__1942d; tmp7 = fncls__1942d } else { tmp7 = fncls__1942 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1943, tmp7, nil); jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(Up_Compiler_AOTFn_IFn(tmp6).Invoke__O())) }
//line :249:1
	var vec__1938000224__2 any = args__0; var seq__1938000225__3 any; var root_1777 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1779 lang.IFn


























	if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = vec__1938000224__2; if linked_1778 == nil { seq__1938000225__3 = ifn_1779.Invoke_O__O(arg_1780) } else { seq__1938000225__3 = linked_1778.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1777, arg_1780) }
//line :249:1
	var first__1938000226__4 any; var root_1781 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1783 lang.IFn


























	if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = seq__1938000225__3; if linked_1782 == nil { first__1938000226__4 = ifn_1783.Invoke_O__O(arg_1784) } else { first__1938000226__4 = linked_1782.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1781, arg_1784) }
//line :249:1
	var seq__1938000225__5 any; var root_1785 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1787 lang.IFn


























	if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = seq__1938000225__3; if linked_1786 == nil { seq__1938000225__5 = ifn_1787.Invoke_O__O(arg_1788) } else { seq__1938000225__5 = linked_1786.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1785, arg_1788) }
//line :249:1
	var root__6 any = first__1938000226__4; var first__1938000226__7 any; var root_1789 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1791 lang.IFn


























	if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = seq__1938000225__5; if linked_1790 == nil { first__1938000226__7 = ifn_1791.Invoke_O__O(arg_1792) } else { first__1938000226__7 = linked_1790.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1789, arg_1792) }
//line :249:1
	var seq__1938000225__8 any; var root_1793 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1795 lang.IFn


























	if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any = seq__1938000225__5; if linked_1794 == nil { seq__1938000225__8 = ifn_1795.Invoke_O__O(arg_1796) } else { seq__1938000225__8 = linked_1794.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1793, arg_1796) }
//line :249:1
	var ns_name__9 any = first__1938000226__7; var pargs__10 any = seq__1938000225__8; var tmp8 any
	var and__1927000168__auto____11 any = root__6


























	if jrt.J2g_Truth(and__1927000168__auto____11) { tmp8 = ns_name__9 } else { tmp8 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp8) { } else {
		var root_1959 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp10 any = A_arbace_go_run_A_const_20; var arg_1962 any = tmp9.Invoke_O_O__O(tmp10, A_arbace_go_run_A_const_21.Get__O()); if linked_1960 == nil { ifn_1961.Invoke_O__O(arg_1962) } else { linked_1960.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1959, arg_1962) }; var tmp11 *lang.Compiler_AOTFn; var fnbody__1958 any = A_arbace_go_run__main_fn__1938000227_A_New(); var tmp12 *jrt.Class; var fncls__1957 *jrt.Class = A_arbace_go_run__main_fn__1938000227_A_fn_class; if fncls__1957 == nil { var fncls__1957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); A_arbace_go_run__main_fn__1938000227_A_fn_class = fncls__1957d; tmp12 = fncls__1957d } else { tmp12 = fncls__1957 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1958, tmp12, nil); Up_Compiler_AOTFn_IFn(tmp11).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :249:1
	var pf__11 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp14 any; var root_1797 any = A_arbace_go_run_A_const_166.GetRawRoot__O(); var linked_1798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1797, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1799 lang.IFn






























	if linked_1798 == nil { ifn_1799 = lang.IFn_Cast(root_1797) } else { ifn_1799 = nil }; var arg_1800 any = ns_name__9; if linked_1798 == nil { tmp14 = ifn_1799.Invoke_O__O(arg_1800) } else { tmp14 = linked_1798.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1797, arg_1800) }
//line :249:1
	pf__11 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, root__6, nil, tmp14)))































	if jrt.File_Cast(pf__11).IsFile__Z() { } else {
		var root_1968 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, A_arbace_go_run_fail_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = A_arbace_go_run_A_const_64; var arg_1972 any = Lit_4; var arg_1973 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__11)).Ref(); if linked_1969 == nil { ifn_1970.Invoke_O_O_O__O(arg_1971, arg_1972, arg_1973) } else { linked_1969.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1968, arg_1971, arg_1972, arg_1973) } }
//line :249:1
	var status__12 any; var tmp15 *lang.Compiler_AOTFn; var fnbody__1833 any = A_arbace_go_run__main_fn__1938000229_A_New_O_O_O(pargs__10, pf__11, root__6); var tmp16 *jrt.Class
	var fncls__1832 /*line :249:1*/*jrt.Class = A_arbace_go_run__main_fn__1938000229_A_fn_class

































	if fncls__1832 == nil { var fncls__1832d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__1833); A_arbace_go_run__main_fn__1938000229_A_fn_class = fncls__1832d; tmp16 = fncls__1832d } else { tmp16 = fncls__1832 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1833, tmp16, nil); status__12 = Up_Compiler_AOTFn_IFn(tmp15).Invoke__O()








	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__12)); return nil }
//line :257:1
func A_arbace_go_run__main_fn__1938000219_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000219_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000219_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_go_run__main_fn__1938000219_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :257:1
func (t *A_arbace_go_run__main_fn__1938000219_A) Invoke_O__O(self any) any { { var opts__1 any = lang.PersistentArrayMap_EMPTY.Ref(); var as__2 any; var root_1838 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1840 lang.IFn; if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any; var t_ any = t.F_args; t.F_args = nil; arg_1841 = t_; if linked_1839 == nil { as__2 = ifn_1840.Invoke_O__O(arg_1841) } else { as__2 = linked_1839.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1838, arg_1841) }; L1: for { var G__1938000220__3_ any; var root_1842 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1844 lang.IFn
										if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = as__2; if linked_1843 == nil { G__1938000220__3_ = ifn_1844.Invoke_O__O(arg_1845) } else { G__1938000220__3_ = linked_1843.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1842, arg_1845) }; switch lang.Util_Hash_O__I_NoInit(G__1938000220__3_) >> 15 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_9) {


		var tmp1 any; var root_1847 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = opts__1; var arg_1851 any = A_arbace_go_run_A_const_171; var arg_1852 any = jrt.Boolean_TRUE.Ref(); if linked_1848 == nil { tmp1 = ifn_1849.Invoke_O_O_O__O(arg_1850, arg_1851, arg_1852) } else { tmp1 = linked_1848.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1847, arg_1850, arg_1851, arg_1852) }; var tmp2 any = tmp1; var tmp3 any; var root_1853 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = as__2; if linked_1854 == nil { tmp3 = ifn_1855.Invoke_O__O(arg_1856) } else { tmp3 = linked_1854.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1853, arg_1856) }; opts__1, as__2 = tmp2, tmp3; continue L1 }
//line :258:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_10) {
		var tmp4 any; var root_1857 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = opts__1; var arg_1861 any = A_arbace_go_run_A_const_172; var arg_1862 any; var root_1863 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1865 lang.IFn; if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = as__2; if linked_1864 == nil { arg_1862 = ifn_1865.Invoke_O__O(arg_1866) } else { arg_1862 = linked_1864.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1863, arg_1866) }; if linked_1858 == nil { tmp4 = ifn_1859.Invoke_O_O_O__O(arg_1860, arg_1861, arg_1862) } else { tmp4 = linked_1858.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1857, arg_1860, arg_1861, arg_1862) }; var tmp5 any = tmp4; var tmp6 any; var root_1867 any = A_arbace_go_run_A_const_173.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1871 any = as__2; if linked_1868 == nil { tmp6 = ifn_1869.Invoke_O_O__O(A_arbace_go_run_A_const_174, arg_1871) } else { tmp6 = linked_1868.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1867, 2, A_arbace_go_run_A_const_174, arg_1871) }; opts__1, as__2 = tmp5, tmp6; continue L1 }
//line :258:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_11) {



		var tmp7 any; var root_1872 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = opts__1; var arg_1876 any = A_arbace_go_run_A_const_175; var arg_1877 any; var root_1878 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1880 lang.IFn; if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any = as__2; if linked_1879 == nil { arg_1877 = ifn_1880.Invoke_O__O(arg_1881) } else { arg_1877 = linked_1879.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1878, arg_1881) }; if linked_1873 == nil { tmp7 = ifn_1874.Invoke_O_O_O__O(arg_1875, arg_1876, arg_1877) } else { tmp7 = linked_1873.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1872, arg_1875, arg_1876, arg_1877) }; var tmp8 any = tmp7; var tmp9 any; var root_1882 any = A_arbace_go_run_A_const_173.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1884 lang.IFn; if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1886 any = as__2; if linked_1883 == nil { tmp9 = ifn_1884.Invoke_O_O__O(A_arbace_go_run_A_const_174, arg_1886) } else { tmp9 = linked_1883.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1882, 2, A_arbace_go_run_A_const_174, arg_1886) }; opts__1, as__2 = tmp8, tmp9; continue L1 }
//line :258:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_12) {

		var tmp10 any; var root_1887 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = opts__1; var arg_1891 any = A_arbace_go_run_A_const_176; var arg_1892 any; var tmp11 any; var root_1893 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = as__2; if linked_1894 == nil { tmp11 = ifn_1895.Invoke_O__O(arg_1896) } else { tmp11 = linked_1894.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1893, arg_1896) }; arg_1892 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp11))).Ref(); if linked_1888 == nil { tmp10 = ifn_1889.Invoke_O_O_O__O(arg_1890, arg_1891, arg_1892) } else { tmp10 = linked_1888.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1887, arg_1890, arg_1891, arg_1892) }; var tmp12 any = tmp10; var tmp13 any; var root_1897 any = A_arbace_go_run_A_const_173.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1901 any = as__2; if linked_1898 == nil { tmp13 = ifn_1899.Invoke_O_O__O(A_arbace_go_run_A_const_174, arg_1901) } else { tmp13 = linked_1898.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1897, 2, A_arbace_go_run_A_const_174, arg_1901) }; opts__1, as__2 = tmp12, tmp13; continue L1 }
//line :258:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__1, as__2) } }; /*line :257:1*/panic("j2g: unreachable") }










func A_arbace_go_run__main_fn__1938000222_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run__main_fn__1938000222_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000222_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :268:1
func (t *A_arbace_go_run__main_fn__1938000222_A) Ctor_O_O_O_O(c__lang, c__pf, c__root, c__opts any) { t.F_lang = c__lang; t.F_pf = c__pf; t.F_root = c__root; t.F_opts = c__opts }
//line :268:1
func (t *A_arbace_go_run__main_fn__1938000222_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1908 any = A_arbace_go_run_A_const_177.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, A_arbace_go_run_errorcheck_A_fn_class); var ifn_1910 lang.IFn; if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any; var t_ any = t.F_root; t.F_root = nil; arg_1911 = t_; var arg_1912 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1912 = t__2; var arg_1913 any; var t__3 any = t.F_lang; t.F_lang = nil; arg_1913 = t__3; var arg_1914 any = A_arbace_go_run_A_const_176.Invoke_O__O(t.F_opts); var arg_1915 any = A_arbace_go_run_A_const_171.Invoke_O__O(t.F_opts); var arg_1916 any; var tmp2 *lang.Keyword = A_arbace_go_run_A_const_175; var tmp3 any; var t__4 any = t.F_opts; t.F_opts = nil; tmp3 = t__4; arg_1916 = tmp2.Invoke_O__O(tmp3); if linked_1909 == nil { tmp1 = ifn_1910.Invoke_O_O_O_O_O_O__O(arg_1911, arg_1912, arg_1913, arg_1914, arg_1915, arg_1916) } else { tmp1 = linked_1909.(*A_arbace_go_run_errorcheck_A).Invoke_O_O_O_O_O_O_O__O(root_1908, arg_1911, arg_1912, arg_1913, arg_1914, arg_1915, arg_1916) } }; return nil }(); if tmp4 != nil { if true { var ex__3 jrt.Throwable_I = tmp4; var d__4 any; var root_1917 any = A_arbace_go_run_A_const_93.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1919 lang.IFn

	if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = ex__3; if linked_1918 == nil { d__4 = ifn_1919.Invoke_O__O(arg_1920) } else { d__4 = linked_1918.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1917, arg_1920) }
//line :268:1
	var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_168.Invoke_O__O(d__4)


	if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
		if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp5 any; var root_1921 any = A_arbace_go_run_A_const_169.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = m__7; var arg_1925 any = Lit_13; if linked_1922 == nil { tmp5 = ifn_1923.Invoke_O_O__O(arg_1924, arg_1925) } else { tmp5 = linked_1922.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1921, arg_1924, arg_1925) }; if jrt.J2g_Truth(tmp5) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
	if jrt.J2g_Truth(u__5) {
		var root_1926 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, A_arbace_go_run_fail_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = A_arbace_go_run_A_const_49; var arg_1930 any = Lit_14; var arg_1931 any = u__5; if linked_1927 == nil { tmp1 = ifn_1928.Invoke_O_O_O__O(arg_1929, arg_1930, arg_1931) } else { tmp1 = linked_1927.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1926, arg_1929, arg_1930, arg_1931) } } else {
			var root_1932 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, A_arbace_go_run_fail_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = A_arbace_go_run_A_const_64; var arg_1936 any = Lit_4; var arg_1937 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil); var tmp7 any; var root_1938 any = A_arbace_go_run_A_const_170.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = ex__3; if linked_1939 == nil { tmp7 = ifn_1940.Invoke_O__O(arg_1941) } else { tmp7 = linked_1939.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1938, arg_1941) }; arg_1937 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp7)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1933 == nil { tmp1 = ifn_1934.Invoke_O_O_O__O(arg_1935, arg_1936, arg_1937) } else { tmp1 = linked_1933.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1932, arg_1935, arg_1936, arg_1937) } } } }; return tmp1 }


func A_arbace_go_run__main_fn__1938000227_A_New() *A_arbace_go_run__main_fn__1938000227_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000227_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_go_run__main_fn__1938000227_A) Ctor() {}
//line :278:1
func (t *A_arbace_go_run__main_fn__1938000227_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_16); return nil }(); var root_1954 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1956 lang.IFn; if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; if linked_1955 == nil { ifn_1956.Invoke__O() } else { linked_1955.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1954) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_go_run__main_fn__1938000229_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run__main_fn__1938000229_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000229_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :283:1
func (t *A_arbace_go_run__main_fn__1938000229_A) Ctor_O_O_O(c__pargs, c__pf, c__root any) { t.F_pargs = c__pargs; t.F_pf = c__pf; t.F_root = c__root }
//line :283:1
func (t *A_arbace_go_run__main_fn__1938000229_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_1801 any = A_arbace_go_run_A_const_167.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, A_arbace_go_run_run_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any; var t_ any = t.F_root; t.F_root = nil; arg_1804 = t_; var arg_1805 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1805 = t__2; var arg_1806 any; var t__3 any = t.F_pargs; t.F_pargs = nil; arg_1806 = t__3; if linked_1802 == nil { tmp1 = ifn_1803.Invoke_O_O_O__O(arg_1804, arg_1805, arg_1806) } else { tmp1 = linked_1802.(*A_arbace_go_run_run_A).Invoke_O_O_O_O__O(root_1801, arg_1804, arg_1805, arg_1806) } }
//line :283:1
	return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var d__4 any; var root_1807 any = A_arbace_go_run_A_const_93.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1809 lang.IFn


		if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = ex__3; if linked_1808 == nil { d__4 = ifn_1809.Invoke_O__O(arg_1810) } else { d__4 = linked_1808.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1807, arg_1810) }
//line :283:1
		var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_168.Invoke_O__O(d__4)



		if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp3 any; var root_1811 any = A_arbace_go_run_A_const_169.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = m__7; var arg_1815 any = Lit_13; if linked_1812 == nil { tmp3 = ifn_1813.Invoke_O_O__O(arg_1814, arg_1815) } else { tmp3 = linked_1812.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1811, arg_1814, arg_1815) }; if jrt.J2g_Truth(tmp3) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
		if jrt.J2g_Truth(u__5) {
			var root_1816 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, A_arbace_go_run_fail_A_fn_class); var ifn_1818 lang.IFn; if linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any = A_arbace_go_run_A_const_49; var arg_1820 any = Lit_14; var arg_1821 any = u__5; if linked_1817 == nil { tmp1 = ifn_1818.Invoke_O_O_O__O(arg_1819, arg_1820, arg_1821) } else { tmp1 = linked_1817.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1816, arg_1819, arg_1820, arg_1821) } } else {
				var root_1822 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, A_arbace_go_run_fail_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = A_arbace_go_run_A_const_64; var arg_1826 any = Lit_4; var arg_1827 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil); var tmp5 any; var root_1828 any = A_arbace_go_run_A_const_170.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = ex__3; if linked_1829 == nil { tmp5 = ifn_1830.Invoke_O__O(arg_1831) } else { tmp5 = linked_1829.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1828, arg_1831) }; arg_1827 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp5)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1823 == nil { tmp1 = ifn_1824.Invoke_O_O_O__O(arg_1825, arg_1826, arg_1827) } else { tmp1 = linked_1823.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1822, arg_1825, arg_1826, arg_1827) } } } }; return tmp1 }































































































type A_arbace_go_run_A struct{ jrt.Object }

var A_arbace_go_run_A_const_pool *jrt.RefArray

var A_arbace_go_run_A_const_0 *lang.Var

var A_arbace_go_run_A_const_1 any

var A_arbace_go_run_A_const_2 *lang.Var

var A_arbace_go_run_A_const_3 any

var A_arbace_go_run_A_const_4 any

var A_arbace_go_run_A_const_5 any

var A_arbace_go_run_A_const_6 any

var A_arbace_go_run_A_const_7 *lang.Var

var A_arbace_go_run_A_const_8 *lang.Var

var A_arbace_go_run_A_const_9 *lang.Var

var A_arbace_go_run_A_const_10 *lang.Var

var A_arbace_go_run_A_const_11 any

var A_arbace_go_run_A_const_12 *lang.Var

var A_arbace_go_run_A_const_13 *lang.Var

var A_arbace_go_run_A_const_14 *lang.Var

var A_arbace_go_run_A_const_15 *lang.Var

var A_arbace_go_run_A_const_16 *lang.Var

var A_arbace_go_run_A_const_17 *lang.Var

var A_arbace_go_run_A_const_18 *lang.Var

var A_arbace_go_run_A_const_19 *lang.Var

var A_arbace_go_run_A_const_20 *lang.Var

var A_arbace_go_run_A_const_21 *lang.Var

var A_arbace_go_run_A_const_22 *lang.Var

var A_arbace_go_run_A_const_23 *lang.Var

var A_arbace_go_run_A_const_24 *lang.Var

var A_arbace_go_run_A_const_25 *lang.Var

var A_arbace_go_run_A_const_26 *lang.Var

var A_arbace_go_run_A_const_27 *lang.Var

var A_arbace_go_run_A_const_28 any

var A_arbace_go_run_A_const_29 *lang.Keyword

var A_arbace_go_run_A_const_30 *lang.Var

var A_arbace_go_run_A_const_31 *lang.Var

var A_arbace_go_run_A_const_32 *lang.Var

var A_arbace_go_run_A_const_33 *lang.Var

var A_arbace_go_run_A_const_34 *lang.Var

var A_arbace_go_run_A_const_35 *lang.Var

var A_arbace_go_run_A_const_36 *lang.Var

var A_arbace_go_run_A_const_37 *lang.Var

var A_arbace_go_run_A_const_38 *lang.Var

var A_arbace_go_run_A_const_39 *lang.Var

var A_arbace_go_run_A_const_40 *lang.Var

var A_arbace_go_run_A_const_41 *lang.Var

var A_arbace_go_run_A_const_42 *lang.Var

var A_arbace_go_run_A_const_43 *lang.Var

var A_arbace_go_run_A_const_44 *lang.Var

var A_arbace_go_run_A_const_45 *lang.Var

var A_arbace_go_run_A_const_46 *lang.Var

var A_arbace_go_run_A_const_47 any

var A_arbace_go_run_A_const_48 *lang.Var

var A_arbace_go_run_A_const_49 any

var A_arbace_go_run_A_const_50 *lang.Keyword

var A_arbace_go_run_A_const_51 *lang.Keyword

var A_arbace_go_run_A_const_52 *lang.Keyword

var A_arbace_go_run_A_const_53 *lang.Var

var A_arbace_go_run_A_const_54 *lang.Var

var A_arbace_go_run_A_const_55 *lang.Keyword

var A_arbace_go_run_A_const_56 *lang.Var

var A_arbace_go_run_A_const_57 *lang.Var

var A_arbace_go_run_A_const_58 *lang.Keyword

var A_arbace_go_run_A_const_59 *lang.Var

var A_arbace_go_run_A_const_60 *lang.Var

var A_arbace_go_run_A_const_61 *lang.Keyword

var A_arbace_go_run_A_const_62 *lang.Keyword

var A_arbace_go_run_A_const_63 *lang.Keyword

var A_arbace_go_run_A_const_64 any

var A_arbace_go_run_A_const_65 *lang.Keyword

var A_arbace_go_run_A_const_66 *lang.Keyword

var A_arbace_go_run_A_const_67 any

var A_arbace_go_run_A_const_68 *lang.Var

var A_arbace_go_run_A_const_69 *lang.Var

var A_arbace_go_run_A_const_70 *lang.Var

var A_arbace_go_run_A_const_71 *lang.Var

var A_arbace_go_run_A_const_72 any

var A_arbace_go_run_A_const_73 *lang.Var

var A_arbace_go_run_A_const_74 *lang.Var

var A_arbace_go_run_A_const_75 *lang.Keyword

var A_arbace_go_run_A_const_76 *lang.Var

var A_arbace_go_run_A_const_77 *lang.Var

var A_arbace_go_run_A_const_78 *lang.Var

var A_arbace_go_run_A_const_79 *lang.Var

var A_arbace_go_run_A_const_80 *lang.Var

var A_arbace_go_run_A_const_81 *lang.Keyword

var A_arbace_go_run_A_const_82 *lang.Keyword

var A_arbace_go_run_A_const_83 *lang.Var

var A_arbace_go_run_A_const_84 *lang.Keyword

var A_arbace_go_run_A_const_85 *lang.Keyword

var A_arbace_go_run_A_const_86 *lang.Keyword

var A_arbace_go_run_A_const_87 *lang.Keyword

var A_arbace_go_run_A_const_88 *lang.Keyword

var A_arbace_go_run_A_const_89 *lang.Keyword

var A_arbace_go_run_A_const_90 *lang.Var

var A_arbace_go_run_A_const_91 any

var A_arbace_go_run_A_const_92 *lang.Keyword

var A_arbace_go_run_A_const_93 *lang.Var

var A_arbace_go_run_A_const_94 *lang.Var

var A_arbace_go_run_A_const_95 *lang.Var

var A_arbace_go_run_A_const_96 *lang.Var

var A_arbace_go_run_A_const_97 *lang.Keyword

var A_arbace_go_run_A_const_98 *lang.Keyword

var A_arbace_go_run_A_const_99 *lang.Var

var A_arbace_go_run_A_const_100 *lang.Var

var A_arbace_go_run_A_const_101 *lang.Var

var A_arbace_go_run_A_const_102 *lang.Var

var A_arbace_go_run_A_const_103 *lang.Var

var A_arbace_go_run_A_const_104 *lang.Var

var A_arbace_go_run_A_const_105 *lang.Var

var A_arbace_go_run_A_const_106 *lang.Var

var A_arbace_go_run_A_const_107 *lang.Var

var A_arbace_go_run_A_const_108 *lang.Var

var A_arbace_go_run_A_const_109 *lang.Keyword

var A_arbace_go_run_A_const_110 *lang.Var

var A_arbace_go_run_A_const_111 *lang.Var

var A_arbace_go_run_A_const_112 *lang.Var

var A_arbace_go_run_A_const_113 *lang.Var

var A_arbace_go_run_A_const_114 *lang.Var

var A_arbace_go_run_A_const_115 *lang.Keyword

var A_arbace_go_run_A_const_116 *lang.Var

var A_arbace_go_run_A_const_117 *lang.Var

var A_arbace_go_run_A_const_118 *lang.Var

var A_arbace_go_run_A_const_119 *lang.Var

var A_arbace_go_run_A_const_120 *lang.Var

var A_arbace_go_run_A_const_121 *lang.Var

var A_arbace_go_run_A_const_122 *lang.Var

var A_arbace_go_run_A_const_123 *lang.Var

var A_arbace_go_run_A_const_124 *lang.Var

var A_arbace_go_run_A_const_125 *lang.Var

var A_arbace_go_run_A_const_126 *lang.Keyword

var A_arbace_go_run_A_const_127 *lang.Var

var A_arbace_go_run_A_const_128 *lang.Var

var A_arbace_go_run_A_const_129 *lang.Keyword

var A_arbace_go_run_A_const_130 *lang.Var

var A_arbace_go_run_A_const_131 *lang.Var

var A_arbace_go_run_A_const_132 any

var A_arbace_go_run_A_const_133 *lang.Keyword

var A_arbace_go_run_A_const_134 *lang.Var

var A_arbace_go_run_A_const_135 *lang.Keyword

var A_arbace_go_run_A_const_136 *lang.Keyword

var A_arbace_go_run_A_const_137 *lang.Var

var A_arbace_go_run_A_const_138 *lang.Var

var A_arbace_go_run_A_const_139 any

var A_arbace_go_run_A_const_140 any

var A_arbace_go_run_A_const_141 *lang.Var

var A_arbace_go_run_A_const_142 any

var A_arbace_go_run_A_const_143 *lang.Keyword

var A_arbace_go_run_A_const_144 *lang.Keyword

var A_arbace_go_run_A_const_145 *lang.Keyword

var A_arbace_go_run_A_const_146 any

var A_arbace_go_run_A_const_147 any

var A_arbace_go_run_A_const_148 *lang.Var

var A_arbace_go_run_A_const_149 any

var A_arbace_go_run_A_const_150 any

var A_arbace_go_run_A_const_151 any

var A_arbace_go_run_A_const_152 *lang.Keyword

var A_arbace_go_run_A_const_153 *lang.Var

var A_arbace_go_run_A_const_154 any

var A_arbace_go_run_A_const_155 any

var A_arbace_go_run_A_const_156 any

var A_arbace_go_run_A_const_157 *lang.Var

var A_arbace_go_run_A_const_158 any

var A_arbace_go_run_A_const_159 *lang.Var

var A_arbace_go_run_A_const_160 *lang.Var

var A_arbace_go_run_A_const_161 any

var A_arbace_go_run_A_const_162 *lang.Var

var A_arbace_go_run_A_const_163 any

var A_arbace_go_run_A_const_164 *lang.Keyword

var A_arbace_go_run_A_const_165 *lang.Keyword

var A_arbace_go_run_A_const_166 *lang.Var

var A_arbace_go_run_A_const_167 *lang.Var

var A_arbace_go_run_A_const_168 *lang.Keyword

var A_arbace_go_run_A_const_169 *lang.Var

var A_arbace_go_run_A_const_170 *lang.Var

var A_arbace_go_run_A_const_171 *lang.Keyword

var A_arbace_go_run_A_const_172 *lang.Keyword

var A_arbace_go_run_A_const_173 *lang.Var

var A_arbace_go_run_A_const_174 any

var A_arbace_go_run_A_const_175 *lang.Keyword

var A_arbace_go_run_A_const_176 *lang.Keyword

var A_arbace_go_run_A_const_177 *lang.Var

var A_arbace_go_run_A_init jrt.ClassInit

func A_arbace_go_run_A_Init() { if !A_arbace_go_run_A_init.Done() { A_arbace_go_run_A_init.Run(A_arbace_go_run_A_clinit) } }

func A_arbace_go_run_A_clinit() { A_arbace_go_run_A_clinit_p0(); A_arbace_go_run_A_clinit_p1(); A_arbace_go_run_A_clinit_p2(); A_arbace_go_run_A_clinit_p3(); A_arbace_go_run_A_clinit_p4(); A_arbace_go_run_A_clinit_p5(); A_arbace_go_run_A_clinit_p6(); A_arbace_go_run_A_clinit_p7(); A_arbace_go_run_A_clinit_p8(); A_arbace_go_run_A_clinit_p9(); A_arbace_go_run_A_clinit_p10(); A_arbace_go_run_A_clinit_p11(); A_arbace_go_run_A_clinit_p12(); A_arbace_go_run_A_clinit_p13(); A_arbace_go_run_A_clinit_p14() }

func A_arbace_go_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 239); A_arbace_go_run_A_const_0 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[61]); A_arbace_go_run_A_const_1 = A_arbace_go_run_A_const_pool.A[62]; A_arbace_go_run_A_const_2 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[63]); A_arbace_go_run_A_const_3 = A_arbace_go_run_A_const_pool.A[64]; A_arbace_go_run_A_const_4 = A_arbace_go_run_A_const_pool.A[65]; A_arbace_go_run_A_const_5 = A_arbace_go_run_A_const_pool.A[66]; A_arbace_go_run_A_const_6 = A_arbace_go_run_A_const_pool.A[67]; A_arbace_go_run_A_const_7 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[68]); A_arbace_go_run_A_const_8 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[69]); A_arbace_go_run_A_const_9 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[70]); A_arbace_go_run_A_const_10 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[71]); A_arbace_go_run_A_const_11 = A_arbace_go_run_A_const_pool.A[72] }

func A_arbace_go_run_A_clinit_p1() { A_arbace_go_run_A_const_12 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[73]); A_arbace_go_run_A_const_13 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[74]); A_arbace_go_run_A_const_14 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[75]); A_arbace_go_run_A_const_15 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[76]); A_arbace_go_run_A_const_16 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[77]); A_arbace_go_run_A_const_17 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[78]); A_arbace_go_run_A_const_18 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[79]); A_arbace_go_run_A_const_19 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[80]); A_arbace_go_run_A_const_20 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[81]); A_arbace_go_run_A_const_21 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[82]); A_arbace_go_run_A_const_22 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[83]); A_arbace_go_run_A_const_23 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[84]) }

func A_arbace_go_run_A_clinit_p2() { A_arbace_go_run_A_const_24 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[85]); A_arbace_go_run_A_const_25 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[86]); A_arbace_go_run_A_const_26 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[87]); A_arbace_go_run_A_const_27 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[88]); A_arbace_go_run_A_const_28 = A_arbace_go_run_A_const_pool.A[89]; A_arbace_go_run_A_const_29 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[90]); A_arbace_go_run_A_const_30 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[91]); A_arbace_go_run_A_const_31 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[92]); A_arbace_go_run_A_const_32 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[93]); A_arbace_go_run_A_const_33 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[94]); A_arbace_go_run_A_const_34 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[95]); A_arbace_go_run_A_const_35 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[96]) }

func A_arbace_go_run_A_clinit_p3() { A_arbace_go_run_A_const_36 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[97]); A_arbace_go_run_A_const_37 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[98]); A_arbace_go_run_A_const_38 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[99]); A_arbace_go_run_A_const_39 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[100]); A_arbace_go_run_A_const_40 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[101]); A_arbace_go_run_A_const_41 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[102]); A_arbace_go_run_A_const_42 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[103]); A_arbace_go_run_A_const_43 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[104]); A_arbace_go_run_A_const_44 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[105]); A_arbace_go_run_A_const_45 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[106]); A_arbace_go_run_A_const_46 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[107]); A_arbace_go_run_A_const_47 = A_arbace_go_run_A_const_pool.A[108] }

func A_arbace_go_run_A_clinit_p4() { A_arbace_go_run_A_const_48 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[109]); A_arbace_go_run_A_const_49 = A_arbace_go_run_A_const_pool.A[110]; A_arbace_go_run_A_const_50 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[111]); A_arbace_go_run_A_const_51 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[112]); A_arbace_go_run_A_const_52 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[113]); A_arbace_go_run_A_const_53 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[114]); A_arbace_go_run_A_const_54 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[115]); A_arbace_go_run_A_const_55 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[116]); A_arbace_go_run_A_const_56 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[117]); A_arbace_go_run_A_const_57 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[118]); A_arbace_go_run_A_const_58 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[119]); A_arbace_go_run_A_const_59 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[120]) }

func A_arbace_go_run_A_clinit_p5() { A_arbace_go_run_A_const_60 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[121]); A_arbace_go_run_A_const_61 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[122]); A_arbace_go_run_A_const_62 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[123]); A_arbace_go_run_A_const_63 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[124]); A_arbace_go_run_A_const_64 = A_arbace_go_run_A_const_pool.A[125]; A_arbace_go_run_A_const_65 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[126]); A_arbace_go_run_A_const_66 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[127]); A_arbace_go_run_A_const_67 = A_arbace_go_run_A_const_pool.A[128]; A_arbace_go_run_A_const_68 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[129]); A_arbace_go_run_A_const_69 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[130]); A_arbace_go_run_A_const_70 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[131]); A_arbace_go_run_A_const_71 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[132]) }

func A_arbace_go_run_A_clinit_p6() { A_arbace_go_run_A_const_72 = A_arbace_go_run_A_const_pool.A[133]; A_arbace_go_run_A_const_73 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[134]); A_arbace_go_run_A_const_74 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[135]); A_arbace_go_run_A_const_75 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[136]); A_arbace_go_run_A_const_76 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[137]); A_arbace_go_run_A_const_77 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[138]); A_arbace_go_run_A_const_78 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[139]); A_arbace_go_run_A_const_79 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[140]); A_arbace_go_run_A_const_80 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[141]); A_arbace_go_run_A_const_81 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[142]); A_arbace_go_run_A_const_82 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[143]); A_arbace_go_run_A_const_83 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[144]) }

func A_arbace_go_run_A_clinit_p7() { A_arbace_go_run_A_const_84 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[145]); A_arbace_go_run_A_const_85 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[146]); A_arbace_go_run_A_const_86 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[147]); A_arbace_go_run_A_const_87 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[148]); A_arbace_go_run_A_const_88 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[149]); A_arbace_go_run_A_const_89 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[150]); A_arbace_go_run_A_const_90 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[151]); A_arbace_go_run_A_const_91 = A_arbace_go_run_A_const_pool.A[152]; A_arbace_go_run_A_const_92 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[153]); A_arbace_go_run_A_const_93 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[154]); A_arbace_go_run_A_const_94 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[155]); A_arbace_go_run_A_const_95 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[156]) }

func A_arbace_go_run_A_clinit_p8() { A_arbace_go_run_A_const_96 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[157]); A_arbace_go_run_A_const_97 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[158]); A_arbace_go_run_A_const_98 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[159]); A_arbace_go_run_A_const_99 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[160]); A_arbace_go_run_A_const_100 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[161]); A_arbace_go_run_A_const_101 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[162]); A_arbace_go_run_A_const_102 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[163]); A_arbace_go_run_A_const_103 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[164]); A_arbace_go_run_A_const_104 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[165]); A_arbace_go_run_A_const_105 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[166]); A_arbace_go_run_A_const_106 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[167]); A_arbace_go_run_A_const_107 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[168]) }

func A_arbace_go_run_A_clinit_p9() { A_arbace_go_run_A_const_108 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[169]); A_arbace_go_run_A_const_109 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[170]); A_arbace_go_run_A_const_110 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[171]); A_arbace_go_run_A_const_111 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[172]); A_arbace_go_run_A_const_112 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[173]); A_arbace_go_run_A_const_113 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[174]); A_arbace_go_run_A_const_114 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[175]); A_arbace_go_run_A_const_115 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[176]); A_arbace_go_run_A_const_116 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[177]); A_arbace_go_run_A_const_117 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[178]); A_arbace_go_run_A_const_118 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[179]); A_arbace_go_run_A_const_119 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[180]) }

func A_arbace_go_run_A_clinit_p10() { A_arbace_go_run_A_const_120 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[181]); A_arbace_go_run_A_const_121 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[182]); A_arbace_go_run_A_const_122 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[183]); A_arbace_go_run_A_const_123 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[184]); A_arbace_go_run_A_const_124 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[185]); A_arbace_go_run_A_const_125 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[186]); A_arbace_go_run_A_const_126 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[187]); A_arbace_go_run_A_const_127 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[188]); A_arbace_go_run_A_const_128 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[189]); A_arbace_go_run_A_const_129 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[190]); A_arbace_go_run_A_const_130 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[191]); A_arbace_go_run_A_const_131 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[192]) }

func A_arbace_go_run_A_clinit_p11() { A_arbace_go_run_A_const_132 = A_arbace_go_run_A_const_pool.A[193]; A_arbace_go_run_A_const_133 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[194]); A_arbace_go_run_A_const_134 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[195]); A_arbace_go_run_A_const_135 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[196]); A_arbace_go_run_A_const_136 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[197]); A_arbace_go_run_A_const_137 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[198]); A_arbace_go_run_A_const_138 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[199]); A_arbace_go_run_A_const_139 = A_arbace_go_run_A_const_pool.A[200]; A_arbace_go_run_A_const_140 = A_arbace_go_run_A_const_pool.A[201]; A_arbace_go_run_A_const_141 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[202]); A_arbace_go_run_A_const_142 = A_arbace_go_run_A_const_pool.A[203]; A_arbace_go_run_A_const_143 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[204]); A_arbace_go_run_A_const_144 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[205]) }

func A_arbace_go_run_A_clinit_p12() { A_arbace_go_run_A_const_145 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[206]); A_arbace_go_run_A_const_146 = A_arbace_go_run_A_const_pool.A[207]; A_arbace_go_run_A_const_147 = A_arbace_go_run_A_const_pool.A[208]; A_arbace_go_run_A_const_148 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[209]); A_arbace_go_run_A_const_149 = A_arbace_go_run_A_const_pool.A[210]; A_arbace_go_run_A_const_150 = A_arbace_go_run_A_const_pool.A[211]; A_arbace_go_run_A_const_151 = A_arbace_go_run_A_const_pool.A[212]; A_arbace_go_run_A_const_152 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[213]); A_arbace_go_run_A_const_153 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[214]); A_arbace_go_run_A_const_154 = A_arbace_go_run_A_const_pool.A[215]; A_arbace_go_run_A_const_155 = A_arbace_go_run_A_const_pool.A[216]; A_arbace_go_run_A_const_156 = A_arbace_go_run_A_const_pool.A[217]; A_arbace_go_run_A_const_157 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[218]); A_arbace_go_run_A_const_158 = A_arbace_go_run_A_const_pool.A[219] }

func A_arbace_go_run_A_clinit_p13() { A_arbace_go_run_A_const_159 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[220]); A_arbace_go_run_A_const_160 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[221]); A_arbace_go_run_A_const_161 = A_arbace_go_run_A_const_pool.A[222]; A_arbace_go_run_A_const_162 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[223]); A_arbace_go_run_A_const_163 = A_arbace_go_run_A_const_pool.A[224]; A_arbace_go_run_A_const_164 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[225]); A_arbace_go_run_A_const_165 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[226]); A_arbace_go_run_A_const_166 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[227]); A_arbace_go_run_A_const_167 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[228]); A_arbace_go_run_A_const_168 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[229]); A_arbace_go_run_A_const_169 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[230]); A_arbace_go_run_A_const_170 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[231]) }

func A_arbace_go_run_A_clinit_p14() { A_arbace_go_run_A_const_171 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[232]); A_arbace_go_run_A_const_172 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[233]); A_arbace_go_run_A_const_173 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[234]); A_arbace_go_run_A_const_174 = A_arbace_go_run_A_const_pool.A[235]; A_arbace_go_run_A_const_175 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[236]); A_arbace_go_run_A_const_176 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[237]); A_arbace_go_run_A_const_177 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[238]) }

func A_arbace_go_run_A_New() *A_arbace_go_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_A) Ctor() {}

func (t *A_arbace_go_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_A_class }

func (t *A_arbace_go_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_A); return ok }

func A_arbace_go_run_A_Cast(x any) *A_arbace_go_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_A_class)) }; return v }



type A_arbace_go_run__main_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000219_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_run__main_fn__1938000219_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000222_A struct{ j2g_header uint64; F_lang, F_pf, F_root, F_opts any }

var A_arbace_go_run__main_fn__1938000222_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000227_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000227_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000229_A struct{ j2g_header uint64; F_pargs, F_pf, F_root any }

var A_arbace_go_run__main_fn__1938000229_A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__fn__1938000065_A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A struct{ j2g_header uint64; F_iter__1938000020, F_s__1938000021 any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A struct{ j2g_header uint64; F_b__1938000023 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_root_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_root_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000163_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000163_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000170_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000170_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000172_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000172_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000174_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000174_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000177_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000177_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000179_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000179_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A struct{ j2g_header uint64; F_s__1938000182, F_iter__1938000181 any }

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A struct{ j2g_header uint64; F_b__1938000184 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A struct{ j2g_header uint64; F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A struct{ j2g_header uint64; F_iter__1938000193, F_s__1938000194, F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A struct{ j2g_header uint64; F_b__1938000196 any; F_size__1927001038__auto__ int32; F_vmsg, F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_pos__1938000203_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_pos__1938000203_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_vmsg__1938000191_A struct{ j2g_header uint64; F_file_lang, F_lang, F_src any }

var A_arbace_go_run_errorcheck_vmsg__1938000191_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000004_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000004_A_New() *A_arbace_go_run_eval1938000004_A { t := &A_arbace_go_run_eval1938000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000004_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000004_A_class }

func (t *A_arbace_go_run_eval1938000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000004_A); return ok }

func A_arbace_go_run_eval1938000004_A_Cast(x any) *A_arbace_go_run_eval1938000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000004_A_class)) }; return v }



type A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000008_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000008_A_New() *A_arbace_go_run_eval1938000008_A { t := &A_arbace_go_run_eval1938000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000008_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000008_A_class }

func (t *A_arbace_go_run_eval1938000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000008_A); return ok }

func A_arbace_go_run_eval1938000008_A_Cast(x any) *A_arbace_go_run_eval1938000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000008_A_class)) }; return v }



type A_arbace_go_run_eval1938000008_fn__1938000009_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_fn_class *jrt.Class



type A_arbace_go_run_fail_A struct{ j2g_header uint64 }

var A_arbace_go_run_fail_A_fn_class *jrt.Class



type A_arbace_go_run_fail_fn__1938000012_A struct{ j2g_header uint64; F_kind, F_msg any }

var A_arbace_go_run_fail_fn__1938000012_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_A struct{ j2g_header uint64 }

var A_arbace_go_run_imports_of_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A struct{ j2g_header uint64; F_s__1938000069, F_iter__1938000068, F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A struct{ j2g_header uint64; F_s__1938000071, F_li, F_iter__1938000070 any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A struct{ j2g_header uint64; F_b__1938000073, F_li any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__fn__1938000032_A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class *jrt.Class



type A_arbace_go_run_no_linkname_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_linkname_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__fn__1938000016_A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000122_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000134_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_A struct{ j2g_header uint64; F_l, F_apos, F_end any }

var A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A struct{ j2g_header uint64; F_iter__1938000139, F_s__1938000140 any }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A struct{ j2g_header uint64; F_b__1938000142 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000129_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_walk_meta__1938000116_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class *jrt.Class



type A_arbace_go_run_run_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_A struct{ j2g_header uint64; F_srcs, F_inits, F_deps any }

var A_arbace_go_run_run_define__1938000091_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000092_A struct{ j2g_header uint64; F_src, F_r, F_st any }

var A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000094_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class *jrt.Class



type A_arbace_go_run_run_extra__1938000089_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_extra__1938000089_A_fn_class *jrt.Class



type A_arbace_go_run_run_fn__1938000087_A struct{ j2g_header uint64; F_pf any }

var A_arbace_go_run_run_fn__1938000087_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000097_A struct{ j2g_header uint64; F_inits, F_deps any }

var A_arbace_go_run_run_init_order__1938000097_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A struct{ j2g_header uint64; F_done, F_deps any }

var A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class *jrt.Class



type A_arbace_go_run_run_load_BANG___1938000101_A struct{ j2g_header uint64; F_root, F_extra, F_srcs, F_index, F_define any }

var A_arbace_go_run_run_load_BANG___1938000101_A_fn_class *jrt.Class
