//line aot_arbace_go_run.ae:1
package aot_arbace_go_run

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_New() *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_1); lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_go_run_A_const_3, A_arbace_go_run_A_const_4, A_arbace_go_run_A_const_5, A_arbace_go_run_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_50)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_51)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_run_eval1938000008_fn__1938000009_A_New() *A_arbace_go_run_eval1938000008_fn__1938000009_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000008_fn__1938000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_go_run_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_run_A_const_10.GetRawRoot__O(), A_arbace_go_run_A_const_11) }

















func A_arbace_go_run_fail_A_New() *A_arbace_go_run_fail_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_run_fail_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_run_fail_A) Invoke_O_O_O_O__O(self, status__0, kind__1, msg__2 any) any {
	var root_45 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_20; var arg_48 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_21.Get__O()); if linked_46 == nil { ifn_47.Invoke_O__O(arg_48) } else { linked_46.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_45, arg_48) }; var tmp3 any = A_arbace_go_run_fail_fn__1938000012_A_New_O_O(kind__1, msg__2); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_run_fail_fn__1938000012_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_run_fail_fn__1938000012_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__0)); return nil }
//line :20:1
func A_arbace_go_run_fail_fn__1938000012_A_New_O_O(p0, p1 any) *A_arbace_go_run_fail_fn__1938000012_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_fn__1938000012_A{}; t.Ctor_O_O(p0, p1); return t }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Ctor_O_O(c__kind, c__msg any) { t.F_kind = c__kind; t.F_msg = c__msg }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_53, nil, Lit_15, nil); var tmp4 any; var t_ any = t.F_kind; t.F_kind = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var root_32 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_36 any = A_arbace_go_run_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var root_40 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var t__2 any = t.F_msg; t.F_msg = nil; arg_43 = t__2; if linked_41 == nil { arg_39 = ifn_42.Invoke_O__O(arg_43) } else { arg_39 = linked_41.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_40, arg_43) }; if linked_37 == nil { arg_35 = ifn_38.Invoke_O__O(arg_39) } else { arg_35 = linked_37.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_36, arg_39) }; if linked_33 == nil { tmp6 = ifn_34.Invoke_O__O(arg_35) } else { tmp6 = linked_33.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_32, arg_35) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref())
											var root_22 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; if linked_23 == nil { tmp1 = ifn_24.Invoke__O() } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_22) } }
//line :20:1
	return nil }(); var root_25 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; if linked_26 == nil { ifn_27.Invoke__O() } else { linked_26.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_25) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_go_run_package_file_QMARK__A_New() *A_arbace_go_run_package_file_QMARK__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(f__0)).IsFile__Z(); if and__1927000168__auto____2 {
											var and__1927000168__auto____3 any; var root_54 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(); var arg_58 any = Lit_64; if linked_55 == nil { and__1927000168__auto____3 = ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { and__1927000168__auto____3 = linked_55.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_54, arg_57, arg_58) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var r__4 any = jrt.BufferedReader_New_Reader(jrt.FileReader_New_File(jrt.File_Cast(f__0))); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__7 any; var root_59 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_61 lang.IFn

		if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_63 any = A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var tmp2 any = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; arg_66 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_67 any; var root_78 any = A_arbace_go_run_A_const_26.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = r__4; if linked_79 == nil { arg_67 = ifn_80.Invoke_O__O(arg_81) } else { arg_67 = linked_79.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_78, arg_81) }; if linked_64 == nil { arg_62 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { arg_62 = linked_64.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if linked_60 == nil { l__7 = ifn_61.Invoke_O__O(arg_62) } else { l__7 = linked_60.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_59, arg_62) }
		var tmp4 any; var and__1927000168__auto____8 any = l__7; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_82 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = l__7; var arg_86 any = Lit_66; if linked_83 == nil { tmp4 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { tmp4 = linked_83.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_82, arg_85, arg_86) } } else { tmp4 = and__1927000168__auto____8 }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref() }; return nil }()
//line :27:1
		jrt.BufferedReader_Cast(r__4).Close__V()
//line :26:1
		if tmp5 != nil { panic(tmp5) }; return tmp1 } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New() *A_arbace_go_run_package_file_QMARK__fn__1938000016_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__fn__1938000016_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Ctor() {}
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Invoke_O_O__O(self, p1__1938000015_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_68 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = p1__1938000015_SHARP___1; if linked_69 == nil { or__1927000174__auto____2 = ifn_70.Invoke_O__O(arg_71) } else { or__1927000174__auto____2 = linked_69.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_72 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = p1__1938000015_SHARP___1; var arg_76 any = Lit_67; if linked_73 == nil { return ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { return linked_73.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_72, arg_75, arg_76) } } }


func A_arbace_go_run_dir_test_root_A_New() *A_arbace_go_run_dir_test_root_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_root_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Invoke_O_O__O(self, pf__0 any) any { { var n__2 any = jrt.NN(jrt.File_Cast(pf__0)).GetName__String().Ref(); var sib__3 any; var tmp1 *jrt.File = jrt.NN(jrt.File_Cast(pf__0)).GetParentFile__File(); var tmp2 any; var root_87 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_89 lang.IFn




	if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = n__2; var arg_91 any = A_arbace_go_run_A_const_28; var arg_92 any = Lit_22; if linked_88 == nil { tmp2 = ifn_89.Invoke_O_O_O__O(arg_90, arg_91, arg_92) } else { tmp2 = linked_88.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_87, arg_90, arg_91, arg_92) }
//line :31:1
	sib__3 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2))





	var tmp3 any; var and__1927000168__auto____4 any; var root_93 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = n__2; var arg_97 any = Lit_23; if linked_94 == nil { and__1927000168__auto____4 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { and__1927000168__auto____4 = linked_94.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(sib__3)).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { return sib__3 } else { var d__4 any = jrt.NN(jrt.File_Cast(pf__0)).GetParentFile__File().Ref(); L1: for {


		if lang.Util_Identical_O_O__Z_NoInit(d__4, nil) { return nil } else { var tmp4 any; var root_98 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_100 lang.IFn

			if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = jrt.NN(jrt.File_Cast(d__4)).GetName__String().Ref(); var arg_102 any = Lit_24; if linked_99 == nil { tmp4 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { tmp4 = linked_99.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }
//line :40:1
			if jrt.J2g_Truth(tmp4) { return d__4 } else { if A_arbace_go_run_A_const_29 != nil {


				d__4 = jrt.NN(jrt.File_Cast(d__4)).GetParentFile__File().Ref(); continue L1 } else {
//line :40:1
					return nil } } } } } }; /*line :31:1*/panic("j2g: unreachable") }













func A_arbace_go_run_dir_test_index_A_New() *A_arbace_go_run_dir_test_index_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Ctor() {}
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Invoke_O_O__O(self, pf__0 any) any { var temp__1927000408__auto____2 any; var root_103 any = A_arbace_go_run_A_const_30.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, A_arbace_go_run_dir_test_root_A_fn_class); var ifn_105 lang.IFn; if



	linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = pf__0; if linked_104 == nil { temp__1927000408__auto____2 = ifn_105.Invoke_O__O(arg_106) } else { temp__1927000408__auto____2 = linked_104.(*A_arbace_go_run_dir_test_root_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var root_107 any = A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_109 lang.IFn
		if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_111 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New(); var tmp2 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class
		if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class = fncls__194d; tmp2 = fncls__194d } else { tmp2 = fncls__194 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_195 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = pf__0; var arg_199 any; var root_200 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = d__3; if linked_201 == nil { arg_199 = ifn_202.Invoke_O__O(arg_203) } else { arg_199 = linked_201.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_200, arg_203) }; if linked_196 == nil { tmp4 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { tmp4 = linked_196.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }; arg_111 = tmp3.Invoke_O__O(tmp4)
//line :50:1
		if linked_108 == nil { return ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { return linked_108.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } } else {
//line :49:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }

func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New() *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Invoke_O_O__O(self, s__1938000021__1 any) any { var tmp1 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(self, s__1938000021__1); var tmp2 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class = fncls__193d; tmp2 = fncls__193d } else { tmp2 = fncls__193 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(p0, p1 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Ctor_O_O(c__iter__1938000020, c__s__1938000021 any) { t.F_iter__1938000020 = c__iter__1938000020; t.F_s__1938000021 = c__s__1938000021 }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Invoke_O__O(self any) any { { var s__1938000021__1 any; var t_ any = t.F_s__1938000021; t.F_s__1938000021 = nil; s__1938000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_112 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = s__1938000021__1; if linked_113 == nil { temp__1927000414__auto____2 = ifn_114.Invoke_O__O(arg_115) } else { temp__1927000414__auto____2 = linked_113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_116 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__1938000021__3; if linked_117 == nil { tmp1 = ifn_118.Invoke_O__O(arg_119) } else { tmp1 = linked_117.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_120 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__1938000021__3; if linked_121 == nil { c__1927001037__auto____4 = ifn_122.Invoke_O__O(arg_123) } else { c__1927001037__auto____4 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_120, arg_123) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000023__6 any; var root_124 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_125 == nil { b__1938000023__6 = ifn_126.Invoke_O__O(arg_127) } else { b__1938000023__6 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_124, arg_127) }; var tmp2 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(b__1938000023__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_142 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_147 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = b__1938000023__6; if linked_148 == nil { arg_145 = ifn_149.Invoke_O__O(arg_150) } else { arg_145 = linked_148.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_147, arg_150) }; var arg_146 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp5 any; var root_151 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__1938000021__3; if linked_152 == nil { tmp5 = ifn_153.Invoke_O__O(arg_154) } else { tmp5 = linked_152.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_151, arg_154) }; arg_146 = tmp4.Invoke_O__O(tmp5); if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } } else { var root_155 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_160 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = b__1938000023__6; if linked_161 == nil { arg_158 = ifn_162.Invoke_O__O(arg_163) } else { arg_158 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_160, arg_163) }; var arg_159 any; if linked_156 == nil { return ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { return linked_156.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) } } } else { var f__4 any; var root_164 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__1938000021__3; if linked_165 == nil { f__4 = ifn_166.Invoke_O__O(arg_167) } else { f__4 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; var tmp6 any; var root_168 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_170 lang.IFn
															if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = f__4; if linked_169 == nil { tmp6 = ifn_170.Invoke_O__O(arg_171) } else { tmp6 = linked_169.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_168, arg_171) }
//line :51:1
	if jrt.J2g_Truth(tmp6) { var p__5 any; var root_172 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_174 lang.IFn

		if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = f__4; if linked_173 == nil { p__5 = ifn_174.Invoke_O__O(arg_175) } else { p__5 = linked_173.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_172, arg_175) }
//line :51:1
		if jrt.J2g_Truth(p__5) { var root_176 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = lang.Tuple_Create_O_O__IPersistentVector(p__5, f__4); var arg_180 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp8 any; var root_181 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = s__1938000021__3; if linked_182 == nil { tmp8 = ifn_183.Invoke_O__O(arg_184) } else { tmp8 = linked_182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_181, arg_184) }; arg_180 = tmp7.Invoke_O__O(tmp8); if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) } } else { var tmp9 any; var root_185 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = s__1938000021__3; if linked_186 == nil { tmp9 = ifn_187.Invoke_O__O(arg_188) } else { tmp9 = linked_186.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_185, arg_188) }; s__1938000021__1 = tmp9; continue L1 } } else { var tmp10 any; var root_189 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__1938000021__3; if linked_190 == nil { tmp10 = ifn_191.Invoke_O__O(arg_192) } else { tmp10 = linked_190.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_189, arg_192) }; s__1938000021__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Ctor_O_I_O(c__b__1938000023 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000023 = c__b__1938000023; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Invoke_O__O(self any) any { { var i__1938000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000022__1)); var tmp2 any; var root_128 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_130 lang.IFn
																if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = f__2; if linked_129 == nil { tmp2 = ifn_130.Invoke_O__O(arg_131) } else { tmp2 = linked_129.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_128, arg_131) }
//line :51:1
	if jrt.J2g_Truth(tmp2) { var p__3 any; var root_132 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_134 lang.IFn

		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__2; if linked_133 == nil { p__3 = ifn_134.Invoke_O__O(arg_135) } else { p__3 = linked_133.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_132, arg_135) }
//line :51:1
		if jrt.J2g_Truth(p__3) { var root_136 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t.F_b__1938000023; var arg_140 any = lang.Tuple_Create_O_O__IPersistentVector(p__3, f__2); if linked_137 == nil { ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { linked_137.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_run_no_assembly_BANG__A_New() *A_arbace_go_run_no_assembly_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Ctor() {}
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Invoke_O_O__O(self, src__0 any) any { var temp__1927000414__auto____2 any; var root_204 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_206 lang.IFn; if
											linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var tmp1 any = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New(); var tmp2 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class = fncls__218d; tmp2 = fncls__218d } else { tmp2 = fncls__218 }; arg_207 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_208 any; var root_219 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = src__0; var arg_223 any = A_arbace_go_run_A_const_47; if linked_220 == nil { arg_208 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { arg_208 = linked_220.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; if linked_205 == nil { temp__1927000414__auto____2 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { temp__1927000414__auto____2 = linked_205.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; var root_224 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_run_fail_A_fn_class); var ifn_226 lang.IFn
												if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = A_arbace_go_run_A_const_49; var arg_228 any = Lit_14; var arg_229 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, s__3, nil)).Ref(); if linked_225 == nil { return ifn_226.Invoke_O_O_O__O(arg_227, arg_228, arg_229) } else { return linked_225.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_224, arg_227, arg_228, arg_229) } } else {
//line :59:1
			return nil } }
//line :59:1
func A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New() *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Ctor() {}
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Invoke_O_O__O(self, p1__1938000031_SHARP___1 any) any { var tmp1 any; var root_209 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var root_214 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = p1__1938000031_SHARP___1; if linked_215 == nil { arg_212 = ifn_216.Invoke_O__O(arg_217) } else { arg_212 = linked_215.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_214, arg_217) }; var arg_213 any = Lit_62; if linked_210 == nil { tmp1 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp1 = linked_210.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(tmp1) { return p1__1938000031_SHARP___1 } else { return nil } }


func A_arbace_go_run_no_linkname_BANG__A_New() *A_arbace_go_run_no_linkname_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_linkname_BANG__A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Ctor() {}
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Invoke_O_O__O(self, src__0 any) any { { var seq_1938000035__2 any; var root_230 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_232 lang.IFn
											if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__0); if linked_231 == nil { seq_1938000035__2 = ifn_232.Invoke_O__O(arg_233) } else { seq_1938000035__2 = linked_231.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_230, arg_233) }
//line :62:1
	var chunk_1938000036__3 any; var count_1938000037__4 int64 = 0; var i_1938000038__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000038__5, count_1938000037__4) { var fi__6 any = lang.Indexed_Cast(chunk_1938000036__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000038__5)); var seq_1938000051__7 any; var root_250 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__6); if linked_251 == nil { seq_1938000051__7 = ifn_252.Invoke_O__O(arg_253) } else { seq_1938000051__7 = linked_251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_250, arg_253) }; var chunk_1938000052__8 any; var count_1938000053__9 int64 = 0; var i_1938000054__10 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000054__10, count_1938000053__9) { var d__11 any = lang.Indexed_Cast(chunk_1938000052__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000054__10)); var seq_1938000059__12 any; var root_270 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any; var root_274 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_276 lang.IFn
			if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_278 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_279 any = d__11; if linked_275 == nil { arg_273 = ifn_276.Invoke_O_O_O__O(arg_277, arg_278, arg_279) } else { arg_273 = linked_275.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_274, arg_277, arg_278, arg_279) }
//line :63:1
			if linked_271 == nil { seq_1938000059__12 = ifn_272.Invoke_O__O(arg_273) } else { seq_1938000059__12 = linked_271.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_270, arg_273) }; var chunk_1938000060__13 any; var count_1938000061__14 int64 = 0; var i_1938000062__15 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000062__15, count_1938000061__14) { var x__16 any = lang.Indexed_Cast(chunk_1938000060__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000062__15)); var tmp1 any; var and__1927000168__auto____17 bool = lang.IObj_InstanceOf(x__16)

				if and__1927000168__auto____17 { var tmp2 *lang.Keyword = A_arbace_go_run_A_const_55; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() }
//line :63:1
				if jrt.J2g_Truth(tmp1) {


					var root_296 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_go_run_fail_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = A_arbace_go_run_A_const_49; var arg_300 any = Lit_14; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_301 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)), nil)).Ref(); if linked_297 == nil { ifn_298.Invoke_O_O_O__O(arg_299, arg_300, arg_301) } else { linked_297.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_296, arg_299, arg_300, arg_301) }
//line :63:1
					seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } else { seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } } else { var temp__1927000414__auto____16 any; var root_280 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = seq_1938000059__12; if linked_281 == nil { temp__1927000414__auto____16 = ifn_282.Invoke_O__O(arg_283) } else { temp__1927000414__auto____16 = linked_281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_280, arg_283) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1938000059__17 any = temp__1927000414__auto____16; var tmp4 any; var root_284 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = seq_1938000059__17; if linked_285 == nil { tmp4 = ifn_286.Invoke_O__O(arg_287) } else { tmp4 = linked_285.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_284, arg_287) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_288 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = seq_1938000059__17; if linked_289 == nil { c__1927000678__auto____18 = ifn_290.Invoke_O__O(arg_291) } else { c__1927000678__auto____18 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_288, arg_291) }; var tmp5 any; var root_302 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = seq_1938000059__17; if linked_303 == nil { tmp5 = ifn_304.Invoke_O__O(arg_305) } else { tmp5 = linked_303.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_302, arg_305) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var x__18 any; var root_292 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1938000059__17; if linked_293 == nil { x__18 = ifn_294.Invoke_O__O(arg_295) } else { x__18 = linked_293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_292, arg_295) }; var tmp6 any; var and__1927000168__auto____19 bool = lang.IObj_InstanceOf(x__18)

						if and__1927000168__auto____19 { var tmp7 *lang.Keyword = A_arbace_go_run_A_const_55; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }
//line :63:1
						if jrt.J2g_Truth(tmp6) {


							var root_306 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, A_arbace_go_run_fail_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = A_arbace_go_run_A_const_49; var arg_310 any = Lit_14; var tmp8 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_311 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)), nil)).Ref(); if linked_307 == nil { ifn_308.Invoke_O_O_O__O(arg_309, arg_310, arg_311) } else { linked_307.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_306, arg_309, arg_310, arg_311) }
//line :63:1
							var tmp9 any; var root_312 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = seq_1938000059__17; if linked_313 == nil { tmp9 = ifn_314.Invoke_O__O(arg_315) } else { tmp9 = linked_313.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_312, arg_315) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp9, nil, 0, 0; continue L3 } else { var tmp10 any; var root_316 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1938000059__17; if linked_317 == nil { tmp10 = ifn_318.Invoke_O__O(arg_319) } else { tmp10 = linked_317.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_316, arg_319) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp10, nil, 0, 0; continue L3 } } } }; break L3 }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000054__10); continue L2 } else { var temp__1927000414__auto____11 any; var root_254 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1938000051__7; if linked_255 == nil { temp__1927000414__auto____11 = ifn_256.Invoke_O__O(arg_257) } else { temp__1927000414__auto____11 = linked_255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1938000051__12 any = temp__1927000414__auto____11; var tmp11 any; var root_258 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1938000051__12; if linked_259 == nil { tmp11 = ifn_260.Invoke_O__O(arg_261) } else { tmp11 = linked_259.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_262 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = seq_1938000051__12; if linked_263 == nil { c__1927000678__auto____13 = ifn_264.Invoke_O__O(arg_265) } else { c__1927000678__auto____13 = linked_263.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_262, arg_265) }; var tmp12 any; var root_320 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1938000051__12; if linked_321 == nil { tmp12 = ifn_322.Invoke_O__O(arg_323) } else { tmp12 = linked_321.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_320, arg_323) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__13 any; var root_266 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = seq_1938000051__12; if linked_267 == nil { d__13 = ifn_268.Invoke_O__O(arg_269) } else { d__13 = linked_267.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_266, arg_269) }; var seq_1938000055__14 any; var root_324 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_328 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_330 lang.IFn
								if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_332 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_333 any = d__13; if linked_329 == nil { arg_327 = ifn_330.Invoke_O_O_O__O(arg_331, arg_332, arg_333) } else { arg_327 = linked_329.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_328, arg_331, arg_332, arg_333) }
//line :63:1
								if linked_325 == nil { seq_1938000055__14 = ifn_326.Invoke_O__O(arg_327) } else { seq_1938000055__14 = linked_325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_324, arg_327) }; var chunk_1938000056__15 any; var count_1938000057__16 int64 = 0; var i_1938000058__17 int64 = 0; L4: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000058__17, count_1938000057__16) { var x__18_2 any = lang.Indexed_Cast(chunk_1938000056__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000058__17)); var tmp13 any; var and__1927000168__auto____19_2 bool = lang.IObj_InstanceOf(x__18_2)

									if and__1927000168__auto____19_2 { var tmp14 *lang.Keyword = A_arbace_go_run_A_const_55; tmp13 = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_2).Ref() }
//line :63:1
									if jrt.J2g_Truth(tmp13) {


										var root_350 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_run_fail_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = A_arbace_go_run_A_const_49; var arg_354 any = Lit_14; var tmp15 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_355 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp15.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)), nil)).Ref(); if linked_351 == nil { ifn_352.Invoke_O_O_O__O(arg_353, arg_354, arg_355) } else { linked_351.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_350, arg_353, arg_354, arg_355) }
//line :63:1
										seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } else { seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } } else { var temp__1927000414__auto____18 any; var root_334 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = seq_1938000055__14; if linked_335 == nil { temp__1927000414__auto____18 = ifn_336.Invoke_O__O(arg_337) } else { temp__1927000414__auto____18 = linked_335.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000055__19 any = temp__1927000414__auto____18; var tmp16 any; var root_338 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = seq_1938000055__19; if linked_339 == nil { tmp16 = ifn_340.Invoke_O__O(arg_341) } else { tmp16 = linked_339.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____20 any; var root_342 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = seq_1938000055__19; if linked_343 == nil { c__1927000678__auto____20 = ifn_344.Invoke_O__O(arg_345) } else { c__1927000678__auto____20 = linked_343.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_342, arg_345) }; var tmp17 any; var root_356 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = seq_1938000055__19; if linked_357 == nil { tmp17 = ifn_358.Invoke_O__O(arg_359) } else { tmp17 = linked_357.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_356, arg_359) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp17, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__20 any; var root_346 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = seq_1938000055__19; if linked_347 == nil { x__20 = ifn_348.Invoke_O__O(arg_349) } else { x__20 = linked_347.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_346, arg_349) }; var tmp18 any; var and__1927000168__auto____21 bool = lang.IObj_InstanceOf(x__20)

											if and__1927000168__auto____21 { var tmp19 *lang.Keyword = A_arbace_go_run_A_const_55; tmp18 = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)) } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }
//line :63:1
											if jrt.J2g_Truth(tmp18) {


												var root_360 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, A_arbace_go_run_fail_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = A_arbace_go_run_A_const_49; var arg_364 any = Lit_14; var tmp20 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_365 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)), nil)).Ref(); if linked_361 == nil { ifn_362.Invoke_O_O_O__O(arg_363, arg_364, arg_365) } else { linked_361.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_360, arg_363, arg_364, arg_365) }
//line :63:1
												var tmp21 any; var root_366 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = seq_1938000055__19; if linked_367 == nil { tmp21 = ifn_368.Invoke_O__O(arg_369) } else { tmp21 = linked_367.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_366, arg_369) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp21, nil, 0, 0; continue L4 } else { var tmp22 any; var root_370 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = seq_1938000055__19; if linked_371 == nil { tmp22 = ifn_372.Invoke_O__O(arg_373) } else { tmp22 = linked_371.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_370, arg_373) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp22, nil, 0, 0; continue L4 } } } }; break L4 }; var tmp23 any; var root_374 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1938000051__12; if linked_375 == nil { tmp23 = ifn_376.Invoke_O__O(arg_377) } else { tmp23 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp23, nil, 0, 0; continue L2 } } }; break L2 }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000038__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_234 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = seq_1938000035__2; if linked_235 == nil { temp__1927000414__auto____6 = ifn_236.Invoke_O__O(arg_237) } else { temp__1927000414__auto____6 = linked_235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1938000035__7 any = temp__1927000414__auto____6; var tmp24 any; var root_238 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = seq_1938000035__7; if linked_239 == nil { tmp24 = ifn_240.Invoke_O__O(arg_241) } else { tmp24 = linked_239.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____8 any; var root_242 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = seq_1938000035__7; if linked_243 == nil { c__1927000678__auto____8 = ifn_244.Invoke_O__O(arg_245) } else { c__1927000678__auto____8 = linked_243.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_242, arg_245) }; var tmp25 any; var root_378 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = seq_1938000035__7; if linked_379 == nil { tmp25 = ifn_380.Invoke_O__O(arg_381) } else { tmp25 = linked_379.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_378, arg_381) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp25, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__8 any; var root_246 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1938000035__7; if linked_247 == nil { fi__8 = ifn_248.Invoke_O__O(arg_249) } else { fi__8 = linked_247.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_246, arg_249) }; var seq_1938000039__9 any; var root_382 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__8); if linked_383 == nil { seq_1938000039__9 = ifn_384.Invoke_O__O(arg_385) } else { seq_1938000039__9 = linked_383.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_382, arg_385) }; var chunk_1938000040__10 any; var count_1938000041__11 int64 = 0; var i_1938000042__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000042__12, count_1938000041__11) { var d__13_2 any = lang.Indexed_Cast(chunk_1938000040__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000042__12)); var seq_1938000047__14 any; var root_402 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_406 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_408 lang.IFn
													if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_410 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_411 any = d__13_2; if linked_407 == nil { arg_405 = ifn_408.Invoke_O_O_O__O(arg_409, arg_410, arg_411) } else { arg_405 = linked_407.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_406, arg_409, arg_410, arg_411) }
//line :63:1
													if linked_403 == nil { seq_1938000047__14 = ifn_404.Invoke_O__O(arg_405) } else { seq_1938000047__14 = linked_403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_402, arg_405) }; var chunk_1938000048__15 any; var count_1938000049__16 int64 = 0; var i_1938000050__17 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000050__17, count_1938000049__16) { var x__18_3 any = lang.Indexed_Cast(chunk_1938000048__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000050__17)); var tmp26 any; var and__1927000168__auto____19_3 bool = lang.IObj_InstanceOf(x__18_3)

														if and__1927000168__auto____19_3 { var tmp27 *lang.Keyword = A_arbace_go_run_A_const_55; tmp26 = tmp27.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)) } else { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_3).Ref() }
//line :63:1
														if jrt.J2g_Truth(tmp26) {


															var root_428 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, A_arbace_go_run_fail_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = A_arbace_go_run_A_const_49; var arg_432 any = Lit_14; var tmp28 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_433 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp28.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)), nil)).Ref(); if linked_429 == nil { ifn_430.Invoke_O_O_O__O(arg_431, arg_432, arg_433) } else { linked_429.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_428, arg_431, arg_432, arg_433) }
//line :63:1
															seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } else { seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } } else { var temp__1927000414__auto____18_2 any; var root_412 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = seq_1938000047__14; if linked_413 == nil { temp__1927000414__auto____18_2 = ifn_414.Invoke_O__O(arg_415) } else { temp__1927000414__auto____18_2 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1938000047__19 any = temp__1927000414__auto____18_2; var tmp29 any; var root_416 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = seq_1938000047__19; if linked_417 == nil { tmp29 = ifn_418.Invoke_O__O(arg_419) } else { tmp29 = linked_417.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_416, arg_419) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____20_2 any; var root_420 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = seq_1938000047__19; if linked_421 == nil { c__1927000678__auto____20_2 = ifn_422.Invoke_O__O(arg_423) } else { c__1927000678__auto____20_2 = linked_421.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_420, arg_423) }; var tmp30 any; var root_434 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1938000047__19; if linked_435 == nil { tmp30 = ifn_436.Invoke_O__O(arg_437) } else { tmp30 = linked_435.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_434, arg_437) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp30, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__20_2 any; var root_424 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = seq_1938000047__19; if linked_425 == nil { x__20_2 = ifn_426.Invoke_O__O(arg_427) } else { x__20_2 = linked_425.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_424, arg_427) }; var tmp31 any; var and__1927000168__auto____21_2 bool = lang.IObj_InstanceOf(x__20_2)

																if and__1927000168__auto____21_2 { var tmp32 *lang.Keyword = A_arbace_go_run_A_const_55; tmp31 = tmp32.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }
//line :63:1
																if jrt.J2g_Truth(tmp31) {


																	var root_438 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_go_run_fail_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_go_run_A_const_49; var arg_442 any = Lit_14; var tmp33 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_443 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp33.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)), nil)).Ref(); if linked_439 == nil { ifn_440.Invoke_O_O_O__O(arg_441, arg_442, arg_443) } else { linked_439.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_438, arg_441, arg_442, arg_443) }
//line :63:1
																	var tmp34 any; var root_444 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = seq_1938000047__19; if linked_445 == nil { tmp34 = ifn_446.Invoke_O__O(arg_447) } else { tmp34 = linked_445.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_444, arg_447) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp34, nil, 0, 0; continue L6 } else { var tmp35 any; var root_448 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = seq_1938000047__19; if linked_449 == nil { tmp35 = ifn_450.Invoke_O__O(arg_451) } else { tmp35 = linked_449.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_448, arg_451) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp35, nil, 0, 0; continue L6 } } } }; break L6 }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000042__12); continue L5 } else { var temp__1927000414__auto____13 any; var root_386 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = seq_1938000039__9; if linked_387 == nil { temp__1927000414__auto____13 = ifn_388.Invoke_O__O(arg_389) } else { temp__1927000414__auto____13 = linked_387.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1938000039__14 any = temp__1927000414__auto____13; var tmp36 any; var root_390 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = seq_1938000039__14; if linked_391 == nil { tmp36 = ifn_392.Invoke_O__O(arg_393) } else { tmp36 = linked_391.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_390, arg_393) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____15 any; var root_394 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_1938000039__14; if linked_395 == nil { c__1927000678__auto____15 = ifn_396.Invoke_O__O(arg_397) } else { c__1927000678__auto____15 = linked_395.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_394, arg_397) }; var tmp37 any; var root_452 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1938000039__14; if linked_453 == nil { tmp37 = ifn_454.Invoke_O__O(arg_455) } else { tmp37 = linked_453.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_452, arg_455) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp37, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var d__15 any; var root_398 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_1938000039__14; if linked_399 == nil { d__15 = ifn_400.Invoke_O__O(arg_401) } else { d__15 = linked_399.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_398, arg_401) }; var seq_1938000043__16 any; var root_456 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var root_460 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_462 lang.IFn
																		if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_464 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_465 any = d__15; if linked_461 == nil { arg_459 = ifn_462.Invoke_O_O_O__O(arg_463, arg_464, arg_465) } else { arg_459 = linked_461.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_460, arg_463, arg_464, arg_465) }
//line :63:1
																		if linked_457 == nil { seq_1938000043__16 = ifn_458.Invoke_O__O(arg_459) } else { seq_1938000043__16 = linked_457.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_456, arg_459) }; var chunk_1938000044__17 any; var count_1938000045__18 int64 = 0; var i_1938000046__19 int64 = 0; L7: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000046__19, count_1938000045__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1938000044__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000046__19)); var tmp38 any; var and__1927000168__auto____21_3 bool = lang.IObj_InstanceOf(x__20_3)

																			if and__1927000168__auto____21_3 { var tmp39 *lang.Keyword = A_arbace_go_run_A_const_55; tmp38 = tmp39.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)) } else { tmp38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_3).Ref() }
//line :63:1
																			if jrt.J2g_Truth(tmp38) {


																				var root_482 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_go_run_fail_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = A_arbace_go_run_A_const_49; var arg_486 any = Lit_14; var tmp40 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_487 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp40.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)), nil)).Ref(); if linked_483 == nil { ifn_484.Invoke_O_O_O__O(arg_485, arg_486, arg_487) } else { linked_483.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_482, arg_485, arg_486, arg_487) }
//line :63:1
																				seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } else { seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } } else { var temp__1927000414__auto____20 any; var root_466 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1938000043__16; if linked_467 == nil { temp__1927000414__auto____20 = ifn_468.Invoke_O__O(arg_469) } else { temp__1927000414__auto____20 = linked_467.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_466, arg_469) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1938000043__21 any = temp__1927000414__auto____20; var tmp41 any; var root_470 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = seq_1938000043__21; if linked_471 == nil { tmp41 = ifn_472.Invoke_O__O(arg_473) } else { tmp41 = linked_471.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_470, arg_473) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____22 any; var root_474 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = seq_1938000043__21; if linked_475 == nil { c__1927000678__auto____22 = ifn_476.Invoke_O__O(arg_477) } else { c__1927000678__auto____22 = linked_475.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_474, arg_477) }; var tmp42 any; var root_488 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = seq_1938000043__21; if linked_489 == nil { tmp42 = ifn_490.Invoke_O__O(arg_491) } else { tmp42 = linked_489.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_488, arg_491) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp42, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22 any; var root_478 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = seq_1938000043__21; if linked_479 == nil { x__22 = ifn_480.Invoke_O__O(arg_481) } else { x__22 = linked_479.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_478, arg_481) }; var tmp43 any; var and__1927000168__auto____23 bool = lang.IObj_InstanceOf(x__22)

																					if and__1927000168__auto____23 { var tmp44 *lang.Keyword = A_arbace_go_run_A_const_55; tmp43 = tmp44.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)) } else { tmp43 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }
//line :63:1
																					if jrt.J2g_Truth(tmp43) {


																						var root_492 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, A_arbace_go_run_fail_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = A_arbace_go_run_A_const_49; var arg_496 any = Lit_14; var tmp45 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_497 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_15, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)), nil)).Ref(); if linked_493 == nil { ifn_494.Invoke_O_O_O__O(arg_495, arg_496, arg_497) } else { linked_493.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_492, arg_495, arg_496, arg_497) }
//line :63:1
																						var tmp46 any; var root_498 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1938000043__21; if linked_499 == nil { tmp46 = ifn_500.Invoke_O__O(arg_501) } else { tmp46 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp46, nil, 0, 0; continue L7 } else { var tmp47 any; var root_502 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = seq_1938000043__21; if linked_503 == nil { tmp47 = ifn_504.Invoke_O__O(arg_505) } else { tmp47 = linked_503.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_502, arg_505) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp47, nil, 0, 0; continue L7 } } } }; break L7 }; var tmp48 any; var root_506 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = seq_1938000039__14; if linked_507 == nil { tmp48 = ifn_508.Invoke_O__O(arg_509) } else { tmp48 = linked_507.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_506, arg_509) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp48, nil, 0, 0; continue L5 } } }; break L5 }; var tmp49 any; var root_510 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = seq_1938000035__7; if linked_511 == nil { tmp49 = ifn_512.Invoke_O__O(arg_513) } else { tmp49 = linked_511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_510, arg_513) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp49, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :62:1*/panic("j2g: unreachable") }





func A_arbace_go_run_check_BANG__A_New() *A_arbace_go_run_check_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Ctor() {}
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Invoke_O_O_O__O(self, src__0, extra__1 any) any {
	var root_519 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = src__0; if linked_520 == nil { ifn_521.Invoke_O__O(arg_522) } else { linked_520.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_519, arg_522) }
	var root_523 any = A_arbace_go_run_A_const_60.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_go_run_no_linkname_BANG__A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = src__0; if linked_524 == nil { ifn_525.Invoke_O__O(arg_526) } else { linked_524.(*A_arbace_go_run_no_linkname_BANG__A).Invoke_O_O__O(root_523, arg_526) }
//line :68:1
	var r__3 any; var root_514 any = A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_516 lang.IFn


	if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = src__0; var arg_518 any = extra__1; if linked_515 == nil { r__3 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { r__3 = linked_515.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }
//line :68:1
	var errs__4 any = A_arbace_go_run_A_const_58.Invoke_O__O(r__3); var temp__1927000414__auto____5 any; var root_527 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_529 lang.IFn




	if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var tmp1 any = A_arbace_go_run_check_BANG__fn__1938000065_A_New(); var tmp2 *jrt.Class; var fncls__532 *jrt.Class = A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class; if fncls__532 == nil { var fncls__532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class = fncls__532d; tmp2 = fncls__532d } else { tmp2 = fncls__532 }; arg_530 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_531 any = errs__4; if linked_528 == nil { temp__1927000414__auto____5 = ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { temp__1927000414__auto____5 = linked_528.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var bi__6 any = temp__1927000414__auto____5; var root_533 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_go_run_fail_A_fn_class); var ifn_535 lang.IFn
		if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = A_arbace_go_run_A_const_49; var arg_537 any = Lit_14; var arg_538 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_63.Invoke_O__O(bi__6))).Ref(); if linked_534 == nil { ifn_535.Invoke_O_O_O__O(arg_536, arg_537, arg_538) } else { linked_534.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_533, arg_536, arg_537, arg_538) } }
	var tmp3 any; var root_539 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = errs__4; if linked_540 == nil { tmp3 = ifn_541.Invoke_O__O(arg_542) } else { tmp3 = linked_540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_539, arg_542) }; if jrt.J2g_Truth(tmp3) {
		var root_543 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_go_run_fail_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = A_arbace_go_run_A_const_64; var arg_547 any = Lit_4; var arg_548 any; var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp5 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__0); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_65; var tmp7 any; var root_549 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = errs__4; if linked_550 == nil { tmp7 = ifn_551.Invoke_O__O(arg_552) } else { tmp7 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Keyword = A_arbace_go_run_A_const_66; var tmp10 any; var root_553 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = errs__4; if linked_554 == nil { tmp10 = ifn_555.Invoke_O__O(arg_556) } else { tmp10 = linked_554.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_553, arg_556) }; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Keyword = A_arbace_go_run_A_const_63; var tmp13 any; var root_557 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = errs__4; if linked_558 == nil { tmp13 = ifn_559.Invoke_O__O(arg_560) } else { tmp13 = linked_558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_557, arg_560) }; arg_548 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp8, nil, tmp11, nil, tmp12.Invoke_O__O(tmp13))).Ref(); if linked_544 == nil { ifn_545.Invoke_O_O_O__O(arg_546, arg_547, arg_548) } else { linked_544.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_543, arg_546, arg_547, arg_548) } }
//line :68:1
	return r__3
}



func A_arbace_go_run_check_BANG__fn__1938000065_A_New() *A_arbace_go_run_check_BANG__fn__1938000065_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__fn__1938000065_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Ctor() {}
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Invoke_O_O__O(self, p1__1938000064_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_61; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000064_SHARP___1)) { return p1__1938000064_SHARP___1 } else { return nil } }





func A_arbace_go_run_imports_of_A_New() *A_arbace_go_run_imports_of_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Invoke_O_O__O(self, src__0 any) any { var li__2 any; var root_561 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_563 lang.IFn; if


	linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = src__0; var arg_565 any = A_arbace_go_run_A_const_67; if linked_562 == nil { li__2 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { li__2 = linked_562.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; var root_566 any =
	A_arbace_go_run_A_const_68.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(li__2); var tmp2 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class; if
	fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class = fncls__688d; tmp2 = fncls__688d } else { tmp2 = fncls__688 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_569 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_run_A_const_51.Invoke_O__O(src__0)); if /*line :83:1*/ linked_567 == nil { return ifn_568.Invoke_O__O(arg_569) } else { return linked_567.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_566, arg_569) } }
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Invoke_O_O__O(self, s__1938000069__1 any) any { var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(s__1938000069__1, self, t.F_li); var tmp2 *jrt.Class; var fncls__687 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class; if fncls__687 == nil { var fncls__687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class = fncls__687d; tmp2 = fncls__687d } else { tmp2 = fncls__687 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Ctor_O_O_O(c__s__1938000069, c__iter__1938000068, c__li any) { t.F_s__1938000069 = c__s__1938000069; t.F_iter__1938000068 = c__iter__1938000068; t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Invoke_O__O(self any) any { { var s__1938000069__1 any; var t_ any = t.F_s__1938000069; t.F_s__1938000069 = nil; s__1938000069__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = s__1938000069__1; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O__O(arg_573) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_570, arg_573) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var fi__4 any; var root_574 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = xs__1927001018__auto____3; if linked_575 == nil { fi__4 = ifn_576.Invoke_O__O(arg_577) } else { fi__4 = linked_575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_574, arg_577) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(t.F_li); var tmp2 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class = fncls__664d; tmp2 = fncls__664d } else { tmp2 = fncls__664 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_665 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_669 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_671 lang.IFn
														if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = fi__4; var arg_673 any = A_arbace_go_run_A_const_72; if linked_670 == nil { tmp4 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp4 = linked_670.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }
//line :84:1
	arg_668 = tmp3.Invoke_O__O(tmp4); if linked_666 == nil { fs__1927001036__auto____6 = ifn_667.Invoke_O__O(arg_668) } else { fs__1927001036__auto____6 = linked_666.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_665, arg_668) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_674 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = fs__1927001036__auto____6; var arg_678 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1938000068); var tmp6 any; var root_679 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__1938000069__1; if linked_680 == nil { tmp6 = ifn_681.Invoke_O__O(arg_682) } else { tmp6 = linked_680.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_679, arg_682) }; arg_678 = tmp5.Invoke_O__O(tmp6); if linked_675 == nil { return ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { return linked_675.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) } } else { var tmp7 any; var root_683 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = s__1938000069__1; if linked_684 == nil { tmp7 = ifn_685.Invoke_O__O(arg_686) } else { tmp7 = linked_684.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_683, arg_686) }; s__1938000069__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Invoke_O_O__O(self, s__1938000071__1 any) any { var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(s__1938000071__1, t.F_li, self); var tmp2 *jrt.Class; var fncls__663 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class; if fncls__663 == nil { var fncls__663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class = fncls__663d; tmp2 = fncls__663d } else { tmp2 = fncls__663 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Ctor_O_O_O(c__s__1938000071, c__li, c__iter__1938000070 any) { t.F_s__1938000071 = c__s__1938000071; t.F_li = c__li; t.F_iter__1938000070 = c__iter__1938000070 }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Invoke_O__O(self any) any { { var s__1938000071__1 any; var t_ any = t.F_s__1938000071; t.F_s__1938000071 = nil; s__1938000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_578 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = s__1938000071__1; if linked_579 == nil { temp__1927000414__auto____2 = ifn_580.Invoke_O__O(arg_581) } else { temp__1927000414__auto____2 = linked_579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_582 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = s__1938000071__3; if linked_583 == nil { tmp1 = ifn_584.Invoke_O__O(arg_585) } else { tmp1 = linked_583.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_582, arg_585) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_586 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = s__1938000071__3; if linked_587 == nil { c__1927001037__auto____4 = ifn_588.Invoke_O__O(arg_589) } else { c__1927001037__auto____4 = linked_587.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_586, arg_589) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000073__6 any; var root_590 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_591 == nil { b__1938000073__6 = ifn_592.Invoke_O__O(arg_593) } else { b__1938000073__6 = linked_591.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_590, arg_593) }; var tmp2 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(b__1938000073__6, t.F_li, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__611 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class; if fncls__611 == nil { var fncls__611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class = fncls__611d; tmp3 = fncls__611d } else { tmp3 = fncls__611 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_612 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var root_617 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = b__1938000073__6; if linked_618 == nil { arg_615 = ifn_619.Invoke_O__O(arg_620) } else { arg_615 = linked_618.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_617, arg_620) }; var arg_616 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp5 any; var root_621 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = s__1938000071__3; if linked_622 == nil { tmp5 = ifn_623.Invoke_O__O(arg_624) } else { tmp5 = linked_622.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_621, arg_624) }; arg_616 = tmp4.Invoke_O__O(tmp5); if linked_613 == nil { return ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { return linked_613.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) } } else { var root_625 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var root_630 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = b__1938000073__6; if linked_631 == nil { arg_628 = ifn_632.Invoke_O__O(arg_633) } else { arg_628 = linked_631.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_630, arg_633) }; var arg_629 any; if linked_626 == nil { return ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { return linked_626.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) } } } else { var spec__4 any; var root_634 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = s__1938000071__3; if linked_635 == nil { spec__4 = ifn_636.Invoke_O__O(arg_637) } else { spec__4 = linked_635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_634, arg_637) }; var p__5 any; var tmp6 any; var root_638 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_640 lang.IFn

	if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = spec__4; if linked_639 == nil { tmp6 = ifn_640.Invoke_O__O(arg_641) } else { tmp6 = linked_639.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_638, arg_641) }; if jrt.J2g_Truth(tmp6) { var root_642 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = spec__4; if linked_643 == nil { p__5 = ifn_644.Invoke_O__O(arg_645) } else { p__5 = linked_643.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_642, arg_645) } } else { p__5 = spec__4 }
//line :84:1
	var tmp7 any; var root_646 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_648 lang.IFn


	if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = p__5; if linked_647 == nil { tmp7 = ifn_648.Invoke_O__O(arg_649) } else { tmp7 = linked_647.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_646, arg_649) }
//line :84:1
	if jrt.J2g_Truth(tmp7) { var root_650 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__5, p__5); var arg_654 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp9 any; var root_655 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = s__1938000071__3; if linked_656 == nil { tmp9 = ifn_657.Invoke_O__O(arg_658) } else { tmp9 = linked_656.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_655, arg_658) }; arg_654 = tmp8.Invoke_O__O(tmp9); if linked_651 == nil { return ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { return linked_651.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) } } else { var tmp10 any; var root_659 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = s__1938000071__3; if linked_660 == nil { tmp10 = ifn_661.Invoke_O__O(arg_662) } else { tmp10 = linked_660.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_659, arg_662) }; s__1938000071__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Ctor_O_O_I_O(c__b__1938000073, c__li any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000073 = c__b__1938000073; t.F_li = c__li; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Invoke_O__O(self any) any { { var i__1938000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000072__1)); var p__3 any; var tmp2 any; var root_594 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_596 lang.IFn

	if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = spec__2; if linked_595 == nil { tmp2 = ifn_596.Invoke_O__O(arg_597) } else { tmp2 = linked_595.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(tmp2) { var root_598 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = spec__2; if linked_599 == nil { p__3 = ifn_600.Invoke_O__O(arg_601) } else { p__3 = linked_599.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_598, arg_601) } } else { p__3 = spec__2 }
//line :84:1
	var tmp3 any; var root_602 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_604 lang.IFn


	if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = p__3; if linked_603 == nil { tmp3 = ifn_604.Invoke_O__O(arg_605) } else { tmp3 = linked_603.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_602, arg_605) }
//line :84:1
	if jrt.J2g_Truth(tmp3) { var root_606 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = t.F_b__1938000073; var arg_610 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__3, p__3); if linked_607 == nil { ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { linked_607.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) }; i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } else { i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_run_A_New() *A_arbace_go_run_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_run_run_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_run_run_A) Invoke_O_O_O_O__O(self, root__0, pf__1, args__2 any) any {




	var root_922 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var arg_926 any = jrt.Boolean_TRUE.Ref(); if linked_923 == nil { ifn_924.Invoke_O_O__O(arg_925, arg_926) } else { linked_923.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_922, arg_925, arg_926)
	}
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_110.GetRawRoot__O()); var tmp2 any; var root_932 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any; var root_937 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = jrt.NN(jrt.File_Cast(pf__1)).GetName__String().Ref(); if linked_938 == nil { arg_935 = ifn_939.Invoke_O__O(arg_940) } else { arg_935 = linked_938.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_937, arg_940) }; var arg_936 any = args__2; if linked_933 == nil { tmp2 = ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { tmp2 = linked_933.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_932, arg_935, arg_936) }; tmp1.Invoke_O_O__O(Lit_77, lang.RT_Object_array_O__O1_NoInit(tmp2).Ref())
//line :90:1
	var src__4 any; var root_689 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_691 lang.IFn







	if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, root__0)); var arg_693 any; var arg_694 any; var root_696 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_697 == nil { arg_694 = ifn_698.Invoke_O__O(arg_699) } else { arg_694 = linked_697.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_696, arg_699) }; var arg_695 any = pf__1; if linked_690 == nil { src__4 = ifn_691.Invoke_O_O_O_O__O(arg_692, arg_693, arg_694, arg_695) } else { src__4 = linked_690.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_689, arg_692, arg_693, arg_694, arg_695) }
//line :90:1
	var ___5 any; var tmp3 any; var root_700 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_702 lang.IFn; _ = ___5








	if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__4); if linked_701 == nil { tmp3 = ifn_702.Invoke_O__O(arg_703) } else { tmp3 = linked_701.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_700, arg_703) }; if jrt.J2g_Truth(tmp3) { var root_704 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, A_arbace_go_run_fail_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = A_arbace_go_run_A_const_49; var arg_708 any = Lit_14; var arg_709 any = Lit_26; if linked_705 == nil { ___5 = ifn_706.Invoke_O_O_O__O(arg_707, arg_708, arg_709) } else { ___5 = linked_705.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_704, arg_707, arg_708, arg_709) } } else { ___5 = nil }
//line :90:1
	var index__6 any; var tmp4 any = A_arbace_go_run_run_fn__1938000087_A_New_O(pf__1); var tmp5 *jrt.Class
	var fncls__714 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_fn__1938000087_A_fn_class









	if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_run_run_fn__1938000087_A_fn_class = fncls__714d; tmp5 = fncls__714d } else { tmp5 = fncls__714 }
//line :90:1
	index__6 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); var srcs__7 any; var root_715 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_717 lang.IFn










	if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_716 == nil { srcs__7 = ifn_717.Invoke_O__O(arg_718) } else { srcs__7 = linked_716.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_715, arg_718) }
//line :90:1
	var inits__8 any; var root_719 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_721 lang.IFn











	if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_720 == nil { inits__8 = ifn_721.Invoke_O__O(arg_722) } else { inits__8 = linked_720.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_719, arg_722) }
//line :90:1
	var deps__9 any; var root_723 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_725 lang.IFn












	if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_724 == nil { deps__9 = ifn_725.Invoke_O__O(arg_726) } else { deps__9 = linked_724.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_723, arg_726) }
//line :90:1
	var extra__10 any; var tmp6 any = A_arbace_go_run_run_extra__1938000089_A_New_O(srcs__7); var tmp7 *jrt.Class
	var fncls__731 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_extra__1938000089_A_fn_class













	if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_run_run_extra__1938000089_A_fn_class = fncls__731d; tmp7 = fncls__731d } else { tmp7 = fncls__731 }; extra__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :90:1
	var define__11 any; var tmp8 any = A_arbace_go_run_run_define__1938000091_A_New_O_O_O(srcs__7, inits__8, deps__9); var tmp9 *jrt.Class
	var fncls__808 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_define__1938000091_A_fn_class














	if fncls__808 == nil { var fncls__808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_go_run_run_define__1938000091_A_fn_class = fncls__808d; tmp9 = fncls__808d } else { tmp9 = fncls__808 }; define__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :90:1
	var init_order__12 any; var tmp10 any = A_arbace_go_run_run_init_order__1938000097_A_New_O_O(inits__8, deps__9); var tmp11 *jrt.Class
	var fncls__878 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_init_order__1938000097_A_fn_class




























	if fncls__878 == nil { var fncls__878d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_go_run_run_init_order__1938000097_A_fn_class = fncls__878d; tmp11 = fncls__878d } else { tmp11 = fncls__878 }; init_order__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :90:1
	var body_load_BANG___13 *A_arbace_go_run_run_load_BANG___1938000101_A = A_arbace_go_run_run_load_BANG___1938000101_A_New_O_O_O_O_O(root__0, extra__10, srcs__7, index__6, define__11); var load_BANG___13 any; var tmp12 *jrt.Class; var fncls__1037 *jrt.Class = A_arbace_go_run_run_load_BANG___1938000101_A_fn_class; if fncls__1037 == nil { var fncls__1037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_go_run_run_load_BANG___1938000101_A_fn_class = fncls__1037d; tmp12 = fncls__1037d } else { tmp12 = fncls__1037 }; load_BANG___13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_load_BANG___13), tmp12, nil); var seq_1938000107__14 any; var root_1038 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1040 lang.IFn












































	if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any; var root_1042 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_run_imports_of_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = src__4; if linked_1043 == nil { arg_1041 = ifn_1044.Invoke_O__O(arg_1045) } else { arg_1041 = linked_1043.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1042, arg_1045) }; if linked_1039 == nil { seq_1938000107__14 = ifn_1040.Invoke_O__O(arg_1041) } else { seq_1938000107__14 = linked_1039.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1038, arg_1041) }
//line :90:1
	var chunk_1938000108__15 any; var count_1938000109__16 int64 = 0; var i_1938000110__17 int64 = 0; L1: for {












































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000110__17, count_1938000109__16) { var p__18 any = lang.Indexed_Cast(chunk_1938000108__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000110__17)); lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__18, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000110__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1046 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = seq_1938000107__14; if linked_1047 == nil { temp__1927000414__auto____18 = ifn_1048.Invoke_O__O(arg_1049) } else { temp__1927000414__auto____18 = linked_1047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1046, arg_1049) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000107__19 any = temp__1927000414__auto____18; var tmp13 any; var root_1050 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = seq_1938000107__19; if linked_1051 == nil { tmp13 = ifn_1052.Invoke_O__O(arg_1053) } else { tmp13 = linked_1051.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1050, arg_1053) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____20 any; var root_1054 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = seq_1938000107__19; if linked_1055 == nil { c__1927000678__auto____20 = ifn_1056.Invoke_O__O(arg_1057) } else { c__1927000678__auto____20 = linked_1055.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1054, arg_1057) }; var tmp14 any; var root_1062 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = seq_1938000107__19; if linked_1063 == nil { tmp14 = ifn_1064.Invoke_O__O(arg_1065) } else { tmp14 = linked_1063.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1062, arg_1065) }; seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = tmp14, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__20 any; var root_1058 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = seq_1938000107__19; if linked_1059 == nil { p__20 = ifn_1060.Invoke_O__O(arg_1061) } else { p__20 = linked_1059.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1058, arg_1061) }; lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__20, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); var tmp15 any; var root_1066 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = seq_1938000107__19; if linked_1067 == nil { tmp15 = ifn_1068.Invoke_O__O(arg_1069) } else { tmp15 = linked_1067.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1066, arg_1069) }; seq_1938000107__14, chunk_1938000108__15, count_1938000109__16, i_1938000110__17 = tmp15, nil, 0, 0; continue L1 } } }
//line :90:1
		break L1 }; var r__13 any; var root_879 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, A_arbace_go_run_check_BANG__A_fn_class); var ifn_881 lang.IFn













































	if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = src__4; var arg_883 any = extra__10; if linked_880 == nil { r__13 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { r__13 = linked_880.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }
//line :90:1
	var ___14 any; var root_884 any = A_arbace_go_run_A_const_94.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_886 lang.IFn; _ = ___14














































	if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = srcs__7; var arg_888 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var arg_889 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__4); var arg_890 any = src__4; if linked_885 == nil { ___14 = ifn_886.Invoke_O_O_O_O__O(arg_887, arg_888, arg_889, arg_890) } else { ___14 = linked_885.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_884, arg_887, arg_888, arg_889, arg_890) }
//line :90:1
	var map__1938000111__15 any = lang.IFn_Cast(define__11).Invoke_O_O__O(src__4, r__13); var map__1938000111__16 any













































	if lang.ISeq_InstanceOf(map__1938000111__15) { var tmp16 any; var root_891 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = map__1938000111__15; if linked_892 == nil { tmp16 = ifn_893.Invoke_O__O(arg_894) } else { tmp16 = linked_892.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_891, arg_894) }; if jrt.J2g_Truth(tmp16) { var tmp17 any; var root_895 any = A_arbace_go_run_A_const_108.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = map__1938000111__15; if linked_896 == nil { tmp17 = ifn_897.Invoke_O__O(arg_898) } else { tmp17 = linked_896.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_895, arg_898) }; map__1938000111__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp17)).Ref() } else { var tmp18 any; var root_899 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = map__1938000111__15; if linked_900 == nil { tmp18 = ifn_901.Invoke_O__O(arg_902) } else { tmp18 = linked_900.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_899, arg_902) }; if jrt.J2g_Truth(tmp18) { var root_903 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = map__1938000111__15; if linked_904 == nil { map__1938000111__16 = ifn_905.Invoke_O__O(arg_906) } else { map__1938000111__16 = linked_904.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_903, arg_906) } } else { map__1938000111__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1938000111__16 = map__1938000111__15 }
//line :90:1
	var main__17 any = lang.RT_Get_O_O__O_NoInit(map__1938000111__16, A_arbace_go_run_A_const_109)
















































	if jrt.J2g_Truth(main__17) { } else {
		var root_1070 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, A_arbace_go_run_fail_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = A_arbace_go_run_A_const_64; var arg_1074 any = Lit_4; var arg_1075 any = Lit_83; if linked_1071 == nil { ifn_1072.Invoke_O_O_O__O(arg_1073, arg_1074, arg_1075) } else { linked_1071.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1070, arg_1073, arg_1074, arg_1075) } }
	var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_110.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_111.GetRawRoot__O()); var tmp21 any; var root_918 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = inits__8; if linked_919 == nil { tmp21 = ifn_920.Invoke_O__O(arg_921) } else { tmp21 = linked_919.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_918, arg_921) }; return tmp19.Invoke_O_O_O__O(Lit_84, lang.RT_Object_array_O__O1_NoInit(tmp20.Invoke_O_O__O(tmp21, lang.IFn_Cast(init_order__12).Invoke__O())).Ref(), main__17) }
//line :100:1
func A_arbace_go_run_run_fn__1938000087_A_New_O(p0 any) *A_arbace_go_run_run_fn__1938000087_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_fn__1938000087_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Ctor_O(c__pf any) { t.F_pf = c__pf }
//line :100:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Invoke_O__O(self any) any { var root_710 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_go_run_dir_test_index_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any; var t_ any = t.F_pf; t.F_pf = nil; arg_713 = t_; if linked_711 == nil { return ifn_712.Invoke_O__O(arg_713) } else { return linked_711.(*A_arbace_go_run_dir_test_index_A).Invoke_O_O__O(root_710, arg_713) } }



func A_arbace_go_run_run_extra__1938000089_A_New_O(p0 any) *A_arbace_go_run_run_extra__1938000089_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_extra__1938000089_A{}; t.Ctor_O(p0); return t }
//line :104:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :104:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_727 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = t.F_srcs; if linked_728 == nil { tmp1 = ifn_729.Invoke_O__O(arg_730) } else { tmp1 = linked_728.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_727, arg_730) }; return lang.RT_Get_O_O__O_NoInit(tmp1, path__1) }
func A_arbace_go_run_run_define__1938000091_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :105:1
func (t *A_arbace_go_run_run_define__1938000091_A) Ctor_O_O_O(c__srcs, c__inits, c__deps any) { t.F_srcs = c__srcs; t.F_inits = c__inits; t.F_deps = c__deps }
//line :105:1
func (t *A_arbace_go_run_run_define__1938000091_A) Invoke_O_O_O__O(self, src__1, r__2 any) any { var st__3 any; var root_732 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_734 lang.IFn; if
												linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any; var tmp1 any = A_arbace_go_run_A_const_50; var tmp2 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var tmp3 any = A_arbace_go_run_A_const_81; var tmp4 any = A_arbace_go_run_A_const_81.Invoke_O__O(src__1); var tmp5 any = A_arbace_go_run_A_const_82; var tmp6 any; var root_736 any = A_arbace_go_run_A_const_83.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_85, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_81.Invoke_O__O(src__1))).Ref(); if linked_737 == nil { tmp6 = ifn_738.Invoke_O__O(arg_739) } else { tmp6 = linked_737.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_736, arg_739) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_run_A_const_84; var tmp9 any = A_arbace_go_run_A_const_84.Invoke_O__O(src__1); var tmp10 any = A_arbace_go_run_A_const_85; var tmp11 any = A_arbace_go_run_A_const_85.Invoke_O__O(src__1); var tmp12 any = A_arbace_go_run_A_const_86; arg_735 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, A_arbace_go_run_A_const_86.Invoke_O__O(src__1), A_arbace_go_run_A_const_51, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_run_A_const_87, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_88, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_89, lang.PersistentArrayMap_EMPTY.Ref())); if linked_733 == nil { st__3 = ifn_734.Invoke_O__O(arg_735) } else { st__3 = linked_733.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_732, arg_735) }; var root_761 any =

	A_arbace_go_run_A_const_94.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var arg_765 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var arg_766 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_767 any = st__3; if linked_762 == nil { ifn_763.Invoke_O_O_O_O__O(arg_764, arg_765, arg_766, arg_767) } else { linked_762.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_761, arg_764, arg_765, arg_766, arg_767) }; var d__4 any; var tmp13 any = /*line :105:1*/A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O_O_O(src__1, r__2, st__3); var tmp14 *jrt.Class; var fncls__760 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class; if



	fncls__760 == nil { var fncls__760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class = fncls__760d; tmp14 = fncls__760d } else { tmp14 = fncls__760 }; d__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O(); var tmp15 /*line :115:1*/*lang.Volatile = lang.Volatile_Cast(t.F_inits); var tmp16 any; var root_768 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = jrt.NN(lang.Volatile_Cast(t.F_inits)).Deref__O(); var arg_772 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_773 any; var root_774 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = A_arbace_go_run_A_const_97.Invoke_O__O(d__4); var arg_778 any = A_arbace_go_run_A_const_98.Invoke_O__O(d__4); if linked_775 == nil { arg_773 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { arg_773 = linked_775.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) }; if linked_769 == nil { tmp16 = ifn_770.Invoke_O_O_O__O(arg_771, arg_772, arg_773) } else { tmp16 = linked_769.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_768, arg_771, arg_772, arg_773) }; jrt.NN(tmp15).Reset_O__O(tmp16); var tmp17 /*line :116:1*/*lang.Volatile = lang.Volatile_Cast(t.F_deps); var tmp18 any; var root_779 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = jrt.NN(lang.Volatile_Cast(t.F_deps)).Deref__O(); var arg_783 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_784 any; var root_785 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; var root_789 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var tmp19 any = A_arbace_go_run_run_define__1938000091_fn__1938000094_A_New_O(t.F_srcs); var tmp20 *jrt.Class; var fncls__803 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class; if fncls__803 == nil { var fncls__803d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class = fncls__803d; tmp20 = fncls__803d } else { tmp20 = fncls__803 }; arg_792 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_793 any; var root_804 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, A_arbace_go_run_imports_of_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = src__1; if linked_805 == nil { arg_793 = ifn_806.Invoke_O__O(arg_807) } else { arg_793 = linked_805.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_804, arg_807) }; if linked_790 == nil { arg_788 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { arg_788 = linked_790.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }; if linked_786 == nil { arg_784 = ifn_787.Invoke_O__O(arg_788) } else { arg_784 = linked_786.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_785, arg_788) }; if linked_780 == nil { tmp18 = ifn_781.Invoke_O_O_O__O(arg_782, arg_783, arg_784) } else { tmp18 = linked_780.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_779, arg_782, arg_783, arg_784) }; jrt.NN(tmp17).Reset_O__O(tmp18); return d__4 }
//line :109:1
func A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_fn__1938000092_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Ctor_O_O_O(c__src, c__r, c__st any) { t.F_src = c__src; t.F_r = c__r; t.F_st = c__st }
//line :109:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_740 any = A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var t_ any = t.F_st; t.F_st = nil; arg_743 = t_; var arg_744 any; var t__2 any = t.F_r; t.F_r = nil; arg_744 = t__2; var arg_745 any = A_arbace_go_run_A_const_91; if linked_741 == nil { tmp1 = ifn_742.Invoke_O_O_O__O(arg_743, arg_744, arg_745) } else { tmp1 = linked_741.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_740, arg_743, arg_744, arg_745) } }; return nil }(); if tmp2 != nil { if lang.ExceptionInfo_InstanceOf(tmp2) { var ex__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp2); var temp__1927000408__auto____4 any; var root_746 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_748 lang.IFn


	if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_92; var tmp4 any; var root_750 any = A_arbace_go_run_A_const_93.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = ex__3; if linked_751 == nil { tmp4 = ifn_752.Invoke_O__O(arg_753) } else { tmp4 = linked_751.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_750, arg_753) }; arg_749 = tmp3.Invoke_O__O(tmp4); if linked_747 == nil { temp__1927000408__auto____4 = ifn_748.Invoke_O__O(arg_749) } else { temp__1927000408__auto____4 = linked_747.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_746, arg_749) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var er__5 any = temp__1927000408__auto____4; var root_754 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_go_run_fail_A_fn_class); var ifn_756 lang.IFn
		if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = A_arbace_go_run_A_const_64; var arg_758 any = Lit_4; var arg_759 any; var tmp5 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_50; var tmp7 any; var t__3 any = t.F_src; t.F_src = nil; tmp7 = t__3; arg_759 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O__O(tmp7), nil, A_arbace_go_run_A_const_65.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_66.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_63.Invoke_O__O(er__5))).Ref(); if linked_755 == nil { tmp1 = ifn_756.Invoke_O_O_O__O(arg_757, arg_758, arg_759) } else { tmp1 = linked_755.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_754, arg_757, arg_758, arg_759) } } else {
//line :112:1
			panic(jrt.Thrown(ex__3)) } } else {
//line :109:1
				panic(tmp2) } }; return tmp1 }






func A_arbace_go_run_run_define__1938000091_fn__1938000094_A_New_O(p0 any) *A_arbace_go_run_run_define__1938000091_fn__1938000094_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000094_A{}; t.Ctor_O(p0); return t }
//line :116:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000094_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :116:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000094_A) Invoke_O_O__O(self, p1__1938000085_SHARP___1 any) any { var root_794 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any; var root_799 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = t.F_srcs; if linked_800 == nil { arg_797 = ifn_801.Invoke_O__O(arg_802) } else { arg_797 = linked_800.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_799, arg_802) }; var arg_798 any = p1__1938000085_SHARP___1; if linked_795 == nil { return ifn_796.Invoke_O_O__O(arg_797, arg_798) } else { return linked_795.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_794, arg_797, arg_798) } }


func A_arbace_go_run_run_init_order__1938000097_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000097_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :119:1
func (t *A_arbace_go_run_run_init_order__1938000097_A) Ctor_O_O(c__inits, c__deps any) { t.F_inits = c__inits; t.F_deps = c__deps }
//line :119:1
func (t *A_arbace_go_run_run_init_order__1938000097_A) Invoke_O__O(self any) any { { var done__1 any = lang.PersistentVector_EMPTY.Ref(); var left__2 any; var root_809 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_811 lang.IFn
											if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_813 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any; var root_817 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = t.F_inits; if linked_818 == nil { arg_816 = ifn_819.Invoke_O__O(arg_820) } else { arg_816 = linked_818.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_817, arg_820) }; if linked_814 == nil { arg_812 = ifn_815.Invoke_O__O(arg_816) } else { arg_812 = linked_814.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_813, arg_816) }; if linked_810 == nil { left__2 = ifn_811.Invoke_O__O(arg_812) } else { left__2 = linked_810.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_809, arg_812) }
//line :119:1
L1: for {

	var tmp1 any; var root_821 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = left__2; if linked_822 == nil { tmp1 = ifn_823.Invoke_O__O(arg_824) } else { tmp1 = linked_822.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_821, arg_824) }; if jrt.J2g_Truth(tmp1) { return done__1 } else { var p__3 any; var root_825 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_827 lang.IFn

		if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any; var root_829 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var root_833 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any; var tmp2 any = A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_New_O_O(done__1, t.F_deps); var tmp3 *jrt.Class; var fncls__851 *jrt.Class = A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class; if fncls__851 == nil { var fncls__851d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class = fncls__851d; tmp3 = fncls__851d } else { tmp3 = fncls__851 }; arg_836 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_837 any = left__2; if linked_834 == nil { arg_832 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { arg_832 = linked_834.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }; if linked_830 == nil { arg_828 = ifn_831.Invoke_O__O(arg_832) } else { arg_828 = linked_830.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_829, arg_832) }; if linked_826 == nil { p__3 = ifn_827.Invoke_O__O(arg_828) } else { p__3 = linked_826.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_825, arg_828) }
		var tmp4 any; var root_852 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = done__1; var arg_856 any; var or__1927000174__auto____4 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_856 = or__1927000174__auto____4 } else { var root_857 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = left__2; if linked_862 == nil { arg_860 = ifn_863.Invoke_O__O(arg_864) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_861, arg_864) }; if linked_858 == nil { arg_856 = ifn_859.Invoke_O__O(arg_860) } else { arg_856 = linked_858.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_857, arg_860) } }; if linked_853 == nil { tmp4 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { tmp4 = linked_853.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; var tmp5 any = tmp4; var tmp6 any; var root_865 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = left__2; var arg_869 any; var or__1927000174__auto____4_2 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4_2) { arg_869 = or__1927000174__auto____4_2 } else { var root_870 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var root_874 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = left__2; if linked_875 == nil { arg_873 = ifn_876.Invoke_O__O(arg_877) } else { arg_873 = linked_875.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_874, arg_877) }; if linked_871 == nil { arg_869 = ifn_872.Invoke_O__O(arg_873) } else { arg_869 = linked_871.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_870, arg_873) } }; if linked_866 == nil { tmp6 = ifn_867.Invoke_O_O__O(arg_868, arg_869) } else { tmp6 = linked_866.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_865, arg_868, arg_869) }; done__1, left__2 = tmp5, tmp6; continue L1 } } }; /*line :119:1*/panic("j2g: unreachable") }



func A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A{}; t.Ctor_O_O(p0, p1); return t }
//line :123:1
func (t *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A) Ctor_O_O(c__done, c__deps any) { t.F_done = c__done; t.F_deps = c__deps }
//line :123:1
func (t *A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A) Invoke_O_O__O(self, p1__1938000086_SHARP___1 any) any { var root_838 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any; var root_843 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = t.F_done; if linked_844 == nil { arg_841 = ifn_845.Invoke_O__O(arg_846) } else { arg_841 = linked_844.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_843, arg_846) }; var arg_842 any; var tmp1 any; var root_847 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = t.F_deps; if linked_848 == nil { tmp1 = ifn_849.Invoke_O__O(arg_850) } else { tmp1 = linked_848.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_847, arg_850) }; arg_842 = lang.RT_Get_O_O__O_NoInit(tmp1, p1__1938000086_SHARP___1); if linked_839 == nil { return ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { return linked_839.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_838, arg_841, arg_842) } }


func A_arbace_go_run_run_load_BANG___1938000101_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_run_run_load_BANG___1938000101_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_load_BANG___1938000101_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :126:1
func (t *A_arbace_go_run_run_load_BANG___1938000101_A) Ctor_O_O_O_O_O(c__root, c__extra, c__srcs, c__index, c__define any) { t.F_root = c__root; t.F_extra = c__extra; t.F_srcs = c__srcs; t.F_index = c__index; t.F_define = c__define }
//line :126:1
func (t *A_arbace_go_run_run_load_BANG___1938000101_A) Invoke_O_O_O__O(self, path__1, seen__2 any) any {
	var tmp1 any; var or__1927000174__auto____3 any; var root_941 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any; var root_946 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = t.F_srcs; if linked_947 == nil { arg_944 = ifn_948.Invoke_O__O(arg_949) } else { arg_944 = linked_947.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_946, arg_949) }; var arg_945 any = path__1; if linked_942 == nil { or__1927000174__auto____3 = ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { or__1927000174__auto____3 = linked_942.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_941, arg_944, arg_945) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_950 any = A_arbace_go_run_A_const_114.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = path__1; if linked_951 == nil { or__1927000174__auto____4 = ifn_952.Invoke_O__O(arg_953) } else { or__1927000174__auto____4 = linked_951.(*aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_950, arg_953) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_954 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = seen__2; var arg_958 any = path__1; if linked_955 == nil { tmp1 = ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { tmp1 = linked_955.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_954, arg_957, arg_958) } } }; if jrt.J2g_Truth(tmp1) { return nil } else { var temp__1927000414__auto____3 any; var tmp2 any; var root_959 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_961 lang.IFn
		if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = t.F_index; if linked_960 == nil { tmp2 = ifn_961.Invoke_O__O(arg_962) } else { tmp2 = linked_960.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_959, arg_962) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, path__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var f__4 any = temp__1927000414__auto____3; var s__5 any; var root_963 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_965 lang.IFn
			if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, t.F_root)); var arg_967 any = path__1; var arg_968 any; var root_970 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_972 lang.IFn; if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_971 == nil { arg_968 = ifn_972.Invoke_O__O(arg_973) } else { arg_968 = linked_971.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_970, arg_973) }; var arg_969 any = f__4; if linked_964 == nil { s__5 = ifn_965.Invoke_O_O_O_O__O(arg_966, arg_967, arg_968, arg_969) } else { s__5 = linked_964.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_963, arg_966, arg_967, arg_968, arg_969) }
//line :128:1
			var seq_1938000102__6 any; var root_988 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_990 lang.IFn

			if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var root_992 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_go_run_imports_of_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = s__5; if linked_993 == nil { arg_991 = ifn_994.Invoke_O__O(arg_995) } else { arg_991 = linked_993.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_992, arg_995) }; if linked_989 == nil { seq_1938000102__6 = ifn_990.Invoke_O__O(arg_991) } else { seq_1938000102__6 = linked_989.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_988, arg_991) }
//line :128:1
			var chunk_1938000103__7 any; var count_1938000104__8 int64 = 0; var i_1938000105__9 int64 = 0; L1: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000105__9, count_1938000104__8) { var p__10 any = lang.Indexed_Cast(chunk_1938000103__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000105__9)); var tmp3 lang.IFn = lang.IFn_Cast(self); var tmp4 any; var root_1012 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = seen__2; var arg_1016 any = path__1; if linked_1013 == nil { tmp4 = ifn_1014.Invoke_O_O__O(arg_1015, arg_1016) } else { tmp4 = linked_1013.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1012, arg_1015, arg_1016) }; tmp3.Invoke_O_O__O(p__10, tmp4); seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000105__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_996 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = seq_1938000102__6; if linked_997 == nil { temp__1927000414__auto____10 = ifn_998.Invoke_O__O(arg_999) } else { temp__1927000414__auto____10 = linked_997.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_996, arg_999) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1938000102__11 any = temp__1927000414__auto____10; var tmp5 any; var root_1000 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = seq_1938000102__11; if linked_1001 == nil { tmp5 = ifn_1002.Invoke_O__O(arg_1003) } else { tmp5 = linked_1001.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1000, arg_1003) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_1004 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = seq_1938000102__11; if linked_1005 == nil { c__1927000678__auto____12 = ifn_1006.Invoke_O__O(arg_1007) } else { c__1927000678__auto____12 = linked_1005.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1004, arg_1007) }; var tmp6 any; var root_1017 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = seq_1938000102__11; if linked_1018 == nil { tmp6 = ifn_1019.Invoke_O__O(arg_1020) } else { tmp6 = linked_1018.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1017, arg_1020) }; seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__12 any; var root_1008 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = seq_1938000102__11; if linked_1009 == nil { p__12 = ifn_1010.Invoke_O__O(arg_1011) } else { p__12 = linked_1009.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1008, arg_1011) }; var tmp7 lang.IFn = lang.IFn_Cast(self); var tmp8 any; var root_1021 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = seen__2; var arg_1025 any = path__1; if linked_1022 == nil { tmp8 = ifn_1023.Invoke_O_O__O(arg_1024, arg_1025) } else { tmp8 = linked_1022.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1021, arg_1024, arg_1025) }; tmp7.Invoke_O_O__O(p__12, tmp8); var tmp9 any; var root_1026 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = seq_1938000102__11; if linked_1027 == nil { tmp9 = ifn_1028.Invoke_O__O(arg_1029) } else { tmp9 = linked_1027.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1026, arg_1029) }; seq_1938000102__6, chunk_1938000103__7, count_1938000104__8, i_1938000105__9 = tmp9, nil, 0, 0; continue L1 } } }
//line :128:1
				break L1
			}

			var tmp10 any; var root_974 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any; var root_979 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = t.F_srcs; if linked_980 == nil { arg_977 = ifn_981.Invoke_O__O(arg_982) } else { arg_977 = linked_980.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_979, arg_982) }; var arg_978 any = path__1; if linked_975 == nil { tmp10 = ifn_976.Invoke_O_O__O(arg_977, arg_978) } else { tmp10 = linked_975.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_974, arg_977, arg_978) }; if jrt.J2g_Truth(tmp10) { return nil } else { var r__6 any; var root_983 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, A_arbace_go_run_check_BANG__A_fn_class); var ifn_985 lang.IFn
				if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = s__5; var arg_987 any = t.F_extra; if linked_984 == nil { r__6 = ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { r__6 = linked_984.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_983, arg_986, arg_987) }
				var root_1030 any = A_arbace_go_run_A_const_94.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = t.F_srcs; var arg_1034 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var arg_1035 any = path__1; var arg_1036 any = s__5; if linked_1031 == nil { ifn_1032.Invoke_O_O_O_O__O(arg_1033, arg_1034, arg_1035, arg_1036) } else { linked_1031.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1030, arg_1033, arg_1034, arg_1035, arg_1036) }
				return lang.IFn_Cast(t.F_define).Invoke_O_O__O(s__5, r__6) } } else {
//line :128:1
					return nil
				}
	}
}











func A_arbace_go_run_raw_lines_A_New() *A_arbace_go_run_raw_lines_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_go_run_raw_lines_A) Ctor() {}
//line :143:1
func (t *A_arbace_go_run_raw_lines_A) Invoke_O_O__O(self, x__0 any) any { var walk_meta__2 any; var tmp1 any = A_arbace_go_run_raw_lines_walk_meta__1938000116_A_New(); var tmp2 *jrt.Class; var fncls__1087 *jrt.Class = A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class; if






	fncls__1087 == nil { var fncls__1087d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class = fncls__1087d; tmp2 = fncls__1087d } else { tmp2 = fncls__1087 }; walk_meta__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var x_SINGLEQUOTE___3 any; var tmp3 any; var root_1088 any = /*line :143:1*/A_arbace_go_run_A_const_118.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1090 lang.IFn; if








	linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = x__0; if linked_1089 == nil { tmp3 = ifn_1090.Invoke_O__O(arg_1091) } else { tmp3 = linked_1089.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1088, arg_1091) }; if /*line :151:1*/ jrt.J2g_Truth(tmp3) {
		var root_1092 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any; var root_1097 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var arg_1101 any; var root_1102 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var arg_1106 any = x__0; if linked_1103 == nil { arg_1101 = ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { arg_1101 = linked_1103.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) }; if linked_1098 == nil { arg_1095 = ifn_1099.Invoke_O_O__O(arg_1100, arg_1101) } else { arg_1095 = linked_1098.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1097, arg_1100, arg_1101) }; var arg_1096 any; var G__1938000119__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000119__3_, nil) { arg_1096 = nil } else { arg_1096 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000119__3_) }; if linked_1093 == nil { x_SINGLEQUOTE___3 = ifn_1094.Invoke_O_O__O(arg_1095, arg_1096) } else { x_SINGLEQUOTE___3 = linked_1093.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1092, arg_1095, arg_1096) } } else {
//line :151:1
			var tmp4 any; var root_1107 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1109 lang.IFn

			if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = x__0; if linked_1108 == nil { tmp4 = ifn_1109.Invoke_O__O(arg_1110) } else { tmp4 = linked_1108.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1107, arg_1110) }
//line :151:1
			if jrt.J2g_Truth(tmp4) {

				var root_1111 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any; var root_1116 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var arg_1120 any = x__0; if linked_1117 == nil { arg_1114 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { arg_1114 = linked_1117.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }; var arg_1115 any; var G__1938000120__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000120__3_, nil) { arg_1115 = nil } else { arg_1115 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000120__3_) }; if linked_1112 == nil { x_SINGLEQUOTE___3 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { x_SINGLEQUOTE___3 = linked_1112.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) } } else {
//line :151:1
					var tmp5 any; var root_1121 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1123 lang.IFn


					if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = x__0; if linked_1122 == nil { tmp5 = ifn_1123.Invoke_O__O(arg_1124) } else { tmp5 = linked_1122.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1121, arg_1124) }
//line :151:1
					if jrt.J2g_Truth(tmp5) {


						var root_1125 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any; var root_1130 any = A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1134 any; var root_1136 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any; var tmp6 any = A_arbace_go_run_raw_lines_fn__1938000122_A_New(); var tmp7 *jrt.Class; var fncls__1148 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class; if fncls__1148 == nil { var fncls__1148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class = fncls__1148d; tmp7 = fncls__1148d } else { tmp7 = fncls__1148 }; arg_1139 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_1137 == nil { arg_1134 = ifn_1138.Invoke_O__O(arg_1139) } else { arg_1134 = linked_1137.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1136, arg_1139) }; var arg_1135 any = x__0; if linked_1131 == nil { arg_1128 = ifn_1132.Invoke_O_O_O__O(arg_1133, arg_1134, arg_1135) } else { arg_1128 = linked_1131.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1130, arg_1133, arg_1134, arg_1135) }; var arg_1129 any; var G__1938000127__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000127__3_, nil) { arg_1129 = nil } else { arg_1129 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000127__3_) }; if linked_1126 == nil { x_SINGLEQUOTE___3 = ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { x_SINGLEQUOTE___3 = linked_1126.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) } } else {
//line :151:1
							var tmp8 any; var root_1149 any = A_arbace_go_run_A_const_125.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1151 lang.IFn



							if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = x__0; if linked_1150 == nil { tmp8 = ifn_1151.Invoke_O__O(arg_1152) } else { tmp8 = linked_1150.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1149, arg_1152) }
//line :151:1
							if jrt.J2g_Truth(tmp8) {



								var root_1153 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = x__0; var arg_1157 any; var G__1938000128__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000128__3_, nil) { arg_1157 = nil } else { arg_1157 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000128__3_) }; if linked_1154 == nil { x_SINGLEQUOTE___3 = ifn_1155.Invoke_O_O__O(arg_1156, arg_1157) } else { x_SINGLEQUOTE___3 = linked_1154.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1153, arg_1156, arg_1157) } } else {
//line :151:1
									if A_arbace_go_run_A_const_29 != nil { x_SINGLEQUOTE___3 = x__0 } else { x_SINGLEQUOTE___3 = nil } } } } }; var m__4 any; if





	lang.IObj_InstanceOf(x_SINGLEQUOTE___3) { m__4 = lang.RT_Meta_O__IPersistentMap_NoInit(x_SINGLEQUOTE___3) } else { m__4 = nil }; var pos__5 any = /*line :143:1*/A_arbace_go_run_A_const_126.Invoke_O__O(m__4); var lines__6 any; var tmp9 any = A_arbace_go_run_raw_lines_lines__1938000129_A_New(); var tmp10 *jrt.Class; var fncls__1172 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class; if


















	fncls__1172 == nil { var fncls__1172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class = fncls__1172d; tmp10 = fncls__1172d } else { tmp10 = fncls__1172 }; lines__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var l__7 any; var or__1927000174__auto____7 any; var tmp11 any; var root_1173 any = /*line :143:1*/A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1175 lang.IFn; if



















	linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = x_SINGLEQUOTE___3; if linked_1174 == nil { tmp11 = ifn_1175.Invoke_O__O(arg_1176) } else { tmp11 = linked_1174.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1173, arg_1176) }; if jrt.J2g_Truth(tmp11) { var G__1938000133__7_ any; var root_1177 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1179 lang.IFn
		if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any; var tmp12 lang.IFn = lang.IFn_Cast(lines__6); var tmp13 any; var root_1182 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = A_arbace_go_run_A_const_129.Invoke_O__O(m__4); if linked_1183 == nil { tmp13 = ifn_1184.Invoke_O__O(arg_1185) } else { tmp13 = linked_1183.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1182, arg_1185) }; arg_1180 = tmp12.Invoke_O__O(tmp13); var arg_1181 any; var root_1186 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1188 lang.IFn
		if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var tmp14 any = A_arbace_go_run_raw_lines_fn__1938000134_A_New(); var tmp15 *jrt.Class; var fncls__1191 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class; if fncls__1191 == nil { var fncls__1191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class = fncls__1191d; tmp15 = fncls__1191d } else { tmp15 = fncls__1191 }; arg_1189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var arg_1190 any = x_SINGLEQUOTE___3; if linked_1187 == nil { arg_1181 = ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { arg_1181 = linked_1187.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) }
//line :164:1
		if linked_1178 == nil { G__1938000133__7_ = ifn_1179.Invoke_O_O__O(arg_1180, arg_1181) } else { G__1938000133__7_ = linked_1178.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1177, arg_1180, arg_1181) }
//line :163:1
		var G__1938000133__8_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__1938000133__7_, nil) { G__1938000133__8_ = nil } else { var root_1192 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = G__1938000133__7_; if linked_1193 == nil { G__1938000133__8_ = ifn_1194.Invoke_O__O(arg_1195) } else { G__1938000133__8_ = linked_1193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1192, arg_1195) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000133__8_, nil) { or__1927000174__auto____7 = nil } else {

			var root_1196 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = A_arbace_go_run_A_const_130.GetRawRoot__O(); var arg_1200 any = G__1938000133__8_; if linked_1197 == nil { or__1927000174__auto____7 = ifn_1198.Invoke_O_O__O(arg_1199, arg_1200) } else { or__1927000174__auto____7 = linked_1197.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1196, arg_1199, arg_1200) } } } else {
//line :163:1
				or__1927000174__auto____7 = nil }; if jrt.J2g_Truth(or__1927000174__auto____7) { l__7 = or__1927000174__auto____7 } else {



					var tmp16 any; var root_1201 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = pos__5; if linked_1202 == nil { tmp16 = ifn_1203.Invoke_O__O(arg_1204) } else { tmp16 = linked_1202.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1201, arg_1204) }; if jrt.J2g_Truth(tmp16) { var G__1938000136__8_ any; var root_1205 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = A_arbace_go_run_A_const_131.GetRawRoot__O(); var arg_1209 any = pos__5; var arg_1210 any = A_arbace_go_run_A_const_132; if linked_1206 == nil { G__1938000136__8_ = ifn_1207.Invoke_O_O_O__O(arg_1208, arg_1209, arg_1210) } else { G__1938000136__8_ = linked_1206.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1205, arg_1208, arg_1209, arg_1210) }; var G__1938000136__9_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__8_, nil) { G__1938000136__9_ = nil } else { var root_1211 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = G__1938000136__8_; if linked_1212 == nil { G__1938000136__9_ = ifn_1213.Invoke_O__O(arg_1214) } else { G__1938000136__9_ = linked_1212.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1211, arg_1214) } }; var G__1938000136__10_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__9_, nil) { G__1938000136__10_ = nil } else { G__1938000136__10_ = lang.IFn_Cast(lines__6).Invoke_O__O(G__1938000136__9_) }; var G__1938000136__11_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__10_, nil) { G__1938000136__11_ = nil } else { var root_1215 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = G__1938000136__10_; if linked_1216 == nil { G__1938000136__11_ = ifn_1217.Invoke_O__O(arg_1218) } else { G__1938000136__11_ = linked_1216.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1215, arg_1218) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000136__11_, nil) { l__7 = nil } else { var root_1219 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = A_arbace_go_run_A_const_130.GetRawRoot__O(); var arg_1223 any = G__1938000136__11_; if linked_1220 == nil { l__7 = ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { l__7 = linked_1220.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) } } } else { l__7 = nil } }; var end__8 any; var tmp17 any; var root_1224 any = /*line :143:1*/A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1226 lang.IFn; if


























	linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = pos__5; if linked_1225 == nil { tmp17 = ifn_1226.Invoke_O__O(arg_1227) } else { tmp17 = linked_1225.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1224, arg_1227) }; if jrt.J2g_Truth(tmp17) { var root_1228 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = A_arbace_go_run_A_const_133.Invoke_O__O(pos__5); if linked_1229 == nil { end__8 = ifn_1230.Invoke_O__O(arg_1231) } else { end__8 = linked_1229.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1228, arg_1231) } } else { end__8 = nil }; var apos__9 any = /*line :143:1*/A_arbace_go_run_A_const_129.Invoke_O__O(m__4); var tmp18 any; var or__1927000174__auto____10 any = l__7; if




























	jrt.J2g_Truth(or__1927000174__auto____10) { tmp18 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 any = end__8; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp18 = or__1927000174__auto____11 } else { var root_1232 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = apos__9; if linked_1233 == nil { tmp18 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp18 = linked_1233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1232, arg_1235) } } }; if jrt.J2g_Truth(tmp18) {
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_134.GetRawRoot__O()); var tmp20 any = A_arbace_go_run_raw_lines_fn__1938000137_A_New_O_O_O(l__7, apos__9, end__8); var tmp21 *jrt.Class; var fncls__1350 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class; if fncls__1350 == nil { var fncls__1350d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class = fncls__1350d; tmp21 = fncls__1350d } else { tmp21 = fncls__1350 }; return tmp19.Invoke_O_O__O(x_SINGLEQUOTE___3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil)) } else {
//line :172:1
			return x_SINGLEQUOTE___3 } }
//line :150:1
func A_arbace_go_run_raw_lines_walk_meta__1938000116_A_New() *A_arbace_go_run_raw_lines_walk_meta__1938000116_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_walk_meta__1938000116_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000116_A) Ctor() {}
//line :150:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000116_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000117__2_ any = m__1; var tmp1 any; var root_1076 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = m__1; var arg_1080 any = A_arbace_go_run_A_const_115; if linked_1077 == nil { tmp1 = ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { tmp1 = linked_1077.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) }; if jrt.J2g_Truth(tmp1) { var root_1081 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = G__1938000117__2_; var arg_1085 any = A_arbace_go_run_A_const_115; var arg_1086 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); if linked_1082 == nil { return ifn_1083.Invoke_O_O_O__O(arg_1084, arg_1085, arg_1086) } else { return linked_1082.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1081, arg_1084, arg_1085, arg_1086) } } else { return G__1938000117__2_ } }



func A_arbace_go_run_raw_lines_fn__1938000122_A_New() *A_arbace_go_run_raw_lines_fn__1938000122_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000122_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_run_raw_lines_fn__1938000122_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_run_raw_lines_fn__1938000122_A) Invoke_O_O__O(self, p__1938000121__1 any) any { var vec__1938000123__2 any = p__1938000121__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000123__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000123__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1140 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = k__3; if linked_1141 == nil { tmp1 = ifn_1142.Invoke_O__O(arg_1143) } else { tmp1 = linked_1141.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1140, arg_1143) }; var tmp2 any = tmp1; var tmp3 any; var root_1144 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = v__4; if linked_1145 == nil { tmp3 = ifn_1146.Invoke_O__O(arg_1147) } else { tmp3 = linked_1145.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1144, arg_1147) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }







func A_arbace_go_run_raw_lines_lines__1938000129_A_New() *A_arbace_go_run_raw_lines_lines__1938000129_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000129_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_A) Ctor() {}
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_A) Invoke_O_O__O(self, ps__1 any) any { var root_1158 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var tmp1 any = A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_New(); var tmp2 *jrt.Class; var fncls__1171 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class; if fncls__1171 == nil { var fncls__1171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class = fncls__1171d; tmp2 = fncls__1171d } else { tmp2 = fncls__1171 }; arg_1161 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1162 any = ps__1; if linked_1159 == nil { return ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { return linked_1159.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) } }
//line :162:1
func A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_New() *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A) Ctor() {}
//line :162:1
func (t *A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A) Invoke_O_O__O(self, p1__1938000114_SHARP___1 any) any { var tmp1 any; var root_1163 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = p1__1938000114_SHARP___1; if linked_1164 == nil { tmp1 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp1 = linked_1164.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1163, arg_1166) }; if jrt.J2g_Truth(tmp1) { var root_1167 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = p1__1938000114_SHARP___1; if linked_1168 == nil { return ifn_1169.Invoke_O__O(arg_1170) } else { return linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170) } } else { return nil } }


func A_arbace_go_run_raw_lines_fn__1938000134_A_New() *A_arbace_go_run_raw_lines_fn__1938000134_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000134_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_run_raw_lines_fn__1938000134_A) Ctor() {}
//line :165:1
func (t *A_arbace_go_run_raw_lines_fn__1938000134_A) Invoke_O_O__O(self, p1__1938000115_SHARP___1 any) any { if lang.IMeta_InstanceOf(p1__1938000115_SHARP___1) { var tmp1 *lang.Keyword = A_arbace_go_run_A_const_66; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1938000115_SHARP___1)) } else { return nil } }







func A_arbace_go_run_raw_lines_fn__1938000137_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_raw_lines_fn__1938000137_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :173:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_A) Ctor_O_O_O(c__l, c__apos, c__end any) { t.F_l = c__l; t.F_apos = c__apos; t.F_end = c__end }
//line :173:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000138__2_ any = m__1; var G__1938000138__3_ any; if jrt.J2g_Truth(t.F_l) {
											var root_1241 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = G__1938000138__2_; var arg_1245 any = A_arbace_go_run_A_const_66; var arg_1246 any = t.F_l; if linked_1242 == nil { G__1938000138__3_ = ifn_1243.Invoke_O_O_O__O(arg_1244, arg_1245, arg_1246) } else { G__1938000138__3_ = linked_1242.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1241, arg_1244, arg_1245, arg_1246) } } else {
//line :173:1
		G__1938000138__3_ = G__1938000138__2_ }; var G__1938000138__4_ any; if jrt.J2g_Truth(t.F_end) {

			var root_1247 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = G__1938000138__3_; var arg_1251 any = A_arbace_go_run_A_const_135; var arg_1252 any = t.F_end; if linked_1248 == nil { G__1938000138__4_ = ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { G__1938000138__4_ = linked_1248.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) } } else {
//line :173:1
				G__1938000138__4_ = G__1938000138__3_ }; var tmp1 any; var root_1253 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1255 lang.IFn; if


	linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = t.F_apos; if linked_1254 == nil { tmp1 = ifn_1255.Invoke_O__O(arg_1256) } else { tmp1 = linked_1254.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1253, arg_1256) }; if /*line :173:1*/ jrt.J2g_Truth(tmp1) {


		var root_1257 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = G__1938000138__4_; var arg_1261 any = A_arbace_go_run_A_const_136; var arg_1262 any; var root_1263 any = A_arbace_go_run_A_const_137.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any; var iter__1927001039__auto____5 any; var tmp2 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_New(); var tmp3 *jrt.Class; var fncls__1345 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class; if fncls__1345 == nil { var fncls__1345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class = fncls__1345d; tmp3 = fncls__1345d } else { tmp3 = fncls__1345 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp5 any; var root_1346 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = t.F_apos; if linked_1347 == nil { tmp5 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp5 = linked_1347.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1346, arg_1349) }; arg_1266 = tmp4.Invoke_O__O(tmp5); if linked_1264 == nil { arg_1262 = ifn_1265.Invoke_O__O(arg_1266) } else { arg_1262 = linked_1264.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1263, arg_1266) }; if linked_1258 == nil { return ifn_1259.Invoke_O_O_O__O(arg_1260, arg_1261, arg_1262) } else { return linked_1258.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1257, arg_1260, arg_1261, arg_1262) } } else {
//line :173:1
			return G__1938000138__4_ } }


func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_New() *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A) Ctor() {}
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A) Invoke_O_O__O(self, s__1938000140__1 any) any { var tmp1 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_New_O_O(self, s__1938000140__1); var tmp2 *jrt.Class; var fncls__1344 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class; if fncls__1344 == nil { var fncls__1344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class = fncls__1344d; tmp2 = fncls__1344d } else { tmp2 = fncls__1344 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :176:1
func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_New_O_O(p0, p1 any) *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A) Ctor_O_O(c__iter__1938000139, c__s__1938000140 any) { t.F_iter__1938000139 = c__iter__1938000139; t.F_s__1938000140 = c__s__1938000140 }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A) Invoke_O__O(self any) any { { var s__1938000140__1 any; var t_ any = t.F_s__1938000140; t.F_s__1938000140 = nil; s__1938000140__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1267 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = s__1938000140__1; if linked_1268 == nil { temp__1927000414__auto____2 = ifn_1269.Invoke_O__O(arg_1270) } else { temp__1927000414__auto____2 = linked_1268.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1267, arg_1270) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000140__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1271 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = s__1938000140__3; if linked_1272 == nil { tmp1 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp1 = linked_1272.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1271, arg_1274) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1275 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = s__1938000140__3; if linked_1276 == nil { c__1927001037__auto____4 = ifn_1277.Invoke_O__O(arg_1278) } else { c__1927001037__auto____4 = linked_1276.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1275, arg_1278) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000142__6 any; var root_1279 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1280 == nil { b__1938000142__6 = ifn_1281.Invoke_O__O(arg_1282) } else { b__1938000142__6 = linked_1280.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1279, arg_1282) }; var tmp2 any = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_New_O_I_O(b__1938000142__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1296 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class; if fncls__1296 == nil { var fncls__1296d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class = fncls__1296d; tmp3 = fncls__1296d } else { tmp3 = fncls__1296 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1297 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any; var root_1302 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = b__1938000142__6; if linked_1303 == nil { arg_1300 = ifn_1304.Invoke_O__O(arg_1305) } else { arg_1300 = linked_1303.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1302, arg_1305) }; var arg_1301 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000139); var tmp5 any; var root_1306 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = s__1938000140__3; if linked_1307 == nil { tmp5 = ifn_1308.Invoke_O__O(arg_1309) } else { tmp5 = linked_1307.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1306, arg_1309) }; arg_1301 = tmp4.Invoke_O__O(tmp5); if linked_1298 == nil { return ifn_1299.Invoke_O_O__O(arg_1300, arg_1301) } else { return linked_1298.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1297, arg_1300, arg_1301) } } else { var root_1310 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any; var root_1315 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = b__1938000142__6; if linked_1316 == nil { arg_1313 = ifn_1317.Invoke_O__O(arg_1318) } else { arg_1313 = linked_1316.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1315, arg_1318) }; var arg_1314 any; if linked_1311 == nil { return ifn_1312.Invoke_O_O__O(arg_1313, arg_1314) } else { return linked_1311.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1310, arg_1313, arg_1314) } } } else { var vec__1938000150__4 any; var root_1319 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = s__1938000140__3; if linked_1320 == nil { vec__1938000150__4 = ifn_1321.Invoke_O__O(arg_1322) } else { vec__1938000150__4 = linked_1320.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1319, arg_1322) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000150__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000150__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_1323 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = p__6; if linked_1324 == nil { tmp6 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp6 = linked_1324.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1323, arg_1326) }; if jrt.J2g_Truth(tmp6) { var root_1327 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any; var tmp7 any; var root_1332 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = p__6; if linked_1333 == nil { tmp7 = ifn_1334.Invoke_O__O(arg_1335) } else { tmp7 = linked_1333.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1332, arg_1335) }; arg_1330 = lang.Tuple_Create_O_O__IPersistentVector(i__5, tmp7); var arg_1331 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000139); var tmp9 any; var root_1336 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = s__1938000140__3; if linked_1337 == nil { tmp9 = ifn_1338.Invoke_O__O(arg_1339) } else { tmp9 = linked_1337.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1336, arg_1339) }; arg_1331 = tmp8.Invoke_O__O(tmp9); if linked_1328 == nil { return ifn_1329.Invoke_O_O__O(arg_1330, arg_1331) } else { return linked_1328.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1327, arg_1330, arg_1331) } } else { var tmp10 any; var root_1340 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = s__1938000140__3; if linked_1341 == nil { tmp10 = ifn_1342.Invoke_O__O(arg_1343) } else { tmp10 = linked_1341.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1340, arg_1343) }; s__1938000140__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :176:1
func A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A) Ctor_O_I_O(c__b__1938000142 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000142 = c__b__1938000142; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A) Invoke_O__O(self any) any { { var i__1938000141__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000141__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1938000146__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000141__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000146__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000146__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_1283 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = p__4; if linked_1284 == nil { tmp2 = ifn_1285.Invoke_O__O(arg_1286) } else { tmp2 = linked_1284.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1283, arg_1286) }; if jrt.J2g_Truth(tmp2) { var root_1287 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = t.F_b__1938000142; var arg_1291 any; var tmp3 any; var root_1292 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = p__4; if linked_1293 == nil { tmp3 = ifn_1294.Invoke_O__O(arg_1295) } else { tmp3 = linked_1293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1292, arg_1295) }; arg_1291 = lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp3); if linked_1288 == nil { ifn_1289.Invoke_O_O__O(arg_1290, arg_1291) } else { linked_1288.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1287, arg_1290, arg_1291) }; i__1938000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000141__1); continue L1 } else { i__1938000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000141__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_run_errorcheck_A_New() *A_arbace_go_run_errorcheck_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_go_run_errorcheck_A) Ctor() {}
//line :179:1
func (t *A_arbace_go_run_errorcheck_A) Invoke_O_O_O_O_O_O_O__O(self, root__0, pf__1, lang__2, max_errors__3, raw__4, front__5 any) any { var src__7 any; var G__1938000162__7_ any; var root_1351 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_1353 lang.IFn; if















	linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, root__0)); var arg_1355 any; var arg_1356 any; var root_1358 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_1359 == nil { arg_1356 = ifn_1360.Invoke_O__O(arg_1361) } else { arg_1356 = linked_1359.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1358, arg_1361) }; var arg_1357 any = pf__1; if linked_1352 == nil { G__1938000162__7_ = ifn_1353.Invoke_O_O_O_O__O(arg_1354, arg_1355, arg_1356, arg_1357) } else { G__1938000162__7_ = linked_1352.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_1351, arg_1354, arg_1355, arg_1356, arg_1357) }; var G__1938000162__8_ any; if jrt.J2g_Truth(lang__2) {
		var root_1362 any = A_arbace_go_run_A_const_138.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = G__1938000162__7_; var arg_1366 any = A_arbace_go_run_A_const_139; var arg_1367 any = lang__2; if linked_1363 == nil { G__1938000162__8_ = ifn_1364.Invoke_O_O_O__O(arg_1365, arg_1366, arg_1367) } else { G__1938000162__8_ = linked_1363.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1362, arg_1365, arg_1366, arg_1367) } } else {
//line :195:1
			G__1938000162__8_ = G__1938000162__7_ }; if jrt.J2g_Truth(raw__4) {





				var root_1368 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var root_1374 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1376 lang.IFn
//line :197:1
				if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = G__1938000162__8_; var arg_1378 any = A_arbace_go_run_A_const_51; var arg_1379 any; var tmp1 any = A_arbace_go_run_errorcheck_fn__1938000163_A_New(); var tmp2 *jrt.Class; var fncls__1415 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000163_A_fn_class; if fncls__1415 == nil { var fncls__1415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_go_run_errorcheck_fn__1938000163_A_fn_class = fncls__1415d; tmp2 = fncls__1415d } else { tmp2 = fncls__1415 }; arg_1379 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1375 == nil { arg_1371 = ifn_1376.Invoke_O_O_O__O(arg_1377, arg_1378, arg_1379) } else { arg_1371 = linked_1375.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1374, arg_1377, arg_1378, arg_1379)
				}


				var arg_1372 any = A_arbace_go_run_A_const_143; var arg_1373 any = jrt.HashMap_New(); if linked_1369 == nil { src__7 = ifn_1370.Invoke_O_O_O__O(arg_1371, arg_1372, arg_1373) } else { src__7 = linked_1369.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1368, arg_1371, arg_1372, arg_1373) } } else {
//line :195:1
					src__7 = G__1938000162__8_ }; var ___8 any; var tmp3 any; var root_1416 any = /*line :179:1*/A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1418 lang.IFn; _ = ___8; if






















	linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__7); if linked_1417 == nil { tmp3 = ifn_1418.Invoke_O__O(arg_1419) } else { tmp3 = linked_1417.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1416, arg_1419) }; if jrt.J2g_Truth(tmp3) { var root_1420 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, A_arbace_go_run_fail_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = A_arbace_go_run_A_const_49; var arg_1424 any = Lit_14; var arg_1425 any = Lit_26; if linked_1421 == nil { ___8 = ifn_1422.Invoke_O_O_O__O(arg_1423, arg_1424, arg_1425) } else { ___8 = linked_1421.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1420, arg_1423, arg_1424, arg_1425) } } else { ___8 = nil }; var ___9 any; var root_1426 any = /*line :179:1*/A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_1428 lang.IFn; _ = ___9; if























	linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = src__7; if linked_1427 == nil { ___9 = ifn_1428.Invoke_O__O(arg_1429) } else { ___9 = linked_1427.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_1426, arg_1429) }; var r__10 any; var root_1430 any = /*line :179:1*/A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_1432 lang.IFn; if
























	linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = src__7; var arg_1434 any; var tmp4 any = A_arbace_go_run_errorcheck_fn__1938000170_A_New(); var tmp5 *jrt.Class; var fncls__1436 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000170_A_fn_class; if fncls__1436 == nil { var fncls__1436d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_run_errorcheck_fn__1938000170_A_fn_class = fncls__1436d; tmp5 = fncls__1436d } else { tmp5 = fncls__1436 }; arg_1434 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1435 any = jrt.Boolean_FALSE.Ref(); if linked_1431 == nil { r__10 = ifn_1432.Invoke_O_O_O__O(arg_1433, arg_1434, arg_1435) } else { r__10 = linked_1431.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O_O__O(root_1430, arg_1433, arg_1434, arg_1435) }; var errs__11 any = /*line :179:1*/A_arbace_go_run_A_const_58.Invoke_O__O(r__10); var temp__1927000414__auto____12 any; var root_1661 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1663 lang.IFn; if


























	linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any; var tmp6 any = A_arbace_go_run_errorcheck_fn__1938000172_A_New(); var tmp7 *jrt.Class; var fncls__1666 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000172_A_fn_class; if fncls__1666 == nil { var fncls__1666d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_run_errorcheck_fn__1938000172_A_fn_class = fncls__1666d; tmp7 = fncls__1666d } else { tmp7 = fncls__1666 }; arg_1664 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1665 any = errs__11; if linked_1662 == nil { temp__1927000414__auto____12 = ifn_1663.Invoke_O_O__O(arg_1664, arg_1665) } else { temp__1927000414__auto____12 = linked_1662.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1661, arg_1664, arg_1665) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var bi__13 any = temp__1927000414__auto____12; var root_1667 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, A_arbace_go_run_fail_A_fn_class); var ifn_1669 lang.IFn
		if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = A_arbace_go_run_A_const_49; var arg_1671 any = Lit_14; var arg_1672 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_63.Invoke_O__O(bi__13))).Ref(); if linked_1668 == nil { ifn_1669.Invoke_O_O_O__O(arg_1670, arg_1671, arg_1672) } else { linked_1668.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1667, arg_1670, arg_1671, arg_1672) } }; var temp__1927000414__auto____12_2 any; var root_1673 any = /*line :179:1*/A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1675 lang.IFn; if




























	linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any; var tmp8 any = A_arbace_go_run_errorcheck_fn__1938000174_A_New(); var tmp9 *jrt.Class; var fncls__1678 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000174_A_fn_class; if fncls__1678 == nil { var fncls__1678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_run_errorcheck_fn__1938000174_A_fn_class = fncls__1678d; tmp9 = fncls__1678d } else { tmp9 = fncls__1678 }; arg_1676 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_1677 any = A_arbace_go_run_A_const_165.Invoke_O__O(r__10); if linked_1674 == nil { temp__1927000414__auto____12_2 = ifn_1675.Invoke_O_O__O(arg_1676, arg_1677) } else { temp__1927000414__auto____12_2 = linked_1674.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1673, arg_1676, arg_1677) }; if jrt.J2g_Truth(temp__1927000414__auto____12_2) { var u__13 any = temp__1927000414__auto____12_2; var root_1679 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, A_arbace_go_run_fail_A_fn_class); var ifn_1681 lang.IFn
		if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = A_arbace_go_run_A_const_49; var arg_1683 any = Lit_14; var arg_1684 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31, nil); var tmp11 *lang.Keyword = A_arbace_go_run_A_const_81; var tmp12 any; var root_1685 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1685, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1687 lang.IFn; if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any = u__13; if linked_1686 == nil { tmp12 = ifn_1687.Invoke_O__O(arg_1688) } else { tmp12 = linked_1686.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1685, arg_1688) }; var tmp13 any = tmp11.Invoke_O__O(tmp12); var tmp14 any; var root_1689 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = u__13; if linked_1690 == nil { tmp14 = ifn_1691.Invoke_O__O(arg_1692) } else { tmp14 = linked_1690.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1689, arg_1692) }; arg_1684 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp14)).Ref(); if linked_1680 == nil { ifn_1681.Invoke_O_O_O__O(arg_1682, arg_1683, arg_1684) } else { linked_1680.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1679, arg_1682, arg_1683, arg_1684) } }; var errs__12 any; var G__1938000176__12_ any; var root_1437 any = /*line :179:1*/A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1439 lang.IFn; if

































	linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any; var tmp15 any = A_arbace_go_run_errorcheck_fn__1938000177_A_New(); var tmp16 *jrt.Class; var fncls__1442 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000177_A_fn_class; if fncls__1442 == nil { var fncls__1442d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_run_errorcheck_fn__1938000177_A_fn_class = fncls__1442d; tmp16 = fncls__1442d } else { tmp16 = fncls__1442 }; arg_1440 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_1441 any = errs__11; if linked_1438 == nil { G__1938000176__12_ = ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { G__1938000176__12_ = linked_1438.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) }; if jrt.J2g_Truth(front__5) {
		var root_1443 any = A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any; var tmp17 any = A_arbace_go_run_errorcheck_fn__1938000179_A_New(); var tmp18 *jrt.Class; var fncls__1448 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000179_A_fn_class; if fncls__1448 == nil { var fncls__1448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_run_errorcheck_fn__1938000179_A_fn_class = fncls__1448d; tmp18 = fncls__1448d } else { tmp18 = fncls__1448 }; arg_1446 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1447 any = G__1938000176__12_; if linked_1444 == nil { errs__12 = ifn_1445.Invoke_O_O__O(arg_1446, arg_1447) } else { errs__12 = linked_1444.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1443, arg_1446, arg_1447) } } else {
//line :213:1
			errs__12 = G__1938000176__12_ }; var file_lang__13 any; var root_1449 any = /*line :179:1*/A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1451 lang.IFn; if




































	linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1453 any; var iter__1927001039__auto____13 any; var tmp19 any = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_New(); var tmp20 *jrt.Class; var fncls__1522 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_fn_class; if fncls__1522 == nil { var fncls__1522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_fn_class = fncls__1522d; tmp20 = fncls__1522d } else { tmp20 = fncls__1522 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); arg_1453 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(A_arbace_go_run_A_const_51.Invoke_O__O(src__7)); if linked_1450 == nil { file_lang__13 = ifn_1451.Invoke_O_O__O(arg_1452, arg_1453) } else { file_lang__13 = linked_1450.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1449, arg_1452, arg_1453) }; var vmsg__14 any; var tmp21 any = /*line :179:1*/A_arbace_go_run_errorcheck_vmsg__1938000191_A_New_O_O_O(file_lang__13, lang__2, src__7); var tmp22 *jrt.Class; var fncls__1533 *jrt.Class = A_arbace_go_run_errorcheck_vmsg__1938000191_A_fn_class; if





































	fncls__1533 == nil { var fncls__1533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_run_errorcheck_vmsg__1938000191_A_fn_class = fncls__1533d; tmp22 = fncls__1533d } else { tmp22 = fncls__1533 }; vmsg__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); var lines__15 any; var iter__1927001039__auto____15 any; var tmp23 any = /*line :179:1*/A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_New_O(vmsg__14); var tmp24 *jrt.Class; var fncls__1592 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_fn_class; if












































	fncls__1592 == nil { var fncls__1592d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_fn_class = fncls__1592d; tmp24 = fncls__1592d } else { tmp24 = fncls__1592 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); lines__15 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(errs__12); var lines__16 any; if
	jrt.J2g_Truth(front__5) { var ___16 any = lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_151); var name__17 any = jrt.File_New_String(jrt.String_Cast(front__5)).GetName__String().Ref(); var noder__18 any; var tmp25 *lang.Keyword = A_arbace_go_run_A_const_152; var tmp26 any; var root_1597 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1599 lang.IFn; _ = ___16


		if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = A_arbace_go_run_A_const_154; if linked_1598 == nil { tmp26 = ifn_1599.Invoke_O__O(arg_1600) } else { tmp26 = linked_1598.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1597, arg_1600) }; noder__18 = tmp25.Invoke_O__O(lang.IFn_Cast(tmp26).Invoke_O_O__O(front__5, name__17))
//line :225:1
		var pos__19 any; var tmp27 any = A_arbace_go_run_errorcheck_pos__1938000203_A_New(); var tmp28 *jrt.Class
		var fncls__1606 /*line :225:1*/*jrt.Class = A_arbace_go_run_errorcheck_pos__1938000203_A_fn_class




		if fncls__1606 == nil { var fncls__1606d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_run_errorcheck_pos__1938000203_A_fn_class = fncls__1606d; tmp28 = fncls__1606d } else { tmp28 = fncls__1606 }; pos__19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil)
//line :225:1
		var merged__20 any; var root_1607 any = A_arbace_go_run_A_const_157.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1609 lang.IFn






		if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = pos__19; var arg_1611 any; var root_1612 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = lines__15; var arg_1616 any = noder__18; if linked_1613 == nil { arg_1611 = ifn_1614.Invoke_O_O__O(arg_1615, arg_1616) } else { arg_1611 = linked_1613.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1612, arg_1615, arg_1616) }; if linked_1608 == nil { merged__20 = ifn_1609.Invoke_O_O__O(arg_1610, arg_1611) } else { merged__20 = linked_1608.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1607, arg_1610, arg_1611) }
		var tmp29 any; var root_1617 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = merged__20; if linked_1618 == nil { tmp29 = ifn_1619.Invoke_O__O(arg_1620) } else { tmp29 = linked_1618.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1617, arg_1620) }; if jrt.J2g_Truth(tmp29) { lines__16 = merged__20 } else {

			var tmp30 any; var root_1621 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = A_arbace_go_run_A_const_158; if linked_1622 == nil { tmp30 = ifn_1623.Invoke_O__O(arg_1624) } else { tmp30 = linked_1622.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1621, arg_1624) }; lines__16 = lang.IFn_Cast(tmp30).Invoke_O_O_O__O(front__5, name__17, lang__2) } } else {
//line :225:1
				lines__16 = lines__15 }; var lines__17 any; var root_1625 any = /*line :179:1*/A_arbace_go_run_A_const_159.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_dedupe_A_fn_class); var ifn_1627 lang.IFn; if

























































	linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = lines__16; if linked_1626 == nil { lines__17 = ifn_1627.Invoke_O__O(arg_1628) } else { lines__17 = linked_1626.(*aot_arbace_core.A_arbace_core_dedupe_A).Invoke_O_O__O(root_1625, arg_1628) }; var lines__18 any; var tmp31 any; var and__1927000168__auto____18 any = max_errors__3; if


	jrt.J2g_Truth(and__1927000168__auto____18) { var tmp32 bool; var na_1629 int64 = int64(lang.RT_Count_O__I_NoInit(lines__17)); var na_1630 any = max_errors__3; if jrt.Long_InstanceOf(na_1630) { var n0_1631 int64 = na_1629; var n1_1632 int64 = jrt.NN(jrt.Long_Cast(na_1630)).LongValue__J(); tmp32 = n0_1631 >= n1_1632 } else { tmp32 = lang.Numbers_Gte_J_O__Z_NoInit(na_1629, na_1630) }; tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp32).Ref() } else { tmp31 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp31) { var ls__18 any; var root_1634 any = A_arbace_go_run_A_const_137.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1636 lang.IFn
		if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any; var root_1638 any = A_arbace_go_run_A_const_160.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = max_errors__3; var arg_1642 any = lines__17; if linked_1639 == nil { arg_1637 = ifn_1640.Invoke_O_O__O(arg_1641, arg_1642) } else { arg_1637 = linked_1639.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1638, arg_1641, arg_1642) }; if linked_1635 == nil { ls__18 = ifn_1636.Invoke_O__O(arg_1637) } else { ls__18 = linked_1635.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1634, arg_1637) }
//line :240:1
		var pos__19_2 any; var root_1643 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1645 lang.IFn

		if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = A_arbace_go_run_A_const_161; var arg_1647 any; var root_1648 any = A_arbace_go_run_A_const_162.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = ls__18; if linked_1649 == nil { arg_1647 = ifn_1650.Invoke_O__O(arg_1651) } else { arg_1647 = linked_1649.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1648, arg_1651) }; if linked_1644 == nil { pos__19_2 = ifn_1645.Invoke_O_O__O(arg_1646, arg_1647) } else { pos__19_2 = linked_1644.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1643, arg_1646, arg_1647) }
		var root_1652 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = ls__18; var arg_1656 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, pos__19_2, nil)).Ref(); if linked_1653 == nil { lines__18 = ifn_1654.Invoke_O_O__O(arg_1655, arg_1656) } else { lines__18 = linked_1653.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1652, arg_1655, arg_1656) } } else {
//line :240:1
			lines__18 = lines__17 }; var seq_1938000208__19 any; var root_1693 any = /*line :179:1*/A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1695 lang.IFn; if

































































	linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = lines__18; if linked_1694 == nil { seq_1938000208__19 = ifn_1695.Invoke_O__O(arg_1696) } else { seq_1938000208__19 = linked_1694.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1693, arg_1696) }; var chunk_1938000209__20 any; var count_1938000210__21 int64 = 0; var i_1938000211__22 int64 = 0; L1:
//line :179:1
	for {

































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000211__22, count_1938000210__21) { var l__23 any = lang.Indexed_Cast(chunk_1938000209__20).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000211__22)); lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(l__23); seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, i_1938000211__22 = seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000211__22); continue L1 } else { var temp__1927000414__auto____23 any; var root_1697 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = seq_1938000208__19; if linked_1698 == nil { temp__1927000414__auto____23 = ifn_1699.Invoke_O__O(arg_1700) } else { temp__1927000414__auto____23 = linked_1698.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1697, arg_1700) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var seq_1938000208__24 any = temp__1927000414__auto____23; var tmp33 any; var root_1701 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = seq_1938000208__24; if linked_1702 == nil { tmp33 = ifn_1703.Invoke_O__O(arg_1704) } else { tmp33 = linked_1702.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1701, arg_1704) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____25 any; var root_1705 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = seq_1938000208__24; if linked_1706 == nil { c__1927000678__auto____25 = ifn_1707.Invoke_O__O(arg_1708) } else { c__1927000678__auto____25 = linked_1706.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1705, arg_1708) }; var tmp34 any; var root_1720 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = seq_1938000208__24; if linked_1721 == nil { tmp34 = ifn_1722.Invoke_O__O(arg_1723) } else { tmp34 = linked_1721.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1720, arg_1723) }; seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, i_1938000211__22 = tmp34, c__1927000678__auto____25, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____25))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__25 any; var root_1709 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = seq_1938000208__24; if linked_1710 == nil { l__25 = ifn_1711.Invoke_O__O(arg_1712) } else { l__25 = linked_1710.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1709, arg_1712) }; lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(l__25); var tmp35 any; var root_1728 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = seq_1938000208__24; if linked_1729 == nil { tmp35 = ifn_1730.Invoke_O__O(arg_1731) } else { tmp35 = linked_1729.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1728, arg_1731) }; seq_1938000208__19, chunk_1938000209__20, count_1938000210__21, i_1938000211__22 = tmp35, nil, 0, 0; continue L1 } } }
//line :179:1
		break L1 }; var root_1713 any =


































































	A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; if linked_1714 == nil { ifn_1715.Invoke__O() } else { linked_1714.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_1713) }; var tmp36 any; var root_1657 any =
	A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = lines__18; if linked_1658 == nil { tmp36 = ifn_1659.Invoke_O__O(arg_1660) } else { tmp36 = linked_1658.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1657, arg_1660) }; if jrt.J2g_Truth(tmp36) { return A_arbace_go_run_A_const_163 } else { return A_arbace_go_run_A_const_156 } }
//line :197:1
func A_arbace_go_run_errorcheck_fn__1938000163_A_New() *A_arbace_go_run_errorcheck_fn__1938000163_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000163_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_A) Invoke_O_O__O(self, fs__1 any) any { var root_1380 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any; var tmp1 any = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_New(); var tmp2 *jrt.Class; var fncls__1414 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_fn_class; if fncls__1414 == nil { var fncls__1414d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_fn_class = fncls__1414d; tmp2 = fncls__1414d } else { tmp2 = fncls__1414 }; arg_1383 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1384 any = fs__1; if linked_1381 == nil { return ifn_1382.Invoke_O_O__O(arg_1383, arg_1384) } else { return linked_1381.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1380, arg_1383, arg_1384) } }
//line :197:1
func A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_New() *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A) Invoke_O_O__O(self, p1__1938000157_SHARP___1 any) any { var G__1938000165__2_ any; var root_1385 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1387 lang.IFn; if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = p1__1938000157_SHARP___1; var arg_1389 any = A_arbace_go_run_A_const_52; var arg_1390 any; var tmp1 any = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_New(); var tmp2 *jrt.Class; var fncls__1396 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_fn_class; if fncls__1396 == nil { var fncls__1396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_fn_class = fncls__1396d; tmp2 = fncls__1396d } else { tmp2 = fncls__1396 }; arg_1390 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1386 == nil { G__1938000165__2_ = ifn_1387.Invoke_O_O_O__O(arg_1388, arg_1389, arg_1390) } else { G__1938000165__2_ = linked_1386.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1385, arg_1388, arg_1389, arg_1390) }; var G__1938000165__3_ any; if jrt.J2g_Truth(A_arbace_go_run_A_const_65.Invoke_O__O(p1__1938000157_SHARP___1)) {
																var root_1397 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = G__1938000165__2_; var arg_1401 any = A_arbace_go_run_A_const_65; var arg_1402 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); if linked_1398 == nil { G__1938000165__3_ = ifn_1399.Invoke_O_O_O__O(arg_1400, arg_1401, arg_1402) } else { G__1938000165__3_ = linked_1398.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1397, arg_1400, arg_1401, arg_1402) } } else {
//line :197:1
		G__1938000165__3_ = G__1938000165__2_ }; var tmp3 any; var root_1403 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1405 lang.IFn; if

	linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = p1__1938000157_SHARP___1; var arg_1407 any = A_arbace_go_run_A_const_140; if linked_1404 == nil { tmp3 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { tmp3 = linked_1404.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }; if /*line :197:1*/ jrt.J2g_Truth(tmp3) {

		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_141.GetRawRoot__O()); var tmp5 any = A_arbace_go_run_A_const_142; return tmp4.Invoke_O_O_O__O(G__1938000165__3_, tmp5, A_arbace_go_run_A_const_117.GetRawRoot__O()) } else {
//line :197:1
			return G__1938000165__3_ } }
//line :197:1
func A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_New() *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A) Invoke_O_O__O(self, ds__1 any) any { var root_1391 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var arg_1395 any = ds__1; if linked_1392 == nil { return ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { return linked_1392.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) } }






func A_arbace_go_run_errorcheck_fn__1938000170_A_New() *A_arbace_go_run_errorcheck_fn__1938000170_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000170_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_go_run_errorcheck_fn__1938000170_A) Ctor() {}
//line :204:1
func (t *A_arbace_go_run_errorcheck_fn__1938000170_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_go_run_errorcheck_fn__1938000172_A_New() *A_arbace_go_run_errorcheck_fn__1938000172_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000172_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_go_run_errorcheck_fn__1938000172_A) Ctor() {}
//line :206:1
func (t *A_arbace_go_run_errorcheck_fn__1938000172_A) Invoke_O_O__O(self, p1__1938000158_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_61; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000158_SHARP___1)) { return p1__1938000158_SHARP___1 } else { return nil } }

func A_arbace_go_run_errorcheck_fn__1938000174_A_New() *A_arbace_go_run_errorcheck_fn__1938000174_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000174_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_run_errorcheck_fn__1938000174_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_run_errorcheck_fn__1938000174_A) Invoke_O_O__O(self, p1__1938000159_SHARP___1 any) any { var temp__1927000414__auto____2 any = A_arbace_go_run_A_const_164.Invoke_O__O(p1__1938000159_SHARP___1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var u__3 any = temp__1927000414__auto____2; return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_run_A_const_65.Invoke_O__O(p1__1938000159_SHARP___1), u__3) } else { return nil } }




func A_arbace_go_run_errorcheck_fn__1938000177_A_New() *A_arbace_go_run_errorcheck_fn__1938000177_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000177_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_go_run_errorcheck_fn__1938000177_A) Ctor() {}
//line :213:1
func (t *A_arbace_go_run_errorcheck_fn__1938000177_A) Invoke_O_O__O(self, p1__1938000160_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_144; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000160_SHARP___1))).Ref() }
func A_arbace_go_run_errorcheck_fn__1938000179_A_New() *A_arbace_go_run_errorcheck_fn__1938000179_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000179_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_run_errorcheck_fn__1938000179_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_run_errorcheck_fn__1938000179_A) Invoke_O_O__O(self, p1__1938000161_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_145; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000161_SHARP___1))).Ref() }

func A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_New() *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A) Ctor() {}
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A) Invoke_O_O__O(self, s__1938000182__1 any) any { var tmp1 any = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_New_O_O(s__1938000182__1, self); var tmp2 *jrt.Class; var fncls__1521 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_fn_class; if fncls__1521 == nil { var fncls__1521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_fn_class = fncls__1521d; tmp2 = fncls__1521d } else { tmp2 = fncls__1521 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :216:1
func A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_New_O_O(p0, p1 any) *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A) Ctor_O_O(c__s__1938000182, c__iter__1938000181 any) { t.F_s__1938000182 = c__s__1938000182; t.F_iter__1938000181 = c__iter__1938000181 }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A) Invoke_O__O(self any) any { { var s__1938000182__1 any; var t_ any = t.F_s__1938000182; t.F_s__1938000182 = nil; s__1938000182__1 = t_; for { var temp__1927000414__auto____2 any; var root_1454 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = s__1938000182__1; if linked_1455 == nil { temp__1927000414__auto____2 = ifn_1456.Invoke_O__O(arg_1457) } else { temp__1927000414__auto____2 = linked_1455.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1454, arg_1457) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000182__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1458 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = s__1938000182__3; if linked_1459 == nil { tmp1 = ifn_1460.Invoke_O__O(arg_1461) } else { tmp1 = linked_1459.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1458, arg_1461) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1462 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = s__1938000182__3; if linked_1463 == nil { c__1927001037__auto____4 = ifn_1464.Invoke_O__O(arg_1465) } else { c__1927001037__auto____4 = linked_1463.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1462, arg_1465) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000184__6 any; var root_1466 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1467 == nil { b__1938000184__6 = ifn_1468.Invoke_O__O(arg_1469) } else { b__1938000184__6 = linked_1467.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1466, arg_1469) }; var tmp2 any = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_New_O_I_O(b__1938000184__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1480 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_fn_class; if fncls__1480 == nil { var fncls__1480d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_fn_class = fncls__1480d; tmp3 = fncls__1480d } else { tmp3 = fncls__1480 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1481 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any; var root_1486 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = b__1938000184__6; if linked_1487 == nil { arg_1484 = ifn_1488.Invoke_O__O(arg_1489) } else { arg_1484 = linked_1487.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1486, arg_1489) }; var arg_1485 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000181); var tmp5 any; var root_1490 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = s__1938000182__3; if linked_1491 == nil { tmp5 = ifn_1492.Invoke_O__O(arg_1493) } else { tmp5 = linked_1491.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1490, arg_1493) }; arg_1485 = tmp4.Invoke_O__O(tmp5); if linked_1482 == nil { return ifn_1483.Invoke_O_O__O(arg_1484, arg_1485) } else { return linked_1482.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1481, arg_1484, arg_1485) } } else { var root_1494 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any; var root_1499 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = b__1938000184__6; if linked_1500 == nil { arg_1497 = ifn_1501.Invoke_O__O(arg_1502) } else { arg_1497 = linked_1500.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1499, arg_1502) }; var arg_1498 any; if linked_1495 == nil { return ifn_1496.Invoke_O_O__O(arg_1497, arg_1498) } else { return linked_1495.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1494, arg_1497, arg_1498) } } } else { var fi__4 any; var root_1503 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = s__1938000182__3; if linked_1504 == nil { fi__4 = ifn_1505.Invoke_O__O(arg_1506) } else { fi__4 = linked_1504.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1503, arg_1506) }; var root_1507 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any; var tmp6 any = A_arbace_go_run_A_const_81.Invoke_O__O(fi__4); var tmp7 any; var root_1512 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = fi__4; var arg_1516 any = A_arbace_go_run_A_const_147; if linked_1513 == nil { tmp7 = ifn_1514.Invoke_O_O__O(arg_1515, arg_1516) } else { tmp7 = linked_1513.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1512, arg_1515, arg_1516) }; arg_1510 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_1511 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000181); var tmp9 any; var root_1517 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = s__1938000182__3; if linked_1518 == nil { tmp9 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp9 = linked_1518.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1517, arg_1520) }; arg_1511 = tmp8.Invoke_O__O(tmp9); if linked_1508 == nil { return ifn_1509.Invoke_O_O__O(arg_1510, arg_1511) } else { return linked_1508.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1507, arg_1510, arg_1511) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :216:1
func A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A) Ctor_O_I_O(c__b__1938000184 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000184 = c__b__1938000184; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :216:1
func (t *A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A) Invoke_O__O(self any) any { { var i__1938000183__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000183__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000183__1)); var root_1470 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = t.F_b__1938000184; var arg_1474 any; var tmp2 any = A_arbace_go_run_A_const_81.Invoke_O__O(fi__2); var tmp3 any; var root_1475 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = fi__2; var arg_1479 any = A_arbace_go_run_A_const_146; if linked_1476 == nil { tmp3 = ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { tmp3 = linked_1476.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) }; arg_1474 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_1471 == nil { ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { linked_1471.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) }; i__1938000183__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000183__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_run_errorcheck_vmsg__1938000191_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_vmsg__1938000191_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_vmsg__1938000191_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :217:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000191_A) Ctor_O_O_O(c__file_lang, c__lang, c__src any) { t.F_file_lang = c__file_lang; t.F_lang = c__lang; t.F_src = c__src }
//line :217:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000191_A) Invoke_O_O__O(self, e__1 any) any { var m__2 any = A_arbace_go_run_A_const_63.Invoke_O__O(e__1); var tmp1 any; var root_1523 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1525 lang.IFn; if

	linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = A_arbace_go_run_A_const_149; var arg_1527 any = m__2; if linked_1524 == nil { tmp1 = ifn_1525.Invoke_O_O__O(arg_1526, arg_1527) } else { tmp1 = linked_1524.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1523, arg_1526, arg_1527) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_file_lang); var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(A_arbace_go_run_A_const_65.Invoke_O__O(e__1))
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var fl__4 any = temp__1927000408__auto____3
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_46, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, m__2, nil, fl__4, nil)).Ref() } else {
				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_48, nil, Lit_49); var tmp4 any; var or__1927000174__auto____8 any = t.F_lang; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var root_1528 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = t.F_src; var arg_1532 any = A_arbace_go_run_A_const_150; if linked_1529 == nil { tmp4 = ifn_1530.Invoke_O_O__O(arg_1531, arg_1532) } else { tmp4 = linked_1529.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1528, arg_1531, arg_1532) } }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, m__2, nil, tmp4, nil)).Ref() } } else {
//line :219:1
					return m__2 } }




func A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_New_O(p0 any) *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A) Ctor_O(c__vmsg any) { t.F_vmsg = c__vmsg }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A) Invoke_O_O__O(self, s__1938000194__1 any) any { var tmp1 any = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_New_O_O_O(self, s__1938000194__1, t.F_vmsg); var tmp2 *jrt.Class; var fncls__1591 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_fn_class; if fncls__1591 == nil { var fncls__1591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_fn_class = fncls__1591d; tmp2 = fncls__1591d } else { tmp2 = fncls__1591 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :224:1
func A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A) Ctor_O_O_O(c__iter__1938000193, c__s__1938000194, c__vmsg any) { t.F_iter__1938000193 = c__iter__1938000193; t.F_s__1938000194 = c__s__1938000194; t.F_vmsg = c__vmsg }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A) Invoke_O__O(self any) any { { var s__1938000194__1 any; var t_ any = t.F_s__1938000194; t.F_s__1938000194 = nil; s__1938000194__1 = t_; for { var temp__1927000414__auto____2 any; var root_1534 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = s__1938000194__1; if linked_1535 == nil { temp__1927000414__auto____2 = ifn_1536.Invoke_O__O(arg_1537) } else { temp__1927000414__auto____2 = linked_1535.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1534, arg_1537) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000194__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1538 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = s__1938000194__3; if linked_1539 == nil { tmp1 = ifn_1540.Invoke_O__O(arg_1541) } else { tmp1 = linked_1539.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1538, arg_1541) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1542 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = s__1938000194__3; if linked_1543 == nil { c__1927001037__auto____4 = ifn_1544.Invoke_O__O(arg_1545) } else { c__1927001037__auto____4 = linked_1543.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1542, arg_1545) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000196__6 any; var root_1546 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1547 == nil { b__1938000196__6 = ifn_1548.Invoke_O__O(arg_1549) } else { b__1938000196__6 = linked_1547.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1546, arg_1549) }; var tmp2 any = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_New_O_I_O_O(b__1938000196__6, size__1927001038__auto____5, t.F_vmsg, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1555 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_fn_class; if fncls__1555 == nil { var fncls__1555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_fn_class = fncls__1555d; tmp3 = fncls__1555d } else { tmp3 = fncls__1555 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1556 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any; var root_1561 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = b__1938000196__6; if linked_1562 == nil { arg_1559 = ifn_1563.Invoke_O__O(arg_1564) } else { arg_1559 = linked_1562.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1561, arg_1564) }; var arg_1560 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000193); var tmp5 any; var root_1565 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = s__1938000194__3; if linked_1566 == nil { tmp5 = ifn_1567.Invoke_O__O(arg_1568) } else { tmp5 = linked_1566.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1565, arg_1568) }; arg_1560 = tmp4.Invoke_O__O(tmp5); if linked_1557 == nil { return ifn_1558.Invoke_O_O__O(arg_1559, arg_1560) } else { return linked_1557.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1556, arg_1559, arg_1560) } } else { var root_1569 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any; var root_1574 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = b__1938000196__6; if linked_1575 == nil { arg_1572 = ifn_1576.Invoke_O__O(arg_1577) } else { arg_1572 = linked_1575.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1574, arg_1577) }; var arg_1573 any; if linked_1570 == nil { return ifn_1571.Invoke_O_O__O(arg_1572, arg_1573) } else { return linked_1570.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1569, arg_1572, arg_1573) } } } else { var e__4 any; var root_1578 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = s__1938000194__3; if linked_1579 == nil { e__4 = ifn_1580.Invoke_O__O(arg_1581) } else { e__4 = linked_1579.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1578, arg_1581) }; var root_1582 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_65.Invoke_O__O(e__4), nil, A_arbace_go_run_A_const_66.Invoke_O__O(e__4), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__4))).Ref(); var arg_1586 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1938000193); var tmp7 any; var root_1587 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = s__1938000194__3; if linked_1588 == nil { tmp7 = ifn_1589.Invoke_O__O(arg_1590) } else { tmp7 = linked_1588.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1587, arg_1590) }; arg_1586 = tmp6.Invoke_O__O(tmp7); if linked_1583 == nil { return ifn_1584.Invoke_O_O__O(arg_1585, arg_1586) } else { return linked_1583.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1582, arg_1585, arg_1586) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :224:1
func A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A) Ctor_O_I_O_O(c__b__1938000196 any, c__size__1927001038__auto__ int32, c__vmsg, c__c__1927001037__auto__ any) { t.F_b__1938000196 = c__b__1938000196; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_vmsg = c__vmsg; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :224:1
func (t *A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A) Invoke_O__O(self any) any { { var i__1938000195__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000195__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000195__1)); var root_1550 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = t.F_b__1938000196; var arg_1554 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_65.Invoke_O__O(e__2), nil, A_arbace_go_run_A_const_66.Invoke_O__O(e__2), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__2))).Ref(); if linked_1551 == nil { ifn_1552.Invoke_O_O__O(arg_1553, arg_1554) } else { linked_1551.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1550, arg_1553, arg_1554) }; i__1938000195__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000195__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_errorcheck_pos__1938000203_A_New() *A_arbace_go_run_errorcheck_pos__1938000203_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_pos__1938000203_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_go_run_errorcheck_pos__1938000203_A) Ctor() {}
//line :230:1
func (t *A_arbace_go_run_errorcheck_pos__1938000203_A) Invoke_O_O__O(self, l__1 any) any { var vec__1938000204__2 any; var root_1601 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = A_arbace_go_run_A_const_155; var arg_1605 any = l__1; if linked_1602 == nil { vec__1938000204__2 = ifn_1603.Invoke_O_O__O(arg_1604, arg_1605) } else { vec__1938000204__2 = linked_1602.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1601, arg_1604, arg_1605) }; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000204__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000204__2, lang.RT_IntCast_J__I_NoInit(1), nil); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000204__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any; var or__1927000174__auto____6 any = f__4; _ = ___3; if
												jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = Lit_22 }; var tmp2 any = tmp1; var tmp3 any; if jrt.J2g_Truth(n__5) { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__5))).Ref() } else { tmp3 = A_arbace_go_run_A_const_156 }; return /*line :230:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }


















func A_arbace_go_run__main_A_New() *A_arbace_go_run__main_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_A{}; t.Ctor(); return t }
//line :249:1
func (t *A_arbace_go_run__main_A) Ctor() {}
//line :249:1
func (t *A_arbace_go_run__main_A) DoInvoke_O_O__O(self, args__0 any) any {






	var tmp1 any; var root_1788 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = args__0; if linked_1789 == nil { tmp1 = ifn_1790.Invoke_O__O(arg_1791) } else { tmp1 = linked_1789.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1788, arg_1791) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_1, tmp1) { var vec__1938000213__2 any; var tmp2 any = A_arbace_go_run__main_fn__1938000219_A_New_O(args__0); var tmp3 *jrt.Class; var fncls__1856 *jrt.Class = A_arbace_go_run__main_fn__1938000219_A_fn_class
		if fncls__1856 == nil { var fncls__1856d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_run__main_fn__1938000219_A_fn_class = fncls__1856d; tmp3 = fncls__1856d } else { tmp3 = fncls__1856 }; vec__1938000213__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :256:1
		var opts__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000213__2, lang.RT_IntCast_J__I_NoInit(0), nil); var args__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000213__2, lang.RT_IntCast_J__I_NoInit(1), nil); var lang__5 any = A_arbace_go_run_A_const_172.Invoke_O__O(opts__3); var vec__1938000216__6 any = args__4; var root__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000216__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_name__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000216__6, lang.RT_IntCast_J__I_NoInit(1), nil); var pf__9 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp5 any; var root_1857 any = A_arbace_go_run_A_const_166.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1859 lang.IFn









		if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = ns_name__8; if linked_1858 == nil { tmp5 = ifn_1859.Invoke_O__O(arg_1860) } else { tmp5 = linked_1858.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1857, arg_1860) }
//line :256:1
		pf__9 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, root__7, nil, tmp5)))










		if jrt.NN(jrt.File_Cast(pf__9)).IsFile__Z() { } else { var root_1896 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, A_arbace_go_run_fail_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = A_arbace_go_run_A_const_64; var arg_1900 any = Lit_4; var arg_1901 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__9)).Ref(); if linked_1897 == nil { ifn_1898.Invoke_O_O_O__O(arg_1899, arg_1900, arg_1901) } else { linked_1897.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1896, arg_1899, arg_1900, arg_1901) } }
		var tmp6 any = A_arbace_go_run__main_fn__1938000222_A_New_O_O_O_O(lang__5, pf__9, root__7, opts__3); var tmp7 *jrt.Class; var fncls__1895 *jrt.Class = A_arbace_go_run__main_fn__1938000222_A_fn_class; if fncls__1895 == nil { var fncls__1895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_run__main_fn__1938000222_A_fn_class = fncls__1895d; tmp7 = fncls__1895d } else { tmp7 = fncls__1895 }; jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O())) }
//line :249:1
	var vec__1938000224__2 any = args__0; var seq__1938000225__3 any; var root_1732 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1734 lang.IFn


























	if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = vec__1938000224__2; if linked_1733 == nil { seq__1938000225__3 = ifn_1734.Invoke_O__O(arg_1735) } else { seq__1938000225__3 = linked_1733.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1732, arg_1735) }
//line :249:1
	var first__1938000226__4 any; var root_1736 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1738 lang.IFn


























	if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = seq__1938000225__3; if linked_1737 == nil { first__1938000226__4 = ifn_1738.Invoke_O__O(arg_1739) } else { first__1938000226__4 = linked_1737.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1736, arg_1739) }
//line :249:1
	var seq__1938000225__5 any; var root_1740 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1742 lang.IFn


























	if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = seq__1938000225__3; if linked_1741 == nil { seq__1938000225__5 = ifn_1742.Invoke_O__O(arg_1743) } else { seq__1938000225__5 = linked_1741.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1740, arg_1743) }
//line :249:1
	var root__6 any = first__1938000226__4; var first__1938000226__7 any; var root_1744 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1746 lang.IFn


























	if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = seq__1938000225__5; if linked_1745 == nil { first__1938000226__7 = ifn_1746.Invoke_O__O(arg_1747) } else { first__1938000226__7 = linked_1745.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1744, arg_1747) }
//line :249:1
	var seq__1938000225__8 any; var root_1748 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1750 lang.IFn


























	if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = seq__1938000225__5; if linked_1749 == nil { seq__1938000225__8 = ifn_1750.Invoke_O__O(arg_1751) } else { seq__1938000225__8 = linked_1749.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1748, arg_1751) }
//line :249:1
	var ns_name__9 any = first__1938000226__7; var pargs__10 any = seq__1938000225__8; var tmp8 any
	var and__1927000168__auto____11 any = root__6


























	if jrt.J2g_Truth(and__1927000168__auto____11) { tmp8 = ns_name__9 } else { tmp8 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp8) { } else {
		var root_1910 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp10 any = A_arbace_go_run_A_const_20; var arg_1913 any = tmp9.Invoke_O_O__O(tmp10, A_arbace_go_run_A_const_21.Get__O()); if linked_1911 == nil { ifn_1912.Invoke_O__O(arg_1913) } else { linked_1911.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1910, arg_1913) }; var tmp11 any = A_arbace_go_run__main_fn__1938000227_A_New(); var tmp12 *jrt.Class; var fncls__1909 *jrt.Class = A_arbace_go_run__main_fn__1938000227_A_fn_class; if fncls__1909 == nil { var fncls__1909d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_run__main_fn__1938000227_A_fn_class = fncls__1909d; tmp12 = fncls__1909d } else { tmp12 = fncls__1909 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :249:1
	var pf__11 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp14 any; var root_1752 any = A_arbace_go_run_A_const_166.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1754 lang.IFn






























	if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = ns_name__9; if linked_1753 == nil { tmp14 = ifn_1754.Invoke_O__O(arg_1755) } else { tmp14 = linked_1753.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1752, arg_1755) }
//line :249:1
	pf__11 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, root__6, nil, tmp14)))































	if jrt.NN(jrt.File_Cast(pf__11)).IsFile__Z() { } else {
		var root_1919 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, A_arbace_go_run_fail_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = A_arbace_go_run_A_const_64; var arg_1923 any = Lit_4; var arg_1924 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__11)).Ref(); if linked_1920 == nil { ifn_1921.Invoke_O_O_O__O(arg_1922, arg_1923, arg_1924) } else { linked_1920.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1919, arg_1922, arg_1923, arg_1924) } }
//line :249:1
	var status__12 any; var tmp15 any = A_arbace_go_run__main_fn__1938000229_A_New_O_O_O(pargs__10, pf__11, root__6); var tmp16 *jrt.Class
	var fncls__1787 /*line :249:1*/*jrt.Class = A_arbace_go_run__main_fn__1938000229_A_fn_class

































	if fncls__1787 == nil { var fncls__1787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_run__main_fn__1938000229_A_fn_class = fncls__1787d; tmp16 = fncls__1787d } else { tmp16 = fncls__1787 }; status__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()








	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__12)); return nil }
//line :257:1
func A_arbace_go_run__main_fn__1938000219_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000219_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000219_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_go_run__main_fn__1938000219_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :257:1
func (t *A_arbace_go_run__main_fn__1938000219_A) Invoke_O__O(self any) any { { var opts__1 any = lang.PersistentArrayMap_EMPTY.Ref(); var as__2 any; var root_1792 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any; var t_ any = t.F_args; t.F_args = nil; arg_1795 = t_; if linked_1793 == nil { as__2 = ifn_1794.Invoke_O__O(arg_1795) } else { as__2 = linked_1793.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1792, arg_1795) }; L1: for { var G__1938000220__3_ any; var root_1796 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1798 lang.IFn
										if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = as__2; if linked_1797 == nil { G__1938000220__3_ = ifn_1798.Invoke_O__O(arg_1799) } else { G__1938000220__3_ = linked_1797.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1796, arg_1799) }; switch lang.Util_Hash_O__I_NoInit(G__1938000220__3_) >> 15 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_9) {


		var tmp1 any; var root_1801 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = opts__1; var arg_1805 any = A_arbace_go_run_A_const_171; var arg_1806 any = jrt.Boolean_TRUE.Ref(); if linked_1802 == nil { tmp1 = ifn_1803.Invoke_O_O_O__O(arg_1804, arg_1805, arg_1806) } else { tmp1 = linked_1802.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1801, arg_1804, arg_1805, arg_1806) }; var tmp2 any = tmp1; var tmp3 any; var root_1807 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = as__2; if linked_1808 == nil { tmp3 = ifn_1809.Invoke_O__O(arg_1810) } else { tmp3 = linked_1808.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1807, arg_1810) }; opts__1, as__2 = tmp2, tmp3; continue L1 }
//line :258:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_10) {
		var tmp4 any; var root_1811 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = opts__1; var arg_1815 any = A_arbace_go_run_A_const_172; var arg_1816 any; var root_1817 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = as__2; if linked_1818 == nil { arg_1816 = ifn_1819.Invoke_O__O(arg_1820) } else { arg_1816 = linked_1818.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1817, arg_1820) }; if linked_1812 == nil { tmp4 = ifn_1813.Invoke_O_O_O__O(arg_1814, arg_1815, arg_1816) } else { tmp4 = linked_1812.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1811, arg_1814, arg_1815, arg_1816) }; var tmp5 any = tmp4; var tmp6 any; var root_1821 any = A_arbace_go_run_A_const_173.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1825 any = as__2; if linked_1822 == nil { tmp6 = ifn_1823.Invoke_O_O__O(A_arbace_go_run_A_const_174, arg_1825) } else { tmp6 = linked_1822.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1821, 2, A_arbace_go_run_A_const_174, arg_1825) }; opts__1, as__2 = tmp5, tmp6; continue L1 }
//line :258:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_11) {



		var tmp7 any; var root_1826 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = opts__1; var arg_1830 any = A_arbace_go_run_A_const_175; var arg_1831 any; var root_1832 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = as__2; if linked_1833 == nil { arg_1831 = ifn_1834.Invoke_O__O(arg_1835) } else { arg_1831 = linked_1833.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1832, arg_1835) }; if linked_1827 == nil { tmp7 = ifn_1828.Invoke_O_O_O__O(arg_1829, arg_1830, arg_1831) } else { tmp7 = linked_1827.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1826, arg_1829, arg_1830, arg_1831) }; var tmp8 any = tmp7; var tmp9 any; var root_1836 any = A_arbace_go_run_A_const_173.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1840 any = as__2; if linked_1837 == nil { tmp9 = ifn_1838.Invoke_O_O__O(A_arbace_go_run_A_const_174, arg_1840) } else { tmp9 = linked_1837.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1836, 2, A_arbace_go_run_A_const_174, arg_1840) }; opts__1, as__2 = tmp8, tmp9; continue L1 }
//line :258:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000220__3_, Lit_12) {

		var tmp10 any; var root_1841 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = opts__1; var arg_1845 any = A_arbace_go_run_A_const_176; var arg_1846 any; var tmp11 any; var root_1847 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = as__2; if linked_1848 == nil { tmp11 = ifn_1849.Invoke_O__O(arg_1850) } else { tmp11 = linked_1848.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1847, arg_1850) }; arg_1846 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp11))).Ref(); if linked_1842 == nil { tmp10 = ifn_1843.Invoke_O_O_O__O(arg_1844, arg_1845, arg_1846) } else { tmp10 = linked_1842.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1841, arg_1844, arg_1845, arg_1846) }; var tmp12 any = tmp10; var tmp13 any; var root_1851 any = A_arbace_go_run_A_const_173.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1855 any = as__2; if linked_1852 == nil { tmp13 = ifn_1853.Invoke_O_O__O(A_arbace_go_run_A_const_174, arg_1855) } else { tmp13 = linked_1852.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1851, 2, A_arbace_go_run_A_const_174, arg_1855) }; opts__1, as__2 = tmp12, tmp13; continue L1 }
//line :258:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__1, as__2) } }; /*line :257:1*/panic("j2g: unreachable") }










func A_arbace_go_run__main_fn__1938000222_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run__main_fn__1938000222_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000222_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :268:1
func (t *A_arbace_go_run__main_fn__1938000222_A) Ctor_O_O_O_O(c__lang, c__pf, c__root, c__opts any) { t.F_lang = c__lang; t.F_pf = c__pf; t.F_root = c__root; t.F_opts = c__opts }
//line :268:1
func (t *A_arbace_go_run__main_fn__1938000222_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1861 any = A_arbace_go_run_A_const_177.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, A_arbace_go_run_errorcheck_A_fn_class); var ifn_1863 lang.IFn; if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any; var t_ any = t.F_root; t.F_root = nil; arg_1864 = t_; var arg_1865 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1865 = t__2; var arg_1866 any; var t__3 any = t.F_lang; t.F_lang = nil; arg_1866 = t__3; var arg_1867 any = A_arbace_go_run_A_const_176.Invoke_O__O(t.F_opts); var arg_1868 any = A_arbace_go_run_A_const_171.Invoke_O__O(t.F_opts); var arg_1869 any; var tmp2 *lang.Keyword = A_arbace_go_run_A_const_175; var tmp3 any; var t__4 any = t.F_opts; t.F_opts = nil; tmp3 = t__4; arg_1869 = tmp2.Invoke_O__O(tmp3); if linked_1862 == nil { tmp1 = ifn_1863.Invoke_O_O_O_O_O_O__O(arg_1864, arg_1865, arg_1866, arg_1867, arg_1868, arg_1869) } else { tmp1 = linked_1862.(*A_arbace_go_run_errorcheck_A).Invoke_O_O_O_O_O_O_O__O(root_1861, arg_1864, arg_1865, arg_1866, arg_1867, arg_1868, arg_1869) } }; return nil }(); if tmp4 != nil { if true { var ex__3 jrt.Throwable_I = tmp4; var d__4 any; var root_1870 any = A_arbace_go_run_A_const_93.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1872 lang.IFn

	if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = ex__3; if linked_1871 == nil { d__4 = ifn_1872.Invoke_O__O(arg_1873) } else { d__4 = linked_1871.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1870, arg_1873) }
//line :268:1
	var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_168.Invoke_O__O(d__4)


	if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
		if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp5 any; var root_1874 any = A_arbace_go_run_A_const_169.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = m__7; var arg_1878 any = Lit_13; if linked_1875 == nil { tmp5 = ifn_1876.Invoke_O_O__O(arg_1877, arg_1878) } else { tmp5 = linked_1875.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1874, arg_1877, arg_1878) }; if jrt.J2g_Truth(tmp5) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
	if jrt.J2g_Truth(u__5) {
		var root_1879 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, A_arbace_go_run_fail_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = A_arbace_go_run_A_const_49; var arg_1883 any = Lit_14; var arg_1884 any = u__5; if linked_1880 == nil { tmp1 = ifn_1881.Invoke_O_O_O__O(arg_1882, arg_1883, arg_1884) } else { tmp1 = linked_1880.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1879, arg_1882, arg_1883, arg_1884) } } else {
			var root_1885 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, A_arbace_go_run_fail_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = A_arbace_go_run_A_const_64; var arg_1889 any = Lit_4; var arg_1890 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil); var tmp7 any; var root_1891 any = A_arbace_go_run_A_const_170.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = ex__3; if linked_1892 == nil { tmp7 = ifn_1893.Invoke_O__O(arg_1894) } else { tmp7 = linked_1892.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1891, arg_1894) }; arg_1890 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp7)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1886 == nil { tmp1 = ifn_1887.Invoke_O_O_O__O(arg_1888, arg_1889, arg_1890) } else { tmp1 = linked_1886.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1885, arg_1888, arg_1889, arg_1890) } } } }; return tmp1 }


func A_arbace_go_run__main_fn__1938000227_A_New() *A_arbace_go_run__main_fn__1938000227_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000227_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_go_run__main_fn__1938000227_A) Ctor() {}
//line :278:1
func (t *A_arbace_go_run__main_fn__1938000227_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_16); return nil }(); var root_1906 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; if linked_1907 == nil { ifn_1908.Invoke__O() } else { linked_1907.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1906) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_go_run__main_fn__1938000229_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run__main_fn__1938000229_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000229_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :283:1
func (t *A_arbace_go_run__main_fn__1938000229_A) Ctor_O_O_O(c__pargs, c__pf, c__root any) { t.F_pargs = c__pargs; t.F_pf = c__pf; t.F_root = c__root }
//line :283:1
func (t *A_arbace_go_run__main_fn__1938000229_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_1756 any = A_arbace_go_run_A_const_167.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, A_arbace_go_run_run_A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any; var t_ any = t.F_root; t.F_root = nil; arg_1759 = t_; var arg_1760 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1760 = t__2; var arg_1761 any; var t__3 any = t.F_pargs; t.F_pargs = nil; arg_1761 = t__3; if linked_1757 == nil { tmp1 = ifn_1758.Invoke_O_O_O__O(arg_1759, arg_1760, arg_1761) } else { tmp1 = linked_1757.(*A_arbace_go_run_run_A).Invoke_O_O_O_O__O(root_1756, arg_1759, arg_1760, arg_1761) } }
//line :283:1
	return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var d__4 any; var root_1762 any = A_arbace_go_run_A_const_93.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1764 lang.IFn


		if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = ex__3; if linked_1763 == nil { d__4 = ifn_1764.Invoke_O__O(arg_1765) } else { d__4 = linked_1763.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1762, arg_1765) }
//line :283:1
		var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_168.Invoke_O__O(d__4)



		if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp3 any; var root_1766 any = A_arbace_go_run_A_const_169.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = m__7; var arg_1770 any = Lit_13; if linked_1767 == nil { tmp3 = ifn_1768.Invoke_O_O__O(arg_1769, arg_1770) } else { tmp3 = linked_1767.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1766, arg_1769, arg_1770) }; if jrt.J2g_Truth(tmp3) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
		if jrt.J2g_Truth(u__5) {
			var root_1771 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, A_arbace_go_run_fail_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = A_arbace_go_run_A_const_49; var arg_1775 any = Lit_14; var arg_1776 any = u__5; if linked_1772 == nil { tmp1 = ifn_1773.Invoke_O_O_O__O(arg_1774, arg_1775, arg_1776) } else { tmp1 = linked_1772.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1771, arg_1774, arg_1775, arg_1776) } } else {
				var root_1777 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, A_arbace_go_run_fail_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = A_arbace_go_run_A_const_64; var arg_1781 any = Lit_4; var arg_1782 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil); var tmp5 any; var root_1783 any = A_arbace_go_run_A_const_170.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = ex__3; if linked_1784 == nil { tmp5 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp5 = linked_1784.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1783, arg_1786) }; arg_1782 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp5)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1778 == nil { tmp1 = ifn_1779.Invoke_O_O_O__O(arg_1780, arg_1781, arg_1782) } else { tmp1 = linked_1778.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1777, arg_1780, arg_1781, arg_1782) } } } }; return tmp1 }































































































type A_arbace_go_run_A struct{ jrt.Object }

var A_arbace_go_run_A_const_pool *jrt.RefArray

var A_arbace_go_run_A_const_0 *lang.Var

var A_arbace_go_run_A_const_1 any

var A_arbace_go_run_A_const_2 *lang.Var

var A_arbace_go_run_A_const_3 any

var A_arbace_go_run_A_const_4 any

var A_arbace_go_run_A_const_5 any

var A_arbace_go_run_A_const_6 any

var A_arbace_go_run_A_const_7 *lang.Var

var A_arbace_go_run_A_const_8 *lang.Var

var A_arbace_go_run_A_const_9 *lang.Var

var A_arbace_go_run_A_const_10 *lang.Var

var A_arbace_go_run_A_const_11 any

var A_arbace_go_run_A_const_12 *lang.Var

var A_arbace_go_run_A_const_13 *lang.Var

var A_arbace_go_run_A_const_14 *lang.Var

var A_arbace_go_run_A_const_15 *lang.Var

var A_arbace_go_run_A_const_16 *lang.Var

var A_arbace_go_run_A_const_17 *lang.Var

var A_arbace_go_run_A_const_18 *lang.Var

var A_arbace_go_run_A_const_19 *lang.Var

var A_arbace_go_run_A_const_20 *lang.Var

var A_arbace_go_run_A_const_21 *lang.Var

var A_arbace_go_run_A_const_22 *lang.Var

var A_arbace_go_run_A_const_23 *lang.Var

var A_arbace_go_run_A_const_24 *lang.Var

var A_arbace_go_run_A_const_25 *lang.Var

var A_arbace_go_run_A_const_26 *lang.Var

var A_arbace_go_run_A_const_27 *lang.Var

var A_arbace_go_run_A_const_28 any

var A_arbace_go_run_A_const_29 *lang.Keyword

var A_arbace_go_run_A_const_30 *lang.Var

var A_arbace_go_run_A_const_31 *lang.Var

var A_arbace_go_run_A_const_32 *lang.Var

var A_arbace_go_run_A_const_33 *lang.Var

var A_arbace_go_run_A_const_34 *lang.Var

var A_arbace_go_run_A_const_35 *lang.Var

var A_arbace_go_run_A_const_36 *lang.Var

var A_arbace_go_run_A_const_37 *lang.Var

var A_arbace_go_run_A_const_38 *lang.Var

var A_arbace_go_run_A_const_39 *lang.Var

var A_arbace_go_run_A_const_40 *lang.Var

var A_arbace_go_run_A_const_41 *lang.Var

var A_arbace_go_run_A_const_42 *lang.Var

var A_arbace_go_run_A_const_43 *lang.Var

var A_arbace_go_run_A_const_44 *lang.Var

var A_arbace_go_run_A_const_45 *lang.Var

var A_arbace_go_run_A_const_46 *lang.Var

var A_arbace_go_run_A_const_47 any

var A_arbace_go_run_A_const_48 *lang.Var

var A_arbace_go_run_A_const_49 any

var A_arbace_go_run_A_const_50 *lang.Keyword

var A_arbace_go_run_A_const_51 *lang.Keyword

var A_arbace_go_run_A_const_52 *lang.Keyword

var A_arbace_go_run_A_const_53 *lang.Var

var A_arbace_go_run_A_const_54 *lang.Var

var A_arbace_go_run_A_const_55 *lang.Keyword

var A_arbace_go_run_A_const_56 *lang.Var

var A_arbace_go_run_A_const_57 *lang.Var

var A_arbace_go_run_A_const_58 *lang.Keyword

var A_arbace_go_run_A_const_59 *lang.Var

var A_arbace_go_run_A_const_60 *lang.Var

var A_arbace_go_run_A_const_61 *lang.Keyword

var A_arbace_go_run_A_const_62 *lang.Keyword

var A_arbace_go_run_A_const_63 *lang.Keyword

var A_arbace_go_run_A_const_64 any

var A_arbace_go_run_A_const_65 *lang.Keyword

var A_arbace_go_run_A_const_66 *lang.Keyword

var A_arbace_go_run_A_const_67 any

var A_arbace_go_run_A_const_68 *lang.Var

var A_arbace_go_run_A_const_69 *lang.Var

var A_arbace_go_run_A_const_70 *lang.Var

var A_arbace_go_run_A_const_71 *lang.Var

var A_arbace_go_run_A_const_72 any

var A_arbace_go_run_A_const_73 *lang.Var

var A_arbace_go_run_A_const_74 *lang.Var

var A_arbace_go_run_A_const_75 *lang.Keyword

var A_arbace_go_run_A_const_76 *lang.Var

var A_arbace_go_run_A_const_77 *lang.Var

var A_arbace_go_run_A_const_78 *lang.Var

var A_arbace_go_run_A_const_79 *lang.Var

var A_arbace_go_run_A_const_80 *lang.Var

var A_arbace_go_run_A_const_81 *lang.Keyword

var A_arbace_go_run_A_const_82 *lang.Keyword

var A_arbace_go_run_A_const_83 *lang.Var

var A_arbace_go_run_A_const_84 *lang.Keyword

var A_arbace_go_run_A_const_85 *lang.Keyword

var A_arbace_go_run_A_const_86 *lang.Keyword

var A_arbace_go_run_A_const_87 *lang.Keyword

var A_arbace_go_run_A_const_88 *lang.Keyword

var A_arbace_go_run_A_const_89 *lang.Keyword

var A_arbace_go_run_A_const_90 *lang.Var

var A_arbace_go_run_A_const_91 any

var A_arbace_go_run_A_const_92 *lang.Keyword

var A_arbace_go_run_A_const_93 *lang.Var

var A_arbace_go_run_A_const_94 *lang.Var

var A_arbace_go_run_A_const_95 *lang.Var

var A_arbace_go_run_A_const_96 *lang.Var

var A_arbace_go_run_A_const_97 *lang.Keyword

var A_arbace_go_run_A_const_98 *lang.Keyword

var A_arbace_go_run_A_const_99 *lang.Var

var A_arbace_go_run_A_const_100 *lang.Var

var A_arbace_go_run_A_const_101 *lang.Var

var A_arbace_go_run_A_const_102 *lang.Var

var A_arbace_go_run_A_const_103 *lang.Var

var A_arbace_go_run_A_const_104 *lang.Var

var A_arbace_go_run_A_const_105 *lang.Var

var A_arbace_go_run_A_const_106 *lang.Var

var A_arbace_go_run_A_const_107 *lang.Var

var A_arbace_go_run_A_const_108 *lang.Var

var A_arbace_go_run_A_const_109 *lang.Keyword

var A_arbace_go_run_A_const_110 *lang.Var

var A_arbace_go_run_A_const_111 *lang.Var

var A_arbace_go_run_A_const_112 *lang.Var

var A_arbace_go_run_A_const_113 *lang.Var

var A_arbace_go_run_A_const_114 *lang.Var

var A_arbace_go_run_A_const_115 *lang.Keyword

var A_arbace_go_run_A_const_116 *lang.Var

var A_arbace_go_run_A_const_117 *lang.Var

var A_arbace_go_run_A_const_118 *lang.Var

var A_arbace_go_run_A_const_119 *lang.Var

var A_arbace_go_run_A_const_120 *lang.Var

var A_arbace_go_run_A_const_121 *lang.Var

var A_arbace_go_run_A_const_122 *lang.Var

var A_arbace_go_run_A_const_123 *lang.Var

var A_arbace_go_run_A_const_124 *lang.Var

var A_arbace_go_run_A_const_125 *lang.Var

var A_arbace_go_run_A_const_126 *lang.Keyword

var A_arbace_go_run_A_const_127 *lang.Var

var A_arbace_go_run_A_const_128 *lang.Var

var A_arbace_go_run_A_const_129 *lang.Keyword

var A_arbace_go_run_A_const_130 *lang.Var

var A_arbace_go_run_A_const_131 *lang.Var

var A_arbace_go_run_A_const_132 any

var A_arbace_go_run_A_const_133 *lang.Keyword

var A_arbace_go_run_A_const_134 *lang.Var

var A_arbace_go_run_A_const_135 *lang.Keyword

var A_arbace_go_run_A_const_136 *lang.Keyword

var A_arbace_go_run_A_const_137 *lang.Var

var A_arbace_go_run_A_const_138 *lang.Var

var A_arbace_go_run_A_const_139 any

var A_arbace_go_run_A_const_140 any

var A_arbace_go_run_A_const_141 *lang.Var

var A_arbace_go_run_A_const_142 any

var A_arbace_go_run_A_const_143 *lang.Keyword

var A_arbace_go_run_A_const_144 *lang.Keyword

var A_arbace_go_run_A_const_145 *lang.Keyword

var A_arbace_go_run_A_const_146 any

var A_arbace_go_run_A_const_147 any

var A_arbace_go_run_A_const_148 *lang.Var

var A_arbace_go_run_A_const_149 any

var A_arbace_go_run_A_const_150 any

var A_arbace_go_run_A_const_151 any

var A_arbace_go_run_A_const_152 *lang.Keyword

var A_arbace_go_run_A_const_153 *lang.Var

var A_arbace_go_run_A_const_154 any

var A_arbace_go_run_A_const_155 any

var A_arbace_go_run_A_const_156 any

var A_arbace_go_run_A_const_157 *lang.Var

var A_arbace_go_run_A_const_158 any

var A_arbace_go_run_A_const_159 *lang.Var

var A_arbace_go_run_A_const_160 *lang.Var

var A_arbace_go_run_A_const_161 any

var A_arbace_go_run_A_const_162 *lang.Var

var A_arbace_go_run_A_const_163 any

var A_arbace_go_run_A_const_164 *lang.Keyword

var A_arbace_go_run_A_const_165 *lang.Keyword

var A_arbace_go_run_A_const_166 *lang.Var

var A_arbace_go_run_A_const_167 *lang.Var

var A_arbace_go_run_A_const_168 *lang.Keyword

var A_arbace_go_run_A_const_169 *lang.Var

var A_arbace_go_run_A_const_170 *lang.Var

var A_arbace_go_run_A_const_171 *lang.Keyword

var A_arbace_go_run_A_const_172 *lang.Keyword

var A_arbace_go_run_A_const_173 *lang.Var

var A_arbace_go_run_A_const_174 any

var A_arbace_go_run_A_const_175 *lang.Keyword

var A_arbace_go_run_A_const_176 *lang.Keyword

var A_arbace_go_run_A_const_177 *lang.Var

var A_arbace_go_run_A_init jrt.ClassInit

func A_arbace_go_run_A_Init() { if !A_arbace_go_run_A_init.Done() { A_arbace_go_run_A_init.Run(A_arbace_go_run_A_clinit) } }

func A_arbace_go_run_A_clinit() { A_arbace_go_run_A_clinit_p0(); A_arbace_go_run_A_clinit_p1(); A_arbace_go_run_A_clinit_p2(); A_arbace_go_run_A_clinit_p3(); A_arbace_go_run_A_clinit_p4(); A_arbace_go_run_A_clinit_p5(); A_arbace_go_run_A_clinit_p6(); A_arbace_go_run_A_clinit_p7(); A_arbace_go_run_A_clinit_p8(); A_arbace_go_run_A_clinit_p9(); A_arbace_go_run_A_clinit_p10(); A_arbace_go_run_A_clinit_p11(); A_arbace_go_run_A_clinit_p12(); A_arbace_go_run_A_clinit_p13(); A_arbace_go_run_A_clinit_p14() }

func A_arbace_go_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 239); A_arbace_go_run_A_const_0 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[61]); A_arbace_go_run_A_const_1 = A_arbace_go_run_A_const_pool.A[62]; A_arbace_go_run_A_const_2 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[63]); A_arbace_go_run_A_const_3 = A_arbace_go_run_A_const_pool.A[64]; A_arbace_go_run_A_const_4 = A_arbace_go_run_A_const_pool.A[65]; A_arbace_go_run_A_const_5 = A_arbace_go_run_A_const_pool.A[66]; A_arbace_go_run_A_const_6 = A_arbace_go_run_A_const_pool.A[67]; A_arbace_go_run_A_const_7 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[68]); A_arbace_go_run_A_const_8 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[69]); A_arbace_go_run_A_const_9 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[70]); A_arbace_go_run_A_const_10 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[71]); A_arbace_go_run_A_const_11 = A_arbace_go_run_A_const_pool.A[72] }

func A_arbace_go_run_A_clinit_p1() { A_arbace_go_run_A_const_12 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[73]); A_arbace_go_run_A_const_13 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[74]); A_arbace_go_run_A_const_14 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[75]); A_arbace_go_run_A_const_15 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[76]); A_arbace_go_run_A_const_16 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[77]); A_arbace_go_run_A_const_17 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[78]); A_arbace_go_run_A_const_18 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[79]); A_arbace_go_run_A_const_19 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[80]); A_arbace_go_run_A_const_20 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[81]); A_arbace_go_run_A_const_21 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[82]); A_arbace_go_run_A_const_22 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[83]); A_arbace_go_run_A_const_23 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[84]) }

func A_arbace_go_run_A_clinit_p2() { A_arbace_go_run_A_const_24 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[85]); A_arbace_go_run_A_const_25 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[86]); A_arbace_go_run_A_const_26 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[87]); A_arbace_go_run_A_const_27 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[88]); A_arbace_go_run_A_const_28 = A_arbace_go_run_A_const_pool.A[89]; A_arbace_go_run_A_const_29 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[90]); A_arbace_go_run_A_const_30 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[91]); A_arbace_go_run_A_const_31 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[92]); A_arbace_go_run_A_const_32 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[93]); A_arbace_go_run_A_const_33 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[94]); A_arbace_go_run_A_const_34 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[95]); A_arbace_go_run_A_const_35 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[96]) }

func A_arbace_go_run_A_clinit_p3() { A_arbace_go_run_A_const_36 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[97]); A_arbace_go_run_A_const_37 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[98]); A_arbace_go_run_A_const_38 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[99]); A_arbace_go_run_A_const_39 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[100]); A_arbace_go_run_A_const_40 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[101]); A_arbace_go_run_A_const_41 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[102]); A_arbace_go_run_A_const_42 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[103]); A_arbace_go_run_A_const_43 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[104]); A_arbace_go_run_A_const_44 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[105]); A_arbace_go_run_A_const_45 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[106]); A_arbace_go_run_A_const_46 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[107]); A_arbace_go_run_A_const_47 = A_arbace_go_run_A_const_pool.A[108] }

func A_arbace_go_run_A_clinit_p4() { A_arbace_go_run_A_const_48 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[109]); A_arbace_go_run_A_const_49 = A_arbace_go_run_A_const_pool.A[110]; A_arbace_go_run_A_const_50 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[111]); A_arbace_go_run_A_const_51 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[112]); A_arbace_go_run_A_const_52 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[113]); A_arbace_go_run_A_const_53 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[114]); A_arbace_go_run_A_const_54 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[115]); A_arbace_go_run_A_const_55 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[116]); A_arbace_go_run_A_const_56 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[117]); A_arbace_go_run_A_const_57 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[118]); A_arbace_go_run_A_const_58 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[119]); A_arbace_go_run_A_const_59 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[120]) }

func A_arbace_go_run_A_clinit_p5() { A_arbace_go_run_A_const_60 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[121]); A_arbace_go_run_A_const_61 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[122]); A_arbace_go_run_A_const_62 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[123]); A_arbace_go_run_A_const_63 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[124]); A_arbace_go_run_A_const_64 = A_arbace_go_run_A_const_pool.A[125]; A_arbace_go_run_A_const_65 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[126]); A_arbace_go_run_A_const_66 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[127]); A_arbace_go_run_A_const_67 = A_arbace_go_run_A_const_pool.A[128]; A_arbace_go_run_A_const_68 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[129]); A_arbace_go_run_A_const_69 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[130]); A_arbace_go_run_A_const_70 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[131]); A_arbace_go_run_A_const_71 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[132]) }

func A_arbace_go_run_A_clinit_p6() { A_arbace_go_run_A_const_72 = A_arbace_go_run_A_const_pool.A[133]; A_arbace_go_run_A_const_73 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[134]); A_arbace_go_run_A_const_74 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[135]); A_arbace_go_run_A_const_75 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[136]); A_arbace_go_run_A_const_76 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[137]); A_arbace_go_run_A_const_77 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[138]); A_arbace_go_run_A_const_78 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[139]); A_arbace_go_run_A_const_79 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[140]); A_arbace_go_run_A_const_80 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[141]); A_arbace_go_run_A_const_81 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[142]); A_arbace_go_run_A_const_82 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[143]); A_arbace_go_run_A_const_83 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[144]) }

func A_arbace_go_run_A_clinit_p7() { A_arbace_go_run_A_const_84 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[145]); A_arbace_go_run_A_const_85 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[146]); A_arbace_go_run_A_const_86 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[147]); A_arbace_go_run_A_const_87 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[148]); A_arbace_go_run_A_const_88 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[149]); A_arbace_go_run_A_const_89 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[150]); A_arbace_go_run_A_const_90 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[151]); A_arbace_go_run_A_const_91 = A_arbace_go_run_A_const_pool.A[152]; A_arbace_go_run_A_const_92 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[153]); A_arbace_go_run_A_const_93 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[154]); A_arbace_go_run_A_const_94 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[155]); A_arbace_go_run_A_const_95 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[156]) }

func A_arbace_go_run_A_clinit_p8() { A_arbace_go_run_A_const_96 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[157]); A_arbace_go_run_A_const_97 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[158]); A_arbace_go_run_A_const_98 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[159]); A_arbace_go_run_A_const_99 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[160]); A_arbace_go_run_A_const_100 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[161]); A_arbace_go_run_A_const_101 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[162]); A_arbace_go_run_A_const_102 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[163]); A_arbace_go_run_A_const_103 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[164]); A_arbace_go_run_A_const_104 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[165]); A_arbace_go_run_A_const_105 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[166]); A_arbace_go_run_A_const_106 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[167]); A_arbace_go_run_A_const_107 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[168]) }

func A_arbace_go_run_A_clinit_p9() { A_arbace_go_run_A_const_108 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[169]); A_arbace_go_run_A_const_109 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[170]); A_arbace_go_run_A_const_110 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[171]); A_arbace_go_run_A_const_111 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[172]); A_arbace_go_run_A_const_112 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[173]); A_arbace_go_run_A_const_113 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[174]); A_arbace_go_run_A_const_114 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[175]); A_arbace_go_run_A_const_115 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[176]); A_arbace_go_run_A_const_116 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[177]); A_arbace_go_run_A_const_117 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[178]); A_arbace_go_run_A_const_118 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[179]); A_arbace_go_run_A_const_119 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[180]) }

func A_arbace_go_run_A_clinit_p10() { A_arbace_go_run_A_const_120 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[181]); A_arbace_go_run_A_const_121 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[182]); A_arbace_go_run_A_const_122 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[183]); A_arbace_go_run_A_const_123 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[184]); A_arbace_go_run_A_const_124 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[185]); A_arbace_go_run_A_const_125 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[186]); A_arbace_go_run_A_const_126 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[187]); A_arbace_go_run_A_const_127 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[188]); A_arbace_go_run_A_const_128 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[189]); A_arbace_go_run_A_const_129 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[190]); A_arbace_go_run_A_const_130 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[191]); A_arbace_go_run_A_const_131 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[192]) }

func A_arbace_go_run_A_clinit_p11() { A_arbace_go_run_A_const_132 = A_arbace_go_run_A_const_pool.A[193]; A_arbace_go_run_A_const_133 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[194]); A_arbace_go_run_A_const_134 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[195]); A_arbace_go_run_A_const_135 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[196]); A_arbace_go_run_A_const_136 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[197]); A_arbace_go_run_A_const_137 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[198]); A_arbace_go_run_A_const_138 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[199]); A_arbace_go_run_A_const_139 = A_arbace_go_run_A_const_pool.A[200]; A_arbace_go_run_A_const_140 = A_arbace_go_run_A_const_pool.A[201]; A_arbace_go_run_A_const_141 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[202]); A_arbace_go_run_A_const_142 = A_arbace_go_run_A_const_pool.A[203]; A_arbace_go_run_A_const_143 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[204]); A_arbace_go_run_A_const_144 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[205]) }

func A_arbace_go_run_A_clinit_p12() { A_arbace_go_run_A_const_145 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[206]); A_arbace_go_run_A_const_146 = A_arbace_go_run_A_const_pool.A[207]; A_arbace_go_run_A_const_147 = A_arbace_go_run_A_const_pool.A[208]; A_arbace_go_run_A_const_148 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[209]); A_arbace_go_run_A_const_149 = A_arbace_go_run_A_const_pool.A[210]; A_arbace_go_run_A_const_150 = A_arbace_go_run_A_const_pool.A[211]; A_arbace_go_run_A_const_151 = A_arbace_go_run_A_const_pool.A[212]; A_arbace_go_run_A_const_152 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[213]); A_arbace_go_run_A_const_153 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[214]); A_arbace_go_run_A_const_154 = A_arbace_go_run_A_const_pool.A[215]; A_arbace_go_run_A_const_155 = A_arbace_go_run_A_const_pool.A[216]; A_arbace_go_run_A_const_156 = A_arbace_go_run_A_const_pool.A[217]; A_arbace_go_run_A_const_157 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[218]); A_arbace_go_run_A_const_158 = A_arbace_go_run_A_const_pool.A[219] }

func A_arbace_go_run_A_clinit_p13() { A_arbace_go_run_A_const_159 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[220]); A_arbace_go_run_A_const_160 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[221]); A_arbace_go_run_A_const_161 = A_arbace_go_run_A_const_pool.A[222]; A_arbace_go_run_A_const_162 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[223]); A_arbace_go_run_A_const_163 = A_arbace_go_run_A_const_pool.A[224]; A_arbace_go_run_A_const_164 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[225]); A_arbace_go_run_A_const_165 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[226]); A_arbace_go_run_A_const_166 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[227]); A_arbace_go_run_A_const_167 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[228]); A_arbace_go_run_A_const_168 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[229]); A_arbace_go_run_A_const_169 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[230]); A_arbace_go_run_A_const_170 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[231]) }

func A_arbace_go_run_A_clinit_p14() { A_arbace_go_run_A_const_171 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[232]); A_arbace_go_run_A_const_172 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[233]); A_arbace_go_run_A_const_173 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[234]); A_arbace_go_run_A_const_174 = A_arbace_go_run_A_const_pool.A[235]; A_arbace_go_run_A_const_175 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[236]); A_arbace_go_run_A_const_176 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[237]); A_arbace_go_run_A_const_177 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[238]) }

func A_arbace_go_run_A_New() *A_arbace_go_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_A) Ctor() {}

func (t *A_arbace_go_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_A_class }

func (t *A_arbace_go_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_A); return ok }

func A_arbace_go_run_A_Cast(x any) *A_arbace_go_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_A_class)) }; return v }



type A_arbace_go_run__main_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000219_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_run__main_fn__1938000219_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000222_A struct{ j2g_header uint64; F_lang, F_pf, F_root, F_opts any }

var A_arbace_go_run__main_fn__1938000222_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000227_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000227_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000229_A struct{ j2g_header uint64; F_pargs, F_pf, F_root any }

var A_arbace_go_run__main_fn__1938000229_A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__fn__1938000065_A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A struct{ j2g_header uint64; F_iter__1938000020, F_s__1938000021 any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A struct{ j2g_header uint64; F_b__1938000023 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_root_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_root_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000163_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000163_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000170_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000170_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000172_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000172_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000174_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000174_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000177_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000177_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000179_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000179_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A struct{ j2g_header uint64; F_s__1938000182, F_iter__1938000181 any }

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A struct{ j2g_header uint64; F_b__1938000184 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A struct{ j2g_header uint64; F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A struct{ j2g_header uint64; F_iter__1938000193, F_s__1938000194, F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A struct{ j2g_header uint64; F_b__1938000196 any; F_size__1927001038__auto__ int32; F_vmsg, F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_pos__1938000203_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_pos__1938000203_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_vmsg__1938000191_A struct{ j2g_header uint64; F_file_lang, F_lang, F_src any }

var A_arbace_go_run_errorcheck_vmsg__1938000191_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000004_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000004_A_New() *A_arbace_go_run_eval1938000004_A { t := &A_arbace_go_run_eval1938000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000004_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000004_A_class }

func (t *A_arbace_go_run_eval1938000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000004_A); return ok }

func A_arbace_go_run_eval1938000004_A_Cast(x any) *A_arbace_go_run_eval1938000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000004_A_class)) }; return v }



type A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000008_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000008_A_New() *A_arbace_go_run_eval1938000008_A { t := &A_arbace_go_run_eval1938000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000008_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000008_A_class }

func (t *A_arbace_go_run_eval1938000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000008_A); return ok }

func A_arbace_go_run_eval1938000008_A_Cast(x any) *A_arbace_go_run_eval1938000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000008_A_class)) }; return v }



type A_arbace_go_run_eval1938000008_fn__1938000009_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_fn_class *jrt.Class



type A_arbace_go_run_fail_A struct{ j2g_header uint64 }

var A_arbace_go_run_fail_A_fn_class *jrt.Class



type A_arbace_go_run_fail_fn__1938000012_A struct{ j2g_header uint64; F_kind, F_msg any }

var A_arbace_go_run_fail_fn__1938000012_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_A struct{ j2g_header uint64 }

var A_arbace_go_run_imports_of_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A struct{ j2g_header uint64; F_s__1938000069, F_iter__1938000068, F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A struct{ j2g_header uint64; F_s__1938000071, F_li, F_iter__1938000070 any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A struct{ j2g_header uint64; F_b__1938000073, F_li any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__fn__1938000032_A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class *jrt.Class



type A_arbace_go_run_no_linkname_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_linkname_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__fn__1938000016_A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000122_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000122_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000134_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000134_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_A struct{ j2g_header uint64; F_l, F_apos, F_end any }

var A_arbace_go_run_raw_lines_fn__1938000137_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A struct{ j2g_header uint64; F_iter__1938000139, F_s__1938000140 any }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A struct{ j2g_header uint64; F_b__1938000142 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000129_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000129_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_walk_meta__1938000116_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_walk_meta__1938000116_A_fn_class *jrt.Class



type A_arbace_go_run_run_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_A struct{ j2g_header uint64; F_srcs, F_inits, F_deps any }

var A_arbace_go_run_run_define__1938000091_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000092_A struct{ j2g_header uint64; F_src, F_r, F_st any }

var A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000094_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_define__1938000091_fn__1938000094_A_fn_class *jrt.Class



type A_arbace_go_run_run_extra__1938000089_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_extra__1938000089_A_fn_class *jrt.Class



type A_arbace_go_run_run_fn__1938000087_A struct{ j2g_header uint64; F_pf any }

var A_arbace_go_run_run_fn__1938000087_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000097_A struct{ j2g_header uint64; F_inits, F_deps any }

var A_arbace_go_run_run_init_order__1938000097_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A struct{ j2g_header uint64; F_done, F_deps any }

var A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_fn_class *jrt.Class



type A_arbace_go_run_run_load_BANG___1938000101_A struct{ j2g_header uint64; F_root, F_extra, F_srcs, F_index, F_define any }

var A_arbace_go_run_run_load_BANG___1938000101_A_fn_class *jrt.Class
