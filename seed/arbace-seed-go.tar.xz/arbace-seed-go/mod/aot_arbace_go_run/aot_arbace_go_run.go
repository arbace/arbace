//line aot_arbace_go_run.ae:1
package aot_arbace_go_run

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_New() *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_1); lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_go_run_A_const_3, A_arbace_go_run_A_const_4, A_arbace_go_run_A_const_5, A_arbace_go_run_A_const_6, A_arbace_go_run_A_const_7, A_arbace_go_run_A_const_8); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_76)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_77)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_run_eval1938000008_fn__1938000009_A_New() *A_arbace_go_run_eval1938000008_fn__1938000009_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000008_fn__1938000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_go_run_A_const_11; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_20, arg_23) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_run_A_const_12.GetRawRoot__O(), A_arbace_go_run_A_const_13) }



















func A_arbace_go_run_fail_A_New() *A_arbace_go_run_fail_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_go_run_fail_A) Ctor() {}
//line :21:1
func (t *A_arbace_go_run_fail_A) Invoke_O_O_O_O__O(self, status__0, kind__1, msg__2 any) any {
	var root_48 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_22; var arg_51 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_23.Get__O()); if linked_49 == nil { ifn_50.Invoke_O__O(arg_51) } else { linked_49.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_48, arg_51) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__47 any = A_arbace_go_run_fail_fn__1938000012_A_New_O_O(kind__1, msg__2); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_go_run_fail_fn__1938000012_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__47); A_arbace_go_run_fail_fn__1938000012_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp4, nil); Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()


	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__0)); return nil }
//line :22:1
func A_arbace_go_run_fail_fn__1938000012_A_New_O_O(p0, p1 any) *A_arbace_go_run_fail_fn__1938000012_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_fn__1938000012_A{}; t.Ctor_O_O(p0, p1); return t }
//line :22:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Ctor_O_O(c__kind, c__msg any) { t.F_kind = c__kind; t.F_msg = c__msg }
//line :22:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_79, nil, Lit_34, nil); var tmp4 any; var t_ any = t.F_kind; t.F_kind = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var root_34 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var root_38 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var root_42 any = A_arbace_go_run_A_const_19.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any; var t__2 any = t.F_msg; t.F_msg = nil; arg_45 = t__2; if linked_43 == nil { arg_41 = ifn_44.Invoke_O__O(arg_45) } else { arg_41 = linked_43.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_42, arg_45) }; if linked_39 == nil { arg_37 = ifn_40.Invoke_O__O(arg_41) } else { arg_37 = linked_39.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_38, arg_41) }; if linked_35 == nil { tmp6 = ifn_36.Invoke_O__O(arg_37) } else { tmp6 = linked_35.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_34, arg_37) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref())
											var root_24 any = A_arbace_go_run_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; if linked_25 == nil { tmp1 = ifn_26.Invoke__O() } else { tmp1 = linked_25.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_24) } }
//line :22:1
	return nil }(); var root_27 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; if linked_28 == nil { ifn_29.Invoke__O() } else { linked_28.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_27) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_go_run_package_file_QMARK__A_New() *A_arbace_go_run_package_file_QMARK__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_go_run_package_file_QMARK__A) Ctor() {}
//line :27:1
func (t *A_arbace_go_run_package_file_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 bool = jrt.File_Cast(f__0).IsFile__Z(); if and__1927000168__auto____2 {
											var and__1927000168__auto____3 any; var root_57 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = jrt.File_Cast(f__0).GetName__String().Ref(); var arg_61 any = Lit_111; if linked_58 == nil { and__1927000168__auto____3 = ifn_59.Invoke_O_O__O(arg_60, arg_61) } else { and__1927000168__auto____3 = linked_58.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_57, arg_60, arg_61) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var r__4 any = jrt.BufferedReader_New_Reader(jrt.FileReader_New_File(jrt.File_Cast(f__0))); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__7 any; var root_62 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_64 lang.IFn

		if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var root_66 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var fnbody__81 any = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New(); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, nil); A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; arg_69 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp2, nil); var arg_70 any; var root_82 any = A_arbace_go_run_A_const_28.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = r__4; if linked_83 == nil { arg_70 = ifn_84.Invoke_O__O(arg_85) } else { arg_70 = linked_83.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_82, arg_85) }; if linked_67 == nil { arg_65 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { arg_65 = linked_67.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }; if linked_63 == nil { l__7 = ifn_64.Invoke_O__O(arg_65) } else { l__7 = linked_63.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_62, arg_65) }
		var tmp3 any; var and__1927000168__auto____8 any = l__7; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_86 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = l__7; var arg_90 any = Lit_113; if linked_87 == nil { tmp3 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { tmp3 = linked_87.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_86, arg_89, arg_90) } } else { tmp3 = and__1927000168__auto____8 }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() }; return nil }()
//line :29:1
		jrt.BufferedReader_Cast(r__4).Close__V()
//line :28:1
		if tmp4 != nil { panic(tmp4) }; return tmp1 } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New() *A_arbace_go_run_package_file_QMARK__fn__1938000016_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__fn__1938000016_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Ctor() {}
//line :30:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Invoke_O_O__O(self, p1__1938000015_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_71 any = A_arbace_go_run_A_const_26.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = p1__1938000015_SHARP___1; if linked_72 == nil { or__1927000174__auto____2 = ifn_73.Invoke_O__O(arg_74) } else { or__1927000174__auto____2 = linked_72.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_71, arg_74) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_75 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = p1__1938000015_SHARP___1; var arg_79 any = Lit_114; if linked_76 == nil { return ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { return linked_76.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_75, arg_78, arg_79) } } }


func A_arbace_go_run_dir_test_root_A_New() *A_arbace_go_run_dir_test_root_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_root_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_go_run_dir_test_root_A) Ctor() {}
//line :33:1
func (t *A_arbace_go_run_dir_test_root_A) Invoke_O_O__O(self, pf__0 any) any { { var n__2 any = jrt.File_Cast(pf__0).GetName__String().Ref(); var sib__3 any; var tmp1 jrt.File_I = jrt.File_Cast(pf__0).GetParentFile__File(); var tmp2 any; var root_91 any = A_arbace_go_run_A_const_29.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_93 lang.IFn




	if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = n__2; var arg_95 any = A_arbace_go_run_A_const_30; var arg_96 any = Lit_41; if linked_92 == nil { tmp2 = ifn_93.Invoke_O_O_O__O(arg_94, arg_95, arg_96) } else { tmp2 = linked_92.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_91, arg_94, arg_95, arg_96) }
//line :33:1
	sib__3 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2))





	var tmp3 any; var and__1927000168__auto____4 any; var root_97 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = n__2; var arg_101 any = Lit_42; if linked_98 == nil { and__1927000168__auto____4 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { and__1927000168__auto____4 = linked_98.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(sib__3).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { return sib__3 } else { var d__4 any = jrt.File_Cast(pf__0).GetParentFile__File(); L1: for {


		if lang.Util_Identical_O_O__Z_NoInit(d__4, nil) { return nil } else { var tmp4 any; var root_102 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_104 lang.IFn

			if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = jrt.File_Cast(d__4).GetName__String().Ref(); var arg_106 any = Lit_43; if linked_103 == nil { tmp4 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { tmp4 = linked_103.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }
//line :42:1
			if jrt.J2g_Truth(tmp4) { return d__4 } else { if A_arbace_go_run_A_const_31 != nil {


				d__4 = jrt.File_Cast(d__4).GetParentFile__File(); continue L1 } else {
//line :42:1
					return nil } } } } } }; /*line :33:1*/panic("j2g: unreachable") }













func A_arbace_go_run_dir_test_index_A_New() *A_arbace_go_run_dir_test_index_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_go_run_dir_test_index_A) Ctor() {}
//line :47:1
func (t *A_arbace_go_run_dir_test_index_A) Invoke_O_O__O(self, pf__0 any) any { var temp__1927000408__auto____2 any; var root_107 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, A_arbace_go_run_dir_test_root_A_fn_class); var ifn_109 lang.IFn; if



	linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = pf__0; if linked_108 == nil { temp__1927000408__auto____2 = ifn_109.Invoke_O__O(arg_110) } else { temp__1927000408__auto____2 = linked_108.(*A_arbace_go_run_dir_test_root_A).Invoke_O_O__O(root_107, arg_110) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var root_111 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_113 lang.IFn
		if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_115 any; var iter__1927001039__auto____4 any; var fnbody__201 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New(); var tmp1 *jrt.Class; var fncls__200 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class
		if fncls__200 == nil { var fncls__200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class = fncls__200d; tmp1 = fncls__200d } else { tmp1 = fncls__200 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__201, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp3 any; var root_202 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = pf__0; var arg_206 any; var root_207 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = d__3; if linked_208 == nil { arg_206 = ifn_209.Invoke_O__O(arg_210) } else { arg_206 = linked_208.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_207, arg_210) }; if linked_203 == nil { tmp3 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { tmp3 = linked_203.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }; arg_115 = tmp2.Invoke_O__O(tmp3)
//line :52:1
		if linked_112 == nil { return ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { return linked_112.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) } } else {
//line :51:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }

func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New() *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Ctor() {}
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Invoke_O_O__O(self, s__1938000021__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__199 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(self, s__1938000021__1); var tmp2 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__199); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class = fncls__198d; tmp2 = fncls__198d } else { tmp2 = fncls__198 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__199, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :53:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(p0, p1 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Ctor_O_O(c__iter__1938000020, c__s__1938000021 any) { t.F_iter__1938000020 = c__iter__1938000020; t.F_s__1938000021 = c__s__1938000021 }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Invoke_O__O(self any) any { { var s__1938000021__1 any; var t_ any = t.F_s__1938000021; t.F_s__1938000021 = nil; s__1938000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_116 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__1938000021__1; if linked_117 == nil { temp__1927000414__auto____2 = ifn_118.Invoke_O__O(arg_119) } else { temp__1927000414__auto____2 = linked_117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_120 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__1938000021__3; if linked_121 == nil { tmp1 = ifn_122.Invoke_O__O(arg_123) } else { tmp1 = linked_121.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_124 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__1938000021__3; if linked_125 == nil { c__1927001037__auto____4 = ifn_126.Invoke_O__O(arg_127) } else { c__1927001037__auto____4 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_124, arg_127) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000023__6 any; var root_128 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_129 == nil { b__1938000023__6 = ifn_130.Invoke_O__O(arg_131) } else { b__1938000023__6 = linked_129.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_128, arg_131) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(b__1938000023__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__146); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_147 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var root_152 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = b__1938000023__6; if linked_153 == nil { arg_150 = ifn_154.Invoke_O__O(arg_155) } else { arg_150 = linked_153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_152, arg_155) }; var arg_151 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp5 any; var root_156 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = s__1938000021__3; if linked_157 == nil { tmp5 = ifn_158.Invoke_O__O(arg_159) } else { tmp5 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_156, arg_159) }; arg_151 = tmp4.Invoke_O__O(tmp5); if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } } else { var root_160 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var root_165 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = b__1938000023__6; if linked_166 == nil { arg_163 = ifn_167.Invoke_O__O(arg_168) } else { arg_163 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_165, arg_168) }; var arg_164 any; if linked_161 == nil { return ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { return linked_161.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) } } } else { var f__4 any; var root_169 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__1938000021__3; if linked_170 == nil { f__4 = ifn_171.Invoke_O__O(arg_172) } else { f__4 = linked_170.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_169, arg_172) }; var tmp6 any; var root_173 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_175 lang.IFn
															if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = f__4; if linked_174 == nil { tmp6 = ifn_175.Invoke_O__O(arg_176) } else { tmp6 = linked_174.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_173, arg_176) }
//line :53:1
	if jrt.J2g_Truth(tmp6) { var p__5 any; var root_177 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_179 lang.IFn

		if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = f__4; if linked_178 == nil { p__5 = ifn_179.Invoke_O__O(arg_180) } else { p__5 = linked_178.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_177, arg_180) }
//line :53:1
		if jrt.J2g_Truth(p__5) { var root_181 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = lang.Tuple_Create_O_O__IPersistentVector(p__5, f__4); var arg_185 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp8 any; var root_186 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__1938000021__3; if linked_187 == nil { tmp8 = ifn_188.Invoke_O__O(arg_189) } else { tmp8 = linked_187.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_186, arg_189) }; arg_185 = tmp7.Invoke_O__O(tmp8); if linked_182 == nil { return ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { return linked_182.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) } } else { var tmp9 any; var root_190 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__1938000021__3; if linked_191 == nil { tmp9 = ifn_192.Invoke_O__O(arg_193) } else { tmp9 = linked_191.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_190, arg_193) }; s__1938000021__1 = tmp9; continue L1 } } else { var tmp10 any; var root_194 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = s__1938000021__3; if linked_195 == nil { tmp10 = ifn_196.Invoke_O__O(arg_197) } else { tmp10 = linked_195.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_194, arg_197) }; s__1938000021__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :53:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Ctor_O_I_O(c__b__1938000023 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000023 = c__b__1938000023; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :53:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Invoke_O__O(self any) any { { var i__1938000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000022__1)); var tmp2 any; var root_132 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_134 lang.IFn
																if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__2; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_132, arg_135) }
//line :53:1
	if jrt.J2g_Truth(tmp2) { var p__3 any; var root_136 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_138 lang.IFn

		if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = f__2; if linked_137 == nil { p__3 = ifn_138.Invoke_O__O(arg_139) } else { p__3 = linked_137.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_136, arg_139) }
//line :53:1
		if jrt.J2g_Truth(p__3) { var root_140 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = t.F_b__1938000023; var arg_144 any = lang.Tuple_Create_O_O__IPersistentVector(p__3, f__2); if linked_141 == nil { ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { linked_141.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }; i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_run_no_assembly_BANG__A_New() *A_arbace_go_run_no_assembly_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Ctor() {}
//line :60:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Invoke_O_O__O(self, src__0 any) any { var temp__1927000414__auto____2 any; var root_211 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_213 lang.IFn; if
											linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var fnbody__226 any = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New(); var tmp1 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class = fncls__225d; tmp1 = fncls__225d } else { tmp1 = fncls__225 }; arg_214 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__226, tmp1, nil); var arg_215 any; var root_227 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = src__0; var arg_231 any = A_arbace_go_run_A_const_49; if linked_228 == nil { arg_215 = ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { arg_215 = linked_228.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) }; if linked_212 == nil { temp__1927000414__auto____2 = ifn_213.Invoke_O_O__O(arg_214, arg_215) } else { temp__1927000414__auto____2 = linked_212.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_211, arg_214, arg_215) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; var root_232 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_go_run_fail_A_fn_class); var ifn_234 lang.IFn
												if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = A_arbace_go_run_A_const_51; var arg_236 any = Lit_33; var arg_237 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_107, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, s__3, nil)).Ref(); if linked_233 == nil { return ifn_234.Invoke_O_O_O__O(arg_235, arg_236, arg_237) } else { return linked_233.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_232, arg_235, arg_236, arg_237) } } else {
//line :61:1
			return nil } }
//line :61:1
func A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New() *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Ctor() {}
//line :61:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Invoke_O_O__O(self, p1__1938000031_SHARP___1 any) any { var tmp1 any; var root_216 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any; var root_221 any = A_arbace_go_run_A_const_19.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = p1__1938000031_SHARP___1; if linked_222 == nil { arg_219 = ifn_223.Invoke_O__O(arg_224) } else { arg_219 = linked_222.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_221, arg_224) }; var arg_220 any = Lit_109; if linked_217 == nil { tmp1 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { tmp1 = linked_217.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; if jrt.J2g_Truth(tmp1) { return p1__1938000031_SHARP___1 } else { return nil } }


func A_arbace_go_run_no_linkname_BANG__A_New() *A_arbace_go_run_no_linkname_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_linkname_BANG__A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Ctor() {}
//line :64:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Invoke_O_O__O(self, src__0 any) any { { var seq_1938000035__2 any; var root_238 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn
											if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__0); if linked_239 == nil { seq_1938000035__2 = ifn_240.Invoke_O__O(arg_241) } else { seq_1938000035__2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }
//line :64:1
	var chunk_1938000036__3 any; var count_1938000037__4 int64 = 0; var i_1938000038__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000038__5, count_1938000037__4) { var fi__6 any = lang.Indexed_Cast(chunk_1938000036__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000038__5)); var seq_1938000051__7 any; var root_258 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = A_arbace_go_run_A_const_54.Invoke_O__O(fi__6); if linked_259 == nil { seq_1938000051__7 = ifn_260.Invoke_O__O(arg_261) } else { seq_1938000051__7 = linked_259.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_258, arg_261) }; var chunk_1938000052__8 any; var count_1938000053__9 int64 = 0; var i_1938000054__10 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000054__10, count_1938000053__9) { var d__11 any = lang.Indexed_Cast(chunk_1938000052__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000054__10)); var seq_1938000059__12 any; var root_278 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_284 lang.IFn
			if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_286 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_287 any = d__11; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O_O__O(arg_285, arg_286, arg_287) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_282, arg_285, arg_286, arg_287) }
//line :65:1
			if linked_279 == nil { seq_1938000059__12 = ifn_280.Invoke_O__O(arg_281) } else { seq_1938000059__12 = linked_279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_278, arg_281) }; var chunk_1938000060__13 any; var count_1938000061__14 int64 = 0; var i_1938000062__15 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000062__15, count_1938000061__14) { var x__16 any = lang.Indexed_Cast(chunk_1938000060__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000062__15)); var tmp1 any; var and__1927000168__auto____17 bool = lang.IObj_InstanceOf(x__16)

				if and__1927000168__auto____17 { var tmp2 *lang.Keyword = A_arbace_go_run_A_const_57; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() }
//line :65:1
				if jrt.J2g_Truth(tmp1) {


					var root_304 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_go_run_fail_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_go_run_A_const_51; var arg_308 any = Lit_33; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_309 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)), nil)).Ref(); if linked_305 == nil { ifn_306.Invoke_O_O_O__O(arg_307, arg_308, arg_309) } else { linked_305.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_304, arg_307, arg_308, arg_309) }
//line :65:1
					seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } else { seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } } else { var temp__1927000414__auto____16 any; var root_288 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = seq_1938000059__12; if linked_289 == nil { temp__1927000414__auto____16 = ifn_290.Invoke_O__O(arg_291) } else { temp__1927000414__auto____16 = linked_289.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_288, arg_291) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1938000059__17 any = temp__1927000414__auto____16; var tmp4 any; var root_292 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1938000059__17; if linked_293 == nil { tmp4 = ifn_294.Invoke_O__O(arg_295) } else { tmp4 = linked_293.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_292, arg_295) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_296 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = seq_1938000059__17; if linked_297 == nil { c__1927000678__auto____18 = ifn_298.Invoke_O__O(arg_299) } else { c__1927000678__auto____18 = linked_297.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_296, arg_299) }; var tmp5 any; var root_310 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = seq_1938000059__17; if linked_311 == nil { tmp5 = ifn_312.Invoke_O__O(arg_313) } else { tmp5 = linked_311.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_310, arg_313) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var x__18 any; var root_300 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = seq_1938000059__17; if linked_301 == nil { x__18 = ifn_302.Invoke_O__O(arg_303) } else { x__18 = linked_301.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_300, arg_303) }; var tmp6 any; var and__1927000168__auto____19 bool = lang.IObj_InstanceOf(x__18)

						if and__1927000168__auto____19 { var tmp7 *lang.Keyword = A_arbace_go_run_A_const_57; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }
//line :65:1
						if jrt.J2g_Truth(tmp6) {


							var root_314 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, A_arbace_go_run_fail_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = A_arbace_go_run_A_const_51; var arg_318 any = Lit_33; var tmp8 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_319 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)), nil)).Ref(); if linked_315 == nil { ifn_316.Invoke_O_O_O__O(arg_317, arg_318, arg_319) } else { linked_315.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_314, arg_317, arg_318, arg_319) }
//line :65:1
							var tmp9 any; var root_320 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1938000059__17; if linked_321 == nil { tmp9 = ifn_322.Invoke_O__O(arg_323) } else { tmp9 = linked_321.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_320, arg_323) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp9, nil, 0, 0; continue L3 } else { var tmp10 any; var root_324 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = seq_1938000059__17; if linked_325 == nil { tmp10 = ifn_326.Invoke_O__O(arg_327) } else { tmp10 = linked_325.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_324, arg_327) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp10, nil, 0, 0; continue L3 } } } }; break L3 }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000054__10); continue L2 } else { var temp__1927000414__auto____11 any; var root_262 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = seq_1938000051__7; if linked_263 == nil { temp__1927000414__auto____11 = ifn_264.Invoke_O__O(arg_265) } else { temp__1927000414__auto____11 = linked_263.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_262, arg_265) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1938000051__12 any = temp__1927000414__auto____11; var tmp11 any; var root_266 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = seq_1938000051__12; if linked_267 == nil { tmp11 = ifn_268.Invoke_O__O(arg_269) } else { tmp11 = linked_267.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_266, arg_269) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_270 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = seq_1938000051__12; if linked_271 == nil { c__1927000678__auto____13 = ifn_272.Invoke_O__O(arg_273) } else { c__1927000678__auto____13 = linked_271.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_270, arg_273) }; var tmp12 any; var root_328 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = seq_1938000051__12; if linked_329 == nil { tmp12 = ifn_330.Invoke_O__O(arg_331) } else { tmp12 = linked_329.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_328, arg_331) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__13 any; var root_274 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = seq_1938000051__12; if linked_275 == nil { d__13 = ifn_276.Invoke_O__O(arg_277) } else { d__13 = linked_275.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_274, arg_277) }; var seq_1938000055__14 any; var root_332 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any; var root_336 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_338 lang.IFn
								if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_340 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_341 any = d__13; if linked_337 == nil { arg_335 = ifn_338.Invoke_O_O_O__O(arg_339, arg_340, arg_341) } else { arg_335 = linked_337.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_336, arg_339, arg_340, arg_341) }
//line :65:1
								if linked_333 == nil { seq_1938000055__14 = ifn_334.Invoke_O__O(arg_335) } else { seq_1938000055__14 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) }; var chunk_1938000056__15 any; var count_1938000057__16 int64 = 0; var i_1938000058__17 int64 = 0; L4: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000058__17, count_1938000057__16) { var x__18_2 any = lang.Indexed_Cast(chunk_1938000056__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000058__17)); var tmp13 any; var and__1927000168__auto____19_2 bool = lang.IObj_InstanceOf(x__18_2)

									if and__1927000168__auto____19_2 { var tmp14 *lang.Keyword = A_arbace_go_run_A_const_57; tmp13 = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_2).Ref() }
//line :65:1
									if jrt.J2g_Truth(tmp13) {


										var root_358 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_go_run_fail_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_go_run_A_const_51; var arg_362 any = Lit_33; var tmp15 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_363 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp15.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)), nil)).Ref(); if linked_359 == nil { ifn_360.Invoke_O_O_O__O(arg_361, arg_362, arg_363) } else { linked_359.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_358, arg_361, arg_362, arg_363) }
//line :65:1
										seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } else { seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } } else { var temp__1927000414__auto____18 any; var root_342 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = seq_1938000055__14; if linked_343 == nil { temp__1927000414__auto____18 = ifn_344.Invoke_O__O(arg_345) } else { temp__1927000414__auto____18 = linked_343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_342, arg_345) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000055__19 any = temp__1927000414__auto____18; var tmp16 any; var root_346 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = seq_1938000055__19; if linked_347 == nil { tmp16 = ifn_348.Invoke_O__O(arg_349) } else { tmp16 = linked_347.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____20 any; var root_350 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = seq_1938000055__19; if linked_351 == nil { c__1927000678__auto____20 = ifn_352.Invoke_O__O(arg_353) } else { c__1927000678__auto____20 = linked_351.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_350, arg_353) }; var tmp17 any; var root_364 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = seq_1938000055__19; if linked_365 == nil { tmp17 = ifn_366.Invoke_O__O(arg_367) } else { tmp17 = linked_365.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_364, arg_367) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp17, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__20 any; var root_354 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = seq_1938000055__19; if linked_355 == nil { x__20 = ifn_356.Invoke_O__O(arg_357) } else { x__20 = linked_355.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_354, arg_357) }; var tmp18 any; var and__1927000168__auto____21 bool = lang.IObj_InstanceOf(x__20)

											if and__1927000168__auto____21 { var tmp19 *lang.Keyword = A_arbace_go_run_A_const_57; tmp18 = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)) } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }
//line :65:1
											if jrt.J2g_Truth(tmp18) {


												var root_368 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, A_arbace_go_run_fail_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = A_arbace_go_run_A_const_51; var arg_372 any = Lit_33; var tmp20 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_373 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)), nil)).Ref(); if linked_369 == nil { ifn_370.Invoke_O_O_O__O(arg_371, arg_372, arg_373) } else { linked_369.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_368, arg_371, arg_372, arg_373) }
//line :65:1
												var tmp21 any; var root_374 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1938000055__19; if linked_375 == nil { tmp21 = ifn_376.Invoke_O__O(arg_377) } else { tmp21 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp21, nil, 0, 0; continue L4 } else { var tmp22 any; var root_378 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = seq_1938000055__19; if linked_379 == nil { tmp22 = ifn_380.Invoke_O__O(arg_381) } else { tmp22 = linked_379.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_378, arg_381) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp22, nil, 0, 0; continue L4 } } } }; break L4 }; var tmp23 any; var root_382 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = seq_1938000051__12; if linked_383 == nil { tmp23 = ifn_384.Invoke_O__O(arg_385) } else { tmp23 = linked_383.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_382, arg_385) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp23, nil, 0, 0; continue L2 } } }; break L2 }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000038__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_242 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = seq_1938000035__2; if linked_243 == nil { temp__1927000414__auto____6 = ifn_244.Invoke_O__O(arg_245) } else { temp__1927000414__auto____6 = linked_243.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_242, arg_245) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1938000035__7 any = temp__1927000414__auto____6; var tmp24 any; var root_246 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1938000035__7; if linked_247 == nil { tmp24 = ifn_248.Invoke_O__O(arg_249) } else { tmp24 = linked_247.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____8 any; var root_250 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1938000035__7; if linked_251 == nil { c__1927000678__auto____8 = ifn_252.Invoke_O__O(arg_253) } else { c__1927000678__auto____8 = linked_251.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_250, arg_253) }; var tmp25 any; var root_386 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = seq_1938000035__7; if linked_387 == nil { tmp25 = ifn_388.Invoke_O__O(arg_389) } else { tmp25 = linked_387.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_386, arg_389) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp25, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__8 any; var root_254 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1938000035__7; if linked_255 == nil { fi__8 = ifn_256.Invoke_O__O(arg_257) } else { fi__8 = linked_255.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_254, arg_257) }; var seq_1938000039__9 any; var root_390 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = A_arbace_go_run_A_const_54.Invoke_O__O(fi__8); if linked_391 == nil { seq_1938000039__9 = ifn_392.Invoke_O__O(arg_393) } else { seq_1938000039__9 = linked_391.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_390, arg_393) }; var chunk_1938000040__10 any; var count_1938000041__11 int64 = 0; var i_1938000042__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000042__12, count_1938000041__11) { var d__13_2 any = lang.Indexed_Cast(chunk_1938000040__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000042__12)); var seq_1938000047__14 any; var root_410 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_412 lang.IFn; if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any; var root_414 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_416 lang.IFn
													if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_418 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_419 any = d__13_2; if linked_415 == nil { arg_413 = ifn_416.Invoke_O_O_O__O(arg_417, arg_418, arg_419) } else { arg_413 = linked_415.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_414, arg_417, arg_418, arg_419) }
//line :65:1
													if linked_411 == nil { seq_1938000047__14 = ifn_412.Invoke_O__O(arg_413) } else { seq_1938000047__14 = linked_411.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_410, arg_413) }; var chunk_1938000048__15 any; var count_1938000049__16 int64 = 0; var i_1938000050__17 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000050__17, count_1938000049__16) { var x__18_3 any = lang.Indexed_Cast(chunk_1938000048__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000050__17)); var tmp26 any; var and__1927000168__auto____19_3 bool = lang.IObj_InstanceOf(x__18_3)

														if and__1927000168__auto____19_3 { var tmp27 *lang.Keyword = A_arbace_go_run_A_const_57; tmp26 = tmp27.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)) } else { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_3).Ref() }
//line :65:1
														if jrt.J2g_Truth(tmp26) {


															var root_436 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_go_run_fail_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = A_arbace_go_run_A_const_51; var arg_440 any = Lit_33; var tmp28 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_441 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp28.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)), nil)).Ref(); if linked_437 == nil { ifn_438.Invoke_O_O_O__O(arg_439, arg_440, arg_441) } else { linked_437.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_436, arg_439, arg_440, arg_441) }
//line :65:1
															seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } else { seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } } else { var temp__1927000414__auto____18_2 any; var root_420 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = seq_1938000047__14; if linked_421 == nil { temp__1927000414__auto____18_2 = ifn_422.Invoke_O__O(arg_423) } else { temp__1927000414__auto____18_2 = linked_421.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_420, arg_423) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1938000047__19 any = temp__1927000414__auto____18_2; var tmp29 any; var root_424 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = seq_1938000047__19; if linked_425 == nil { tmp29 = ifn_426.Invoke_O__O(arg_427) } else { tmp29 = linked_425.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_424, arg_427) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____20_2 any; var root_428 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = seq_1938000047__19; if linked_429 == nil { c__1927000678__auto____20_2 = ifn_430.Invoke_O__O(arg_431) } else { c__1927000678__auto____20_2 = linked_429.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_428, arg_431) }; var tmp30 any; var root_442 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = seq_1938000047__19; if linked_443 == nil { tmp30 = ifn_444.Invoke_O__O(arg_445) } else { tmp30 = linked_443.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_442, arg_445) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp30, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__20_2 any; var root_432 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seq_1938000047__19; if linked_433 == nil { x__20_2 = ifn_434.Invoke_O__O(arg_435) } else { x__20_2 = linked_433.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_432, arg_435) }; var tmp31 any; var and__1927000168__auto____21_2 bool = lang.IObj_InstanceOf(x__20_2)

																if and__1927000168__auto____21_2 { var tmp32 *lang.Keyword = A_arbace_go_run_A_const_57; tmp31 = tmp32.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }
//line :65:1
																if jrt.J2g_Truth(tmp31) {


																	var root_446 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, A_arbace_go_run_fail_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = A_arbace_go_run_A_const_51; var arg_450 any = Lit_33; var tmp33 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_451 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp33.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)), nil)).Ref(); if linked_447 == nil { ifn_448.Invoke_O_O_O__O(arg_449, arg_450, arg_451) } else { linked_447.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_446, arg_449, arg_450, arg_451) }
//line :65:1
																	var tmp34 any; var root_452 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1938000047__19; if linked_453 == nil { tmp34 = ifn_454.Invoke_O__O(arg_455) } else { tmp34 = linked_453.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_452, arg_455) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp34, nil, 0, 0; continue L6 } else { var tmp35 any; var root_456 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = seq_1938000047__19; if linked_457 == nil { tmp35 = ifn_458.Invoke_O__O(arg_459) } else { tmp35 = linked_457.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_456, arg_459) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp35, nil, 0, 0; continue L6 } } } }; break L6 }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000042__12); continue L5 } else { var temp__1927000414__auto____13 any; var root_394 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_1938000039__9; if linked_395 == nil { temp__1927000414__auto____13 = ifn_396.Invoke_O__O(arg_397) } else { temp__1927000414__auto____13 = linked_395.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_394, arg_397) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1938000039__14 any = temp__1927000414__auto____13; var tmp36 any; var root_398 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_1938000039__14; if linked_399 == nil { tmp36 = ifn_400.Invoke_O__O(arg_401) } else { tmp36 = linked_399.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_398, arg_401) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____15 any; var root_402 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = seq_1938000039__14; if linked_403 == nil { c__1927000678__auto____15 = ifn_404.Invoke_O__O(arg_405) } else { c__1927000678__auto____15 = linked_403.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_402, arg_405) }; var tmp37 any; var root_460 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = seq_1938000039__14; if linked_461 == nil { tmp37 = ifn_462.Invoke_O__O(arg_463) } else { tmp37 = linked_461.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_460, arg_463) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp37, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var d__15 any; var root_406 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = seq_1938000039__14; if linked_407 == nil { d__15 = ifn_408.Invoke_O__O(arg_409) } else { d__15 = linked_407.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_406, arg_409) }; var seq_1938000043__16 any; var root_464 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any; var root_468 any = A_arbace_go_run_A_const_55.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_470 lang.IFn
																		if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var arg_472 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var arg_473 any = d__15; if linked_469 == nil { arg_467 = ifn_470.Invoke_O_O_O__O(arg_471, arg_472, arg_473) } else { arg_467 = linked_469.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_468, arg_471, arg_472, arg_473) }
//line :65:1
																		if linked_465 == nil { seq_1938000043__16 = ifn_466.Invoke_O__O(arg_467) } else { seq_1938000043__16 = linked_465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_464, arg_467) }; var chunk_1938000044__17 any; var count_1938000045__18 int64 = 0; var i_1938000046__19 int64 = 0; L7: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000046__19, count_1938000045__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1938000044__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000046__19)); var tmp38 any; var and__1927000168__auto____21_3 bool = lang.IObj_InstanceOf(x__20_3)

																			if and__1927000168__auto____21_3 { var tmp39 *lang.Keyword = A_arbace_go_run_A_const_57; tmp38 = tmp39.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)) } else { tmp38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_3).Ref() }
//line :65:1
																			if jrt.J2g_Truth(tmp38) {


																				var root_490 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, A_arbace_go_run_fail_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = A_arbace_go_run_A_const_51; var arg_494 any = Lit_33; var tmp40 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_495 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp40.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)), nil)).Ref(); if linked_491 == nil { ifn_492.Invoke_O_O_O__O(arg_493, arg_494, arg_495) } else { linked_491.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_490, arg_493, arg_494, arg_495) }
//line :65:1
																				seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } else { seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } } else { var temp__1927000414__auto____20 any; var root_474 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = seq_1938000043__16; if linked_475 == nil { temp__1927000414__auto____20 = ifn_476.Invoke_O__O(arg_477) } else { temp__1927000414__auto____20 = linked_475.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_474, arg_477) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1938000043__21 any = temp__1927000414__auto____20; var tmp41 any; var root_478 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = seq_1938000043__21; if linked_479 == nil { tmp41 = ifn_480.Invoke_O__O(arg_481) } else { tmp41 = linked_479.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_478, arg_481) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____22 any; var root_482 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = seq_1938000043__21; if linked_483 == nil { c__1927000678__auto____22 = ifn_484.Invoke_O__O(arg_485) } else { c__1927000678__auto____22 = linked_483.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_482, arg_485) }; var tmp42 any; var root_496 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = seq_1938000043__21; if linked_497 == nil { tmp42 = ifn_498.Invoke_O__O(arg_499) } else { tmp42 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_496, arg_499) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp42, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22 any; var root_486 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = seq_1938000043__21; if linked_487 == nil { x__22 = ifn_488.Invoke_O__O(arg_489) } else { x__22 = linked_487.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_486, arg_489) }; var tmp43 any; var and__1927000168__auto____23 bool = lang.IObj_InstanceOf(x__22)

																					if and__1927000168__auto____23 { var tmp44 *lang.Keyword = A_arbace_go_run_A_const_57; tmp43 = tmp44.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)) } else { tmp43 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }
//line :65:1
																					if jrt.J2g_Truth(tmp43) {


																						var root_500 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_go_run_fail_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = A_arbace_go_run_A_const_51; var arg_504 any = Lit_33; var tmp45 *lang.Keyword = A_arbace_go_run_A_const_57; var arg_505 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_34, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_52.Invoke_O__O(src__0), nil, tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)), nil)).Ref(); if linked_501 == nil { ifn_502.Invoke_O_O_O__O(arg_503, arg_504, arg_505) } else { linked_501.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_500, arg_503, arg_504, arg_505) }
//line :65:1
																						var tmp46 any; var root_506 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = seq_1938000043__21; if linked_507 == nil { tmp46 = ifn_508.Invoke_O__O(arg_509) } else { tmp46 = linked_507.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_506, arg_509) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp46, nil, 0, 0; continue L7 } else { var tmp47 any; var root_510 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = seq_1938000043__21; if linked_511 == nil { tmp47 = ifn_512.Invoke_O__O(arg_513) } else { tmp47 = linked_511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_510, arg_513) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp47, nil, 0, 0; continue L7 } } } }; break L7 }; var tmp48 any; var root_514 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = seq_1938000039__14; if linked_515 == nil { tmp48 = ifn_516.Invoke_O__O(arg_517) } else { tmp48 = linked_515.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_514, arg_517) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp48, nil, 0, 0; continue L5 } } }; break L5 }; var tmp49 any; var root_518 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = seq_1938000035__7; if linked_519 == nil { tmp49 = ifn_520.Invoke_O__O(arg_521) } else { tmp49 = linked_519.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_518, arg_521) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp49, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :64:1*/panic("j2g: unreachable") }





func A_arbace_go_run_check_BANG__A_New() *A_arbace_go_run_check_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_go_run_check_BANG__A) Ctor() {}
//line :70:1
func (t *A_arbace_go_run_check_BANG__A) Invoke_O_O_O__O(self, src__0, extra__1 any) any {
	var root_527 any = A_arbace_go_run_A_const_61.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = src__0; if linked_528 == nil { ifn_529.Invoke_O__O(arg_530) } else { linked_528.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_527, arg_530) }
	var root_531 any = A_arbace_go_run_A_const_62.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, A_arbace_go_run_no_linkname_BANG__A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = src__0; if linked_532 == nil { ifn_533.Invoke_O__O(arg_534) } else { linked_532.(*A_arbace_go_run_no_linkname_BANG__A).Invoke_O_O__O(root_531, arg_534) }
//line :70:1
	var r__3 any; var root_522 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_524 lang.IFn


	if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = src__0; var arg_526 any = extra__1; if linked_523 == nil { r__3 = ifn_524.Invoke_O_O__O(arg_525, arg_526) } else { r__3 = linked_523.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_522, arg_525, arg_526) }
//line :70:1
	var errs__4 any = A_arbace_go_run_A_const_60.Invoke_O__O(r__3); var temp__1927000414__auto____5 any; var root_535 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_537 lang.IFn




	if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any; var fnbody__541 any = A_arbace_go_run_check_BANG__fn__1938000065_A_New(); var tmp1 *jrt.Class; var fncls__540 *jrt.Class = A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class; if fncls__540 == nil { var fncls__540d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class = fncls__540d; tmp1 = fncls__540d } else { tmp1 = fncls__540 }; arg_538 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__541, tmp1, nil); var arg_539 any = errs__4; if linked_536 == nil { temp__1927000414__auto____5 = ifn_537.Invoke_O_O__O(arg_538, arg_539) } else { temp__1927000414__auto____5 = linked_536.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_535, arg_538, arg_539) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var bi__6 any = temp__1927000414__auto____5; var root_542 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, A_arbace_go_run_fail_A_fn_class); var ifn_544 lang.IFn
		if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = A_arbace_go_run_A_const_51; var arg_546 any = Lit_33; var arg_547 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_37, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_65.Invoke_O__O(bi__6))).Ref(); if linked_543 == nil { ifn_544.Invoke_O_O_O__O(arg_545, arg_546, arg_547) } else { linked_543.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_542, arg_545, arg_546, arg_547) } }
	var tmp2 any; var root_548 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = errs__4; if linked_549 == nil { tmp2 = ifn_550.Invoke_O__O(arg_551) } else { tmp2 = linked_549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_548, arg_551) }; if jrt.J2g_Truth(tmp2) {
		var root_552 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, A_arbace_go_run_fail_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = A_arbace_go_run_A_const_66; var arg_556 any = Lit_8; var arg_557 any; var tmp3 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp4 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__0); var tmp5 *lang.Keyword = A_arbace_go_run_A_const_67; var tmp6 any; var root_558 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = errs__4; if linked_559 == nil { tmp6 = ifn_560.Invoke_O__O(arg_561) } else { tmp6 = linked_559.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_558, arg_561) }; var tmp7 any = tmp5.Invoke_O__O(tmp6); var tmp8 *lang.Keyword = A_arbace_go_run_A_const_68; var tmp9 any; var root_562 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = errs__4; if linked_563 == nil { tmp9 = ifn_564.Invoke_O__O(arg_565) } else { tmp9 = linked_563.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_562, arg_565) }; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 *lang.Keyword = A_arbace_go_run_A_const_65; var tmp12 any; var root_566 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = errs__4; if linked_567 == nil { tmp12 = ifn_568.Invoke_O__O(arg_569) } else { tmp12 = linked_567.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_566, arg_569) }; arg_557 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp7, nil, tmp10, nil, tmp11.Invoke_O__O(tmp12))).Ref(); if linked_553 == nil { ifn_554.Invoke_O_O_O__O(arg_555, arg_556, arg_557) } else { linked_553.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_552, arg_555, arg_556, arg_557) } }
//line :70:1
	return r__3
}



func A_arbace_go_run_check_BANG__fn__1938000065_A_New() *A_arbace_go_run_check_BANG__fn__1938000065_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__fn__1938000065_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Ctor() {}
//line :75:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Invoke_O_O__O(self, p1__1938000064_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_63; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000064_SHARP___1)) { return p1__1938000064_SHARP___1 } else { return nil } }





func A_arbace_go_run_imports_of_A_New() *A_arbace_go_run_imports_of_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_go_run_imports_of_A) Ctor() {}
//line :81:1
func (t *A_arbace_go_run_imports_of_A) Invoke_O_O__O(self, src__0 any) any { var li__2 any; var root_570 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_572 lang.IFn; if


	linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = src__0; var arg_574 any = A_arbace_go_run_A_const_69; if linked_571 == nil { li__2 = ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { li__2 = linked_571.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) }; var root_575 any =
	A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var iter__1927001039__auto____3 any; var fnbody__702 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(li__2); var tmp1 *jrt.Class; var fncls__701 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class; if
	fncls__701 == nil { var fncls__701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__702); A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class = fncls__701d; tmp1 = fncls__701d } else { tmp1 = fncls__701 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__702, tmp1, nil); arg_578 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_run_A_const_53.Invoke_O__O(src__0)); if /*line :85:1*/ linked_576 == nil { return ifn_577.Invoke_O__O(arg_578) } else { return linked_576.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_575, arg_578) } }
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A{}; t.Ctor_O(p0); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Invoke_O_O__O(self, s__1938000069__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__700 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(s__1938000069__1, self, t.F_li); var tmp2 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class; if fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__700); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class = fncls__699d; tmp2 = fncls__699d } else { tmp2 = fncls__699 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__700, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Ctor_O_O_O(c__s__1938000069, c__iter__1938000068, c__li any) { t.F_s__1938000069 = c__s__1938000069; t.F_iter__1938000068 = c__iter__1938000068; t.F_li = c__li }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Invoke_O__O(self any) any { { var s__1938000069__1 any; var t_ any = t.F_s__1938000069; t.F_s__1938000069 = nil; s__1938000069__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_579 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = s__1938000069__1; if linked_580 == nil { temp__1927000414__auto____2 = ifn_581.Invoke_O__O(arg_582) } else { temp__1927000414__auto____2 = linked_580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_579, arg_582) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var fi__4 any; var root_583 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = xs__1927001018__auto____3; if linked_584 == nil { fi__4 = ifn_585.Invoke_O__O(arg_586) } else { fi__4 = linked_584.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_583, arg_586) }; var iterys__1927001035__auto____5 any; var fnbody__676 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(t.F_li); var tmp1 *jrt.Class; var fncls__675 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class; if fncls__675 == nil { var fncls__675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__676); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class = fncls__675d; tmp1 = fncls__675d } else { tmp1 = fncls__675 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__676, tmp1, nil); var fs__1927001036__auto____6 any; var root_677 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_681 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_683 lang.IFn
														if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = fi__4; var arg_685 any = A_arbace_go_run_A_const_74; if linked_682 == nil { tmp3 = ifn_683.Invoke_O_O__O(arg_684, arg_685) } else { tmp3 = linked_682.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_681, arg_684, arg_685) }
//line :86:1
	arg_680 = tmp2.Invoke_O__O(tmp3); if linked_678 == nil { fs__1927001036__auto____6 = ifn_679.Invoke_O__O(arg_680) } else { fs__1927001036__auto____6 = linked_678.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_677, arg_680) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_686 any = A_arbace_go_run_A_const_75.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = fs__1927001036__auto____6; var arg_690 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000068); var tmp5 any; var root_691 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = s__1938000069__1; if linked_692 == nil { tmp5 = ifn_693.Invoke_O__O(arg_694) } else { tmp5 = linked_692.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_691, arg_694) }; arg_690 = tmp4.Invoke_O__O(tmp5); if linked_687 == nil { return ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { return linked_687.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) } } else { var tmp6 any; var root_695 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_697 lang.IFn; if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = s__1938000069__1; if linked_696 == nil { tmp6 = ifn_697.Invoke_O__O(arg_698) } else { tmp6 = linked_696.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_695, arg_698) }; s__1938000069__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A{}; t.Ctor_O(p0); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Invoke_O_O__O(self, s__1938000071__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__674 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(s__1938000071__1, t.F_li, self); var tmp2 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__674); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class = fncls__673d; tmp2 = fncls__673d } else { tmp2 = fncls__673 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__674, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Ctor_O_O_O(c__s__1938000071, c__li, c__iter__1938000070 any) { t.F_s__1938000071 = c__s__1938000071; t.F_li = c__li; t.F_iter__1938000070 = c__iter__1938000070 }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Invoke_O__O(self any) any { { var s__1938000071__1 any; var t_ any = t.F_s__1938000071; t.F_s__1938000071 = nil; s__1938000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_587 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = s__1938000071__1; if linked_588 == nil { temp__1927000414__auto____2 = ifn_589.Invoke_O__O(arg_590) } else { temp__1927000414__auto____2 = linked_588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_587, arg_590) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_591 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = s__1938000071__3; if linked_592 == nil { tmp1 = ifn_593.Invoke_O__O(arg_594) } else { tmp1 = linked_592.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_591, arg_594) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_595 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = s__1938000071__3; if linked_596 == nil { c__1927001037__auto____4 = ifn_597.Invoke_O__O(arg_598) } else { c__1927001037__auto____4 = linked_596.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_595, arg_598) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000073__6 any; var root_599 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_600 == nil { b__1938000073__6 = ifn_601.Invoke_O__O(arg_602) } else { b__1938000073__6 = linked_600.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_599, arg_602) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__621 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(b__1938000073__6, t.F_li, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__621); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class = fncls__620d; tmp3 = fncls__620d } else { tmp3 = fncls__620 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__621, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_622 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var root_627 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = b__1938000073__6; if linked_628 == nil { arg_625 = ifn_629.Invoke_O__O(arg_630) } else { arg_625 = linked_628.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_627, arg_630) }; var arg_626 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp5 any; var root_631 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = s__1938000071__3; if linked_632 == nil { tmp5 = ifn_633.Invoke_O__O(arg_634) } else { tmp5 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_631, arg_634) }; arg_626 = tmp4.Invoke_O__O(tmp5); if linked_623 == nil { return ifn_624.Invoke_O_O__O(arg_625, arg_626) } else { return linked_623.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_622, arg_625, arg_626) } } else { var root_635 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any; var root_640 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = b__1938000073__6; if linked_641 == nil { arg_638 = ifn_642.Invoke_O__O(arg_643) } else { arg_638 = linked_641.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_640, arg_643) }; var arg_639 any; if linked_636 == nil { return ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { return linked_636.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } } } else { var spec__4 any; var root_644 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = s__1938000071__3; if linked_645 == nil { spec__4 = ifn_646.Invoke_O__O(arg_647) } else { spec__4 = linked_645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_644, arg_647) }; var p__5 any; var tmp6 any; var root_648 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_650 lang.IFn

	if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = spec__4; if linked_649 == nil { tmp6 = ifn_650.Invoke_O__O(arg_651) } else { tmp6 = linked_649.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_648, arg_651) }; if jrt.J2g_Truth(tmp6) { var root_652 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = spec__4; if linked_653 == nil { p__5 = ifn_654.Invoke_O__O(arg_655) } else { p__5 = linked_653.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_652, arg_655) } } else { p__5 = spec__4 }
//line :86:1
	var tmp7 any; var root_656 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_658 lang.IFn


	if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = p__5; if linked_657 == nil { tmp7 = ifn_658.Invoke_O__O(arg_659) } else { tmp7 = linked_657.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_656, arg_659) }
//line :86:1
	if jrt.J2g_Truth(tmp7) { var root_660 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__5, p__5); var arg_664 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp9 any; var root_665 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = s__1938000071__3; if linked_666 == nil { tmp9 = ifn_667.Invoke_O__O(arg_668) } else { tmp9 = linked_666.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_665, arg_668) }; arg_664 = tmp8.Invoke_O__O(tmp9); if linked_661 == nil { return ifn_662.Invoke_O_O__O(arg_663, arg_664) } else { return linked_661.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_660, arg_663, arg_664) } } else { var tmp10 any; var root_669 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = s__1938000071__3; if linked_670 == nil { tmp10 = ifn_671.Invoke_O__O(arg_672) } else { tmp10 = linked_670.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_669, arg_672) }; s__1938000071__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :86:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Ctor_O_O_I_O(c__b__1938000073, c__li any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000073 = c__b__1938000073; t.F_li = c__li; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :86:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Invoke_O__O(self any) any { { var i__1938000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000072__1)); var p__3 any; var tmp2 any; var root_603 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_605 lang.IFn

	if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = spec__2; if linked_604 == nil { tmp2 = ifn_605.Invoke_O__O(arg_606) } else { tmp2 = linked_604.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_603, arg_606) }; if jrt.J2g_Truth(tmp2) { var root_607 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = spec__2; if linked_608 == nil { p__3 = ifn_609.Invoke_O__O(arg_610) } else { p__3 = linked_608.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_607, arg_610) } } else { p__3 = spec__2 }
//line :86:1
	var tmp3 any; var root_611 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_613 lang.IFn


	if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = p__3; if linked_612 == nil { tmp3 = ifn_613.Invoke_O__O(arg_614) } else { tmp3 = linked_612.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_611, arg_614) }
//line :86:1
	if jrt.J2g_Truth(tmp3) { var root_615 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = t.F_b__1938000073; var arg_619 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__3, p__3); if linked_616 == nil { ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { linked_616.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_615, arg_618, arg_619) }; i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } else { i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_run_run_A_New() *A_arbace_go_run_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_go_run_run_A) Ctor() {}
//line :94:1
func (t *A_arbace_go_run_run_A) Invoke_O_O_O_O__O(self, root__0, pf__1, args__2 any) any {




	var root_957 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = A_arbace_go_run_A_const_118.GetRawRoot__O(); var arg_961 any = jrt.Boolean_TRUE.Ref(); if linked_958 == nil { ifn_959.Invoke_O_O__O(arg_960, arg_961) } else { linked_958.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_957, arg_960, arg_961)
	}
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_115.GetRawRoot__O()); var tmp2 any; var root_967 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any; var root_972 any = A_arbace_go_run_A_const_19.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = jrt.File_Cast(pf__1).GetName__String().Ref(); if linked_973 == nil { arg_970 = ifn_974.Invoke_O__O(arg_975) } else { arg_970 = linked_973.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_972, arg_975) }; var arg_971 any = args__2; if linked_968 == nil { tmp2 = ifn_969.Invoke_O_O__O(arg_970, arg_971) } else { tmp2 = linked_968.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_967, arg_970, arg_971) }; tmp1.Invoke_O_O__O(Lit_125, lang.RT_Object_array_O__O1_NoInit(tmp2).Ref())
//line :94:1
	var src__4 any; var G__1938000087__4_ any; var root_703 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_705 lang.IFn







	if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_77, root__0)); var arg_707 any; var arg_708 any; var root_710 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_711 == nil { arg_708 = ifn_712.Invoke_O__O(arg_713) } else { arg_708 = linked_711.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_710, arg_713) }; var arg_709 any = pf__1; if linked_704 == nil { G__1938000087__4_ = ifn_705.Invoke_O_O_O_O__O(arg_706, arg_707, arg_708, arg_709) } else { G__1938000087__4_ = linked_704.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_703, arg_706, arg_707, arg_708, arg_709) }; var tmp3 any; var root_714 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, A_arbace_go_run_full_forms_QMARK__A_fn_class); var ifn_716 lang.IFn
	if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = root__0; var arg_718 any = pf__1; if linked_715 == nil { tmp3 = ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { tmp3 = linked_715.(*A_arbace_go_run_full_forms_QMARK__A).Invoke_O_O_O__O(root_714, arg_717, arg_718) }
//line :102:1
	if jrt.J2g_Truth(tmp3) {
		var root_719 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, A_arbace_go_run_full_lines_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = G__1938000087__4_; var arg_723 any = jrt.Boolean_TRUE.Ref(); if linked_720 == nil { src__4 = ifn_721.Invoke_O_O__O(arg_722, arg_723) } else { src__4 = linked_720.(*A_arbace_go_run_full_lines_A).Invoke_O_O_O__O(root_719, arg_722, arg_723) } } else {
//line :102:1
			src__4 = G__1938000087__4_ }
//line :94:1
	var ___5 any; var tmp4 any; var root_724 any = A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_726 lang.IFn; _ = ___5









	if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__4); if linked_725 == nil { tmp4 = ifn_726.Invoke_O__O(arg_727) } else { tmp4 = linked_725.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_724, arg_727) }; if jrt.J2g_Truth(tmp4) { var root_728 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, A_arbace_go_run_fail_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = A_arbace_go_run_A_const_51; var arg_732 any = Lit_33; var arg_733 any = Lit_48; if linked_729 == nil { ___5 = ifn_730.Invoke_O_O_O__O(arg_731, arg_732, arg_733) } else { ___5 = linked_729.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_728, arg_731, arg_732, arg_733) } } else { ___5 = nil }
//line :94:1
	var index__6 any; var tmp5 *lang.Compiler_AOTFn; var fnbody__739 any = A_arbace_go_run_run_fn__1938000088_A_New_O(pf__1); var tmp6 *jrt.Class
	var fncls__738 /*line :94:1*/*jrt.Class = A_arbace_go_run_run_fn__1938000088_A_fn_class










	if fncls__738 == nil { var fncls__738d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, fnbody__739); A_arbace_go_run_run_fn__1938000088_A_fn_class = fncls__738d; tmp6 = fncls__738d } else { tmp6 = fncls__738 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__739, tmp6, nil)
//line :94:1
	index__6 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp5)); var srcs__7 any; var root_740 any = A_arbace_go_run_A_const_83.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_742 lang.IFn











	if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_741 == nil { srcs__7 = ifn_742.Invoke_O__O(arg_743) } else { srcs__7 = linked_741.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_740, arg_743) }
//line :94:1
	var inits__8 any; var root_744 any = A_arbace_go_run_A_const_84.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_746 lang.IFn












	if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_745 == nil { inits__8 = ifn_746.Invoke_O__O(arg_747) } else { inits__8 = linked_745.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_744, arg_747) }
//line :94:1
	var deps__9 any; var root_748 any = A_arbace_go_run_A_const_84.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_750 lang.IFn













	if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_749 == nil { deps__9 = ifn_750.Invoke_O__O(arg_751) } else { deps__9 = linked_749.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_748, arg_751) }
//line :94:1
	var extra__10 any; var fnbody__757 any = A_arbace_go_run_run_extra__1938000090_A_New_O(srcs__7); var tmp7 *jrt.Class
	var fncls__756 /*line :94:1*/*jrt.Class = A_arbace_go_run_run_extra__1938000090_A_fn_class














	if fncls__756 == nil { var fncls__756d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, fnbody__757); A_arbace_go_run_run_extra__1938000090_A_fn_class = fncls__756d; tmp7 = fncls__756d } else { tmp7 = fncls__756 }; extra__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__757, tmp7, nil)
//line :94:1
	var define__11 any; var fnbody__841 any = A_arbace_go_run_run_define__1938000092_A_New_O_O_O(srcs__7, inits__8, deps__9); var tmp8 *jrt.Class
	var fncls__840 /*line :94:1*/*jrt.Class = A_arbace_go_run_run_define__1938000092_A_fn_class















	if fncls__840 == nil { var fncls__840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, fnbody__841); A_arbace_go_run_run_define__1938000092_A_fn_class = fncls__840d; tmp8 = fncls__840d } else { tmp8 = fncls__840 }; define__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__841, tmp8, nil)
//line :94:1
	var init_order__12 any; var fnbody__913 any = A_arbace_go_run_run_init_order__1938000098_A_New_O_O(inits__8, deps__9); var tmp9 *jrt.Class
	var fncls__912 /*line :94:1*/*jrt.Class = A_arbace_go_run_run_init_order__1938000098_A_fn_class





























	if fncls__912 == nil { var fncls__912d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, fnbody__913); A_arbace_go_run_run_init_order__1938000098_A_fn_class = fncls__912d; tmp9 = fncls__912d } else { tmp9 = fncls__912 }; init_order__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__913, tmp9, nil)
//line :94:1
	var body_load_BANG___13 *A_arbace_go_run_run_load_BANG___1938000102_A = A_arbace_go_run_run_load_BANG___1938000102_A_New_O_O_O_O_O(root__0, extra__10, srcs__7, index__6, define__11); var load_BANG___13 any; var fnbody__1083 any = any(body_load_BANG___13); var tmp10 *jrt.Class; var fncls__1082 *jrt.Class = A_arbace_go_run_run_load_BANG___1938000102_A_fn_class; if fncls__1082 == nil { var fncls__1082d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, fnbody__1083); A_arbace_go_run_run_load_BANG___1938000102_A_fn_class = fncls__1082d; tmp10 = fncls__1082d } else { tmp10 = fncls__1082 }; load_BANG___13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1083, tmp10, nil); var seq_1938000109__14 any; var root_1084 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1086 lang.IFn














































	if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any; var root_1088 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, A_arbace_go_run_imports_of_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = src__4; if linked_1089 == nil { arg_1087 = ifn_1090.Invoke_O__O(arg_1091) } else { arg_1087 = linked_1089.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1088, arg_1091) }; if linked_1085 == nil { seq_1938000109__14 = ifn_1086.Invoke_O__O(arg_1087) } else { seq_1938000109__14 = linked_1085.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1084, arg_1087) }
//line :94:1
	var chunk_1938000110__15 any; var count_1938000111__16 int64 = 0; var i_1938000112__17 int64 = 0; L1: for {














































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000112__17, count_1938000111__16) { var p__18 any = lang.Indexed_Cast(chunk_1938000110__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000112__17)); lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__18, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_52.Invoke_O__O(src__4)))); seq_1938000109__14, chunk_1938000110__15, count_1938000111__16, i_1938000112__17 = seq_1938000109__14, chunk_1938000110__15, count_1938000111__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000112__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1092 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = seq_1938000109__14; if linked_1093 == nil { temp__1927000414__auto____18 = ifn_1094.Invoke_O__O(arg_1095) } else { temp__1927000414__auto____18 = linked_1093.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1092, arg_1095) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000109__19 any = temp__1927000414__auto____18; var tmp11 any; var root_1096 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = seq_1938000109__19; if linked_1097 == nil { tmp11 = ifn_1098.Invoke_O__O(arg_1099) } else { tmp11 = linked_1097.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1096, arg_1099) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____20 any; var root_1100 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = seq_1938000109__19; if linked_1101 == nil { c__1927000678__auto____20 = ifn_1102.Invoke_O__O(arg_1103) } else { c__1927000678__auto____20 = linked_1101.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1100, arg_1103) }; var tmp12 any; var root_1108 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = seq_1938000109__19; if linked_1109 == nil { tmp12 = ifn_1110.Invoke_O__O(arg_1111) } else { tmp12 = linked_1109.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1108, arg_1111) }; seq_1938000109__14, chunk_1938000110__15, count_1938000111__16, i_1938000112__17 = tmp12, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__20 any; var root_1104 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = seq_1938000109__19; if linked_1105 == nil { p__20 = ifn_1106.Invoke_O__O(arg_1107) } else { p__20 = linked_1105.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1104, arg_1107) }; lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__20, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_52.Invoke_O__O(src__4)))); var tmp13 any; var root_1112 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = seq_1938000109__19; if linked_1113 == nil { tmp13 = ifn_1114.Invoke_O__O(arg_1115) } else { tmp13 = linked_1113.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1112, arg_1115) }; seq_1938000109__14, chunk_1938000110__15, count_1938000111__16, i_1938000112__17 = tmp13, nil, 0, 0; continue L1 } } }
//line :94:1
		break L1 }; var r__13 any; var root_914 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, A_arbace_go_run_check_BANG__A_fn_class); var ifn_916 lang.IFn















































	if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = src__4; var arg_918 any = extra__10; if linked_915 == nil { r__13 = ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { r__13 = linked_915.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_914, arg_917, arg_918) }
//line :94:1
	var ___14 any; var root_919 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_921 lang.IFn; _ = ___14
















































	if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = srcs__7; var arg_923 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var arg_924 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__4); var arg_925 any = src__4; if linked_920 == nil { ___14 = ifn_921.Invoke_O_O_O_O__O(arg_922, arg_923, arg_924, arg_925) } else { ___14 = linked_920.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_919, arg_922, arg_923, arg_924, arg_925) }
//line :94:1
	var map__1938000113__15 any = lang.IFn_Cast(define__11).Invoke_O_O__O(src__4, r__13); var map__1938000113__16 any















































	if lang.ISeq_InstanceOf(map__1938000113__15) { var tmp14 any; var root_926 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = map__1938000113__15; if linked_927 == nil { tmp14 = ifn_928.Invoke_O__O(arg_929) } else { tmp14 = linked_927.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_926, arg_929) }; if jrt.J2g_Truth(tmp14) { var tmp15 any; var root_930 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = map__1938000113__15; if linked_931 == nil { tmp15 = ifn_932.Invoke_O__O(arg_933) } else { tmp15 = linked_931.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_930, arg_933) }; map__1938000113__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp15)).Ref() } else { var tmp16 any; var root_934 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = map__1938000113__15; if linked_935 == nil { tmp16 = ifn_936.Invoke_O__O(arg_937) } else { tmp16 = linked_935.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_934, arg_937) }; if jrt.J2g_Truth(tmp16) { var root_938 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = map__1938000113__15; if linked_939 == nil { map__1938000113__16 = ifn_940.Invoke_O__O(arg_941) } else { map__1938000113__16 = linked_939.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_938, arg_941) } } else { map__1938000113__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1938000113__16 = map__1938000113__15 }
//line :94:1
	var main__17 any = lang.RT_Get_O_O__O_NoInit(map__1938000113__16, A_arbace_go_run_A_const_114)


















































	if jrt.J2g_Truth(main__17) { } else {
		var root_1116 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, A_arbace_go_run_fail_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = A_arbace_go_run_A_const_66; var arg_1120 any = Lit_8; var arg_1121 any = Lit_131; if linked_1117 == nil { ifn_1118.Invoke_O_O_O__O(arg_1119, arg_1120, arg_1121) } else { linked_1117.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1116, arg_1119, arg_1120, arg_1121) } }
	var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_115.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_116.GetRawRoot__O()); var tmp19 any; var root_953 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = inits__8; if linked_954 == nil { tmp19 = ifn_955.Invoke_O__O(arg_956) } else { tmp19 = linked_954.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_953, arg_956) }; return tmp17.Invoke_O_O_O__O(Lit_132, lang.RT_Object_array_O__O1_NoInit(tmp18.Invoke_O_O__O(tmp19, lang.IFn_Cast(init_order__12).Invoke__O())).Ref(), main__17) }
//line :105:1
func A_arbace_go_run_run_fn__1938000088_A_New_O(p0 any) *A_arbace_go_run_run_fn__1938000088_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_fn__1938000088_A{}; t.Ctor_O(p0); return t }
//line :105:1
func (t *A_arbace_go_run_run_fn__1938000088_A) Ctor_O(c__pf any) { t.F_pf = c__pf }
//line :105:1
func (t *A_arbace_go_run_run_fn__1938000088_A) Invoke_O__O(self any) any { var root_734 any = A_arbace_go_run_A_const_82.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, A_arbace_go_run_dir_test_index_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var t_ any = t.F_pf; t.F_pf = nil; arg_737 = t_; if linked_735 == nil { return ifn_736.Invoke_O__O(arg_737) } else { return linked_735.(*A_arbace_go_run_dir_test_index_A).Invoke_O_O__O(root_734, arg_737) } }



func A_arbace_go_run_run_extra__1938000090_A_New_O(p0 any) *A_arbace_go_run_run_extra__1938000090_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_extra__1938000090_A{}; t.Ctor_O(p0); return t }
//line :109:1
func (t *A_arbace_go_run_run_extra__1938000090_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :109:1
func (t *A_arbace_go_run_run_extra__1938000090_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_752 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = t.F_srcs; if linked_753 == nil { tmp1 = ifn_754.Invoke_O__O(arg_755) } else { tmp1 = linked_753.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_752, arg_755) }; return lang.RT_Get_O_O__O_NoInit(tmp1, path__1) }
func A_arbace_go_run_run_define__1938000092_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000092_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000092_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :110:1
func (t *A_arbace_go_run_run_define__1938000092_A) Ctor_O_O_O(c__srcs, c__inits, c__deps any) { t.F_srcs = c__srcs; t.F_inits = c__inits; t.F_deps = c__deps }
//line :110:1
func (t *A_arbace_go_run_run_define__1938000092_A) Invoke_O_O_O__O(self, src__1, r__2 any) any { var st__3 any; var root_758 any = A_arbace_go_run_A_const_83.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_760 lang.IFn; if
												linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any; var tmp1 any = A_arbace_go_run_A_const_52; var tmp2 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var tmp3 any = A_arbace_go_run_A_const_85; var tmp4 any = A_arbace_go_run_A_const_85.Invoke_O__O(src__1); var tmp5 any = A_arbace_go_run_A_const_86; var tmp6 any; var root_762 any = A_arbace_go_run_A_const_87.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_133, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_85.Invoke_O__O(src__1))).Ref(); if linked_763 == nil { tmp6 = ifn_764.Invoke_O__O(arg_765) } else { tmp6 = linked_763.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_762, arg_765) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_run_A_const_88; var tmp9 any = A_arbace_go_run_A_const_88.Invoke_O__O(src__1); var tmp10 any = A_arbace_go_run_A_const_89; var tmp11 any = A_arbace_go_run_A_const_89.Invoke_O__O(src__1); var tmp12 any = A_arbace_go_run_A_const_90; var tmp13 any = A_arbace_go_run_A_const_90.Invoke_O__O(src__1); var tmp14 any = A_arbace_go_run_A_const_53; var tmp15 any; var root_766 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_768 lang.IFn; if
												linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__1); if linked_767 == nil { tmp15 = ifn_768.Invoke_O__O(arg_769) } else { tmp15 = linked_767.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_766, arg_769) }; arg_761 = /*line :111:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, A_arbace_go_run_A_const_92, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_93, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_94, lang.PersistentArrayMap_EMPTY.Ref())); if linked_759 == nil { st__3 = ifn_760.Invoke_O__O(arg_761) } else { st__3 = linked_759.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_758, arg_761) }; var root_792 any =

	A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var arg_796 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var arg_797 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var arg_798 any = st__3; if linked_793 == nil { ifn_794.Invoke_O_O_O_O__O(arg_795, arg_796, arg_797, arg_798) } else { linked_793.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_792, arg_795, arg_796, arg_797, arg_798) }; var d__4 any; var tmp16 /*line :110:1*/*lang.Compiler_AOTFn; var fnbody__791 any = A_arbace_go_run_run_define__1938000092_fn__1938000093_A_New_O_O_O(src__1, r__2, st__3); var tmp17 *jrt.Class; var fncls__790 *jrt.Class = A_arbace_go_run_run_define__1938000092_fn__1938000093_A_fn_class; if



	fncls__790 == nil { var fncls__790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__791); A_arbace_go_run_run_define__1938000092_fn__1938000093_A_fn_class = fncls__790d; tmp17 = fncls__790d } else { tmp17 = fncls__790 }; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__791, tmp17, nil); d__4 = Up_Compiler_AOTFn_IFn(tmp16).Invoke__O(); var tmp18 /*line :120:1*/*lang.Volatile = lang.Volatile_Cast(t.F_inits); var tmp19 any; var root_799 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = jrt.NN(lang.Volatile_Cast(t.F_inits)).Deref__O(); var arg_803 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var arg_804 any; var root_805 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = A_arbace_go_run_A_const_102.Invoke_O__O(d__4); var arg_809 any = A_arbace_go_run_A_const_103.Invoke_O__O(d__4); if linked_806 == nil { arg_804 = ifn_807.Invoke_O_O__O(arg_808, arg_809) } else { arg_804 = linked_806.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_805, arg_808, arg_809) }; if linked_800 == nil { tmp19 = ifn_801.Invoke_O_O_O__O(arg_802, arg_803, arg_804) } else { tmp19 = linked_800.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_799, arg_802, arg_803, arg_804) }; jrt.NN(tmp18).Reset_O__O(tmp19); var tmp20 /*line :121:1*/*lang.Volatile = lang.Volatile_Cast(t.F_deps); var tmp21 any; var root_810 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = jrt.NN(lang.Volatile_Cast(t.F_deps)).Deref__O(); var arg_814 any = A_arbace_go_run_A_const_52.Invoke_O__O(src__1); var arg_815 any; var root_816 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_820 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var fnbody__835 any = A_arbace_go_run_run_define__1938000092_fn__1938000095_A_New_O(t.F_srcs); var tmp22 *jrt.Class; var fncls__834 *jrt.Class = A_arbace_go_run_run_define__1938000092_fn__1938000095_A_fn_class; if fncls__834 == nil { var fncls__834d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__835); A_arbace_go_run_run_define__1938000092_fn__1938000095_A_fn_class = fncls__834d; tmp22 = fncls__834d } else { tmp22 = fncls__834 }; arg_823 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__835, tmp22, nil); var arg_824 any; var root_836 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_go_run_imports_of_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = src__1; if linked_837 == nil { arg_824 = ifn_838.Invoke_O__O(arg_839) } else { arg_824 = linked_837.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_836, arg_839) }; if linked_821 == nil { arg_819 = ifn_822.Invoke_O_O__O(arg_823, arg_824) } else { arg_819 = linked_821.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_820, arg_823, arg_824) }; if linked_817 == nil { arg_815 = ifn_818.Invoke_O__O(arg_819) } else { arg_815 = linked_817.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_816, arg_819) }; if linked_811 == nil { tmp21 = ifn_812.Invoke_O_O_O__O(arg_813, arg_814, arg_815) } else { tmp21 = linked_811.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_810, arg_813, arg_814, arg_815) }; jrt.NN(tmp20).Reset_O__O(tmp21); return d__4 }
//line :114:1
func A_arbace_go_run_run_define__1938000092_fn__1938000093_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000092_fn__1938000093_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000092_fn__1938000093_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_go_run_run_define__1938000092_fn__1938000093_A) Ctor_O_O_O(c__src, c__r, c__st any) { t.F_src = c__src; t.F_r = c__r; t.F_st = c__st }
//line :114:1
func (t *A_arbace_go_run_run_define__1938000092_fn__1938000093_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_770 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var t_ any = t.F_st; t.F_st = nil; arg_773 = t_; var arg_774 any; var t__2 any = t.F_r; t.F_r = nil; arg_774 = t__2; var arg_775 any = A_arbace_go_run_A_const_96; if linked_771 == nil { tmp1 = ifn_772.Invoke_O_O_O__O(arg_773, arg_774, arg_775) } else { tmp1 = linked_771.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_770, arg_773, arg_774, arg_775) } }; return nil }(); if tmp2 != nil { if lang.ExceptionInfo_InstanceOf(tmp2) { var ex__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp2); var temp__1927000408__auto____4 any; var root_776 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_778 lang.IFn


	if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_97; var tmp4 any; var root_780 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = ex__3; if linked_781 == nil { tmp4 = ifn_782.Invoke_O__O(arg_783) } else { tmp4 = linked_781.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_780, arg_783) }; arg_779 = tmp3.Invoke_O__O(tmp4); if linked_777 == nil { temp__1927000408__auto____4 = ifn_778.Invoke_O__O(arg_779) } else { temp__1927000408__auto____4 = linked_777.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_776, arg_779) }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var er__5 any = temp__1927000408__auto____4; var root_784 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, A_arbace_go_run_fail_A_fn_class); var ifn_786 lang.IFn
		if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = A_arbace_go_run_A_const_66; var arg_788 any = Lit_8; var arg_789 any; var tmp5 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_52; var tmp7 any; var t__3 any = t.F_src; t.F_src = nil; tmp7 = t__3; arg_789 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O__O(tmp7), nil, A_arbace_go_run_A_const_67.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_68.Invoke_O__O(er__5), nil, A_arbace_go_run_A_const_65.Invoke_O__O(er__5))).Ref(); if linked_785 == nil { tmp1 = ifn_786.Invoke_O_O_O__O(arg_787, arg_788, arg_789) } else { tmp1 = linked_785.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_784, arg_787, arg_788, arg_789) } } else {
//line :117:1
			panic(jrt.Thrown(ex__3)) } } else {
//line :114:1
				panic(tmp2) } }; return tmp1 }






func A_arbace_go_run_run_define__1938000092_fn__1938000095_A_New_O(p0 any) *A_arbace_go_run_run_define__1938000092_fn__1938000095_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000092_fn__1938000095_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_go_run_run_define__1938000092_fn__1938000095_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :121:1
func (t *A_arbace_go_run_run_define__1938000092_fn__1938000095_A) Invoke_O_O__O(self, p1__1938000085_SHARP___1 any) any { var root_825 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any; var root_830 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = t.F_srcs; if linked_831 == nil { arg_828 = ifn_832.Invoke_O__O(arg_833) } else { arg_828 = linked_831.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_830, arg_833) }; var arg_829 any = p1__1938000085_SHARP___1; if linked_826 == nil { return ifn_827.Invoke_O_O__O(arg_828, arg_829) } else { return linked_826.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_825, arg_828, arg_829) } }


func A_arbace_go_run_run_init_order__1938000098_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000098_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000098_A{}; t.Ctor_O_O(p0, p1); return t }
//line :124:1
func (t *A_arbace_go_run_run_init_order__1938000098_A) Ctor_O_O(c__inits, c__deps any) { t.F_inits = c__inits; t.F_deps = c__deps }
//line :124:1
func (t *A_arbace_go_run_run_init_order__1938000098_A) Invoke_O__O(self any) any { { var done__1 any = lang.PersistentVector_EMPTY.Ref(); var left__2 any; var root_842 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_844 lang.IFn
											if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var root_846 any = A_arbace_go_run_A_const_108.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = t.F_inits; if linked_851 == nil { arg_849 = ifn_852.Invoke_O__O(arg_853) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_850, arg_853) }; if linked_847 == nil { arg_845 = ifn_848.Invoke_O__O(arg_849) } else { arg_845 = linked_847.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_846, arg_849) }; if linked_843 == nil { left__2 = ifn_844.Invoke_O__O(arg_845) } else { left__2 = linked_843.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_842, arg_845) }
//line :124:1
L1: for {

	var tmp1 any; var root_854 any = A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = left__2; if linked_855 == nil { tmp1 = ifn_856.Invoke_O__O(arg_857) } else { tmp1 = linked_855.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_854, arg_857) }; if jrt.J2g_Truth(tmp1) { return done__1 } else { var p__3 any; var root_858 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_860 lang.IFn

		if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any; var root_862 any = A_arbace_go_run_A_const_109.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any; var root_866 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var fnbody__885 any = A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A_New_O_O(done__1, t.F_deps); var tmp2 *jrt.Class; var fncls__884 *jrt.Class = A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A_fn_class; if fncls__884 == nil { var fncls__884d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, fnbody__885); A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A_fn_class = fncls__884d; tmp2 = fncls__884d } else { tmp2 = fncls__884 }; arg_869 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__885, tmp2, nil); var arg_870 any = left__2; if linked_867 == nil { arg_865 = ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { arg_865 = linked_867.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) }; if linked_863 == nil { arg_861 = ifn_864.Invoke_O__O(arg_865) } else { arg_861 = linked_863.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_862, arg_865) }; if linked_859 == nil { p__3 = ifn_860.Invoke_O__O(arg_861) } else { p__3 = linked_859.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_858, arg_861) }
		var tmp3 any; var root_886 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = done__1; var arg_890 any; var or__1927000174__auto____4 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_890 = or__1927000174__auto____4 } else { var root_891 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any; var root_895 any = A_arbace_go_run_A_const_109.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = left__2; if linked_896 == nil { arg_894 = ifn_897.Invoke_O__O(arg_898) } else { arg_894 = linked_896.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_895, arg_898) }; if linked_892 == nil { arg_890 = ifn_893.Invoke_O__O(arg_894) } else { arg_890 = linked_892.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_891, arg_894) } }; if linked_887 == nil { tmp3 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { tmp3 = linked_887.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; var tmp4 any = tmp3; var tmp5 any; var root_899 any = A_arbace_go_run_A_const_111.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = left__2; var arg_903 any; var or__1927000174__auto____4_2 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4_2) { arg_903 = or__1927000174__auto____4_2 } else { var root_904 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any; var root_908 any = A_arbace_go_run_A_const_109.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = left__2; if linked_909 == nil { arg_907 = ifn_910.Invoke_O__O(arg_911) } else { arg_907 = linked_909.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_908, arg_911) }; if linked_905 == nil { arg_903 = ifn_906.Invoke_O__O(arg_907) } else { arg_903 = linked_905.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_904, arg_907) } }; if linked_900 == nil { tmp5 = ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { tmp5 = linked_900.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_899, arg_902, arg_903) }; done__1, left__2 = tmp4, tmp5; continue L1 } } }; /*line :124:1*/panic("j2g: unreachable") }



func A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A{}; t.Ctor_O_O(p0, p1); return t }
//line :128:1
func (t *A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A) Ctor_O_O(c__done, c__deps any) { t.F_done = c__done; t.F_deps = c__deps }
//line :128:1
func (t *A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A) Invoke_O_O__O(self, p1__1938000086_SHARP___1 any) any { var root_871 any = A_arbace_go_run_A_const_110.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any; var root_876 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = t.F_done; if linked_877 == nil { arg_874 = ifn_878.Invoke_O__O(arg_879) } else { arg_874 = linked_877.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_876, arg_879) }; var arg_875 any; var tmp1 any; var root_880 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = t.F_deps; if linked_881 == nil { tmp1 = ifn_882.Invoke_O__O(arg_883) } else { tmp1 = linked_881.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_880, arg_883) }; arg_875 = lang.RT_Get_O_O__O_NoInit(tmp1, p1__1938000086_SHARP___1); if linked_872 == nil { return ifn_873.Invoke_O_O__O(arg_874, arg_875) } else { return linked_872.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_871, arg_874, arg_875) } }


func A_arbace_go_run_run_load_BANG___1938000102_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_run_run_load_BANG___1938000102_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_load_BANG___1938000102_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :131:1
func (t *A_arbace_go_run_run_load_BANG___1938000102_A) Ctor_O_O_O_O_O(c__root, c__extra, c__srcs, c__index, c__define any) { t.F_root = c__root; t.F_extra = c__extra; t.F_srcs = c__srcs; t.F_index = c__index; t.F_define = c__define }
//line :131:1
func (t *A_arbace_go_run_run_load_BANG___1938000102_A) Invoke_O_O_O__O(self, path__1, seen__2 any) any {
	var tmp1 any; var or__1927000174__auto____3 any; var root_976 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any; var root_981 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = t.F_srcs; if linked_982 == nil { arg_979 = ifn_983.Invoke_O__O(arg_984) } else { arg_979 = linked_982.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_981, arg_984) }; var arg_980 any = path__1; if linked_977 == nil { or__1927000174__auto____3 = ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { or__1927000174__auto____3 = linked_977.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_976, arg_979, arg_980) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_985 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = path__1; if linked_986 == nil { or__1927000174__auto____4 = ifn_987.Invoke_O__O(arg_988) } else { or__1927000174__auto____4 = linked_986.(*aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_985, arg_988) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_989 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = seen__2; var arg_993 any = path__1; if linked_990 == nil { tmp1 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { tmp1 = linked_990.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_989, arg_992, arg_993) } } }; if jrt.J2g_Truth(tmp1) { return nil } else { var temp__1927000414__auto____3 any; var tmp2 any; var root_994 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_996 lang.IFn
		if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = t.F_index; if linked_995 == nil { tmp2 = ifn_996.Invoke_O__O(arg_997) } else { tmp2 = linked_995.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_994, arg_997) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, path__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var f__4 any = temp__1927000414__auto____3; var s__5 any; var G__1938000103__5_ any; var root_998 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_1000 lang.IFn
			if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_77, t.F_root)); var arg_1002 any = path__1; var arg_1003 any; var root_1005 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_1006 == nil { arg_1003 = ifn_1007.Invoke_O__O(arg_1008) } else { arg_1003 = linked_1006.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1005, arg_1008) }; var arg_1004 any = f__4; if linked_999 == nil { G__1938000103__5_ = ifn_1000.Invoke_O_O_O_O__O(arg_1001, arg_1002, arg_1003, arg_1004) } else { G__1938000103__5_ = linked_999.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_998, arg_1001, arg_1002, arg_1003, arg_1004) }; var tmp3 any; var root_1009 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_go_run_full_forms_QMARK__A_fn_class); var ifn_1011 lang.IFn
			if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = t.F_root; var arg_1013 any = f__4; if linked_1010 == nil { tmp3 = ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { tmp3 = linked_1010.(*A_arbace_go_run_full_forms_QMARK__A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }
//line :134:1
			if jrt.J2g_Truth(tmp3) {
				var root_1014 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, A_arbace_go_run_full_lines_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = G__1938000103__5_; var arg_1018 any = jrt.Boolean_TRUE.Ref(); if linked_1015 == nil { s__5 = ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { s__5 = linked_1015.(*A_arbace_go_run_full_lines_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) } } else {
//line :134:1
					s__5 = G__1938000103__5_ }
//line :133:1
			var seq_1938000104__6 any; var root_1033 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1035 lang.IFn


			if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any; var root_1037 any = A_arbace_go_run_A_const_107.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, A_arbace_go_run_imports_of_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = s__5; if linked_1038 == nil { arg_1036 = ifn_1039.Invoke_O__O(arg_1040) } else { arg_1036 = linked_1038.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1037, arg_1040) }; if linked_1034 == nil { seq_1938000104__6 = ifn_1035.Invoke_O__O(arg_1036) } else { seq_1938000104__6 = linked_1034.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1033, arg_1036) }
//line :133:1
			var chunk_1938000105__7 any; var count_1938000106__8 int64 = 0; var i_1938000107__9 int64 = 0; L1: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000107__9, count_1938000106__8) { var p__10 any = lang.Indexed_Cast(chunk_1938000105__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000107__9)); var tmp4 lang.IFn = lang.IFn_Cast(self); var tmp5 any; var root_1057 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = seen__2; var arg_1061 any = path__1; if linked_1058 == nil { tmp5 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { tmp5 = linked_1058.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }; tmp4.Invoke_O_O__O(p__10, tmp5); seq_1938000104__6, chunk_1938000105__7, count_1938000106__8, i_1938000107__9 = seq_1938000104__6, chunk_1938000105__7, count_1938000106__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000107__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_1041 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = seq_1938000104__6; if linked_1042 == nil { temp__1927000414__auto____10 = ifn_1043.Invoke_O__O(arg_1044) } else { temp__1927000414__auto____10 = linked_1042.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1041, arg_1044) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1938000104__11 any = temp__1927000414__auto____10; var tmp6 any; var root_1045 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = seq_1938000104__11; if linked_1046 == nil { tmp6 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp6 = linked_1046.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1045, arg_1048) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____12 any; var root_1049 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = seq_1938000104__11; if linked_1050 == nil { c__1927000678__auto____12 = ifn_1051.Invoke_O__O(arg_1052) } else { c__1927000678__auto____12 = linked_1050.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1049, arg_1052) }; var tmp7 any; var root_1062 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = seq_1938000104__11; if linked_1063 == nil { tmp7 = ifn_1064.Invoke_O__O(arg_1065) } else { tmp7 = linked_1063.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1062, arg_1065) }; seq_1938000104__6, chunk_1938000105__7, count_1938000106__8, i_1938000107__9 = tmp7, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__12 any; var root_1053 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = seq_1938000104__11; if linked_1054 == nil { p__12 = ifn_1055.Invoke_O__O(arg_1056) } else { p__12 = linked_1054.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1053, arg_1056) }; var tmp8 lang.IFn = lang.IFn_Cast(self); var tmp9 any; var root_1066 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = seen__2; var arg_1070 any = path__1; if linked_1067 == nil { tmp9 = ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { tmp9 = linked_1067.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) }; tmp8.Invoke_O_O__O(p__12, tmp9); var tmp10 any; var root_1071 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = seq_1938000104__11; if linked_1072 == nil { tmp10 = ifn_1073.Invoke_O__O(arg_1074) } else { tmp10 = linked_1072.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1071, arg_1074) }; seq_1938000104__6, chunk_1938000105__7, count_1938000106__8, i_1938000107__9 = tmp10, nil, 0, 0; continue L1 } } }
//line :133:1
				break L1
			}


			var tmp11 any; var root_1019 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any; var root_1024 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = t.F_srcs; if linked_1025 == nil { arg_1022 = ifn_1026.Invoke_O__O(arg_1027) } else { arg_1022 = linked_1025.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1024, arg_1027) }; var arg_1023 any = path__1; if linked_1020 == nil { tmp11 = ifn_1021.Invoke_O_O__O(arg_1022, arg_1023) } else { tmp11 = linked_1020.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1019, arg_1022, arg_1023) }; if jrt.J2g_Truth(tmp11) { return nil } else { var r__6 any; var root_1028 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, A_arbace_go_run_check_BANG__A_fn_class); var ifn_1030 lang.IFn
				if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = s__5; var arg_1032 any = t.F_extra; if linked_1029 == nil { r__6 = ifn_1030.Invoke_O_O__O(arg_1031, arg_1032) } else { r__6 = linked_1029.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_1028, arg_1031, arg_1032) }
				var root_1075 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = t.F_srcs; var arg_1079 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var arg_1080 any = path__1; var arg_1081 any = s__5; if linked_1076 == nil { ifn_1077.Invoke_O_O_O_O__O(arg_1078, arg_1079, arg_1080, arg_1081) } else { linked_1076.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1075, arg_1078, arg_1079, arg_1080, arg_1081) }
				return lang.IFn_Cast(t.F_define).Invoke_O_O__O(s__5, r__6) } } else {
//line :133:1
					return nil
				}
	}
}























func A_arbace_go_run_raw_lines_A_New() *A_arbace_go_run_raw_lines_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_go_run_raw_lines_A) Ctor() {}
//line :160:1
func (t *A_arbace_go_run_raw_lines_A) Invoke_O_O__O(self, x__0 any) any { var walk_meta__2 any; var fnbody__1134 any = A_arbace_go_run_raw_lines_walk_meta__1938000118_A_New(); var tmp1 *jrt.Class; var fncls__1133 *jrt.Class = A_arbace_go_run_raw_lines_walk_meta__1938000118_A_fn_class; if








	fncls__1133 == nil { var fncls__1133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); A_arbace_go_run_raw_lines_walk_meta__1938000118_A_fn_class = fncls__1133d; tmp1 = fncls__1133d } else { tmp1 = fncls__1133 }; walk_meta__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1134, tmp1, nil); var x_SINGLEQUOTE___3 any; var tmp2 any; var root_1135 any = /*line :160:1*/A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1137 lang.IFn; if










	linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = x__0; if linked_1136 == nil { tmp2 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp2 = linked_1136.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1135, arg_1138) }; if /*line :170:1*/ jrt.J2g_Truth(tmp2) {
		var root_1139 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var root_1144 any = A_arbace_go_run_A_const_125.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = A_arbace_go_run_A_const_126.GetRawRoot__O(); var arg_1148 any; var root_1149 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var arg_1153 any = x__0; if linked_1150 == nil { arg_1148 = ifn_1151.Invoke_O_O__O(arg_1152, arg_1153) } else { arg_1148 = linked_1150.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1149, arg_1152, arg_1153) }; if linked_1145 == nil { arg_1142 = ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { arg_1142 = linked_1145.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) }; var arg_1143 any; var G__1938000121__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000121__3_, nil) { arg_1143 = nil } else { arg_1143 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000121__3_) }; if linked_1140 == nil { x_SINGLEQUOTE___3 = ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { x_SINGLEQUOTE___3 = linked_1140.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) } } else {
//line :170:1
			var tmp3 any; var root_1154 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1156 lang.IFn

			if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = x__0; if linked_1155 == nil { tmp3 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp3 = linked_1155.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1154, arg_1157) }
//line :170:1
			if jrt.J2g_Truth(tmp3) {

				var root_1158 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var root_1163 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var arg_1167 any = x__0; if linked_1164 == nil { arg_1161 = ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { arg_1161 = linked_1164.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) }; var arg_1162 any; var G__1938000122__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000122__3_, nil) { arg_1162 = nil } else { arg_1162 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000122__3_) }; if linked_1159 == nil { x_SINGLEQUOTE___3 = ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { x_SINGLEQUOTE___3 = linked_1159.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) } } else {
//line :170:1
					var tmp4 any; var root_1168 any = A_arbace_go_run_A_const_129.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1170 lang.IFn


					if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = x__0; if linked_1169 == nil { tmp4 = ifn_1170.Invoke_O__O(arg_1171) } else { tmp4 = linked_1169.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1168, arg_1171) }
//line :170:1
					if jrt.J2g_Truth(tmp4) {


						var root_1172 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any; var root_1177 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1181 any; var root_1183 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any; var fnbody__1196 any = A_arbace_go_run_raw_lines_fn__1938000124_A_New(); var tmp5 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000124_A_fn_class; if fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, nil); A_arbace_go_run_raw_lines_fn__1938000124_A_fn_class = fncls__1195d; tmp5 = fncls__1195d } else { tmp5 = fncls__1195 }; arg_1186 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1196, tmp5, nil); if linked_1184 == nil { arg_1181 = ifn_1185.Invoke_O__O(arg_1186) } else { arg_1181 = linked_1184.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1183, arg_1186) }; var arg_1182 any = x__0; if linked_1178 == nil { arg_1175 = ifn_1179.Invoke_O_O_O__O(arg_1180, arg_1181, arg_1182) } else { arg_1175 = linked_1178.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1177, arg_1180, arg_1181, arg_1182) }; var arg_1176 any; var G__1938000129__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000129__3_, nil) { arg_1176 = nil } else { arg_1176 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000129__3_) }; if linked_1173 == nil { x_SINGLEQUOTE___3 = ifn_1174.Invoke_O_O__O(arg_1175, arg_1176) } else { x_SINGLEQUOTE___3 = linked_1173.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1172, arg_1175, arg_1176) } } else {
//line :170:1
							var tmp6 any; var root_1197 any = A_arbace_go_run_A_const_130.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1199 lang.IFn



							if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = x__0; if linked_1198 == nil { tmp6 = ifn_1199.Invoke_O__O(arg_1200) } else { tmp6 = linked_1198.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1197, arg_1200) }
//line :170:1
							if jrt.J2g_Truth(tmp6) {



								var root_1201 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = x__0; var arg_1205 any; var G__1938000130__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000130__3_, nil) { arg_1205 = nil } else { arg_1205 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000130__3_) }; if linked_1202 == nil { x_SINGLEQUOTE___3 = ifn_1203.Invoke_O_O__O(arg_1204, arg_1205) } else { x_SINGLEQUOTE___3 = linked_1202.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1201, arg_1204, arg_1205) } } else {
//line :170:1
									if A_arbace_go_run_A_const_31 != nil { x_SINGLEQUOTE___3 = x__0 } else { x_SINGLEQUOTE___3 = nil } } } } }; var m__4 any; if





	lang.IObj_InstanceOf(x_SINGLEQUOTE___3) { m__4 = lang.RT_Meta_O__IPersistentMap_NoInit(x_SINGLEQUOTE___3) } else { m__4 = nil }; var pos__5 any = /*line :160:1*/A_arbace_go_run_A_const_131.Invoke_O__O(m__4); var least__6 any; var fnbody__1255 any = A_arbace_go_run_raw_lines_least__1938000131_A_New(); var tmp7 *jrt.Class; var fncls__1254 *jrt.Class = A_arbace_go_run_raw_lines_least__1938000131_A_fn_class; if




















	fncls__1254 == nil { var fncls__1254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_go_run_raw_lines_least__1938000131_A_fn_class = fncls__1254d; tmp7 = fncls__1254d } else { tmp7 = fncls__1254 }; least__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1255, tmp7, nil); var p__7 any; var or__1927000174__auto____7 any; var tmp8 any; var root_1256 any = /*line :160:1*/A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1258 lang.IFn; if






















	linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = x_SINGLEQUOTE___3; if linked_1257 == nil { tmp8 = ifn_1258.Invoke_O__O(arg_1259) } else { tmp8 = linked_1257.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1256, arg_1259) }; if jrt.J2g_Truth(tmp8) {
		var tmp9 lang.IFn = lang.IFn_Cast(least__6); var tmp10 any; var root_1417 any = A_arbace_go_run_A_const_75.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any; var root_1422 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = A_arbace_go_run_A_const_143.Invoke_O__O(m__4); if linked_1423 == nil { arg_1420 = ifn_1424.Invoke_O__O(arg_1425) } else { arg_1420 = linked_1423.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1422, arg_1425) }; var arg_1421 any; var root_1426 any = A_arbace_go_run_A_const_149.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1428 lang.IFn
		if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any; var fnbody__1432 any = A_arbace_go_run_raw_lines_fn__1938000138_A_New(); var tmp11 *jrt.Class; var fncls__1431 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000138_A_fn_class; if fncls__1431 == nil { var fncls__1431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, nil); A_arbace_go_run_raw_lines_fn__1938000138_A_fn_class = fncls__1431d; tmp11 = fncls__1431d } else { tmp11 = fncls__1431 }; arg_1429 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1432, tmp11, nil); var arg_1430 any = x_SINGLEQUOTE___3; if linked_1427 == nil { arg_1421 = ifn_1428.Invoke_O_O__O(arg_1429, arg_1430) } else { arg_1421 = linked_1427.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1426, arg_1429, arg_1430) }
//line :184:1
		if linked_1418 == nil { tmp10 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { tmp10 = linked_1418.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; or__1927000174__auto____7 = tmp9.Invoke_O__O(tmp10) } else {
//line :183:1
			or__1927000174__auto____7 = nil }; if jrt.J2g_Truth(or__1927000174__auto____7) { p__7 = or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var tmp12 any; var and__1927000168__auto____8 any = A_arbace_go_run_A_const_136.Get__O()


				if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_1260 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = x_SINGLEQUOTE___3; if linked_1261 == nil { and__1927000168__auto____9 = ifn_1262.Invoke_O__O(arg_1263) } else { and__1927000168__auto____9 = linked_1261.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1260, arg_1263) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1264 any = A_arbace_go_run_A_const_129.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = pos__5; if linked_1265 == nil { and__1927000168__auto____10 = ifn_1266.Invoke_O__O(arg_1267) } else { and__1927000168__auto____10 = linked_1265.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1264, arg_1267) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_1268 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = A_arbace_go_run_A_const_137.Invoke_O__O(pos__5); if linked_1269 == nil { and__1927000168__auto____11 = ifn_1270.Invoke_O__O(arg_1271) } else { and__1927000168__auto____11 = linked_1269.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1268, arg_1271) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_1272 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = A_arbace_go_run_A_const_138.Invoke_O__O(pos__5); if linked_1273 == nil { tmp12 = ifn_1274.Invoke_O__O(arg_1275) } else { tmp12 = linked_1273.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1272, arg_1275) } } else { tmp12 = and__1927000168__auto____11 } } else { tmp12 = and__1927000168__auto____10 } } else { tmp12 = and__1927000168__auto____9 } } else { tmp12 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp12) { or__1927000174__auto____8 = A_arbace_go_run_A_const_137.Invoke_O__O(pos__5) } else { or__1927000174__auto____8 = nil }
//line :183:1
				if jrt.J2g_Truth(or__1927000174__auto____8) { p__7 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var tmp13 any; var and__1927000168__auto____9_2 any = A_arbace_go_run_A_const_136.Get__O()



					if jrt.J2g_Truth(and__1927000168__auto____9_2) { var and__1927000168__auto____10_2 any; var root_1276 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = x_SINGLEQUOTE___3; if linked_1277 == nil { and__1927000168__auto____10_2 = ifn_1278.Invoke_O__O(arg_1279) } else { and__1927000168__auto____10_2 = linked_1277.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1276, arg_1279) }; if jrt.J2g_Truth(and__1927000168__auto____10_2) { var and__1927000168__auto____11_2 any; var root_1280 any = A_arbace_go_run_A_const_129.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = pos__5; if linked_1281 == nil { and__1927000168__auto____11_2 = ifn_1282.Invoke_O__O(arg_1283) } else { and__1927000168__auto____11_2 = linked_1281.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1280, arg_1283) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var and__1927000168__auto____12 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_139); var tmp15 any; var root_1433 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = x_SINGLEQUOTE___3; if linked_1434 == nil { tmp15 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp15 = linked_1434.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1433, arg_1436) }; and__1927000168__auto____12 = tmp14.Invoke_O__O(tmp15); if jrt.J2g_Truth(and__1927000168__auto____12) { var root_1284 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = A_arbace_go_run_A_const_140.Invoke_O__O(pos__5); if linked_1285 == nil { tmp13 = ifn_1286.Invoke_O__O(arg_1287) } else { tmp13 = linked_1285.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1284, arg_1287) } } else { tmp13 = and__1927000168__auto____12 } } else { tmp13 = and__1927000168__auto____11_2 } } else { tmp13 = and__1927000168__auto____10_2 } } else { tmp13 = and__1927000168__auto____9_2 }; if jrt.J2g_Truth(tmp13) { or__1927000174__auto____9 = A_arbace_go_run_A_const_140.Invoke_O__O(pos__5) } else { or__1927000174__auto____9 = nil }
//line :183:1
					if jrt.J2g_Truth(or__1927000174__auto____9) { p__7 = or__1927000174__auto____9 } else {




						var tmp16 any; var root_1288 any = A_arbace_go_run_A_const_129.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = pos__5; if linked_1289 == nil { tmp16 = ifn_1290.Invoke_O__O(arg_1291) } else { tmp16 = linked_1289.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1288, arg_1291) }; if jrt.J2g_Truth(tmp16) { var tmp17 lang.IFn = lang.IFn_Cast(least__6); var tmp18 any; var root_1437 any = A_arbace_go_run_A_const_148.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any; var root_1441 any = A_arbace_go_run_A_const_125.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = A_arbace_go_run_A_const_150.GetRawRoot__O(); var arg_1445 any = pos__5; var arg_1446 any = A_arbace_go_run_A_const_151; if linked_1442 == nil { arg_1440 = ifn_1443.Invoke_O_O_O__O(arg_1444, arg_1445, arg_1446) } else { arg_1440 = linked_1442.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1441, arg_1444, arg_1445, arg_1446) }; if linked_1438 == nil { tmp18 = ifn_1439.Invoke_O__O(arg_1440) } else { tmp18 = linked_1438.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1437, arg_1440) }; p__7 = tmp17.Invoke_O__O(tmp18) } else { p__7 = nil } } } }; var pk__8 any; var or__1927000174__auto____8_2 any = /*line :160:1*/A_arbace_go_run_A_const_141.Get__O(); if




























	jrt.J2g_Truth(or__1927000174__auto____8_2) { pk__8 = or__1927000174__auto____8_2 } else { pk__8 = A_arbace_go_run_A_const_17.GetRawRoot__O() }; var end__9 any; var tmp19 any; var root_1292 any = /*line :160:1*/A_arbace_go_run_A_const_129.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1294 lang.IFn; if































	linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = pos__5; if linked_1293 == nil { tmp19 = ifn_1294.Invoke_O__O(arg_1295) } else { tmp19 = linked_1293.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1292, arg_1295) }; if jrt.J2g_Truth(tmp19) { var temp__1927000414__auto____9 any = A_arbace_go_run_A_const_142.Invoke_O__O(pos__5); if jrt.J2g_Truth(temp__1927000414__auto____9) { var r__10 any = temp__1927000414__auto____9; var tmp20 any; var root_1296 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = r__10; if linked_1297 == nil { tmp20 = ifn_1298.Invoke_O__O(arg_1299) } else { tmp20 = linked_1297.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1296, arg_1299) }; if jrt.J2g_Truth(tmp20) { end__9 = lang.IFn_Cast(pk__8).Invoke_O__O(r__10) } else { end__9 = nil } } else { end__9 = nil } } else { end__9 = nil }; var apos__10 any = /*line :160:1*/A_arbace_go_run_A_const_143.Invoke_O__O(m__4); var tmp21 any; var or__1927000174__auto____11 any = p__7; if

































	jrt.J2g_Truth(or__1927000174__auto____11) { tmp21 = or__1927000174__auto____11 } else { var or__1927000174__auto____12 any = end__9; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp21 = or__1927000174__auto____12 } else { var root_1300 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = apos__10; if linked_1301 == nil { tmp21 = ifn_1302.Invoke_O__O(arg_1303) } else { tmp21 = linked_1301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1300, arg_1303) } } }; if jrt.J2g_Truth(tmp21) {
		var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_144.GetRawRoot__O()); var tmp23 *lang.Compiler_AOTFn; var fnbody__1416 any = A_arbace_go_run_raw_lines_fn__1938000140_A_New_O_O_O_O(p__7, apos__10, end__9, pk__8); var tmp24 *jrt.Class; var fncls__1415 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000140_A_fn_class; if fncls__1415 == nil { var fncls__1415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__1416); A_arbace_go_run_raw_lines_fn__1938000140_A_fn_class = fncls__1415d; tmp24 = fncls__1415d } else { tmp24 = fncls__1415 }; tmp23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1416, tmp24, nil); return tmp22.Invoke_O_O__O(x_SINGLEQUOTE___3, tmp23.Ref()) } else {
//line :194:1
			return x_SINGLEQUOTE___3 } }
//line :169:1
func A_arbace_go_run_raw_lines_walk_meta__1938000118_A_New() *A_arbace_go_run_raw_lines_walk_meta__1938000118_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_walk_meta__1938000118_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000118_A) Ctor() {}
//line :169:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000118_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000119__2_ any = m__1; var tmp1 any; var root_1122 any = A_arbace_go_run_A_const_106.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = m__1; var arg_1126 any = A_arbace_go_run_A_const_120; if linked_1123 == nil { tmp1 = ifn_1124.Invoke_O_O__O(arg_1125, arg_1126) } else { tmp1 = linked_1123.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1122, arg_1125, arg_1126) }; if jrt.J2g_Truth(tmp1) { var root_1127 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = G__1938000119__2_; var arg_1131 any = A_arbace_go_run_A_const_120; var arg_1132 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); if linked_1128 == nil { return ifn_1129.Invoke_O_O_O__O(arg_1130, arg_1131, arg_1132) } else { return linked_1128.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132) } } else { return G__1938000119__2_ } }



func A_arbace_go_run_raw_lines_fn__1938000124_A_New() *A_arbace_go_run_raw_lines_fn__1938000124_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000124_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_go_run_raw_lines_fn__1938000124_A) Ctor() {}
//line :173:1
func (t *A_arbace_go_run_raw_lines_fn__1938000124_A) Invoke_O_O__O(self, p__1938000123__1 any) any { var vec__1938000125__2 any = p__1938000123__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000125__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000125__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1187 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = k__3; if linked_1188 == nil { tmp1 = ifn_1189.Invoke_O__O(arg_1190) } else { tmp1 = linked_1188.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1187, arg_1190) }; var tmp2 any = tmp1; var tmp3 any; var root_1191 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = v__4; if linked_1192 == nil { tmp3 = ifn_1193.Invoke_O__O(arg_1194) } else { tmp3 = linked_1192.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1191, arg_1194) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }







func A_arbace_go_run_raw_lines_least__1938000131_A_New() *A_arbace_go_run_raw_lines_least__1938000131_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_least__1938000131_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_run_raw_lines_least__1938000131_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_run_raw_lines_least__1938000131_A) Invoke_O_O__O(self, ps__1 any) any { var G__1938000132__2_ any = ps__1; var G__1938000132__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000132__2_, nil) { G__1938000132__3_ = nil } else { var root_1206 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any; var fnbody__1224 any = A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A_New(); var tmp1 *jrt.Class; var fncls__1223 *jrt.Class = A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A_fn_class; if fncls__1223 == nil { var fncls__1223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, nil); A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A_fn_class = fncls__1223d; tmp1 = fncls__1223d } else { tmp1 = fncls__1223 }; arg_1209 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1224, tmp1, nil); var arg_1210 any = G__1938000132__2_; if linked_1207 == nil { G__1938000132__3_ = ifn_1208.Invoke_O_O__O(arg_1209, arg_1210) } else { G__1938000132__3_ = linked_1207.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1206, arg_1209, arg_1210) } }; var G__1938000132__4_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000132__3_, nil) { G__1938000132__4_ = nil } else { var root_1225 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = G__1938000132__3_; if linked_1226 == nil { G__1938000132__4_ = ifn_1227.Invoke_O__O(arg_1228) } else { G__1938000132__4_ = linked_1226.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1225, arg_1228) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000132__4_, nil) { return nil } else {
												var root_1229 any = A_arbace_go_run_A_const_133.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any; var fnbody__1253 any = A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A_New(); var tmp2 *jrt.Class; var fncls__1252 *jrt.Class = A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A_fn_class; if fncls__1252 == nil { var fncls__1252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A_fn_class = fncls__1252d; tmp2 = fncls__1252d } else { tmp2 = fncls__1252 }; arg_1232 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1253, tmp2, nil); var arg_1233 any = G__1938000132__4_; if linked_1230 == nil { return ifn_1231.Invoke_O_O__O(arg_1232, arg_1233) } else { return linked_1230.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_1229, arg_1232, arg_1233) } } }
//line :181:1
func A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A_New() *A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A) Invoke_O_O__O(self, p1__1938000116_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1211 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any = p1__1938000116_SHARP___1; if linked_1212 == nil { and__1927000168__auto____2 = ifn_1213.Invoke_O__O(arg_1214) } else { and__1927000168__auto____2 = linked_1212.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1211, arg_1214) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1215 any = A_arbace_go_run_A_const_132.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any; var root_1219 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = p1__1938000116_SHARP___1; if linked_1220 == nil { arg_1218 = ifn_1221.Invoke_O__O(arg_1222) } else { arg_1218 = linked_1220.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1219, arg_1222) }; if linked_1216 == nil { return ifn_1217.Invoke_O__O(arg_1218) } else { return linked_1216.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_1215, arg_1218) } } else { return and__1927000168__auto____2 } }
func A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A_New() *A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A) Ctor() {}
//line :182:1
func (t *A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A) Invoke_O_O_O__O(self, a__1, b__2 any) any { var tmp1 any; var root_1234 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any; var root_1238 any = A_arbace_go_run_A_const_134.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = A_arbace_go_run_A_const_135; var arg_1242 any = b__2; if linked_1239 == nil { arg_1237 = ifn_1240.Invoke_O_O__O(arg_1241, arg_1242) } else { arg_1237 = linked_1239.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1238, arg_1241, arg_1242) }; if linked_1235 == nil { tmp1 = ifn_1236.Invoke_O__O(arg_1237) } else { tmp1 = linked_1235.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1234, arg_1237) }; var tmp2 any = tmp1; var tmp3 any; var root_1243 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any; var root_1247 any = A_arbace_go_run_A_const_134.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = A_arbace_go_run_A_const_135; var arg_1251 any = a__1; if linked_1248 == nil { arg_1246 = ifn_1249.Invoke_O_O__O(arg_1250, arg_1251) } else { arg_1246 = linked_1248.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1247, arg_1250, arg_1251) }; if linked_1244 == nil { tmp3 = ifn_1245.Invoke_O__O(arg_1246) } else { tmp3 = linked_1244.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1243, arg_1246) }; if lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(tmp2, tmp3))) { return b__2 } else { return a__1 } }


func A_arbace_go_run_raw_lines_fn__1938000138_A_New() *A_arbace_go_run_raw_lines_fn__1938000138_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000138_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_go_run_raw_lines_fn__1938000138_A) Ctor() {}
//line :185:1
func (t *A_arbace_go_run_raw_lines_fn__1938000138_A) Invoke_O_O__O(self, p1__1938000117_SHARP___1 any) any { if lang.IMeta_InstanceOf(p1__1938000117_SHARP___1) { var tmp1 *lang.Keyword = A_arbace_go_run_A_const_145; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1938000117_SHARP___1)) } else { return nil } }









func A_arbace_go_run_raw_lines_fn__1938000140_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run_raw_lines_fn__1938000140_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000140_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :195:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_A) Ctor_O_O_O_O(c__p, c__apos, c__end, c__pk any) { t.F_p = c__p; t.F_apos = c__apos; t.F_end = c__end; t.F_pk = c__pk }
//line :195:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000141__2_ any = m__1; var G__1938000141__3_ any; if jrt.J2g_Truth(t.F_p) {
											var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_101.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_68; G__1938000141__3_ = tmp1.Invoke_O_O_O_O_O__O(G__1938000141__2_, tmp2, lang.IFn_Cast(t.F_pk).Invoke_O__O(t.F_p), A_arbace_go_run_A_const_145, t.F_p) } else {
//line :195:1
		G__1938000141__3_ = G__1938000141__2_ }; var G__1938000141__4_ any; if jrt.J2g_Truth(t.F_end) {

			var root_1317 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = G__1938000141__3_; var arg_1321 any = A_arbace_go_run_A_const_146; var arg_1322 any = t.F_end; if linked_1318 == nil { G__1938000141__4_ = ifn_1319.Invoke_O_O_O__O(arg_1320, arg_1321, arg_1322) } else { G__1938000141__4_ = linked_1318.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1317, arg_1320, arg_1321, arg_1322) } } else {
//line :195:1
				G__1938000141__4_ = G__1938000141__3_ }; var tmp3 any; var root_1323 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1325 lang.IFn; if


	linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = t.F_apos; if linked_1324 == nil { tmp3 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp3 = linked_1324.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1323, arg_1326) }; if /*line :195:1*/ jrt.J2g_Truth(tmp3) {


		var root_1327 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = G__1938000141__4_; var arg_1331 any = A_arbace_go_run_A_const_147; var arg_1332 any; var root_1333 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any; var iter__1927001039__auto____5 any; var fnbody__1410 any = A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A_New_O(t.F_pk); var tmp4 *jrt.Class; var fncls__1409 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A_fn_class; if fncls__1409 == nil { var fncls__1409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, fnbody__1410); A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A_fn_class = fncls__1409d; tmp4 = fncls__1409d } else { tmp4 = fncls__1409 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1410, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp6 any; var root_1411 any = A_arbace_go_run_A_const_109.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = t.F_apos; if linked_1412 == nil { tmp6 = ifn_1413.Invoke_O__O(arg_1414) } else { tmp6 = linked_1412.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1411, arg_1414) }; arg_1336 = tmp5.Invoke_O__O(tmp6); if linked_1334 == nil { arg_1332 = ifn_1335.Invoke_O__O(arg_1336) } else { arg_1332 = linked_1334.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1333, arg_1336) }; if linked_1328 == nil { return ifn_1329.Invoke_O_O_O__O(arg_1330, arg_1331, arg_1332) } else { return linked_1328.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1327, arg_1330, arg_1331, arg_1332) } } else {
//line :195:1
			return G__1938000141__4_ } }


func A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A_New_O(p0 any) *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A) Ctor_O(c__pk any) { t.F_pk = c__pk }
//line :198:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A) Invoke_O_O__O(self, s__1938000143__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1408 any = A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A_New_O_O_O(self, t.F_pk, s__1938000143__1); var tmp2 *jrt.Class; var fncls__1407 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A_fn_class; if fncls__1407 == nil { var fncls__1407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__1408); A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A_fn_class = fncls__1407d; tmp2 = fncls__1407d } else { tmp2 = fncls__1407 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1408, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :198:1
func A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :198:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A) Ctor_O_O_O(c__iter__1938000142, c__pk, c__s__1938000143 any) { t.F_iter__1938000142 = c__iter__1938000142; t.F_pk = c__pk; t.F_s__1938000143 = c__s__1938000143 }
//line :198:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A) Invoke_O__O(self any) any { { var s__1938000143__1 any; var t_ any = t.F_s__1938000143; t.F_s__1938000143 = nil; s__1938000143__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1337 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = s__1938000143__1; if linked_1338 == nil { temp__1927000414__auto____2 = ifn_1339.Invoke_O__O(arg_1340) } else { temp__1927000414__auto____2 = linked_1338.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1337, arg_1340) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000143__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1341 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = s__1938000143__3; if linked_1342 == nil { tmp1 = ifn_1343.Invoke_O__O(arg_1344) } else { tmp1 = linked_1342.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1341, arg_1344) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1345 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = s__1938000143__3; if linked_1346 == nil { c__1927001037__auto____4 = ifn_1347.Invoke_O__O(arg_1348) } else { c__1927001037__auto____4 = linked_1346.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1345, arg_1348) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000145__6 any; var root_1349 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1350 == nil { b__1938000145__6 = ifn_1351.Invoke_O__O(arg_1352) } else { b__1938000145__6 = linked_1350.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1349, arg_1352) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1363 any = A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A_New_O_O_I_O(b__1938000145__6, t.F_pk, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1362 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A_fn_class; if fncls__1362 == nil { var fncls__1362d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__1363); A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A_fn_class = fncls__1362d; tmp3 = fncls__1362d } else { tmp3 = fncls__1362 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1363, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1364 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any; var root_1369 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = b__1938000145__6; if linked_1370 == nil { arg_1367 = ifn_1371.Invoke_O__O(arg_1372) } else { arg_1367 = linked_1370.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1369, arg_1372) }; var arg_1368 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000142); var tmp5 any; var root_1373 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = s__1938000143__3; if linked_1374 == nil { tmp5 = ifn_1375.Invoke_O__O(arg_1376) } else { tmp5 = linked_1374.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1373, arg_1376) }; arg_1368 = tmp4.Invoke_O__O(tmp5); if linked_1365 == nil { return ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { return linked_1365.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) } } else { var root_1377 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any; var root_1382 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = b__1938000145__6; if linked_1383 == nil { arg_1380 = ifn_1384.Invoke_O__O(arg_1385) } else { arg_1380 = linked_1383.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1382, arg_1385) }; var arg_1381 any; if linked_1378 == nil { return ifn_1379.Invoke_O_O__O(arg_1380, arg_1381) } else { return linked_1378.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1377, arg_1380, arg_1381) } } } else { var vec__1938000153__4 any; var root_1386 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = s__1938000143__3; if linked_1387 == nil { vec__1938000153__4 = ifn_1388.Invoke_O__O(arg_1389) } else { vec__1938000153__4 = linked_1387.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1386, arg_1389) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000153__4, lang.RT_IntCast_J__I_NoInit(0), nil); var q__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000153__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_1390 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1392 lang.IFn; if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any = q__6; if linked_1391 == nil { tmp6 = ifn_1392.Invoke_O__O(arg_1393) } else { tmp6 = linked_1391.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1390, arg_1393) }; if jrt.J2g_Truth(tmp6) { var root_1394 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = lang.Tuple_Create_O_O__IPersistentVector(i__5, lang.IFn_Cast(t.F_pk).Invoke_O__O(q__6)); var arg_1398 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000142); var tmp8 any; var root_1399 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = s__1938000143__3; if linked_1400 == nil { tmp8 = ifn_1401.Invoke_O__O(arg_1402) } else { tmp8 = linked_1400.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1399, arg_1402) }; arg_1398 = tmp7.Invoke_O__O(tmp8); if linked_1395 == nil { return ifn_1396.Invoke_O_O__O(arg_1397, arg_1398) } else { return linked_1395.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1394, arg_1397, arg_1398) } } else { var tmp9 any; var root_1403 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = s__1938000143__3; if linked_1404 == nil { tmp9 = ifn_1405.Invoke_O__O(arg_1406) } else { tmp9 = linked_1404.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1403, arg_1406) }; s__1938000143__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :198:1
func A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :198:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A) Ctor_O_O_I_O(c__b__1938000145, c__pk any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000145 = c__b__1938000145; t.F_pk = c__pk; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :198:1
func (t *A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A) Invoke_O__O(self any) any { { var i__1938000144__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000144__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1938000149__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000144__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000149__2, lang.RT_IntCast_J__I_NoInit(0), nil); var q__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000149__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_1353 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = q__4; if linked_1354 == nil { tmp2 = ifn_1355.Invoke_O__O(arg_1356) } else { tmp2 = linked_1354.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1353, arg_1356) }; if jrt.J2g_Truth(tmp2) { var root_1357 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = t.F_b__1938000145; var arg_1361 any = lang.Tuple_Create_O_O__IPersistentVector(i__3, lang.IFn_Cast(t.F_pk).Invoke_O__O(q__4)); if linked_1358 == nil { ifn_1359.Invoke_O_O__O(arg_1360, arg_1361) } else { linked_1358.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1357, arg_1360, arg_1361) }; i__1938000144__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000144__1); continue L1 } else { i__1938000144__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000144__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_run_directives_A_New() *A_arbace_go_run_directives_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_directives_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_go_run_directives_A) Ctor() {}
//line :201:1
func (t *A_arbace_go_run_directives_A) Invoke_O_O__O(self, comments__0 any) any { { var cs__2 any; var root_1447 any = A_arbace_go_run_A_const_152.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_1449 lang.IFn






	if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any; var fnbody__1462 any = A_arbace_go_run_directives_fn__1938000161_A_New(); var tmp1 *jrt.Class; var fncls__1461 *jrt.Class = A_arbace_go_run_directives_fn__1938000161_A_fn_class; if fncls__1461 == nil { var fncls__1461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_go_run_directives_fn__1938000161_A_fn_class = fncls__1461d; tmp1 = fncls__1461d } else { tmp1 = fncls__1461 }; arg_1450 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1462, tmp1, nil); var arg_1451 any = comments__0; if linked_1448 == nil { cs__2 = ifn_1449.Invoke_O_O__O(arg_1450, arg_1451) } else { cs__2 = linked_1448.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_1447, arg_1450, arg_1451) }
//line :201:1
	var prev__3 any; var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____5 any; var root_1463 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1465 lang.IFn







		if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = cs__2; if linked_1464 == nil { temp__1927000408__auto____5 = ifn_1465.Invoke_O__O(arg_1466) } else { temp__1927000408__auto____5 = linked_1464.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1463, arg_1466) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var vec__1938000163__6 any = temp__1927000408__auto____5; var l__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000163__6, lang.RT_IntCast_J__I_NoInit(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000163__6, lang.RT_IntCast_J__I_NoInit(1), nil); var t__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000163__6, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__1938000166__10 any; var tmp2 any; var and__1927000168__auto____10 bool = lang.Util_Equiv_J_J__Z_NoInit(1, lang.RT_LongCast_O__J_NoInit(c__8))

			if and__1927000168__auto____10 { var root_1467 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = t__9; var arg_1471 any = Lit_45; if linked_1468 == nil { tmp2 = ifn_1469.Invoke_O_O__O(arg_1470, arg_1471) } else { tmp2 = linked_1468.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1467, arg_1470, arg_1471) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }
//line :210:1
			if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_1496 any = A_arbace_go_run_A_const_156.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1498 lang.IFn
				if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = t__9; var arg_1500 any = A_arbace_go_run_A_const_157; if linked_1497 == nil { tmp3 = ifn_1498.Invoke_O_O__O(arg_1499, arg_1500) } else { tmp3 = linked_1497.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1496, arg_1499, arg_1500) }
//line :210:1
				vec__1938000166__10 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(l__7))).Ref(), A_arbace_go_run_A_const_158)) } else { var tmp4 any; var and__1927000168__auto____10_2 any; var root_1472 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1474 lang.IFn

					if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = t__9; var arg_1476 any = Lit_46; if linked_1473 == nil { and__1927000168__auto____10_2 = ifn_1474.Invoke_O_O__O(arg_1475, arg_1476) } else { and__1927000168__auto____10_2 = linked_1473.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1472, arg_1475, arg_1476) }; if jrt.J2g_Truth(and__1927000168__auto____10_2) { var root_1477 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = t__9; var arg_1481 any = Lit_47; if linked_1478 == nil { tmp4 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { tmp4 = linked_1478.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) } } else { tmp4 = and__1927000168__auto____10_2 }
//line :210:1
					if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1501 any = A_arbace_go_run_A_const_156.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1503 lang.IFn


						if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = t__9; var arg_1505 any = A_arbace_go_run_A_const_157; var arg_1506 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t__9)), 2)).Ref(); if linked_1502 == nil { tmp5 = ifn_1503.Invoke_O_O_O__O(arg_1504, arg_1505, arg_1506) } else { tmp5 = linked_1502.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1501, arg_1504, arg_1505, arg_1506) }
//line :210:1
						vec__1938000166__10 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.Tuple_Create_O_O__IPersistentVector(l__7, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(c__8), int64(lang.RT_Count_O__I_NoInit(t__9)))).Ref())) } else { if A_arbace_go_run_A_const_31 != nil { vec__1938000166__10 = nil } else { vec__1938000166__10 = nil } } }
//line :209:1
			var body__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000166__10, lang.RT_IntCast_J__I_NoInit(0), nil); var from__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000166__10, lang.RT_IntCast_J__I_NoInit(1), nil); var d__13 any





			if jrt.J2g_Truth(body__11) { var or__1927000174__auto____13 any; var temp__1927000414__auto____13 any; var root_1482 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1484 lang.IFn
				if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = A_arbace_go_run_A_const_154; var arg_1486 any = body__11; if linked_1483 == nil { temp__1927000414__auto____13 = ifn_1484.Invoke_O_O__O(arg_1485, arg_1486) } else { temp__1927000414__auto____13 = linked_1483.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1482, arg_1485, arg_1486) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var vec__1938000169__14 any = temp__1927000414__auto____13; var ___15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000169__14, lang.RT_IntCast_J__I_NoInit(0), nil); var f__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000169__14, lang.RT_IntCast_J__I_NoInit(1), nil); var n__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000169__14, lang.RT_IntCast_J__I_NoInit(2), nil); var _c__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000169__14, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp6 any; _ = ___15; _ = _c__18
					if lang.Util_Equiv_O_O__Z_NoInit(Lit_41, f__16) { tmp6 = prev__3 } else { tmp6 = f__16 }
//line :216:1
					or__1927000174__auto____13 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__17))).Ref()) } else { or__1927000174__auto____13 = nil }; if jrt.J2g_Truth(or__1927000174__auto____13) { d__13 = or__1927000174__auto____13 } else { var temp__1927000414__auto____14 any; var root_1487 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1489 lang.IFn

						if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = A_arbace_go_run_A_const_155; var arg_1491 any = body__11; if linked_1488 == nil { temp__1927000414__auto____14 = ifn_1489.Invoke_O_O__O(arg_1490, arg_1491) } else { temp__1927000414__auto____14 = linked_1488.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1487, arg_1490, arg_1491) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var vec__1938000172__15 any = temp__1927000414__auto____14; var ___16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000172__15, lang.RT_IntCast_J__I_NoInit(0), nil); var f__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000172__15, lang.RT_IntCast_J__I_NoInit(1), nil); var n__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000172__15, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___16; d__13 = lang.Tuple_Create_O_O__IPersistentVector(f__17, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__18))).Ref()) } else { d__13 = nil } } } else {
//line :215:1
							d__13 = nil
						}



			var tmp7 any; var and__1927000168__auto____14 any = d__13; if jrt.J2g_Truth(and__1927000168__auto____14) { var tmp8 any; var root_1492 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = d__13; if linked_1493 == nil { tmp8 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp8 = linked_1493.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1492, arg_1495) }; tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp8))).Ref() } else { tmp7 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp7) {
				var tmp9 any; var root_1507 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = cs__2; if linked_1508 == nil { tmp9 = ifn_1509.Invoke_O__O(arg_1510) } else { tmp9 = linked_1508.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1507, arg_1510) }; var tmp10 any = tmp9; var tmp11 any; var root_1511 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = d__13; if linked_1512 == nil { tmp11 = ifn_1513.Invoke_O__O(arg_1514) } else { tmp11 = linked_1512.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1511, arg_1514) }; var tmp12 any = tmp11; var tmp13 any; var root_1515 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = acc__4; var arg_1519 any; var tmp14 any; var root_1520 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = from__12; if linked_1521 == nil { tmp14 = ifn_1522.Invoke_O__O(arg_1523) } else { tmp14 = linked_1521.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1520, arg_1523) }; var tmp15 any = tmp14; var tmp16 any; var root_1524 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = from__12; if linked_1525 == nil { tmp16 = ifn_1526.Invoke_O__O(arg_1527) } else { tmp16 = linked_1525.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1524, arg_1527) }; var tmp17 any = tmp16; var tmp18 any; var root_1528 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = d__13; if linked_1529 == nil { tmp18 = ifn_1530.Invoke_O__O(arg_1531) } else { tmp18 = linked_1529.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1528, arg_1531) }; var tmp19 any = tmp18; var tmp20 any; var root_1532 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = d__13; if linked_1533 == nil { tmp20 = ifn_1534.Invoke_O__O(arg_1535) } else { tmp20 = linked_1533.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1532, arg_1535) }; arg_1519 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp15, tmp17, tmp19, tmp20); if linked_1516 == nil { tmp13 = ifn_1517.Invoke_O_O__O(arg_1518, arg_1519) } else { tmp13 = linked_1516.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1515, arg_1518, arg_1519) }; cs__2, prev__3, acc__4 = tmp10, tmp12, tmp13; continue L1 } else {
					var tmp21 any; var root_1536 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = cs__2; if linked_1537 == nil { tmp21 = ifn_1538.Invoke_O__O(arg_1539) } else { tmp21 = linked_1537.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1536, arg_1539) }; cs__2, prev__3, acc__4 = tmp21, prev__3, acc__4; continue L1 } } else {
//line :209:1
						return acc__4 } } }; /*line :201:1*/panic("j2g: unreachable") }






func A_arbace_go_run_directives_fn__1938000161_A_New() *A_arbace_go_run_directives_fn__1938000161_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_directives_fn__1938000161_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_go_run_directives_fn__1938000161_A) Ctor() {}
//line :208:1
func (t *A_arbace_go_run_directives_fn__1938000161_A) Invoke_O_O__O(self, p1__1938000160_SHARP___1 any) any { var root_1452 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any; var root_1456 any = A_arbace_go_run_A_const_134.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = A_arbace_go_run_A_const_135; var arg_1460 any = p1__1938000160_SHARP___1; if linked_1457 == nil { arg_1455 = ifn_1458.Invoke_O_O__O(arg_1459, arg_1460) } else { arg_1455 = linked_1457.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1456, arg_1459, arg_1460) }; if linked_1453 == nil { return ifn_1454.Invoke_O__O(arg_1455) } else { return linked_1453.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1452, arg_1455) } }
















func A_arbace_go_run_key_lines_A_New() *A_arbace_go_run_key_lines_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_go_run_key_lines_A) Ctor() {}
//line :225:1
func (t *A_arbace_go_run_key_lines_A) Invoke_O_O__O(self, fi__0 any) any { var tmp1 *lang.Keyword = A_arbace_go_run_A_const_159; var cs__2 any = tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(A_arbace_go_run_A_const_67.Invoke_O__O(fi__0))); var ds__3 any; var tmp2 any; var root_1540 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1542 lang.IFn; if







	linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any; var fnbody__1555 any = A_arbace_go_run_key_lines_fn__1938000177_A_New(); var tmp3 *jrt.Class; var fncls__1554 *jrt.Class = A_arbace_go_run_key_lines_fn__1938000177_A_fn_class; if fncls__1554 == nil { var fncls__1554d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_go_run_key_lines_fn__1938000177_A_fn_class = fncls__1554d; tmp3 = fncls__1554d } else { tmp3 = fncls__1554 }; arg_1543 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1555, tmp3, nil); var arg_1544 any = cs__2; if linked_1541 == nil { tmp2 = ifn_1542.Invoke_O_O__O(arg_1543, arg_1544) } else { tmp2 = linked_1541.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1540, arg_1543, arg_1544) }; if jrt.J2g_Truth(tmp2) { var root_1556 any = A_arbace_go_run_A_const_160.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, A_arbace_go_run_directives_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = cs__2; if linked_1557 == nil { ds__3 = ifn_1558.Invoke_O__O(arg_1559) } else { ds__3 = linked_1557.(*A_arbace_go_run_directives_A).Invoke_O_O__O(root_1556, arg_1559) } } else { ds__3 = nil }; var tmp4 any; var root_1560 any =
	A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = ds__3; if linked_1561 == nil { tmp4 = ifn_1562.Invoke_O__O(arg_1563) } else { tmp4 = linked_1561.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1560, arg_1563) }; if jrt.J2g_Truth(tmp4) { var G__1938000179__4_ any; var root_1564 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1566 lang.IFn
		if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = fi__0; var arg_1568 any = A_arbace_go_run_A_const_54; var arg_1569 any; var fnbody__1576 any = A_arbace_go_run_key_lines_fn__1938000180_A_New(); var tmp5 *jrt.Class; var fncls__1575 *jrt.Class = A_arbace_go_run_key_lines_fn__1938000180_A_fn_class; if fncls__1575 == nil { var fncls__1575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_go_run_key_lines_fn__1938000180_A_fn_class = fncls__1575d; tmp5 = fncls__1575d } else { tmp5 = fncls__1575 }; arg_1569 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1576, tmp5, nil); if linked_1565 == nil { G__1938000179__4_ = ifn_1566.Invoke_O_O_O__O(arg_1567, arg_1568, arg_1569) } else { G__1938000179__4_ = linked_1565.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1564, arg_1567, arg_1568, arg_1569) }
//line :234:1
		var G__1938000179__5_ any
		if jrt.J2g_Truth(A_arbace_go_run_A_const_67.Invoke_O__O(fi__0)) {
			var root_1577 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = G__1938000179__4_; var arg_1581 any = A_arbace_go_run_A_const_67; var arg_1582 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); if linked_1578 == nil { G__1938000179__5_ = ifn_1579.Invoke_O_O_O__O(arg_1580, arg_1581, arg_1582) } else { G__1938000179__5_ = linked_1578.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1577, arg_1580, arg_1581, arg_1582) } } else {
//line :235:1
				G__1938000179__5_ = G__1938000179__4_ }; var tmp6 any; var root_1583 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1585 lang.IFn

		if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = fi__0; var arg_1587 any = A_arbace_go_run_A_const_161; if linked_1584 == nil { tmp6 = ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { tmp6 = linked_1584.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) }
//line :235:1
		if jrt.J2g_Truth(tmp6) {

			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_162.GetRawRoot__O()); var tmp8 any = A_arbace_go_run_A_const_163; return tmp7.Invoke_O_O_O__O(G__1938000179__5_, tmp8, A_arbace_go_run_A_const_122.GetRawRoot__O()) } else {
//line :235:1
				return G__1938000179__5_ } } else {
//line :234:1
					var used__4 any = jrt.TreeMap_New(); var pk__5 any; var fnbody__1612 any = A_arbace_go_run_key_lines_pk__1938000183_A_New_O_O_O(fi__0, ds__3, used__4); var tmp9 *jrt.Class
					var fncls__1611 /*line :234:1*/*jrt.Class = A_arbace_go_run_key_lines_pk__1938000183_A_fn_class




					if fncls__1611 == nil { var fncls__1611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__1612); A_arbace_go_run_key_lines_pk__1938000183_A_fn_class = fncls__1611d; tmp9 = fncls__1611d } else { tmp9 = fncls__1611 }; pk__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1612, tmp9, nil)
//line :234:1
					var fi__6 any; var root_1720 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1722 lang.IFn











					if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_run_A_const_141, pk__5); if linked_1721 == nil { ifn_1722.Invoke_O__O(arg_1723) } else { linked_1721.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1720, arg_1723) }; var tmp10 *lang.Compiler_AOTFn; var fnbody__1647 any = A_arbace_go_run_key_lines_fn__1938000197_A_New_O(fi__0); var tmp11 *jrt.Class; var fncls__1646 *jrt.Class = A_arbace_go_run_key_lines_fn__1938000197_A_fn_class; if fncls__1646 == nil { var fncls__1646d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__1647); A_arbace_go_run_key_lines_fn__1938000197_A_fn_class = fncls__1646d; tmp11 = fncls__1646d } else { tmp11 = fncls__1646 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1647, tmp11, nil); fi__6 = Up_Compiler_AOTFn_IFn(tmp10).Invoke__O()



					var root_1648 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = fi__6; var arg_1652 any = A_arbace_go_run_A_const_167; var arg_1653 any; var root_1654 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any; var iter__1927001039__auto____7 any; var fnbody__1719 any = A_arbace_go_run_key_lines_iter__1938000202__1938000206_A_New(); var tmp12 *jrt.Class; var fncls__1718 *jrt.Class = A_arbace_go_run_key_lines_iter__1938000202__1938000206_A_fn_class; if fncls__1718 == nil { var fncls__1718d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_go_run_key_lines_iter__1938000202__1938000206_A_fn_class = fncls__1718d; tmp12 = fncls__1718d } else { tmp12 = fncls__1718 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1719, tmp12, nil); arg_1657 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(used__4); if linked_1655 == nil { arg_1653 = ifn_1656.Invoke_O__O(arg_1657) } else { arg_1653 = linked_1655.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1654, arg_1657) }; if linked_1649 == nil { return ifn_1650.Invoke_O_O_O__O(arg_1651, arg_1652, arg_1653) } else { return linked_1649.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1648, arg_1651, arg_1652, arg_1653) } } }
//line :233:1
func A_arbace_go_run_key_lines_fn__1938000177_A_New() *A_arbace_go_run_key_lines_fn__1938000177_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_fn__1938000177_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_go_run_key_lines_fn__1938000177_A) Ctor() {}
//line :233:1
func (t *A_arbace_go_run_key_lines_fn__1938000177_A) Invoke_O_O__O(self, p1__1938000176_SHARP___1 any) any { var root_1545 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any; var root_1550 any = A_arbace_go_run_A_const_19.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = lang.RT_Nth_O_I__O_NoInit(p1__1938000176_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)); if linked_1551 == nil { arg_1548 = ifn_1552.Invoke_O__O(arg_1553) } else { arg_1548 = linked_1551.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1550, arg_1553) }; var arg_1549 any = Lit_46; if linked_1546 == nil { return ifn_1547.Invoke_O_O__O(arg_1548, arg_1549) } else { return linked_1546.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1545, arg_1548, arg_1549) } }

func A_arbace_go_run_key_lines_fn__1938000180_A_New() *A_arbace_go_run_key_lines_fn__1938000180_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_fn__1938000180_A{}; t.Ctor(); return t }
//line :235:1
func (t *A_arbace_go_run_key_lines_fn__1938000180_A) Ctor() {}
//line :235:1
func (t *A_arbace_go_run_key_lines_fn__1938000180_A) Invoke_O_O__O(self, d__1 any) any { var root_1570 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var arg_1574 any = d__1; if linked_1571 == nil { return ifn_1572.Invoke_O_O__O(arg_1573, arg_1574) } else { return linked_1571.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1570, arg_1573, arg_1574) } }



func A_arbace_go_run_key_lines_pk__1938000183_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_key_lines_pk__1938000183_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_pk__1938000183_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :239:1
func (t *A_arbace_go_run_key_lines_pk__1938000183_A) Ctor_O_O_O(c__fi, c__ds, c__used any) { t.F_fi = c__fi; t.F_ds = c__ds; t.F_used = c__used }
//line :239:1
func (t *A_arbace_go_run_key_lines_pk__1938000183_A) Invoke_O_O__O(self, p__1938000182__1 any) any { var vec__1938000184__2 any = p__1938000182__1; var l__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000184__2, lang.RT_IntCast_J__I_NoInit(0), nil); var c__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000184__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 int64 = lang.Numbers_Add_J_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(1000, lang.RT_LongCast_O__J_NoInit(l__3)), lang.Numbers_Min_J_J__J_NoInit(999, lang.RT_LongCast_O__J_NoInit(c__4))); var tmp1 jrt.TreeMap_I = jrt.TreeMap_Cast(t.F_used); if

	tmp1.ContainsKey_O__Z(jrt.Long_ValueOf_J__Long_NoInit(k__5).Ref()) { } else { var d__6 any; var root_1594 any = A_arbace_go_run_A_const_164.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_1596 lang.IFn
		if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any; var root_1598 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any; var fnbody__1606 any = A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A_New_O_O(l__3, c__4); var tmp2 *jrt.Class; var fncls__1605 *jrt.Class = A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A_fn_class; if fncls__1605 == nil { var fncls__1605d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__1606); A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A_fn_class = fncls__1605d; tmp2 = fncls__1605d } else { tmp2 = fncls__1605 }; arg_1601 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1606, tmp2, nil); var arg_1602 any = t.F_ds; if linked_1599 == nil { arg_1597 = ifn_1600.Invoke_O_O__O(arg_1601, arg_1602) } else { arg_1597 = linked_1599.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1598, arg_1601, arg_1602) }; if linked_1595 == nil { d__6 = ifn_1596.Invoke_O__O(arg_1597) } else { d__6 = linked_1595.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_1594, arg_1597) }
//line :241:1
		var vec__1938000187__7 any

		if jrt.J2g_Truth(d__6) { var tmp3 any = lang.RT_Nth_O_I__O_NoInit(d__6, lang.RT_IntCast_J__I_NoInit(2)); var tmp4 int64 = lang.RT_LongCast_O__J_NoInit(lang.RT_Nth_O_I__O_NoInit(d__6, lang.RT_IntCast_J__I_NoInit(3))); var tmp5 int64 = lang.RT_LongCast_O__J_NoInit(l__3); var tmp6 any; var root_1607 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = d__6; if linked_1608 == nil { tmp6 = ifn_1609.Invoke_O__O(arg_1610) } else { tmp6 = linked_1608.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1607, arg_1610) }; vec__1938000187__7 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(tmp4, lang.Numbers_Minus_J_J__J_NoInit(tmp5, lang.RT_LongCast_O__J_NoInit(tmp6)))).Ref()) } else { vec__1938000187__7 = lang.Tuple_Create_O_O__IPersistentVector(nil, l__3) }
//line :241:1
		var f__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000187__7, lang.RT_IntCast_J__I_NoInit(0), nil); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000187__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp7 jrt.TreeMap_I = jrt.TreeMap_Cast(t.F_used); var tmp8 any = jrt.Long_ValueOf_J__Long_NoInit(k__5).Ref(); var tmp9 any


		if lang.Util_Identical_O_O__Z_NoInit(f__8, nil) { tmp9 = A_arbace_go_run_A_const_85.Invoke_O__O(t.F_fi) } else { tmp9 = f__8 }; tmp7.Put_O_O__O(tmp8, lang.Tuple_Create_O_O__IPersistentVector(tmp9, n__9)) }; return /*line :239:1*/ jrt.Long_ValueOf_J__Long_NoInit(k__5).Ref() }


func A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A_New_O_O(p0, p1 any) *A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :242:1
func (t *A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A) Ctor_O_O(c__l, c__c any) { t.F_l = c__l; t.F_c = c__c }
//line :242:1
func (t *A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A) Invoke_O_O__O(self, p__1938000190__1 any) any { var vec__1938000192__2 any = p__1938000190__1; var dl__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000192__2, lang.RT_IntCast_J__I_NoInit(0), nil); var dc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000192__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(dl__3)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(dc__4)).Ref()); var tmp2 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(t.F_l)).Ref(); var tmp3 jrt.Number_I; var na_1603 any = t.F_c; if jrt.Long_InstanceOf(na_1603) { var n0_1604 int64 = jrt.NN(jrt.Long_Cast(na_1603)).LongValue__J(); if n0_1604 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_1603) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1604 + 1)) } } else { if jrt.Double_InstanceOf(na_1603) { var n0_1604_2 float64 = jrt.NN(jrt.Double_Cast(na_1603)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1604_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_1603) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(int64(lang.Util_Compare_O_O__I_NoInit(tmp1, lang.Tuple_Create_O_O__IPersistentVector(tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp3)).Ref()))))).Ref() }



func A_arbace_go_run_key_lines_fn__1938000197_A_New_O(p0 any) *A_arbace_go_run_key_lines_fn__1938000197_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_fn__1938000197_A{}; t.Ctor_O(p0); return t }
//line :246:1
func (t *A_arbace_go_run_key_lines_fn__1938000197_A) Ctor_O(c__fi any) { t.F_fi = c__fi }
//line :246:1
func (t *A_arbace_go_run_key_lines_fn__1938000197_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var G__1938000198__3_ any; var root_1613 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1615 lang.IFn
										if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = t.F_fi; var arg_1617 any = A_arbace_go_run_A_const_54; var arg_1618 any; var fnbody__1625 any = A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A_New(); var tmp2 *jrt.Class; var fncls__1624 *jrt.Class = A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A_fn_class; if fncls__1624 == nil { var fncls__1624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, nil); A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A_fn_class = fncls__1624d; tmp2 = fncls__1624d } else { tmp2 = fncls__1624 }; arg_1618 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1625, tmp2, nil); if linked_1614 == nil { G__1938000198__3_ = ifn_1615.Invoke_O_O_O__O(arg_1616, arg_1617, arg_1618) } else { G__1938000198__3_ = linked_1614.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1613, arg_1616, arg_1617, arg_1618) }
//line :246:1
	var G__1938000198__4_ any
	if jrt.J2g_Truth(A_arbace_go_run_A_const_67.Invoke_O__O(t.F_fi)) {
		var root_1626 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = G__1938000198__3_; var arg_1630 any = A_arbace_go_run_A_const_67; var arg_1631 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); if linked_1627 == nil { G__1938000198__4_ = ifn_1628.Invoke_O_O_O__O(arg_1629, arg_1630, arg_1631) } else { G__1938000198__4_ = linked_1627.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1626, arg_1629, arg_1630, arg_1631) } } else {
//line :247:1
			G__1938000198__4_ = G__1938000198__3_ }; var tmp3 any; var root_1632 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1634 lang.IFn

	if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any; var t_ any = t.F_fi; t.F_fi = nil; arg_1635 = t_; var arg_1636 any = A_arbace_go_run_A_const_165; if linked_1633 == nil { tmp3 = ifn_1634.Invoke_O_O__O(arg_1635, arg_1636) } else { tmp3 = linked_1633.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1632, arg_1635, arg_1636) }
//line :247:1
	if jrt.J2g_Truth(tmp3) {

		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_162.GetRawRoot__O()); var tmp5 any = A_arbace_go_run_A_const_166; tmp1 = tmp4.Invoke_O_O_O__O(G__1938000198__4_, tmp5, A_arbace_go_run_A_const_122.GetRawRoot__O()) } else {
//line :247:1
			tmp1 = G__1938000198__4_ } }; return nil }(); var root_1643 any = /*line :246:1*/A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; if linked_1644 == nil { ifn_1645.Invoke__O() } else { linked_1644.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1643) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
func A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A_New() *A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A) Ctor() {}
//line :247:1
func (t *A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A) Invoke_O_O__O(self, d__1 any) any { var root_1619 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var arg_1623 any = d__1; if linked_1620 == nil { return ifn_1621.Invoke_O_O__O(arg_1622, arg_1623) } else { return linked_1620.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1619, arg_1622, arg_1623) } }


func A_arbace_go_run_key_lines_iter__1938000202__1938000206_A_New() *A_arbace_go_run_key_lines_iter__1938000202__1938000206_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_iter__1938000202__1938000206_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_go_run_key_lines_iter__1938000202__1938000206_A) Ctor() {}
//line :250:1
func (t *A_arbace_go_run_key_lines_iter__1938000202__1938000206_A) Invoke_O_O__O(self, s__1938000203__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1717 any = A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A_New_O_O(s__1938000203__1, self); var tmp2 *jrt.Class; var fncls__1716 *jrt.Class = A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A_fn_class; if fncls__1716 == nil { var fncls__1716d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__1717); A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A_fn_class = fncls__1716d; tmp2 = fncls__1716d } else { tmp2 = fncls__1716 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1717, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :250:1
func A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A_New_O_O(p0, p1 any) *A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :250:1
func (t *A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A) Ctor_O_O(c__s__1938000203, c__iter__1938000202 any) { t.F_s__1938000203 = c__s__1938000203; t.F_iter__1938000202 = c__iter__1938000202 }
//line :250:1
func (t *A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A) Invoke_O__O(self any) any { { var s__1938000203__1 any; var t_ any = t.F_s__1938000203; t.F_s__1938000203 = nil; s__1938000203__1 = t_; for { var temp__1927000414__auto____2 any; var root_1658 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = s__1938000203__1; if linked_1659 == nil { temp__1927000414__auto____2 = ifn_1660.Invoke_O__O(arg_1661) } else { temp__1927000414__auto____2 = linked_1659.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1658, arg_1661) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000203__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1662 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = s__1938000203__3; if linked_1663 == nil { tmp1 = ifn_1664.Invoke_O__O(arg_1665) } else { tmp1 = linked_1663.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1662, arg_1665) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1666 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1668 lang.IFn; if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any = s__1938000203__3; if linked_1667 == nil { c__1927001037__auto____4 = ifn_1668.Invoke_O__O(arg_1669) } else { c__1927001037__auto____4 = linked_1667.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1666, arg_1669) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000205__6 any; var root_1670 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1672 lang.IFn; if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1671 == nil { b__1938000205__6 = ifn_1672.Invoke_O__O(arg_1673) } else { b__1938000205__6 = linked_1671.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1670, arg_1673) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1680 any = A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A_New_O_I_O(b__1938000205__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1679 *jrt.Class = A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A_fn_class; if fncls__1679 == nil { var fncls__1679d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__1680); A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A_fn_class = fncls__1679d; tmp3 = fncls__1679d } else { tmp3 = fncls__1679 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1680, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1681 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any; var root_1686 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = b__1938000205__6; if linked_1687 == nil { arg_1684 = ifn_1688.Invoke_O__O(arg_1689) } else { arg_1684 = linked_1687.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1686, arg_1689) }; var arg_1685 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000202); var tmp5 any; var root_1690 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = s__1938000203__3; if linked_1691 == nil { tmp5 = ifn_1692.Invoke_O__O(arg_1693) } else { tmp5 = linked_1691.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1690, arg_1693) }; arg_1685 = tmp4.Invoke_O__O(tmp5); if linked_1682 == nil { return ifn_1683.Invoke_O_O__O(arg_1684, arg_1685) } else { return linked_1682.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1681, arg_1684, arg_1685) } } else { var root_1694 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1694, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any; var root_1699 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = b__1938000205__6; if linked_1700 == nil { arg_1697 = ifn_1701.Invoke_O__O(arg_1702) } else { arg_1697 = linked_1700.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1699, arg_1702) }; var arg_1698 any; if linked_1695 == nil { return ifn_1696.Invoke_O_O__O(arg_1697, arg_1698) } else { return linked_1695.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1694, arg_1697, arg_1698) } } } else { var vec__1938000216__4 any; var root_1703 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = s__1938000203__3; if linked_1704 == nil { vec__1938000216__4 = ifn_1705.Invoke_O__O(arg_1706) } else { vec__1938000216__4 = linked_1704.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1703, arg_1706) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000216__4, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1938000219__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000216__4, lang.RT_IntCast_J__I_NoInit(1), nil); var f__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000219__6, lang.RT_IntCast_J__I_NoInit(0), nil); var n__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000219__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1707 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var tmp6 any = A_arbace_go_run_A_const_68; var tmp7 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(k__5))).Ref(); var tmp8 any = A_arbace_go_run_A_const_168; var arg_1710 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__7, nil, n__8)).Ref())); var arg_1711 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1938000202); var tmp10 any; var root_1712 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = s__1938000203__3; if linked_1713 == nil { tmp10 = ifn_1714.Invoke_O__O(arg_1715) } else { tmp10 = linked_1713.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1712, arg_1715) }; arg_1711 = tmp9.Invoke_O__O(tmp10); if linked_1708 == nil { return ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { return linked_1708.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :250:1
func A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :250:1
func (t *A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A) Ctor_O_I_O(c__b__1938000205 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000205 = c__b__1938000205; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :250:1
func (t *A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A) Invoke_O__O(self any) any { { var i__1938000204__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000204__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1938000209__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000204__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000209__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__1938000212__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000209__2, lang.RT_IntCast_J__I_NoInit(1), nil); var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000212__4, lang.RT_IntCast_J__I_NoInit(0), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000212__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1674 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = t.F_b__1938000205; var tmp2 any = A_arbace_go_run_A_const_68; var tmp3 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(k__3))).Ref(); var tmp4 any = A_arbace_go_run_A_const_168; var arg_1678 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil, Lit_69, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__5, nil, n__6)).Ref())); if linked_1675 == nil { ifn_1676.Invoke_O_O__O(arg_1677, arg_1678) } else { linked_1675.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1674, arg_1677, arg_1678) }; i__1938000204__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000204__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_run_full_forms_QMARK__A_New() *A_arbace_go_run_full_forms_QMARK__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_full_forms_QMARK__A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_run_full_forms_QMARK__A) Ctor() {}
//line :252:1
func (t *A_arbace_go_run_full_forms_QMARK__A) Invoke_O_O_O__O(self, root__0, pf__1 any) any {


	var tmp1 any; var root_1729 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = A_arbace_go_run_A_const_169; var arg_1733 any = lang.IFn_Cast(A_arbace_go_run_A_const_170.GetRawRoot__O()).Invoke_O__O(pf__1); if linked_1730 == nil { tmp1 = ifn_1731.Invoke_O_O__O(arg_1732, arg_1733) } else { tmp1 = linked_1730.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1729, arg_1732, arg_1733) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_go_run_full_lines_A_New() *A_arbace_go_run_full_lines_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_full_lines_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_go_run_full_lines_A) Ctor() {}
//line :257:1
func (t *A_arbace_go_run_full_lines_A) Invoke_O_O_O__O(self, src__0, keys__1 any) any {





	var root_1790 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_run_A_const_136, keys__1); if linked_1791 == nil { ifn_1792.Invoke_O__O(arg_1793) } else { linked_1791.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1790, arg_1793) }
//line :257:1
	var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






		{ var root_1738 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = src__0; var arg_1742 any = A_arbace_go_run_A_const_53; var arg_1743 any; var fnbody__1786 any = A_arbace_go_run_full_lines_fn__1938000227_A_New_O(keys__1); var tmp2 *jrt.Class; var fncls__1785 *jrt.Class = A_arbace_go_run_full_lines_fn__1938000227_A_fn_class; if fncls__1785 == nil { var fncls__1785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1786); A_arbace_go_run_full_lines_fn__1938000227_A_fn_class = fncls__1785d; tmp2 = fncls__1785d } else { tmp2 = fncls__1785 }; arg_1743 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1786, tmp2, nil); if linked_1739 == nil { tmp1 = ifn_1740.Invoke_O_O_O__O(arg_1741, arg_1742, arg_1743) } else { tmp1 = linked_1739.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1738, arg_1741, arg_1742, arg_1743) } }
//line :257:1
		return nil }(); var root_1787 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1789 lang.IFn





	if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; if linked_1788 == nil { ifn_1789.Invoke__O() } else { linked_1788.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1787) }
//line :257:1
	if tmp3 != nil { panic(tmp3) }; return tmp1 }
//line :257:1
func (t *A_arbace_go_run_full_lines_A) Invoke_O_O__O(self, src__0 any) any {



	var root_1799 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, A_arbace_go_run_full_lines_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = src__0; var arg_1803 any = jrt.Boolean_FALSE.Ref(); if linked_1800 == nil { return ifn_1801.Invoke_O_O__O(arg_1802, arg_1803) } else { return linked_1800.(*A_arbace_go_run_full_lines_A).Invoke_O_O_O__O(root_1799, arg_1802, arg_1803)
	}
}
func A_arbace_go_run_full_lines_fn__1938000227_A_New_O(p0 any) *A_arbace_go_run_full_lines_fn__1938000227_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_full_lines_fn__1938000227_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_go_run_full_lines_fn__1938000227_A) Ctor_O(c__keys any) { t.F_keys = c__keys }
//line :264:1
func (t *A_arbace_go_run_full_lines_fn__1938000227_A) Invoke_O_O__O(self, fs__1 any) any { var root_1744 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any; var fnbody__1784 any = A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A_New_O(t.F_keys); var tmp1 *jrt.Class; var fncls__1783 *jrt.Class = A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A_fn_class; if fncls__1783 == nil { var fncls__1783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1784); A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A_fn_class = fncls__1783d; tmp1 = fncls__1783d } else { tmp1 = fncls__1783 }; arg_1747 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1784, tmp1, nil); var arg_1748 any = fs__1; if linked_1745 == nil { return ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { return linked_1745.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) } }
//line :264:1
func A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A_New_O(p0 any) *A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A) Ctor_O(c__keys any) { t.F_keys = c__keys }
//line :264:1
func (t *A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A) Invoke_O_O__O(self, p1__1938000226_SHARP___1 any) any { if jrt.J2g_Truth(t.F_keys) {
																var root_1749 any = A_arbace_go_run_A_const_171.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, A_arbace_go_run_key_lines_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = p1__1938000226_SHARP___1; if linked_1750 == nil { return ifn_1751.Invoke_O__O(arg_1752) } else { return linked_1750.(*A_arbace_go_run_key_lines_A).Invoke_O_O__O(root_1749, arg_1752) } } else {
//line :264:1
		var G__1938000229__2_ any; var root_1753 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1755 lang.IFn

		if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = p1__1938000226_SHARP___1; var arg_1757 any = A_arbace_go_run_A_const_54; var arg_1758 any; var fnbody__1765 any = A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A_New(); var tmp1 *jrt.Class; var fncls__1764 *jrt.Class = A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A_fn_class; if fncls__1764 == nil { var fncls__1764d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A_fn_class = fncls__1764d; tmp1 = fncls__1764d } else { tmp1 = fncls__1764 }; arg_1758 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1765, tmp1, nil); if linked_1754 == nil { G__1938000229__2_ = ifn_1755.Invoke_O_O_O__O(arg_1756, arg_1757, arg_1758) } else { G__1938000229__2_ = linked_1754.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1753, arg_1756, arg_1757, arg_1758) }
//line :264:1
		var G__1938000229__3_ any

		if jrt.J2g_Truth(A_arbace_go_run_A_const_67.Invoke_O__O(p1__1938000226_SHARP___1)) {
			var root_1766 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = G__1938000229__2_; var arg_1770 any = A_arbace_go_run_A_const_67; var arg_1771 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); if linked_1767 == nil { G__1938000229__3_ = ifn_1768.Invoke_O_O_O__O(arg_1769, arg_1770, arg_1771) } else { G__1938000229__3_ = linked_1767.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1766, arg_1769, arg_1770, arg_1771) } } else {
//line :266:1
				G__1938000229__3_ = G__1938000229__2_ }; var tmp2 any; var root_1772 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1774 lang.IFn

		if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any = p1__1938000226_SHARP___1; var arg_1776 any = A_arbace_go_run_A_const_172; if linked_1773 == nil { tmp2 = ifn_1774.Invoke_O_O__O(arg_1775, arg_1776) } else { tmp2 = linked_1773.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1772, arg_1775, arg_1776) }
//line :266:1
		if jrt.J2g_Truth(tmp2) {

			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_162.GetRawRoot__O()); var tmp4 any = A_arbace_go_run_A_const_173; return tmp3.Invoke_O_O_O__O(G__1938000229__3_, tmp4, A_arbace_go_run_A_const_122.GetRawRoot__O()) } else {
//line :266:1
				return G__1938000229__3_ } } }
//line :266:1
func A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A_New() *A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A) Ctor() {}
//line :266:1
func (t *A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A) Invoke_O_O__O(self, ds__1 any) any { var root_1759 any = A_arbace_go_run_A_const_128.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = A_arbace_go_run_A_const_122.GetRawRoot__O(); var arg_1763 any = ds__1; if linked_1760 == nil { return ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { return linked_1760.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) } }




func A_arbace_go_run_line_map_A_New() *A_arbace_go_run_line_map_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_go_run_line_map_A) Ctor() {}
//line :271:1
func (t *A_arbace_go_run_line_map_A) Invoke_O_O__O(self, path__0 any) any { var text__2 any = lang.IFn_Cast(A_arbace_go_run_A_const_170.GetRawRoot__O()).Invoke_O__O(path__0); var tmp1 any; var or__1927000174__auto____3 any; var root_1808 any = A_arbace_go_run_A_const_174.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1810 lang.IFn; if









	linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = text__2; var arg_1812 any = Lit_45; if linked_1809 == nil { or__1927000174__auto____3 = ifn_1810.Invoke_O_O__O(arg_1811, arg_1812) } else { or__1927000174__auto____3 = linked_1809.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1808, arg_1811, arg_1812) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_1813 any = A_arbace_go_run_A_const_174.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = text__2; var arg_1817 any = Lit_46; if linked_1814 == nil { tmp1 = ifn_1815.Invoke_O_O__O(arg_1816, arg_1817) } else { tmp1 = linked_1814.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1813, arg_1816, arg_1817) } }; if jrt.J2g_Truth(tmp1) { var ls__3 any; var root_1818 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1820 lang.IFn
		if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any; var root_1822 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = text__2; if linked_1823 == nil { arg_1821 = ifn_1824.Invoke_O__O(arg_1825) } else { arg_1821 = linked_1823.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_1822, arg_1825) }; if linked_1819 == nil { ls__3 = ifn_1820.Invoke_O__O(arg_1821) } else { ls__3 = linked_1819.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1818, arg_1821) }
//line :281:1
		var ds__4 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__1967 any = A_arbace_go_run_line_map_fn__1938000235_A_New_O(ls__3); var tmp3 *jrt.Class
		var fncls__1966 /*line :281:1*/*jrt.Class = A_arbace_go_run_line_map_fn__1938000235_A_fn_class


		if fncls__1966 == nil { var fncls__1966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__1967); A_arbace_go_run_line_map_fn__1938000235_A_fn_class = fncls__1966d; tmp3 = fncls__1966d } else { tmp3 = fncls__1966 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1967, tmp3, nil); ds__4 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()





















		var tmp4 any; var root_1968 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = ds__4; if linked_1969 == nil { tmp4 = ifn_1970.Invoke_O__O(arg_1971) } else { tmp4 = linked_1969.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1968, arg_1971) }; if jrt.J2g_Truth(tmp4) {
			var fnbody__1984 any = A_arbace_go_run_line_map_fn__1938000271_A_New_O(ds__4); var tmp5 *jrt.Class; var fncls__1983 *jrt.Class = A_arbace_go_run_line_map_fn__1938000271_A_fn_class; if fncls__1983 == nil { var fncls__1983d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__1984); A_arbace_go_run_line_map_fn__1938000271_A_fn_class = fncls__1983d; tmp5 = fncls__1983d } else { tmp5 = fncls__1983 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1984, tmp5, nil) } else {
//line :306:1
				return nil } } else {
//line :281:1
					return nil } }


func A_arbace_go_run_line_map_fn__1938000235_A_New_O(p0 any) *A_arbace_go_run_line_map_fn__1938000235_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000235_A{}; t.Ctor_O(p0); return t }
//line :284:1
func (t *A_arbace_go_run_line_map_fn__1938000235_A) Ctor_O(c__ls any) { t.F_ls = c__ls }
//line :284:1
func (t *A_arbace_go_run_line_map_fn__1938000235_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var prev__2 any; var acc__3 any = lang.PersistentVector_EMPTY.Ref(); L1: for {
										if lang.Util_Equiv_J_J__Z_NoInit(i__1, int64(lang.RT_Count_O__I_NoInit(t.F_ls))) { return acc__3 } else { var tmp1 any = t.F_ls; var l__4 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_J__I_NoInit(i__1)); var parse__5 any; var fnbody__1837 any = A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A_New_O(prev__2); var tmp2 *jrt.Class
											var fncls__1836 /*line :285:1*/*jrt.Class = A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A_fn_class


		if fncls__1836 == nil { var fncls__1836d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, fnbody__1837); A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A_fn_class = fncls__1836d; tmp2 = fncls__1836d } else { tmp2 = fncls__1836 }; parse__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1837, tmp2, nil)
//line :285:1
		var found__6 any; var root_1838 any = A_arbace_go_run_A_const_75.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1840 lang.IFn








		if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any; var tmp3 any; var root_1843 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_1844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1843, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1845 lang.IFn
		if linked_1844 == nil { ifn_1845 = lang.IFn_Cast(root_1843) } else { ifn_1845 = nil }; var arg_1846 any = l__4; var arg_1847 any = Lit_45; if linked_1844 == nil { tmp3 = ifn_1845.Invoke_O_O__O(arg_1846, arg_1847) } else { tmp3 = linked_1844.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1843, arg_1846, arg_1847) }; if jrt.J2g_Truth(tmp3) { var temp__1927000414__auto____6 any; var tmp4 lang.IFn = lang.IFn_Cast(parse__5); var tmp5 any; var root_1848 any = A_arbace_go_run_A_const_156.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1850 lang.IFn
			if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = l__4; var arg_1852 any = A_arbace_go_run_A_const_157; if linked_1849 == nil { tmp5 = ifn_1850.Invoke_O_O__O(arg_1851, arg_1852) } else { tmp5 = linked_1849.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1848, arg_1851, arg_1852) }; temp__1927000414__auto____6 = tmp4.Invoke_O__O(tmp5); if jrt.J2g_Truth(temp__1927000414__auto____6) { var d__7 any = temp__1927000414__auto____6; arg_1841 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(i__1, 2)).Ref(), A_arbace_go_run_A_const_158, d__7)) } else { arg_1841 = nil } } else {
//line :295:1
				arg_1841 = nil }
//line :294:1
		var arg_1842 any; var tmp6 any; var root_1853 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1855 lang.IFn


		if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = l__4; var arg_1857 any = Lit_100; if linked_1854 == nil { tmp6 = ifn_1855.Invoke_O_O__O(arg_1856, arg_1857) } else { tmp6 = linked_1854.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1853, arg_1856, arg_1857) }; if jrt.J2g_Truth(tmp6) { arg_1842 = nil } else { var iter__1927001039__auto____6 any; var fnbody__1947 any = A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A_New_J_O_O(i__1, l__4, parse__5); var tmp7 *jrt.Class; var fncls__1946 *jrt.Class = A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A_fn_class
			if fncls__1946 == nil { var fncls__1946d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__1947); A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A_fn_class = fncls__1946d; tmp7 = fncls__1946d } else { tmp7 = fncls__1946 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1947, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp9 any; var root_1948 any = A_arbace_go_run_A_const_177.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = A_arbace_go_run_A_const_178; var arg_1952 any = l__4; if linked_1949 == nil { tmp9 = ifn_1950.Invoke_O_O__O(arg_1951, arg_1952) } else { tmp9 = linked_1949.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_1948, arg_1951, arg_1952) }; arg_1842 = tmp8.Invoke_O__O(tmp9) }
//line :294:1
		if linked_1839 == nil { found__6 = ifn_1840.Invoke_O_O__O(arg_1841, arg_1842) } else { found__6 = linked_1839.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1838, arg_1841, arg_1842) }
//line :285:1
		var vec__1938000236__7 any; var root_1953 any = A_arbace_go_run_A_const_133.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1955 lang.IFn
















		if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any; var fnbody__1965 any = A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A_New(); var tmp10 *jrt.Class; var fncls__1964 *jrt.Class = A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A_fn_class; if fncls__1964 == nil { var fncls__1964d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A_fn_class = fncls__1964d; tmp10 = fncls__1964d } else { tmp10 = fncls__1964 }; arg_1956 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1965, tmp10, nil); var arg_1957 any = lang.Tuple_Create_O_O__IPersistentVector(acc__3, prev__2); var arg_1958 any = found__6; if linked_1954 == nil { vec__1938000236__7 = ifn_1955.Invoke_O_O_O__O(arg_1956, arg_1957, arg_1958) } else { vec__1938000236__7 = linked_1954.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1953, arg_1956, arg_1957, arg_1958) }
//line :285:1
		var acc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000236__7, lang.RT_IntCast_J__I_NoInit(0), nil); var prev__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000236__7, lang.RT_IntCast_J__I_NoInit(1), nil)



















		i__1, prev__2, acc__3 = lang.Numbers_Inc_J__J_NoInit(i__1), prev__9, acc__8; continue L1 } } }; /*line :284:1*/panic("j2g: unreachable") }



func A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A_New_O(p0 any) *A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A{}; t.Ctor_O(p0); return t }
//line :288:1
func (t *A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A) Ctor_O(c__prev any) { t.F_prev = c__prev }
//line :288:1
func (t *A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A) Invoke_O_O__O(self, text__1 any) any { var or__1927000174__auto____2 any; var temp__1927000414__auto____2 any; var root_1826 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1828 lang.IFn; if
														linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = A_arbace_go_run_A_const_175; var arg_1830 any = text__1; if linked_1827 == nil { temp__1927000414__auto____2 = ifn_1828.Invoke_O_O__O(arg_1829, arg_1830) } else { temp__1927000414__auto____2 = linked_1827.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1826, arg_1829, arg_1830) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1938000240__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000240__3, lang.RT_IntCast_J__I_NoInit(0), nil); var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000240__3, lang.RT_IntCast_J__I_NoInit(1), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000240__3, lang.RT_IntCast_J__I_NoInit(2), nil); var _c__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000240__3, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 any; _ = ___4; _ = _c__7
															if lang.Util_Equiv_O_O__Z_NoInit(Lit_41, f__5) { tmp1 = t.F_prev } else { tmp1 = f__5 }
//line :289:1
		or__1927000174__auto____2 = lang.Tuple_Create_O_O__IPersistentVector(tmp1, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__6))).Ref()) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var temp__1927000414__auto____3 any; var root_1831 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_1832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1831, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1833 lang.IFn

			if linked_1832 == nil { ifn_1833 = lang.IFn_Cast(root_1831) } else { ifn_1833 = nil }; var arg_1834 any = A_arbace_go_run_A_const_176; var arg_1835 any = text__1; if linked_1832 == nil { temp__1927000414__auto____3 = ifn_1833.Invoke_O_O__O(arg_1834, arg_1835) } else { temp__1927000414__auto____3 = linked_1832.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1831, arg_1834, arg_1835) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var vec__1938000243__4 any = temp__1927000414__auto____3; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000243__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000243__4, lang.RT_IntCast_J__I_NoInit(1), nil); var n__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000243__4, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___5; return lang.Tuple_Create_O_O__IPersistentVector(f__6, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__7))).Ref()) } else { return nil } } }






func A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A_New_J_O_O(p0 int64, p1, p2 any) *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A{}; t.Ctor_J_O_O(p0, p1, p2); return t }
//line :298:1
func (t *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A) Ctor_J_O_O(c__i int64, c__l, c__parse any) { t.F_i = c__i; t.F_l = c__l; t.F_parse = c__parse }
//line :298:1
func (t *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A) Invoke_O_O__O(self, s__1938000248__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1945 any = A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A_New_O_J_O_O_O(s__1938000248__1, t.F_i, t.F_l, self, t.F_parse); var tmp2 *jrt.Class; var fncls__1944 *jrt.Class = A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A_fn_class; if fncls__1944 == nil { var fncls__1944d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, fnbody__1945); A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A_fn_class = fncls__1944d; tmp2 = fncls__1944d } else { tmp2 = fncls__1944 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1945, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :298:1
func A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A_New_O_J_O_O_O(p0 any, p1 int64, p2, p3, p4 any) *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A{}; t.Ctor_O_J_O_O_O(p0, p1, p2, p3, p4); return t }
//line :298:1
func (t *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A) Ctor_O_J_O_O_O(c__s__1938000248 any, c__i int64, c__l, c__iter__1938000247, c__parse any) { t.F_s__1938000248 = c__s__1938000248; t.F_i = c__i; t.F_l = c__l; t.F_iter__1938000247 = c__iter__1938000247; t.F_parse = c__parse }
//line :298:1
func (t *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A) Invoke_O__O(self any) any { { var s__1938000248__1 any; var t_ any = t.F_s__1938000248; t.F_s__1938000248 = nil; s__1938000248__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1858 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1858, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1860 lang.IFn; if linked_1859 == nil { ifn_1860 = lang.IFn_Cast(root_1858) } else { ifn_1860 = nil }; var arg_1861 any = s__1938000248__1; if linked_1859 == nil { temp__1927000414__auto____2 = ifn_1860.Invoke_O__O(arg_1861) } else { temp__1927000414__auto____2 = linked_1859.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1858, arg_1861) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000248__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1862 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = s__1938000248__3; if linked_1863 == nil { tmp1 = ifn_1864.Invoke_O__O(arg_1865) } else { tmp1 = linked_1863.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1862, arg_1865) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1866 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1868 lang.IFn; if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = s__1938000248__3; if linked_1867 == nil { c__1927001037__auto____4 = ifn_1868.Invoke_O__O(arg_1869) } else { c__1927001037__auto____4 = linked_1867.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1866, arg_1869) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000250__6 any; var root_1870 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1871 == nil { b__1938000250__6 = ifn_1872.Invoke_O__O(arg_1873) } else { b__1938000250__6 = linked_1871.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1870, arg_1873) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1892 any = A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A_New_O_J_O_O_I_O(b__1938000250__6, t.F_i, t.F_l, t.F_parse, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1891 *jrt.Class = A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A_fn_class; if fncls__1891 == nil { var fncls__1891d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__1892); A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A_fn_class = fncls__1891d; tmp3 = fncls__1891d } else { tmp3 = fncls__1891 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1892, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1893 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any; var root_1898 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = b__1938000250__6; if linked_1899 == nil { arg_1896 = ifn_1900.Invoke_O__O(arg_1901) } else { arg_1896 = linked_1899.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1898, arg_1901) }; var arg_1897 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000247); var tmp5 any; var root_1902 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = s__1938000248__3; if linked_1903 == nil { tmp5 = ifn_1904.Invoke_O__O(arg_1905) } else { tmp5 = linked_1903.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1902, arg_1905) }; arg_1897 = tmp4.Invoke_O__O(tmp5); if linked_1894 == nil { return ifn_1895.Invoke_O_O__O(arg_1896, arg_1897) } else { return linked_1894.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1893, arg_1896, arg_1897) } } else { var root_1906 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any; var root_1911 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = b__1938000250__6; if linked_1912 == nil { arg_1909 = ifn_1913.Invoke_O__O(arg_1914) } else { arg_1909 = linked_1912.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1911, arg_1914) }; var arg_1910 any; if linked_1907 == nil { return ifn_1908.Invoke_O_O__O(arg_1909, arg_1910) } else { return linked_1907.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1906, arg_1909, arg_1910) } } } else { var m__4 any; var root_1915 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = s__1938000248__3; if linked_1916 == nil { m__4 = ifn_1917.Invoke_O__O(arg_1918) } else { m__4 = linked_1916.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1915, arg_1918) }; var d__5 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_parse); var tmp7 any; var root_1936 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1938 lang.IFn
																if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = m__4; if linked_1937 == nil { tmp7 = ifn_1938.Invoke_O__O(arg_1939) } else { tmp7 = linked_1937.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1936, arg_1939) }; d__5 = tmp6.Invoke_O__O(tmp7)
//line :298:1
	if jrt.J2g_Truth(d__5) { var root_1919 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any; var tmp8 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(t.F_i)).Ref(); var tmp9 *jrt.String = jrt.String_Cast(t.F_l); var tmp10 any; var root_1924 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1926 lang.IFn


		if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = m__4; if linked_1925 == nil { tmp10 = ifn_1926.Invoke_O__O(arg_1927) } else { tmp10 = linked_1925.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1924, arg_1927) }
//line :298:1
		var tmp11 int64 = lang.Numbers_Add_J_J__J_NoInit(1, int64(jrt.NN(tmp9).IndexOf_String__I(jrt.String_Cast(tmp10)))); var tmp12 any; var root_1928 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1930 lang.IFn


		if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = m__4; if linked_1929 == nil { tmp12 = ifn_1930.Invoke_O__O(arg_1931) } else { tmp12 = linked_1929.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1928, arg_1931) }
//line :298:1
		arg_1922 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(tmp11, int64(lang.RT_Count_O__I_NoInit(tmp12)))).Ref(), d__5); var arg_1923 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__1938000247); var tmp14 any; var root_1932 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = s__1938000248__3; if linked_1933 == nil { tmp14 = ifn_1934.Invoke_O__O(arg_1935) } else { tmp14 = linked_1933.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1932, arg_1935) }; arg_1923 = tmp13.Invoke_O__O(tmp14); if linked_1920 == nil { return ifn_1921.Invoke_O_O__O(arg_1922, arg_1923) } else { return linked_1920.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1919, arg_1922, arg_1923) } } else { var tmp15 any; var root_1940 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = s__1938000248__3; if linked_1941 == nil { tmp15 = ifn_1942.Invoke_O__O(arg_1943) } else { tmp15 = linked_1941.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1940, arg_1943) }; s__1938000248__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :298:1
func A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A_New_O_J_O_O_I_O(p0 any, p1 int64, p2, p3 any, p4 int32, p5 any) *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A{}; t.Ctor_O_J_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :298:1
func (t *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A) Ctor_O_J_O_O_I_O(c__b__1938000250 any, c__i int64, c__l, c__parse any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000250 = c__b__1938000250; t.F_i = c__i; t.F_l = c__l; t.F_parse = c__parse; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :298:1
func (t *A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A) Invoke_O__O(self any) any { { var i__1938000249__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000249__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000249__1)); var d__3 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_parse); var tmp3 any; var root_1874 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1876 lang.IFn
																		if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = m__2; if linked_1875 == nil { tmp3 = ifn_1876.Invoke_O__O(arg_1877) } else { tmp3 = linked_1875.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1874, arg_1877) }; d__3 = tmp2.Invoke_O__O(tmp3)
//line :298:1
	if jrt.J2g_Truth(d__3) { var root_1878 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1880 lang.IFn; if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any = t.F_b__1938000250; var arg_1882 any; var tmp4 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(t.F_i)).Ref(); var tmp5 *jrt.String = jrt.String_Cast(t.F_l); var tmp6 any; var root_1883 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1885 lang.IFn


		if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = m__2; if linked_1884 == nil { tmp6 = ifn_1885.Invoke_O__O(arg_1886) } else { tmp6 = linked_1884.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1883, arg_1886) }
//line :298:1
		var tmp7 int64 = lang.Numbers_Add_J_J__J_NoInit(1, int64(jrt.NN(tmp5).IndexOf_String__I(jrt.String_Cast(tmp6)))); var tmp8 any; var root_1887 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1889 lang.IFn


		if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = m__2; if linked_1888 == nil { tmp8 = ifn_1889.Invoke_O__O(arg_1890) } else { tmp8 = linked_1888.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1887, arg_1890) }
//line :298:1
		arg_1882 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(tmp7, int64(lang.RT_Count_O__I_NoInit(tmp8)))).Ref(), d__3); if linked_1879 == nil { ifn_1880.Invoke_O_O__O(arg_1881, arg_1882) } else { linked_1879.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1878, arg_1881, arg_1882) }; i__1938000249__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000249__1); continue L1 } else { i__1938000249__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000249__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A_New() *A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A) Ctor() {}
//line :302:1
func (t *A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A) Invoke_O_O_O__O(self, p__1938000257__1, p__1938000258__2 any) any { var vec__1938000260__3 any = p__1938000257__1; var acc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000260__3, lang.RT_IntCast_J__I_NoInit(0), nil); var prev__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000260__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1938000263__6 any = p__1938000258__2; var el__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000263__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ec__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000263__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1938000266__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000263__6, lang.RT_IntCast_J__I_NoInit(2), nil); var f__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000266__9, lang.RT_IntCast_J__I_NoInit(0), nil); var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000266__9, lang.RT_IntCast_J__I_NoInit(1), nil); if
																	lang.Numbers_IsPos_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(n__11)) { var tmp1 any; var root_1959 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = acc__4; var arg_1963 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(el__7, ec__8, f__10, n__11); if linked_1960 == nil { tmp1 = ifn_1961.Invoke_O_O__O(arg_1962, arg_1963) } else { tmp1 = linked_1960.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1959, arg_1962, arg_1963) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, f__10) } else { return lang.Tuple_Create_O_O__IPersistentVector(acc__4, prev__5) } }



func A_arbace_go_run_line_map_fn__1938000271_A_New_O(p0 any) *A_arbace_go_run_line_map_fn__1938000271_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000271_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_go_run_line_map_fn__1938000271_A) Ctor_O(c__ds any) { t.F_ds = c__ds }
//line :307:1
func (t *A_arbace_go_run_line_map_fn__1938000271_A) InvokePrim_O_O_J_O__O(self, file__1 any, line__2 int64, col__3 any) any { var c__4 int64; var tmp1 any; var or__1927000174__auto____4 any = col__3; if
																jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = A_arbace_go_run_A_const_179 }; c__4 = lang.RT_LongCast_O__J_NoInit(tmp1); var temp__1927000408__auto____5 any; var root_1972 any = /*line :307:1*/A_arbace_go_run_A_const_164.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_1974 lang.IFn; if

	linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any; var root_1976 any = A_arbace_go_run_A_const_105.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any; var fnbody__1982 any = A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A_New_J_J(line__2, c__4); var tmp2 *jrt.Class; var fncls__1981 *jrt.Class = A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A_fn_class; if fncls__1981 == nil { var fncls__1981d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, fnbody__1982); A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A_fn_class = fncls__1981d; tmp2 = fncls__1981d } else { tmp2 = fncls__1981 }; arg_1979 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1982, tmp2, nil); var arg_1980 any = t.F_ds; if linked_1977 == nil { arg_1975 = ifn_1978.Invoke_O_O__O(arg_1979, arg_1980) } else { arg_1975 = linked_1977.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1976, arg_1979, arg_1980) }; if linked_1973 == nil { temp__1927000408__auto____5 = ifn_1974.Invoke_O__O(arg_1975) } else { temp__1927000408__auto____5 = linked_1973.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_1972, arg_1975) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var vec__1938000278__6 any = temp__1927000408__auto____5; var el__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000278__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000278__6, lang.RT_IntCast_J__I_NoInit(1), nil); var f__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000278__6, lang.RT_IntCast_J__I_NoInit(2), nil); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000278__6, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp3 any; var or__1927000174__auto____11 any = f__9; _ = ___8
		if jrt.J2g_Truth(or__1927000174__auto____11) { tmp3 = or__1927000174__auto____11 } else { tmp3 = file__1 }
//line :309:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp3, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(n__10), lang.Numbers_Minus_J_J__J_NoInit(line__2, lang.RT_LongCast_O__J_NoInit(el__7)))).Ref()) } else { return lang.Tuple_Create_O_O__IPersistentVector(file__1, jrt.Long_ValueOf_J__Long_NoInit(line__2).Ref()) } }
//line :307:1
func (t *A_arbace_go_run_line_map_fn__1938000271_A) Invoke_O_O_O_O__O(self, file__1, p_line__2, col__3 any) any { return t.InvokePrim_O_O_J_O__O(self, file__1, lang.RT_LongCast_O__J_NoInit(p_line__2), col__3) }

func A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A_New_J_J(p0, p1 int64) *A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A{}; t.Ctor_J_J(p0, p1); return t }
//line :309:1
func (t *A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A) Ctor_J_J(c__line, c__c int64) { t.F_line = c__line; t.F_c = c__c }
//line :309:1
func (t *A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A) Invoke_O_O__O(self, p__1938000272__1 any) any { var vec__1938000274__2 any = p__1938000272__1; var el__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000274__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ec__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000274__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 int64 = t.F_line; var or__1927000174__auto____5 bool = lang.Numbers_Gt_J_J__Z_NoInit(tmp1, lang.RT_LongCast_O__J_NoInit(el__3)); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var tmp2 int64 = t.F_line; var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(tmp2, lang.RT_LongCast_O__J_NoInit(el__3)); if and__1927000168__auto____6 { var tmp3 int64 = t.F_c; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gte_J_J__Z_NoInit(tmp3, lang.RT_LongCast_O__J_NoInit(ec__4))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } }



func A_arbace_go_run_errorcheck_A_New() *A_arbace_go_run_errorcheck_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_go_run_errorcheck_A) Ctor() {}
//line :313:1
func (t *A_arbace_go_run_errorcheck_A) DoInvoke_O_O_O_O_O_O_O_O__O(self, root__0, pf__1, lang__2, max_errors__3, raw__4, front__5, p__1938000287__6 any) any { var vec__1938000288__8 any = p__1938000287__6; var gcflags__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000288__8, lang.RT_IntCast_J__I_NoInit(0), nil); var src__10 any; var G__1938000291__10_ any; var root_1985 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_1987 lang.IFn; if
















	linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_77, root__0)); var arg_1989 any; var arg_1990 any; var root_1992 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1994 lang.IFn; if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_1993 == nil { arg_1990 = ifn_1994.Invoke_O__O(arg_1995) } else { arg_1990 = linked_1993.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1992, arg_1995) }; var arg_1991 any = pf__1; if linked_1986 == nil { G__1938000291__10_ = ifn_1987.Invoke_O_O_O_O__O(arg_1988, arg_1989, arg_1990, arg_1991) } else { G__1938000291__10_ = linked_1986.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_1985, arg_1988, arg_1989, arg_1990, arg_1991) }; var G__1938000291__11_ any; if jrt.J2g_Truth(lang__2) {
		var root_1996 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = G__1938000291__10_; var arg_2000 any = A_arbace_go_run_A_const_181; var arg_2001 any = lang__2; if linked_1997 == nil { G__1938000291__11_ = ifn_1998.Invoke_O_O_O__O(arg_1999, arg_2000, arg_2001) } else { G__1938000291__11_ = linked_1997.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1996, arg_1999, arg_2000, arg_2001) } } else {
//line :330:1
			G__1938000291__11_ = G__1938000291__10_ }; var G__1938000291__12_ any; var tmp1 any; var or__1927000174__auto____12 any = raw__4; if

	jrt.J2g_Truth(or__1927000174__auto____12) { tmp1 = or__1927000174__auto____12 } else { var root_2002 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, A_arbace_go_run_full_forms_QMARK__A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = root__0; var arg_2006 any = pf__1; if linked_2003 == nil { tmp1 = ifn_2004.Invoke_O_O__O(arg_2005, arg_2006) } else { tmp1 = linked_2003.(*A_arbace_go_run_full_forms_QMARK__A).Invoke_O_O_O__O(root_2002, arg_2005, arg_2006) } }; if /*line :330:1*/ jrt.J2g_Truth(tmp1) { var root_2007 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, A_arbace_go_run_full_lines_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = G__1938000291__11_; if linked_2008 == nil { G__1938000291__12_ = ifn_2009.Invoke_O__O(arg_2010) } else { G__1938000291__12_ = linked_2008.(*A_arbace_go_run_full_lines_A).Invoke_O_O__O(root_2007, arg_2010) } } else { G__1938000291__12_ = G__1938000291__11_ }; if jrt.J2g_Truth(raw__4) {


		var root_2011 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = G__1938000291__12_; var arg_2015 any = A_arbace_go_run_A_const_182; var arg_2016 any = jrt.HashMap_New(); if linked_2012 == nil { src__10 = ifn_2013.Invoke_O_O_O__O(arg_2014, arg_2015, arg_2016) } else { src__10 = linked_2012.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2011, arg_2014, arg_2015, arg_2016) } } else {
//line :330:1
			src__10 = G__1938000291__12_ }; var ___11 any; var tmp2 any; var root_2017 any = /*line :313:1*/A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2019 lang.IFn; _ = ___11; if




















	linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = A_arbace_go_run_A_const_53.Invoke_O__O(src__10); if linked_2018 == nil { tmp2 = ifn_2019.Invoke_O__O(arg_2020) } else { tmp2 = linked_2018.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2017, arg_2020) }; if jrt.J2g_Truth(tmp2) { var root_2021 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, A_arbace_go_run_fail_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = A_arbace_go_run_A_const_51; var arg_2025 any = Lit_33; var arg_2026 any = Lit_48; if linked_2022 == nil { ___11 = ifn_2023.Invoke_O_O_O__O(arg_2024, arg_2025, arg_2026) } else { ___11 = linked_2022.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2021, arg_2024, arg_2025, arg_2026) } } else { ___11 = nil }; var ___12 any; var root_2027 any = /*line :313:1*/A_arbace_go_run_A_const_61.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_2029 lang.IFn; _ = ___12; if





















	linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = src__10; if linked_2028 == nil { ___12 = ifn_2029.Invoke_O__O(arg_2030) } else { ___12 = linked_2028.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_2027, arg_2030) }; var sizes__13 any; if

	jrt.J2g_Truth(front__5) { var root_2031 any = A_arbace_go_run_A_const_83.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = lang.PersistentVector_EMPTY.Ref(); if linked_2032 == nil { sizes__13 = ifn_2033.Invoke_O__O(arg_2034) } else { sizes__13 = linked_2032.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2031, arg_2034) } } else { sizes__13 = nil }; var r__14 any; var root_2412 any = /*line :313:1*/A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2414 lang.IFn; if
























	linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_run_A_const_217, sizes__13); if linked_2413 == nil { ifn_2414.Invoke_O__O(arg_2415) } else { linked_2413.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2412, arg_2415) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__2047 any = A_arbace_go_run_errorcheck_fn__1938000292_A_New_O(src__10); var tmp4 *jrt.Class; var fncls__2046 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000292_A_fn_class; if fncls__2046 == nil { var fncls__2046d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__2047); A_arbace_go_run_errorcheck_fn__1938000292_A_fn_class = fncls__2046d; tmp4 = fncls__2046d } else { tmp4 = fncls__2046 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2047, tmp4, nil); r__14 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); var errs__15 any = /*line :313:1*/A_arbace_go_run_A_const_60.Invoke_O__O(r__14); var temp__1927000414__auto____16 any; var root_2421 any = A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2423 lang.IFn; if


























	linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any; var fnbody__2427 any = A_arbace_go_run_errorcheck_fn__1938000296_A_New(); var tmp5 *jrt.Class; var fncls__2426 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000296_A_fn_class; if fncls__2426 == nil { var fncls__2426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_go_run_errorcheck_fn__1938000296_A_fn_class = fncls__2426d; tmp5 = fncls__2426d } else { tmp5 = fncls__2426 }; arg_2424 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2427, tmp5, nil); var arg_2425 any = errs__15; if linked_2422 == nil { temp__1927000414__auto____16 = ifn_2423.Invoke_O_O__O(arg_2424, arg_2425) } else { temp__1927000414__auto____16 = linked_2422.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2421, arg_2424, arg_2425) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var bi__17 any = temp__1927000414__auto____16; var root_2428 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2428, A_arbace_go_run_fail_A_fn_class); var ifn_2430 lang.IFn
		if linked_2429 == nil { ifn_2430 = lang.IFn_Cast(root_2428) } else { ifn_2430 = nil }; var arg_2431 any = A_arbace_go_run_A_const_51; var arg_2432 any = Lit_33; var arg_2433 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_37, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_65.Invoke_O__O(bi__17))).Ref(); if linked_2429 == nil { ifn_2430.Invoke_O_O_O__O(arg_2431, arg_2432, arg_2433) } else { linked_2429.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2428, arg_2431, arg_2432, arg_2433) } }; var temp__1927000414__auto____16_2 any; var root_2434 any = /*line :313:1*/A_arbace_go_run_A_const_47.GetRawRoot__O(); var linked_2435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2434, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2436 lang.IFn; if




























	linked_2435 == nil { ifn_2436 = lang.IFn_Cast(root_2434) } else { ifn_2436 = nil }; var arg_2437 any; var fnbody__2440 any = A_arbace_go_run_errorcheck_fn__1938000298_A_New(); var tmp6 *jrt.Class; var fncls__2439 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000298_A_fn_class; if fncls__2439 == nil { var fncls__2439d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_go_run_errorcheck_fn__1938000298_A_fn_class = fncls__2439d; tmp6 = fncls__2439d } else { tmp6 = fncls__2439 }; arg_2437 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2440, tmp6, nil); var arg_2438 any = A_arbace_go_run_A_const_219.Invoke_O__O(r__14); if linked_2435 == nil { temp__1927000414__auto____16_2 = ifn_2436.Invoke_O_O__O(arg_2437, arg_2438) } else { temp__1927000414__auto____16_2 = linked_2435.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2434, arg_2437, arg_2438) }; if jrt.J2g_Truth(temp__1927000414__auto____16_2) { var u__17 any = temp__1927000414__auto____16_2; var root_2441 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, A_arbace_go_run_fail_A_fn_class); var ifn_2443 lang.IFn
		if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = A_arbace_go_run_A_const_51; var arg_2445 any = Lit_33; var arg_2446 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_52, nil, Lit_53, nil); var tmp8 *lang.Keyword = A_arbace_go_run_A_const_85; var tmp9 any; var root_2447 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2447, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2449 lang.IFn; if linked_2448 == nil { ifn_2449 = lang.IFn_Cast(root_2447) } else { ifn_2449 = nil }; var arg_2450 any = u__17; if linked_2448 == nil { tmp9 = ifn_2449.Invoke_O__O(arg_2450) } else { tmp9 = linked_2448.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2447, arg_2450) }; var tmp10 any = tmp8.Invoke_O__O(tmp9); var tmp11 any; var root_2451 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = u__17; if linked_2452 == nil { tmp11 = ifn_2453.Invoke_O__O(arg_2454) } else { tmp11 = linked_2452.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2451, arg_2454) }; arg_2446 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp11)).Ref(); if linked_2442 == nil { ifn_2443.Invoke_O_O_O__O(arg_2444, arg_2445, arg_2446) } else { linked_2442.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2441, arg_2444, arg_2445, arg_2446) } }; var errs__16 any; var G__1938000300__16_ any; var root_2048 any = /*line :313:1*/A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2050 lang.IFn; if

































	linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any; var fnbody__2054 any = A_arbace_go_run_errorcheck_fn__1938000301_A_New(); var tmp12 *jrt.Class; var fncls__2053 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000301_A_fn_class; if fncls__2053 == nil { var fncls__2053d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_go_run_errorcheck_fn__1938000301_A_fn_class = fncls__2053d; tmp12 = fncls__2053d } else { tmp12 = fncls__2053 }; arg_2051 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2054, tmp12, nil); var arg_2052 any = errs__15; if linked_2049 == nil { G__1938000300__16_ = ifn_2050.Invoke_O_O__O(arg_2051, arg_2052) } else { G__1938000300__16_ = linked_2049.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2048, arg_2051, arg_2052) }; if jrt.J2g_Truth(front__5) {
		var root_2055 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2057 lang.IFn; if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any; var fnbody__2061 any = A_arbace_go_run_errorcheck_fn__1938000303_A_New(); var tmp13 *jrt.Class; var fncls__2060 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000303_A_fn_class; if fncls__2060 == nil { var fncls__2060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_go_run_errorcheck_fn__1938000303_A_fn_class = fncls__2060d; tmp13 = fncls__2060d } else { tmp13 = fncls__2060 }; arg_2058 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2061, tmp13, nil); var arg_2059 any = G__1938000300__16_; if linked_2056 == nil { errs__16 = ifn_2057.Invoke_O_O__O(arg_2058, arg_2059) } else { errs__16 = linked_2056.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2055, arg_2058, arg_2059) } } else {
//line :347:1
			errs__16 = G__1938000300__16_ }; var file_lang__17 any; var root_2062 any = /*line :313:1*/A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2064 lang.IFn; if




































	linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2066 any; var iter__1927001039__auto____17 any; var fnbody__2138 any = A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A_New(); var tmp14 *jrt.Class; var fncls__2137 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A_fn_class; if fncls__2137 == nil { var fncls__2137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A_fn_class = fncls__2137d; tmp14 = fncls__2137d } else { tmp14 = fncls__2137 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2138, tmp14, nil); arg_2066 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(A_arbace_go_run_A_const_53.Invoke_O__O(src__10)); if linked_2063 == nil { file_lang__17 = ifn_2064.Invoke_O_O__O(arg_2065, arg_2066) } else { file_lang__17 = linked_2063.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2062, arg_2065, arg_2066) }; var vmsg__18 any; var fnbody__2150 any = /*line :313:1*/A_arbace_go_run_errorcheck_vmsg__1938000315_A_New_O_O_O(file_lang__17, lang__2, src__10); var tmp15 *jrt.Class; var fncls__2149 *jrt.Class = A_arbace_go_run_errorcheck_vmsg__1938000315_A_fn_class; if





































	fncls__2149 == nil { var fncls__2149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__2150); A_arbace_go_run_errorcheck_vmsg__1938000315_A_fn_class = fncls__2149d; tmp15 = fncls__2149d } else { tmp15 = fncls__2149 }; vmsg__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2150, tmp15, nil); var lmap__19 any; if








	jrt.J2g_Truth(front__5) { var root_2151 any = A_arbace_go_run_A_const_189.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, A_arbace_go_run_line_map_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any = front__5; if linked_2152 == nil { lmap__19 = ifn_2153.Invoke_O__O(arg_2154) } else { lmap__19 = linked_2152.(*A_arbace_go_run_line_map_A).Invoke_O_O__O(root_2151, arg_2154) } } else { lmap__19 = nil }; var relocate__20 any; var fnbody__2161 any = /*line :313:1*/A_arbace_go_run_errorcheck_relocate__1938000317_A_New_O(lmap__19); var tmp16 *jrt.Class; var fncls__2160 *jrt.Class = A_arbace_go_run_errorcheck_relocate__1938000317_A_fn_class; if















































	fncls__2160 == nil { var fncls__2160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__2161); A_arbace_go_run_errorcheck_relocate__1938000317_A_fn_class = fncls__2160d; tmp16 = fncls__2160d } else { tmp16 = fncls__2160 }; relocate__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2161, tmp16, nil); var lines__21 any; var iter__1927001039__auto____21 any; var fnbody__2223 any = /*line :313:1*/A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A_New_O_O(vmsg__18, lmap__19); var tmp17 *jrt.Class; var fncls__2222 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A_fn_class; if



















































	fncls__2222 == nil { var fncls__2222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__2223); A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A_fn_class = fncls__2222d; tmp17 = fncls__2222d } else { tmp17 = fncls__2222 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2223, tmp17, nil); lines__21 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(errs__16); var lines__22 any; if


	jrt.J2g_Truth(front__5) { var ___22 any = lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_192); var name__23 any = jrt.File_New_String(jrt.String_Cast(front__5)).GetName__String().Ref(); var noder__24 any; var tmp18 *lang.Keyword = A_arbace_go_run_A_const_193; var tmp19 any; var root_2228 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2230 lang.IFn; _ = ___22


		if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any = A_arbace_go_run_A_const_195; if linked_2229 == nil { tmp19 = ifn_2230.Invoke_O__O(arg_2231) } else { tmp19 = linked_2229.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2228, arg_2231) }; noder__24 = tmp18.Invoke_O__O(lang.IFn_Cast(tmp19).Invoke_O_O__O(front__5, name__23))
//line :368:1
		var pos__25 any; var fnbody__2238 any = A_arbace_go_run_errorcheck_pos__1938000341_A_New(); var tmp20 *jrt.Class
		var fncls__2237 /*line :368:1*/*jrt.Class = A_arbace_go_run_errorcheck_pos__1938000341_A_fn_class




		if fncls__2237 == nil { var fncls__2237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); A_arbace_go_run_errorcheck_pos__1938000341_A_fn_class = fncls__2237d; tmp20 = fncls__2237d } else { tmp20 = fncls__2237 }; pos__25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2238, tmp20, nil)
//line :368:1
		var merged__26 any; var root_2239 any = A_arbace_go_run_A_const_152.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2241 lang.IFn






		if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = pos__25; var arg_2243 any; var root_2244 any = A_arbace_go_run_A_const_75.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2244, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2246 lang.IFn; if linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any = lines__21; var arg_2248 any = noder__24; if linked_2245 == nil { arg_2243 = ifn_2246.Invoke_O_O__O(arg_2247, arg_2248) } else { arg_2243 = linked_2245.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2244, arg_2247, arg_2248) }; if linked_2240 == nil { merged__26 = ifn_2241.Invoke_O_O__O(arg_2242, arg_2243) } else { merged__26 = linked_2240.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2239, arg_2242, arg_2243) }
		var tmp21 any; var root_2249 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = merged__26; if linked_2250 == nil { tmp21 = ifn_2251.Invoke_O__O(arg_2252) } else { tmp21 = linked_2250.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2249, arg_2252) }; if jrt.J2g_Truth(tmp21) { lines__22 = merged__26 } else { var d__27 any; var tmp22 any; var root_2253 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2255 lang.IFn

			if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = A_arbace_go_run_A_const_197; if linked_2254 == nil { tmp22 = ifn_2255.Invoke_O__O(arg_2256) } else { tmp22 = linked_2254.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2253, arg_2256) }; d__27 = lang.IFn_Cast(tmp22).Invoke_O_O_O__O(front__5, name__23, lang__2)


			var tmp23 any; var root_2257 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = d__27; if linked_2258 == nil { tmp23 = ifn_2259.Invoke_O__O(arg_2260) } else { tmp23 = linked_2258.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2257, arg_2260) }; if jrt.J2g_Truth(tmp23) { lines__22 = d__27 } else { var root_2261 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2261, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = relocate__20; var arg_2265 any; var root_2266 any = A_arbace_go_run_A_const_198.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_go_check_code.A_arbace_go_check_code_size_errors_A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any; var root_2270 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2270, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2272 lang.IFn; if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = sizes__13; if linked_2271 == nil { arg_2269 = ifn_2272.Invoke_O__O(arg_2273) } else { arg_2269 = linked_2271.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2270, arg_2273) }; if linked_2267 == nil { arg_2265 = ifn_2268.Invoke_O__O(arg_2269) } else { arg_2265 = linked_2267.(*aot_arbace_go_check_code.A_arbace_go_check_code_size_errors_A).Invoke_O_O__O(root_2266, arg_2269) }; if linked_2262 == nil { lines__22 = ifn_2263.Invoke_O_O__O(arg_2264, arg_2265) } else { lines__22 = linked_2262.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2261, arg_2264, arg_2265) } } } } else {
//line :368:1
				lines__22 = lines__21 }; var lines__23 any; var root_2274 any = /*line :313:1*/A_arbace_go_run_A_const_199.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2274, aot_arbace_core.A_arbace_core_dedupe_A_fn_class); var ifn_2276 lang.IFn; if





































































	linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any = lines__22; if linked_2275 == nil { lines__23 = ifn_2276.Invoke_O__O(arg_2277) } else { lines__23 = linked_2275.(*aot_arbace_core.A_arbace_core_dedupe_A).Invoke_O_O__O(root_2274, arg_2277) }; var errs_QMARK___24 bool; var tmp24 any; var root_2278 any = /*line :313:1*/A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2280 lang.IFn; if








































































	linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = lines__23; if linked_2279 == nil { tmp24 = ifn_2280.Invoke_O__O(arg_2281) } else { tmp24 = linked_2279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2278, arg_2281) }; errs_QMARK___24 = lang.RT_BooleanCast_O__Z_NoInit(tmp24); var lines__25 any; var tmp25 any; var and__1927000168__auto____25 any; var root_2282 any = /*line :313:1*/A_arbace_go_run_A_const_200.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2284 lang.IFn; if









































































	linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(errs_QMARK___24).Ref(); if linked_2283 == nil { and__1927000168__auto____25 = ifn_2284.Invoke_O__O(arg_2285) } else { and__1927000168__auto____25 = linked_2283.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2282, arg_2285) }; if jrt.J2g_Truth(and__1927000168__auto____25) { var tmp26 any; var or__1927000174__auto____26 any = A_arbace_go_run_A_const_201.Invoke_O__O(gcflags__9); if jrt.J2g_Truth(or__1927000174__auto____26) { tmp26 = or__1927000174__auto____26 } else { tmp26 = A_arbace_go_run_A_const_179 }; tmp25 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(tmp26))).Ref() } else { tmp25 = and__1927000168__auto____25 }; if jrt.J2g_Truth(tmp25) { var ___25 any = lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_202); var analyze__26 any; var root_2290 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2292 lang.IFn; _ = ___25

		if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = A_arbace_go_run_A_const_203; if linked_2291 == nil { analyze__26 = ifn_2292.Invoke_O__O(arg_2293) } else { analyze__26 = linked_2291.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2290, arg_2293) }
//line :387:1
		var el__27 any; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_204.GetRawRoot__O()); var tmp28 any; var root_2299 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2301 lang.IFn


		if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = A_arbace_go_run_A_const_205; if linked_2300 == nil { tmp28 = ifn_2301.Invoke_O__O(arg_2302) } else { tmp28 = linked_2300.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2299, arg_2302) }; var tmp29 any = tmp28; var tmp30 any = A_arbace_go_run_A_const_206.Invoke_O__O(gcflags__9); var tmp31 any; var root_2303 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2305 lang.IFn
		if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = A_arbace_go_run_A_const_207; if linked_2304 == nil { tmp31 = ifn_2305.Invoke_O__O(arg_2306) } else { tmp31 = linked_2304.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2303, arg_2306) }
//line :390:1
		var tmp32 any = tmp31; var tmp33 any = A_arbace_go_run_A_const_208.Invoke_O__O(gcflags__9); var tmp34 any; var root_2307 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2309 lang.IFn

		if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any = A_arbace_go_run_A_const_209; if linked_2308 == nil { tmp34 = ifn_2309.Invoke_O__O(arg_2310) } else { tmp34 = linked_2308.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2307, arg_2310) }
//line :390:1
		var tmp35 any = tmp34; var tmp36 any; var root_2311 any = A_arbace_go_run_A_const_210.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_2313 lang.IFn

		if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = A_arbace_go_run_A_const_211; var arg_2315 any = A_arbace_go_run_A_const_212.Invoke_O__O(gcflags__9); if linked_2312 == nil { tmp36 = ifn_2313.Invoke_O_O__O(arg_2314, arg_2315) } else { tmp36 = linked_2312.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_2311, arg_2314, arg_2315) }
//line :390:1
		var tmp37 any = tmp36; var tmp38 any; var root_2316 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2318 lang.IFn


		if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = A_arbace_go_run_A_const_213; if linked_2317 == nil { tmp38 = ifn_2318.Invoke_O__O(arg_2319) } else { tmp38 = linked_2317.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2316, arg_2319) }
//line :390:1
		var tmp39 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp32, tmp33, tmp35, tmp37, tmp38, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_go_run_A_const_214.Invoke_O__O(gcflags__9))).Ref())); var tmp40 *lang.Compiler_AOTFn; var fnbody__2321 any = A_arbace_go_run_errorcheck_fn__1938000346_A_New_O_O_O(gcflags__9, r__14, analyze__26); var tmp41 *jrt.Class; var fncls__2320 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000346_A_fn_class; if fncls__2320 == nil { var fncls__2320d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__2321); A_arbace_go_run_errorcheck_fn__1938000346_A_fn_class = fncls__2320d; tmp41 = fncls__2320d } else { tmp41 = fncls__2320 }; tmp40 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2321, tmp41, nil); el__27 = tmp27.Invoke_O_O__O(tmp39, tmp40.Ref())
//line :387:1
		var iter__1927001039__auto____28 any; var fnbody__2383 any = A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A_New_O(relocate__20); var tmp42 *jrt.Class
		var fncls__2382 /*line :387:1*/*jrt.Class = A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A_fn_class







		if fncls__2382 == nil { var fncls__2382d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__2383); A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A_fn_class = fncls__2382d; tmp42 = fncls__2382d } else { tmp42 = fncls__2382 }; iter__1927001039__auto____28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2383, tmp42, nil); lines__25 = lang.IFn_Cast(iter__1927001039__auto____28).Invoke_O__O(el__27) } else {
//line :387:1
			lines__25 = lines__23 }; var lines__26 any; var tmp43 any; var and__1927000168__auto____26 any = max_errors__3; if











	jrt.J2g_Truth(and__1927000168__auto____26) { var tmp44 bool; var na_2384 int64 = int64(lang.RT_Count_O__I_NoInit(lines__25)); var na_2385 any = max_errors__3; if jrt.Long_InstanceOf(na_2385) { var n0_2386 int64 = na_2384; var n1_2387 int64 = jrt.NN(jrt.Long_Cast(na_2385)).LongValue__J(); tmp44 = n0_2386 >= n1_2387 } else { tmp44 = lang.Numbers_Gte_J_O__Z_NoInit(na_2384, na_2385) }; tmp43 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp44).Ref() } else { tmp43 = and__1927000168__auto____26 }; if jrt.J2g_Truth(tmp43) { var ls__26 any; var root_2389 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2391 lang.IFn
		if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any; var root_2393 any = A_arbace_go_run_A_const_134.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = max_errors__3; var arg_2397 any = lines__25; if linked_2394 == nil { arg_2392 = ifn_2395.Invoke_O_O__O(arg_2396, arg_2397) } else { arg_2392 = linked_2394.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_2393, arg_2396, arg_2397) }; if linked_2390 == nil { ls__26 = ifn_2391.Invoke_O__O(arg_2392) } else { ls__26 = linked_2390.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2389, arg_2392) }
//line :399:1
		var pos__27 any; var root_2398 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2398, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2400 lang.IFn

		if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = A_arbace_go_run_A_const_215; var arg_2402 any; var root_2403 any = A_arbace_go_run_A_const_216.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = ls__26; if linked_2404 == nil { arg_2402 = ifn_2405.Invoke_O__O(arg_2406) } else { arg_2402 = linked_2404.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_2403, arg_2406) }; if linked_2399 == nil { pos__27 = ifn_2400.Invoke_O_O__O(arg_2401, arg_2402) } else { pos__27 = linked_2399.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2398, arg_2401, arg_2402) }
		var root_2407 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = ls__26; var arg_2411 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_63), jrt.RefArrayOf(jrt.Object_class, pos__27, nil)).Ref(); if linked_2408 == nil { lines__26 = ifn_2409.Invoke_O_O__O(arg_2410, arg_2411) } else { lines__26 = linked_2408.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2407, arg_2410, arg_2411) } } else {
//line :399:1
			lines__26 = lines__25 }; var seq_1938000364__27 any; var root_2455 any = /*line :313:1*/A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2455, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2457 lang.IFn; if


























































































	linked_2456 == nil { ifn_2457 = lang.IFn_Cast(root_2455) } else { ifn_2457 = nil }; var arg_2458 any = lines__26; if linked_2456 == nil { seq_1938000364__27 = ifn_2457.Invoke_O__O(arg_2458) } else { seq_1938000364__27 = linked_2456.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2455, arg_2458) }; var chunk_1938000365__28 any; var count_1938000366__29 int64 = 0; var i_1938000367__30 int64 = 0; L1:
//line :313:1
	for {


























































































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000367__30, count_1938000366__29) { var l__31 any = lang.Indexed_Cast(chunk_1938000365__28).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000367__30)); lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(l__31); seq_1938000364__27, chunk_1938000365__28, count_1938000366__29, i_1938000367__30 = seq_1938000364__27, chunk_1938000365__28, count_1938000366__29, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000367__30); continue L1 } else { var temp__1927000414__auto____31 any; var root_2459 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2461 lang.IFn; if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any = seq_1938000364__27; if linked_2460 == nil { temp__1927000414__auto____31 = ifn_2461.Invoke_O__O(arg_2462) } else { temp__1927000414__auto____31 = linked_2460.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2459, arg_2462) }; if jrt.J2g_Truth(temp__1927000414__auto____31) { var seq_1938000364__32 any = temp__1927000414__auto____31; var tmp45 any; var root_2463 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = seq_1938000364__32; if linked_2464 == nil { tmp45 = ifn_2465.Invoke_O__O(arg_2466) } else { tmp45 = linked_2464.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2463, arg_2466) }; if jrt.J2g_Truth(tmp45) { var c__1927000678__auto____33 any; var root_2467 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = seq_1938000364__32; if linked_2468 == nil { c__1927000678__auto____33 = ifn_2469.Invoke_O__O(arg_2470) } else { c__1927000678__auto____33 = linked_2468.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2467, arg_2470) }; var tmp46 any; var root_2482 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_2483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2482, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2484 lang.IFn; if linked_2483 == nil { ifn_2484 = lang.IFn_Cast(root_2482) } else { ifn_2484 = nil }; var arg_2485 any = seq_1938000364__32; if linked_2483 == nil { tmp46 = ifn_2484.Invoke_O__O(arg_2485) } else { tmp46 = linked_2483.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2482, arg_2485) }; seq_1938000364__27, chunk_1938000365__28, count_1938000366__29, i_1938000367__30 = tmp46, c__1927000678__auto____33, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____33))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__33 any; var root_2471 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = seq_1938000364__32; if linked_2472 == nil { l__33 = ifn_2473.Invoke_O__O(arg_2474) } else { l__33 = linked_2472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2471, arg_2474) }; lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(l__33); var tmp47 any; var root_2490 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = seq_1938000364__32; if linked_2491 == nil { tmp47 = ifn_2492.Invoke_O__O(arg_2493) } else { tmp47 = linked_2491.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2490, arg_2493) }; seq_1938000364__27, chunk_1938000365__28, count_1938000366__29, i_1938000367__30 = tmp47, nil, 0, 0; continue L1 } } }
//line :313:1
		break L1 }; var root_2475 any =



























































































	A_arbace_go_run_A_const_14.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_2477 lang.IFn; if linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; if linked_2476 == nil { ifn_2477.Invoke__O() } else { linked_2476.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_2475) }; if errs_QMARK___24 {
		return A_arbace_go_run_A_const_158 } else { return A_arbace_go_run_A_const_179 } }
//line :338:1
func A_arbace_go_run_errorcheck_fn__1938000292_A_New_O(p0 any) *A_arbace_go_run_errorcheck_fn__1938000292_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000292_A{}; t.Ctor_O(p0); return t }
//line :338:1
func (t *A_arbace_go_run_errorcheck_fn__1938000292_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :338:1
func (t *A_arbace_go_run_errorcheck_fn__1938000292_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2035 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any; var t_ any = t.F_src; t.F_src = nil; arg_2038 = t_; var arg_2039 any; var fnbody__2042 any = A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A_New(); var tmp2 *jrt.Class; var fncls__2041 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A_fn_class; if fncls__2041 == nil { var fncls__2041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, nil); A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A_fn_class = fncls__2041d; tmp2 = fncls__2041d } else { tmp2 = fncls__2041 }; arg_2039 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2042, tmp2, nil); var arg_2040 any = jrt.Boolean_FALSE.Ref(); if linked_2036 == nil { tmp1 = ifn_2037.Invoke_O_O_O__O(arg_2038, arg_2039, arg_2040) } else { tmp1 = linked_2036.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O_O__O(root_2035, arg_2038, arg_2039, arg_2040) } }; return nil }(); var root_2043 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; if linked_2044 == nil { ifn_2045.Invoke__O() } else { linked_2044.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2043) }; if tmp3 != nil { panic(tmp3) }; return tmp1 }
//line :338:1
func A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A_New() *A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A) Ctor() {}
//line :338:1
func (t *A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_go_run_errorcheck_fn__1938000296_A_New() *A_arbace_go_run_errorcheck_fn__1938000296_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000296_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_go_run_errorcheck_fn__1938000296_A) Ctor() {}
//line :340:1
func (t *A_arbace_go_run_errorcheck_fn__1938000296_A) Invoke_O_O__O(self, p1__1938000283_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_63; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000283_SHARP___1)) { return p1__1938000283_SHARP___1 } else { return nil } }

func A_arbace_go_run_errorcheck_fn__1938000298_A_New() *A_arbace_go_run_errorcheck_fn__1938000298_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000298_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_go_run_errorcheck_fn__1938000298_A) Ctor() {}
//line :342:1
func (t *A_arbace_go_run_errorcheck_fn__1938000298_A) Invoke_O_O__O(self, p1__1938000284_SHARP___1 any) any { var temp__1927000414__auto____2 any = A_arbace_go_run_A_const_218.Invoke_O__O(p1__1938000284_SHARP___1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var u__3 any = temp__1927000414__auto____2; return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_run_A_const_67.Invoke_O__O(p1__1938000284_SHARP___1), u__3) } else { return nil } }




func A_arbace_go_run_errorcheck_fn__1938000301_A_New() *A_arbace_go_run_errorcheck_fn__1938000301_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000301_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_go_run_errorcheck_fn__1938000301_A) Ctor() {}
//line :347:1
func (t *A_arbace_go_run_errorcheck_fn__1938000301_A) Invoke_O_O__O(self, p1__1938000285_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_183; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000285_SHARP___1))).Ref() }
func A_arbace_go_run_errorcheck_fn__1938000303_A_New() *A_arbace_go_run_errorcheck_fn__1938000303_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000303_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_go_run_errorcheck_fn__1938000303_A) Ctor() {}
//line :348:1
func (t *A_arbace_go_run_errorcheck_fn__1938000303_A) Invoke_O_O__O(self, p1__1938000286_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_184; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_64.Invoke_O__O(p1__1938000286_SHARP___1))).Ref() }

func A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A_New() *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A) Ctor() {}
//line :350:1
func (t *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A) Invoke_O_O__O(self, s__1938000306__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2136 any = A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A_New_O_O(s__1938000306__1, self); var tmp2 *jrt.Class; var fncls__2135 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A_fn_class; if fncls__2135 == nil { var fncls__2135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__2136); A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A_fn_class = fncls__2135d; tmp2 = fncls__2135d } else { tmp2 = fncls__2135 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2136, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :350:1
func A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A_New_O_O(p0, p1 any) *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A{}; t.Ctor_O_O(p0, p1); return t }
//line :350:1
func (t *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A) Ctor_O_O(c__s__1938000306, c__iter__1938000305 any) { t.F_s__1938000306 = c__s__1938000306; t.F_iter__1938000305 = c__iter__1938000305 }
//line :350:1
func (t *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A) Invoke_O__O(self any) any { { var s__1938000306__1 any; var t_ any = t.F_s__1938000306; t.F_s__1938000306 = nil; s__1938000306__1 = t_; for { var temp__1927000414__auto____2 any; var root_2067 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = s__1938000306__1; if linked_2068 == nil { temp__1927000414__auto____2 = ifn_2069.Invoke_O__O(arg_2070) } else { temp__1927000414__auto____2 = linked_2068.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2067, arg_2070) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000306__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2071 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = s__1938000306__3; if linked_2072 == nil { tmp1 = ifn_2073.Invoke_O__O(arg_2074) } else { tmp1 = linked_2072.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2071, arg_2074) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2075 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = s__1938000306__3; if linked_2076 == nil { c__1927001037__auto____4 = ifn_2077.Invoke_O__O(arg_2078) } else { c__1927001037__auto____4 = linked_2076.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2075, arg_2078) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000308__6 any; var root_2079 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2080 == nil { b__1938000308__6 = ifn_2081.Invoke_O__O(arg_2082) } else { b__1938000308__6 = linked_2080.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2079, arg_2082) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2094 any = A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A_New_O_I_O(b__1938000308__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2093 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A_fn_class; if fncls__2093 == nil { var fncls__2093d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__2094); A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A_fn_class = fncls__2093d; tmp3 = fncls__2093d } else { tmp3 = fncls__2093 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2094, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2095 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any; var root_2100 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2102 lang.IFn; if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = b__1938000308__6; if linked_2101 == nil { arg_2098 = ifn_2102.Invoke_O__O(arg_2103) } else { arg_2098 = linked_2101.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2100, arg_2103) }; var arg_2099 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000305); var tmp5 any; var root_2104 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = s__1938000306__3; if linked_2105 == nil { tmp5 = ifn_2106.Invoke_O__O(arg_2107) } else { tmp5 = linked_2105.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2104, arg_2107) }; arg_2099 = tmp4.Invoke_O__O(tmp5); if linked_2096 == nil { return ifn_2097.Invoke_O_O__O(arg_2098, arg_2099) } else { return linked_2096.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2095, arg_2098, arg_2099) } } else { var root_2108 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2110 lang.IFn; if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any; var root_2113 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any = b__1938000308__6; if linked_2114 == nil { arg_2111 = ifn_2115.Invoke_O__O(arg_2116) } else { arg_2111 = linked_2114.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2113, arg_2116) }; var arg_2112 any; if linked_2109 == nil { return ifn_2110.Invoke_O_O__O(arg_2111, arg_2112) } else { return linked_2109.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2108, arg_2111, arg_2112) } } } else { var fi__4 any; var root_2117 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = s__1938000306__3; if linked_2118 == nil { fi__4 = ifn_2119.Invoke_O__O(arg_2120) } else { fi__4 = linked_2118.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2117, arg_2120) }; var root_2121 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any; var tmp6 any = A_arbace_go_run_A_const_85.Invoke_O__O(fi__4); var tmp7 any; var root_2126 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = fi__4; var arg_2130 any = A_arbace_go_run_A_const_186; if linked_2127 == nil { tmp7 = ifn_2128.Invoke_O_O__O(arg_2129, arg_2130) } else { tmp7 = linked_2127.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2126, arg_2129, arg_2130) }; arg_2124 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_2125 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000305); var tmp9 any; var root_2131 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2131, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2133 lang.IFn; if linked_2132 == nil { ifn_2133 = lang.IFn_Cast(root_2131) } else { ifn_2133 = nil }; var arg_2134 any = s__1938000306__3; if linked_2132 == nil { tmp9 = ifn_2133.Invoke_O__O(arg_2134) } else { tmp9 = linked_2132.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2131, arg_2134) }; arg_2125 = tmp8.Invoke_O__O(tmp9); if linked_2122 == nil { return ifn_2123.Invoke_O_O__O(arg_2124, arg_2125) } else { return linked_2122.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2121, arg_2124, arg_2125) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :350:1
func A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :350:1
func (t *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A) Ctor_O_I_O(c__b__1938000308 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000308 = c__b__1938000308; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :350:1
func (t *A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A) Invoke_O__O(self any) any { { var i__1938000307__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000307__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000307__1)); var root_2083 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = t.F_b__1938000308; var arg_2087 any; var tmp2 any = A_arbace_go_run_A_const_85.Invoke_O__O(fi__2); var tmp3 any; var root_2088 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = fi__2; var arg_2092 any = A_arbace_go_run_A_const_185; if linked_2089 == nil { tmp3 = ifn_2090.Invoke_O_O__O(arg_2091, arg_2092) } else { tmp3 = linked_2089.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2088, arg_2091, arg_2092) }; arg_2087 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_2084 == nil { ifn_2085.Invoke_O_O__O(arg_2086, arg_2087) } else { linked_2084.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2083, arg_2086, arg_2087) }; i__1938000307__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000307__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_run_errorcheck_vmsg__1938000315_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_vmsg__1938000315_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_vmsg__1938000315_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :351:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000315_A) Ctor_O_O_O(c__file_lang, c__lang, c__src any) { t.F_file_lang = c__file_lang; t.F_lang = c__lang; t.F_src = c__src }
//line :351:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000315_A) Invoke_O_O__O(self, e__1 any) any { var m__2 any = A_arbace_go_run_A_const_65.Invoke_O__O(e__1); var tmp1 any; var root_2139 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2141 lang.IFn; if

	linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = A_arbace_go_run_A_const_187; var arg_2143 any = m__2; if linked_2140 == nil { tmp1 = ifn_2141.Invoke_O_O__O(arg_2142, arg_2143) } else { tmp1 = linked_2140.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2139, arg_2142, arg_2143) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_file_lang); var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(A_arbace_go_run_A_const_67.Invoke_O__O(e__1))
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var fl__4 any = temp__1927000408__auto____3
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil, Lit_73), jrt.RefArrayOf(jrt.Object_class, m__2, nil, fl__4, nil)).Ref() } else {
				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_74, nil, Lit_75); var tmp4 any; var or__1927000174__auto____8 any = t.F_lang; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var root_2144 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2146 lang.IFn; if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any = t.F_src; var arg_2148 any = A_arbace_go_run_A_const_188; if linked_2145 == nil { tmp4 = ifn_2146.Invoke_O_O__O(arg_2147, arg_2148) } else { tmp4 = linked_2145.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2144, arg_2147, arg_2148) } }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, m__2, nil, tmp4, nil)).Ref() } } else {
//line :353:1
					return m__2 } }







func A_arbace_go_run_errorcheck_relocate__1938000317_A_New_O(p0 any) *A_arbace_go_run_errorcheck_relocate__1938000317_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_relocate__1938000317_A{}; t.Ctor_O(p0); return t }
//line :361:1
func (t *A_arbace_go_run_errorcheck_relocate__1938000317_A) Ctor_O(c__lmap any) { t.F_lmap = c__lmap }
//line :361:1
func (t *A_arbace_go_run_errorcheck_relocate__1938000317_A) Invoke_O_O__O(self, l__1 any) any { var temp__1927000408__auto____2 any; if
												jrt.J2g_Truth(t.F_lmap) { var root_2155 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any = A_arbace_go_run_A_const_190; var arg_2159 any = l__1; if linked_2156 == nil { temp__1927000408__auto____2 = ifn_2157.Invoke_O_O__O(arg_2158, arg_2159) } else { temp__1927000408__auto____2 = linked_2156.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2155, arg_2158, arg_2159) } } else { temp__1927000408__auto____2 = nil }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var vec__1938000318__3 any = temp__1927000408__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000318__3, lang.RT_IntCast_J__I_NoInit(0), nil); var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000318__3, lang.RT_IntCast_J__I_NoInit(1), nil); var n__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000318__3, lang.RT_IntCast_J__I_NoInit(2), nil); var m__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000318__3, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_lmap); var vec__1938000321__8 any = tmp1.Invoke_O_O_O__O(f__5, jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__6))).Ref(), nil); var f__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000321__8, lang.RT_IntCast_J__I_NoInit(0), nil); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000321__8, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4
													return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, f__9, nil, n__10, nil, m__7)).Ref() } else {
//line :362:1
			return l__1 } }


func A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A_New_O_O(p0, p1 any) *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A{}; t.Ctor_O_O(p0, p1); return t }
//line :365:1
func (t *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A) Ctor_O_O(c__vmsg, c__lmap any) { t.F_vmsg = c__vmsg; t.F_lmap = c__lmap }
//line :365:1
func (t *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A) Invoke_O_O__O(self, s__1938000326__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2221 any = A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A_New_O_O_O_O(s__1938000326__1, self, t.F_vmsg, t.F_lmap); var tmp2 *jrt.Class; var fncls__2220 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A_fn_class; if fncls__2220 == nil { var fncls__2220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__2221); A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A_fn_class = fncls__2220d; tmp2 = fncls__2220d } else { tmp2 = fncls__2220 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2221, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :365:1
func A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A) Ctor_O_O_O_O(c__s__1938000326, c__iter__1938000325, c__vmsg, c__lmap any) { t.F_s__1938000326 = c__s__1938000326; t.F_iter__1938000325 = c__iter__1938000325; t.F_vmsg = c__vmsg; t.F_lmap = c__lmap }
//line :365:1
func (t *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A) Invoke_O__O(self any) any { { var s__1938000326__1 any; var t_ any = t.F_s__1938000326; t.F_s__1938000326 = nil; s__1938000326__1 = t_; for { var temp__1927000414__auto____2 any; var root_2162 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2164 lang.IFn; if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = s__1938000326__1; if linked_2163 == nil { temp__1927000414__auto____2 = ifn_2164.Invoke_O__O(arg_2165) } else { temp__1927000414__auto____2 = linked_2163.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2162, arg_2165) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000326__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2166 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = s__1938000326__3; if linked_2167 == nil { tmp1 = ifn_2168.Invoke_O__O(arg_2169) } else { tmp1 = linked_2167.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2166, arg_2169) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2170 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any = s__1938000326__3; if linked_2171 == nil { c__1927001037__auto____4 = ifn_2172.Invoke_O__O(arg_2173) } else { c__1927001037__auto____4 = linked_2171.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2170, arg_2173) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000328__6 any; var root_2174 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_2175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2174, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2176 lang.IFn; if linked_2175 == nil { ifn_2176 = lang.IFn_Cast(root_2174) } else { ifn_2176 = nil }; var arg_2177 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2175 == nil { b__1938000328__6 = ifn_2176.Invoke_O__O(arg_2177) } else { b__1938000328__6 = linked_2175.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2174, arg_2177) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2184 any = A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A_New_O_O_I_O_O(b__1938000328__6, t.F_vmsg, size__1927001038__auto____5, t.F_lmap, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2183 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A_fn_class; if fncls__2183 == nil { var fncls__2183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__2184); A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A_fn_class = fncls__2183d; tmp3 = fncls__2183d } else { tmp3 = fncls__2183 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2184, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2185 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2187 lang.IFn; if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any; var root_2190 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = b__1938000328__6; if linked_2191 == nil { arg_2188 = ifn_2192.Invoke_O__O(arg_2193) } else { arg_2188 = linked_2191.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2190, arg_2193) }; var arg_2189 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000325); var tmp5 any; var root_2194 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2196 lang.IFn; if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any = s__1938000326__3; if linked_2195 == nil { tmp5 = ifn_2196.Invoke_O__O(arg_2197) } else { tmp5 = linked_2195.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2194, arg_2197) }; arg_2189 = tmp4.Invoke_O__O(tmp5); if linked_2186 == nil { return ifn_2187.Invoke_O_O__O(arg_2188, arg_2189) } else { return linked_2186.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2185, arg_2188, arg_2189) } } else { var root_2198 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2198, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any; var root_2203 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = b__1938000328__6; if linked_2204 == nil { arg_2201 = ifn_2205.Invoke_O__O(arg_2206) } else { arg_2201 = linked_2204.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2203, arg_2206) }; var arg_2202 any; if linked_2199 == nil { return ifn_2200.Invoke_O_O__O(arg_2201, arg_2202) } else { return linked_2199.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2198, arg_2201, arg_2202) } } } else { var e__4 any; var root_2207 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = s__1938000326__3; if linked_2208 == nil { e__4 = ifn_2209.Invoke_O__O(arg_2210) } else { e__4 = linked_2208.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2207, arg_2210) }; var root_2211 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any; var vec__1938000336__5 any; var tmp6 any; var and__1927000168__auto____5 any = t.F_lmap
														if jrt.J2g_Truth(and__1927000168__auto____5) { tmp6 = A_arbace_go_run_A_const_68.Invoke_O__O(e__4) } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_lmap); vec__1938000336__5 = tmp7.Invoke_O_O_O__O(A_arbace_go_run_A_const_67.Invoke_O__O(e__4), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_go_run_A_const_68.Invoke_O__O(e__4))).Ref(), A_arbace_go_run_A_const_191.Invoke_O__O(e__4)) } else { vec__1938000336__5 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_run_A_const_67.Invoke_O__O(e__4), A_arbace_go_run_A_const_68.Invoke_O__O(e__4)) }
//line :365:1
	var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000336__5, lang.RT_IntCast_J__I_NoInit(0), nil); var n__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000336__5, lang.RT_IntCast_J__I_NoInit(1), nil)

	arg_2214 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, f__6, nil, n__7, nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__4))).Ref()
//line :365:1
	var arg_2215 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000325); var tmp9 any; var root_2216 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = s__1938000326__3; if linked_2217 == nil { tmp9 = ifn_2218.Invoke_O__O(arg_2219) } else { tmp9 = linked_2217.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2216, arg_2219) }; arg_2215 = tmp8.Invoke_O__O(tmp9); if linked_2212 == nil { return ifn_2213.Invoke_O_O__O(arg_2214, arg_2215) } else { return linked_2212.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2211, arg_2214, arg_2215) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :365:1
func A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :365:1
func (t *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A) Ctor_O_O_I_O_O(c__b__1938000328, c__vmsg any, c__size__1927001038__auto__ int32, c__lmap, c__c__1927001037__auto__ any) { t.F_b__1938000328 = c__b__1938000328; t.F_vmsg = c__vmsg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_lmap = c__lmap; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A) Invoke_O__O(self any) any { { var i__1938000327__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000327__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000327__1)); var root_2178 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = t.F_b__1938000328; var arg_2182 any; var vec__1938000332__3 any; var tmp2 any; var and__1927000168__auto____3 any = t.F_lmap
																if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = A_arbace_go_run_A_const_68.Invoke_O__O(e__2) } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_lmap); vec__1938000332__3 = tmp3.Invoke_O_O_O__O(A_arbace_go_run_A_const_67.Invoke_O__O(e__2), jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_go_run_A_const_68.Invoke_O__O(e__2))).Ref(), A_arbace_go_run_A_const_191.Invoke_O__O(e__2)) } else { vec__1938000332__3 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_run_A_const_67.Invoke_O__O(e__2), A_arbace_go_run_A_const_68.Invoke_O__O(e__2)) }
//line :365:1
	var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000332__3, lang.RT_IntCast_J__I_NoInit(0), nil); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000332__3, lang.RT_IntCast_J__I_NoInit(1), nil)

	arg_2182 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, f__4, nil, n__5, nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__2))).Ref()
//line :365:1
	if linked_2179 == nil { ifn_2180.Invoke_O_O__O(arg_2181, arg_2182) } else { linked_2179.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2178, arg_2181, arg_2182) }; i__1938000327__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000327__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_go_run_errorcheck_pos__1938000341_A_New() *A_arbace_go_run_errorcheck_pos__1938000341_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_pos__1938000341_A{}; t.Ctor(); return t }
//line :373:1
func (t *A_arbace_go_run_errorcheck_pos__1938000341_A) Ctor() {}
//line :373:1
func (t *A_arbace_go_run_errorcheck_pos__1938000341_A) Invoke_O_O__O(self, l__1 any) any { var vec__1938000342__2 any; var root_2232 any = A_arbace_go_run_A_const_153.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2232, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_2234 lang.IFn; if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any = A_arbace_go_run_A_const_196; var arg_2236 any = l__1; if linked_2233 == nil { vec__1938000342__2 = ifn_2234.Invoke_O_O__O(arg_2235, arg_2236) } else { vec__1938000342__2 = linked_2233.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_2232, arg_2235, arg_2236) }; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000342__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000342__2, lang.RT_IntCast_J__I_NoInit(1), nil); var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000342__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 any; var or__1927000174__auto____6 any = f__4; _ = ___3; if
												jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = Lit_41 }; var tmp2 any = tmp1; var tmp3 any; if jrt.J2g_Truth(n__5) { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(n__5))).Ref() } else { tmp3 = A_arbace_go_run_A_const_179 }; return /*line :373:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }
















func A_arbace_go_run_errorcheck_fn__1938000346_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_fn__1938000346_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000346_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :390:1
func (t *A_arbace_go_run_errorcheck_fn__1938000346_A) Ctor_O_O_O(c__gcflags, c__r, c__analyze any) { t.F_gcflags = c__gcflags; t.F_r = c__r; t.F_analyze = c__analyze }
//line :390:1
func (t *A_arbace_go_run_errorcheck_fn__1938000346_A) Invoke_O__O(self any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(t.F_analyze); var tmp2 any = t.F_r; return tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_201.Invoke_O__O(t.F_gcflags)) }
func A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A_New_O(p0 any) *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A{}; t.Ctor_O(p0); return t }
//line :395:1
func (t *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A) Ctor_O(c__relocate any) { t.F_relocate = c__relocate }
//line :395:1
func (t *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A) Invoke_O_O__O(self, s__1938000349__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2381 any = A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A_New_O_O_O(s__1938000349__1, self, t.F_relocate); var tmp2 *jrt.Class; var fncls__2380 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A_fn_class; if fncls__2380 == nil { var fncls__2380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__2381); A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A_fn_class = fncls__2380d; tmp2 = fncls__2380d } else { tmp2 = fncls__2380 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2381, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :395:1
func A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :395:1
func (t *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A) Ctor_O_O_O(c__s__1938000349, c__iter__1938000348, c__relocate any) { t.F_s__1938000349 = c__s__1938000349; t.F_iter__1938000348 = c__iter__1938000348; t.F_relocate = c__relocate }
//line :395:1
func (t *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A) Invoke_O__O(self any) any { { var s__1938000349__1 any; var t_ any = t.F_s__1938000349; t.F_s__1938000349 = nil; s__1938000349__1 = t_; for { var temp__1927000414__auto____2 any; var root_2322 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2324 lang.IFn; if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any = s__1938000349__1; if linked_2323 == nil { temp__1927000414__auto____2 = ifn_2324.Invoke_O__O(arg_2325) } else { temp__1927000414__auto____2 = linked_2323.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2322, arg_2325) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000349__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2326 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = s__1938000349__3; if linked_2327 == nil { tmp1 = ifn_2328.Invoke_O__O(arg_2329) } else { tmp1 = linked_2327.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2326, arg_2329) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2330 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = s__1938000349__3; if linked_2331 == nil { c__1927001037__auto____4 = ifn_2332.Invoke_O__O(arg_2333) } else { c__1927001037__auto____4 = linked_2331.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2330, arg_2333) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000351__6 any; var root_2334 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_2335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2334, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2336 lang.IFn; if linked_2335 == nil { ifn_2336 = lang.IFn_Cast(root_2334) } else { ifn_2336 = nil }; var arg_2337 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2335 == nil { b__1938000351__6 = ifn_2336.Invoke_O__O(arg_2337) } else { b__1938000351__6 = linked_2335.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2334, arg_2337) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2344 any = A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A_New_O_O_I_O(b__1938000351__6, t.F_relocate, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2343 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A_fn_class; if fncls__2343 == nil { var fncls__2343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__2344); A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A_fn_class = fncls__2343d; tmp3 = fncls__2343d } else { tmp3 = fncls__2343 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2344, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2345 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_2346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2345, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2347 lang.IFn; if linked_2346 == nil { ifn_2347 = lang.IFn_Cast(root_2345) } else { ifn_2347 = nil }; var arg_2348 any; var root_2350 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_2351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2350, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2352 lang.IFn; if linked_2351 == nil { ifn_2352 = lang.IFn_Cast(root_2350) } else { ifn_2352 = nil }; var arg_2353 any = b__1938000351__6; if linked_2351 == nil { arg_2348 = ifn_2352.Invoke_O__O(arg_2353) } else { arg_2348 = linked_2351.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2350, arg_2353) }; var arg_2349 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000348); var tmp5 any; var root_2354 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_2355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2354, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2356 lang.IFn; if linked_2355 == nil { ifn_2356 = lang.IFn_Cast(root_2354) } else { ifn_2356 = nil }; var arg_2357 any = s__1938000349__3; if linked_2355 == nil { tmp5 = ifn_2356.Invoke_O__O(arg_2357) } else { tmp5 = linked_2355.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2354, arg_2357) }; arg_2349 = tmp4.Invoke_O__O(tmp5); if linked_2346 == nil { return ifn_2347.Invoke_O_O__O(arg_2348, arg_2349) } else { return linked_2346.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2345, arg_2348, arg_2349) } } else { var root_2358 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_2359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2358, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2360 lang.IFn; if linked_2359 == nil { ifn_2360 = lang.IFn_Cast(root_2358) } else { ifn_2360 = nil }; var arg_2361 any; var root_2363 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any = b__1938000351__6; if linked_2364 == nil { arg_2361 = ifn_2365.Invoke_O__O(arg_2366) } else { arg_2361 = linked_2364.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2363, arg_2366) }; var arg_2362 any; if linked_2359 == nil { return ifn_2360.Invoke_O_O__O(arg_2361, arg_2362) } else { return linked_2359.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2358, arg_2361, arg_2362) } } } else { var vec__1938000359__4 any; var root_2367 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any = s__1938000349__3; if linked_2368 == nil { vec__1938000359__4 = ifn_2369.Invoke_O__O(arg_2370) } else { vec__1938000359__4 = linked_2368.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2367, arg_2370) }; var f__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000359__4, lang.RT_IntCast_J__I_NoInit(0), nil); var l__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000359__4, lang.RT_IntCast_J__I_NoInit(1), nil); var m__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000359__4, lang.RT_IntCast_J__I_NoInit(2), nil); var root_2371 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_2372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2371, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2373 lang.IFn; if linked_2372 == nil { ifn_2373 = lang.IFn_Cast(root_2371) } else { ifn_2373 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_relocate); var arg_2374 any = tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, f__5, nil, l__6, nil, m__7)).Ref()); var arg_2375 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000348); var tmp8 any; var root_2376 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = s__1938000349__3; if linked_2377 == nil { tmp8 = ifn_2378.Invoke_O__O(arg_2379) } else { tmp8 = linked_2377.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2376, arg_2379) }; arg_2375 = tmp7.Invoke_O__O(tmp8); if linked_2372 == nil { return ifn_2373.Invoke_O_O__O(arg_2374, arg_2375) } else { return linked_2372.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2371, arg_2374, arg_2375) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :395:1
func A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :395:1
func (t *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A) Ctor_O_O_I_O(c__b__1938000351, c__relocate any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000351 = c__b__1938000351; t.F_relocate = c__relocate; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :395:1
func (t *A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A) Invoke_O__O(self any) any { { var i__1938000350__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000350__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1938000355__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000350__1)); var f__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000355__2, lang.RT_IntCast_J__I_NoInit(0), nil); var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000355__2, lang.RT_IntCast_J__I_NoInit(1), nil); var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000355__2, lang.RT_IntCast_J__I_NoInit(2), nil); var root_2338 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2340 lang.IFn; if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = t.F_b__1938000351; var tmp2 lang.IFn = lang.IFn_Cast(t.F_relocate); var arg_2342 any = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_69, nil, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, f__3, nil, l__4, nil, m__5)).Ref()); if linked_2339 == nil { ifn_2340.Invoke_O_O__O(arg_2341, arg_2342) } else { linked_2339.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2338, arg_2341, arg_2342) }; i__1938000350__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000350__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_go_run__main_A_New() *A_arbace_go_run__main_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_go_run__main_A) Ctor() {}
//line :408:1
func (t *A_arbace_go_run__main_A) DoInvoke_O_O__O(self, args__0 any) any {










	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_224); var tmp2 any; var root_2800 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2800, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2802 lang.IFn; if linked_2801 == nil { ifn_2802 = lang.IFn_Cast(root_2800) } else { ifn_2802 = nil }; var arg_2803 any = args__0; if linked_2801 == nil { tmp2 = ifn_2802.Invoke_O__O(arg_2803) } else { tmp2 = linked_2801.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2800, arg_2803) }; if jrt.J2g_Truth(tmp1.Invoke_O__O(tmp2)) { var vec__1938000369__2 any = args__0; var seq__1938000370__3 any; var root_2551 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2553 lang.IFn
		if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = vec__1938000369__2; if linked_2552 == nil { seq__1938000370__3 = ifn_2553.Invoke_O__O(arg_2554) } else { seq__1938000370__3 = linked_2552.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2551, arg_2554) }
//line :419:1
		var first__1938000371__4 any; var root_2555 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2557 lang.IFn
		if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = seq__1938000370__3; if linked_2556 == nil { first__1938000371__4 = ifn_2557.Invoke_O__O(arg_2558) } else { first__1938000371__4 = linked_2556.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2555, arg_2558) }
//line :419:1
		var seq__1938000370__5 any; var root_2559 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2561 lang.IFn
		if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = seq__1938000370__3; if linked_2560 == nil { seq__1938000370__5 = ifn_2561.Invoke_O__O(arg_2562) } else { seq__1938000370__5 = linked_2560.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2559, arg_2562) }
//line :419:1
		var mode__6 any = first__1938000371__4; var first__1938000371__7 any; var root_2563 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2565 lang.IFn
		if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any = seq__1938000370__5; if linked_2564 == nil { first__1938000371__7 = ifn_2565.Invoke_O__O(arg_2566) } else { first__1938000371__7 = linked_2564.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2563, arg_2566) }
//line :419:1
		var seq__1938000370__8 any; var root_2567 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2567, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2569 lang.IFn
		if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any = seq__1938000370__5; if linked_2568 == nil { seq__1938000370__8 = ifn_2569.Invoke_O__O(arg_2570) } else { seq__1938000370__8 = linked_2568.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2567, arg_2570) }
//line :419:1
		var std__9 any = first__1938000371__7; var first__1938000371__10 any; var root_2571 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2573 lang.IFn
		if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = seq__1938000370__8; if linked_2572 == nil { first__1938000371__10 = ifn_2573.Invoke_O__O(arg_2574) } else { first__1938000371__10 = linked_2572.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2571, arg_2574) }
//line :419:1
		var seq__1938000370__11 any; var root_2575 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2575, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2577 lang.IFn
		if linked_2576 == nil { ifn_2577 = lang.IFn_Cast(root_2575) } else { ifn_2577 = nil }; var arg_2578 any = seq__1938000370__8; if linked_2576 == nil { seq__1938000370__11 = ifn_2577.Invoke_O__O(arg_2578) } else { seq__1938000370__11 = linked_2576.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2575, arg_2578) }
//line :419:1
		var cache__12 any = first__1938000371__10
		var pkgs__13 any = seq__1938000370__11
		lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_238)
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_204.GetRawRoot__O()); var tmp4 any; var root_2813 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2813, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2815 lang.IFn; if linked_2814 == nil { ifn_2815 = lang.IFn_Cast(root_2813) } else { ifn_2815 = nil }; var arg_2816 any = A_arbace_go_run_A_const_239; if linked_2814 == nil { tmp4 = ifn_2815.Invoke_O__O(arg_2816) } else { tmp4 = linked_2814.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2813, arg_2816) }; var tmp5 any = tmp4; var tmp6 any; var root_2817 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2817, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2819 lang.IFn
		if linked_2818 == nil { ifn_2819 = lang.IFn_Cast(root_2817) } else { ifn_2819 = nil }; var arg_2820 any = A_arbace_go_run_A_const_240; if linked_2818 == nil { tmp6 = ifn_2819.Invoke_O__O(arg_2820) } else { tmp6 = linked_2818.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2817, arg_2820) }
//line :422:1
		var tmp7 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, std__9, tmp6, cache__12)); var tmp8 *lang.Compiler_AOTFn; var fnbody__2898 any = A_arbace_go_run__main_fn__1938000372_A_New_O_O(pkgs__13, mode__6); var tmp9 *jrt.Class; var fncls__2897 *jrt.Class = A_arbace_go_run__main_fn__1938000372_A_fn_class; if fncls__2897 == nil { var fncls__2897d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__2898); A_arbace_go_run__main_fn__1938000372_A_fn_class = fncls__2897d; tmp9 = fncls__2897d } else { tmp9 = fncls__2897 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2898, tmp9, nil); tmp3.Invoke_O_O__O(tmp7, tmp8.Ref())




		var root_2899 any = A_arbace_go_run_A_const_14.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2899, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_2901 lang.IFn; if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; if linked_2900 == nil { ifn_2901.Invoke__O() } else { linked_2900.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_2899) }
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)) }
	var tmp10 any; var root_2579 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2579, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2581 lang.IFn; if linked_2580 == nil { ifn_2581 = lang.IFn_Cast(root_2579) } else { ifn_2581 = nil }; var arg_2582 any = args__0; if linked_2580 == nil { tmp10 = ifn_2581.Invoke_O__O(arg_2582) } else { tmp10 = linked_2580.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2579, arg_2582) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_2, tmp10) { var vec__1938000382__2 any; var root_2583 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2583, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2585 lang.IFn
		if linked_2584 == nil { ifn_2585 = lang.IFn_Cast(root_2583) } else { ifn_2585 = nil }; var arg_2586 any = args__0; if linked_2584 == nil { vec__1938000382__2 = ifn_2585.Invoke_O__O(arg_2586) } else { vec__1938000382__2 = linked_2584.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2583, arg_2586) }
//line :429:1
		var seq__1938000383__3 any; var root_2587 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2589 lang.IFn
		if linked_2588 == nil { ifn_2589 = lang.IFn_Cast(root_2587) } else { ifn_2589 = nil }; var arg_2590 any = vec__1938000382__2; if linked_2588 == nil { seq__1938000383__3 = ifn_2589.Invoke_O__O(arg_2590) } else { seq__1938000383__3 = linked_2588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2587, arg_2590) }
//line :429:1
		var first__1938000384__4 any; var root_2591 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2591, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2593 lang.IFn
		if linked_2592 == nil { ifn_2593 = lang.IFn_Cast(root_2591) } else { ifn_2593 = nil }; var arg_2594 any = seq__1938000383__3; if linked_2592 == nil { first__1938000384__4 = ifn_2593.Invoke_O__O(arg_2594) } else { first__1938000384__4 = linked_2592.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2591, arg_2594) }
//line :429:1
		var seq__1938000383__5 any; var root_2595 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2597 lang.IFn
		if linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any = seq__1938000383__3; if linked_2596 == nil { seq__1938000383__5 = ifn_2597.Invoke_O__O(arg_2598) } else { seq__1938000383__5 = linked_2596.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2595, arg_2598) }
//line :429:1
		var std__6 any = first__1938000384__4; var first__1938000384__7 any; var root_2599 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2601 lang.IFn
		if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = seq__1938000383__5; if linked_2600 == nil { first__1938000384__7 = ifn_2601.Invoke_O__O(arg_2602) } else { first__1938000384__7 = linked_2600.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2599, arg_2602) }
//line :429:1
		var seq__1938000383__8 any; var root_2603 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2605 lang.IFn
		if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any = seq__1938000383__5; if linked_2604 == nil { seq__1938000383__8 = ifn_2605.Invoke_O__O(arg_2606) } else { seq__1938000383__8 = linked_2604.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2603, arg_2606) }
//line :429:1
		var cache__9 any = first__1938000384__7; var first__1938000384__10 any; var root_2607 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2607, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2609 lang.IFn
		if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = seq__1938000383__8; if linked_2608 == nil { first__1938000384__10 = ifn_2609.Invoke_O__O(arg_2610) } else { first__1938000384__10 = linked_2608.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2607, arg_2610) }
//line :429:1
		var seq__1938000383__11 any; var root_2611 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2611, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2613 lang.IFn
		if linked_2612 == nil { ifn_2613 = lang.IFn_Cast(root_2611) } else { ifn_2613 = nil }; var arg_2614 any = seq__1938000383__8; if linked_2612 == nil { seq__1938000383__11 = ifn_2613.Invoke_O__O(arg_2614) } else { seq__1938000383__11 = linked_2612.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2611, arg_2614) }
//line :429:1
		var root__12 any = first__1938000384__10
		var nss__13 any = seq__1938000383__11
		lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_243)
//line :429:1
		var seq_1938000385__14 any; var root_2906 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2906, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2908 lang.IFn


		if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any = nss__13; if linked_2907 == nil { seq_1938000385__14 = ifn_2908.Invoke_O__O(arg_2909) } else { seq_1938000385__14 = linked_2907.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2906, arg_2909) }
//line :429:1
		var chunk_1938000386__15 any; var count_1938000387__16 int64 = 0; var i_1938000388__17 int64 = 0; L1: for {


			if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000388__17, count_1938000387__16) { var ns_name__18 any = lang.Indexed_Cast(chunk_1938000386__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000388__17)); var tmp11 *lang.Compiler_AOTFn; var fnbody__3007 any = A_arbace_go_run__main_fn__1938000389_A_New_O_O_O_O(ns_name__18, root__12, cache__9, std__6); var tmp12 *jrt.Class; var fncls__3006 *jrt.Class = A_arbace_go_run__main_fn__1938000389_A_fn_class
				if fncls__3006 == nil { var fncls__3006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__3007); A_arbace_go_run__main_fn__1938000389_A_fn_class = fncls__3006d; tmp12 = fncls__3006d } else { tmp12 = fncls__3006 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3007, tmp12, nil); Up_Compiler_AOTFn_IFn(tmp11).Invoke__O()
//line :432:1
				seq_1938000385__14, chunk_1938000386__15, count_1938000387__16, i_1938000388__17 = seq_1938000385__14, chunk_1938000386__15, count_1938000387__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000388__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_2910 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2910, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2912 lang.IFn; if linked_2911 == nil { ifn_2912 = lang.IFn_Cast(root_2910) } else { ifn_2912 = nil }; var arg_2913 any = seq_1938000385__14; if linked_2911 == nil { temp__1927000414__auto____18 = ifn_2912.Invoke_O__O(arg_2913) } else { temp__1927000414__auto____18 = linked_2911.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2910, arg_2913) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000385__19 any = temp__1927000414__auto____18; var tmp13 any; var root_2914 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2914, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2916 lang.IFn; if linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any = seq_1938000385__19; if linked_2915 == nil { tmp13 = ifn_2916.Invoke_O__O(arg_2917) } else { tmp13 = linked_2915.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2914, arg_2917) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____20 any; var root_2918 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_2919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2918, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2920 lang.IFn; if linked_2919 == nil { ifn_2920 = lang.IFn_Cast(root_2918) } else { ifn_2920 = nil }; var arg_2921 any = seq_1938000385__19; if linked_2919 == nil { c__1927000678__auto____20 = ifn_2920.Invoke_O__O(arg_2921) } else { c__1927000678__auto____20 = linked_2919.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2918, arg_2921) }; var tmp14 any; var root_3008 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3008, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3010 lang.IFn; if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any = seq_1938000385__19; if linked_3009 == nil { tmp14 = ifn_3010.Invoke_O__O(arg_3011) } else { tmp14 = linked_3009.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3008, arg_3011) }; seq_1938000385__14, chunk_1938000386__15, count_1938000387__16, i_1938000388__17 = tmp14, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var ns_name__20 any; var root_2922 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2922, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2924 lang.IFn; if linked_2923 == nil { ifn_2924 = lang.IFn_Cast(root_2922) } else { ifn_2924 = nil }; var arg_2925 any = seq_1938000385__19; if linked_2923 == nil { ns_name__20 = ifn_2924.Invoke_O__O(arg_2925) } else { ns_name__20 = linked_2923.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2922, arg_2925) }
					var tmp15 *lang.Compiler_AOTFn; var fnbody__3093 any = A_arbace_go_run__main_fn__1938000399_A_New_O_O_O_O(ns_name__20, root__12, cache__9, std__6); var tmp16 *jrt.Class; var fncls__3092 *jrt.Class = A_arbace_go_run__main_fn__1938000399_A_fn_class; if fncls__3092 == nil { var fncls__3092d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__3093); A_arbace_go_run__main_fn__1938000399_A_fn_class = fncls__3092d; tmp16 = fncls__3092d } else { tmp16 = fncls__3092 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3093, tmp16, nil); Up_Compiler_AOTFn_IFn(tmp15).Invoke__O()
//line :432:1
					var tmp17 any; var root_3094 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_3095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3094, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3096 lang.IFn; if linked_3095 == nil { ifn_3096 = lang.IFn_Cast(root_3094) } else { ifn_3096 = nil }; var arg_3097 any = seq_1938000385__19; if linked_3095 == nil { tmp17 = ifn_3096.Invoke_O__O(arg_3097) } else { tmp17 = linked_3095.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3094, arg_3097) }; seq_1938000385__14, chunk_1938000386__15, count_1938000387__16, i_1938000388__17 = tmp17, nil, 0, 0; continue L1 } } }
//line :429:1
			break L1
		}












		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)) }
	var tmp18 any; var root_2615 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2615, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2617 lang.IFn; if linked_2616 == nil { ifn_2617 = lang.IFn_Cast(root_2615) } else { ifn_2617 = nil }; var arg_2618 any = args__0; if linked_2616 == nil { tmp18 = ifn_2617.Invoke_O__O(arg_2618) } else { tmp18 = linked_2616.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2615, arg_2618) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_5, tmp18) { var vec__1938000409__2 any; var tmp19 *lang.Compiler_AOTFn; var fnbody__2758 any = A_arbace_go_run__main_fn__1938000415_A_New_O(args__0); var tmp20 *jrt.Class; var fncls__2757 *jrt.Class = A_arbace_go_run__main_fn__1938000415_A_fn_class
		if fncls__2757 == nil { var fncls__2757d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__2758); A_arbace_go_run__main_fn__1938000415_A_fn_class = fncls__2757d; tmp20 = fncls__2757d } else { tmp20 = fncls__2757 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2758, tmp20, nil); vec__1938000409__2 = Up_Compiler_AOTFn_IFn(tmp19).Invoke__O()
//line :444:1
		var opts__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000409__2, lang.RT_IntCast_J__I_NoInit(0), nil); var args__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000409__2, lang.RT_IntCast_J__I_NoInit(1), nil); var lang__5 any = A_arbace_go_run_A_const_230.Invoke_O__O(opts__3); var vec__1938000412__6 any = args__4; var root__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000412__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_name__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000412__6, lang.RT_IntCast_J__I_NoInit(1), nil); var pf__9 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp22 any; var root_2759 any = A_arbace_go_run_A_const_220.GetRawRoot__O(); var linked_2760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2759, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_2761 lang.IFn

















		if linked_2760 == nil { ifn_2761 = lang.IFn_Cast(root_2759) } else { ifn_2761 = nil }; var arg_2762 any = ns_name__8; if linked_2760 == nil { tmp22 = ifn_2761.Invoke_O__O(arg_2762) } else { tmp22 = linked_2760.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_2759, arg_2762) }
//line :444:1
		pf__9 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, root__7, nil, tmp22)))


















		if jrt.File_Cast(pf__9).IsFile__Z() { } else { var root_3098 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_3099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3098, A_arbace_go_run_fail_A_fn_class); var ifn_3100 lang.IFn; if linked_3099 == nil { ifn_3100 = lang.IFn_Cast(root_3098) } else { ifn_3100 = nil }; var arg_3101 any = A_arbace_go_run_A_const_66; var arg_3102 any = Lit_8; var arg_3103 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__9)).Ref(); if linked_3099 == nil { ifn_3100.Invoke_O_O_O__O(arg_3101, arg_3102, arg_3103) } else { linked_3099.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_3098, arg_3101, arg_3102, arg_3103) } }
		var tmp23 *lang.Compiler_AOTFn; var fnbody__2799 any = A_arbace_go_run__main_fn__1938000418_A_New_O_O_O_O(lang__5, pf__9, root__7, opts__3); var tmp24 *jrt.Class; var fncls__2798 *jrt.Class = A_arbace_go_run__main_fn__1938000418_A_fn_class; if fncls__2798 == nil { var fncls__2798d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__2799); A_arbace_go_run__main_fn__1938000418_A_fn_class = fncls__2798d; tmp24 = fncls__2798d } else { tmp24 = fncls__2798 }; tmp23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2799, tmp24, nil); jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(Up_Compiler_AOTFn_IFn(tmp23).Invoke__O())) }
//line :408:1
	var vec__1938000420__2 any = args__0; var seq__1938000421__3 any; var root_2494 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2496 lang.IFn































































	if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = vec__1938000420__2; if linked_2495 == nil { seq__1938000421__3 = ifn_2496.Invoke_O__O(arg_2497) } else { seq__1938000421__3 = linked_2495.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2494, arg_2497) }
//line :408:1
	var first__1938000422__4 any; var root_2498 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2500 lang.IFn































































	if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = seq__1938000421__3; if linked_2499 == nil { first__1938000422__4 = ifn_2500.Invoke_O__O(arg_2501) } else { first__1938000422__4 = linked_2499.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2498, arg_2501) }
//line :408:1
	var seq__1938000421__5 any; var root_2502 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2504 lang.IFn































































	if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any = seq__1938000421__3; if linked_2503 == nil { seq__1938000421__5 = ifn_2504.Invoke_O__O(arg_2505) } else { seq__1938000421__5 = linked_2503.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2502, arg_2505) }
//line :408:1
	var root__6 any = first__1938000422__4; var first__1938000422__7 any; var root_2506 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2508 lang.IFn































































	if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = seq__1938000421__5; if linked_2507 == nil { first__1938000422__7 = ifn_2508.Invoke_O__O(arg_2509) } else { first__1938000422__7 = linked_2507.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2506, arg_2509) }
//line :408:1
	var seq__1938000421__8 any; var root_2510 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2512 lang.IFn































































	if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = seq__1938000421__5; if linked_2511 == nil { seq__1938000421__8 = ifn_2512.Invoke_O__O(arg_2513) } else { seq__1938000421__8 = linked_2511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2510, arg_2513) }
//line :408:1
	var ns_name__9 any = first__1938000422__7; var pargs__10 any = seq__1938000421__8; var tmp25 any
	var and__1927000168__auto____11 any = root__6































































	if jrt.J2g_Truth(and__1927000168__auto____11) { tmp25 = ns_name__9 } else { tmp25 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp25) { } else {
		var root_3113 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_3114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3113, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3115 lang.IFn; if linked_3114 == nil { ifn_3115 = lang.IFn_Cast(root_3113) } else { ifn_3115 = nil }; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()); var tmp27 any = A_arbace_go_run_A_const_22; var arg_3116 any = tmp26.Invoke_O_O__O(tmp27, A_arbace_go_run_A_const_23.Get__O()); if linked_3114 == nil { ifn_3115.Invoke_O__O(arg_3116) } else { linked_3114.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3113, arg_3116) }; var tmp28 *lang.Compiler_AOTFn; var fnbody__3112 any = A_arbace_go_run__main_fn__1938000423_A_New(); var tmp29 *jrt.Class; var fncls__3111 *jrt.Class = A_arbace_go_run__main_fn__1938000423_A_fn_class; if fncls__3111 == nil { var fncls__3111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); A_arbace_go_run__main_fn__1938000423_A_fn_class = fncls__3111d; tmp29 = fncls__3111d } else { tmp29 = fncls__3111 }; tmp28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3112, tmp29, nil); Up_Compiler_AOTFn_IFn(tmp28).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :408:1
	var pf__11 any; var tmp30 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp31 any; var root_2514 any = A_arbace_go_run_A_const_220.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_2516 lang.IFn



































































	if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = ns_name__9; if linked_2515 == nil { tmp31 = ifn_2516.Invoke_O__O(arg_2517) } else { tmp31 = linked_2515.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_2514, arg_2517) }
//line :408:1
	pf__11 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp30, jrt.RefArrayOf(jrt.Object_class, root__6, nil, tmp31)))




































































	if jrt.File_Cast(pf__11).IsFile__Z() { } else {
		var root_3122 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_3123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3122, A_arbace_go_run_fail_A_fn_class); var ifn_3124 lang.IFn; if linked_3123 == nil { ifn_3124 = lang.IFn_Cast(root_3122) } else { ifn_3124 = nil }; var arg_3125 any = A_arbace_go_run_A_const_66; var arg_3126 any = Lit_8; var arg_3127 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__11)).Ref(); if linked_3123 == nil { ifn_3124.Invoke_O_O_O__O(arg_3125, arg_3126, arg_3127) } else { linked_3123.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_3122, arg_3125, arg_3126, arg_3127) } }
//line :408:1
	var status__12 any; var tmp32 *lang.Compiler_AOTFn; var fnbody__2550 any = A_arbace_go_run__main_fn__1938000425_A_New_O_O_O(pargs__10, pf__11, root__6); var tmp33 *jrt.Class
	var fncls__2549 /*line :408:1*/*jrt.Class = A_arbace_go_run__main_fn__1938000425_A_fn_class






































































	if fncls__2549 == nil { var fncls__2549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__2550); A_arbace_go_run__main_fn__1938000425_A_fn_class = fncls__2549d; tmp33 = fncls__2549d } else { tmp33 = fncls__2549 }; tmp32 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2550, tmp33, nil); status__12 = Up_Compiler_AOTFn_IFn(tmp32).Invoke__O()








	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__12)); return nil }
//line :422:1
func A_arbace_go_run__main_fn__1938000372_A_New_O_O(p0, p1 any) *A_arbace_go_run__main_fn__1938000372_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000372_A{}; t.Ctor_O_O(p0, p1); return t }
//line :422:1
func (t *A_arbace_go_run__main_fn__1938000372_A) Ctor_O_O(c__pkgs, c__mode any) { t.F_pkgs = c__pkgs; t.F_mode = c__mode }
//line :422:1
func (t *A_arbace_go_run__main_fn__1938000372_A) Invoke_O__O(self any) any {

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_mode, Lit_13) { var seq_1938000373__1 any; var root_2821 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2823 lang.IFn
		if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; var arg_2824 any; var tmp1 any; var root_2825 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = A_arbace_go_run_A_const_241; if linked_2826 == nil { tmp1 = ifn_2827.Invoke_O__O(arg_2828) } else { tmp1 = linked_2826.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2825, arg_2828) }; arg_2824 = lang.IFn_Cast(tmp1).Invoke_O__O(t.F_pkgs); if linked_2822 == nil { seq_1938000373__1 = ifn_2823.Invoke_O__O(arg_2824) } else { seq_1938000373__1 = linked_2822.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2821, arg_2824) }
//line :424:1
		var chunk_1938000374__2 any; var count_1938000375__3 int64 = 0; var i_1938000376__4 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000376__4, count_1938000375__3) { var p__5 any = lang.Indexed_Cast(chunk_1938000374__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000376__4)); lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(p__5); seq_1938000373__1, chunk_1938000374__2, count_1938000375__3, i_1938000376__4 = seq_1938000373__1, chunk_1938000374__2, count_1938000375__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000376__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_2829 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = seq_1938000373__1; if linked_2830 == nil { temp__1927000414__auto____5 = ifn_2831.Invoke_O__O(arg_2832) } else { temp__1927000414__auto____5 = linked_2830.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2829, arg_2832) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1938000373__6 any = temp__1927000414__auto____5; var tmp2 any; var root_2833 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_2834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2833, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2835 lang.IFn; if linked_2834 == nil { ifn_2835 = lang.IFn_Cast(root_2833) } else { ifn_2835 = nil }; var arg_2836 any = seq_1938000373__6; if linked_2834 == nil { tmp2 = ifn_2835.Invoke_O__O(arg_2836) } else { tmp2 = linked_2834.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2833, arg_2836) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____7 any; var root_2837 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_2838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2837, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2839 lang.IFn; if linked_2838 == nil { ifn_2839 = lang.IFn_Cast(root_2837) } else { ifn_2839 = nil }; var arg_2840 any = seq_1938000373__6; if linked_2838 == nil { c__1927000678__auto____7 = ifn_2839.Invoke_O__O(arg_2840) } else { c__1927000678__auto____7 = linked_2838.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2837, arg_2840) }; var tmp3 any; var root_2869 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_2870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2869, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2871 lang.IFn; if linked_2870 == nil { ifn_2871 = lang.IFn_Cast(root_2869) } else { ifn_2871 = nil }; var arg_2872 any = seq_1938000373__6; if linked_2870 == nil { tmp3 = ifn_2871.Invoke_O__O(arg_2872) } else { tmp3 = linked_2870.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2869, arg_2872) }; seq_1938000373__1, chunk_1938000374__2, count_1938000375__3, i_1938000376__4 = tmp3, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__7 any; var root_2841 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2841, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2843 lang.IFn; if linked_2842 == nil { ifn_2843 = lang.IFn_Cast(root_2841) } else { ifn_2843 = nil }; var arg_2844 any = seq_1938000373__6; if linked_2842 == nil { p__7 = ifn_2843.Invoke_O__O(arg_2844) } else { p__7 = linked_2842.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2841, arg_2844) }; lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(p__7); var tmp4 any; var root_2877 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2877, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2879 lang.IFn; if linked_2878 == nil { ifn_2879 = lang.IFn_Cast(root_2877) } else { ifn_2879 = nil }; var arg_2880 any = seq_1938000373__6; if linked_2878 == nil { tmp4 = ifn_2879.Invoke_O__O(arg_2880) } else { tmp4 = linked_2878.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2877, arg_2880) }; seq_1938000373__1, chunk_1938000374__2, count_1938000375__3, i_1938000376__4 = tmp4, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :424:1
				var seq_1938000377__1 any; var root_2845 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2845, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2847 lang.IFn

				if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any = t.F_pkgs; if linked_2846 == nil { seq_1938000377__1 = ifn_2847.Invoke_O__O(arg_2848) } else { seq_1938000377__1 = linked_2846.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2845, arg_2848) }
//line :424:1
				var chunk_1938000378__2 any; var count_1938000379__3 int64 = 0; var i_1938000380__4 int64 = 0; L2: for {

					if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000380__4, count_1938000379__3) { var p__5_2 any = lang.Indexed_Cast(chunk_1938000378__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000380__4)); var tmp5 any; var root_2881 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2881, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2883 lang.IFn; if linked_2882 == nil { ifn_2883 = lang.IFn_Cast(root_2881) } else { ifn_2883 = nil }; var arg_2884 any = A_arbace_go_run_A_const_242; if linked_2882 == nil { tmp5 = ifn_2883.Invoke_O__O(arg_2884) } else { tmp5 = linked_2882.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2881, arg_2884) }; lang.IFn_Cast(tmp5).Invoke_O__O(p__5_2); seq_1938000377__1, chunk_1938000378__2, count_1938000379__3, i_1938000380__4 = seq_1938000377__1, chunk_1938000378__2, count_1938000379__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000380__4); continue L2 } else { var temp__1927000414__auto____5_2 any; var root_2849 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_2850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2849, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2851 lang.IFn; if linked_2850 == nil { ifn_2851 = lang.IFn_Cast(root_2849) } else { ifn_2851 = nil }; var arg_2852 any = seq_1938000377__1; if linked_2850 == nil { temp__1927000414__auto____5_2 = ifn_2851.Invoke_O__O(arg_2852) } else { temp__1927000414__auto____5_2 = linked_2850.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2849, arg_2852) }; if jrt.J2g_Truth(temp__1927000414__auto____5_2) { var seq_1938000377__6 any = temp__1927000414__auto____5_2; var tmp6 any; var root_2853 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_2854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2853, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2855 lang.IFn; if linked_2854 == nil { ifn_2855 = lang.IFn_Cast(root_2853) } else { ifn_2855 = nil }; var arg_2856 any = seq_1938000377__6; if linked_2854 == nil { tmp6 = ifn_2855.Invoke_O__O(arg_2856) } else { tmp6 = linked_2854.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2853, arg_2856) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____7_2 any; var root_2857 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_2858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2857, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2859 lang.IFn; if linked_2858 == nil { ifn_2859 = lang.IFn_Cast(root_2857) } else { ifn_2859 = nil }; var arg_2860 any = seq_1938000377__6; if linked_2858 == nil { c__1927000678__auto____7_2 = ifn_2859.Invoke_O__O(arg_2860) } else { c__1927000678__auto____7_2 = linked_2858.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2857, arg_2860) }; var tmp7 any; var root_2885 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = seq_1938000377__6; if linked_2886 == nil { tmp7 = ifn_2887.Invoke_O__O(arg_2888) } else { tmp7 = linked_2886.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2885, arg_2888) }; seq_1938000377__1, chunk_1938000378__2, count_1938000379__3, i_1938000380__4 = tmp7, c__1927000678__auto____7_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var p__7_2 any; var root_2861 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2863 lang.IFn; if linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any = seq_1938000377__6; if linked_2862 == nil { p__7_2 = ifn_2863.Invoke_O__O(arg_2864) } else { p__7_2 = linked_2862.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2861, arg_2864) }; var tmp8 any; var root_2889 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = A_arbace_go_run_A_const_242; if linked_2890 == nil { tmp8 = ifn_2891.Invoke_O__O(arg_2892) } else { tmp8 = linked_2890.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2889, arg_2892) }; lang.IFn_Cast(tmp8).Invoke_O__O(p__7_2); var tmp9 any; var root_2893 any = A_arbace_go_run_A_const_58.GetRawRoot__O(); var linked_2894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2893, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2895 lang.IFn; if linked_2894 == nil { ifn_2895 = lang.IFn_Cast(root_2893) } else { ifn_2895 = nil }; var arg_2896 any = seq_1938000377__6; if linked_2894 == nil { tmp9 = ifn_2895.Invoke_O__O(arg_2896) } else { tmp9 = linked_2894.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2893, arg_2896) }; seq_1938000377__1, chunk_1938000378__2, count_1938000379__3, i_1938000380__4 = tmp9, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :422:1
	panic("j2g: unreachable")
}









func A_arbace_go_run__main_fn__1938000389_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run__main_fn__1938000389_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000389_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :433:1
func (t *A_arbace_go_run__main_fn__1938000389_A) Ctor_O_O_O_O(c__ns_name, c__root, c__cache, c__std any) { t.F_ns_name = c__ns_name; t.F_root = c__root; t.F_cache = c__cache; t.F_std = c__std }
//line :433:1
func (t *A_arbace_go_run__main_fn__1938000389_A) Invoke_O__O(self any) any { var tmp1 any; tmp21 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var pf__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp3 any = t.F_root; var tmp4 any; var root_2926 any = A_arbace_go_run_A_const_220.GetRawRoot__O(); var linked_2927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2926, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_2928 lang.IFn
										if linked_2927 == nil { ifn_2928 = lang.IFn_Cast(root_2926) } else { ifn_2928 = nil }; var arg_2929 any = t.F_ns_name; if linked_2927 == nil { tmp4 = ifn_2928.Invoke_O__O(arg_2929) } else { tmp4 = linked_2927.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_2926, arg_2929) }
//line :433:1
	pf__3 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4))); var src__4 any; var root_2930 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_2931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2930, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_2932 lang.IFn

	if linked_2931 == nil { ifn_2932 = lang.IFn_Cast(root_2930) } else { ifn_2932 = nil }; var arg_2933 any; var tmp5 any = A_arbace_go_run_A_const_77; var tmp6 any; var t_ any = t.F_root; t.F_root = nil; tmp6 = t_; arg_2933 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6)); var arg_2934 any; var arg_2935 any; var root_2937 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_2938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2937, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2939 lang.IFn; if linked_2938 == nil { ifn_2939 = lang.IFn_Cast(root_2937) } else { ifn_2939 = nil }; var arg_2940 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_2938 == nil { arg_2935 = ifn_2939.Invoke_O__O(arg_2940) } else { arg_2935 = linked_2938.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2937, arg_2940) }; var arg_2936 any = pf__3; if linked_2931 == nil { src__4 = ifn_2932.Invoke_O_O_O_O__O(arg_2933, arg_2934, arg_2935, arg_2936) } else { src__4 = linked_2931.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_2930, arg_2933, arg_2934, arg_2935, arg_2936) }
//line :433:1
	var r__5 any; var root_2977 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2979 lang.IFn


	if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_run_A_const_217, nil); if linked_2978 == nil { ifn_2979.Invoke_O__O(arg_2980) } else { linked_2978.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2977, arg_2980) }; var tmp7 *lang.Compiler_AOTFn; var fnbody__2953 any = A_arbace_go_run__main_fn__1938000389_fn__1938000390_A_New_O(src__4); var tmp8 *jrt.Class; var fncls__2952 *jrt.Class = A_arbace_go_run__main_fn__1938000389_fn__1938000390_A_fn_class; if fncls__2952 == nil { var fncls__2952d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__2953); A_arbace_go_run__main_fn__1938000389_fn__1938000390_A_fn_class = fncls__2952d; tmp8 = fncls__2952d } else { tmp8 = fncls__2952 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2953, tmp8, nil); r__5 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O()
	var tmp9 any; var root_2954 any = A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2954, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2956 lang.IFn; if linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var arg_2957 any = A_arbace_go_run_A_const_60.Invoke_O__O(r__5); if linked_2955 == nil { tmp9 = ifn_2956.Invoke_O__O(arg_2957) } else { tmp9 = linked_2955.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2954, arg_2957) }; if jrt.J2g_Truth(tmp9) {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_204.GetRawRoot__O()); var tmp11 any; var root_2963 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2963, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2965 lang.IFn; if linked_2964 == nil { ifn_2965 = lang.IFn_Cast(root_2963) } else { ifn_2965 = nil }; var arg_2966 any = A_arbace_go_run_A_const_244; if linked_2964 == nil { tmp11 = ifn_2965.Invoke_O__O(arg_2966) } else { tmp11 = linked_2964.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2963, arg_2966) }; var tmp12 any = tmp11; var tmp13 any; var t__2 any = t.F_std; t.F_std = nil; tmp13 = t__2; var tmp14 any = tmp13; var tmp15 any; var root_2967 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2969 lang.IFn
		if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any = A_arbace_go_run_A_const_245; if linked_2968 == nil { tmp15 = ifn_2969.Invoke_O__O(arg_2970) } else { tmp15 = linked_2968.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2967, arg_2970) }
//line :438:1
		var tmp16 any = tmp15; var tmp17 any; var t__3 any = t.F_cache; t.F_cache = nil; tmp17 = t__3; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, tmp16, tmp17)); var tmp19 *lang.Compiler_AOTFn; var fnbody__2976 any = A_arbace_go_run__main_fn__1938000389_fn__1938000394_A_New_O(r__5); var tmp20 *jrt.Class; var fncls__2975 *jrt.Class = A_arbace_go_run__main_fn__1938000389_fn__1938000394_A_fn_class; if fncls__2975 == nil { var fncls__2975d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__2976); A_arbace_go_run__main_fn__1938000389_fn__1938000394_A_fn_class = fncls__2975d; tmp20 = fncls__2975d } else { tmp20 = fncls__2975 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2976, tmp20, nil); tmp1 = tmp10.Invoke_O_O__O(tmp18, tmp19.Ref()) } else {
//line :437:1
			tmp1 = nil } }; return nil }(); if /*line :433:1*/ tmp21 != nil { if true { var ex__3 jrt.Throwable_I = tmp21; var root_2997 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2999 lang.IFn








				if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()); var tmp23 any = A_arbace_go_run_A_const_22; var arg_3000 any = tmp22.Invoke_O_O__O(tmp23, A_arbace_go_run_A_const_23.Get__O()); if linked_2998 == nil { ifn_2999.Invoke_O__O(arg_3000) } else { linked_2998.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2997, arg_3000) }; var tmp24 *lang.Compiler_AOTFn; var fnbody__2996 any = A_arbace_go_run__main_fn__1938000389_fn__1938000396_A_New_O_O(ex__3, t.F_ns_name); var tmp25 *jrt.Class; var fncls__2995 *jrt.Class = A_arbace_go_run__main_fn__1938000389_fn__1938000396_A_fn_class; if fncls__2995 == nil { var fncls__2995d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__2996); A_arbace_go_run__main_fn__1938000389_fn__1938000396_A_fn_class = fncls__2995d; tmp25 = fncls__2995d } else { tmp25 = fncls__2995 }; tmp24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2996, tmp25, nil); tmp1 = Up_Compiler_AOTFn_IFn(tmp24).Invoke__O() } }; return tmp1 }
//line :433:1
func A_arbace_go_run__main_fn__1938000399_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run__main_fn__1938000399_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000399_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :433:1
func (t *A_arbace_go_run__main_fn__1938000399_A) Ctor_O_O_O_O(c__ns_name, c__root, c__cache, c__std any) { t.F_ns_name = c__ns_name; t.F_root = c__root; t.F_cache = c__cache; t.F_std = c__std }
//line :433:1
func (t *A_arbace_go_run__main_fn__1938000399_A) Invoke_O__O(self any) any { var tmp1 any; tmp21 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var pf__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_7, nil); var tmp3 any = t.F_root; var tmp4 any; var root_3012 any = A_arbace_go_run_A_const_220.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_3014 lang.IFn
										if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var arg_3015 any = t.F_ns_name; if linked_3013 == nil { tmp4 = ifn_3014.Invoke_O__O(arg_3015) } else { tmp4 = linked_3013.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_3012, arg_3015) }
//line :433:1
	pf__3 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4))); var src__4 any; var root_3016 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_3018 lang.IFn

	if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any; var tmp5 any = A_arbace_go_run_A_const_77; var tmp6 any; var t_ any = t.F_root; t.F_root = nil; tmp6 = t_; arg_3019 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6)); var arg_3020 any; var arg_3021 any; var root_3023 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_3024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3023, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3025 lang.IFn; if linked_3024 == nil { ifn_3025 = lang.IFn_Cast(root_3023) } else { ifn_3025 = nil }; var arg_3026 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); if linked_3024 == nil { arg_3021 = ifn_3025.Invoke_O__O(arg_3026) } else { arg_3021 = linked_3024.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3023, arg_3026) }; var arg_3022 any = pf__3; if linked_3017 == nil { src__4 = ifn_3018.Invoke_O_O_O_O__O(arg_3019, arg_3020, arg_3021, arg_3022) } else { src__4 = linked_3017.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_3016, arg_3019, arg_3020, arg_3021, arg_3022) }
//line :433:1
	var r__5 any; var root_3063 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_3064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3063, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3065 lang.IFn


	if linked_3064 == nil { ifn_3065 = lang.IFn_Cast(root_3063) } else { ifn_3065 = nil }; var arg_3066 any = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_go_run_A_const_217, nil); if linked_3064 == nil { ifn_3065.Invoke_O__O(arg_3066) } else { linked_3064.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3063, arg_3066) }; var tmp7 *lang.Compiler_AOTFn; var fnbody__3039 any = A_arbace_go_run__main_fn__1938000399_fn__1938000400_A_New_O(src__4); var tmp8 *jrt.Class; var fncls__3038 *jrt.Class = A_arbace_go_run__main_fn__1938000399_fn__1938000400_A_fn_class; if fncls__3038 == nil { var fncls__3038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__3039); A_arbace_go_run__main_fn__1938000399_fn__1938000400_A_fn_class = fncls__3038d; tmp8 = fncls__3038d } else { tmp8 = fncls__3038 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3039, tmp8, nil); r__5 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O()
	var tmp9 any; var root_3040 any = A_arbace_go_run_A_const_81.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = A_arbace_go_run_A_const_60.Invoke_O__O(r__5); if linked_3041 == nil { tmp9 = ifn_3042.Invoke_O__O(arg_3043) } else { tmp9 = linked_3041.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3040, arg_3043) }; if jrt.J2g_Truth(tmp9) {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_204.GetRawRoot__O()); var tmp11 any; var root_3049 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_3051 lang.IFn; if linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any = A_arbace_go_run_A_const_244; if linked_3050 == nil { tmp11 = ifn_3051.Invoke_O__O(arg_3052) } else { tmp11 = linked_3050.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_3049, arg_3052) }; var tmp12 any = tmp11; var tmp13 any; var t__2 any = t.F_std; t.F_std = nil; tmp13 = t__2; var tmp14 any = tmp13; var tmp15 any; var root_3053 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_3054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3053, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_3055 lang.IFn
		if linked_3054 == nil { ifn_3055 = lang.IFn_Cast(root_3053) } else { ifn_3055 = nil }; var arg_3056 any = A_arbace_go_run_A_const_245; if linked_3054 == nil { tmp15 = ifn_3055.Invoke_O__O(arg_3056) } else { tmp15 = linked_3054.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_3053, arg_3056) }
//line :438:1
		var tmp16 any = tmp15; var tmp17 any; var t__3 any = t.F_cache; t.F_cache = nil; tmp17 = t__3; var tmp18 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, tmp16, tmp17)); var tmp19 *lang.Compiler_AOTFn; var fnbody__3062 any = A_arbace_go_run__main_fn__1938000399_fn__1938000404_A_New_O(r__5); var tmp20 *jrt.Class; var fncls__3061 *jrt.Class = A_arbace_go_run__main_fn__1938000399_fn__1938000404_A_fn_class; if fncls__3061 == nil { var fncls__3061d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__3062); A_arbace_go_run__main_fn__1938000399_fn__1938000404_A_fn_class = fncls__3061d; tmp20 = fncls__3061d } else { tmp20 = fncls__3061 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3062, tmp20, nil); tmp1 = tmp10.Invoke_O_O__O(tmp18, tmp19.Ref()) } else {
//line :437:1
			tmp1 = nil } }; return nil }(); if /*line :433:1*/ tmp21 != nil { if true { var ex__3 jrt.Throwable_I = tmp21; var root_3083 any = A_arbace_go_run_A_const_20.GetRawRoot__O(); var linked_3084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3083, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3085 lang.IFn








				if linked_3084 == nil { ifn_3085 = lang.IFn_Cast(root_3083) } else { ifn_3085 = nil }; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_21.GetRawRoot__O()); var tmp23 any = A_arbace_go_run_A_const_22; var arg_3086 any = tmp22.Invoke_O_O__O(tmp23, A_arbace_go_run_A_const_23.Get__O()); if linked_3084 == nil { ifn_3085.Invoke_O__O(arg_3086) } else { linked_3084.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3083, arg_3086) }; var tmp24 *lang.Compiler_AOTFn; var fnbody__3082 any = A_arbace_go_run__main_fn__1938000399_fn__1938000406_A_New_O_O(ex__3, t.F_ns_name); var tmp25 *jrt.Class; var fncls__3081 *jrt.Class = A_arbace_go_run__main_fn__1938000399_fn__1938000406_A_fn_class; if fncls__3081 == nil { var fncls__3081d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__3082); A_arbace_go_run__main_fn__1938000399_fn__1938000406_A_fn_class = fncls__3081d; tmp25 = fncls__3081d } else { tmp25 = fncls__3081 }; tmp24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3082, tmp25, nil); tmp1 = Up_Compiler_AOTFn_IFn(tmp24).Invoke__O() } }; return tmp1 }
//line :436:1
func A_arbace_go_run__main_fn__1938000389_fn__1938000390_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000389_fn__1938000390_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000389_fn__1938000390_A{}; t.Ctor_O(p0); return t }
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000390_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000390_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_2941 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_2942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2941, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_2943 lang.IFn; if linked_2942 == nil { ifn_2943 = lang.IFn_Cast(root_2941) } else { ifn_2943 = nil }; var arg_2944 any; var t_ any = t.F_src; t.F_src = nil; arg_2944 = t_; var arg_2945 any; var fnbody__2948 any = A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A_New(); var tmp2 *jrt.Class; var fncls__2947 *jrt.Class = A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A_fn_class; if fncls__2947 == nil { var fncls__2947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A_fn_class = fncls__2947d; tmp2 = fncls__2947d } else { tmp2 = fncls__2947 }; arg_2945 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2948, tmp2, nil); var arg_2946 any = jrt.Boolean_FALSE.Ref(); if linked_2942 == nil { tmp1 = ifn_2943.Invoke_O_O_O__O(arg_2944, arg_2945, arg_2946) } else { tmp1 = linked_2942.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O_O__O(root_2941, arg_2944, arg_2945, arg_2946) } }; return nil }(); var root_2949 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2951 lang.IFn; if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; if linked_2950 == nil { ifn_2951.Invoke__O() } else { linked_2950.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2949) }; if tmp3 != nil { panic(tmp3) }; return tmp1 }
//line :436:1
func A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A_New() *A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A) Ctor() {}
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :436:1
func A_arbace_go_run__main_fn__1938000399_fn__1938000400_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000399_fn__1938000400_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000399_fn__1938000400_A{}; t.Ctor_O(p0); return t }
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000400_A) Ctor_O(c__src any) { t.F_src = c__src }
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000400_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3027 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_3028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3027, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_3029 lang.IFn; if linked_3028 == nil { ifn_3029 = lang.IFn_Cast(root_3027) } else { ifn_3029 = nil }; var arg_3030 any; var t_ any = t.F_src; t.F_src = nil; arg_3030 = t_; var arg_3031 any; var fnbody__3034 any = A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A_New(); var tmp2 *jrt.Class; var fncls__3033 *jrt.Class = A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A_fn_class; if fncls__3033 == nil { var fncls__3033d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A_fn_class = fncls__3033d; tmp2 = fncls__3033d } else { tmp2 = fncls__3033 }; arg_3031 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3034, tmp2, nil); var arg_3032 any = jrt.Boolean_FALSE.Ref(); if linked_3028 == nil { tmp1 = ifn_3029.Invoke_O_O_O__O(arg_3030, arg_3031, arg_3032) } else { tmp1 = linked_3028.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O_O__O(root_3027, arg_3030, arg_3031, arg_3032) } }; return nil }(); var root_3035 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_3036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3035, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3037 lang.IFn; if linked_3036 == nil { ifn_3037 = lang.IFn_Cast(root_3035) } else { ifn_3037 = nil }; if linked_3036 == nil { ifn_3037.Invoke__O() } else { linked_3036.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3035) }; if tmp3 != nil { panic(tmp3) }; return tmp1 }
//line :436:1
func A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A_New() *A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A) Ctor() {}
//line :436:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_go_run__main_fn__1938000389_fn__1938000394_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000389_fn__1938000394_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000389_fn__1938000394_A{}; t.Ctor_O(p0); return t }
//line :438:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000394_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :438:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000394_A) Invoke_O__O(self any) any {

	var tmp1 any; var root_2971 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2971, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any = A_arbace_go_run_A_const_246; if linked_2972 == nil { tmp1 = ifn_2973.Invoke_O__O(arg_2974) } else { tmp1 = linked_2972.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_2971, arg_2974) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(t.F_r, A_arbace_go_run_A_const_179) }
//line :438:1
func A_arbace_go_run__main_fn__1938000399_fn__1938000404_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000399_fn__1938000404_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000399_fn__1938000404_A{}; t.Ctor_O(p0); return t }
//line :438:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000404_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :438:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000404_A) Invoke_O__O(self any) any {

	var tmp1 any; var root_3057 any = A_arbace_go_run_A_const_194.GetRawRoot__O(); var linked_3058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3057, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_3059 lang.IFn; if linked_3058 == nil { ifn_3059 = lang.IFn_Cast(root_3057) } else { ifn_3059 = nil }; var arg_3060 any = A_arbace_go_run_A_const_246; if linked_3058 == nil { tmp1 = ifn_3059.Invoke_O__O(arg_3060) } else { tmp1 = linked_3058.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_3057, arg_3060) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(t.F_r, A_arbace_go_run_A_const_179)
}
func A_arbace_go_run__main_fn__1938000389_fn__1938000396_A_New_O_O(p0, p1 any) *A_arbace_go_run__main_fn__1938000389_fn__1938000396_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000389_fn__1938000396_A{}; t.Ctor_O_O(p0, p1); return t }
//line :442:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000396_A) Ctor_O_O(c__ex, c__ns_name any) { t.F_ex = c__ex; t.F_ns_name = c__ns_name }
//line :442:1
func (t *A_arbace_go_run__main_fn__1938000389_fn__1938000396_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns_name; t.F_ns_name = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_ex; t.F_ex = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O__O(Lit_18, tmp4, jrt.Throwable_Cast(tmp5).GetMessage__String().Ref()) }; return nil }(); var root_2992 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; if linked_2993 == nil { ifn_2994.Invoke__O() } else { linked_2993.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2992) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :442:1
func A_arbace_go_run__main_fn__1938000399_fn__1938000406_A_New_O_O(p0, p1 any) *A_arbace_go_run__main_fn__1938000399_fn__1938000406_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000399_fn__1938000406_A{}; t.Ctor_O_O(p0, p1); return t }
//line :442:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000406_A) Ctor_O_O(c__ex, c__ns_name any) { t.F_ex = c__ex; t.F_ns_name = c__ns_name }
//line :442:1
func (t *A_arbace_go_run__main_fn__1938000399_fn__1938000406_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ns_name; t.F_ns_name = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_ex; t.F_ex = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O__O(Lit_18, tmp4, jrt.Throwable_Cast(tmp5).GetMessage__String().Ref()) }; return nil }(); var root_3078 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_3079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3078, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3080 lang.IFn; if linked_3079 == nil { ifn_3080 = lang.IFn_Cast(root_3078) } else { ifn_3080 = nil }; if linked_3079 == nil { ifn_3080.Invoke__O() } else { linked_3079.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3078) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }


func A_arbace_go_run__main_fn__1938000415_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000415_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000415_A{}; t.Ctor_O(p0); return t }
//line :445:1
func (t *A_arbace_go_run__main_fn__1938000415_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :445:1
func (t *A_arbace_go_run__main_fn__1938000415_A) Invoke_O__O(self any) any { { var opts__1 any = lang.PersistentArrayMap_EMPTY.Ref(); var as__2 any; var root_2619 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2619, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2621 lang.IFn; if linked_2620 == nil { ifn_2621 = lang.IFn_Cast(root_2619) } else { ifn_2621 = nil }; var arg_2622 any; var t_ any = t.F_args; t.F_args = nil; arg_2622 = t_; if linked_2620 == nil { as__2 = ifn_2621.Invoke_O__O(arg_2622) } else { as__2 = linked_2620.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2619, arg_2622) }; L1: for { var G__1938000416__3_ any; var root_2623 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_2624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2623, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2625 lang.IFn
										if linked_2624 == nil { ifn_2625 = lang.IFn_Cast(root_2623) } else { ifn_2625 = nil }; var arg_2626 any = as__2; if linked_2624 == nil { G__1938000416__3_ = ifn_2625.Invoke_O__O(arg_2626) } else { G__1938000416__3_ = linked_2624.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2623, arg_2626) }; switch lang.Util_Hash_O__I_NoInit(G__1938000416__3_) >> 0 & 31 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_23) {






		var tmp1 any; var root_2628 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = opts__1; var arg_2632 any = A_arbace_go_run_A_const_225; var arg_2633 any; var tmp2 any; var root_2634 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2634, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2636 lang.IFn; if linked_2635 == nil { ifn_2636 = lang.IFn_Cast(root_2634) } else { ifn_2636 = nil }; var arg_2637 any = as__2; if linked_2635 == nil { tmp2 = ifn_2636.Invoke_O__O(arg_2637) } else { tmp2 = linked_2635.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2634, arg_2637) }; arg_2633 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp2))).Ref(); if linked_2629 == nil { tmp1 = ifn_2630.Invoke_O_O_O__O(arg_2631, arg_2632, arg_2633) } else { tmp1 = linked_2629.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2628, arg_2631, arg_2632, arg_2633) }; var tmp3 any = tmp1; var tmp4 any; var root_2638 any = A_arbace_go_run_A_const_226.GetRawRoot__O(); var linked_2639 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2638, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2640 lang.IFn; if linked_2639 == nil { ifn_2640 = lang.IFn_Cast(root_2638) } else { ifn_2640 = nil }; var arg_2642 any = as__2; if linked_2639 == nil { tmp4 = ifn_2640.Invoke_O_O__O(A_arbace_go_run_A_const_135, arg_2642) } else { tmp4 = linked_2639.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2638, 2, A_arbace_go_run_A_const_135, arg_2642) }; opts__1, as__2 = tmp3, tmp4; continue L1 }
//line :446:1
	case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_24) {







		var tmp5 any; var root_2643 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_2644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2643, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2645 lang.IFn; if linked_2644 == nil { ifn_2645 = lang.IFn_Cast(root_2643) } else { ifn_2645 = nil }; var arg_2646 any = opts__1; var arg_2647 any = A_arbace_go_run_A_const_227; var arg_2648 any; var root_2649 any = A_arbace_go_run_A_const_228.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_2651 lang.IFn; if linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any; var root_2653 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = as__2; if linked_2654 == nil { arg_2652 = ifn_2655.Invoke_O__O(arg_2656) } else { arg_2652 = linked_2654.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2653, arg_2656) }; if linked_2650 == nil { arg_2648 = ifn_2651.Invoke_O__O(arg_2652) } else { arg_2648 = linked_2650.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_2649, arg_2652) }; if linked_2644 == nil { tmp5 = ifn_2645.Invoke_O_O_O__O(arg_2646, arg_2647, arg_2648) } else { tmp5 = linked_2644.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2643, arg_2646, arg_2647, arg_2648) }; var tmp6 any = tmp5; var tmp7 any; var root_2657 any = A_arbace_go_run_A_const_226.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2661 any = as__2; if linked_2658 == nil { tmp7 = ifn_2659.Invoke_O_O__O(A_arbace_go_run_A_const_135, arg_2661) } else { tmp7 = linked_2658.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2657, 2, A_arbace_go_run_A_const_135, arg_2661) }; opts__1, as__2 = tmp6, tmp7; continue L1 }
//line :446:1
	case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_25) {


		var tmp8 any; var root_2662 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2662, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = opts__1; var arg_2666 any = A_arbace_go_run_A_const_229; var arg_2667 any = jrt.Boolean_TRUE.Ref(); if linked_2663 == nil { tmp8 = ifn_2664.Invoke_O_O_O__O(arg_2665, arg_2666, arg_2667) } else { tmp8 = linked_2663.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2662, arg_2665, arg_2666, arg_2667) }; var tmp9 any = tmp8; var tmp10 any; var root_2668 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = as__2; if linked_2669 == nil { tmp10 = ifn_2670.Invoke_O__O(arg_2671) } else { tmp10 = linked_2669.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2668, arg_2671) }; opts__1, as__2 = tmp9, tmp10; continue L1 }
//line :446:1
	case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_26) {
		var tmp11 any; var root_2672 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2672, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2674 lang.IFn; if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any = opts__1; var arg_2676 any = A_arbace_go_run_A_const_230; var arg_2677 any; var root_2678 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = as__2; if linked_2679 == nil { arg_2677 = ifn_2680.Invoke_O__O(arg_2681) } else { arg_2677 = linked_2679.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2678, arg_2681) }; if linked_2673 == nil { tmp11 = ifn_2674.Invoke_O_O_O__O(arg_2675, arg_2676, arg_2677) } else { tmp11 = linked_2673.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2672, arg_2675, arg_2676, arg_2677) }; var tmp12 any = tmp11; var tmp13 any; var root_2682 any = A_arbace_go_run_A_const_226.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2682, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2686 any = as__2; if linked_2683 == nil { tmp13 = ifn_2684.Invoke_O_O__O(A_arbace_go_run_A_const_135, arg_2686) } else { tmp13 = linked_2683.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2682, 2, A_arbace_go_run_A_const_135, arg_2686) }; opts__1, as__2 = tmp12, tmp13; continue L1 }
//line :446:1
	case 20: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_27) {

		var tmp14 any; var root_2687 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = opts__1; var arg_2691 any = A_arbace_go_run_A_const_231; var arg_2692 any; var tmp15 any; var root_2693 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2695 lang.IFn; if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = as__2; if linked_2694 == nil { tmp15 = ifn_2695.Invoke_O__O(arg_2696) } else { tmp15 = linked_2694.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2693, arg_2696) }; arg_2692 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp15))).Ref(); if linked_2688 == nil { tmp14 = ifn_2689.Invoke_O_O_O__O(arg_2690, arg_2691, arg_2692) } else { tmp14 = linked_2688.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2687, arg_2690, arg_2691, arg_2692) }; var tmp16 any = tmp14; var tmp17 any; var root_2697 any = A_arbace_go_run_A_const_226.GetRawRoot__O(); var linked_2698 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2697, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2699 lang.IFn; if linked_2698 == nil { ifn_2699 = lang.IFn_Cast(root_2697) } else { ifn_2699 = nil }; var arg_2701 any = as__2; if linked_2698 == nil { tmp17 = ifn_2699.Invoke_O_O__O(A_arbace_go_run_A_const_135, arg_2701) } else { tmp17 = linked_2698.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2697, 2, A_arbace_go_run_A_const_135, arg_2701) }; opts__1, as__2 = tmp16, tmp17; continue L1 }
//line :446:1
	case 22: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_28) {









		var tmp18 any; var root_2702 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any = opts__1; var arg_2706 any = A_arbace_go_run_A_const_232; var arg_2707 any; var root_2708 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2708, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2710 lang.IFn; if linked_2709 == nil { ifn_2710 = lang.IFn_Cast(root_2708) } else { ifn_2710 = nil }; var arg_2711 any = as__2; if linked_2709 == nil { arg_2707 = ifn_2710.Invoke_O__O(arg_2711) } else { arg_2707 = linked_2709.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2708, arg_2711) }; if linked_2703 == nil { tmp18 = ifn_2704.Invoke_O_O_O__O(arg_2705, arg_2706, arg_2707) } else { tmp18 = linked_2703.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2702, arg_2705, arg_2706, arg_2707) }; var tmp19 any = tmp18; var tmp20 any; var root_2712 any = A_arbace_go_run_A_const_226.GetRawRoot__O(); var linked_2713 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2712, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2714 lang.IFn; if linked_2713 == nil { ifn_2714 = lang.IFn_Cast(root_2712) } else { ifn_2714 = nil }; var arg_2716 any = as__2; if linked_2713 == nil { tmp20 = ifn_2714.Invoke_O_O__O(A_arbace_go_run_A_const_135, arg_2716) } else { tmp20 = linked_2713.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2712, 2, A_arbace_go_run_A_const_135, arg_2716) }; opts__1, as__2 = tmp19, tmp20; continue L1 }
//line :446:1
	case 23: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_29) {








		var tmp21 any; var root_2717 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2719 lang.IFn; if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any = opts__1; var arg_2721 any = A_arbace_go_run_A_const_233; var arg_2722 any; var root_2723 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = as__2; if linked_2724 == nil { arg_2722 = ifn_2725.Invoke_O__O(arg_2726) } else { arg_2722 = linked_2724.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2723, arg_2726) }; if linked_2718 == nil { tmp21 = ifn_2719.Invoke_O_O_O__O(arg_2720, arg_2721, arg_2722) } else { tmp21 = linked_2718.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2717, arg_2720, arg_2721, arg_2722) }; var tmp22 any = tmp21; var tmp23 any; var root_2727 any = A_arbace_go_run_A_const_226.GetRawRoot__O(); var linked_2728 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2727, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2729 lang.IFn; if linked_2728 == nil { ifn_2729 = lang.IFn_Cast(root_2727) } else { ifn_2729 = nil }; var arg_2731 any = as__2; if linked_2728 == nil { tmp23 = ifn_2729.Invoke_O_O__O(A_arbace_go_run_A_const_135, arg_2731) } else { tmp23 = linked_2728.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2727, 2, A_arbace_go_run_A_const_135, arg_2731) }; opts__1, as__2 = tmp22, tmp23; continue L1 }
//line :446:1
	case 24: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_30) {



		var tmp24 any; var root_2732 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_2733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2732, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2734 lang.IFn; if linked_2733 == nil { ifn_2734 = lang.IFn_Cast(root_2732) } else { ifn_2734 = nil }; var arg_2735 any = opts__1; var arg_2736 any = A_arbace_go_run_A_const_234; var arg_2737 any; var root_2738 any = A_arbace_go_run_A_const_72.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any = as__2; if linked_2739 == nil { arg_2737 = ifn_2740.Invoke_O__O(arg_2741) } else { arg_2737 = linked_2739.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2738, arg_2741) }; if linked_2733 == nil { tmp24 = ifn_2734.Invoke_O_O_O__O(arg_2735, arg_2736, arg_2737) } else { tmp24 = linked_2733.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2732, arg_2735, arg_2736, arg_2737) }; var tmp25 any = tmp24; var tmp26 any; var root_2742 any = A_arbace_go_run_A_const_226.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2746 any = as__2; if linked_2743 == nil { tmp26 = ifn_2744.Invoke_O_O__O(A_arbace_go_run_A_const_135, arg_2746) } else { tmp26 = linked_2743.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2742, 2, A_arbace_go_run_A_const_135, arg_2746) }; opts__1, as__2 = tmp25, tmp26; continue L1 }
//line :446:1
	case 25: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000416__3_, Lit_31) {











		var tmp27 any; var root_2747 any = A_arbace_go_run_A_const_180.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2747, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_2749 lang.IFn; if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any = opts__1; var arg_2751 any = A_arbace_go_run_A_const_235; var arg_2752 any = jrt.Boolean_TRUE.Ref(); if linked_2748 == nil { tmp27 = ifn_2749.Invoke_O_O_O__O(arg_2750, arg_2751, arg_2752) } else { tmp27 = linked_2748.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_2747, arg_2750, arg_2751, arg_2752) }; var tmp28 any = tmp27; var tmp29 any; var root_2753 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_2754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2753, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2755 lang.IFn; if linked_2754 == nil { ifn_2755 = lang.IFn_Cast(root_2753) } else { ifn_2755 = nil }; var arg_2756 any = as__2; if linked_2754 == nil { tmp29 = ifn_2755.Invoke_O__O(arg_2756) } else { tmp29 = linked_2754.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2753, arg_2756) }; opts__1, as__2 = tmp28, tmp29; continue L1 }
//line :446:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__1, as__2) } }; /*line :445:1*/panic("j2g: unreachable") }


















func A_arbace_go_run__main_fn__1938000418_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run__main_fn__1938000418_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000418_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :464:1
func (t *A_arbace_go_run__main_fn__1938000418_A) Ctor_O_O_O_O(c__lang, c__pf, c__root, c__opts any) { t.F_lang = c__lang; t.F_pf = c__pf; t.F_root = c__root; t.F_opts = c__opts }
//line :464:1
func (t *A_arbace_go_run__main_fn__1938000418_A) Invoke_O__O(self any) any { var tmp1 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_236.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_root; t.F_root = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_pf; t.F_pf = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any; var t__3 any = t.F_lang; t.F_lang = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any = A_arbace_go_run_A_const_231.Invoke_O__O(t.F_opts); var tmp10 any = A_arbace_go_run_A_const_229.Invoke_O__O(t.F_opts); var tmp11 any = A_arbace_go_run_A_const_234.Invoke_O__O(t.F_opts); var tmp12 *lang.Keyword = A_arbace_go_run_A_const_237; var tmp13 any; var t__4 any = t.F_opts; t.F_opts = nil; tmp13 = t__4; tmp1 = tmp2.Invoke_O_O_O_O_O_O_O__O(tmp4, tmp6, tmp8, tmp9, tmp10, tmp11, tmp12.Invoke_O__O(tmp13)) }; return nil }(); if tmp14 != nil { if true { var ex__3 jrt.Throwable_I = tmp14; var d__4 any; var root_2773 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_2774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2773, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2775 lang.IFn

	if linked_2774 == nil { ifn_2775 = lang.IFn_Cast(root_2773) } else { ifn_2775 = nil }; var arg_2776 any = ex__3; if linked_2774 == nil { d__4 = ifn_2775.Invoke_O__O(arg_2776) } else { d__4 = linked_2774.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2773, arg_2776) }
//line :464:1
	var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_222.Invoke_O__O(d__4)


	if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
		if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp15 any; var root_2777 any = A_arbace_go_run_A_const_174.GetRawRoot__O(); var linked_2778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2777, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2779 lang.IFn; if linked_2778 == nil { ifn_2779 = lang.IFn_Cast(root_2777) } else { ifn_2779 = nil }; var arg_2780 any = m__7; var arg_2781 any = Lit_32; if linked_2778 == nil { tmp15 = ifn_2779.Invoke_O_O__O(arg_2780, arg_2781) } else { tmp15 = linked_2778.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2777, arg_2780, arg_2781) }; if jrt.J2g_Truth(tmp15) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
	if jrt.J2g_Truth(u__5) {
		var root_2782 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2782, A_arbace_go_run_fail_A_fn_class); var ifn_2784 lang.IFn; if linked_2783 == nil { ifn_2784 = lang.IFn_Cast(root_2782) } else { ifn_2784 = nil }; var arg_2785 any = A_arbace_go_run_A_const_51; var arg_2786 any = Lit_33; var arg_2787 any = u__5; if linked_2783 == nil { tmp1 = ifn_2784.Invoke_O_O_O__O(arg_2785, arg_2786, arg_2787) } else { tmp1 = linked_2783.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2782, arg_2785, arg_2786, arg_2787) } } else {
			var root_2788 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2788, A_arbace_go_run_fail_A_fn_class); var ifn_2790 lang.IFn; if linked_2789 == nil { ifn_2790 = lang.IFn_Cast(root_2788) } else { ifn_2790 = nil }; var arg_2791 any = A_arbace_go_run_A_const_66; var arg_2792 any = Lit_8; var arg_2793 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil); var tmp17 any; var root_2794 any = A_arbace_go_run_A_const_223.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2794, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_2796 lang.IFn; if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any = ex__3; if linked_2795 == nil { tmp17 = ifn_2796.Invoke_O__O(arg_2797) } else { tmp17 = linked_2795.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2794, arg_2797) }; arg_2793 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp17)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_2789 == nil { tmp1 = ifn_2790.Invoke_O_O_O__O(arg_2791, arg_2792, arg_2793) } else { tmp1 = linked_2789.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2788, arg_2791, arg_2792, arg_2793) } } } }; return tmp1 }


func A_arbace_go_run__main_fn__1938000423_A_New() *A_arbace_go_run__main_fn__1938000423_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000423_A{}; t.Ctor(); return t }
//line :474:1
func (t *A_arbace_go_run__main_fn__1938000423_A) Ctor() {}
//line :474:1
func (t *A_arbace_go_run__main_fn__1938000423_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_go_run_A_const_16.GetRawRoot__O()).Invoke_O__O(Lit_35); return nil }(); var root_3108 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_3109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3108, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3110 lang.IFn; if linked_3109 == nil { ifn_3110 = lang.IFn_Cast(root_3108) } else { ifn_3110 = nil }; if linked_3109 == nil { ifn_3110.Invoke__O() } else { linked_3109.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3108) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_go_run__main_fn__1938000425_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run__main_fn__1938000425_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000425_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :479:1
func (t *A_arbace_go_run__main_fn__1938000425_A) Ctor_O_O_O(c__pargs, c__pf, c__root any) { t.F_pargs = c__pargs; t.F_pf = c__pf; t.F_root = c__root }
//line :479:1
func (t *A_arbace_go_run__main_fn__1938000425_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_2518 any = A_arbace_go_run_A_const_221.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, A_arbace_go_run_run_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any; var t_ any = t.F_root; t.F_root = nil; arg_2521 = t_; var arg_2522 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_2522 = t__2; var arg_2523 any; var t__3 any = t.F_pargs; t.F_pargs = nil; arg_2523 = t__3; if linked_2519 == nil { tmp1 = ifn_2520.Invoke_O_O_O__O(arg_2521, arg_2522, arg_2523) } else { tmp1 = linked_2519.(*A_arbace_go_run_run_A).Invoke_O_O_O_O__O(root_2518, arg_2521, arg_2522, arg_2523) } }
//line :479:1
	return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var d__4 any; var root_2524 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_2525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2524, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2526 lang.IFn


		if linked_2525 == nil { ifn_2526 = lang.IFn_Cast(root_2524) } else { ifn_2526 = nil }; var arg_2527 any = ex__3; if linked_2525 == nil { d__4 = ifn_2526.Invoke_O__O(arg_2527) } else { d__4 = linked_2525.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2524, arg_2527) }
//line :479:1
		var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_222.Invoke_O__O(d__4)



		if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp3 any; var root_2528 any = A_arbace_go_run_A_const_174.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2528, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = m__7; var arg_2532 any = Lit_32; if linked_2529 == nil { tmp3 = ifn_2530.Invoke_O_O__O(arg_2531, arg_2532) } else { tmp3 = linked_2529.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_2528, arg_2531, arg_2532) }; if jrt.J2g_Truth(tmp3) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
		if jrt.J2g_Truth(u__5) {
			var root_2533 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2533, A_arbace_go_run_fail_A_fn_class); var ifn_2535 lang.IFn; if linked_2534 == nil { ifn_2535 = lang.IFn_Cast(root_2533) } else { ifn_2535 = nil }; var arg_2536 any = A_arbace_go_run_A_const_51; var arg_2537 any = Lit_33; var arg_2538 any = u__5; if linked_2534 == nil { tmp1 = ifn_2535.Invoke_O_O_O__O(arg_2536, arg_2537, arg_2538) } else { tmp1 = linked_2534.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2533, arg_2536, arg_2537, arg_2538) } } else {
				var root_2539 any = A_arbace_go_run_A_const_50.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, A_arbace_go_run_fail_A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = A_arbace_go_run_A_const_66; var arg_2543 any = Lit_8; var arg_2544 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil); var tmp5 any; var root_2545 any = A_arbace_go_run_A_const_223.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any = ex__3; if linked_2546 == nil { tmp5 = ifn_2547.Invoke_O__O(arg_2548) } else { tmp5 = linked_2546.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2545, arg_2548) }; arg_2544 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp5)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_2540 == nil { tmp1 = ifn_2541.Invoke_O_O_O__O(arg_2542, arg_2543, arg_2544) } else { tmp1 = linked_2540.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_2539, arg_2542, arg_2543, arg_2544) } } } }; return tmp1 }























































































































































type A_arbace_go_run_A struct{ jrt.Object }

var A_arbace_go_run_A_const_pool *jrt.RefArray

var A_arbace_go_run_A_const_0 *lang.Var

var A_arbace_go_run_A_const_1 any

var A_arbace_go_run_A_const_2 *lang.Var

var A_arbace_go_run_A_const_3 any

var A_arbace_go_run_A_const_4 any

var A_arbace_go_run_A_const_5 any

var A_arbace_go_run_A_const_6 any

var A_arbace_go_run_A_const_7 any

var A_arbace_go_run_A_const_8 any

var A_arbace_go_run_A_const_9 *lang.Var

var A_arbace_go_run_A_const_10 *lang.Var

var A_arbace_go_run_A_const_11 *lang.Var

var A_arbace_go_run_A_const_12 *lang.Var

var A_arbace_go_run_A_const_13 any

var A_arbace_go_run_A_const_14 *lang.Var

var A_arbace_go_run_A_const_15 *lang.Var

var A_arbace_go_run_A_const_16 *lang.Var

var A_arbace_go_run_A_const_17 *lang.Var

var A_arbace_go_run_A_const_18 *lang.Var

var A_arbace_go_run_A_const_19 *lang.Var

var A_arbace_go_run_A_const_20 *lang.Var

var A_arbace_go_run_A_const_21 *lang.Var

var A_arbace_go_run_A_const_22 *lang.Var

var A_arbace_go_run_A_const_23 *lang.Var

var A_arbace_go_run_A_const_24 *lang.Var

var A_arbace_go_run_A_const_25 *lang.Var

var A_arbace_go_run_A_const_26 *lang.Var

var A_arbace_go_run_A_const_27 *lang.Var

var A_arbace_go_run_A_const_28 *lang.Var

var A_arbace_go_run_A_const_29 *lang.Var

var A_arbace_go_run_A_const_30 any

var A_arbace_go_run_A_const_31 *lang.Keyword

var A_arbace_go_run_A_const_32 *lang.Var

var A_arbace_go_run_A_const_33 *lang.Var

var A_arbace_go_run_A_const_34 *lang.Var

var A_arbace_go_run_A_const_35 *lang.Var

var A_arbace_go_run_A_const_36 *lang.Var

var A_arbace_go_run_A_const_37 *lang.Var

var A_arbace_go_run_A_const_38 *lang.Var

var A_arbace_go_run_A_const_39 *lang.Var

var A_arbace_go_run_A_const_40 *lang.Var

var A_arbace_go_run_A_const_41 *lang.Var

var A_arbace_go_run_A_const_42 *lang.Var

var A_arbace_go_run_A_const_43 *lang.Var

var A_arbace_go_run_A_const_44 *lang.Var

var A_arbace_go_run_A_const_45 *lang.Var

var A_arbace_go_run_A_const_46 *lang.Var

var A_arbace_go_run_A_const_47 *lang.Var

var A_arbace_go_run_A_const_48 *lang.Var

var A_arbace_go_run_A_const_49 any

var A_arbace_go_run_A_const_50 *lang.Var

var A_arbace_go_run_A_const_51 any

var A_arbace_go_run_A_const_52 *lang.Keyword

var A_arbace_go_run_A_const_53 *lang.Keyword

var A_arbace_go_run_A_const_54 *lang.Keyword

var A_arbace_go_run_A_const_55 *lang.Var

var A_arbace_go_run_A_const_56 *lang.Var

var A_arbace_go_run_A_const_57 *lang.Keyword

var A_arbace_go_run_A_const_58 *lang.Var

var A_arbace_go_run_A_const_59 *lang.Var

var A_arbace_go_run_A_const_60 *lang.Keyword

var A_arbace_go_run_A_const_61 *lang.Var

var A_arbace_go_run_A_const_62 *lang.Var

var A_arbace_go_run_A_const_63 *lang.Keyword

var A_arbace_go_run_A_const_64 *lang.Keyword

var A_arbace_go_run_A_const_65 *lang.Keyword

var A_arbace_go_run_A_const_66 any

var A_arbace_go_run_A_const_67 *lang.Keyword

var A_arbace_go_run_A_const_68 *lang.Keyword

var A_arbace_go_run_A_const_69 any

var A_arbace_go_run_A_const_70 *lang.Var

var A_arbace_go_run_A_const_71 *lang.Var

var A_arbace_go_run_A_const_72 *lang.Var

var A_arbace_go_run_A_const_73 *lang.Var

var A_arbace_go_run_A_const_74 any

var A_arbace_go_run_A_const_75 *lang.Var

var A_arbace_go_run_A_const_76 *lang.Var

var A_arbace_go_run_A_const_77 *lang.Keyword

var A_arbace_go_run_A_const_78 *lang.Var

var A_arbace_go_run_A_const_79 *lang.Var

var A_arbace_go_run_A_const_80 *lang.Var

var A_arbace_go_run_A_const_81 *lang.Var

var A_arbace_go_run_A_const_82 *lang.Var

var A_arbace_go_run_A_const_83 *lang.Var

var A_arbace_go_run_A_const_84 *lang.Var

var A_arbace_go_run_A_const_85 *lang.Keyword

var A_arbace_go_run_A_const_86 *lang.Keyword

var A_arbace_go_run_A_const_87 *lang.Var

var A_arbace_go_run_A_const_88 *lang.Keyword

var A_arbace_go_run_A_const_89 *lang.Keyword

var A_arbace_go_run_A_const_90 *lang.Keyword

var A_arbace_go_run_A_const_91 *lang.Var

var A_arbace_go_run_A_const_92 *lang.Keyword

var A_arbace_go_run_A_const_93 *lang.Keyword

var A_arbace_go_run_A_const_94 *lang.Keyword

var A_arbace_go_run_A_const_95 *lang.Var

var A_arbace_go_run_A_const_96 any

var A_arbace_go_run_A_const_97 *lang.Keyword

var A_arbace_go_run_A_const_98 *lang.Var

var A_arbace_go_run_A_const_99 *lang.Var

var A_arbace_go_run_A_const_100 *lang.Var

var A_arbace_go_run_A_const_101 *lang.Var

var A_arbace_go_run_A_const_102 *lang.Keyword

var A_arbace_go_run_A_const_103 *lang.Keyword

var A_arbace_go_run_A_const_104 *lang.Var

var A_arbace_go_run_A_const_105 *lang.Var

var A_arbace_go_run_A_const_106 *lang.Var

var A_arbace_go_run_A_const_107 *lang.Var

var A_arbace_go_run_A_const_108 *lang.Var

var A_arbace_go_run_A_const_109 *lang.Var

var A_arbace_go_run_A_const_110 *lang.Var

var A_arbace_go_run_A_const_111 *lang.Var

var A_arbace_go_run_A_const_112 *lang.Var

var A_arbace_go_run_A_const_113 *lang.Var

var A_arbace_go_run_A_const_114 *lang.Keyword

var A_arbace_go_run_A_const_115 *lang.Var

var A_arbace_go_run_A_const_116 *lang.Var

var A_arbace_go_run_A_const_117 *lang.Var

var A_arbace_go_run_A_const_118 *lang.Var

var A_arbace_go_run_A_const_119 *lang.Var

var A_arbace_go_run_A_const_120 *lang.Keyword

var A_arbace_go_run_A_const_121 *lang.Var

var A_arbace_go_run_A_const_122 *lang.Var

var A_arbace_go_run_A_const_123 *lang.Var

var A_arbace_go_run_A_const_124 *lang.Var

var A_arbace_go_run_A_const_125 *lang.Var

var A_arbace_go_run_A_const_126 *lang.Var

var A_arbace_go_run_A_const_127 *lang.Var

var A_arbace_go_run_A_const_128 *lang.Var

var A_arbace_go_run_A_const_129 *lang.Var

var A_arbace_go_run_A_const_130 *lang.Var

var A_arbace_go_run_A_const_131 *lang.Keyword

var A_arbace_go_run_A_const_132 *lang.Var

var A_arbace_go_run_A_const_133 *lang.Var

var A_arbace_go_run_A_const_134 *lang.Var

var A_arbace_go_run_A_const_135 any

var A_arbace_go_run_A_const_136 *lang.Var

var A_arbace_go_run_A_const_137 *lang.Keyword

var A_arbace_go_run_A_const_138 *lang.Keyword

var A_arbace_go_run_A_const_139 any

var A_arbace_go_run_A_const_140 *lang.Keyword

var A_arbace_go_run_A_const_141 *lang.Var

var A_arbace_go_run_A_const_142 *lang.Keyword

var A_arbace_go_run_A_const_143 *lang.Keyword

var A_arbace_go_run_A_const_144 *lang.Var

var A_arbace_go_run_A_const_145 *lang.Keyword

var A_arbace_go_run_A_const_146 *lang.Keyword

var A_arbace_go_run_A_const_147 *lang.Keyword

var A_arbace_go_run_A_const_148 *lang.Var

var A_arbace_go_run_A_const_149 *lang.Var

var A_arbace_go_run_A_const_150 *lang.Var

var A_arbace_go_run_A_const_151 any

var A_arbace_go_run_A_const_152 *lang.Var

var A_arbace_go_run_A_const_153 *lang.Var

var A_arbace_go_run_A_const_154 any

var A_arbace_go_run_A_const_155 any

var A_arbace_go_run_A_const_156 *lang.Var

var A_arbace_go_run_A_const_157 any

var A_arbace_go_run_A_const_158 any

var A_arbace_go_run_A_const_159 *lang.Keyword

var A_arbace_go_run_A_const_160 *lang.Var

var A_arbace_go_run_A_const_161 any

var A_arbace_go_run_A_const_162 *lang.Var

var A_arbace_go_run_A_const_163 any

var A_arbace_go_run_A_const_164 *lang.Var

var A_arbace_go_run_A_const_165 any

var A_arbace_go_run_A_const_166 any

var A_arbace_go_run_A_const_167 *lang.Keyword

var A_arbace_go_run_A_const_168 *lang.Keyword

var A_arbace_go_run_A_const_169 any

var A_arbace_go_run_A_const_170 *lang.Var

var A_arbace_go_run_A_const_171 *lang.Var

var A_arbace_go_run_A_const_172 any

var A_arbace_go_run_A_const_173 any

var A_arbace_go_run_A_const_174 *lang.Var

var A_arbace_go_run_A_const_175 any

var A_arbace_go_run_A_const_176 any

var A_arbace_go_run_A_const_177 *lang.Var

var A_arbace_go_run_A_const_178 any

var A_arbace_go_run_A_const_179 any

var A_arbace_go_run_A_const_180 *lang.Var

var A_arbace_go_run_A_const_181 any

var A_arbace_go_run_A_const_182 *lang.Keyword

var A_arbace_go_run_A_const_183 *lang.Keyword

var A_arbace_go_run_A_const_184 *lang.Keyword

var A_arbace_go_run_A_const_185 any

var A_arbace_go_run_A_const_186 any

var A_arbace_go_run_A_const_187 any

var A_arbace_go_run_A_const_188 any

var A_arbace_go_run_A_const_189 *lang.Var

var A_arbace_go_run_A_const_190 any

var A_arbace_go_run_A_const_191 *lang.Keyword

var A_arbace_go_run_A_const_192 any

var A_arbace_go_run_A_const_193 *lang.Keyword

var A_arbace_go_run_A_const_194 *lang.Var

var A_arbace_go_run_A_const_195 any

var A_arbace_go_run_A_const_196 any

var A_arbace_go_run_A_const_197 any

var A_arbace_go_run_A_const_198 *lang.Var

var A_arbace_go_run_A_const_199 *lang.Var

var A_arbace_go_run_A_const_200 *lang.Var

var A_arbace_go_run_A_const_201 *lang.Keyword

var A_arbace_go_run_A_const_202 any

var A_arbace_go_run_A_const_203 any

var A_arbace_go_run_A_const_204 *lang.Var

var A_arbace_go_run_A_const_205 any

var A_arbace_go_run_A_const_206 *lang.Keyword

var A_arbace_go_run_A_const_207 any

var A_arbace_go_run_A_const_208 *lang.Keyword

var A_arbace_go_run_A_const_209 any

var A_arbace_go_run_A_const_210 *lang.Var

var A_arbace_go_run_A_const_211 any

var A_arbace_go_run_A_const_212 *lang.Keyword

var A_arbace_go_run_A_const_213 any

var A_arbace_go_run_A_const_214 *lang.Keyword

var A_arbace_go_run_A_const_215 any

var A_arbace_go_run_A_const_216 *lang.Var

var A_arbace_go_run_A_const_217 *lang.Var

var A_arbace_go_run_A_const_218 *lang.Keyword

var A_arbace_go_run_A_const_219 *lang.Keyword

var A_arbace_go_run_A_const_220 *lang.Var

var A_arbace_go_run_A_const_221 *lang.Var

var A_arbace_go_run_A_const_222 *lang.Keyword

var A_arbace_go_run_A_const_223 *lang.Var

var A_arbace_go_run_A_const_224 any

var A_arbace_go_run_A_const_225 any

var A_arbace_go_run_A_const_226 *lang.Var

var A_arbace_go_run_A_const_227 any

var A_arbace_go_run_A_const_228 *lang.Var

var A_arbace_go_run_A_const_229 *lang.Keyword

var A_arbace_go_run_A_const_230 *lang.Keyword

var A_arbace_go_run_A_const_231 *lang.Keyword

var A_arbace_go_run_A_const_232 any

var A_arbace_go_run_A_const_233 any

var A_arbace_go_run_A_const_234 *lang.Keyword

var A_arbace_go_run_A_const_235 any

var A_arbace_go_run_A_const_236 *lang.Var

var A_arbace_go_run_A_const_237 *lang.Keyword

var A_arbace_go_run_A_const_238 any

var A_arbace_go_run_A_const_239 any

var A_arbace_go_run_A_const_240 any

var A_arbace_go_run_A_const_241 any

var A_arbace_go_run_A_const_242 any

var A_arbace_go_run_A_const_243 any

var A_arbace_go_run_A_const_244 any

var A_arbace_go_run_A_const_245 any

var A_arbace_go_run_A_const_246 any

var A_arbace_go_run_A_init jrt.ClassInit

func A_arbace_go_run_A_Init() { if !A_arbace_go_run_A_init.Done() { A_arbace_go_run_A_init.Run(A_arbace_go_run_A_clinit) } }

func A_arbace_go_run_A_clinit() { A_arbace_go_run_A_clinit_p0(); A_arbace_go_run_A_clinit_p1(); A_arbace_go_run_A_clinit_p2(); A_arbace_go_run_A_clinit_p3(); A_arbace_go_run_A_clinit_p4(); A_arbace_go_run_A_clinit_p5(); A_arbace_go_run_A_clinit_p6(); A_arbace_go_run_A_clinit_p7(); A_arbace_go_run_A_clinit_p8(); A_arbace_go_run_A_clinit_p9(); A_arbace_go_run_A_clinit_p10(); A_arbace_go_run_A_clinit_p11(); A_arbace_go_run_A_clinit_p12(); A_arbace_go_run_A_clinit_p13(); A_arbace_go_run_A_clinit_p14(); A_arbace_go_run_A_clinit_p15(); A_arbace_go_run_A_clinit_p16(); A_arbace_go_run_A_clinit_p17(); A_arbace_go_run_A_clinit_p18(); A_arbace_go_run_A_clinit_p19() }

func A_arbace_go_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 337); A_arbace_go_run_A_const_0 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[90]); A_arbace_go_run_A_const_1 = A_arbace_go_run_A_const_pool.A[91]; A_arbace_go_run_A_const_2 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[92]); A_arbace_go_run_A_const_3 = A_arbace_go_run_A_const_pool.A[93]; A_arbace_go_run_A_const_4 = A_arbace_go_run_A_const_pool.A[94]; A_arbace_go_run_A_const_5 = A_arbace_go_run_A_const_pool.A[95]; A_arbace_go_run_A_const_6 = A_arbace_go_run_A_const_pool.A[96]; A_arbace_go_run_A_const_7 = A_arbace_go_run_A_const_pool.A[97]; A_arbace_go_run_A_const_8 = A_arbace_go_run_A_const_pool.A[98]; A_arbace_go_run_A_const_9 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[99]); A_arbace_go_run_A_const_10 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[100]); A_arbace_go_run_A_const_11 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[101]); A_arbace_go_run_A_const_12 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[102]) }

func A_arbace_go_run_A_clinit_p1() { A_arbace_go_run_A_const_13 = A_arbace_go_run_A_const_pool.A[103]; A_arbace_go_run_A_const_14 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[104]); A_arbace_go_run_A_const_15 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[105]); A_arbace_go_run_A_const_16 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[106]); A_arbace_go_run_A_const_17 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[107]); A_arbace_go_run_A_const_18 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[108]); A_arbace_go_run_A_const_19 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[109]); A_arbace_go_run_A_const_20 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[110]); A_arbace_go_run_A_const_21 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[111]); A_arbace_go_run_A_const_22 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[112]); A_arbace_go_run_A_const_23 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[113]); A_arbace_go_run_A_const_24 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[114]) }

func A_arbace_go_run_A_clinit_p2() { A_arbace_go_run_A_const_25 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[115]); A_arbace_go_run_A_const_26 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[116]); A_arbace_go_run_A_const_27 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[117]); A_arbace_go_run_A_const_28 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[118]); A_arbace_go_run_A_const_29 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[119]); A_arbace_go_run_A_const_30 = A_arbace_go_run_A_const_pool.A[120]; A_arbace_go_run_A_const_31 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[121]); A_arbace_go_run_A_const_32 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[122]); A_arbace_go_run_A_const_33 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[123]); A_arbace_go_run_A_const_34 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[124]); A_arbace_go_run_A_const_35 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[125]); A_arbace_go_run_A_const_36 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[126]) }

func A_arbace_go_run_A_clinit_p3() { A_arbace_go_run_A_const_37 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[127]); A_arbace_go_run_A_const_38 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[128]); A_arbace_go_run_A_const_39 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[129]); A_arbace_go_run_A_const_40 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[130]); A_arbace_go_run_A_const_41 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[131]); A_arbace_go_run_A_const_42 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[132]); A_arbace_go_run_A_const_43 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[133]); A_arbace_go_run_A_const_44 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[134]); A_arbace_go_run_A_const_45 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[135]); A_arbace_go_run_A_const_46 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[136]); A_arbace_go_run_A_const_47 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[137]); A_arbace_go_run_A_const_48 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[138]) }

func A_arbace_go_run_A_clinit_p4() { A_arbace_go_run_A_const_49 = A_arbace_go_run_A_const_pool.A[139]; A_arbace_go_run_A_const_50 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[140]); A_arbace_go_run_A_const_51 = A_arbace_go_run_A_const_pool.A[141]; A_arbace_go_run_A_const_52 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[142]); A_arbace_go_run_A_const_53 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[143]); A_arbace_go_run_A_const_54 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[144]); A_arbace_go_run_A_const_55 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[145]); A_arbace_go_run_A_const_56 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[146]); A_arbace_go_run_A_const_57 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[147]); A_arbace_go_run_A_const_58 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[148]); A_arbace_go_run_A_const_59 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[149]); A_arbace_go_run_A_const_60 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[150]) }

func A_arbace_go_run_A_clinit_p5() { A_arbace_go_run_A_const_61 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[151]); A_arbace_go_run_A_const_62 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[152]); A_arbace_go_run_A_const_63 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[153]); A_arbace_go_run_A_const_64 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[154]); A_arbace_go_run_A_const_65 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[155]); A_arbace_go_run_A_const_66 = A_arbace_go_run_A_const_pool.A[156]; A_arbace_go_run_A_const_67 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[157]); A_arbace_go_run_A_const_68 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[158]); A_arbace_go_run_A_const_69 = A_arbace_go_run_A_const_pool.A[159]; A_arbace_go_run_A_const_70 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[160]); A_arbace_go_run_A_const_71 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[161]); A_arbace_go_run_A_const_72 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[162]) }

func A_arbace_go_run_A_clinit_p6() { A_arbace_go_run_A_const_73 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[163]); A_arbace_go_run_A_const_74 = A_arbace_go_run_A_const_pool.A[164]; A_arbace_go_run_A_const_75 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[165]); A_arbace_go_run_A_const_76 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[166]); A_arbace_go_run_A_const_77 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[167]); A_arbace_go_run_A_const_78 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[168]); A_arbace_go_run_A_const_79 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[169]); A_arbace_go_run_A_const_80 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[170]); A_arbace_go_run_A_const_81 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[171]); A_arbace_go_run_A_const_82 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[172]); A_arbace_go_run_A_const_83 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[173]); A_arbace_go_run_A_const_84 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[174]) }

func A_arbace_go_run_A_clinit_p7() { A_arbace_go_run_A_const_85 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[175]); A_arbace_go_run_A_const_86 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[176]); A_arbace_go_run_A_const_87 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[177]); A_arbace_go_run_A_const_88 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[178]); A_arbace_go_run_A_const_89 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[179]); A_arbace_go_run_A_const_90 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[180]); A_arbace_go_run_A_const_91 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[181]); A_arbace_go_run_A_const_92 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[182]); A_arbace_go_run_A_const_93 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[183]); A_arbace_go_run_A_const_94 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[184]); A_arbace_go_run_A_const_95 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[185]); A_arbace_go_run_A_const_96 = A_arbace_go_run_A_const_pool.A[186] }

func A_arbace_go_run_A_clinit_p8() { A_arbace_go_run_A_const_97 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[187]); A_arbace_go_run_A_const_98 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[188]); A_arbace_go_run_A_const_99 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[189]); A_arbace_go_run_A_const_100 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[190]); A_arbace_go_run_A_const_101 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[191]); A_arbace_go_run_A_const_102 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[192]); A_arbace_go_run_A_const_103 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[193]); A_arbace_go_run_A_const_104 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[194]); A_arbace_go_run_A_const_105 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[195]); A_arbace_go_run_A_const_106 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[196]); A_arbace_go_run_A_const_107 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[197]); A_arbace_go_run_A_const_108 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[198]) }

func A_arbace_go_run_A_clinit_p9() { A_arbace_go_run_A_const_109 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[199]); A_arbace_go_run_A_const_110 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[200]); A_arbace_go_run_A_const_111 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[201]); A_arbace_go_run_A_const_112 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[202]); A_arbace_go_run_A_const_113 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[203]); A_arbace_go_run_A_const_114 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[204]); A_arbace_go_run_A_const_115 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[205]); A_arbace_go_run_A_const_116 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[206]); A_arbace_go_run_A_const_117 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[207]); A_arbace_go_run_A_const_118 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[208]); A_arbace_go_run_A_const_119 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[209]); A_arbace_go_run_A_const_120 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[210]) }

func A_arbace_go_run_A_clinit_p10() { A_arbace_go_run_A_const_121 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[211]); A_arbace_go_run_A_const_122 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[212]); A_arbace_go_run_A_const_123 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[213]); A_arbace_go_run_A_const_124 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[214]); A_arbace_go_run_A_const_125 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[215]); A_arbace_go_run_A_const_126 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[216]); A_arbace_go_run_A_const_127 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[217]); A_arbace_go_run_A_const_128 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[218]); A_arbace_go_run_A_const_129 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[219]); A_arbace_go_run_A_const_130 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[220]); A_arbace_go_run_A_const_131 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[221]); A_arbace_go_run_A_const_132 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[222]) }

func A_arbace_go_run_A_clinit_p11() { A_arbace_go_run_A_const_133 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[223]); A_arbace_go_run_A_const_134 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[224]); A_arbace_go_run_A_const_135 = A_arbace_go_run_A_const_pool.A[225]; A_arbace_go_run_A_const_136 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[226]); A_arbace_go_run_A_const_137 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[227]); A_arbace_go_run_A_const_138 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[228]); A_arbace_go_run_A_const_139 = A_arbace_go_run_A_const_pool.A[229]; A_arbace_go_run_A_const_140 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[230]); A_arbace_go_run_A_const_141 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[231]); A_arbace_go_run_A_const_142 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[232]); A_arbace_go_run_A_const_143 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[233]); A_arbace_go_run_A_const_144 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[234]) }

func A_arbace_go_run_A_clinit_p12() { A_arbace_go_run_A_const_145 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[235]); A_arbace_go_run_A_const_146 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[236]); A_arbace_go_run_A_const_147 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[237]); A_arbace_go_run_A_const_148 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[238]); A_arbace_go_run_A_const_149 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[239]); A_arbace_go_run_A_const_150 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[240]); A_arbace_go_run_A_const_151 = A_arbace_go_run_A_const_pool.A[241]; A_arbace_go_run_A_const_152 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[242]); A_arbace_go_run_A_const_153 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[243]); A_arbace_go_run_A_const_154 = A_arbace_go_run_A_const_pool.A[244]; A_arbace_go_run_A_const_155 = A_arbace_go_run_A_const_pool.A[245]; A_arbace_go_run_A_const_156 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[246]); A_arbace_go_run_A_const_157 = A_arbace_go_run_A_const_pool.A[247] }

func A_arbace_go_run_A_clinit_p13() { A_arbace_go_run_A_const_158 = A_arbace_go_run_A_const_pool.A[248]; A_arbace_go_run_A_const_159 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[249]); A_arbace_go_run_A_const_160 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[250]); A_arbace_go_run_A_const_161 = A_arbace_go_run_A_const_pool.A[251]; A_arbace_go_run_A_const_162 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[252]); A_arbace_go_run_A_const_163 = A_arbace_go_run_A_const_pool.A[253]; A_arbace_go_run_A_const_164 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[254]); A_arbace_go_run_A_const_165 = A_arbace_go_run_A_const_pool.A[255]; A_arbace_go_run_A_const_166 = A_arbace_go_run_A_const_pool.A[256]; A_arbace_go_run_A_const_167 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[257]); A_arbace_go_run_A_const_168 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[258]); A_arbace_go_run_A_const_169 = A_arbace_go_run_A_const_pool.A[259]; A_arbace_go_run_A_const_170 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[260]) }

func A_arbace_go_run_A_clinit_p14() { A_arbace_go_run_A_const_171 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[261]); A_arbace_go_run_A_const_172 = A_arbace_go_run_A_const_pool.A[262]; A_arbace_go_run_A_const_173 = A_arbace_go_run_A_const_pool.A[263]; A_arbace_go_run_A_const_174 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[264]); A_arbace_go_run_A_const_175 = A_arbace_go_run_A_const_pool.A[265]; A_arbace_go_run_A_const_176 = A_arbace_go_run_A_const_pool.A[266]; A_arbace_go_run_A_const_177 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[267]); A_arbace_go_run_A_const_178 = A_arbace_go_run_A_const_pool.A[268]; A_arbace_go_run_A_const_179 = A_arbace_go_run_A_const_pool.A[269]; A_arbace_go_run_A_const_180 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[270]); A_arbace_go_run_A_const_181 = A_arbace_go_run_A_const_pool.A[271]; A_arbace_go_run_A_const_182 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[272]); A_arbace_go_run_A_const_183 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[273]) }

func A_arbace_go_run_A_clinit_p15() { A_arbace_go_run_A_const_184 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[274]); A_arbace_go_run_A_const_185 = A_arbace_go_run_A_const_pool.A[275]; A_arbace_go_run_A_const_186 = A_arbace_go_run_A_const_pool.A[276]; A_arbace_go_run_A_const_187 = A_arbace_go_run_A_const_pool.A[277]; A_arbace_go_run_A_const_188 = A_arbace_go_run_A_const_pool.A[278]; A_arbace_go_run_A_const_189 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[279]); A_arbace_go_run_A_const_190 = A_arbace_go_run_A_const_pool.A[280]; A_arbace_go_run_A_const_191 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[281]); A_arbace_go_run_A_const_192 = A_arbace_go_run_A_const_pool.A[282]; A_arbace_go_run_A_const_193 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[283]); A_arbace_go_run_A_const_194 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[284]); A_arbace_go_run_A_const_195 = A_arbace_go_run_A_const_pool.A[285]; A_arbace_go_run_A_const_196 = A_arbace_go_run_A_const_pool.A[286]; A_arbace_go_run_A_const_197 = A_arbace_go_run_A_const_pool.A[287] }

func A_arbace_go_run_A_clinit_p16() { A_arbace_go_run_A_const_198 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[288]); A_arbace_go_run_A_const_199 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[289]); A_arbace_go_run_A_const_200 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[290]); A_arbace_go_run_A_const_201 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[291]); A_arbace_go_run_A_const_202 = A_arbace_go_run_A_const_pool.A[292]; A_arbace_go_run_A_const_203 = A_arbace_go_run_A_const_pool.A[293]; A_arbace_go_run_A_const_204 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[294]); A_arbace_go_run_A_const_205 = A_arbace_go_run_A_const_pool.A[295]; A_arbace_go_run_A_const_206 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[296]); A_arbace_go_run_A_const_207 = A_arbace_go_run_A_const_pool.A[297]; A_arbace_go_run_A_const_208 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[298]); A_arbace_go_run_A_const_209 = A_arbace_go_run_A_const_pool.A[299]; A_arbace_go_run_A_const_210 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[300]) }

func A_arbace_go_run_A_clinit_p17() { A_arbace_go_run_A_const_211 = A_arbace_go_run_A_const_pool.A[301]; A_arbace_go_run_A_const_212 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[302]); A_arbace_go_run_A_const_213 = A_arbace_go_run_A_const_pool.A[303]; A_arbace_go_run_A_const_214 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[304]); A_arbace_go_run_A_const_215 = A_arbace_go_run_A_const_pool.A[305]; A_arbace_go_run_A_const_216 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[306]); A_arbace_go_run_A_const_217 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[307]); A_arbace_go_run_A_const_218 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[308]); A_arbace_go_run_A_const_219 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[309]); A_arbace_go_run_A_const_220 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[310]); A_arbace_go_run_A_const_221 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[311]); A_arbace_go_run_A_const_222 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[312]) }

func A_arbace_go_run_A_clinit_p18() { A_arbace_go_run_A_const_223 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[313]); A_arbace_go_run_A_const_224 = A_arbace_go_run_A_const_pool.A[314]; A_arbace_go_run_A_const_225 = A_arbace_go_run_A_const_pool.A[315]; A_arbace_go_run_A_const_226 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[316]); A_arbace_go_run_A_const_227 = A_arbace_go_run_A_const_pool.A[317]; A_arbace_go_run_A_const_228 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[318]); A_arbace_go_run_A_const_229 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[319]); A_arbace_go_run_A_const_230 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[320]); A_arbace_go_run_A_const_231 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[321]); A_arbace_go_run_A_const_232 = A_arbace_go_run_A_const_pool.A[322]; A_arbace_go_run_A_const_233 = A_arbace_go_run_A_const_pool.A[323]; A_arbace_go_run_A_const_234 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[324]); A_arbace_go_run_A_const_235 = A_arbace_go_run_A_const_pool.A[325] }

func A_arbace_go_run_A_clinit_p19() { A_arbace_go_run_A_const_236 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[326]); A_arbace_go_run_A_const_237 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[327]); A_arbace_go_run_A_const_238 = A_arbace_go_run_A_const_pool.A[328]; A_arbace_go_run_A_const_239 = A_arbace_go_run_A_const_pool.A[329]; A_arbace_go_run_A_const_240 = A_arbace_go_run_A_const_pool.A[330]; A_arbace_go_run_A_const_241 = A_arbace_go_run_A_const_pool.A[331]; A_arbace_go_run_A_const_242 = A_arbace_go_run_A_const_pool.A[332]; A_arbace_go_run_A_const_243 = A_arbace_go_run_A_const_pool.A[333]; A_arbace_go_run_A_const_244 = A_arbace_go_run_A_const_pool.A[334]; A_arbace_go_run_A_const_245 = A_arbace_go_run_A_const_pool.A[335]; A_arbace_go_run_A_const_246 = A_arbace_go_run_A_const_pool.A[336] }

func A_arbace_go_run_A_New() *A_arbace_go_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_A) Ctor() {}

func (t *A_arbace_go_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_A_class }

func (t *A_arbace_go_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_A); return ok }

func A_arbace_go_run_A_Cast(x any) *A_arbace_go_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_A_class)) }; return v }



type A_arbace_go_run__main_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000372_A struct{ j2g_header uint64; F_pkgs, F_mode any }

var A_arbace_go_run__main_fn__1938000372_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000389_A struct{ j2g_header uint64; F_ns_name, F_root, F_cache, F_std any }

var A_arbace_go_run__main_fn__1938000389_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000389_fn__1938000390_A struct{ j2g_header uint64; F_src any }

var A_arbace_go_run__main_fn__1938000389_fn__1938000390_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000389_fn__1938000390_fn__1938000391_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000389_fn__1938000394_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_run__main_fn__1938000389_fn__1938000394_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000389_fn__1938000396_A struct{ j2g_header uint64; F_ex, F_ns_name any }

var A_arbace_go_run__main_fn__1938000389_fn__1938000396_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000399_A struct{ j2g_header uint64; F_ns_name, F_root, F_cache, F_std any }

var A_arbace_go_run__main_fn__1938000399_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000399_fn__1938000400_A struct{ j2g_header uint64; F_src any }

var A_arbace_go_run__main_fn__1938000399_fn__1938000400_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000399_fn__1938000400_fn__1938000401_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000399_fn__1938000404_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_run__main_fn__1938000399_fn__1938000404_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000399_fn__1938000406_A struct{ j2g_header uint64; F_ex, F_ns_name any }

var A_arbace_go_run__main_fn__1938000399_fn__1938000406_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000415_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_run__main_fn__1938000415_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000418_A struct{ j2g_header uint64; F_lang, F_pf, F_root, F_opts any }

var A_arbace_go_run__main_fn__1938000418_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000423_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000423_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000425_A struct{ j2g_header uint64; F_pargs, F_pf, F_root any }

var A_arbace_go_run__main_fn__1938000425_A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__fn__1938000065_A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A struct{ j2g_header uint64; F_iter__1938000020, F_s__1938000021 any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A struct{ j2g_header uint64; F_b__1938000023 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_root_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_root_A_fn_class *jrt.Class



type A_arbace_go_run_directives_A struct{ j2g_header uint64 }

var A_arbace_go_run_directives_A_fn_class *jrt.Class



type A_arbace_go_run_directives_fn__1938000161_A struct{ j2g_header uint64 }

var A_arbace_go_run_directives_fn__1938000161_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000292_A struct{ j2g_header uint64; F_src any }

var A_arbace_go_run_errorcheck_fn__1938000292_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000292_fn__1938000293_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000296_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000296_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000298_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000298_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000301_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000301_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000303_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000303_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000346_A struct{ j2g_header uint64; F_gcflags, F_r, F_analyze any }

var A_arbace_go_run_errorcheck_fn__1938000346_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_iter__1938000305__1938000309_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A struct{ j2g_header uint64; F_s__1938000306, F_iter__1938000305 any }

var A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A struct{ j2g_header uint64; F_b__1938000308 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000305__1938000309_fn__1938000310_fn__1938000311_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A struct{ j2g_header uint64; F_vmsg, F_lmap any }

var A_arbace_go_run_errorcheck_iter__1938000325__1938000329_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A struct{ j2g_header uint64; F_s__1938000326, F_iter__1938000325, F_vmsg, F_lmap any }

var A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A struct{ j2g_header uint64; F_b__1938000328, F_vmsg any; F_size__1927001038__auto__ int32; F_lmap, F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000325__1938000329_fn__1938000330_fn__1938000331_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A struct{ j2g_header uint64; F_relocate any }

var A_arbace_go_run_errorcheck_iter__1938000348__1938000352_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A struct{ j2g_header uint64; F_s__1938000349, F_iter__1938000348, F_relocate any }

var A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A struct{ j2g_header uint64; F_b__1938000351, F_relocate any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000348__1938000352_fn__1938000353_fn__1938000354_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_pos__1938000341_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_pos__1938000341_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_relocate__1938000317_A struct{ j2g_header uint64; F_lmap any }

var A_arbace_go_run_errorcheck_relocate__1938000317_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_vmsg__1938000315_A struct{ j2g_header uint64; F_file_lang, F_lang, F_src any }

var A_arbace_go_run_errorcheck_vmsg__1938000315_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000004_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000004_A_New() *A_arbace_go_run_eval1938000004_A { t := &A_arbace_go_run_eval1938000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000004_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000004_A_class }

func (t *A_arbace_go_run_eval1938000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000004_A); return ok }

func A_arbace_go_run_eval1938000004_A_Cast(x any) *A_arbace_go_run_eval1938000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000004_A_class)) }; return v }



type A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000008_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000008_A_New() *A_arbace_go_run_eval1938000008_A { t := &A_arbace_go_run_eval1938000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000008_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000008_A_class }

func (t *A_arbace_go_run_eval1938000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000008_A); return ok }

func A_arbace_go_run_eval1938000008_A_Cast(x any) *A_arbace_go_run_eval1938000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000008_A_class)) }; return v }



type A_arbace_go_run_eval1938000008_fn__1938000009_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_fn_class *jrt.Class



type A_arbace_go_run_fail_A struct{ j2g_header uint64 }

var A_arbace_go_run_fail_A_fn_class *jrt.Class



type A_arbace_go_run_fail_fn__1938000012_A struct{ j2g_header uint64; F_kind, F_msg any }

var A_arbace_go_run_fail_fn__1938000012_A_fn_class *jrt.Class



type A_arbace_go_run_full_forms_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_run_full_forms_QMARK__A_fn_class *jrt.Class



type A_arbace_go_run_full_lines_A struct{ j2g_header uint64 }

var A_arbace_go_run_full_lines_A_fn_class *jrt.Class



type A_arbace_go_run_full_lines_fn__1938000227_A struct{ j2g_header uint64; F_keys any }

var A_arbace_go_run_full_lines_fn__1938000227_A_fn_class *jrt.Class



type A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A struct{ j2g_header uint64; F_keys any }

var A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_A_fn_class *jrt.Class



type A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A struct{ j2g_header uint64 }

var A_arbace_go_run_full_lines_fn__1938000227_fn__1938000228_fn__1938000230_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_A struct{ j2g_header uint64 }

var A_arbace_go_run_imports_of_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A struct{ j2g_header uint64; F_s__1938000069, F_iter__1938000068, F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A struct{ j2g_header uint64; F_s__1938000071, F_li, F_iter__1938000070 any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A struct{ j2g_header uint64; F_b__1938000073, F_li any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_A struct{ j2g_header uint64 }

var A_arbace_go_run_key_lines_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_fn__1938000177_A struct{ j2g_header uint64 }

var A_arbace_go_run_key_lines_fn__1938000177_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_fn__1938000180_A struct{ j2g_header uint64 }

var A_arbace_go_run_key_lines_fn__1938000180_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_fn__1938000197_A struct{ j2g_header uint64; F_fi any }

var A_arbace_go_run_key_lines_fn__1938000197_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A struct{ j2g_header uint64 }

var A_arbace_go_run_key_lines_fn__1938000197_fn__1938000199_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_iter__1938000202__1938000206_A struct{ j2g_header uint64 }

var A_arbace_go_run_key_lines_iter__1938000202__1938000206_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A struct{ j2g_header uint64; F_s__1938000203, F_iter__1938000202 any }

var A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A struct{ j2g_header uint64; F_b__1938000205 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_key_lines_iter__1938000202__1938000206_fn__1938000207_fn__1938000208_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_pk__1938000183_A struct{ j2g_header uint64; F_fi, F_ds, F_used any }

var A_arbace_go_run_key_lines_pk__1938000183_A_fn_class *jrt.Class



type A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A struct{ j2g_header uint64; F_l, F_c any }

var A_arbace_go_run_key_lines_pk__1938000183_fn__1938000191_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_A struct{ j2g_header uint64 }

var A_arbace_go_run_line_map_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000235_A struct{ j2g_header uint64; F_ls any }

var A_arbace_go_run_line_map_fn__1938000235_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A struct{ j2g_header uint64 }

var A_arbace_go_run_line_map_fn__1938000235_fn__1938000259_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A struct{ j2g_header uint64; F_i int64; F_l, F_parse any }

var A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A struct{ j2g_header uint64; F_s__1938000248 any; F_i int64; F_l, F_iter__1938000247, F_parse any }

var A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A struct{ j2g_header uint64; F_b__1938000250 any; F_i int64; F_l, F_parse any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_line_map_fn__1938000235_iter__1938000247__1938000251_fn__1938000252_fn__1938000253_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A struct{ j2g_header uint64; F_prev any }

var A_arbace_go_run_line_map_fn__1938000235_parse__1938000239_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000271_A struct{ j2g_header uint64; F_ds any }

var A_arbace_go_run_line_map_fn__1938000271_A_fn_class *jrt.Class



type A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A struct{ j2g_header uint64; F_line, F_c int64 }

var A_arbace_go_run_line_map_fn__1938000271_fn__1938000273_A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__fn__1938000032_A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class *jrt.Class



type A_arbace_go_run_no_linkname_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_linkname_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__fn__1938000016_A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000124_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000124_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000138_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000138_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000140_A struct{ j2g_header uint64; F_p, F_apos, F_end, F_pk any }

var A_arbace_go_run_raw_lines_fn__1938000140_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A struct{ j2g_header uint64; F_pk any }

var A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A struct{ j2g_header uint64; F_iter__1938000142, F_pk, F_s__1938000143 any }

var A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A struct{ j2g_header uint64; F_b__1938000145, F_pk any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_raw_lines_fn__1938000140_iter__1938000142__1938000146_fn__1938000147_fn__1938000148_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_least__1938000131_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_least__1938000131_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_least__1938000131_fn__1938000133_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_least__1938000131_fn__1938000135_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_walk_meta__1938000118_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_walk_meta__1938000118_A_fn_class *jrt.Class



type A_arbace_go_run_run_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000092_A struct{ j2g_header uint64; F_srcs, F_inits, F_deps any }

var A_arbace_go_run_run_define__1938000092_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000092_fn__1938000093_A struct{ j2g_header uint64; F_src, F_r, F_st any }

var A_arbace_go_run_run_define__1938000092_fn__1938000093_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000092_fn__1938000095_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_define__1938000092_fn__1938000095_A_fn_class *jrt.Class



type A_arbace_go_run_run_extra__1938000090_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_extra__1938000090_A_fn_class *jrt.Class



type A_arbace_go_run_run_fn__1938000088_A struct{ j2g_header uint64; F_pf any }

var A_arbace_go_run_run_fn__1938000088_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000098_A struct{ j2g_header uint64; F_inits, F_deps any }

var A_arbace_go_run_run_init_order__1938000098_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A struct{ j2g_header uint64; F_done, F_deps any }

var A_arbace_go_run_run_init_order__1938000098_fn__1938000099_A_fn_class *jrt.Class



type A_arbace_go_run_run_load_BANG___1938000102_A struct{ j2g_header uint64; F_root, F_extra, F_srcs, F_index, F_define any }

var A_arbace_go_run_run_load_BANG___1938000102_A_fn_class *jrt.Class
