//line aot_arbace_go_run.ae:1
package aot_arbace_go_run

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check_load"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_New() *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_run_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_run_A_const_1); lang.IFn_Cast(A_arbace_go_run_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_go_run_A_const_3, A_arbace_go_run_A_const_4, A_arbace_go_run_A_const_5, A_arbace_go_run_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_47)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_48)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_run_eval1938000008_fn__1938000009_A_New() *A_arbace_go_run_eval1938000008_fn__1938000009_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_eval1938000008_fn__1938000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_run_eval1938000008_fn__1938000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_go_run_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_run_A_const_10.GetRawRoot__O(), A_arbace_go_run_A_const_11) }

















func A_arbace_go_run_fail_A_New() *A_arbace_go_run_fail_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_run_fail_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_run_fail_A) Invoke_O_O_O_O__O(self, status__0, kind__1, msg__2 any) any {
	var root_45 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp2 any = A_arbace_go_run_A_const_20; var arg_48 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_go_run_A_const_21.Get__O()); if linked_46 == nil { ifn_47.Invoke_O__O(arg_48) } else { linked_46.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_45, arg_48) }; var tmp3 any = A_arbace_go_run_fail_fn__1938000012_A_New_O_O(kind__1, msg__2); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_go_run_fail_fn__1938000012_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_go_run_fail_fn__1938000012_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()


	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__0)); return nil }
//line :20:1
func A_arbace_go_run_fail_fn__1938000012_A_New_O_O(p0, p1 any) *A_arbace_go_run_fail_fn__1938000012_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_fail_fn__1938000012_A{}; t.Ctor_O_O(p0, p1); return t }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Ctor_O_O(c__kind, c__msg any) { t.F_kind = c__kind; t.F_msg = c__msg }
//line :20:1
func (t *A_arbace_go_run_fail_fn__1938000012_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_50, nil, Lit_14, nil); var tmp4 any; var t_ any = t.F_kind; t.F_kind = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any; var root_32 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_36 any = A_arbace_go_run_A_const_16.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var root_40 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any; var t__2 any = t.F_msg; t.F_msg = nil; arg_43 = t__2; if linked_41 == nil { arg_39 = ifn_42.Invoke_O__O(arg_43) } else { arg_39 = linked_41.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_40, arg_43) }; if linked_37 == nil { arg_35 = ifn_38.Invoke_O__O(arg_39) } else { arg_35 = linked_37.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_36, arg_39) }; if linked_33 == nil { tmp6 = ifn_34.Invoke_O__O(arg_35) } else { tmp6 = linked_33.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_32, arg_35) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6)).Ref())
											var root_22 any = A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; if linked_23 == nil { tmp1 = ifn_24.Invoke__O() } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_22) } }
//line :20:1
	return nil }(); var root_25 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; if linked_26 == nil { ifn_27.Invoke__O() } else { linked_26.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_25) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_go_run_package_file_QMARK__A_New() *A_arbace_go_run_package_file_QMARK__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_go_run_package_file_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(f__0)).IsFile__Z(); if and__1927000168__auto____2 {
											var and__1927000168__auto____3 any; var root_54 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(); var arg_58 any = Lit_61; if linked_55 == nil { and__1927000168__auto____3 = ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { and__1927000168__auto____3 = linked_55.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_54, arg_57, arg_58) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var r__4 any = jrt.BufferedReader_New_Reader(jrt.FileReader_New_File(jrt.File_Cast(f__0))); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__7 any; var root_59 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_61 lang.IFn

		if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_63 any = A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var tmp2 any = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; arg_66 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_67 any; var root_78 any = A_arbace_go_run_A_const_26.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = r__4; if linked_79 == nil { arg_67 = ifn_80.Invoke_O__O(arg_81) } else { arg_67 = linked_79.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_78, arg_81) }; if linked_64 == nil { arg_62 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { arg_62 = linked_64.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if linked_60 == nil { l__7 = ifn_61.Invoke_O__O(arg_62) } else { l__7 = linked_60.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_59, arg_62) }
		var tmp4 any; var and__1927000168__auto____8 any = l__7; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_82 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = l__7; var arg_86 any = Lit_63; if linked_83 == nil { tmp4 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { tmp4 = linked_83.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_82, arg_85, arg_86) } } else { tmp4 = and__1927000168__auto____8 }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp4)).Ref() }; return nil }()
//line :27:1
		jrt.BufferedReader_Cast(r__4).Close__V()
//line :26:1
		if tmp5 != nil { panic(tmp5) }; return tmp1 } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_go_run_package_file_QMARK__fn__1938000016_A_New() *A_arbace_go_run_package_file_QMARK__fn__1938000016_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_package_file_QMARK__fn__1938000016_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Ctor() {}
//line :28:1
func (t *A_arbace_go_run_package_file_QMARK__fn__1938000016_A) Invoke_O_O__O(self, p1__1938000015_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_68 any = A_arbace_go_run_A_const_24.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = p1__1938000015_SHARP___1; if linked_69 == nil { or__1927000174__auto____2 = ifn_70.Invoke_O__O(arg_71) } else { or__1927000174__auto____2 = linked_69.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_68, arg_71) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_72 any = A_arbace_go_run_A_const_25.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = p1__1938000015_SHARP___1; var arg_76 any = Lit_64; if linked_73 == nil { return ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { return linked_73.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_72, arg_75, arg_76) } } }


func A_arbace_go_run_dir_test_root_A_New() *A_arbace_go_run_dir_test_root_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_root_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Ctor() {}
//line :31:1
func (t *A_arbace_go_run_dir_test_root_A) Invoke_O_O__O(self, pf__0 any) any { { var n__2 any = jrt.NN(jrt.File_Cast(pf__0)).GetName__String().Ref(); var sib__3 any; var tmp1 *jrt.File = jrt.NN(jrt.File_Cast(pf__0)).GetParentFile__File(); var tmp2 any; var root_87 any = A_arbace_go_run_A_const_27.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_89 lang.IFn




	if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = n__2; var arg_91 any = A_arbace_go_run_A_const_28; var arg_92 any = Lit_21; if linked_88 == nil { tmp2 = ifn_89.Invoke_O_O_O__O(arg_90, arg_91, arg_92) } else { tmp2 = linked_88.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_87, arg_90, arg_91, arg_92) }
//line :31:1
	sib__3 = jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2))





	var tmp3 any; var and__1927000168__auto____4 any; var root_93 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = n__2; var arg_97 any = Lit_22; if linked_94 == nil { and__1927000168__auto____4 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { and__1927000168__auto____4 = linked_94.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_93, arg_96, arg_97) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(sib__3)).IsDirectory__Z()).Ref() } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { return sib__3 } else { var d__4 any = jrt.NN(jrt.File_Cast(pf__0)).GetParentFile__File().Ref(); L1: for {


		if lang.Util_Identical_O_O__Z_NoInit(d__4, nil) { return nil } else { var tmp4 any; var root_98 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_100 lang.IFn

			if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = jrt.NN(jrt.File_Cast(d__4)).GetName__String().Ref(); var arg_102 any = Lit_23; if linked_99 == nil { tmp4 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { tmp4 = linked_99.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_98, arg_101, arg_102) }
//line :40:1
			if jrt.J2g_Truth(tmp4) { return d__4 } else { if A_arbace_go_run_A_const_29 != nil {


				d__4 = jrt.NN(jrt.File_Cast(d__4)).GetParentFile__File().Ref(); continue L1 } else {
//line :40:1
					return nil } } } } } }; /*line :31:1*/panic("j2g: unreachable") }













func A_arbace_go_run_dir_test_index_A_New() *A_arbace_go_run_dir_test_index_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Ctor() {}
//line :45:1
func (t *A_arbace_go_run_dir_test_index_A) Invoke_O_O__O(self, pf__0 any) any { var temp__1927000408__auto____2 any; var root_103 any = A_arbace_go_run_A_const_30.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, A_arbace_go_run_dir_test_root_A_fn_class); var ifn_105 lang.IFn; if



	linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = pf__0; if linked_104 == nil { temp__1927000408__auto____2 = ifn_105.Invoke_O__O(arg_106) } else { temp__1927000408__auto____2 = linked_104.(*A_arbace_go_run_dir_test_root_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var root_107 any = A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_109 lang.IFn
		if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_111 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New(); var tmp2 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class
		if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class = fncls__194d; tmp2 = fncls__194d } else { tmp2 = fncls__194 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_195 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = pf__0; var arg_199 any; var root_200 any = A_arbace_go_run_A_const_44.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = d__3; if linked_201 == nil { arg_199 = ifn_202.Invoke_O__O(arg_203) } else { arg_199 = linked_201.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_200, arg_203) }; if linked_196 == nil { tmp4 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { tmp4 = linked_196.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }; arg_111 = tmp3.Invoke_O__O(tmp4)
//line :50:1
		if linked_108 == nil { return ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { return linked_108.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } } else {
//line :49:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }

func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_New() *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Ctor() {}
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A) Invoke_O_O__O(self, s__1938000021__1 any) any { var tmp1 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(self, s__1938000021__1); var tmp2 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class = fncls__193d; tmp2 = fncls__193d } else { tmp2 = fncls__193 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_New_O_O(p0, p1 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Ctor_O_O(c__iter__1938000020, c__s__1938000021 any) { t.F_iter__1938000020 = c__iter__1938000020; t.F_s__1938000021 = c__s__1938000021 }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A) Invoke_O__O(self any) any { { var s__1938000021__1 any; var t_ any = t.F_s__1938000021; t.F_s__1938000021 = nil; s__1938000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_112 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = s__1938000021__1; if linked_113 == nil { temp__1927000414__auto____2 = ifn_114.Invoke_O__O(arg_115) } else { temp__1927000414__auto____2 = linked_113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_116 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = s__1938000021__3; if linked_117 == nil { tmp1 = ifn_118.Invoke_O__O(arg_119) } else { tmp1 = linked_117.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_120 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = s__1938000021__3; if linked_121 == nil { c__1927001037__auto____4 = ifn_122.Invoke_O__O(arg_123) } else { c__1927001037__auto____4 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_120, arg_123) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000023__6 any; var root_124 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_125 == nil { b__1938000023__6 = ifn_126.Invoke_O__O(arg_127) } else { b__1938000023__6 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_124, arg_127) }; var tmp2 any = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(b__1938000023__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_142 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_147 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = b__1938000023__6; if linked_148 == nil { arg_145 = ifn_149.Invoke_O__O(arg_150) } else { arg_145 = linked_148.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_147, arg_150) }; var arg_146 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp5 any; var root_151 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__1938000021__3; if linked_152 == nil { tmp5 = ifn_153.Invoke_O__O(arg_154) } else { tmp5 = linked_152.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_151, arg_154) }; arg_146 = tmp4.Invoke_O__O(tmp5); if linked_143 == nil { return ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { return linked_143.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) } } else { var root_155 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any; var root_160 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = b__1938000023__6; if linked_161 == nil { arg_158 = ifn_162.Invoke_O__O(arg_163) } else { arg_158 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_160, arg_163) }; var arg_159 any; if linked_156 == nil { return ifn_157.Invoke_O_O__O(arg_158, arg_159) } else { return linked_156.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_155, arg_158, arg_159) } } } else { var f__4 any; var root_164 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = s__1938000021__3; if linked_165 == nil { f__4 = ifn_166.Invoke_O__O(arg_167) } else { f__4 = linked_165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_164, arg_167) }; var tmp6 any; var root_168 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_170 lang.IFn
															if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = f__4; if linked_169 == nil { tmp6 = ifn_170.Invoke_O__O(arg_171) } else { tmp6 = linked_169.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_168, arg_171) }
//line :51:1
	if jrt.J2g_Truth(tmp6) { var p__5 any; var root_172 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_174 lang.IFn

		if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = f__4; if linked_173 == nil { p__5 = ifn_174.Invoke_O__O(arg_175) } else { p__5 = linked_173.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_172, arg_175) }
//line :51:1
		if jrt.J2g_Truth(p__5) { var root_176 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = lang.Tuple_Create_O_O__IPersistentVector(p__5, f__4); var arg_180 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1938000020); var tmp8 any; var root_181 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = s__1938000021__3; if linked_182 == nil { tmp8 = ifn_183.Invoke_O__O(arg_184) } else { tmp8 = linked_182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_181, arg_184) }; arg_180 = tmp7.Invoke_O__O(tmp8); if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) } } else { var tmp9 any; var root_185 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = s__1938000021__3; if linked_186 == nil { tmp9 = ifn_187.Invoke_O__O(arg_188) } else { tmp9 = linked_186.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_185, arg_188) }; s__1938000021__1 = tmp9; continue L1 } } else { var tmp10 any; var root_189 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__1938000021__3; if linked_190 == nil { tmp10 = ifn_191.Invoke_O__O(arg_192) } else { tmp10 = linked_190.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_189, arg_192) }; s__1938000021__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :51:1
func A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Ctor_O_I_O(c__b__1938000023 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000023 = c__b__1938000023; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :51:1
func (t *A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A) Invoke_O__O(self any) any { { var i__1938000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000022__1)); var tmp2 any; var root_128 any = A_arbace_go_run_A_const_36.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_go_run_package_file_QMARK__A_fn_class); var ifn_130 lang.IFn
																if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = f__2; if linked_129 == nil { tmp2 = ifn_130.Invoke_O__O(arg_131) } else { tmp2 = linked_129.(*A_arbace_go_run_package_file_QMARK__A).Invoke_O_O__O(root_128, arg_131) }
//line :51:1
	if jrt.J2g_Truth(tmp2) { var p__3 any; var root_132 any = A_arbace_go_run_A_const_37.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A_fn_class); var ifn_134 lang.IFn

		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = f__2; if linked_133 == nil { p__3 = ifn_134.Invoke_O__O(arg_135) } else { p__3 = linked_133.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A).Invoke_O_O__O(root_132, arg_135) }
//line :51:1
		if jrt.J2g_Truth(p__3) { var root_136 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = t.F_b__1938000023; var arg_140 any = lang.Tuple_Create_O_O__IPersistentVector(p__3, f__2); if linked_137 == nil { ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { linked_137.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { i__1938000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_go_run_no_assembly_BANG__A_New() *A_arbace_go_run_no_assembly_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Ctor() {}
//line :58:1
func (t *A_arbace_go_run_no_assembly_BANG__A) Invoke_O_O__O(self, src__0 any) any { var temp__1927000414__auto____2 any; var root_204 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_206 lang.IFn; if
											linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var tmp1 any = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New(); var tmp2 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class = fncls__218d; tmp2 = fncls__218d } else { tmp2 = fncls__218 }; arg_207 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_208 any; var root_219 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = src__0; var arg_223 any = A_arbace_go_run_A_const_47; if linked_220 == nil { arg_208 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { arg_208 = linked_220.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; if linked_205 == nil { temp__1927000414__auto____2 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { temp__1927000414__auto____2 = linked_205.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; var root_224 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_go_run_fail_A_fn_class); var ifn_226 lang.IFn
												if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = A_arbace_go_run_A_const_49; var arg_228 any = Lit_13; var arg_229 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_57, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, s__3, nil)).Ref(); if linked_225 == nil { return ifn_226.Invoke_O_O_O__O(arg_227, arg_228, arg_229) } else { return linked_225.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_224, arg_227, arg_228, arg_229) } } else {
//line :59:1
			return nil } }
//line :59:1
func A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_New() *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Ctor() {}
//line :59:1
func (t *A_arbace_go_run_no_assembly_BANG__fn__1938000032_A) Invoke_O_O__O(self, p1__1938000031_SHARP___1 any) any { var tmp1 any; var root_209 any = A_arbace_go_run_A_const_22.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var root_214 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = p1__1938000031_SHARP___1; if linked_215 == nil { arg_212 = ifn_216.Invoke_O__O(arg_217) } else { arg_212 = linked_215.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_214, arg_217) }; var arg_213 any = Lit_59; if linked_210 == nil { tmp1 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp1 = linked_210.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(tmp1) { return p1__1938000031_SHARP___1 } else { return nil } }


func A_arbace_go_run_no_linkname_BANG__A_New() *A_arbace_go_run_no_linkname_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_no_linkname_BANG__A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Ctor() {}
//line :62:1
func (t *A_arbace_go_run_no_linkname_BANG__A) Invoke_O_O__O(self, src__0 any) any { { var seq_1938000035__2 any; var root_230 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_232 lang.IFn
											if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__0); if linked_231 == nil { seq_1938000035__2 = ifn_232.Invoke_O__O(arg_233) } else { seq_1938000035__2 = linked_231.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_230, arg_233) }
//line :62:1
	var chunk_1938000036__3 any; var count_1938000037__4 int64 = 0; var i_1938000038__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000038__5, count_1938000037__4) { var fi__6 any = lang.Indexed_Cast(chunk_1938000036__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000038__5)); var seq_1938000051__7 any; var root_250 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__6); if linked_251 == nil { seq_1938000051__7 = ifn_252.Invoke_O__O(arg_253) } else { seq_1938000051__7 = linked_251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_250, arg_253) }; var chunk_1938000052__8 any; var count_1938000053__9 int64 = 0; var i_1938000054__10 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000054__10, count_1938000053__9) { var d__11 any = lang.Indexed_Cast(chunk_1938000052__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000054__10)); var seq_1938000059__12 any; var root_270 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any; var root_274 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_276 lang.IFn
			if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_278 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_279 any = d__11; if linked_275 == nil { arg_273 = ifn_276.Invoke_O_O_O__O(arg_277, arg_278, arg_279) } else { arg_273 = linked_275.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_274, arg_277, arg_278, arg_279) }
//line :63:1
			if linked_271 == nil { seq_1938000059__12 = ifn_272.Invoke_O__O(arg_273) } else { seq_1938000059__12 = linked_271.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_270, arg_273) }; var chunk_1938000060__13 any; var count_1938000061__14 int64 = 0; var i_1938000062__15 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000062__15, count_1938000061__14) { var x__16 any = lang.Indexed_Cast(chunk_1938000060__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000062__15)); var tmp1 any; var and__1927000168__auto____17 bool = lang.IObj_InstanceOf(x__16)

				if and__1927000168__auto____17 { var tmp2 *lang.Keyword = A_arbace_go_run_A_const_55; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() }
//line :63:1
				if jrt.J2g_Truth(tmp1) {


					var root_296 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_go_run_fail_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = A_arbace_go_run_A_const_49; var arg_300 any = Lit_13; var tmp3 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_301 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__16)), nil)).Ref(); if linked_297 == nil { ifn_298.Invoke_O_O_O__O(arg_299, arg_300, arg_301) } else { linked_297.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_296, arg_299, arg_300, arg_301) }
//line :63:1
					seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } else { seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000062__15); continue L3 } } else { var temp__1927000414__auto____16 any; var root_280 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = seq_1938000059__12; if linked_281 == nil { temp__1927000414__auto____16 = ifn_282.Invoke_O__O(arg_283) } else { temp__1927000414__auto____16 = linked_281.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_280, arg_283) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1938000059__17 any = temp__1927000414__auto____16; var tmp4 any; var root_284 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = seq_1938000059__17; if linked_285 == nil { tmp4 = ifn_286.Invoke_O__O(arg_287) } else { tmp4 = linked_285.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_284, arg_287) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____18 any; var root_288 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = seq_1938000059__17; if linked_289 == nil { c__1927000678__auto____18 = ifn_290.Invoke_O__O(arg_291) } else { c__1927000678__auto____18 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_288, arg_291) }; var tmp5 any; var root_302 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = seq_1938000059__17; if linked_303 == nil { tmp5 = ifn_304.Invoke_O__O(arg_305) } else { tmp5 = linked_303.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_302, arg_305) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp5, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var x__18 any; var root_292 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1938000059__17; if linked_293 == nil { x__18 = ifn_294.Invoke_O__O(arg_295) } else { x__18 = linked_293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_292, arg_295) }; var tmp6 any; var and__1927000168__auto____19 bool = lang.IObj_InstanceOf(x__18)

						if and__1927000168__auto____19 { var tmp7 *lang.Keyword = A_arbace_go_run_A_const_55; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }
//line :63:1
						if jrt.J2g_Truth(tmp6) {


							var root_306 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, A_arbace_go_run_fail_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = A_arbace_go_run_A_const_49; var arg_310 any = Lit_13; var tmp8 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_311 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18)), nil)).Ref(); if linked_307 == nil { ifn_308.Invoke_O_O_O__O(arg_309, arg_310, arg_311) } else { linked_307.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_306, arg_309, arg_310, arg_311) }
//line :63:1
							var tmp9 any; var root_312 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = seq_1938000059__17; if linked_313 == nil { tmp9 = ifn_314.Invoke_O__O(arg_315) } else { tmp9 = linked_313.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_312, arg_315) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp9, nil, 0, 0; continue L3 } else { var tmp10 any; var root_316 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = seq_1938000059__17; if linked_317 == nil { tmp10 = ifn_318.Invoke_O__O(arg_319) } else { tmp10 = linked_317.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_316, arg_319) }; seq_1938000059__12, chunk_1938000060__13, count_1938000061__14, i_1938000062__15 = tmp10, nil, 0, 0; continue L3 } } } }; break L3 }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000054__10); continue L2 } else { var temp__1927000414__auto____11 any; var root_254 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1938000051__7; if linked_255 == nil { temp__1927000414__auto____11 = ifn_256.Invoke_O__O(arg_257) } else { temp__1927000414__auto____11 = linked_255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1938000051__12 any = temp__1927000414__auto____11; var tmp11 any; var root_258 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1938000051__12; if linked_259 == nil { tmp11 = ifn_260.Invoke_O__O(arg_261) } else { tmp11 = linked_259.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____13 any; var root_262 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = seq_1938000051__12; if linked_263 == nil { c__1927000678__auto____13 = ifn_264.Invoke_O__O(arg_265) } else { c__1927000678__auto____13 = linked_263.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_262, arg_265) }; var tmp12 any; var root_320 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = seq_1938000051__12; if linked_321 == nil { tmp12 = ifn_322.Invoke_O__O(arg_323) } else { tmp12 = linked_321.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_320, arg_323) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp12, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__13 any; var root_266 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = seq_1938000051__12; if linked_267 == nil { d__13 = ifn_268.Invoke_O__O(arg_269) } else { d__13 = linked_267.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_266, arg_269) }; var seq_1938000055__14 any; var root_324 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_328 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_330 lang.IFn
								if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_332 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_333 any = d__13; if linked_329 == nil { arg_327 = ifn_330.Invoke_O_O_O__O(arg_331, arg_332, arg_333) } else { arg_327 = linked_329.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_328, arg_331, arg_332, arg_333) }
//line :63:1
								if linked_325 == nil { seq_1938000055__14 = ifn_326.Invoke_O__O(arg_327) } else { seq_1938000055__14 = linked_325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_324, arg_327) }; var chunk_1938000056__15 any; var count_1938000057__16 int64 = 0; var i_1938000058__17 int64 = 0; L4: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000058__17, count_1938000057__16) { var x__18_2 any = lang.Indexed_Cast(chunk_1938000056__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000058__17)); var tmp13 any; var and__1927000168__auto____19_2 bool = lang.IObj_InstanceOf(x__18_2)

									if and__1927000168__auto____19_2 { var tmp14 *lang.Keyword = A_arbace_go_run_A_const_55; tmp13 = tmp14.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_2).Ref() }
//line :63:1
									if jrt.J2g_Truth(tmp13) {


										var root_350 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_go_run_fail_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = A_arbace_go_run_A_const_49; var arg_354 any = Lit_13; var tmp15 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_355 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp15.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_2)), nil)).Ref(); if linked_351 == nil { ifn_352.Invoke_O_O_O__O(arg_353, arg_354, arg_355) } else { linked_351.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_350, arg_353, arg_354, arg_355) }
//line :63:1
										seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } else { seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000058__17); continue L4 } } else { var temp__1927000414__auto____18 any; var root_334 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = seq_1938000055__14; if linked_335 == nil { temp__1927000414__auto____18 = ifn_336.Invoke_O__O(arg_337) } else { temp__1927000414__auto____18 = linked_335.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000055__19 any = temp__1927000414__auto____18; var tmp16 any; var root_338 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = seq_1938000055__19; if linked_339 == nil { tmp16 = ifn_340.Invoke_O__O(arg_341) } else { tmp16 = linked_339.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____20 any; var root_342 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = seq_1938000055__19; if linked_343 == nil { c__1927000678__auto____20 = ifn_344.Invoke_O__O(arg_345) } else { c__1927000678__auto____20 = linked_343.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_342, arg_345) }; var tmp17 any; var root_356 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = seq_1938000055__19; if linked_357 == nil { tmp17 = ifn_358.Invoke_O__O(arg_359) } else { tmp17 = linked_357.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_356, arg_359) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp17, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var x__20 any; var root_346 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = seq_1938000055__19; if linked_347 == nil { x__20 = ifn_348.Invoke_O__O(arg_349) } else { x__20 = linked_347.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_346, arg_349) }; var tmp18 any; var and__1927000168__auto____21 bool = lang.IObj_InstanceOf(x__20)

											if and__1927000168__auto____21 { var tmp19 *lang.Keyword = A_arbace_go_run_A_const_55; tmp18 = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)) } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21).Ref() }
//line :63:1
											if jrt.J2g_Truth(tmp18) {


												var root_360 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, A_arbace_go_run_fail_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = A_arbace_go_run_A_const_49; var arg_364 any = Lit_13; var tmp20 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_365 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp20.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20)), nil)).Ref(); if linked_361 == nil { ifn_362.Invoke_O_O_O__O(arg_363, arg_364, arg_365) } else { linked_361.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_360, arg_363, arg_364, arg_365) }
//line :63:1
												var tmp21 any; var root_366 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = seq_1938000055__19; if linked_367 == nil { tmp21 = ifn_368.Invoke_O__O(arg_369) } else { tmp21 = linked_367.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_366, arg_369) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp21, nil, 0, 0; continue L4 } else { var tmp22 any; var root_370 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = seq_1938000055__19; if linked_371 == nil { tmp22 = ifn_372.Invoke_O__O(arg_373) } else { tmp22 = linked_371.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_370, arg_373) }; seq_1938000055__14, chunk_1938000056__15, count_1938000057__16, i_1938000058__17 = tmp22, nil, 0, 0; continue L4 } } } }; break L4 }; var tmp23 any; var root_374 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1938000051__12; if linked_375 == nil { tmp23 = ifn_376.Invoke_O__O(arg_377) } else { tmp23 = linked_375.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_374, arg_377) }; seq_1938000051__7, chunk_1938000052__8, count_1938000053__9, i_1938000054__10 = tmp23, nil, 0, 0; continue L2 } } }; break L2 }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000038__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_234 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = seq_1938000035__2; if linked_235 == nil { temp__1927000414__auto____6 = ifn_236.Invoke_O__O(arg_237) } else { temp__1927000414__auto____6 = linked_235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1938000035__7 any = temp__1927000414__auto____6; var tmp24 any; var root_238 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = seq_1938000035__7; if linked_239 == nil { tmp24 = ifn_240.Invoke_O__O(arg_241) } else { tmp24 = linked_239.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____8 any; var root_242 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = seq_1938000035__7; if linked_243 == nil { c__1927000678__auto____8 = ifn_244.Invoke_O__O(arg_245) } else { c__1927000678__auto____8 = linked_243.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_242, arg_245) }; var tmp25 any; var root_378 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = seq_1938000035__7; if linked_379 == nil { tmp25 = ifn_380.Invoke_O__O(arg_381) } else { tmp25 = linked_379.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_378, arg_381) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp25, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var fi__8 any; var root_246 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1938000035__7; if linked_247 == nil { fi__8 = ifn_248.Invoke_O__O(arg_249) } else { fi__8 = linked_247.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_246, arg_249) }; var seq_1938000039__9 any; var root_382 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = A_arbace_go_run_A_const_52.Invoke_O__O(fi__8); if linked_383 == nil { seq_1938000039__9 = ifn_384.Invoke_O__O(arg_385) } else { seq_1938000039__9 = linked_383.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_382, arg_385) }; var chunk_1938000040__10 any; var count_1938000041__11 int64 = 0; var i_1938000042__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000042__12, count_1938000041__11) { var d__13_2 any = lang.Indexed_Cast(chunk_1938000040__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000042__12)); var seq_1938000047__14 any; var root_402 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var root_406 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_408 lang.IFn
													if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_410 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_411 any = d__13_2; if linked_407 == nil { arg_405 = ifn_408.Invoke_O_O_O__O(arg_409, arg_410, arg_411) } else { arg_405 = linked_407.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_406, arg_409, arg_410, arg_411) }
//line :63:1
													if linked_403 == nil { seq_1938000047__14 = ifn_404.Invoke_O__O(arg_405) } else { seq_1938000047__14 = linked_403.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_402, arg_405) }; var chunk_1938000048__15 any; var count_1938000049__16 int64 = 0; var i_1938000050__17 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000050__17, count_1938000049__16) { var x__18_3 any = lang.Indexed_Cast(chunk_1938000048__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000050__17)); var tmp26 any; var and__1927000168__auto____19_3 bool = lang.IObj_InstanceOf(x__18_3)

														if and__1927000168__auto____19_3 { var tmp27 *lang.Keyword = A_arbace_go_run_A_const_55; tmp26 = tmp27.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)) } else { tmp26 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19_3).Ref() }
//line :63:1
														if jrt.J2g_Truth(tmp26) {


															var root_428 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, A_arbace_go_run_fail_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = A_arbace_go_run_A_const_49; var arg_432 any = Lit_13; var tmp28 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_433 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp28.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__18_3)), nil)).Ref(); if linked_429 == nil { ifn_430.Invoke_O_O_O__O(arg_431, arg_432, arg_433) } else { linked_429.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_428, arg_431, arg_432, arg_433) }
//line :63:1
															seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } else { seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000050__17); continue L6 } } else { var temp__1927000414__auto____18_2 any; var root_412 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = seq_1938000047__14; if linked_413 == nil { temp__1927000414__auto____18_2 = ifn_414.Invoke_O__O(arg_415) } else { temp__1927000414__auto____18_2 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(temp__1927000414__auto____18_2) { var seq_1938000047__19 any = temp__1927000414__auto____18_2; var tmp29 any; var root_416 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = seq_1938000047__19; if linked_417 == nil { tmp29 = ifn_418.Invoke_O__O(arg_419) } else { tmp29 = linked_417.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_416, arg_419) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____20_2 any; var root_420 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = seq_1938000047__19; if linked_421 == nil { c__1927000678__auto____20_2 = ifn_422.Invoke_O__O(arg_423) } else { c__1927000678__auto____20_2 = linked_421.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_420, arg_423) }; var tmp30 any; var root_434 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = seq_1938000047__19; if linked_435 == nil { tmp30 = ifn_436.Invoke_O__O(arg_437) } else { tmp30 = linked_435.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_434, arg_437) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp30, c__1927000678__auto____20_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L6 } else { var x__20_2 any; var root_424 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = seq_1938000047__19; if linked_425 == nil { x__20_2 = ifn_426.Invoke_O__O(arg_427) } else { x__20_2 = linked_425.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_424, arg_427) }; var tmp31 any; var and__1927000168__auto____21_2 bool = lang.IObj_InstanceOf(x__20_2)

																if and__1927000168__auto____21_2 { var tmp32 *lang.Keyword = A_arbace_go_run_A_const_55; tmp31 = tmp32.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)) } else { tmp31 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_2).Ref() }
//line :63:1
																if jrt.J2g_Truth(tmp31) {


																	var root_438 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_go_run_fail_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_go_run_A_const_49; var arg_442 any = Lit_13; var tmp33 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_443 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp33.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_2)), nil)).Ref(); if linked_439 == nil { ifn_440.Invoke_O_O_O__O(arg_441, arg_442, arg_443) } else { linked_439.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_438, arg_441, arg_442, arg_443) }
//line :63:1
																	var tmp34 any; var root_444 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = seq_1938000047__19; if linked_445 == nil { tmp34 = ifn_446.Invoke_O__O(arg_447) } else { tmp34 = linked_445.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_444, arg_447) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp34, nil, 0, 0; continue L6 } else { var tmp35 any; var root_448 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = seq_1938000047__19; if linked_449 == nil { tmp35 = ifn_450.Invoke_O__O(arg_451) } else { tmp35 = linked_449.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_448, arg_451) }; seq_1938000047__14, chunk_1938000048__15, count_1938000049__16, i_1938000050__17 = tmp35, nil, 0, 0; continue L6 } } } }; break L6 }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000042__12); continue L5 } else { var temp__1927000414__auto____13 any; var root_386 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = seq_1938000039__9; if linked_387 == nil { temp__1927000414__auto____13 = ifn_388.Invoke_O__O(arg_389) } else { temp__1927000414__auto____13 = linked_387.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1938000039__14 any = temp__1927000414__auto____13; var tmp36 any; var root_390 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = seq_1938000039__14; if linked_391 == nil { tmp36 = ifn_392.Invoke_O__O(arg_393) } else { tmp36 = linked_391.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_390, arg_393) }; if jrt.J2g_Truth(tmp36) { var c__1927000678__auto____15 any; var root_394 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_1938000039__14; if linked_395 == nil { c__1927000678__auto____15 = ifn_396.Invoke_O__O(arg_397) } else { c__1927000678__auto____15 = linked_395.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_394, arg_397) }; var tmp37 any; var root_452 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = seq_1938000039__14; if linked_453 == nil { tmp37 = ifn_454.Invoke_O__O(arg_455) } else { tmp37 = linked_453.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_452, arg_455) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp37, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var d__15 any; var root_398 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_1938000039__14; if linked_399 == nil { d__15 = ifn_400.Invoke_O__O(arg_401) } else { d__15 = linked_399.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_398, arg_401) }; var seq_1938000043__16 any; var root_456 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var root_460 any = A_arbace_go_run_A_const_53.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_462 lang.IFn
																		if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = A_arbace_go_run_A_const_54.GetRawRoot__O(); var arg_464 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var arg_465 any = d__15; if linked_461 == nil { arg_459 = ifn_462.Invoke_O_O_O__O(arg_463, arg_464, arg_465) } else { arg_459 = linked_461.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_460, arg_463, arg_464, arg_465) }
//line :63:1
																		if linked_457 == nil { seq_1938000043__16 = ifn_458.Invoke_O__O(arg_459) } else { seq_1938000043__16 = linked_457.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_456, arg_459) }; var chunk_1938000044__17 any; var count_1938000045__18 int64 = 0; var i_1938000046__19 int64 = 0; L7: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000046__19, count_1938000045__18) { var x__20_3 any = lang.Indexed_Cast(chunk_1938000044__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000046__19)); var tmp38 any; var and__1927000168__auto____21_3 bool = lang.IObj_InstanceOf(x__20_3)

																			if and__1927000168__auto____21_3 { var tmp39 *lang.Keyword = A_arbace_go_run_A_const_55; tmp38 = tmp39.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)) } else { tmp38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____21_3).Ref() }
//line :63:1
																			if jrt.J2g_Truth(tmp38) {


																				var root_482 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, A_arbace_go_run_fail_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = A_arbace_go_run_A_const_49; var arg_486 any = Lit_13; var tmp40 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_487 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp40.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__20_3)), nil)).Ref(); if linked_483 == nil { ifn_484.Invoke_O_O_O__O(arg_485, arg_486, arg_487) } else { linked_483.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_482, arg_485, arg_486, arg_487) }
//line :63:1
																				seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } else { seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000046__19); continue L7 } } else { var temp__1927000414__auto____20 any; var root_466 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = seq_1938000043__16; if linked_467 == nil { temp__1927000414__auto____20 = ifn_468.Invoke_O__O(arg_469) } else { temp__1927000414__auto____20 = linked_467.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_466, arg_469) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1938000043__21 any = temp__1927000414__auto____20; var tmp41 any; var root_470 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = seq_1938000043__21; if linked_471 == nil { tmp41 = ifn_472.Invoke_O__O(arg_473) } else { tmp41 = linked_471.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_470, arg_473) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____22 any; var root_474 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = seq_1938000043__21; if linked_475 == nil { c__1927000678__auto____22 = ifn_476.Invoke_O__O(arg_477) } else { c__1927000678__auto____22 = linked_475.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_474, arg_477) }; var tmp42 any; var root_488 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = seq_1938000043__21; if linked_489 == nil { tmp42 = ifn_490.Invoke_O__O(arg_491) } else { tmp42 = linked_489.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_488, arg_491) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp42, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L7 } else { var x__22 any; var root_478 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = seq_1938000043__21; if linked_479 == nil { x__22 = ifn_480.Invoke_O__O(arg_481) } else { x__22 = linked_479.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_478, arg_481) }; var tmp43 any; var and__1927000168__auto____23 bool = lang.IObj_InstanceOf(x__22)

																					if and__1927000168__auto____23 { var tmp44 *lang.Keyword = A_arbace_go_run_A_const_55; tmp43 = tmp44.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)) } else { tmp43 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____23).Ref() }
//line :63:1
																					if jrt.J2g_Truth(tmp43) {


																						var root_492 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, A_arbace_go_run_fail_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = A_arbace_go_run_A_const_49; var arg_496 any = Lit_13; var tmp45 *lang.Keyword = A_arbace_go_run_A_const_55; var arg_497 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_14, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_50.Invoke_O__O(src__0), nil, tmp45.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__22)), nil)).Ref(); if linked_493 == nil { ifn_494.Invoke_O_O_O__O(arg_495, arg_496, arg_497) } else { linked_493.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_492, arg_495, arg_496, arg_497) }
//line :63:1
																						var tmp46 any; var root_498 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = seq_1938000043__21; if linked_499 == nil { tmp46 = ifn_500.Invoke_O__O(arg_501) } else { tmp46 = linked_499.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_498, arg_501) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp46, nil, 0, 0; continue L7 } else { var tmp47 any; var root_502 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = seq_1938000043__21; if linked_503 == nil { tmp47 = ifn_504.Invoke_O__O(arg_505) } else { tmp47 = linked_503.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_502, arg_505) }; seq_1938000043__16, chunk_1938000044__17, count_1938000045__18, i_1938000046__19 = tmp47, nil, 0, 0; continue L7 } } } }; break L7 }; var tmp48 any; var root_506 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = seq_1938000039__14; if linked_507 == nil { tmp48 = ifn_508.Invoke_O__O(arg_509) } else { tmp48 = linked_507.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_506, arg_509) }; seq_1938000039__9, chunk_1938000040__10, count_1938000041__11, i_1938000042__12 = tmp48, nil, 0, 0; continue L5 } } }; break L5 }; var tmp49 any; var root_510 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = seq_1938000035__7; if linked_511 == nil { tmp49 = ifn_512.Invoke_O__O(arg_513) } else { tmp49 = linked_511.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_510, arg_513) }; seq_1938000035__2, chunk_1938000036__3, count_1938000037__4, i_1938000038__5 = tmp49, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :62:1*/panic("j2g: unreachable") }





func A_arbace_go_run_check_BANG__A_New() *A_arbace_go_run_check_BANG__A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Ctor() {}
//line :68:1
func (t *A_arbace_go_run_check_BANG__A) Invoke_O_O_O__O(self, src__0, extra__1 any) any {
	var root_519 any = A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = src__0; if linked_520 == nil { ifn_521.Invoke_O__O(arg_522) } else { linked_520.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_519, arg_522) }
	var root_523 any = A_arbace_go_run_A_const_60.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_go_run_no_linkname_BANG__A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = src__0; if linked_524 == nil { ifn_525.Invoke_O__O(arg_526) } else { linked_524.(*A_arbace_go_run_no_linkname_BANG__A).Invoke_O_O__O(root_523, arg_526) }
//line :68:1
	var r__3 any; var root_514 any = A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_516 lang.IFn


	if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = src__0; var arg_518 any = extra__1; if linked_515 == nil { r__3 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { r__3 = linked_515.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }
//line :68:1
	var errs__4 any = A_arbace_go_run_A_const_58.Invoke_O__O(r__3); var temp__1927000414__auto____5 any; var root_527 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_529 lang.IFn




	if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var tmp1 any = A_arbace_go_run_check_BANG__fn__1938000065_A_New(); var tmp2 *jrt.Class; var fncls__532 *jrt.Class = A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class; if fncls__532 == nil { var fncls__532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class = fncls__532d; tmp2 = fncls__532d } else { tmp2 = fncls__532 }; arg_530 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_531 any = errs__4; if linked_528 == nil { temp__1927000414__auto____5 = ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { temp__1927000414__auto____5 = linked_528.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var bi__6 any = temp__1927000414__auto____5; var root_533 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_go_run_fail_A_fn_class); var ifn_535 lang.IFn
		if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = A_arbace_go_run_A_const_49; var arg_537 any = Lit_13; var arg_538 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_63.Invoke_O__O(bi__6))).Ref(); if linked_534 == nil { ifn_535.Invoke_O_O_O__O(arg_536, arg_537, arg_538) } else { linked_534.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_533, arg_536, arg_537, arg_538) } }
	var tmp3 any; var root_539 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = errs__4; if linked_540 == nil { tmp3 = ifn_541.Invoke_O__O(arg_542) } else { tmp3 = linked_540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_539, arg_542) }; if jrt.J2g_Truth(tmp3) {
		var root_543 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_go_run_fail_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = A_arbace_go_run_A_const_64; var arg_547 any = Lit_4; var arg_548 any; var tmp4 *jrt.RefArray = jrt.ConstRefArray("[0,8,s7:check: ns2:: ns1::ns2:: n", []*jrt.Class{jrt.String_class}); var tmp5 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__0); var tmp6 *lang.Keyword = A_arbace_go_run_A_const_65; var tmp7 any; var root_549 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = errs__4; if linked_550 == nil { tmp7 = ifn_551.Invoke_O__O(arg_552) } else { tmp7 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Keyword = A_arbace_go_run_A_const_66; var tmp10 any; var root_553 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = errs__4; if linked_554 == nil { tmp10 = ifn_555.Invoke_O__O(arg_556) } else { tmp10 = linked_554.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_553, arg_556) }; var tmp11 any = tmp9.Invoke_O__O(tmp10); var tmp12 *lang.Keyword = A_arbace_go_run_A_const_63; var tmp13 any; var root_557 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = errs__4; if linked_558 == nil { tmp13 = ifn_559.Invoke_O__O(arg_560) } else { tmp13 = linked_558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_557, arg_560) }; arg_548 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp8, nil, tmp11, nil, tmp12.Invoke_O__O(tmp13))).Ref(); if linked_544 == nil { ifn_545.Invoke_O_O_O__O(arg_546, arg_547, arg_548) } else { linked_544.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_543, arg_546, arg_547, arg_548) } }
//line :68:1
	return r__3
}



func A_arbace_go_run_check_BANG__fn__1938000065_A_New() *A_arbace_go_run_check_BANG__fn__1938000065_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_check_BANG__fn__1938000065_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Ctor() {}
//line :73:1
func (t *A_arbace_go_run_check_BANG__fn__1938000065_A) Invoke_O_O__O(self, p1__1938000064_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_61; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000064_SHARP___1)) { return p1__1938000064_SHARP___1 } else { return nil } }





func A_arbace_go_run_imports_of_A_New() *A_arbace_go_run_imports_of_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Ctor() {}
//line :79:1
func (t *A_arbace_go_run_imports_of_A) Invoke_O_O__O(self, src__0 any) any { var li__2 any; var root_561 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_563 lang.IFn; if


	linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = src__0; var arg_565 any = A_arbace_go_run_A_const_67; if linked_562 == nil { li__2 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { li__2 = linked_562.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; var root_566 any =
	A_arbace_go_run_A_const_68.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(li__2); var tmp2 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class; if
	fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class = fncls__688d; tmp2 = fncls__688d } else { tmp2 = fncls__688 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_569 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(A_arbace_go_run_A_const_51.Invoke_O__O(src__0)); if /*line :83:1*/ linked_567 == nil { return ifn_568.Invoke_O__O(arg_569) } else { return linked_567.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_566, arg_569) } }
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_A) Invoke_O_O__O(self, s__1938000069__1 any) any { var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(s__1938000069__1, self, t.F_li); var tmp2 *jrt.Class; var fncls__687 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class; if fncls__687 == nil { var fncls__687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class = fncls__687d; tmp2 = fncls__687d } else { tmp2 = fncls__687 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Ctor_O_O_O(c__s__1938000069, c__iter__1938000068, c__li any) { t.F_s__1938000069 = c__s__1938000069; t.F_iter__1938000068 = c__iter__1938000068; t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A) Invoke_O__O(self any) any { { var s__1938000069__1 any; var t_ any = t.F_s__1938000069; t.F_s__1938000069 = nil; s__1938000069__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_570 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = s__1938000069__1; if linked_571 == nil { temp__1927000414__auto____2 = ifn_572.Invoke_O__O(arg_573) } else { temp__1927000414__auto____2 = linked_571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_570, arg_573) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var fi__4 any; var root_574 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = xs__1927001018__auto____3; if linked_575 == nil { fi__4 = ifn_576.Invoke_O__O(arg_577) } else { fi__4 = linked_575.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_574, arg_577) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(t.F_li); var tmp2 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class = fncls__664d; tmp2 = fncls__664d } else { tmp2 = fncls__664 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_665 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_669 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_671 lang.IFn
														if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = fi__4; var arg_673 any = A_arbace_go_run_A_const_72; if linked_670 == nil { tmp4 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp4 = linked_670.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }
//line :84:1
	arg_668 = tmp3.Invoke_O__O(tmp4); if linked_666 == nil { fs__1927001036__auto____6 = ifn_667.Invoke_O__O(arg_668) } else { fs__1927001036__auto____6 = linked_666.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_665, arg_668) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_674 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = fs__1927001036__auto____6; var arg_678 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1938000068); var tmp6 any; var root_679 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__1938000069__1; if linked_680 == nil { tmp6 = ifn_681.Invoke_O__O(arg_682) } else { tmp6 = linked_680.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_679, arg_682) }; arg_678 = tmp5.Invoke_O__O(tmp6); if linked_675 == nil { return ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { return linked_675.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) } } else { var tmp7 any; var root_683 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = s__1938000069__1; if linked_684 == nil { tmp7 = ifn_685.Invoke_O__O(arg_686) } else { tmp7 = linked_684.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_683, arg_686) }; s__1938000069__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_New_O(p0 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Ctor_O(c__li any) { t.F_li = c__li }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A) Invoke_O_O__O(self, s__1938000071__1 any) any { var tmp1 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(s__1938000071__1, t.F_li, self); var tmp2 *jrt.Class; var fncls__663 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class; if fncls__663 == nil { var fncls__663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class = fncls__663d; tmp2 = fncls__663d } else { tmp2 = fncls__663 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Ctor_O_O_O(c__s__1938000071, c__li, c__iter__1938000070 any) { t.F_s__1938000071 = c__s__1938000071; t.F_li = c__li; t.F_iter__1938000070 = c__iter__1938000070 }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A) Invoke_O__O(self any) any { { var s__1938000071__1 any; var t_ any = t.F_s__1938000071; t.F_s__1938000071 = nil; s__1938000071__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_578 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = s__1938000071__1; if linked_579 == nil { temp__1927000414__auto____2 = ifn_580.Invoke_O__O(arg_581) } else { temp__1927000414__auto____2 = linked_579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000071__3 any = temp__1927000414__auto____2; var tmp1 any; var root_582 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = s__1938000071__3; if linked_583 == nil { tmp1 = ifn_584.Invoke_O__O(arg_585) } else { tmp1 = linked_583.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_582, arg_585) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_586 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = s__1938000071__3; if linked_587 == nil { c__1927001037__auto____4 = ifn_588.Invoke_O__O(arg_589) } else { c__1927001037__auto____4 = linked_587.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_586, arg_589) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000073__6 any; var root_590 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_591 == nil { b__1938000073__6 = ifn_592.Invoke_O__O(arg_593) } else { b__1938000073__6 = linked_591.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_590, arg_593) }; var tmp2 any = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(b__1938000073__6, t.F_li, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__611 *jrt.Class = A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class; if fncls__611 == nil { var fncls__611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class = fncls__611d; tmp3 = fncls__611d } else { tmp3 = fncls__611 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_612 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var root_617 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = b__1938000073__6; if linked_618 == nil { arg_615 = ifn_619.Invoke_O__O(arg_620) } else { arg_615 = linked_618.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_617, arg_620) }; var arg_616 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp5 any; var root_621 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = s__1938000071__3; if linked_622 == nil { tmp5 = ifn_623.Invoke_O__O(arg_624) } else { tmp5 = linked_622.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_621, arg_624) }; arg_616 = tmp4.Invoke_O__O(tmp5); if linked_613 == nil { return ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { return linked_613.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) } } else { var root_625 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var root_630 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = b__1938000073__6; if linked_631 == nil { arg_628 = ifn_632.Invoke_O__O(arg_633) } else { arg_628 = linked_631.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_630, arg_633) }; var arg_629 any; if linked_626 == nil { return ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { return linked_626.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) } } } else { var spec__4 any; var root_634 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = s__1938000071__3; if linked_635 == nil { spec__4 = ifn_636.Invoke_O__O(arg_637) } else { spec__4 = linked_635.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_634, arg_637) }; var p__5 any; var tmp6 any; var root_638 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_640 lang.IFn

	if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = spec__4; if linked_639 == nil { tmp6 = ifn_640.Invoke_O__O(arg_641) } else { tmp6 = linked_639.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_638, arg_641) }; if jrt.J2g_Truth(tmp6) { var root_642 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = spec__4; if linked_643 == nil { p__5 = ifn_644.Invoke_O__O(arg_645) } else { p__5 = linked_643.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_642, arg_645) } } else { p__5 = spec__4 }
//line :84:1
	var tmp7 any; var root_646 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_648 lang.IFn


	if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = p__5; if linked_647 == nil { tmp7 = ifn_648.Invoke_O__O(arg_649) } else { tmp7 = linked_647.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_646, arg_649) }
//line :84:1
	if jrt.J2g_Truth(tmp7) { var root_650 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__5, p__5); var arg_654 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000070); var tmp9 any; var root_655 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = s__1938000071__3; if linked_656 == nil { tmp9 = ifn_657.Invoke_O__O(arg_658) } else { tmp9 = linked_656.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_655, arg_658) }; arg_654 = tmp8.Invoke_O__O(tmp9); if linked_651 == nil { return ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { return linked_651.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) } } else { var tmp10 any; var root_659 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = s__1938000071__3; if linked_660 == nil { tmp10 = ifn_661.Invoke_O__O(arg_662) } else { tmp10 = linked_660.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_659, arg_662) }; s__1938000071__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Ctor_O_O_I_O(c__b__1938000073, c__li any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000073 = c__b__1938000073; t.F_li = c__li; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :84:1
func (t *A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A) Invoke_O__O(self any) any { { var i__1938000072__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000072__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000072__1)); var p__3 any; var tmp2 any; var root_594 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_596 lang.IFn

	if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = spec__2; if linked_595 == nil { tmp2 = ifn_596.Invoke_O__O(arg_597) } else { tmp2 = linked_595.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(tmp2) { var root_598 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = spec__2; if linked_599 == nil { p__3 = ifn_600.Invoke_O__O(arg_601) } else { p__3 = linked_599.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_598, arg_601) } } else { p__3 = spec__2 }
//line :84:1
	var tmp3 any; var root_602 any = A_arbace_go_run_A_const_71.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_604 lang.IFn


	if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = p__3; if linked_603 == nil { tmp3 = ifn_604.Invoke_O__O(arg_605) } else { tmp3 = linked_603.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_602, arg_605) }
//line :84:1
	if jrt.J2g_Truth(tmp3) { var root_606 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = t.F_b__1938000073; var arg_610 any = lang.RT_Get_O_O_O__O_NoInit(t.F_li, p__3, p__3); if linked_607 == nil { ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { linked_607.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) }; i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } else { i__1938000072__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000072__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_run_run_A_New() *A_arbace_go_run_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_go_run_run_A) Ctor() {}
//line :90:1
func (t *A_arbace_go_run_run_A) Invoke_O_O_O_O__O(self, root__0, pf__1, args__2 any) any {




	var root_907 any = A_arbace_go_run_A_const_108.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = A_arbace_go_run_A_const_109.GetRawRoot__O(); var arg_911 any = jrt.Boolean_TRUE.Ref(); if linked_908 == nil { ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { linked_908.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_907, arg_910, arg_911)
	}
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_106.GetRawRoot__O()); var tmp2 any; var root_917 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any; var root_922 any = A_arbace_go_run_A_const_17.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = jrt.NN(jrt.File_Cast(pf__1)).GetName__String().Ref(); if linked_923 == nil { arg_920 = ifn_924.Invoke_O__O(arg_925) } else { arg_920 = linked_923.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_922, arg_925) }; var arg_921 any = args__2; if linked_918 == nil { tmp2 = ifn_919.Invoke_O_O__O(arg_920, arg_921) } else { tmp2 = linked_918.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_917, arg_920, arg_921) }; tmp1.Invoke_O_O__O(Lit_74, lang.RT_Object_array_O__O1_NoInit(tmp2).Ref())
//line :90:1
	var src__4 any; var root_689 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_691 lang.IFn







	if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, root__0)); var arg_693 any; var arg_694 any; var root_696 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_697 == nil { arg_694 = ifn_698.Invoke_O__O(arg_699) } else { arg_694 = linked_697.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_696, arg_699) }; var arg_695 any = pf__1; if linked_690 == nil { src__4 = ifn_691.Invoke_O_O_O_O__O(arg_692, arg_693, arg_694, arg_695) } else { src__4 = linked_690.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_689, arg_692, arg_693, arg_694, arg_695) }
//line :90:1
	var ___5 any; var tmp3 any; var root_700 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_702 lang.IFn; _ = ___5








	if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__4); if linked_701 == nil { tmp3 = ifn_702.Invoke_O__O(arg_703) } else { tmp3 = linked_701.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_700, arg_703) }; if jrt.J2g_Truth(tmp3) { var root_704 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, A_arbace_go_run_fail_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = A_arbace_go_run_A_const_49; var arg_708 any = Lit_13; var arg_709 any = Lit_25; if linked_705 == nil { ___5 = ifn_706.Invoke_O_O_O__O(arg_707, arg_708, arg_709) } else { ___5 = linked_705.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_704, arg_707, arg_708, arg_709) } } else { ___5 = nil }
//line :90:1
	var index__6 any; var tmp4 any = A_arbace_go_run_run_fn__1938000087_A_New_O(pf__1); var tmp5 *jrt.Class
	var fncls__714 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_fn__1938000087_A_fn_class









	if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_go_run_run_fn__1938000087_A_fn_class = fncls__714d; tmp5 = fncls__714d } else { tmp5 = fncls__714 }
//line :90:1
	index__6 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); var srcs__7 any; var root_715 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_717 lang.IFn










	if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_716 == nil { srcs__7 = ifn_717.Invoke_O__O(arg_718) } else { srcs__7 = linked_716.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_715, arg_718) }
//line :90:1
	var inits__8 any; var root_719 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_721 lang.IFn











	if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_720 == nil { inits__8 = ifn_721.Invoke_O__O(arg_722) } else { inits__8 = linked_720.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_719, arg_722) }
//line :90:1
	var deps__9 any; var root_723 any = A_arbace_go_run_A_const_80.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_725 lang.IFn












	if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_724 == nil { deps__9 = ifn_725.Invoke_O__O(arg_726) } else { deps__9 = linked_724.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_723, arg_726) }
//line :90:1
	var extra__10 any; var tmp6 any = A_arbace_go_run_run_extra__1938000089_A_New_O(srcs__7); var tmp7 *jrt.Class
	var fncls__731 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_extra__1938000089_A_fn_class













	if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_go_run_run_extra__1938000089_A_fn_class = fncls__731d; tmp7 = fncls__731d } else { tmp7 = fncls__731 }; extra__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)
//line :90:1
	var define__11 any; var tmp8 any = A_arbace_go_run_run_define__1938000091_A_New_O_O_O(srcs__7, inits__8, deps__9); var tmp9 *jrt.Class
	var fncls__793 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_define__1938000091_A_fn_class














	if fncls__793 == nil { var fncls__793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_go_run_run_define__1938000091_A_fn_class = fncls__793d; tmp9 = fncls__793d } else { tmp9 = fncls__793 }; define__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)
//line :90:1
	var init_order__12 any; var tmp10 any = A_arbace_go_run_run_init_order__1938000095_A_New_O_O(inits__8, deps__9); var tmp11 *jrt.Class
	var fncls__863 /*line :90:1*/*jrt.Class = A_arbace_go_run_run_init_order__1938000095_A_fn_class























	if fncls__863 == nil { var fncls__863d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_go_run_run_init_order__1938000095_A_fn_class = fncls__863d; tmp11 = fncls__863d } else { tmp11 = fncls__863 }; init_order__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)
//line :90:1
	var body_load_BANG___13 *A_arbace_go_run_run_load_BANG___1938000099_A = A_arbace_go_run_run_load_BANG___1938000099_A_New_O_O_O_O_O(root__0, extra__10, srcs__7, index__6, define__11); var load_BANG___13 any; var tmp12 *jrt.Class; var fncls__1022 *jrt.Class = A_arbace_go_run_run_load_BANG___1938000099_A_fn_class; if fncls__1022 == nil { var fncls__1022d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_go_run_run_load_BANG___1938000099_A_fn_class = fncls__1022d; tmp12 = fncls__1022d } else { tmp12 = fncls__1022 }; load_BANG___13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_load_BANG___13), tmp12, nil); var seq_1938000105__14 any; var root_1023 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1025 lang.IFn







































	if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any; var root_1027 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, A_arbace_go_run_imports_of_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = src__4; if linked_1028 == nil { arg_1026 = ifn_1029.Invoke_O__O(arg_1030) } else { arg_1026 = linked_1028.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_1027, arg_1030) }; if linked_1024 == nil { seq_1938000105__14 = ifn_1025.Invoke_O__O(arg_1026) } else { seq_1938000105__14 = linked_1024.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1023, arg_1026) }
//line :90:1
	var chunk_1938000106__15 any; var count_1938000107__16 int64 = 0; var i_1938000108__17 int64 = 0; L1: for {







































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000108__17, count_1938000107__16) { var p__18 any = lang.Indexed_Cast(chunk_1938000106__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000108__17)); lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__18, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, i_1938000108__17 = seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000108__17); continue L1 } else { var temp__1927000414__auto____18 any; var root_1031 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = seq_1938000105__14; if linked_1032 == nil { temp__1927000414__auto____18 = ifn_1033.Invoke_O__O(arg_1034) } else { temp__1927000414__auto____18 = linked_1032.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1031, arg_1034) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1938000105__19 any = temp__1927000414__auto____18; var tmp13 any; var root_1035 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = seq_1938000105__19; if linked_1036 == nil { tmp13 = ifn_1037.Invoke_O__O(arg_1038) } else { tmp13 = linked_1036.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1035, arg_1038) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____20 any; var root_1039 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = seq_1938000105__19; if linked_1040 == nil { c__1927000678__auto____20 = ifn_1041.Invoke_O__O(arg_1042) } else { c__1927000678__auto____20 = linked_1040.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1039, arg_1042) }; var tmp14 any; var root_1047 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = seq_1938000105__19; if linked_1048 == nil { tmp14 = ifn_1049.Invoke_O__O(arg_1050) } else { tmp14 = linked_1048.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1047, arg_1050) }; seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, i_1938000108__17 = tmp14, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__20 any; var root_1043 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = seq_1938000105__19; if linked_1044 == nil { p__20 = ifn_1045.Invoke_O__O(arg_1046) } else { p__20 = linked_1044.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1043, arg_1046) }; lang.IFn_Cast(load_BANG___13).Invoke_O_O__O(p__20, lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_50.Invoke_O__O(src__4)))); var tmp15 any; var root_1051 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = seq_1938000105__19; if linked_1052 == nil { tmp15 = ifn_1053.Invoke_O__O(arg_1054) } else { tmp15 = linked_1052.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1051, arg_1054) }; seq_1938000105__14, chunk_1938000106__15, count_1938000107__16, i_1938000108__17 = tmp15, nil, 0, 0; continue L1 } } }
//line :90:1
		break L1 }; var r__13 any; var root_864 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_go_run_check_BANG__A_fn_class); var ifn_866 lang.IFn








































	if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = src__4; var arg_868 any = extra__10; if linked_865 == nil { r__13 = ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { r__13 = linked_865.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_864, arg_867, arg_868) }
//line :90:1
	var ___14 any; var root_869 any = A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_871 lang.IFn; _ = ___14









































	if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = srcs__7; var arg_873 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var arg_874 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__4); var arg_875 any = src__4; if linked_870 == nil { ___14 = ifn_871.Invoke_O_O_O_O__O(arg_872, arg_873, arg_874, arg_875) } else { ___14 = linked_870.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_869, arg_872, arg_873, arg_874, arg_875) }
//line :90:1
	var map__1938000109__15 any = lang.IFn_Cast(define__11).Invoke_O_O__O(src__4, r__13); var map__1938000109__16 any








































	if lang.ISeq_InstanceOf(map__1938000109__15) { var tmp16 any; var root_876 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = map__1938000109__15; if linked_877 == nil { tmp16 = ifn_878.Invoke_O__O(arg_879) } else { tmp16 = linked_877.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_876, arg_879) }; if jrt.J2g_Truth(tmp16) { var tmp17 any; var root_880 any = A_arbace_go_run_A_const_104.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = map__1938000109__15; if linked_881 == nil { tmp17 = ifn_882.Invoke_O__O(arg_883) } else { tmp17 = linked_881.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_880, arg_883) }; map__1938000109__16 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp17, jrt.Object_class.ArrayClass())).Ref() } else { var tmp18 any; var root_884 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = map__1938000109__15; if linked_885 == nil { tmp18 = ifn_886.Invoke_O__O(arg_887) } else { tmp18 = linked_885.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_884, arg_887) }; if jrt.J2g_Truth(tmp18) { var root_888 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = map__1938000109__15; if linked_889 == nil { map__1938000109__16 = ifn_890.Invoke_O__O(arg_891) } else { map__1938000109__16 = linked_889.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_888, arg_891) } } else { map__1938000109__16 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1938000109__16 = map__1938000109__15 }
//line :90:1
	var main__17 any = lang.RT_Get_O_O__O_NoInit(map__1938000109__16, A_arbace_go_run_A_const_105)











































	if jrt.J2g_Truth(main__17) { } else {
		var root_1055 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, A_arbace_go_run_fail_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = A_arbace_go_run_A_const_64; var arg_1059 any = Lit_4; var arg_1060 any = Lit_80; if linked_1056 == nil { ifn_1057.Invoke_O_O_O__O(arg_1058, arg_1059, arg_1060) } else { linked_1056.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1055, arg_1058, arg_1059, arg_1060) } }
	var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_106.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_107.GetRawRoot__O()); var tmp21 any; var root_903 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = inits__8; if linked_904 == nil { tmp21 = ifn_905.Invoke_O__O(arg_906) } else { tmp21 = linked_904.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_903, arg_906) }; return tmp19.Invoke_O_O_O__O(Lit_81, lang.RT_Object_array_O__O1_NoInit(tmp20.Invoke_O_O__O(tmp21, lang.IFn_Cast(init_order__12).Invoke__O())).Ref(), main__17) }
//line :100:1
func A_arbace_go_run_run_fn__1938000087_A_New_O(p0 any) *A_arbace_go_run_run_fn__1938000087_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_fn__1938000087_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Ctor_O(c__pf any) { t.F_pf = c__pf }
//line :100:1
func (t *A_arbace_go_run_run_fn__1938000087_A) Invoke_O__O(self any) any { var root_710 any = A_arbace_go_run_A_const_78.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_go_run_dir_test_index_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any; var t_ any = t.F_pf; t.F_pf = nil; arg_713 = t_; if linked_711 == nil { return ifn_712.Invoke_O__O(arg_713) } else { return linked_711.(*A_arbace_go_run_dir_test_index_A).Invoke_O_O__O(root_710, arg_713) } }



func A_arbace_go_run_run_extra__1938000089_A_New_O(p0 any) *A_arbace_go_run_run_extra__1938000089_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_extra__1938000089_A{}; t.Ctor_O(p0); return t }
//line :104:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :104:1
func (t *A_arbace_go_run_run_extra__1938000089_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_727 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = t.F_srcs; if linked_728 == nil { tmp1 = ifn_729.Invoke_O__O(arg_730) } else { tmp1 = linked_728.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_727, arg_730) }; return lang.RT_Get_O_O__O_NoInit(tmp1, path__1) }
func A_arbace_go_run_run_define__1938000091_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_run_define__1938000091_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :105:1
func (t *A_arbace_go_run_run_define__1938000091_A) Ctor_O_O_O(c__srcs, c__inits, c__deps any) { t.F_srcs = c__srcs; t.F_inits = c__inits; t.F_deps = c__deps }
//line :105:1
func (t *A_arbace_go_run_run_define__1938000091_A) Invoke_O_O_O__O(self, src__1, r__2 any) any { var st__3 any; var root_732 any = A_arbace_go_run_A_const_79.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_734 lang.IFn; if
												linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any; var tmp1 any = A_arbace_go_run_A_const_50; var tmp2 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var tmp3 any = A_arbace_go_run_A_const_81; var tmp4 any = A_arbace_go_run_A_const_81.Invoke_O__O(src__1); var tmp5 any = A_arbace_go_run_A_const_82; var tmp6 any; var root_736 any = A_arbace_go_run_A_const_83.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_82, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_81.Invoke_O__O(src__1))).Ref(); if linked_737 == nil { tmp6 = ifn_738.Invoke_O__O(arg_739) } else { tmp6 = linked_737.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_736, arg_739) }; var tmp7 any = tmp6; var tmp8 any = A_arbace_go_run_A_const_84; arg_735 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp7, tmp8, A_arbace_go_run_A_const_84.Invoke_O__O(src__1), A_arbace_go_run_A_const_51, lang.PersistentVector_EMPTY.Ref(), A_arbace_go_run_A_const_85, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_86, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_go_run_A_const_87, lang.PersistentArrayMap_EMPTY.Ref())); if linked_733 == nil { st__3 = ifn_734.Invoke_O__O(arg_735) } else { st__3 = linked_733.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_732, arg_735) }; var root_746 any =

	A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = A_arbace_go_run_A_const_91.GetRawRoot__O(); var arg_750 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var arg_751 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_752 any = st__3; if linked_747 == nil { ifn_748.Invoke_O_O_O_O__O(arg_749, arg_750, arg_751, arg_752) } else { linked_747.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_746, arg_749, arg_750, arg_751, arg_752) }; var d__4 any; var root_740 any = /*line :105:1*/A_arbace_go_run_A_const_88.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_742 lang.IFn; if



	linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = st__3; var arg_744 any = r__2; var arg_745 any = A_arbace_go_run_A_const_89; if linked_741 == nil { d__4 = ifn_742.Invoke_O_O_O__O(arg_743, arg_744, arg_745) } else { d__4 = linked_741.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_740, arg_743, arg_744, arg_745) }; var tmp9 /*line :110:1*/*lang.Volatile = lang.Volatile_Cast(t.F_inits); var tmp10 any; var root_753 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = jrt.NN(lang.Volatile_Cast(t.F_inits)).Deref__O(); var arg_757 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_758 any; var root_759 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = A_arbace_go_run_A_const_93.Invoke_O__O(d__4); var arg_763 any = A_arbace_go_run_A_const_94.Invoke_O__O(d__4); if linked_760 == nil { arg_758 = ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { arg_758 = linked_760.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; if linked_754 == nil { tmp10 = ifn_755.Invoke_O_O_O__O(arg_756, arg_757, arg_758) } else { tmp10 = linked_754.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_753, arg_756, arg_757, arg_758) }; jrt.NN(tmp9).Reset_O__O(tmp10); var tmp11 /*line :111:1*/*lang.Volatile = lang.Volatile_Cast(t.F_deps); var tmp12 any; var root_764 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = jrt.NN(lang.Volatile_Cast(t.F_deps)).Deref__O(); var arg_768 any = A_arbace_go_run_A_const_50.Invoke_O__O(src__1); var arg_769 any; var root_770 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var root_774 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var tmp13 any = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O(t.F_srcs); var tmp14 *jrt.Class; var fncls__788 *jrt.Class = A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class; if fncls__788 == nil { var fncls__788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class = fncls__788d; tmp14 = fncls__788d } else { tmp14 = fncls__788 }; arg_777 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_778 any; var root_789 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, A_arbace_go_run_imports_of_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = src__1; if linked_790 == nil { arg_778 = ifn_791.Invoke_O__O(arg_792) } else { arg_778 = linked_790.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_789, arg_792) }; if linked_775 == nil { arg_773 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { arg_773 = linked_775.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) }; if linked_771 == nil { arg_769 = ifn_772.Invoke_O__O(arg_773) } else { arg_769 = linked_771.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_770, arg_773) }; if linked_765 == nil { tmp12 = ifn_766.Invoke_O_O_O__O(arg_767, arg_768, arg_769) } else { tmp12 = linked_765.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_764, arg_767, arg_768, arg_769) }; jrt.NN(tmp11).Reset_O__O(tmp12); return d__4 }
//line :111:1
func A_arbace_go_run_run_define__1938000091_fn__1938000092_A_New_O(p0 any) *A_arbace_go_run_run_define__1938000091_fn__1938000092_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_define__1938000091_fn__1938000092_A{}; t.Ctor_O(p0); return t }
//line :111:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :111:1
func (t *A_arbace_go_run_run_define__1938000091_fn__1938000092_A) Invoke_O_O__O(self, p1__1938000085_SHARP___1 any) any { var root_779 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any; var root_784 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = t.F_srcs; if linked_785 == nil { arg_782 = ifn_786.Invoke_O__O(arg_787) } else { arg_782 = linked_785.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_784, arg_787) }; var arg_783 any = p1__1938000085_SHARP___1; if linked_780 == nil { return ifn_781.Invoke_O_O__O(arg_782, arg_783) } else { return linked_780.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_779, arg_782, arg_783) } }


func A_arbace_go_run_run_init_order__1938000095_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000095_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_go_run_run_init_order__1938000095_A) Ctor_O_O(c__inits, c__deps any) { t.F_inits = c__inits; t.F_deps = c__deps }
//line :114:1
func (t *A_arbace_go_run_run_init_order__1938000095_A) Invoke_O__O(self any) any { { var done__1 any = lang.PersistentVector_EMPTY.Ref(); var left__2 any; var root_794 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_796 lang.IFn
											if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any; var root_798 any = A_arbace_go_run_A_const_99.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any; var root_802 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = t.F_inits; if linked_803 == nil { arg_801 = ifn_804.Invoke_O__O(arg_805) } else { arg_801 = linked_803.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_802, arg_805) }; if linked_799 == nil { arg_797 = ifn_800.Invoke_O__O(arg_801) } else { arg_797 = linked_799.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_798, arg_801) }; if linked_795 == nil { left__2 = ifn_796.Invoke_O__O(arg_797) } else { left__2 = linked_795.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_794, arg_797) }
//line :114:1
L1: for {

	var tmp1 any; var root_806 any = A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = left__2; if linked_807 == nil { tmp1 = ifn_808.Invoke_O__O(arg_809) } else { tmp1 = linked_807.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_806, arg_809) }; if jrt.J2g_Truth(tmp1) { return done__1 } else { var p__3 any; var root_810 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_812 lang.IFn

		if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any; var root_814 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any; var root_818 any = A_arbace_go_run_A_const_96.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var tmp2 any = A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_New_O_O(done__1, t.F_deps); var tmp3 *jrt.Class; var fncls__836 *jrt.Class = A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_fn_class; if fncls__836 == nil { var fncls__836d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_fn_class = fncls__836d; tmp3 = fncls__836d } else { tmp3 = fncls__836 }; arg_821 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_822 any = left__2; if linked_819 == nil { arg_817 = ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { arg_817 = linked_819.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) }; if linked_815 == nil { arg_813 = ifn_816.Invoke_O__O(arg_817) } else { arg_813 = linked_815.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_814, arg_817) }; if linked_811 == nil { p__3 = ifn_812.Invoke_O__O(arg_813) } else { p__3 = linked_811.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_810, arg_813) }
		var tmp4 any; var root_837 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = done__1; var arg_841 any; var or__1927000174__auto____4 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_841 = or__1927000174__auto____4 } else { var root_842 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var root_846 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = left__2; if linked_847 == nil { arg_845 = ifn_848.Invoke_O__O(arg_849) } else { arg_845 = linked_847.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_846, arg_849) }; if linked_843 == nil { arg_841 = ifn_844.Invoke_O__O(arg_845) } else { arg_841 = linked_843.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_842, arg_845) } }; if linked_838 == nil { tmp4 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { tmp4 = linked_838.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) }; var tmp5 any = tmp4; var tmp6 any; var root_850 any = A_arbace_go_run_A_const_102.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = left__2; var arg_854 any; var or__1927000174__auto____4_2 any = p__3; if jrt.J2g_Truth(or__1927000174__auto____4_2) { arg_854 = or__1927000174__auto____4_2 } else { var root_855 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any; var root_859 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = left__2; if linked_860 == nil { arg_858 = ifn_861.Invoke_O__O(arg_862) } else { arg_858 = linked_860.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_859, arg_862) }; if linked_856 == nil { arg_854 = ifn_857.Invoke_O__O(arg_858) } else { arg_854 = linked_856.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_855, arg_858) } }; if linked_851 == nil { tmp6 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { tmp6 = linked_851.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; done__1, left__2 = tmp5, tmp6; continue L1 } } }; /*line :114:1*/panic("j2g: unreachable") }



func A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_New_O_O(p0, p1 any) *A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A{}; t.Ctor_O_O(p0, p1); return t }
//line :118:1
func (t *A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A) Ctor_O_O(c__done, c__deps any) { t.F_done = c__done; t.F_deps = c__deps }
//line :118:1
func (t *A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A) Invoke_O_O__O(self, p1__1938000086_SHARP___1 any) any { var root_823 any = A_arbace_go_run_A_const_101.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; var root_828 any = A_arbace_go_run_A_const_95.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = t.F_done; if linked_829 == nil { arg_826 = ifn_830.Invoke_O__O(arg_831) } else { arg_826 = linked_829.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_828, arg_831) }; var arg_827 any; var tmp1 any; var root_832 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = t.F_deps; if linked_833 == nil { tmp1 = ifn_834.Invoke_O__O(arg_835) } else { tmp1 = linked_833.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_832, arg_835) }; arg_827 = lang.RT_Get_O_O__O_NoInit(tmp1, p1__1938000086_SHARP___1); if linked_824 == nil { return ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { return linked_824.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_823, arg_826, arg_827) } }


func A_arbace_go_run_run_load_BANG___1938000099_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_go_run_run_load_BANG___1938000099_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_run_load_BANG___1938000099_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :121:1
func (t *A_arbace_go_run_run_load_BANG___1938000099_A) Ctor_O_O_O_O_O(c__root, c__extra, c__srcs, c__index, c__define any) { t.F_root = c__root; t.F_extra = c__extra; t.F_srcs = c__srcs; t.F_index = c__index; t.F_define = c__define }
//line :121:1
func (t *A_arbace_go_run_run_load_BANG___1938000099_A) Invoke_O_O_O__O(self, path__1, seen__2 any) any {
	var tmp1 any; var or__1927000174__auto____3 any; var root_926 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any; var root_931 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = t.F_srcs; if linked_932 == nil { arg_929 = ifn_933.Invoke_O__O(arg_934) } else { arg_929 = linked_932.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_931, arg_934) }; var arg_930 any = path__1; if linked_927 == nil { or__1927000174__auto____3 = ifn_928.Invoke_O_O__O(arg_929, arg_930) } else { or__1927000174__auto____3 = linked_927.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_926, arg_929, arg_930) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_935 any = A_arbace_go_run_A_const_110.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = path__1; if linked_936 == nil { or__1927000174__auto____4 = ifn_937.Invoke_O__O(arg_938) } else { or__1927000174__auto____4 = linked_936.(*aot_arbace_go_repl.A_arbace_go_repl_listed_QMARK__A).Invoke_O_O__O(root_935, arg_938) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_939 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = seen__2; var arg_943 any = path__1; if linked_940 == nil { tmp1 = ifn_941.Invoke_O_O__O(arg_942, arg_943) } else { tmp1 = linked_940.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_939, arg_942, arg_943) } } }; if jrt.J2g_Truth(tmp1) { return nil } else { var temp__1927000414__auto____3 any; var tmp2 any; var root_944 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_946 lang.IFn
		if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = t.F_index; if linked_945 == nil { tmp2 = ifn_946.Invoke_O__O(arg_947) } else { tmp2 = linked_945.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_944, arg_947) }; temp__1927000414__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, path__1); if jrt.J2g_Truth(temp__1927000414__auto____3) { var f__4 any = temp__1927000414__auto____3; var s__5 any; var root_948 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_950 lang.IFn
			if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, t.F_root)); var arg_952 any = path__1; var arg_953 any; var root_955 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_956 == nil { arg_953 = ifn_957.Invoke_O__O(arg_958) } else { arg_953 = linked_956.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_955, arg_958) }; var arg_954 any = f__4; if linked_949 == nil { s__5 = ifn_950.Invoke_O_O_O_O__O(arg_951, arg_952, arg_953, arg_954) } else { s__5 = linked_949.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_948, arg_951, arg_952, arg_953, arg_954) }
//line :123:1
			var seq_1938000100__6 any; var root_973 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_975 lang.IFn

			if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any; var root_977 any = A_arbace_go_run_A_const_98.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, A_arbace_go_run_imports_of_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = s__5; if linked_978 == nil { arg_976 = ifn_979.Invoke_O__O(arg_980) } else { arg_976 = linked_978.(*A_arbace_go_run_imports_of_A).Invoke_O_O__O(root_977, arg_980) }; if linked_974 == nil { seq_1938000100__6 = ifn_975.Invoke_O__O(arg_976) } else { seq_1938000100__6 = linked_974.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_973, arg_976) }
//line :123:1
			var chunk_1938000101__7 any; var count_1938000102__8 int64 = 0; var i_1938000103__9 int64 = 0; L1: for {

				if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000103__9, count_1938000102__8) { var p__10 any = lang.Indexed_Cast(chunk_1938000101__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000103__9)); var tmp3 lang.IFn = lang.IFn_Cast(self); var tmp4 any; var root_997 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = seen__2; var arg_1001 any = path__1; if linked_998 == nil { tmp4 = ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { tmp4 = linked_998.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) }; tmp3.Invoke_O_O__O(p__10, tmp4); seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, i_1938000103__9 = seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000103__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_981 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = seq_1938000100__6; if linked_982 == nil { temp__1927000414__auto____10 = ifn_983.Invoke_O__O(arg_984) } else { temp__1927000414__auto____10 = linked_982.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_981, arg_984) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1938000100__11 any = temp__1927000414__auto____10; var tmp5 any; var root_985 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = seq_1938000100__11; if linked_986 == nil { tmp5 = ifn_987.Invoke_O__O(arg_988) } else { tmp5 = linked_986.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_985, arg_988) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_989 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = seq_1938000100__11; if linked_990 == nil { c__1927000678__auto____12 = ifn_991.Invoke_O__O(arg_992) } else { c__1927000678__auto____12 = linked_990.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_989, arg_992) }; var tmp6 any; var root_1002 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = seq_1938000100__11; if linked_1003 == nil { tmp6 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp6 = linked_1003.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1002, arg_1005) }; seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, i_1938000103__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__12 any; var root_993 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = seq_1938000100__11; if linked_994 == nil { p__12 = ifn_995.Invoke_O__O(arg_996) } else { p__12 = linked_994.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_993, arg_996) }; var tmp7 lang.IFn = lang.IFn_Cast(self); var tmp8 any; var root_1006 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = seen__2; var arg_1010 any = path__1; if linked_1007 == nil { tmp8 = ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { tmp8 = linked_1007.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) }; tmp7.Invoke_O_O__O(p__12, tmp8); var tmp9 any; var root_1011 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = seq_1938000100__11; if linked_1012 == nil { tmp9 = ifn_1013.Invoke_O__O(arg_1014) } else { tmp9 = linked_1012.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1011, arg_1014) }; seq_1938000100__6, chunk_1938000101__7, count_1938000102__8, i_1938000103__9 = tmp9, nil, 0, 0; continue L1 } } }
//line :123:1
				break L1
			}

			var tmp10 any; var root_959 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any; var root_964 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = t.F_srcs; if linked_965 == nil { arg_962 = ifn_966.Invoke_O__O(arg_967) } else { arg_962 = linked_965.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_964, arg_967) }; var arg_963 any = path__1; if linked_960 == nil { tmp10 = ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { tmp10 = linked_960.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_959, arg_962, arg_963) }; if jrt.J2g_Truth(tmp10) { return nil } else { var r__6 any; var root_968 any = A_arbace_go_run_A_const_103.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, A_arbace_go_run_check_BANG__A_fn_class); var ifn_970 lang.IFn
				if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = s__5; var arg_972 any = t.F_extra; if linked_969 == nil { r__6 = ifn_970.Invoke_O_O__O(arg_971, arg_972) } else { r__6 = linked_969.(*A_arbace_go_run_check_BANG__A).Invoke_O_O_O__O(root_968, arg_971, arg_972) }
				var root_1015 any = A_arbace_go_run_A_const_90.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = t.F_srcs; var arg_1019 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var arg_1020 any = path__1; var arg_1021 any = s__5; if linked_1016 == nil { ifn_1017.Invoke_O_O_O_O__O(arg_1018, arg_1019, arg_1020, arg_1021) } else { linked_1016.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1015, arg_1018, arg_1019, arg_1020, arg_1021) }
				return lang.IFn_Cast(t.F_define).Invoke_O_O__O(s__5, r__6) } } else {
//line :123:1
					return nil
				}
	}
}











func A_arbace_go_run_raw_lines_A_New() *A_arbace_go_run_raw_lines_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_go_run_raw_lines_A) Ctor() {}
//line :138:1
func (t *A_arbace_go_run_raw_lines_A) Invoke_O_O__O(self, x__0 any) any { var walk_meta__2 any; var tmp1 any = A_arbace_go_run_raw_lines_walk_meta__1938000114_A_New(); var tmp2 *jrt.Class; var fncls__1072 *jrt.Class = A_arbace_go_run_raw_lines_walk_meta__1938000114_A_fn_class; if






	fncls__1072 == nil { var fncls__1072d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_go_run_raw_lines_walk_meta__1938000114_A_fn_class = fncls__1072d; tmp2 = fncls__1072d } else { tmp2 = fncls__1072 }; walk_meta__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var x_SINGLEQUOTE___3 any; var tmp3 any; var root_1073 any = /*line :138:1*/A_arbace_go_run_A_const_114.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1075 lang.IFn; if








	linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = x__0; if linked_1074 == nil { tmp3 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp3 = linked_1074.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1073, arg_1076) }; if /*line :146:1*/ jrt.J2g_Truth(tmp3) {
		var root_1077 any = A_arbace_go_run_A_const_115.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any; var root_1082 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = A_arbace_go_run_A_const_117.GetRawRoot__O(); var arg_1086 any; var root_1087 any = A_arbace_go_run_A_const_118.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var arg_1091 any = x__0; if linked_1088 == nil { arg_1086 = ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { arg_1086 = linked_1088.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) }; if linked_1083 == nil { arg_1080 = ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { arg_1080 = linked_1083.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }; var arg_1081 any; var G__1938000117__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000117__3_, nil) { arg_1081 = nil } else { arg_1081 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000117__3_) }; if linked_1078 == nil { x_SINGLEQUOTE___3 = ifn_1079.Invoke_O_O__O(arg_1080, arg_1081) } else { x_SINGLEQUOTE___3 = linked_1078.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1077, arg_1080, arg_1081) } } else {
//line :146:1
			var tmp4 any; var root_1092 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1094 lang.IFn

			if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = x__0; if linked_1093 == nil { tmp4 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp4 = linked_1093.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1092, arg_1095) }
//line :146:1
			if jrt.J2g_Truth(tmp4) {

				var root_1096 any = A_arbace_go_run_A_const_115.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var root_1101 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var arg_1105 any = x__0; if linked_1102 == nil { arg_1099 = ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { arg_1099 = linked_1102.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }; var arg_1100 any; var G__1938000118__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000118__3_, nil) { arg_1100 = nil } else { arg_1100 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000118__3_) }; if linked_1097 == nil { x_SINGLEQUOTE___3 = ifn_1098.Invoke_O_O__O(arg_1099, arg_1100) } else { x_SINGLEQUOTE___3 = linked_1097.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1096, arg_1099, arg_1100) } } else {
//line :146:1
					var tmp5 any; var root_1106 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1108 lang.IFn


					if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = x__0; if linked_1107 == nil { tmp5 = ifn_1108.Invoke_O__O(arg_1109) } else { tmp5 = linked_1107.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1106, arg_1109) }
//line :146:1
					if jrt.J2g_Truth(tmp5) {


						var root_1110 any = A_arbace_go_run_A_const_115.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any; var root_1115 any = A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1119 any; var root_1121 any = A_arbace_go_run_A_const_118.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any; var tmp6 any = A_arbace_go_run_raw_lines_fn__1938000120_A_New(); var tmp7 *jrt.Class; var fncls__1133 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000120_A_fn_class; if fncls__1133 == nil { var fncls__1133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_go_run_raw_lines_fn__1938000120_A_fn_class = fncls__1133d; tmp7 = fncls__1133d } else { tmp7 = fncls__1133 }; arg_1124 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_1122 == nil { arg_1119 = ifn_1123.Invoke_O__O(arg_1124) } else { arg_1119 = linked_1122.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1121, arg_1124) }; var arg_1120 any = x__0; if linked_1116 == nil { arg_1113 = ifn_1117.Invoke_O_O_O__O(arg_1118, arg_1119, arg_1120) } else { arg_1113 = linked_1116.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1115, arg_1118, arg_1119, arg_1120) }; var arg_1114 any; var G__1938000125__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000125__3_, nil) { arg_1114 = nil } else { arg_1114 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000125__3_) }; if linked_1111 == nil { x_SINGLEQUOTE___3 = ifn_1112.Invoke_O_O__O(arg_1113, arg_1114) } else { x_SINGLEQUOTE___3 = linked_1111.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1110, arg_1113, arg_1114) } } else {
//line :146:1
							var tmp8 any; var root_1134 any = A_arbace_go_run_A_const_121.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1136 lang.IFn



							if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = x__0; if linked_1135 == nil { tmp8 = ifn_1136.Invoke_O__O(arg_1137) } else { tmp8 = linked_1135.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1134, arg_1137) }
//line :146:1
							if jrt.J2g_Truth(tmp8) {



								var root_1138 any = A_arbace_go_run_A_const_115.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = x__0; var arg_1142 any; var G__1938000126__3_ any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); if lang.Util_Identical_O_O__Z_NoInit(G__1938000126__3_, nil) { arg_1142 = nil } else { arg_1142 = lang.IFn_Cast(walk_meta__2).Invoke_O__O(G__1938000126__3_) }; if linked_1139 == nil { x_SINGLEQUOTE___3 = ifn_1140.Invoke_O_O__O(arg_1141, arg_1142) } else { x_SINGLEQUOTE___3 = linked_1139.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1138, arg_1141, arg_1142) } } else {
//line :146:1
									if A_arbace_go_run_A_const_29 != nil { x_SINGLEQUOTE___3 = x__0 } else { x_SINGLEQUOTE___3 = nil } } } } }; var m__4 any; if





	lang.IObj_InstanceOf(x_SINGLEQUOTE___3) { m__4 = lang.RT_Meta_O__IPersistentMap_NoInit(x_SINGLEQUOTE___3) } else { m__4 = nil }; var pos__5 any = /*line :138:1*/A_arbace_go_run_A_const_122.Invoke_O__O(m__4); var lines__6 any; var tmp9 any = A_arbace_go_run_raw_lines_lines__1938000127_A_New(); var tmp10 *jrt.Class; var fncls__1157 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000127_A_fn_class; if


















	fncls__1157 == nil { var fncls__1157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_go_run_raw_lines_lines__1938000127_A_fn_class = fncls__1157d; tmp10 = fncls__1157d } else { tmp10 = fncls__1157 }; lines__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var l__7 any; var or__1927000174__auto____7 any; var tmp11 any; var root_1158 any = /*line :138:1*/A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1160 lang.IFn; if



















	linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = x_SINGLEQUOTE___3; if linked_1159 == nil { tmp11 = ifn_1160.Invoke_O__O(arg_1161) } else { tmp11 = linked_1159.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1158, arg_1161) }; if jrt.J2g_Truth(tmp11) { var G__1938000131__7_ any; var root_1162 any = A_arbace_go_run_A_const_73.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1164 lang.IFn
		if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any; var tmp12 lang.IFn = lang.IFn_Cast(lines__6); var tmp13 any; var root_1167 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = A_arbace_go_run_A_const_125.Invoke_O__O(m__4); if linked_1168 == nil { tmp13 = ifn_1169.Invoke_O__O(arg_1170) } else { tmp13 = linked_1168.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1167, arg_1170) }; arg_1165 = tmp12.Invoke_O__O(tmp13); var arg_1166 any; var root_1171 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1173 lang.IFn
		if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any; var tmp14 any = A_arbace_go_run_raw_lines_fn__1938000132_A_New(); var tmp15 *jrt.Class; var fncls__1176 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000132_A_fn_class; if fncls__1176 == nil { var fncls__1176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_go_run_raw_lines_fn__1938000132_A_fn_class = fncls__1176d; tmp15 = fncls__1176d } else { tmp15 = fncls__1176 }; arg_1174 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var arg_1175 any = x_SINGLEQUOTE___3; if linked_1172 == nil { arg_1166 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { arg_1166 = linked_1172.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }
//line :159:1
		if linked_1163 == nil { G__1938000131__7_ = ifn_1164.Invoke_O_O__O(arg_1165, arg_1166) } else { G__1938000131__7_ = linked_1163.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1162, arg_1165, arg_1166) }
//line :158:1
		var G__1938000131__8_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__1938000131__7_, nil) { G__1938000131__8_ = nil } else { var root_1177 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = G__1938000131__7_; if linked_1178 == nil { G__1938000131__8_ = ifn_1179.Invoke_O__O(arg_1180) } else { G__1938000131__8_ = linked_1178.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1177, arg_1180) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000131__8_, nil) { or__1927000174__auto____7 = nil } else {

			var root_1181 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = A_arbace_go_run_A_const_126.GetRawRoot__O(); var arg_1185 any = G__1938000131__8_; if linked_1182 == nil { or__1927000174__auto____7 = ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { or__1927000174__auto____7 = linked_1182.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) } } } else {
//line :158:1
				or__1927000174__auto____7 = nil }; if jrt.J2g_Truth(or__1927000174__auto____7) { l__7 = or__1927000174__auto____7 } else {



					var tmp16 any; var root_1186 any = A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = pos__5; if linked_1187 == nil { tmp16 = ifn_1188.Invoke_O__O(arg_1189) } else { tmp16 = linked_1187.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1186, arg_1189) }; if jrt.J2g_Truth(tmp16) { var G__1938000134__8_ any; var root_1190 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = A_arbace_go_run_A_const_127.GetRawRoot__O(); var arg_1194 any = pos__5; var arg_1195 any = A_arbace_go_run_A_const_128; if linked_1191 == nil { G__1938000134__8_ = ifn_1192.Invoke_O_O_O__O(arg_1193, arg_1194, arg_1195) } else { G__1938000134__8_ = linked_1191.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_1190, arg_1193, arg_1194, arg_1195) }; var G__1938000134__9_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000134__8_, nil) { G__1938000134__9_ = nil } else { var root_1196 any = A_arbace_go_run_A_const_124.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = G__1938000134__8_; if linked_1197 == nil { G__1938000134__9_ = ifn_1198.Invoke_O__O(arg_1199) } else { G__1938000134__9_ = linked_1197.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1196, arg_1199) } }; var G__1938000134__10_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000134__9_, nil) { G__1938000134__10_ = nil } else { G__1938000134__10_ = lang.IFn_Cast(lines__6).Invoke_O__O(G__1938000134__9_) }; var G__1938000134__11_ any; if lang.Util_Identical_O_O__Z_NoInit(G__1938000134__10_, nil) { G__1938000134__11_ = nil } else { var root_1200 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = G__1938000134__10_; if linked_1201 == nil { G__1938000134__11_ = ifn_1202.Invoke_O__O(arg_1203) } else { G__1938000134__11_ = linked_1201.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1200, arg_1203) } }; if lang.Util_Identical_O_O__Z_NoInit(G__1938000134__11_, nil) { l__7 = nil } else { var root_1204 any = A_arbace_go_run_A_const_116.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = A_arbace_go_run_A_const_126.GetRawRoot__O(); var arg_1208 any = G__1938000134__11_; if linked_1205 == nil { l__7 = ifn_1206.Invoke_O_O__O(arg_1207, arg_1208) } else { l__7 = linked_1205.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1204, arg_1207, arg_1208) } } } else { l__7 = nil } }; var end__8 any; var tmp17 any; var root_1209 any = /*line :138:1*/A_arbace_go_run_A_const_120.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1211 lang.IFn; if


























	linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = pos__5; if linked_1210 == nil { tmp17 = ifn_1211.Invoke_O__O(arg_1212) } else { tmp17 = linked_1210.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1209, arg_1212) }; if jrt.J2g_Truth(tmp17) { var root_1213 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = A_arbace_go_run_A_const_129.Invoke_O__O(pos__5); if linked_1214 == nil { end__8 = ifn_1215.Invoke_O__O(arg_1216) } else { end__8 = linked_1214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1213, arg_1216) } } else { end__8 = nil }; var apos__9 any = /*line :138:1*/A_arbace_go_run_A_const_125.Invoke_O__O(m__4); var tmp18 any; var or__1927000174__auto____10 any = l__7; if




























	jrt.J2g_Truth(or__1927000174__auto____10) { tmp18 = or__1927000174__auto____10 } else { var or__1927000174__auto____11 any = end__8; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp18 = or__1927000174__auto____11 } else { var root_1217 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = apos__9; if linked_1218 == nil { tmp18 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp18 = linked_1218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1217, arg_1220) } } }; if jrt.J2g_Truth(tmp18) {
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_130.GetRawRoot__O()); var tmp20 any = A_arbace_go_run_raw_lines_fn__1938000135_A_New_O_O_O(l__7, apos__9, end__8); var tmp21 *jrt.Class; var fncls__1335 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000135_A_fn_class; if fncls__1335 == nil { var fncls__1335d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_go_run_raw_lines_fn__1938000135_A_fn_class = fncls__1335d; tmp21 = fncls__1335d } else { tmp21 = fncls__1335 }; return tmp19.Invoke_O_O__O(x_SINGLEQUOTE___3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil)) } else {
//line :167:1
			return x_SINGLEQUOTE___3 } }
//line :145:1
func A_arbace_go_run_raw_lines_walk_meta__1938000114_A_New() *A_arbace_go_run_raw_lines_walk_meta__1938000114_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_walk_meta__1938000114_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000114_A) Ctor() {}
//line :145:1
func (t *A_arbace_go_run_raw_lines_walk_meta__1938000114_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000115__2_ any = m__1; var tmp1 any; var root_1061 any = A_arbace_go_run_A_const_97.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = m__1; var arg_1065 any = A_arbace_go_run_A_const_111; if linked_1062 == nil { tmp1 = ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { tmp1 = linked_1062.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }; if jrt.J2g_Truth(tmp1) { var root_1066 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = G__1938000115__2_; var arg_1070 any = A_arbace_go_run_A_const_111; var arg_1071 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); if linked_1067 == nil { return ifn_1068.Invoke_O_O_O__O(arg_1069, arg_1070, arg_1071) } else { return linked_1067.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1066, arg_1069, arg_1070, arg_1071) } } else { return G__1938000115__2_ } }



func A_arbace_go_run_raw_lines_fn__1938000120_A_New() *A_arbace_go_run_raw_lines_fn__1938000120_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000120_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_run_raw_lines_fn__1938000120_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_run_raw_lines_fn__1938000120_A) Invoke_O_O__O(self, p__1938000119__1 any) any { var vec__1938000121__2 any = p__1938000119__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000121__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000121__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1125 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = k__3; if linked_1126 == nil { tmp1 = ifn_1127.Invoke_O__O(arg_1128) } else { tmp1 = linked_1126.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp2 any = tmp1; var tmp3 any; var root_1129 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, A_arbace_go_run_raw_lines_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = v__4; if linked_1130 == nil { tmp3 = ifn_1131.Invoke_O__O(arg_1132) } else { tmp3 = linked_1130.(*A_arbace_go_run_raw_lines_A).Invoke_O_O__O(root_1129, arg_1132) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }







func A_arbace_go_run_raw_lines_lines__1938000127_A_New() *A_arbace_go_run_raw_lines_lines__1938000127_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000127_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_run_raw_lines_lines__1938000127_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_run_raw_lines_lines__1938000127_A) Invoke_O_O__O(self, ps__1 any) any { var root_1143 any = A_arbace_go_run_A_const_123.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any; var tmp1 any = A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A_New(); var tmp2 *jrt.Class; var fncls__1156 *jrt.Class = A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A_fn_class; if fncls__1156 == nil { var fncls__1156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A_fn_class = fncls__1156d; tmp2 = fncls__1156d } else { tmp2 = fncls__1156 }; arg_1146 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1147 any = ps__1; if linked_1144 == nil { return ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { return linked_1144.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) } }
//line :157:1
func A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A_New() *A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A) Invoke_O_O__O(self, p1__1938000112_SHARP___1 any) any { var tmp1 any; var root_1148 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = p1__1938000112_SHARP___1; if linked_1149 == nil { tmp1 = ifn_1150.Invoke_O__O(arg_1151) } else { tmp1 = linked_1149.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1148, arg_1151) }; if jrt.J2g_Truth(tmp1) { var root_1152 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = p1__1938000112_SHARP___1; if linked_1153 == nil { return ifn_1154.Invoke_O__O(arg_1155) } else { return linked_1153.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1152, arg_1155) } } else { return nil } }


func A_arbace_go_run_raw_lines_fn__1938000132_A_New() *A_arbace_go_run_raw_lines_fn__1938000132_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000132_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_go_run_raw_lines_fn__1938000132_A) Ctor() {}
//line :160:1
func (t *A_arbace_go_run_raw_lines_fn__1938000132_A) Invoke_O_O__O(self, p1__1938000113_SHARP___1 any) any { if lang.IMeta_InstanceOf(p1__1938000113_SHARP___1) { var tmp1 *lang.Keyword = A_arbace_go_run_A_const_66; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1938000113_SHARP___1)) } else { return nil } }







func A_arbace_go_run_raw_lines_fn__1938000135_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_raw_lines_fn__1938000135_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000135_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :168:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_A) Ctor_O_O_O(c__l, c__apos, c__end any) { t.F_l = c__l; t.F_apos = c__apos; t.F_end = c__end }
//line :168:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_A) Invoke_O_O__O(self, m__1 any) any { var G__1938000136__2_ any = m__1; var G__1938000136__3_ any; if jrt.J2g_Truth(t.F_l) {
											var root_1226 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = G__1938000136__2_; var arg_1230 any = A_arbace_go_run_A_const_66; var arg_1231 any = t.F_l; if linked_1227 == nil { G__1938000136__3_ = ifn_1228.Invoke_O_O_O__O(arg_1229, arg_1230, arg_1231) } else { G__1938000136__3_ = linked_1227.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1226, arg_1229, arg_1230, arg_1231) } } else {
//line :168:1
		G__1938000136__3_ = G__1938000136__2_ }; var G__1938000136__4_ any; if jrt.J2g_Truth(t.F_end) {

			var root_1232 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = G__1938000136__3_; var arg_1236 any = A_arbace_go_run_A_const_131; var arg_1237 any = t.F_end; if linked_1233 == nil { G__1938000136__4_ = ifn_1234.Invoke_O_O_O__O(arg_1235, arg_1236, arg_1237) } else { G__1938000136__4_ = linked_1233.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1232, arg_1235, arg_1236, arg_1237) } } else {
//line :168:1
				G__1938000136__4_ = G__1938000136__3_ }; var tmp1 any; var root_1238 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1240 lang.IFn; if


	linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = t.F_apos; if linked_1239 == nil { tmp1 = ifn_1240.Invoke_O__O(arg_1241) } else { tmp1 = linked_1239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1238, arg_1241) }; if /*line :168:1*/ jrt.J2g_Truth(tmp1) {


		var root_1242 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = G__1938000136__4_; var arg_1246 any = A_arbace_go_run_A_const_132; var arg_1247 any; var root_1248 any = A_arbace_go_run_A_const_133.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any; var iter__1927001039__auto____5 any; var tmp2 any = A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A_New(); var tmp3 *jrt.Class; var fncls__1330 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A_fn_class; if fncls__1330 == nil { var fncls__1330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A_fn_class = fncls__1330d; tmp3 = fncls__1330d } else { tmp3 = fncls__1330 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp5 any; var root_1331 any = A_arbace_go_run_A_const_100.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = t.F_apos; if linked_1332 == nil { tmp5 = ifn_1333.Invoke_O__O(arg_1334) } else { tmp5 = linked_1332.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1331, arg_1334) }; arg_1251 = tmp4.Invoke_O__O(tmp5); if linked_1249 == nil { arg_1247 = ifn_1250.Invoke_O__O(arg_1251) } else { arg_1247 = linked_1249.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1248, arg_1251) }; if linked_1243 == nil { return ifn_1244.Invoke_O_O_O__O(arg_1245, arg_1246, arg_1247) } else { return linked_1243.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1242, arg_1245, arg_1246, arg_1247) } } else {
//line :168:1
			return G__1938000136__4_ } }


func A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A_New() *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A) Ctor() {}
//line :171:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A) Invoke_O_O__O(self, s__1938000138__1 any) any { var tmp1 any = A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A_New_O_O(s__1938000138__1, self); var tmp2 *jrt.Class; var fncls__1329 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A_fn_class; if fncls__1329 == nil { var fncls__1329d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A_fn_class = fncls__1329d; tmp2 = fncls__1329d } else { tmp2 = fncls__1329 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :171:1
func A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A_New_O_O(p0, p1 any) *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :171:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A) Ctor_O_O(c__s__1938000138, c__iter__1938000137 any) { t.F_s__1938000138 = c__s__1938000138; t.F_iter__1938000137 = c__iter__1938000137 }
//line :171:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A) Invoke_O__O(self any) any { { var s__1938000138__1 any; var t_ any = t.F_s__1938000138; t.F_s__1938000138 = nil; s__1938000138__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1252 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = s__1938000138__1; if linked_1253 == nil { temp__1927000414__auto____2 = ifn_1254.Invoke_O__O(arg_1255) } else { temp__1927000414__auto____2 = linked_1253.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1252, arg_1255) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000138__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1256 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = s__1938000138__3; if linked_1257 == nil { tmp1 = ifn_1258.Invoke_O__O(arg_1259) } else { tmp1 = linked_1257.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1256, arg_1259) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1260 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = s__1938000138__3; if linked_1261 == nil { c__1927001037__auto____4 = ifn_1262.Invoke_O__O(arg_1263) } else { c__1927001037__auto____4 = linked_1261.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1260, arg_1263) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000140__6 any; var root_1264 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1265 == nil { b__1938000140__6 = ifn_1266.Invoke_O__O(arg_1267) } else { b__1938000140__6 = linked_1265.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1264, arg_1267) }; var tmp2 any = A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A_New_O_I_O(b__1938000140__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1281 *jrt.Class = A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A_fn_class; if fncls__1281 == nil { var fncls__1281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A_fn_class = fncls__1281d; tmp3 = fncls__1281d } else { tmp3 = fncls__1281 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1282 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var root_1287 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = b__1938000140__6; if linked_1288 == nil { arg_1285 = ifn_1289.Invoke_O__O(arg_1290) } else { arg_1285 = linked_1288.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1287, arg_1290) }; var arg_1286 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000137); var tmp5 any; var root_1291 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = s__1938000138__3; if linked_1292 == nil { tmp5 = ifn_1293.Invoke_O__O(arg_1294) } else { tmp5 = linked_1292.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1291, arg_1294) }; arg_1286 = tmp4.Invoke_O__O(tmp5); if linked_1283 == nil { return ifn_1284.Invoke_O_O__O(arg_1285, arg_1286) } else { return linked_1283.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1282, arg_1285, arg_1286) } } else { var root_1295 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any; var root_1300 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = b__1938000140__6; if linked_1301 == nil { arg_1298 = ifn_1302.Invoke_O__O(arg_1303) } else { arg_1298 = linked_1301.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1300, arg_1303) }; var arg_1299 any; if linked_1296 == nil { return ifn_1297.Invoke_O_O__O(arg_1298, arg_1299) } else { return linked_1296.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1295, arg_1298, arg_1299) } } } else { var vec__1938000148__4 any; var root_1304 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1304, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1306 lang.IFn; if linked_1305 == nil { ifn_1306 = lang.IFn_Cast(root_1304) } else { ifn_1306 = nil }; var arg_1307 any = s__1938000138__3; if linked_1305 == nil { vec__1938000148__4 = ifn_1306.Invoke_O__O(arg_1307) } else { vec__1938000148__4 = linked_1305.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1304, arg_1307) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000148__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000148__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_1308 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = p__6; if linked_1309 == nil { tmp6 = ifn_1310.Invoke_O__O(arg_1311) } else { tmp6 = linked_1309.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1308, arg_1311) }; if jrt.J2g_Truth(tmp6) { var root_1312 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any; var tmp7 any; var root_1317 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1319 lang.IFn; if linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any = p__6; if linked_1318 == nil { tmp7 = ifn_1319.Invoke_O__O(arg_1320) } else { tmp7 = linked_1318.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1317, arg_1320) }; arg_1315 = lang.Tuple_Create_O_O__IPersistentVector(i__5, tmp7); var arg_1316 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000137); var tmp9 any; var root_1321 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = s__1938000138__3; if linked_1322 == nil { tmp9 = ifn_1323.Invoke_O__O(arg_1324) } else { tmp9 = linked_1322.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1321, arg_1324) }; arg_1316 = tmp8.Invoke_O__O(tmp9); if linked_1313 == nil { return ifn_1314.Invoke_O_O__O(arg_1315, arg_1316) } else { return linked_1313.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1312, arg_1315, arg_1316) } } else { var tmp10 any; var root_1325 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = s__1938000138__3; if linked_1326 == nil { tmp10 = ifn_1327.Invoke_O__O(arg_1328) } else { tmp10 = linked_1326.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1325, arg_1328) }; s__1938000138__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :171:1
func A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :171:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A) Ctor_O_I_O(c__b__1938000140 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000140 = c__b__1938000140; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :171:1
func (t *A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A) Invoke_O__O(self any) any { { var i__1938000139__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000139__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1938000144__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000139__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000144__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000144__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_1268 any = A_arbace_go_run_A_const_69.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = p__4; if linked_1269 == nil { tmp2 = ifn_1270.Invoke_O__O(arg_1271) } else { tmp2 = linked_1269.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1268, arg_1271) }; if jrt.J2g_Truth(tmp2) { var root_1272 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = t.F_b__1938000140; var arg_1276 any; var tmp3 any; var root_1277 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = p__4; if linked_1278 == nil { tmp3 = ifn_1279.Invoke_O__O(arg_1280) } else { tmp3 = linked_1278.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1277, arg_1280) }; arg_1276 = lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp3); if linked_1273 == nil { ifn_1274.Invoke_O_O__O(arg_1275, arg_1276) } else { linked_1273.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1272, arg_1275, arg_1276) }; i__1938000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000139__1); continue L1 } else { i__1938000139__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000139__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_go_run_errorcheck_A_New() *A_arbace_go_run_errorcheck_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_go_run_errorcheck_A) Ctor() {}
//line :174:1
func (t *A_arbace_go_run_errorcheck_A) Invoke_O_O_O_O_O_O__O(self, root__0, pf__1, lang__2, max_errors__3, raw__4 any) any { var src__6 any; var G__1938000159__6_ any; var root_1336 any = A_arbace_go_run_A_const_74.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A_fn_class); var ifn_1338 lang.IFn; if










	linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_75, root__0)); var arg_1340 any; var arg_1341 any; var root_1343 any = A_arbace_go_run_A_const_8.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = A_arbace_go_run_A_const_76.GetRawRoot__O(); if linked_1344 == nil { arg_1341 = ifn_1345.Invoke_O__O(arg_1346) } else { arg_1341 = linked_1344.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1343, arg_1346) }; var arg_1342 any = pf__1; if linked_1337 == nil { G__1938000159__6_ = ifn_1338.Invoke_O_O_O_O__O(arg_1339, arg_1340, arg_1341, arg_1342) } else { G__1938000159__6_ = linked_1337.(*aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_1336, arg_1339, arg_1340, arg_1341, arg_1342) }; var G__1938000159__7_ any; if jrt.J2g_Truth(lang__2) {
		var root_1347 any = A_arbace_go_run_A_const_134.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = G__1938000159__6_; var arg_1351 any = A_arbace_go_run_A_const_135; var arg_1352 any = lang__2; if linked_1348 == nil { G__1938000159__7_ = ifn_1349.Invoke_O_O_O__O(arg_1350, arg_1351, arg_1352) } else { G__1938000159__7_ = linked_1348.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1347, arg_1350, arg_1351, arg_1352) } } else {
//line :185:1
			G__1938000159__7_ = G__1938000159__6_ }; if jrt.J2g_Truth(raw__4) {





				var root_1353 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var root_1359 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1361 lang.IFn
//line :187:1
				if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any = G__1938000159__7_; var arg_1363 any = A_arbace_go_run_A_const_51; var arg_1364 any; var tmp1 any = A_arbace_go_run_errorcheck_fn__1938000160_A_New(); var tmp2 *jrt.Class; var fncls__1400 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000160_A_fn_class; if fncls__1400 == nil { var fncls__1400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_run_errorcheck_fn__1938000160_A_fn_class = fncls__1400d; tmp2 = fncls__1400d } else { tmp2 = fncls__1400 }; arg_1364 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1360 == nil { arg_1356 = ifn_1361.Invoke_O_O_O__O(arg_1362, arg_1363, arg_1364) } else { arg_1356 = linked_1360.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1359, arg_1362, arg_1363, arg_1364)
				}


				var arg_1357 any = A_arbace_go_run_A_const_139; var arg_1358 any = jrt.HashMap_New(); if linked_1354 == nil { src__6 = ifn_1355.Invoke_O_O_O__O(arg_1356, arg_1357, arg_1358) } else { src__6 = linked_1354.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1353, arg_1356, arg_1357, arg_1358) } } else {
//line :185:1
					src__6 = G__1938000159__7_ }; var ___7 any; var tmp3 any; var root_1401 any = /*line :174:1*/A_arbace_go_run_A_const_77.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1403 lang.IFn; _ = ___7; if

















	linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = A_arbace_go_run_A_const_51.Invoke_O__O(src__6); if linked_1402 == nil { tmp3 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp3 = linked_1402.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1401, arg_1404) }; if jrt.J2g_Truth(tmp3) { var root_1405 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, A_arbace_go_run_fail_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = A_arbace_go_run_A_const_49; var arg_1409 any = Lit_13; var arg_1410 any = Lit_25; if linked_1406 == nil { ___7 = ifn_1407.Invoke_O_O_O__O(arg_1408, arg_1409, arg_1410) } else { ___7 = linked_1406.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1405, arg_1408, arg_1409, arg_1410) } } else { ___7 = nil }; var ___8 any; var root_1411 any = /*line :174:1*/A_arbace_go_run_A_const_59.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, A_arbace_go_run_no_assembly_BANG__A_fn_class); var ifn_1413 lang.IFn; _ = ___8; if


















	linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = src__6; if linked_1412 == nil { ___8 = ifn_1413.Invoke_O__O(arg_1414) } else { ___8 = linked_1412.(*A_arbace_go_run_no_assembly_BANG__A).Invoke_O_O__O(root_1411, arg_1414) }; var r__9 any; var root_1415 any = /*line :174:1*/A_arbace_go_run_A_const_57.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_1417 lang.IFn; if



















	linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = src__6; var arg_1419 any; var tmp4 any = A_arbace_go_run_errorcheck_fn__1938000167_A_New(); var tmp5 *jrt.Class; var fncls__1421 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000167_A_fn_class; if fncls__1421 == nil { var fncls__1421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_go_run_errorcheck_fn__1938000167_A_fn_class = fncls__1421d; tmp5 = fncls__1421d } else { tmp5 = fncls__1421 }; arg_1419 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1420 any = jrt.Boolean_FALSE.Ref(); if linked_1416 == nil { r__9 = ifn_1417.Invoke_O_O_O__O(arg_1418, arg_1419, arg_1420) } else { r__9 = linked_1416.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O_O__O(root_1415, arg_1418, arg_1419, arg_1420) }; var errs__10 any = /*line :174:1*/A_arbace_go_run_A_const_58.Invoke_O__O(r__9); var temp__1927000414__auto____11 any; var root_1608 any = A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1610 lang.IFn; if





















	linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any; var tmp6 any = A_arbace_go_run_errorcheck_fn__1938000169_A_New(); var tmp7 *jrt.Class; var fncls__1613 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000169_A_fn_class; if fncls__1613 == nil { var fncls__1613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_run_errorcheck_fn__1938000169_A_fn_class = fncls__1613d; tmp7 = fncls__1613d } else { tmp7 = fncls__1613 }; arg_1611 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1612 any = errs__10; if linked_1609 == nil { temp__1927000414__auto____11 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { temp__1927000414__auto____11 = linked_1609.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var bi__12 any = temp__1927000414__auto____11; var root_1614 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1614, A_arbace_go_run_fail_A_fn_class); var ifn_1616 lang.IFn
		if linked_1615 == nil { ifn_1616 = lang.IFn_Cast(root_1614) } else { ifn_1616 = nil }; var arg_1617 any = A_arbace_go_run_A_const_49; var arg_1618 any = Lit_13; var arg_1619 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_run_A_const_63.Invoke_O__O(bi__12))).Ref(); if linked_1615 == nil { ifn_1616.Invoke_O_O_O__O(arg_1617, arg_1618, arg_1619) } else { linked_1615.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1614, arg_1617, arg_1618, arg_1619) } }; var temp__1927000414__auto____11_2 any; var root_1620 any = /*line :174:1*/A_arbace_go_run_A_const_45.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1622 lang.IFn; if























	linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any; var tmp8 any = A_arbace_go_run_errorcheck_fn__1938000171_A_New(); var tmp9 *jrt.Class; var fncls__1625 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000171_A_fn_class; if fncls__1625 == nil { var fncls__1625d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_run_errorcheck_fn__1938000171_A_fn_class = fncls__1625d; tmp9 = fncls__1625d } else { tmp9 = fncls__1625 }; arg_1623 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_1624 any = A_arbace_go_run_A_const_153.Invoke_O__O(r__9); if linked_1621 == nil { temp__1927000414__auto____11_2 = ifn_1622.Invoke_O_O__O(arg_1623, arg_1624) } else { temp__1927000414__auto____11_2 = linked_1621.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1620, arg_1623, arg_1624) }; if jrt.J2g_Truth(temp__1927000414__auto____11_2) { var u__12 any = temp__1927000414__auto____11_2; var root_1626 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, A_arbace_go_run_fail_A_fn_class); var ifn_1628 lang.IFn
		if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = A_arbace_go_run_A_const_49; var arg_1630 any = Lit_13; var arg_1631 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_29, nil, Lit_30, nil); var tmp11 *lang.Keyword = A_arbace_go_run_A_const_81; var tmp12 any; var root_1632 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = u__12; if linked_1633 == nil { tmp12 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp12 = linked_1633.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1632, arg_1635) }; var tmp13 any = tmp11.Invoke_O__O(tmp12); var tmp14 any; var root_1636 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = u__12; if linked_1637 == nil { tmp14 = ifn_1638.Invoke_O__O(arg_1639) } else { tmp14 = linked_1637.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1636, arg_1639) }; arg_1631 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp14)).Ref(); if linked_1627 == nil { ifn_1628.Invoke_O_O_O__O(arg_1629, arg_1630, arg_1631) } else { linked_1627.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1626, arg_1629, arg_1630, arg_1631) } }; var errs__11 any; var root_1422 any = /*line :174:1*/A_arbace_go_run_A_const_23.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1424 lang.IFn; if




























	linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any; var tmp15 any = A_arbace_go_run_errorcheck_fn__1938000173_A_New(); var tmp16 *jrt.Class; var fncls__1427 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000173_A_fn_class; if fncls__1427 == nil { var fncls__1427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_go_run_errorcheck_fn__1938000173_A_fn_class = fncls__1427d; tmp16 = fncls__1427d } else { tmp16 = fncls__1427 }; arg_1425 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_1426 any = errs__10; if linked_1423 == nil { errs__11 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { errs__11 = linked_1423.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }; var file_lang__12 any; var root_1428 any = /*line :174:1*/A_arbace_go_run_A_const_31.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1430 lang.IFn; if






























	linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1432 any; var iter__1927001039__auto____12 any; var tmp17 any = A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A_New(); var tmp18 *jrt.Class; var fncls__1501 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A_fn_class; if fncls__1501 == nil { var fncls__1501d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A_fn_class = fncls__1501d; tmp18 = fncls__1501d } else { tmp18 = fncls__1501 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_1432 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_go_run_A_const_51.Invoke_O__O(src__6)); if linked_1429 == nil { file_lang__12 = ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { file_lang__12 = linked_1429.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; var vmsg__13 any; var tmp19 any = /*line :174:1*/A_arbace_go_run_errorcheck_vmsg__1938000185_A_New_O_O_O(file_lang__12, lang__2, src__6); var tmp20 *jrt.Class; var fncls__1512 *jrt.Class = A_arbace_go_run_errorcheck_vmsg__1938000185_A_fn_class; if































	fncls__1512 == nil { var fncls__1512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_run_errorcheck_vmsg__1938000185_A_fn_class = fncls__1512d; tmp20 = fncls__1512d } else { tmp20 = fncls__1512 }; vmsg__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var lines__14 any; var root_1513 any = /*line :174:1*/A_arbace_go_run_A_const_146.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_dedupe_A_fn_class); var ifn_1515 lang.IFn; if






































	linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any; var iter__1927001039__auto____14 any; var tmp21 any = A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A_New_O(vmsg__13); var tmp22 *jrt.Class; var fncls__1575 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A_fn_class; if fncls__1575 == nil { var fncls__1575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A_fn_class = fncls__1575d; tmp22 = fncls__1575d } else { tmp22 = fncls__1575 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); arg_1516 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(errs__11); if linked_1514 == nil { lines__14 = ifn_1515.Invoke_O__O(arg_1516) } else { lines__14 = linked_1514.(*aot_arbace_core.A_arbace_core_dedupe_A).Invoke_O_O__O(root_1513, arg_1516) }; var lines__15 any; var tmp23 any; var and__1927000168__auto____15 any = max_errors__3; if


	jrt.J2g_Truth(and__1927000168__auto____15) { var tmp24 bool; var na_1576 int64 = int64(lang.RT_Count_O__I_NoInit(lines__14)); var na_1577 any = max_errors__3; if jrt.Long_InstanceOf(na_1577) { var n0_1578 int64 = na_1576; var n1_1579 int64 = jrt.NN(jrt.Long_Cast(na_1577)).LongValue__J(); tmp24 = n0_1578 >= n1_1579 } else { tmp24 = lang.Numbers_Gte_J_O__Z_NoInit(na_1576, na_1577) }; tmp23 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp24).Ref() } else { tmp23 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp23) { var ls__15 any; var root_1581 any = A_arbace_go_run_A_const_133.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1583 lang.IFn
		if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any; var root_1585 any = A_arbace_go_run_A_const_147.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = max_errors__3; var arg_1589 any = lines__14; if linked_1586 == nil { arg_1584 = ifn_1587.Invoke_O_O__O(arg_1588, arg_1589) } else { arg_1584 = linked_1586.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1585, arg_1588, arg_1589) }; if linked_1582 == nil { ls__15 = ifn_1583.Invoke_O__O(arg_1584) } else { ls__15 = linked_1582.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1581, arg_1584) }
//line :216:1
		var pos__16 any; var root_1590 any = A_arbace_go_run_A_const_143.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1592 lang.IFn

		if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = A_arbace_go_run_A_const_148; var arg_1594 any; var root_1595 any = A_arbace_go_run_A_const_149.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = ls__15; if linked_1596 == nil { arg_1594 = ifn_1597.Invoke_O__O(arg_1598) } else { arg_1594 = linked_1596.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_1595, arg_1598) }; if linked_1591 == nil { pos__16 = ifn_1592.Invoke_O_O__O(arg_1593, arg_1594) } else { pos__16 = linked_1591.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1590, arg_1593, arg_1594) }
		var root_1599 any = A_arbace_go_run_A_const_10.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = ls__15; var arg_1603 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_35), jrt.RefArrayOf(jrt.Object_class, pos__16, nil)).Ref(); if linked_1600 == nil { lines__15 = ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { lines__15 = linked_1600.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) } } else {
//line :216:1
			lines__15 = lines__14 }; var seq_1938000197__16 any; var root_1640 any = /*line :174:1*/A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1642 lang.IFn; if














































	linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = lines__15; if linked_1641 == nil { seq_1938000197__16 = ifn_1642.Invoke_O__O(arg_1643) } else { seq_1938000197__16 = linked_1641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1640, arg_1643) }; var chunk_1938000198__17 any; var count_1938000199__18 int64 = 0; var i_1938000200__19 int64 = 0; L1:
//line :174:1
	for {














































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1938000200__19, count_1938000199__18) { var l__20 any = lang.Indexed_Cast(chunk_1938000198__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1938000200__19)); lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(l__20); seq_1938000197__16, chunk_1938000198__17, count_1938000199__18, i_1938000200__19 = seq_1938000197__16, chunk_1938000198__17, count_1938000199__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1938000200__19); continue L1 } else { var temp__1927000414__auto____20 any; var root_1644 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = seq_1938000197__16; if linked_1645 == nil { temp__1927000414__auto____20 = ifn_1646.Invoke_O__O(arg_1647) } else { temp__1927000414__auto____20 = linked_1645.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1644, arg_1647) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1938000197__21 any = temp__1927000414__auto____20; var tmp25 any; var root_1648 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1650 lang.IFn; if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = seq_1938000197__21; if linked_1649 == nil { tmp25 = ifn_1650.Invoke_O__O(arg_1651) } else { tmp25 = linked_1649.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1648, arg_1651) }; if jrt.J2g_Truth(tmp25) { var c__1927000678__auto____22 any; var root_1652 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = seq_1938000197__21; if linked_1653 == nil { c__1927000678__auto____22 = ifn_1654.Invoke_O__O(arg_1655) } else { c__1927000678__auto____22 = linked_1653.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1652, arg_1655) }; var tmp26 any; var root_1667 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = seq_1938000197__21; if linked_1668 == nil { tmp26 = ifn_1669.Invoke_O__O(arg_1670) } else { tmp26 = linked_1668.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1667, arg_1670) }; seq_1938000197__16, chunk_1938000198__17, count_1938000199__18, i_1938000200__19 = tmp26, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var l__22 any; var root_1656 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = seq_1938000197__21; if linked_1657 == nil { l__22 = ifn_1658.Invoke_O__O(arg_1659) } else { l__22 = linked_1657.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1656, arg_1659) }; lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(l__22); var tmp27 any; var root_1675 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = seq_1938000197__21; if linked_1676 == nil { tmp27 = ifn_1677.Invoke_O__O(arg_1678) } else { tmp27 = linked_1676.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1675, arg_1678) }; seq_1938000197__16, chunk_1938000198__17, count_1938000199__18, i_1938000200__19 = tmp27, nil, 0, 0; continue L1 } } }
//line :174:1
		break L1 }; var root_1660 any =















































	A_arbace_go_run_A_const_12.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; if linked_1661 == nil { ifn_1662.Invoke__O() } else { linked_1661.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_1660) }; var tmp28 any; var root_1604 any =
	A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = lines__15; if linked_1605 == nil { tmp28 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp28 = linked_1605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1604, arg_1607) }; if jrt.J2g_Truth(tmp28) { return A_arbace_go_run_A_const_150 } else { return A_arbace_go_run_A_const_151 } }
//line :187:1
func A_arbace_go_run_errorcheck_fn__1938000160_A_New() *A_arbace_go_run_errorcheck_fn__1938000160_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000160_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_go_run_errorcheck_fn__1938000160_A) Ctor() {}
//line :187:1
func (t *A_arbace_go_run_errorcheck_fn__1938000160_A) Invoke_O_O__O(self, fs__1 any) any { var root_1365 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any; var tmp1 any = A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A_New(); var tmp2 *jrt.Class; var fncls__1399 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A_fn_class; if fncls__1399 == nil { var fncls__1399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A_fn_class = fncls__1399d; tmp2 = fncls__1399d } else { tmp2 = fncls__1399 }; arg_1368 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1369 any = fs__1; if linked_1366 == nil { return ifn_1367.Invoke_O_O__O(arg_1368, arg_1369) } else { return linked_1366.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1365, arg_1368, arg_1369) } }
//line :187:1
func A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A_New() *A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A) Ctor() {}
//line :187:1
func (t *A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A) Invoke_O_O__O(self, p1__1938000155_SHARP___1 any) any { var G__1938000162__2_ any; var root_1370 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = p1__1938000155_SHARP___1; var arg_1374 any = A_arbace_go_run_A_const_52; var arg_1375 any; var tmp1 any = A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A_New(); var tmp2 *jrt.Class; var fncls__1381 *jrt.Class = A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A_fn_class; if fncls__1381 == nil { var fncls__1381d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A_fn_class = fncls__1381d; tmp2 = fncls__1381d } else { tmp2 = fncls__1381 }; arg_1375 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1371 == nil { G__1938000162__2_ = ifn_1372.Invoke_O_O_O__O(arg_1373, arg_1374, arg_1375) } else { G__1938000162__2_ = linked_1371.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1370, arg_1373, arg_1374, arg_1375) }; var G__1938000162__3_ any; if jrt.J2g_Truth(A_arbace_go_run_A_const_65.Invoke_O__O(p1__1938000155_SHARP___1)) {
																var root_1382 any = A_arbace_go_run_A_const_112.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = G__1938000162__2_; var arg_1386 any = A_arbace_go_run_A_const_65; var arg_1387 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); if linked_1383 == nil { G__1938000162__3_ = ifn_1384.Invoke_O_O_O__O(arg_1385, arg_1386, arg_1387) } else { G__1938000162__3_ = linked_1383.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1382, arg_1385, arg_1386, arg_1387) } } else {
//line :187:1
		G__1938000162__3_ = G__1938000162__2_ }; var tmp3 any; var root_1388 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1390 lang.IFn; if

	linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = p1__1938000155_SHARP___1; var arg_1392 any = A_arbace_go_run_A_const_136; if linked_1389 == nil { tmp3 = ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { tmp3 = linked_1389.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) }; if /*line :187:1*/ jrt.J2g_Truth(tmp3) {

		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_137.GetRawRoot__O()); var tmp5 any = A_arbace_go_run_A_const_138; return tmp4.Invoke_O_O_O__O(G__1938000162__3_, tmp5, A_arbace_go_run_A_const_113.GetRawRoot__O()) } else {
//line :187:1
			return G__1938000162__3_ } }
//line :187:1
func A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A_New() *A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A) Ctor() {}
//line :187:1
func (t *A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A) Invoke_O_O__O(self, ds__1 any) any { var root_1376 any = A_arbace_go_run_A_const_119.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = A_arbace_go_run_A_const_113.GetRawRoot__O(); var arg_1380 any = ds__1; if linked_1377 == nil { return ifn_1378.Invoke_O_O__O(arg_1379, arg_1380) } else { return linked_1377.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1376, arg_1379, arg_1380) } }






func A_arbace_go_run_errorcheck_fn__1938000167_A_New() *A_arbace_go_run_errorcheck_fn__1938000167_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000167_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_go_run_errorcheck_fn__1938000167_A) Ctor() {}
//line :194:1
func (t *A_arbace_go_run_errorcheck_fn__1938000167_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_go_run_errorcheck_fn__1938000169_A_New() *A_arbace_go_run_errorcheck_fn__1938000169_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000169_A{}; t.Ctor(); return t }
//line :196:1
func (t *A_arbace_go_run_errorcheck_fn__1938000169_A) Ctor() {}
//line :196:1
func (t *A_arbace_go_run_errorcheck_fn__1938000169_A) Invoke_O_O__O(self, p1__1938000156_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_61; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000156_SHARP___1)) { return p1__1938000156_SHARP___1 } else { return nil } }

func A_arbace_go_run_errorcheck_fn__1938000171_A_New() *A_arbace_go_run_errorcheck_fn__1938000171_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000171_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_go_run_errorcheck_fn__1938000171_A) Ctor() {}
//line :198:1
func (t *A_arbace_go_run_errorcheck_fn__1938000171_A) Invoke_O_O__O(self, p1__1938000157_SHARP___1 any) any { var temp__1927000414__auto____2 any = A_arbace_go_run_A_const_152.Invoke_O__O(p1__1938000157_SHARP___1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var u__3 any = temp__1927000414__auto____2; return lang.Tuple_Create_O_O__IPersistentVector(A_arbace_go_run_A_const_65.Invoke_O__O(p1__1938000157_SHARP___1), u__3) } else { return nil } }




func A_arbace_go_run_errorcheck_fn__1938000173_A_New() *A_arbace_go_run_errorcheck_fn__1938000173_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_fn__1938000173_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_go_run_errorcheck_fn__1938000173_A) Ctor() {}
//line :203:1
func (t *A_arbace_go_run_errorcheck_fn__1938000173_A) Invoke_O_O__O(self, p1__1938000158_SHARP___1 any) any { var tmp1 any = A_arbace_go_run_A_const_140; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_go_run_A_const_62.Invoke_O__O(p1__1938000158_SHARP___1))).Ref() }

func A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A_New() *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A) Ctor() {}
//line :205:1
func (t *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A) Invoke_O_O__O(self, s__1938000176__1 any) any { var tmp1 any = A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A_New_O_O(self, s__1938000176__1); var tmp2 *jrt.Class; var fncls__1500 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A_fn_class; if fncls__1500 == nil { var fncls__1500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A_fn_class = fncls__1500d; tmp2 = fncls__1500d } else { tmp2 = fncls__1500 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :205:1
func A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A_New_O_O(p0, p1 any) *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A{}; t.Ctor_O_O(p0, p1); return t }
//line :205:1
func (t *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A) Ctor_O_O(c__iter__1938000175, c__s__1938000176 any) { t.F_iter__1938000175 = c__iter__1938000175; t.F_s__1938000176 = c__s__1938000176 }
//line :205:1
func (t *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A) Invoke_O__O(self any) any { { var s__1938000176__1 any; var t_ any = t.F_s__1938000176; t.F_s__1938000176 = nil; s__1938000176__1 = t_; for { var temp__1927000414__auto____2 any; var root_1433 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = s__1938000176__1; if linked_1434 == nil { temp__1927000414__auto____2 = ifn_1435.Invoke_O__O(arg_1436) } else { temp__1927000414__auto____2 = linked_1434.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1433, arg_1436) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000176__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1437 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = s__1938000176__3; if linked_1438 == nil { tmp1 = ifn_1439.Invoke_O__O(arg_1440) } else { tmp1 = linked_1438.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1437, arg_1440) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1441 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = s__1938000176__3; if linked_1442 == nil { c__1927001037__auto____4 = ifn_1443.Invoke_O__O(arg_1444) } else { c__1927001037__auto____4 = linked_1442.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1441, arg_1444) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000178__6 any; var root_1445 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1446 == nil { b__1938000178__6 = ifn_1447.Invoke_O__O(arg_1448) } else { b__1938000178__6 = linked_1446.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1445, arg_1448) }; var tmp2 any = A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A_New_O_I_O(b__1938000178__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1459 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A_fn_class; if fncls__1459 == nil { var fncls__1459d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A_fn_class = fncls__1459d; tmp3 = fncls__1459d } else { tmp3 = fncls__1459 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1460 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any; var root_1465 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = b__1938000178__6; if linked_1466 == nil { arg_1463 = ifn_1467.Invoke_O__O(arg_1468) } else { arg_1463 = linked_1466.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1465, arg_1468) }; var arg_1464 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000175); var tmp5 any; var root_1469 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = s__1938000176__3; if linked_1470 == nil { tmp5 = ifn_1471.Invoke_O__O(arg_1472) } else { tmp5 = linked_1470.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1469, arg_1472) }; arg_1464 = tmp4.Invoke_O__O(tmp5); if linked_1461 == nil { return ifn_1462.Invoke_O_O__O(arg_1463, arg_1464) } else { return linked_1461.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1460, arg_1463, arg_1464) } } else { var root_1473 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any; var root_1478 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = b__1938000178__6; if linked_1479 == nil { arg_1476 = ifn_1480.Invoke_O__O(arg_1481) } else { arg_1476 = linked_1479.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1478, arg_1481) }; var arg_1477 any; if linked_1474 == nil { return ifn_1475.Invoke_O_O__O(arg_1476, arg_1477) } else { return linked_1474.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1473, arg_1476, arg_1477) } } } else { var fi__4 any; var root_1482 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = s__1938000176__3; if linked_1483 == nil { fi__4 = ifn_1484.Invoke_O__O(arg_1485) } else { fi__4 = linked_1483.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1482, arg_1485) }; var root_1486 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any; var tmp6 any = A_arbace_go_run_A_const_81.Invoke_O__O(fi__4); var tmp7 any; var root_1491 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = fi__4; var arg_1495 any = A_arbace_go_run_A_const_142; if linked_1492 == nil { tmp7 = ifn_1493.Invoke_O_O__O(arg_1494, arg_1495) } else { tmp7 = linked_1492.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1491, arg_1494, arg_1495) }; arg_1489 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_1490 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1938000175); var tmp9 any; var root_1496 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = s__1938000176__3; if linked_1497 == nil { tmp9 = ifn_1498.Invoke_O__O(arg_1499) } else { tmp9 = linked_1497.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1496, arg_1499) }; arg_1490 = tmp8.Invoke_O__O(tmp9); if linked_1487 == nil { return ifn_1488.Invoke_O_O__O(arg_1489, arg_1490) } else { return linked_1487.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1486, arg_1489, arg_1490) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :205:1
func A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :205:1
func (t *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A) Ctor_O_I_O(c__b__1938000178 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1938000178 = c__b__1938000178; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :205:1
func (t *A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A) Invoke_O__O(self any) any { { var i__1938000177__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000177__1)); var root_1449 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = t.F_b__1938000178; var arg_1453 any; var tmp2 any = A_arbace_go_run_A_const_81.Invoke_O__O(fi__2); var tmp3 any; var root_1454 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = fi__2; var arg_1458 any = A_arbace_go_run_A_const_141; if linked_1455 == nil { tmp3 = ifn_1456.Invoke_O_O__O(arg_1457, arg_1458) } else { tmp3 = linked_1455.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1454, arg_1457, arg_1458) }; arg_1453 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_1450 == nil { ifn_1451.Invoke_O_O__O(arg_1452, arg_1453) } else { linked_1450.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1449, arg_1452, arg_1453) }; i__1938000177__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000177__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_run_errorcheck_vmsg__1938000185_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_vmsg__1938000185_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_vmsg__1938000185_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :206:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000185_A) Ctor_O_O_O(c__file_lang, c__lang, c__src any) { t.F_file_lang = c__file_lang; t.F_lang = c__lang; t.F_src = c__src }
//line :206:1
func (t *A_arbace_go_run_errorcheck_vmsg__1938000185_A) Invoke_O_O__O(self, e__1 any) any { var m__2 any = A_arbace_go_run_A_const_63.Invoke_O__O(e__1); var tmp1 any; var root_1502 any = A_arbace_go_run_A_const_143.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1504 lang.IFn; if

	linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = A_arbace_go_run_A_const_144; var arg_1506 any = m__2; if linked_1503 == nil { tmp1 = ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { tmp1 = linked_1503.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_file_lang); var temp__1927000408__auto____3 any = tmp2.Invoke_O__O(A_arbace_go_run_A_const_65.Invoke_O__O(e__1))
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var fl__4 any = temp__1927000408__auto____3
			return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, m__2, nil, fl__4, nil)).Ref() } else {
				var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil, Lit_46); var tmp4 any; var or__1927000174__auto____8 any = t.F_lang; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp4 = or__1927000174__auto____8 } else { var root_1507 any = A_arbace_go_run_A_const_46.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = t.F_src; var arg_1511 any = A_arbace_go_run_A_const_145; if linked_1508 == nil { tmp4 = ifn_1509.Invoke_O_O__O(arg_1510, arg_1511) } else { tmp4 = linked_1508.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1507, arg_1510, arg_1511) } }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, m__2, nil, tmp4, nil)).Ref() } } else {
//line :208:1
					return m__2 } }




func A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A_New_O(p0 any) *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A{}; t.Ctor_O(p0); return t }
//line :213:1
func (t *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A) Ctor_O(c__vmsg any) { t.F_vmsg = c__vmsg }
//line :213:1
func (t *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A) Invoke_O_O__O(self, s__1938000188__1 any) any { var tmp1 any = A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A_New_O_O_O(s__1938000188__1, self, t.F_vmsg); var tmp2 *jrt.Class; var fncls__1574 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A_fn_class; if fncls__1574 == nil { var fncls__1574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A_fn_class = fncls__1574d; tmp2 = fncls__1574d } else { tmp2 = fncls__1574 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :213:1
func A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :213:1
func (t *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A) Ctor_O_O_O(c__s__1938000188, c__iter__1938000187, c__vmsg any) { t.F_s__1938000188 = c__s__1938000188; t.F_iter__1938000187 = c__iter__1938000187; t.F_vmsg = c__vmsg }
//line :213:1
func (t *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A) Invoke_O__O(self any) any { { var s__1938000188__1 any; var t_ any = t.F_s__1938000188; t.F_s__1938000188 = nil; s__1938000188__1 = t_; for { var temp__1927000414__auto____2 any; var root_1517 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = s__1938000188__1; if linked_1518 == nil { temp__1927000414__auto____2 = ifn_1519.Invoke_O__O(arg_1520) } else { temp__1927000414__auto____2 = linked_1518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1517, arg_1520) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1938000188__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1521 any = A_arbace_go_run_A_const_33.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = s__1938000188__3; if linked_1522 == nil { tmp1 = ifn_1523.Invoke_O__O(arg_1524) } else { tmp1 = linked_1522.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1521, arg_1524) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1525 any = A_arbace_go_run_A_const_34.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = s__1938000188__3; if linked_1526 == nil { c__1927001037__auto____4 = ifn_1527.Invoke_O__O(arg_1528) } else { c__1927001037__auto____4 = linked_1526.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1525, arg_1528) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1938000190__6 any; var root_1529 any = A_arbace_go_run_A_const_35.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1530 == nil { b__1938000190__6 = ifn_1531.Invoke_O__O(arg_1532) } else { b__1938000190__6 = linked_1530.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1529, arg_1532) }; var tmp2 any = A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A_New_O_I_O_O(b__1938000190__6, size__1927001038__auto____5, t.F_vmsg, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1538 *jrt.Class = A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A_fn_class; if fncls__1538 == nil { var fncls__1538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A_fn_class = fncls__1538d; tmp3 = fncls__1538d } else { tmp3 = fncls__1538 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1539 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any; var root_1544 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = b__1938000190__6; if linked_1545 == nil { arg_1542 = ifn_1546.Invoke_O__O(arg_1547) } else { arg_1542 = linked_1545.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1544, arg_1547) }; var arg_1543 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1938000187); var tmp5 any; var root_1548 any = A_arbace_go_run_A_const_41.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = s__1938000188__3; if linked_1549 == nil { tmp5 = ifn_1550.Invoke_O__O(arg_1551) } else { tmp5 = linked_1549.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1548, arg_1551) }; arg_1543 = tmp4.Invoke_O__O(tmp5); if linked_1540 == nil { return ifn_1541.Invoke_O_O__O(arg_1542, arg_1543) } else { return linked_1540.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1539, arg_1542, arg_1543) } } else { var root_1552 any = A_arbace_go_run_A_const_39.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any; var root_1557 any = A_arbace_go_run_A_const_40.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = b__1938000190__6; if linked_1558 == nil { arg_1555 = ifn_1559.Invoke_O__O(arg_1560) } else { arg_1555 = linked_1558.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1557, arg_1560) }; var arg_1556 any; if linked_1553 == nil { return ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { return linked_1553.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) } } } else { var e__4 any; var root_1561 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = s__1938000188__3; if linked_1562 == nil { e__4 = ifn_1563.Invoke_O__O(arg_1564) } else { e__4 = linked_1562.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1561, arg_1564) }; var root_1565 any = A_arbace_go_run_A_const_42.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_42, nil, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_65.Invoke_O__O(e__4), nil, A_arbace_go_run_A_const_66.Invoke_O__O(e__4), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__4))).Ref(); var arg_1569 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1938000187); var tmp7 any; var root_1570 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = s__1938000188__3; if linked_1571 == nil { tmp7 = ifn_1572.Invoke_O__O(arg_1573) } else { tmp7 = linked_1571.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1570, arg_1573) }; arg_1569 = tmp6.Invoke_O__O(tmp7); if linked_1566 == nil { return ifn_1567.Invoke_O_O__O(arg_1568, arg_1569) } else { return linked_1566.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1565, arg_1568, arg_1569) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :213:1
func A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :213:1
func (t *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A) Ctor_O_I_O_O(c__b__1938000190 any, c__size__1927001038__auto__ int32, c__vmsg, c__c__1927001037__auto__ any) { t.F_b__1938000190 = c__b__1938000190; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_vmsg = c__vmsg; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :213:1
func (t *A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A) Invoke_O__O(self any) any { { var i__1938000189__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1938000189__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1938000189__1)); var root_1533 any = A_arbace_go_run_A_const_38.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = t.F_b__1938000190; var arg_1537 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_42, nil, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_run_A_const_65.Invoke_O__O(e__2), nil, A_arbace_go_run_A_const_66.Invoke_O__O(e__2), nil, lang.IFn_Cast(t.F_vmsg).Invoke_O__O(e__2))).Ref(); if linked_1534 == nil { ifn_1535.Invoke_O_O__O(arg_1536, arg_1537) } else { linked_1534.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1533, arg_1536, arg_1537) }; i__1938000189__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1938000189__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_go_run__main_A_New() *A_arbace_go_run__main_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_go_run__main_A) Ctor() {}
//line :225:1
func (t *A_arbace_go_run__main_A) DoInvoke_O_O__O(self, args__0 any) any {





	var tmp1 any; var root_1735 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = args__0; if linked_1736 == nil { tmp1 = ifn_1737.Invoke_O__O(arg_1738) } else { tmp1 = linked_1736.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1735, arg_1738) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_1, tmp1) { var vec__1938000202__2 any; var tmp2 any = A_arbace_go_run__main_fn__1938000208_A_New_O(args__0); var tmp3 *jrt.Class; var fncls__1788 *jrt.Class = A_arbace_go_run__main_fn__1938000208_A_fn_class
		if fncls__1788 == nil { var fncls__1788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_run__main_fn__1938000208_A_fn_class = fncls__1788d; tmp3 = fncls__1788d } else { tmp3 = fncls__1788 }; vec__1938000202__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :231:1
		var opts__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000202__2, lang.RT_IntCast_J__I_NoInit(0), nil); var args__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000202__2, lang.RT_IntCast_J__I_NoInit(1), nil); var lang__5 any = A_arbace_go_run_A_const_164.Invoke_O__O(opts__3); var vec__1938000205__6 any = args__4; var root__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000205__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ns_name__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1938000205__6, lang.RT_IntCast_J__I_NoInit(1), nil); var pf__9 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp5 any; var root_1789 any = A_arbace_go_run_A_const_154.GetRawRoot__O(); var linked_1790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1789, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1791 lang.IFn








		if linked_1790 == nil { ifn_1791 = lang.IFn_Cast(root_1789) } else { ifn_1791 = nil }; var arg_1792 any = ns_name__8; if linked_1790 == nil { tmp5 = ifn_1791.Invoke_O__O(arg_1792) } else { tmp5 = linked_1790.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1789, arg_1792) }
//line :231:1
		pf__9 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, root__7, nil, tmp5)))









		if jrt.NN(jrt.File_Cast(pf__9)).IsFile__Z() { } else { var root_1827 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, A_arbace_go_run_fail_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = A_arbace_go_run_A_const_64; var arg_1831 any = Lit_4; var arg_1832 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__9)).Ref(); if linked_1828 == nil { ifn_1829.Invoke_O_O_O__O(arg_1830, arg_1831, arg_1832) } else { linked_1828.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1827, arg_1830, arg_1831, arg_1832) } }
		var tmp6 any = A_arbace_go_run__main_fn__1938000211_A_New_O_O_O_O(lang__5, pf__9, root__7, opts__3); var tmp7 *jrt.Class; var fncls__1826 *jrt.Class = A_arbace_go_run__main_fn__1938000211_A_fn_class; if fncls__1826 == nil { var fncls__1826d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_run__main_fn__1938000211_A_fn_class = fncls__1826d; tmp7 = fncls__1826d } else { tmp7 = fncls__1826 }; jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O())) }
//line :225:1
	var vec__1938000213__2 any = args__0; var seq__1938000214__3 any; var root_1679 any = A_arbace_go_run_A_const_32.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1681 lang.IFn
























	if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = vec__1938000213__2; if linked_1680 == nil { seq__1938000214__3 = ifn_1681.Invoke_O__O(arg_1682) } else { seq__1938000214__3 = linked_1680.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1679, arg_1682) }
//line :225:1
	var first__1938000215__4 any; var root_1683 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1685 lang.IFn
























	if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = seq__1938000214__3; if linked_1684 == nil { first__1938000215__4 = ifn_1685.Invoke_O__O(arg_1686) } else { first__1938000215__4 = linked_1684.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1683, arg_1686) }
//line :225:1
	var seq__1938000214__5 any; var root_1687 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1689 lang.IFn
























	if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any = seq__1938000214__3; if linked_1688 == nil { seq__1938000214__5 = ifn_1689.Invoke_O__O(arg_1690) } else { seq__1938000214__5 = linked_1688.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1687, arg_1690) }
//line :225:1
	var root__6 any = first__1938000215__4; var first__1938000215__7 any; var root_1691 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1693 lang.IFn
























	if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = seq__1938000214__5; if linked_1692 == nil { first__1938000215__7 = ifn_1693.Invoke_O__O(arg_1694) } else { first__1938000215__7 = linked_1692.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1691, arg_1694) }
//line :225:1
	var seq__1938000214__8 any; var root_1695 any = A_arbace_go_run_A_const_56.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1697 lang.IFn
























	if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = seq__1938000214__5; if linked_1696 == nil { seq__1938000214__8 = ifn_1697.Invoke_O__O(arg_1698) } else { seq__1938000214__8 = linked_1696.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1695, arg_1698) }
//line :225:1
	var ns_name__9 any = first__1938000215__7; var pargs__10 any = seq__1938000214__8; var tmp8 any
	var and__1927000168__auto____11 any = root__6
























	if jrt.J2g_Truth(and__1927000168__auto____11) { tmp8 = ns_name__9 } else { tmp8 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp8) { } else {
		var root_1841 any = A_arbace_go_run_A_const_18.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_run_A_const_19.GetRawRoot__O()); var tmp10 any = A_arbace_go_run_A_const_20; var arg_1844 any = tmp9.Invoke_O_O__O(tmp10, A_arbace_go_run_A_const_21.Get__O()); if linked_1842 == nil { ifn_1843.Invoke_O__O(arg_1844) } else { linked_1842.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1841, arg_1844) }; var tmp11 any = A_arbace_go_run__main_fn__1938000216_A_New(); var tmp12 *jrt.Class; var fncls__1840 *jrt.Class = A_arbace_go_run__main_fn__1938000216_A_fn_class; if fncls__1840 == nil { var fncls__1840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_run__main_fn__1938000216_A_fn_class = fncls__1840d; tmp12 = fncls__1840d } else { tmp12 = fncls__1840 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :225:1
	var pf__11 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3, nil); var tmp14 any; var root_1699 any = A_arbace_go_run_A_const_154.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_1701 lang.IFn




























	if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = ns_name__9; if linked_1700 == nil { tmp14 = ifn_1701.Invoke_O__O(arg_1702) } else { tmp14 = linked_1700.(*aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_1699, arg_1702) }
//line :225:1
	pf__11 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, root__6, nil, tmp14)))





























	if jrt.NN(jrt.File_Cast(pf__11)).IsFile__Z() { } else {
		var root_1850 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, A_arbace_go_run_fail_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = A_arbace_go_run_A_const_64; var arg_1854 any = Lit_4; var arg_1855 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, pf__11)).Ref(); if linked_1851 == nil { ifn_1852.Invoke_O_O_O__O(arg_1853, arg_1854, arg_1855) } else { linked_1851.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1850, arg_1853, arg_1854, arg_1855) } }
//line :225:1
	var status__12 any; var tmp15 any = A_arbace_go_run__main_fn__1938000218_A_New_O_O_O(pargs__10, pf__11, root__6); var tmp16 *jrt.Class
	var fncls__1734 /*line :225:1*/*jrt.Class = A_arbace_go_run__main_fn__1938000218_A_fn_class































	if fncls__1734 == nil { var fncls__1734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_run__main_fn__1938000218_A_fn_class = fncls__1734d; tmp16 = fncls__1734d } else { tmp16 = fncls__1734 }; status__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil).Invoke__O()








	jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__12)); return nil }
//line :232:1
func A_arbace_go_run__main_fn__1938000208_A_New_O(p0 any) *A_arbace_go_run__main_fn__1938000208_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000208_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_go_run__main_fn__1938000208_A) Ctor_O(c__args any) { t.F_args = c__args }
//line :232:1
func (t *A_arbace_go_run__main_fn__1938000208_A) Invoke_O__O(self any) any { { var opts__1 any = lang.PersistentArrayMap_EMPTY.Ref(); var as__2 any; var root_1739 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any; var t_ any = t.F_args; t.F_args = nil; arg_1742 = t_; if linked_1740 == nil { as__2 = ifn_1741.Invoke_O__O(arg_1742) } else { as__2 = linked_1740.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1739, arg_1742) }; L1: for { var G__1938000209__3_ any; var root_1743 any = A_arbace_go_run_A_const_15.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1743, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1745 lang.IFn
										if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any = as__2; if linked_1744 == nil { G__1938000209__3_ = ifn_1745.Invoke_O__O(arg_1746) } else { G__1938000209__3_ = linked_1744.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1743, arg_1746) }; switch lang.Util_Hash_O__I_NoInit(G__1938000209__3_) >> 1 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000209__3_, Lit_9) {


		var tmp1 any; var root_1748 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = opts__1; var arg_1752 any = A_arbace_go_run_A_const_160; var arg_1753 any = jrt.Boolean_TRUE.Ref(); if linked_1749 == nil { tmp1 = ifn_1750.Invoke_O_O_O__O(arg_1751, arg_1752, arg_1753) } else { tmp1 = linked_1749.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1748, arg_1751, arg_1752, arg_1753) }; var tmp2 any = tmp1; var tmp3 any; var root_1754 any = A_arbace_go_run_A_const_43.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = as__2; if linked_1755 == nil { tmp3 = ifn_1756.Invoke_O__O(arg_1757) } else { tmp3 = linked_1755.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1754, arg_1757) }; opts__1, as__2 = tmp2, tmp3; continue L1 }
//line :233:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000209__3_, Lit_10) {

		var tmp4 any; var root_1758 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = opts__1; var arg_1762 any = A_arbace_go_run_A_const_161; var arg_1763 any; var tmp5 any; var root_1764 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = as__2; if linked_1765 == nil { tmp5 = ifn_1766.Invoke_O__O(arg_1767) } else { tmp5 = linked_1765.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1764, arg_1767) }; arg_1763 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp5))).Ref(); if linked_1759 == nil { tmp4 = ifn_1760.Invoke_O_O_O__O(arg_1761, arg_1762, arg_1763) } else { tmp4 = linked_1759.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1758, arg_1761, arg_1762, arg_1763) }; var tmp6 any = tmp4; var tmp7 any; var root_1768 any = A_arbace_go_run_A_const_162.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1772 any = as__2; if linked_1769 == nil { tmp7 = ifn_1770.Invoke_O_O__O(A_arbace_go_run_A_const_163, arg_1772) } else { tmp7 = linked_1769.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1768, 2, A_arbace_go_run_A_const_163, arg_1772) }; opts__1, as__2 = tmp6, tmp7; continue L1 }
//line :233:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1938000209__3_, Lit_11) {
		var tmp8 any; var root_1773 any = A_arbace_go_run_A_const_92.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = opts__1; var arg_1777 any = A_arbace_go_run_A_const_164; var arg_1778 any; var root_1779 any = A_arbace_go_run_A_const_70.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = as__2; if linked_1780 == nil { arg_1778 = ifn_1781.Invoke_O__O(arg_1782) } else { arg_1778 = linked_1780.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1779, arg_1782) }; if linked_1774 == nil { tmp8 = ifn_1775.Invoke_O_O_O__O(arg_1776, arg_1777, arg_1778) } else { tmp8 = linked_1774.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1773, arg_1776, arg_1777, arg_1778) }; var tmp9 any = tmp8; var tmp10 any; var root_1783 any = A_arbace_go_run_A_const_162.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1787 any = as__2; if linked_1784 == nil { tmp10 = ifn_1785.Invoke_O_O__O(A_arbace_go_run_A_const_163, arg_1787) } else { tmp10 = linked_1784.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1783, 2, A_arbace_go_run_A_const_163, arg_1787) }; opts__1, as__2 = tmp9, tmp10; continue L1 }
//line :233:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__1, as__2) } }; /*line :232:1*/panic("j2g: unreachable") }









func A_arbace_go_run__main_fn__1938000211_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_run__main_fn__1938000211_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000211_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :242:1
func (t *A_arbace_go_run__main_fn__1938000211_A) Ctor_O_O_O_O(c__lang, c__pf, c__root, c__opts any) { t.F_lang = c__lang; t.F_pf = c__pf; t.F_root = c__root; t.F_opts = c__opts }
//line :242:1
func (t *A_arbace_go_run__main_fn__1938000211_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1793 any = A_arbace_go_run_A_const_165.GetRawRoot__O(); var linked_1794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1793, A_arbace_go_run_errorcheck_A_fn_class); var ifn_1795 lang.IFn; if linked_1794 == nil { ifn_1795 = lang.IFn_Cast(root_1793) } else { ifn_1795 = nil }; var arg_1796 any; var t_ any = t.F_root; t.F_root = nil; arg_1796 = t_; var arg_1797 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1797 = t__2; var arg_1798 any; var t__3 any = t.F_lang; t.F_lang = nil; arg_1798 = t__3; var arg_1799 any = A_arbace_go_run_A_const_161.Invoke_O__O(t.F_opts); var arg_1800 any; var tmp2 *lang.Keyword = A_arbace_go_run_A_const_160; var tmp3 any; var t__4 any = t.F_opts; t.F_opts = nil; tmp3 = t__4; arg_1800 = tmp2.Invoke_O__O(tmp3); if linked_1794 == nil { tmp1 = ifn_1795.Invoke_O_O_O_O_O__O(arg_1796, arg_1797, arg_1798, arg_1799, arg_1800) } else { tmp1 = linked_1794.(*A_arbace_go_run_errorcheck_A).Invoke_O_O_O_O_O_O__O(root_1793, arg_1796, arg_1797, arg_1798, arg_1799, arg_1800) } }; return nil }(); if tmp4 != nil { if true { var ex__3 jrt.Throwable_I = tmp4; var d__4 any; var root_1801 any = A_arbace_go_run_A_const_156.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1803 lang.IFn

	if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = ex__3; if linked_1802 == nil { d__4 = ifn_1803.Invoke_O__O(arg_1804) } else { d__4 = linked_1802.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1801, arg_1804) }
//line :242:1
	var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_157.Invoke_O__O(d__4)


	if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
		if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp5 any; var root_1805 any = A_arbace_go_run_A_const_158.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = m__7; var arg_1809 any = Lit_12; if linked_1806 == nil { tmp5 = ifn_1807.Invoke_O_O__O(arg_1808, arg_1809) } else { tmp5 = linked_1806.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1805, arg_1808, arg_1809) }; if jrt.J2g_Truth(tmp5) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
	if jrt.J2g_Truth(u__5) {
		var root_1810 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, A_arbace_go_run_fail_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = A_arbace_go_run_A_const_49; var arg_1814 any = Lit_13; var arg_1815 any = u__5; if linked_1811 == nil { tmp1 = ifn_1812.Invoke_O_O_O__O(arg_1813, arg_1814, arg_1815) } else { tmp1 = linked_1811.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1810, arg_1813, arg_1814, arg_1815) } } else {
			var root_1816 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, A_arbace_go_run_fail_A_fn_class); var ifn_1818 lang.IFn; if linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any = A_arbace_go_run_A_const_64; var arg_1820 any = Lit_4; var arg_1821 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil); var tmp7 any; var root_1822 any = A_arbace_go_run_A_const_159.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = ex__3; if linked_1823 == nil { tmp7 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp7 = linked_1823.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1822, arg_1825) }; arg_1821 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp7)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1817 == nil { tmp1 = ifn_1818.Invoke_O_O_O__O(arg_1819, arg_1820, arg_1821) } else { tmp1 = linked_1817.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1816, arg_1819, arg_1820, arg_1821) } } } }; return tmp1 }


func A_arbace_go_run__main_fn__1938000216_A_New() *A_arbace_go_run__main_fn__1938000216_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000216_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_go_run__main_fn__1938000216_A) Ctor() {}
//line :252:1
func (t *A_arbace_go_run__main_fn__1938000216_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_go_run_A_const_14.GetRawRoot__O()).Invoke_O__O(Lit_15); return nil }(); var root_1837 any = A_arbace_go_run_A_const_13.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; if linked_1838 == nil { ifn_1839.Invoke__O() } else { linked_1838.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1837) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }




func A_arbace_go_run__main_fn__1938000218_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_run__main_fn__1938000218_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run__main_fn__1938000218_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_go_run__main_fn__1938000218_A) Ctor_O_O_O(c__pargs, c__pf, c__root any) { t.F_pargs = c__pargs; t.F_pf = c__pf; t.F_root = c__root }
//line :257:1
func (t *A_arbace_go_run__main_fn__1938000218_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var root_1703 any = A_arbace_go_run_A_const_155.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, A_arbace_go_run_run_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any; var t_ any = t.F_root; t.F_root = nil; arg_1706 = t_; var arg_1707 any; var t__2 any = t.F_pf; t.F_pf = nil; arg_1707 = t__2; var arg_1708 any; var t__3 any = t.F_pargs; t.F_pargs = nil; arg_1708 = t__3; if linked_1704 == nil { tmp1 = ifn_1705.Invoke_O_O_O__O(arg_1706, arg_1707, arg_1708) } else { tmp1 = linked_1704.(*A_arbace_go_run_run_A).Invoke_O_O_O_O__O(root_1703, arg_1706, arg_1707, arg_1708) } }
//line :257:1
	return nil }(); if tmp2 != nil { if true { var ex__3 jrt.Throwable_I = tmp2; var d__4 any; var root_1709 any = A_arbace_go_run_A_const_156.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1711 lang.IFn


		if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = ex__3; if linked_1710 == nil { d__4 = ifn_1711.Invoke_O__O(arg_1712) } else { d__4 = linked_1710.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1709, arg_1712) }
//line :257:1
		var u__5 any; var or__1927000174__auto____5 any = A_arbace_go_run_A_const_157.Invoke_O__O(d__4)



		if jrt.J2g_Truth(or__1927000174__auto____5) { u__5 = or__1927000174__auto____5 } else { var temp__1927000414__auto____6 any = ex__3.GetMessage__String().Ref()
			if jrt.J2g_Truth(temp__1927000414__auto____6) { var m__7 any = temp__1927000414__auto____6; var tmp3 any; var root_1713 any = A_arbace_go_run_A_const_158.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = m__7; var arg_1717 any = Lit_12; if linked_1714 == nil { tmp3 = ifn_1715.Invoke_O_O__O(arg_1716, arg_1717) } else { tmp3 = linked_1714.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_1713, arg_1716, arg_1717) }; if jrt.J2g_Truth(tmp3) { u__5 = m__7 } else { u__5 = nil } } else { u__5 = nil } }
		if jrt.J2g_Truth(u__5) {
			var root_1718 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, A_arbace_go_run_fail_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = A_arbace_go_run_A_const_49; var arg_1722 any = Lit_13; var arg_1723 any = u__5; if linked_1719 == nil { tmp1 = ifn_1720.Invoke_O_O_O__O(arg_1721, arg_1722, arg_1723) } else { tmp1 = linked_1719.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1718, arg_1721, arg_1722, arg_1723) } } else {
				var root_1724 any = A_arbace_go_run_A_const_48.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, A_arbace_go_run_fail_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = A_arbace_go_run_A_const_64; var arg_1728 any = Lit_4; var arg_1729 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil); var tmp5 any; var root_1730 any = A_arbace_go_run_A_const_159.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = ex__3; if linked_1731 == nil { tmp5 = ifn_1732.Invoke_O__O(arg_1733) } else { tmp5 = linked_1731.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_1730, arg_1733) }; arg_1729 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp5)).GetName__String().Ref(), nil, ex__3.GetMessage__String().Ref())).Ref(); if linked_1725 == nil { tmp1 = ifn_1726.Invoke_O_O_O__O(arg_1727, arg_1728, arg_1729) } else { tmp1 = linked_1725.(*A_arbace_go_run_fail_A).Invoke_O_O_O_O__O(root_1724, arg_1727, arg_1728, arg_1729) } } } }; return tmp1 }







































































































type A_arbace_go_run_A struct{ jrt.Object }

var A_arbace_go_run_A_const_pool *jrt.RefArray

var A_arbace_go_run_A_const_0 *lang.Var

var A_arbace_go_run_A_const_1 any

var A_arbace_go_run_A_const_2 *lang.Var

var A_arbace_go_run_A_const_3 any

var A_arbace_go_run_A_const_4 any

var A_arbace_go_run_A_const_5 any

var A_arbace_go_run_A_const_6 any

var A_arbace_go_run_A_const_7 *lang.Var

var A_arbace_go_run_A_const_8 *lang.Var

var A_arbace_go_run_A_const_9 *lang.Var

var A_arbace_go_run_A_const_10 *lang.Var

var A_arbace_go_run_A_const_11 any

var A_arbace_go_run_A_const_12 *lang.Var

var A_arbace_go_run_A_const_13 *lang.Var

var A_arbace_go_run_A_const_14 *lang.Var

var A_arbace_go_run_A_const_15 *lang.Var

var A_arbace_go_run_A_const_16 *lang.Var

var A_arbace_go_run_A_const_17 *lang.Var

var A_arbace_go_run_A_const_18 *lang.Var

var A_arbace_go_run_A_const_19 *lang.Var

var A_arbace_go_run_A_const_20 *lang.Var

var A_arbace_go_run_A_const_21 *lang.Var

var A_arbace_go_run_A_const_22 *lang.Var

var A_arbace_go_run_A_const_23 *lang.Var

var A_arbace_go_run_A_const_24 *lang.Var

var A_arbace_go_run_A_const_25 *lang.Var

var A_arbace_go_run_A_const_26 *lang.Var

var A_arbace_go_run_A_const_27 *lang.Var

var A_arbace_go_run_A_const_28 any

var A_arbace_go_run_A_const_29 *lang.Keyword

var A_arbace_go_run_A_const_30 *lang.Var

var A_arbace_go_run_A_const_31 *lang.Var

var A_arbace_go_run_A_const_32 *lang.Var

var A_arbace_go_run_A_const_33 *lang.Var

var A_arbace_go_run_A_const_34 *lang.Var

var A_arbace_go_run_A_const_35 *lang.Var

var A_arbace_go_run_A_const_36 *lang.Var

var A_arbace_go_run_A_const_37 *lang.Var

var A_arbace_go_run_A_const_38 *lang.Var

var A_arbace_go_run_A_const_39 *lang.Var

var A_arbace_go_run_A_const_40 *lang.Var

var A_arbace_go_run_A_const_41 *lang.Var

var A_arbace_go_run_A_const_42 *lang.Var

var A_arbace_go_run_A_const_43 *lang.Var

var A_arbace_go_run_A_const_44 *lang.Var

var A_arbace_go_run_A_const_45 *lang.Var

var A_arbace_go_run_A_const_46 *lang.Var

var A_arbace_go_run_A_const_47 any

var A_arbace_go_run_A_const_48 *lang.Var

var A_arbace_go_run_A_const_49 any

var A_arbace_go_run_A_const_50 *lang.Keyword

var A_arbace_go_run_A_const_51 *lang.Keyword

var A_arbace_go_run_A_const_52 *lang.Keyword

var A_arbace_go_run_A_const_53 *lang.Var

var A_arbace_go_run_A_const_54 *lang.Var

var A_arbace_go_run_A_const_55 *lang.Keyword

var A_arbace_go_run_A_const_56 *lang.Var

var A_arbace_go_run_A_const_57 *lang.Var

var A_arbace_go_run_A_const_58 *lang.Keyword

var A_arbace_go_run_A_const_59 *lang.Var

var A_arbace_go_run_A_const_60 *lang.Var

var A_arbace_go_run_A_const_61 *lang.Keyword

var A_arbace_go_run_A_const_62 *lang.Keyword

var A_arbace_go_run_A_const_63 *lang.Keyword

var A_arbace_go_run_A_const_64 any

var A_arbace_go_run_A_const_65 *lang.Keyword

var A_arbace_go_run_A_const_66 *lang.Keyword

var A_arbace_go_run_A_const_67 any

var A_arbace_go_run_A_const_68 *lang.Var

var A_arbace_go_run_A_const_69 *lang.Var

var A_arbace_go_run_A_const_70 *lang.Var

var A_arbace_go_run_A_const_71 *lang.Var

var A_arbace_go_run_A_const_72 any

var A_arbace_go_run_A_const_73 *lang.Var

var A_arbace_go_run_A_const_74 *lang.Var

var A_arbace_go_run_A_const_75 *lang.Keyword

var A_arbace_go_run_A_const_76 *lang.Var

var A_arbace_go_run_A_const_77 *lang.Var

var A_arbace_go_run_A_const_78 *lang.Var

var A_arbace_go_run_A_const_79 *lang.Var

var A_arbace_go_run_A_const_80 *lang.Var

var A_arbace_go_run_A_const_81 *lang.Keyword

var A_arbace_go_run_A_const_82 *lang.Keyword

var A_arbace_go_run_A_const_83 *lang.Var

var A_arbace_go_run_A_const_84 *lang.Keyword

var A_arbace_go_run_A_const_85 *lang.Keyword

var A_arbace_go_run_A_const_86 *lang.Keyword

var A_arbace_go_run_A_const_87 *lang.Keyword

var A_arbace_go_run_A_const_88 *lang.Var

var A_arbace_go_run_A_const_89 any

var A_arbace_go_run_A_const_90 *lang.Var

var A_arbace_go_run_A_const_91 *lang.Var

var A_arbace_go_run_A_const_92 *lang.Var

var A_arbace_go_run_A_const_93 *lang.Keyword

var A_arbace_go_run_A_const_94 *lang.Keyword

var A_arbace_go_run_A_const_95 *lang.Var

var A_arbace_go_run_A_const_96 *lang.Var

var A_arbace_go_run_A_const_97 *lang.Var

var A_arbace_go_run_A_const_98 *lang.Var

var A_arbace_go_run_A_const_99 *lang.Var

var A_arbace_go_run_A_const_100 *lang.Var

var A_arbace_go_run_A_const_101 *lang.Var

var A_arbace_go_run_A_const_102 *lang.Var

var A_arbace_go_run_A_const_103 *lang.Var

var A_arbace_go_run_A_const_104 *lang.Var

var A_arbace_go_run_A_const_105 *lang.Keyword

var A_arbace_go_run_A_const_106 *lang.Var

var A_arbace_go_run_A_const_107 *lang.Var

var A_arbace_go_run_A_const_108 *lang.Var

var A_arbace_go_run_A_const_109 *lang.Var

var A_arbace_go_run_A_const_110 *lang.Var

var A_arbace_go_run_A_const_111 *lang.Keyword

var A_arbace_go_run_A_const_112 *lang.Var

var A_arbace_go_run_A_const_113 *lang.Var

var A_arbace_go_run_A_const_114 *lang.Var

var A_arbace_go_run_A_const_115 *lang.Var

var A_arbace_go_run_A_const_116 *lang.Var

var A_arbace_go_run_A_const_117 *lang.Var

var A_arbace_go_run_A_const_118 *lang.Var

var A_arbace_go_run_A_const_119 *lang.Var

var A_arbace_go_run_A_const_120 *lang.Var

var A_arbace_go_run_A_const_121 *lang.Var

var A_arbace_go_run_A_const_122 *lang.Keyword

var A_arbace_go_run_A_const_123 *lang.Var

var A_arbace_go_run_A_const_124 *lang.Var

var A_arbace_go_run_A_const_125 *lang.Keyword

var A_arbace_go_run_A_const_126 *lang.Var

var A_arbace_go_run_A_const_127 *lang.Var

var A_arbace_go_run_A_const_128 any

var A_arbace_go_run_A_const_129 *lang.Keyword

var A_arbace_go_run_A_const_130 *lang.Var

var A_arbace_go_run_A_const_131 *lang.Keyword

var A_arbace_go_run_A_const_132 *lang.Keyword

var A_arbace_go_run_A_const_133 *lang.Var

var A_arbace_go_run_A_const_134 *lang.Var

var A_arbace_go_run_A_const_135 any

var A_arbace_go_run_A_const_136 any

var A_arbace_go_run_A_const_137 *lang.Var

var A_arbace_go_run_A_const_138 any

var A_arbace_go_run_A_const_139 *lang.Keyword

var A_arbace_go_run_A_const_140 *lang.Keyword

var A_arbace_go_run_A_const_141 any

var A_arbace_go_run_A_const_142 any

var A_arbace_go_run_A_const_143 *lang.Var

var A_arbace_go_run_A_const_144 any

var A_arbace_go_run_A_const_145 any

var A_arbace_go_run_A_const_146 *lang.Var

var A_arbace_go_run_A_const_147 *lang.Var

var A_arbace_go_run_A_const_148 any

var A_arbace_go_run_A_const_149 *lang.Var

var A_arbace_go_run_A_const_150 any

var A_arbace_go_run_A_const_151 any

var A_arbace_go_run_A_const_152 *lang.Keyword

var A_arbace_go_run_A_const_153 *lang.Keyword

var A_arbace_go_run_A_const_154 *lang.Var

var A_arbace_go_run_A_const_155 *lang.Var

var A_arbace_go_run_A_const_156 *lang.Var

var A_arbace_go_run_A_const_157 *lang.Keyword

var A_arbace_go_run_A_const_158 *lang.Var

var A_arbace_go_run_A_const_159 *lang.Var

var A_arbace_go_run_A_const_160 *lang.Keyword

var A_arbace_go_run_A_const_161 *lang.Keyword

var A_arbace_go_run_A_const_162 *lang.Var

var A_arbace_go_run_A_const_163 any

var A_arbace_go_run_A_const_164 *lang.Keyword

var A_arbace_go_run_A_const_165 *lang.Var

var A_arbace_go_run_A_init jrt.ClassInit

func A_arbace_go_run_A_Init() { if !A_arbace_go_run_A_init.Done() { A_arbace_go_run_A_init.Run(A_arbace_go_run_A_clinit) } }

func A_arbace_go_run_A_clinit() { A_arbace_go_run_A_clinit_p0(); A_arbace_go_run_A_clinit_p1(); A_arbace_go_run_A_clinit_p2(); A_arbace_go_run_A_clinit_p3(); A_arbace_go_run_A_clinit_p4(); A_arbace_go_run_A_clinit_p5(); A_arbace_go_run_A_clinit_p6(); A_arbace_go_run_A_clinit_p7(); A_arbace_go_run_A_clinit_p8(); A_arbace_go_run_A_clinit_p9(); A_arbace_go_run_A_clinit_p10(); A_arbace_go_run_A_clinit_p11(); A_arbace_go_run_A_clinit_p12(); A_arbace_go_run_A_clinit_p13() }

func A_arbace_go_run_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_run_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 219); A_arbace_go_run_A_const_0 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[53]); A_arbace_go_run_A_const_1 = A_arbace_go_run_A_const_pool.A[54]; A_arbace_go_run_A_const_2 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[55]); A_arbace_go_run_A_const_3 = A_arbace_go_run_A_const_pool.A[56]; A_arbace_go_run_A_const_4 = A_arbace_go_run_A_const_pool.A[57]; A_arbace_go_run_A_const_5 = A_arbace_go_run_A_const_pool.A[58]; A_arbace_go_run_A_const_6 = A_arbace_go_run_A_const_pool.A[59]; A_arbace_go_run_A_const_7 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[60]); A_arbace_go_run_A_const_8 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[61]); A_arbace_go_run_A_const_9 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[62]); A_arbace_go_run_A_const_10 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[63]); A_arbace_go_run_A_const_11 = A_arbace_go_run_A_const_pool.A[64] }

func A_arbace_go_run_A_clinit_p1() { A_arbace_go_run_A_const_12 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[65]); A_arbace_go_run_A_const_13 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[66]); A_arbace_go_run_A_const_14 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[67]); A_arbace_go_run_A_const_15 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[68]); A_arbace_go_run_A_const_16 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[69]); A_arbace_go_run_A_const_17 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[70]); A_arbace_go_run_A_const_18 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[71]); A_arbace_go_run_A_const_19 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[72]); A_arbace_go_run_A_const_20 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[73]); A_arbace_go_run_A_const_21 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[74]); A_arbace_go_run_A_const_22 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[75]); A_arbace_go_run_A_const_23 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[76]) }

func A_arbace_go_run_A_clinit_p2() { A_arbace_go_run_A_const_24 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[77]); A_arbace_go_run_A_const_25 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[78]); A_arbace_go_run_A_const_26 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[79]); A_arbace_go_run_A_const_27 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[80]); A_arbace_go_run_A_const_28 = A_arbace_go_run_A_const_pool.A[81]; A_arbace_go_run_A_const_29 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[82]); A_arbace_go_run_A_const_30 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[83]); A_arbace_go_run_A_const_31 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[84]); A_arbace_go_run_A_const_32 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[85]); A_arbace_go_run_A_const_33 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[86]); A_arbace_go_run_A_const_34 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[87]); A_arbace_go_run_A_const_35 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[88]) }

func A_arbace_go_run_A_clinit_p3() { A_arbace_go_run_A_const_36 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[89]); A_arbace_go_run_A_const_37 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[90]); A_arbace_go_run_A_const_38 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[91]); A_arbace_go_run_A_const_39 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[92]); A_arbace_go_run_A_const_40 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[93]); A_arbace_go_run_A_const_41 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[94]); A_arbace_go_run_A_const_42 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[95]); A_arbace_go_run_A_const_43 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[96]); A_arbace_go_run_A_const_44 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[97]); A_arbace_go_run_A_const_45 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[98]); A_arbace_go_run_A_const_46 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[99]); A_arbace_go_run_A_const_47 = A_arbace_go_run_A_const_pool.A[100] }

func A_arbace_go_run_A_clinit_p4() { A_arbace_go_run_A_const_48 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[101]); A_arbace_go_run_A_const_49 = A_arbace_go_run_A_const_pool.A[102]; A_arbace_go_run_A_const_50 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[103]); A_arbace_go_run_A_const_51 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[104]); A_arbace_go_run_A_const_52 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[105]); A_arbace_go_run_A_const_53 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[106]); A_arbace_go_run_A_const_54 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[107]); A_arbace_go_run_A_const_55 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[108]); A_arbace_go_run_A_const_56 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[109]); A_arbace_go_run_A_const_57 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[110]); A_arbace_go_run_A_const_58 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[111]); A_arbace_go_run_A_const_59 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[112]) }

func A_arbace_go_run_A_clinit_p5() { A_arbace_go_run_A_const_60 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[113]); A_arbace_go_run_A_const_61 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[114]); A_arbace_go_run_A_const_62 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[115]); A_arbace_go_run_A_const_63 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[116]); A_arbace_go_run_A_const_64 = A_arbace_go_run_A_const_pool.A[117]; A_arbace_go_run_A_const_65 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[118]); A_arbace_go_run_A_const_66 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[119]); A_arbace_go_run_A_const_67 = A_arbace_go_run_A_const_pool.A[120]; A_arbace_go_run_A_const_68 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[121]); A_arbace_go_run_A_const_69 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[122]); A_arbace_go_run_A_const_70 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[123]); A_arbace_go_run_A_const_71 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[124]) }

func A_arbace_go_run_A_clinit_p6() { A_arbace_go_run_A_const_72 = A_arbace_go_run_A_const_pool.A[125]; A_arbace_go_run_A_const_73 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[126]); A_arbace_go_run_A_const_74 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[127]); A_arbace_go_run_A_const_75 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[128]); A_arbace_go_run_A_const_76 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[129]); A_arbace_go_run_A_const_77 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[130]); A_arbace_go_run_A_const_78 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[131]); A_arbace_go_run_A_const_79 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[132]); A_arbace_go_run_A_const_80 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[133]); A_arbace_go_run_A_const_81 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[134]); A_arbace_go_run_A_const_82 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[135]); A_arbace_go_run_A_const_83 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[136]) }

func A_arbace_go_run_A_clinit_p7() { A_arbace_go_run_A_const_84 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[137]); A_arbace_go_run_A_const_85 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[138]); A_arbace_go_run_A_const_86 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[139]); A_arbace_go_run_A_const_87 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[140]); A_arbace_go_run_A_const_88 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[141]); A_arbace_go_run_A_const_89 = A_arbace_go_run_A_const_pool.A[142]; A_arbace_go_run_A_const_90 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[143]); A_arbace_go_run_A_const_91 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[144]); A_arbace_go_run_A_const_92 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[145]); A_arbace_go_run_A_const_93 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[146]); A_arbace_go_run_A_const_94 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[147]); A_arbace_go_run_A_const_95 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[148]) }

func A_arbace_go_run_A_clinit_p8() { A_arbace_go_run_A_const_96 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[149]); A_arbace_go_run_A_const_97 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[150]); A_arbace_go_run_A_const_98 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[151]); A_arbace_go_run_A_const_99 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[152]); A_arbace_go_run_A_const_100 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[153]); A_arbace_go_run_A_const_101 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[154]); A_arbace_go_run_A_const_102 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[155]); A_arbace_go_run_A_const_103 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[156]); A_arbace_go_run_A_const_104 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[157]); A_arbace_go_run_A_const_105 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[158]); A_arbace_go_run_A_const_106 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[159]); A_arbace_go_run_A_const_107 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[160]) }

func A_arbace_go_run_A_clinit_p9() { A_arbace_go_run_A_const_108 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[161]); A_arbace_go_run_A_const_109 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[162]); A_arbace_go_run_A_const_110 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[163]); A_arbace_go_run_A_const_111 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[164]); A_arbace_go_run_A_const_112 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[165]); A_arbace_go_run_A_const_113 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[166]); A_arbace_go_run_A_const_114 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[167]); A_arbace_go_run_A_const_115 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[168]); A_arbace_go_run_A_const_116 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[169]); A_arbace_go_run_A_const_117 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[170]); A_arbace_go_run_A_const_118 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[171]); A_arbace_go_run_A_const_119 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[172]) }

func A_arbace_go_run_A_clinit_p10() { A_arbace_go_run_A_const_120 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[173]); A_arbace_go_run_A_const_121 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[174]); A_arbace_go_run_A_const_122 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[175]); A_arbace_go_run_A_const_123 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[176]); A_arbace_go_run_A_const_124 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[177]); A_arbace_go_run_A_const_125 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[178]); A_arbace_go_run_A_const_126 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[179]); A_arbace_go_run_A_const_127 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[180]); A_arbace_go_run_A_const_128 = A_arbace_go_run_A_const_pool.A[181]; A_arbace_go_run_A_const_129 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[182]); A_arbace_go_run_A_const_130 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[183]); A_arbace_go_run_A_const_131 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[184]) }

func A_arbace_go_run_A_clinit_p11() { A_arbace_go_run_A_const_132 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[185]); A_arbace_go_run_A_const_133 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[186]); A_arbace_go_run_A_const_134 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[187]); A_arbace_go_run_A_const_135 = A_arbace_go_run_A_const_pool.A[188]; A_arbace_go_run_A_const_136 = A_arbace_go_run_A_const_pool.A[189]; A_arbace_go_run_A_const_137 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[190]); A_arbace_go_run_A_const_138 = A_arbace_go_run_A_const_pool.A[191]; A_arbace_go_run_A_const_139 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[192]); A_arbace_go_run_A_const_140 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[193]); A_arbace_go_run_A_const_141 = A_arbace_go_run_A_const_pool.A[194]; A_arbace_go_run_A_const_142 = A_arbace_go_run_A_const_pool.A[195]; A_arbace_go_run_A_const_143 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[196]); A_arbace_go_run_A_const_144 = A_arbace_go_run_A_const_pool.A[197] }

func A_arbace_go_run_A_clinit_p12() { A_arbace_go_run_A_const_145 = A_arbace_go_run_A_const_pool.A[198]; A_arbace_go_run_A_const_146 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[199]); A_arbace_go_run_A_const_147 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[200]); A_arbace_go_run_A_const_148 = A_arbace_go_run_A_const_pool.A[201]; A_arbace_go_run_A_const_149 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[202]); A_arbace_go_run_A_const_150 = A_arbace_go_run_A_const_pool.A[203]; A_arbace_go_run_A_const_151 = A_arbace_go_run_A_const_pool.A[204]; A_arbace_go_run_A_const_152 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[205]); A_arbace_go_run_A_const_153 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[206]); A_arbace_go_run_A_const_154 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[207]); A_arbace_go_run_A_const_155 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[208]); A_arbace_go_run_A_const_156 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[209]); A_arbace_go_run_A_const_157 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[210]) }

func A_arbace_go_run_A_clinit_p13() { A_arbace_go_run_A_const_158 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[211]); A_arbace_go_run_A_const_159 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[212]); A_arbace_go_run_A_const_160 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[213]); A_arbace_go_run_A_const_161 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[214]); A_arbace_go_run_A_const_162 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[215]); A_arbace_go_run_A_const_163 = A_arbace_go_run_A_const_pool.A[216]; A_arbace_go_run_A_const_164 = lang.Keyword_Cast(A_arbace_go_run_A_const_pool.A[217]); A_arbace_go_run_A_const_165 = lang.Var_Cast(A_arbace_go_run_A_const_pool.A[218]) }

func A_arbace_go_run_A_New() *A_arbace_go_run_A { A_arbace_go_run_A_Init(); t := &A_arbace_go_run_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_A) Ctor() {}

func (t *A_arbace_go_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_A_class }

func (t *A_arbace_go_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_A); return ok }

func A_arbace_go_run_A_Cast(x any) *A_arbace_go_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_A_class)) }; return v }



type A_arbace_go_run__main_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000208_A struct{ j2g_header uint64; F_args any }

var A_arbace_go_run__main_fn__1938000208_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000211_A struct{ j2g_header uint64; F_lang, F_pf, F_root, F_opts any }

var A_arbace_go_run__main_fn__1938000211_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000216_A struct{ j2g_header uint64 }

var A_arbace_go_run__main_fn__1938000216_A_fn_class *jrt.Class



type A_arbace_go_run__main_fn__1938000218_A struct{ j2g_header uint64; F_pargs, F_pf, F_root any }

var A_arbace_go_run__main_fn__1938000218_A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_check_BANG__fn__1938000065_A struct{ j2g_header uint64 }

var A_arbace_go_run_check_BANG__fn__1938000065_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A struct{ j2g_header uint64; F_iter__1938000020, F_s__1938000021 any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A struct{ j2g_header uint64; F_b__1938000023 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_fn_class *jrt.Class



type A_arbace_go_run_dir_test_root_A struct{ j2g_header uint64 }

var A_arbace_go_run_dir_test_root_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000160_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000160_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000160_fn__1938000161_fn__1938000163_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000167_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000167_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000169_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000169_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000171_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000171_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_fn__1938000173_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_fn__1938000173_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A struct{ j2g_header uint64 }

var A_arbace_go_run_errorcheck_iter__1938000175__1938000179_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A struct{ j2g_header uint64; F_iter__1938000175, F_s__1938000176 any }

var A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A struct{ j2g_header uint64; F_b__1938000178 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000175__1938000179_fn__1938000180_fn__1938000181_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A struct{ j2g_header uint64; F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000187__1938000191_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A struct{ j2g_header uint64; F_s__1938000188, F_iter__1938000187, F_vmsg any }

var A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A struct{ j2g_header uint64; F_b__1938000190 any; F_size__1927001038__auto__ int32; F_vmsg, F_c__1927001037__auto__ any }

var A_arbace_go_run_errorcheck_iter__1938000187__1938000191_fn__1938000192_fn__1938000193_A_fn_class *jrt.Class



type A_arbace_go_run_errorcheck_vmsg__1938000185_A struct{ j2g_header uint64; F_file_lang, F_lang, F_src any }

var A_arbace_go_run_errorcheck_vmsg__1938000185_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000004_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000004_A_New() *A_arbace_go_run_eval1938000004_A { t := &A_arbace_go_run_eval1938000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000004_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000004_A_class }

func (t *A_arbace_go_run_eval1938000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000004_A); return ok }

func A_arbace_go_run_eval1938000004_A_Cast(x any) *A_arbace_go_run_eval1938000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000004_A_class)) }; return v }



type A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_fn_class *jrt.Class



type A_arbace_go_run_eval1938000008_A struct{ jrt.Object }

func A_arbace_go_run_eval1938000008_A_New() *A_arbace_go_run_eval1938000008_A { t := &A_arbace_go_run_eval1938000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_run_eval1938000008_A) Ctor() {}

func (t *A_arbace_go_run_eval1938000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_run_eval1938000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_run_eval1938000008_A_class }

func (t *A_arbace_go_run_eval1938000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_run_eval1938000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_run_eval1938000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_run_eval1938000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_run_eval1938000008_A); return ok }

func A_arbace_go_run_eval1938000008_A_Cast(x any) *A_arbace_go_run_eval1938000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_run_eval1938000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_run_eval1938000008_A_class)) }; return v }



type A_arbace_go_run_eval1938000008_fn__1938000009_A struct{ j2g_header uint64 }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_fn_class *jrt.Class



type A_arbace_go_run_fail_A struct{ j2g_header uint64 }

var A_arbace_go_run_fail_A_fn_class *jrt.Class



type A_arbace_go_run_fail_fn__1938000012_A struct{ j2g_header uint64; F_kind, F_msg any }

var A_arbace_go_run_fail_fn__1938000012_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_A struct{ j2g_header uint64 }

var A_arbace_go_run_imports_of_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A struct{ j2g_header uint64; F_s__1938000069, F_iter__1938000068, F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A struct{ j2g_header uint64; F_li any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A struct{ j2g_header uint64; F_s__1938000071, F_li, F_iter__1938000070 any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_fn_class *jrt.Class



type A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A struct{ j2g_header uint64; F_b__1938000073, F_li any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_no_assembly_BANG__fn__1938000032_A struct{ j2g_header uint64 }

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_fn_class *jrt.Class



type A_arbace_go_run_no_linkname_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_run_no_linkname_BANG__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_run_package_file_QMARK__fn__1938000016_A struct{ j2g_header uint64 }

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000120_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000120_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000132_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000132_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000135_A struct{ j2g_header uint64; F_l, F_apos, F_end any }

var A_arbace_go_run_raw_lines_fn__1938000135_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A struct{ j2g_header uint64; F_s__1938000138, F_iter__1938000137 any }

var A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A struct{ j2g_header uint64; F_b__1938000140 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_run_raw_lines_fn__1938000135_iter__1938000137__1938000141_fn__1938000142_fn__1938000143_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000127_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000127_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_lines__1938000127_fn__1938000128_A_fn_class *jrt.Class



type A_arbace_go_run_raw_lines_walk_meta__1938000114_A struct{ j2g_header uint64 }

var A_arbace_go_run_raw_lines_walk_meta__1938000114_A_fn_class *jrt.Class



type A_arbace_go_run_run_A struct{ j2g_header uint64 }

var A_arbace_go_run_run_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_A struct{ j2g_header uint64; F_srcs, F_inits, F_deps any }

var A_arbace_go_run_run_define__1938000091_A_fn_class *jrt.Class



type A_arbace_go_run_run_define__1938000091_fn__1938000092_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_define__1938000091_fn__1938000092_A_fn_class *jrt.Class



type A_arbace_go_run_run_extra__1938000089_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_go_run_run_extra__1938000089_A_fn_class *jrt.Class



type A_arbace_go_run_run_fn__1938000087_A struct{ j2g_header uint64; F_pf any }

var A_arbace_go_run_run_fn__1938000087_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000095_A struct{ j2g_header uint64; F_inits, F_deps any }

var A_arbace_go_run_run_init_order__1938000095_A_fn_class *jrt.Class



type A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A struct{ j2g_header uint64; F_done, F_deps any }

var A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_fn_class *jrt.Class



type A_arbace_go_run_run_load_BANG___1938000099_A struct{ j2g_header uint64; F_root, F_extra, F_srcs, F_index, F_define any }

var A_arbace_go_run_run_load_BANG___1938000099_A_fn_class *jrt.Class
