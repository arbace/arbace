//line j2g_strings.ae:1
package aot_arbace_go_run

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.go.replyn4,replyn20,arbace.go.check.loadyn4,loadyn15,arbace.go.buildyn1,bkn3,dockn4,elsekn4,optskn11,other-fileskn4,pathkn5,fileskn5,declsks2,go8,linknamekn6,errorskn12,BrokenImportkn4,codekn3,msgkn4,filekn4,linekn13,local-importskn7,importskn3,dirkn4,namekn2,nskn6,configkn5,funcskn7,globalskn5,typeskn5,vars?kn5,eagerkn5,initskn10,init-funcskn4,mainks3,goi11,unsupportedv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.go.runm2,R10,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).v11,arbace.core5,flushv11,arbace.core19,pop-thread-bindingsv11,arbace.core7,printlnv11,arbace.core5,firstv13,arbace.string11,split-linesv11,arbace.core3,strv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v13,arbace.string10,ends-with?v11,arbace.core6,removev13,arbace.string6,blank?v13,arbace.string12,starts-with?v11,arbace.core8,line-seqv13,arbace.string7,replacep5,\\.ae$R11,v13,arbace.go.run13,dir-test-rootv11,arbace.core4,intov11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv13,arbace.go.run13,package-file?v20,arbace.go.check.load15,package-path-ofv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core8,file-seqv11,arbace.core4,somev11,arbace.core6,get-inV2,R12,R13,v13,arbace.go.run4,faill125,R14,R15,R16,v11,arbace.core8,tree-seqv11,arbace.core5,coll?R17,v11,arbace.core4,nextv14,arbace.go.repl12,check-sourceR18,v13,arbace.go.run12,no-assembly!v13,arbace.go.run12,no-linkname!R19,R20,R21,l126,R22,R23,V2,R12,R24,v11,arbace.core8,distinctv11,arbace.core7,vector?v11,arbace.core6,secondv11,arbace.core7,string?V2,R12,R25,v11,arbace.core6,concatv20,arbace.go.check.load14,package-sourceR26,v14,arbace.go.repl6,configv11,arbace.core6,empty?v13,arbace.go.run14,dir-test-indexv11,arbace.core4,atomv11,arbace.core9,volatile!R27,R28,v11,arbace.core6,symbolR29,R30,R31,R32,v14,arbace.go.repl7,define!m4,R33,FR34,Tv11,arbace.core5,swap!v14,arbace.go.repl8,packagesv11,arbace.core5,assocR35,R36,v11,arbace.core3,setv11,arbace.core6,filterv11,arbace.core9,contains?v13,arbace.go.run10,imports-ofv11,arbace.core4,keysv11,arbace.core4,sortv11,arbace.core6,every?v11,arbace.core4,disjv13,arbace.go.run6,check!v11,arbace.core8,to-arrayR37,v15,arbace.go.build2,opv11,arbace.core6,mapcatv11,arbace.core6,reset!v15,arbace.go.build12,program-modev14,arbace.go.repl7,listed?v20,arbace.go.check.load8,ns->filev13,arbace.go.run3,runv11,arbace.core7,ex-dataR38,v13,arbace.string9,includes?v11,arbace.core5,class")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000115")

var Lit_2 *jrt.String = jrt.Intern("/")

var Lit_3 *jrt.String = jrt.Intern("error")

var Lit_4 *jrt.String = jrt.Intern("no package file ")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000117")

var Lit_6 *jrt.String = jrt.Intern("usage: arbace -m arbace.go.run ROOT NS [ARG...]")

var Lit_7 *jrt.String = jrt.Intern("not supported by goi yet")

var Lit_8 *jrt.String = jrt.Intern("unsupported")

var Lit_9 *jrt.String = jrt.Intern(": ")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.run$check_BANG_$fn__1938000065")

var Lit_11 *jrt.String = jrt.Intern("an import neither in the table nor interpreted: ")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index$iter__1938000020__1938000024")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025$fn__1938000026")

var Lit_15 *jrt.String = jrt.Intern("")

var Lit_16 *jrt.String = jrt.Intern("_dir.ae")

var Lit_17 *jrt.String = jrt.Intern("_dir")

var Lit_18 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_19 *jrt.String = jrt.Intern("java.io.File")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.run$fail$fn__1938000012")

var Lit_21 *jrt.String = jrt.Intern("goi: ")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077$fn__1938000078")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.run$no_assembly_BANG_$fn__1938000032")

var Lit_28 *jrt.String = jrt.Intern("assembly (")

var Lit_29 *jrt.String = jrt.Intern("): out of scope (§1.1)")

var Lit_30 *jrt.String = jrt.Intern(".s")

var Lit_31 *jrt.String = jrt.Intern("go:linkname (")

var Lit_32 *jrt.String = jrt.Intern(".ae")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.run$package_file_QMARK_$fn__1938000016")

var Lit_34 *jrt.String = jrt.Intern("(ns ")

var Lit_35 *jrt.String = jrt.Intern(";")

var Lit_36 *jrt.String = jrt.Intern("no Go files for the configuration")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.run$run$fn__1938000087")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.run$run$extra__1938000089")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.run$run$define__1938000091")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.run$run$init_order__1938000095")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.run$run$load_BANG___1938000099")

var Lit_42 *jrt.String = jrt.Intern("no main function")

var Lit_43 *jrt.String = jrt.Intern("SetOSArgs")

var Lit_44 *jrt.String = jrt.Intern("RunProgram")

var Lit_45 *jrt.String = jrt.Intern("goi.run.")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.run$run$define__1938000091$fn__1938000092")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.run$run$init_order__1938000095$fn__1938000096")

var Lit_48 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn6,statuskn3,tagyn6,Stringkn4,linekn6,columnkn4,fileyn4,Fileyn12,java.io.Fileyn3,srcyn5,extrayn4,rootyn4,argsyn1,&v11,arbace.core5,in-nsMyn13,arbace.go.runm2,R0,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).m2,R0,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).R1,v13,arbace.go.run4,failm10,R2,TR3,L1,V3,R4,Myn4,kindm2,R5,R6,Myn3,msgm2,R5,R6,R7,i19,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run13,package-file?m10,R2,TR3,L1,V1,Myn1,fm2,R5,R10,R7,i25,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run13,dir-test-rootm12,R2,TR3,L1,MV1,Myn2,pfm2,R5,R10,m2,R5,R11,R0,s184,The directory of a directory test's packages (GOI-SPEC.md §11.2) that package file pf belongs\n  to: its nearest ancestor named *_dir, or its sibling STEM_dir for STEM_dir.ae; else nil.R7,i31,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run14,dir-test-indexm12,R2,TR3,L1,V1,Myn2,pfm2,R5,R10,R0,s112,The packages of a directory test: import path -> package file (pf's own and those under its\n  test's directory).R7,i45,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run12,no-assembly!m10,R2,TR3,L1,V1,R12,R7,i58,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run12,no-linkname!m10,R2,TR3,L1,V1,R12,R7,i62,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run6,check!m10,R2,TR3,L1,V2,R12,R13,R7,i68,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run10,imports-ofm12,R2,TR3,L1,V1,R12,R0,s71,The import paths package source src names (its local imports resolved).R7,i79,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run3,runm10,R3,L1,V3,R14,Myn2,pfm2,R5,R10,R15,R0,s207,Runs the program of package file pf (forms root root) with args: its exit status. The\n  interpreted packages it imports (a directory test's) are checked, defined and initialized\n  first, in dependency order.R7,i90,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run5,-mainm10,R3,L1,V2,R16,R15,R0,s44,bin/goi run's Arbace side: ROOT NS [ARG...].R7,i137,R8,i1,R9,s16,arbace/go/run.ae")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.run$eval1938000004$loading__1927001464__auto____1938000005")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.run$eval1938000008$fn__1938000009")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.run$fail")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.run$package_file_QMARK_")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.run$dir_test_root")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.run$no_assembly_BANG_")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.run$no_linkname_BANG_")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.run$check_BANG_")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.run$imports_of")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.run$run")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.run$_main")
