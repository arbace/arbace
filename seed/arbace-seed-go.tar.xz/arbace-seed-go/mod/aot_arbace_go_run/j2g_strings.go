//line j2g_strings.ae:1
package aot_arbace_go_run

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.go.replyn4,replyn20,arbace.go.check.loadyn4,loadyn15,arbace.go.buildyn1,bkn3,dockn3,dirkn5,fileskn6,errorskn4,pathkn4,namekn2,nskn6,configkn5,funcskn7,globalskn5,typeskn5,vars?kn5,eagerkn5,initskn10,init-funcskn4,mainkn12,BrokenImportkn4,codekn3,msgkn4,filekn4,lineks3,goi11,unsupportedv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.go.runm2,R10,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).v11,arbace.core5,flushv11,arbace.core19,pop-thread-bindingsv11,arbace.core7,printlnv11,arbace.core5,firstv13,arbace.string11,split-linesv11,arbace.core3,strv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v20,arbace.go.check.load14,package-sourceR11,v14,arbace.go.repl6,configv11,arbace.core6,empty?R12,v13,arbace.go.run4,faill125,v14,arbace.go.repl12,check-sourceR13,v11,arbace.core4,atomR14,R15,R16,v11,arbace.core6,symbolR17,R18,R19,R20,v14,arbace.go.repl7,define!m4,R21,FR22,Tv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqR23,R24,R25,v15,arbace.go.build2,opv11,arbace.core4,consv11,arbace.core4,someR26,R27,R28,l126,R29,R30,v11,arbace.core5,swap!v14,arbace.go.repl8,packagesv11,arbace.core5,assocv20,arbace.go.check.load8,ns->filev13,arbace.go.run3,runv11,arbace.core7,ex-dataR31,v13,arbace.string9,includes?v11,arbace.core5,class")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000024")

var Lit_2 *jrt.String = jrt.Intern("/")

var Lit_3 *jrt.String = jrt.Intern("error")

var Lit_4 *jrt.String = jrt.Intern("no package file ")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000026")

var Lit_6 *jrt.String = jrt.Intern("usage: arbace -m arbace.go.run ROOT NS [ARG...]")

var Lit_7 *jrt.String = jrt.Intern("not supported by goi yet")

var Lit_8 *jrt.String = jrt.Intern("unsupported")

var Lit_9 *jrt.String = jrt.Intern(": ")

var Lit_10 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_11 *jrt.String = jrt.Intern("java.io.File")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.run$fail$fn__1938000012")

var Lit_13 *jrt.String = jrt.Intern("goi: ")

var Lit_14 *jrt.String = jrt.Intern("no Go files for the configuration")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.run$run$fn__1938000016")

var Lit_16 *jrt.String = jrt.Intern("an import neither in the table nor interpreted: ")

var Lit_17 *jrt.String = jrt.Intern("check: ")

var Lit_18 *jrt.String = jrt.Intern(":")

var Lit_19 *jrt.String = jrt.Intern("goi.run.")

var Lit_20 *jrt.String = jrt.Intern("no main function")

var Lit_21 *jrt.String = jrt.Intern("SetOSArgs")

var Lit_22 *jrt.String = jrt.Intern("RunProgram")

var Lit_23 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn6,statuskn3,tagyn6,Stringkn4,linekn6,columnkn4,fileyn4,rootyn4,Fileyn4,argsyn1,&v11,arbace.core5,in-nsMyn13,arbace.go.runm2,R0,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).m2,R0,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).R1,v13,arbace.go.run4,failm10,R2,TR3,L1,V3,R4,Myn4,kindm2,R5,R6,Myn3,msgm2,R5,R6,R7,i19,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run3,runm10,R3,L1,V3,R10,Myn2,pfm2,R5,R11,R12,R0,s81,Runs the program of package file pf (forms root root) with args: its exit status.R7,i25,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run5,-mainm10,R3,L1,V2,R13,R12,R0,s44,bin/goi run's Arbace side: ROOT NS [ARG...].R7,i45,R8,i1,R9,s16,arbace/go/run.ae")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.run$eval1938000004$loading__1927001464__auto____1938000005")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.run$eval1938000008$fn__1938000009")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.run$fail")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.run$run")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.run$_main")
