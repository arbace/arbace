//line j2g_strings.ae:1
package aot_arbace_go_run

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.go.replyn4,replyn20,arbace.go.check.loadyn4,loadyn19,arbace.go.check.envyn3,envyn20,arbace.go.check.codeyn4,codeyn15,arbace.go.buildyn1,bkn3,dockn4,elsekn4,optskn11,other-fileskn4,pathkn5,fileskn5,declsks2,go8,linknamekn6,errorskn12,BrokenImportkn4,codekn3,msgkn4,filekn4,linekn13,local-importskn7,importskn3,dirkn4,namekn2,nskn6,configkn2,pfkn5,funcskn7,globalskn5,typeskn5,vars?kn5,eagerks2,go6,errorskn5,initskn10,init-funcskn4,mainkn3,tagks2,go3,posks2,go4,aposkn7,commentkn6,rbraceks2,go3,endks2,go6,breakskn4,langkn7,answerskn18,AnnotationMismatchkn11,BranchErroryn21,arbace.repr.go.syntaxkn5,linesys21,arbace.repr.go.syntax11,file-errorsys21,arbace.repr.go.syntax11,decl-errorskn11,unsupportedkn10,decl-infosks3,goi11,unsupportedkn3,rawkn5,frontkn3,maxv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.go.runm2,R14,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).v11,arbace.core5,flushv11,arbace.core19,pop-thread-bindingsv11,arbace.core7,printlnv11,arbace.core5,firstv13,arbace.string11,split-linesv11,arbace.core3,strv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v13,arbace.string10,ends-with?v11,arbace.core6,removev13,arbace.string6,blank?v13,arbace.string12,starts-with?v11,arbace.core8,line-seqv13,arbace.string7,replacep5,\\.ae$R15,v13,arbace.go.run13,dir-test-rootv11,arbace.core4,intov11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv13,arbace.go.run13,package-file?v20,arbace.go.check.load15,package-path-ofv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core8,file-seqv11,arbace.core4,somev11,arbace.core6,get-inV2,R16,R17,v13,arbace.go.run4,faill125,R18,R19,R20,v11,arbace.core8,tree-seqv11,arbace.core5,coll?R21,v11,arbace.core4,nextv14,arbace.go.repl12,check-sourceR22,v13,arbace.go.run12,no-assembly!v13,arbace.go.run12,no-linkname!R23,R24,R25,l126,R26,R27,V2,R16,R28,v11,arbace.core8,distinctv11,arbace.core7,vector?v11,arbace.core6,secondv11,arbace.core7,string?V2,R16,R29,v11,arbace.core6,concatv20,arbace.go.check.load14,package-sourceR30,v14,arbace.go.repl6,configv11,arbace.core6,empty?v13,arbace.go.run14,dir-test-indexv11,arbace.core4,atomv11,arbace.core9,volatile!R31,R32,v11,arbace.core6,symbolR33,R16,R34,v11,arbace.core3,vecR35,R36,R37,v14,arbace.go.repl7,define!m4,R38,FR39,TR40,v11,arbace.core7,ex-datav11,arbace.core5,swap!v14,arbace.go.repl8,packagesv11,arbace.core5,assocR41,R42,v11,arbace.core3,setv11,arbace.core6,filterv11,arbace.core9,contains?v13,arbace.go.run10,imports-ofv11,arbace.core4,keysv11,arbace.core4,sortv11,arbace.core6,every?v11,arbace.core4,disjv13,arbace.go.run6,check!v11,arbace.core8,to-arrayR43,v15,arbace.go.build2,opv11,arbace.core6,mapcatv11,arbace.core6,reset!v15,arbace.go.build12,program-modev14,arbace.go.repl7,listed?R44,v11,arbace.core6,updatev13,arbace.go.run9,raw-linesv11,arbace.core4,seq?v11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core3,mapv11,arbace.core4,mapvv11,arbace.core4,map?v11,arbace.core7,symbol?R45,v11,arbace.core4,keepv11,arbace.core4,valsR46,v11,arbace.core3,minv11,arbace.core6,dissocV2,R14,R47,R48,v11,arbace.core9,vary-metaR49,R50,v11,arbace.core5,slurpv11,arbace.core3,notv13,arbace.string9,includes?v11,arbace.core4,subsl7,v11,arbace.core7,re-findp24,^(.*):([0-9]+):([0-9]+)$p15,^(.*):([0-9]+)$v11,arbace.core4,lastv11,arbace.core8,assoc-inV2,R33,R51,V2,R16,R29,v11,arbace.core9,update-inV2,R16,R29,R52,R53,R54,V2,R16,R51,V2,R16,R51,p34,requires go[0-9]+\\.[0-9]+ or laterV2,R33,R51,v13,arbace.go.run8,line-mapp26,(?s)^(.*?):([0-9]+): (.*)$R55,R56,v11,arbace.core7,resolveR57,p17,^(.*?):([0-9]+): l0,v11,arbace.core7,sort-byR58,v20,arbace.go.check.code11,size-errorsv11,arbace.core6,dedupev11,arbace.core4,takep13,^[^:]*:[0-9]+v11,arbace.core4,peekl1,v19,arbace.go.check.env7,*sizes*R59,R60,v20,arbace.go.check.load8,ns->filev13,arbace.go.run3,runR61,v11,arbace.core5,classR62,R51,v11,arbace.core4,dropl2,R63,R64,v13,arbace.go.run10,errorcheck")

var Lit_1 *jrt.String = jrt.Intern("--errorcheck")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000252")

var Lit_3 *jrt.String = jrt.Intern("/")

var Lit_4 *jrt.String = jrt.Intern("error")

var Lit_5 *jrt.String = jrt.Intern("no package file ")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000255")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000260")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.run$_main$fn__1938000262")

var Lit_9 *jrt.String = jrt.Intern("--raw")

var Lit_10 *jrt.String = jrt.Intern("--lang")

var Lit_11 *jrt.String = jrt.Intern("--gc-front")

var Lit_12 *jrt.String = jrt.Intern("--max-errors")

var Lit_13 *jrt.String = jrt.Intern("not supported by goi yet")

var Lit_14 *jrt.String = jrt.Intern("unsupported")

var Lit_15 *jrt.String = jrt.Intern(": ")

var Lit_16 *jrt.String = jrt.Intern("usage: arbace -m arbace.go.run ROOT NS [ARG...]")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.run$check_BANG_$fn__1938000065")

var Lit_18 *jrt.String = jrt.Intern("an import neither in the table nor interpreted: ")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index$iter__1938000020__1938000024")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025$fn__1938000026")

var Lit_22 *jrt.String = jrt.Intern("")

var Lit_23 *jrt.String = jrt.Intern("_dir.ae")

var Lit_24 *jrt.String = jrt.Intern("_dir")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000186")

var Lit_26 *jrt.String = jrt.Intern("no Go files for the configuration")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000193")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000197")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000199")

var Lit_30 *jrt.String = jrt.Intern("a declaration goi's checker does not check (")

var Lit_31 *jrt.String = jrt.Intern("): ")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000202")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000204")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$iter__1938000206__1938000210")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$vmsg__1938000216")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$relocate__1938000218")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$iter__1938000226__1938000230")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$pos__1938000236")

var Lit_39 *jrt.String = jrt.Intern(": too many errors")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000186$fn__1938000187")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000186$fn__1938000187$fn__1938000189")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$fn__1938000193$fn__1938000194")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$iter__1938000206__1938000210$fn__1938000211")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$iter__1938000206__1938000210$fn__1938000211$fn__1938000212")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$iter__1938000226__1938000230$fn__1938000231")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.run$errorcheck$iter__1938000226__1938000230$fn__1938000231$fn__1938000232")

var Lit_47 *jrt.String = jrt.Intern(":")

var Lit_48 *jrt.String = jrt.Intern(" (file declares //go:build ")

var Lit_49 *jrt.String = jrt.Intern(")")

var Lit_50 *jrt.String = jrt.Intern(" (-lang was set to ")

var Lit_51 *jrt.String = jrt.Intern("; check go.mod)")

var Lit_52 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_53 *jrt.String = jrt.Intern("java.io.File")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.run$fail$fn__1938000012")

var Lit_55 *jrt.String = jrt.Intern("goi: ")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077$fn__1938000078")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.run$line_map$fn__1938000160")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.run$line_map$fn__1938000162")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.run$line_map$fn__1938000164")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.run$line_map$fn__1938000172")

var Lit_65 *jrt.String = jrt.Intern("//line ")

var Lit_66 *jrt.String = jrt.Intern("/*line ")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.run$line_map$fn__1938000172$fn__1938000173")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.run$no_assembly_BANG_$fn__1938000032")

var Lit_69 *jrt.String = jrt.Intern("assembly (")

var Lit_70 *jrt.String = jrt.Intern("): out of scope (§1.1)")

var Lit_71 *jrt.String = jrt.Intern(".s")

var Lit_72 *jrt.String = jrt.Intern("go:linkname (")

var Lit_73 *jrt.String = jrt.Intern(".ae")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.run$package_file_QMARK_$fn__1938000016")

var Lit_75 *jrt.String = jrt.Intern("(ns ")

var Lit_76 *jrt.String = jrt.Intern(";")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$walk_meta__1938000116")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$fn__1938000122")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$lines__1938000129")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$fn__1938000134")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$fn__1938000137")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$fn__1938000137$iter__1938000139__1938000143")

var Lit_83 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$fn__1938000137$iter__1938000139__1938000143$fn__1938000144")

var Lit_84 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$fn__1938000137$iter__1938000139__1938000143$fn__1938000144$fn__1938000145")

var Lit_85 *jrt.String = jrt.Intern("arbace.go.run$raw_lines$lines__1938000129$fn__1938000130")

var Lit_86 *jrt.String = jrt.Intern("SetOSArgs")

var Lit_87 *jrt.String = jrt.Intern("arbace.go.run$run$fn__1938000087")

var Lit_88 *jrt.String = jrt.Intern("arbace.go.run$run$extra__1938000089")

var Lit_89 *jrt.String = jrt.Intern("arbace.go.run$run$define__1938000091")

var Lit_90 *jrt.String = jrt.Intern("arbace.go.run$run$init_order__1938000097")

var Lit_91 *jrt.String = jrt.Intern("arbace.go.run$run$load_BANG___1938000101")

var Lit_92 *jrt.String = jrt.Intern("no main function")

var Lit_93 *jrt.String = jrt.Intern("RunProgram")

var Lit_94 *jrt.String = jrt.Intern("goi.run.")

var Lit_95 *jrt.String = jrt.Intern("arbace.go.run$run$define__1938000091$fn__1938000092")

var Lit_96 *jrt.String = jrt.Intern("arbace.go.run$run$define__1938000091$fn__1938000094")

var Lit_97 *jrt.String = jrt.Intern("arbace.go.run$run$init_order__1938000097$fn__1938000098")

var Lit_98 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn6,statuskn3,tagyn6,Stringkn4,linekn6,columnkn4,fileyn4,Fileyn12,java.io.Fileyn3,srcyn5,extrayn4,rootyn4,argsyn1,xyn4,langyn10,max-errorsyn3,rawyn5,frontyn1,&v11,arbace.core5,in-nsMyn13,arbace.go.runm2,R0,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).m2,R0,s755,bin/goi run ROOT NS [ARG...] (doc/go/GOI-SPEC.md §2.7, §11): an interpreted Go program in\n  program mode. The package of namespace NS is read from the forms root ROOT (its package file\n  ROOT/go/....ae), checked against the table's digest, built eagerly (so that the builder's\n  errors show before anything runs), initialized and run: os.Exit exits, an uncaught panic is\n  reported as gc reports it (status 2), os.Args is NS and the arguments.\n\n  What goi cannot run (§11.3) ends the run before it starts, on standard error:\n  goi: unsupported: REASON, status 125 (a form of a later milestone, an import neither listed in\n  the table nor interpreted); goi: error: MESSAGE, status 126 (a check error or a builder's\n  failure: goi's bug on a valid program).R1,v13,arbace.go.run4,failm10,R2,TR3,L1,V3,R4,Myn4,kindm2,R5,R6,Myn3,msgm2,R5,R6,R7,i21,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run13,package-file?m10,R2,TR3,L1,V1,Myn1,fm2,R5,R10,R7,i27,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run13,dir-test-rootm12,R2,TR3,L1,MV1,Myn2,pfm2,R5,R10,m2,R5,R11,R0,s184,The directory of a directory test's packages (GOI-SPEC.md §11.2) that package file pf belongs\n  to: its nearest ancestor named *_dir, or its sibling STEM_dir for STEM_dir.ae; else nil.R7,i33,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run14,dir-test-indexm12,R2,TR3,L1,V1,Myn2,pfm2,R5,R10,R0,s112,The packages of a directory test: import path -> package file (pf's own and those under its\n  test's directory).R7,i47,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run12,no-assembly!m10,R2,TR3,L1,V1,R12,R7,i60,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run12,no-linkname!m10,R2,TR3,L1,V1,R12,R7,i64,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run6,check!m10,R2,TR3,L1,V2,R12,R13,R7,i70,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run10,imports-ofm12,R2,TR3,L1,V1,R12,R0,s71,The import paths package source src names (its local imports resolved).R7,i81,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run3,runm10,R3,L1,V3,R14,Myn2,pfm2,R5,R10,R15,R0,s207,Runs the program of package file pf (forms root root) with args: its exit status. The\n  interpreted packages it imports (a directory test's) are checked, defined and initialized\n  first, in dependency order.R7,i92,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run9,raw-linesm12,R2,TR3,L1,V1,R16,R0,s452,Form x of raw forms read from text, the lines mode :lines writes from the positions mode\n  :full writes (doc/go/SPEC.md §10.2), as the converter's in-memory forms carry them: each\n  form's :line its node's first line (its :go/pos' least; a vector's its children's), not the\n  reader's (a vector's, a symbol's, a list's written after its line); a function's :go/end its\n  closing brace's line; a literal child's line its :go/breaks entry, from :go/apos.R7,i145,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run8,line-mapm12,R2,TR3,L1,V1,Myn4,pathm2,R5,R6,R0,s628,gc's //line directives of the Go file at path (cmd/compile/internal/syntax's updateBase): a\n  comment //line FILE:LINE or //line FILE:LINE:COL at a line's start makes the next line LINE of\n  FILE (an empty FILE: \"\", or with COL the file before; a relative FILE joined to the source's\n  directory as gc does, which the judge's base name matching takes alike, so written as given).\n  A function of [file line] (the checker's position) to gc's [file line]; nil when the file has\n  no //line directive or has a /*line directive (positions within a line, which the forms do not\n  keep: the harness leaves those programs unsupported).R7,i181,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run10,errorcheckm10,R3,L1,V6,R14,Myn2,pfm2,R5,R10,R17,R18,R19,R20,R0,s1344,Checks the package of package file pf (forms root root) without running it (GR7b, the\n  errorcheck programs of §11): its errors on standard output as gc prints them with -C, one\n  FILE:LINE: MESSAGE each (a message's further lines indented by a tab), in the checker's\n  order; the status 1 when there are errors, else 0. What goi cannot check ends it as a run's:\n  goi: unsupported (125), goi: error (126). max-errors (gc without -e: 10, GR10): the first\n  max-errors printed, then gc's FILE:LINE: too many errors at the last one's position. raw:\n  the forms are repr/go's raw forms of an invalid program (doc/go/CONVERTER-NOTES.md, \"Raw\n  forms\"; doc/go/GO-PARSER-SURVEY.md GP6, GPS9 (b)), checked in the checker's resolve mode\n  (GOI-SPEC.md §3.10), its answers dropped. front: the Go file the forms are of, whose errors of\n  gc's front end beside its type checker come from gc's syntax and noder's port\n  (arbace.repr.go.syntax, doc/go/GO-PARSER-SURVEY.md GPS39 (b), GPS41 (c)): the parse's (its\n  branch checks, noder's pragmas') in place of the checker's own branch errors (types2's\n  IgnoreBranchErrors), merged by position; when there are none and the checker reports none,\n  the declarations' checks of noder's writer (decl-errors), and when there are none of those,\n  gc's checks of its types' sizes (arbace.go.check.code/size-errors).R7,i213,R8,i1,R9,s16,arbace/go/run.aev13,arbace.go.run5,-mainm10,R3,L1,V2,R21,R15,R0,s483,bin/goi run's Arbace side: ROOT NS [ARG...]; --errorcheck [--lang goV] [--max-errors N] [--raw]\n  [--gc-front FILE] ROOT NS: the package's errors (errorcheck), checked at language version goV\n  (gc's -lang) when given, at most N of them then gc's too many errors (gc without -e); --raw: ROOT\n  holds repr/go's raw forms of the program (GP6), checked in the resolve mode; --gc-front: the\n  errors of gc's front end beside its type checker from FILE, the program's Go file (GPS41 (c)).R7,i296,R8,i1,R9,s16,arbace/go/run.ae")

var Lit_99 *jrt.String = jrt.Intern("arbace.go.run$eval1938000004$loading__1927001464__auto____1938000005")

var Lit_100 *jrt.String = jrt.Intern("arbace.go.run$eval1938000008$fn__1938000009")

var Lit_101 *jrt.String = jrt.Intern("arbace.go.run$fail")

var Lit_102 *jrt.String = jrt.Intern("arbace.go.run$package_file_QMARK_")

var Lit_103 *jrt.String = jrt.Intern("arbace.go.run$dir_test_root")

var Lit_104 *jrt.String = jrt.Intern("arbace.go.run$dir_test_index")

var Lit_105 *jrt.String = jrt.Intern("arbace.go.run$no_assembly_BANG_")

var Lit_106 *jrt.String = jrt.Intern("arbace.go.run$no_linkname_BANG_")

var Lit_107 *jrt.String = jrt.Intern("arbace.go.run$check_BANG_")

var Lit_108 *jrt.String = jrt.Intern("arbace.go.run$imports_of")

var Lit_109 *jrt.String = jrt.Intern("arbace.go.run$run")

var Lit_110 *jrt.String = jrt.Intern("arbace.go.run$raw_lines")

var Lit_111 *jrt.String = jrt.Intern("arbace.go.run$line_map")

var Lit_112 *jrt.String = jrt.Intern("arbace.go.run$errorcheck")

var Lit_113 *jrt.String = jrt.Intern("arbace.go.run$_main")
