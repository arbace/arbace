//line j2g_classes.ae:1
package aot_arbace_go_run

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_run__main_A_class, Name: "arbace.go.run$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000115_A_class, Name: "arbace.go.run$_main$fn__1938000115", Modifiers: 25, Simple: "fn__1938000115", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000115_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000117_A_class, Name: "arbace.go.run$_main$fn__1938000117", Modifiers: 25, Simple: "fn__1938000117", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000117_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_check_BANG__A_class, Name: "arbace.go.run$check_BANG_", Modifiers: 25, Simple: "check_BANG_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_check_BANG__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_check_BANG__fn__1938000065_A_class, Name: "arbace.go.run$check_BANG_$fn__1938000065", Modifiers: 25, Simple: "fn__1938000065", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_check_BANG__fn__1938000065_A", Source: "run.ae", Declaring: &A_arbace_go_run_check_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_A_class, Name: "arbace.go.run$dir_test_index", Modifiers: 25, Simple: "dir_test_index", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_class, Name: "arbace.go.run$dir_test_index$iter__1938000020__1938000024", Modifiers: 25, Simple: "iter__1938000020__1938000024", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A", Source: "run.ae", Declaring: &A_arbace_go_run_dir_test_index_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_class, Name: "arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025", Modifiers: 25, Simple: "fn__1938000025", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A", Source: "run.ae", Declaring: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_class, Name: "arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025$fn__1938000026", Modifiers: 25, Simple: "fn__1938000026", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A", Source: "run.ae", Declaring: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_root_A_class, Name: "arbace.go.run$dir_test_root", Modifiers: 25, Simple: "dir_test_root", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_root_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_class, Name: "arbace.go.run$eval1938000004$loading__1927001464__auto____1938000005", Modifiers: 25, Simple: "loading__1927001464__auto____1938000005", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A", Source: "run.ae", Declaring: &A_arbace_go_run_eval1938000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_eval1938000008_fn__1938000009_A_class, Name: "arbace.go.run$eval1938000008$fn__1938000009", Modifiers: 25, Simple: "fn__1938000009", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000008_fn__1938000009_A", Source: "run.ae", Declaring: &A_arbace_go_run_eval1938000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_fail_A_class, Name: "arbace.go.run$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_fail_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_fail_fn__1938000012_A_class, Name: "arbace.go.run$fail$fn__1938000012", Modifiers: 25, Simple: "fn__1938000012", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_fail_fn__1938000012_A", Source: "run.ae", Declaring: &A_arbace_go_run_fail_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_A_class, Name: "arbace.go.run$imports_of", Modifiers: 25, Simple: "imports_of", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074", Modifiers: 25, Simple: "iter__1938000068__1938000074", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075", Modifiers: 25, Simple: "fn__1938000075", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076", Modifiers: 25, Simple: "iter__1938000070__1938000076", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077", Modifiers: 25, Simple: "fn__1938000077", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077$fn__1938000078", Modifiers: 25, Simple: "fn__1938000078", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_no_assembly_BANG__A_class, Name: "arbace.go.run$no_assembly_BANG_", Modifiers: 25, Simple: "no_assembly_BANG_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_no_assembly_BANG__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_class, Name: "arbace.go.run$no_assembly_BANG_$fn__1938000032", Modifiers: 25, Simple: "fn__1938000032", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_no_assembly_BANG__fn__1938000032_A", Source: "run.ae", Declaring: &A_arbace_go_run_no_assembly_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_no_linkname_BANG__A_class, Name: "arbace.go.run$no_linkname_BANG_", Modifiers: 25, Simple: "no_linkname_BANG_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_no_linkname_BANG__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_package_file_QMARK__A_class, Name: "arbace.go.run$package_file_QMARK_", Modifiers: 25, Simple: "package_file_QMARK_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_package_file_QMARK__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_package_file_QMARK__fn__1938000016_A_class, Name: "arbace.go.run$package_file_QMARK_$fn__1938000016", Modifiers: 25, Simple: "fn__1938000016", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_package_file_QMARK__fn__1938000016_A", Source: "run.ae", Declaring: &A_arbace_go_run_package_file_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_A_class, Name: "arbace.go.run$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_define__1938000091_A_class, Name: "arbace.go.run$run$define__1938000091", Modifiers: 25, Simple: "define__1938000091", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_define__1938000091_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_define__1938000091_fn__1938000092_A_class, Name: "arbace.go.run$run$define__1938000091$fn__1938000092", Modifiers: 25, Simple: "fn__1938000092", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_define__1938000091_fn__1938000092_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_define__1938000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_extra__1938000089_A_class, Name: "arbace.go.run$run$extra__1938000089", Modifiers: 25, Simple: "extra__1938000089", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_extra__1938000089_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_fn__1938000087_A_class, Name: "arbace.go.run$run$fn__1938000087", Modifiers: 25, Simple: "fn__1938000087", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_fn__1938000087_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_init_order__1938000095_A_class, Name: "arbace.go.run$run$init_order__1938000095", Modifiers: 25, Simple: "init_order__1938000095", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_init_order__1938000095_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_class, Name: "arbace.go.run$run$init_order__1938000095$fn__1938000096", Modifiers: 25, Simple: "fn__1938000096", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_init_order__1938000095_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_load_BANG___1938000099_A_class, Name: "arbace.go.run$run$load_BANG___1938000099", Modifiers: 25, Simple: "load_BANG___1938000099", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_load_BANG___1938000099_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_A_New()}; return nil }

var A_arbace_go_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_A_new}

var A_arbace_go_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_run.A_arbace_go_run_A"})

func init() { i := A_arbace_go_run_A_class.Info(); i.IsInstance = A_arbace_go_run_A_InstanceOf; i.Init = A_arbace_go_run_A_Init; i.Table = A_arbace_go_run_A_members }

var A_arbace_go_run__main_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000115_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000117_A_class *jrt.Class

var A_arbace_go_run_check_BANG__A_class *jrt.Class

var A_arbace_go_run_check_BANG__fn__1938000065_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_class *jrt.Class

var A_arbace_go_run_dir_test_root_A_class *jrt.Class

func A_arbace_go_run_eval1938000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_eval1938000004_A_New()}; return nil }

var A_arbace_go_run_eval1938000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_eval1938000004_A_new}

var A_arbace_go_run_eval1938000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run$eval1938000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_run_A_class, Simple: "eval1938000004", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000004_A"})

func init() { i := A_arbace_go_run_eval1938000004_A_class.Info(); i.IsInstance = A_arbace_go_run_eval1938000004_A_InstanceOf; i.Table = A_arbace_go_run_eval1938000004_A_members }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_class *jrt.Class

func A_arbace_go_run_eval1938000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_eval1938000008_A_New()}; return nil }

var A_arbace_go_run_eval1938000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_eval1938000008_A_new}

var A_arbace_go_run_eval1938000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run$eval1938000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_run_A_class, Simple: "eval1938000008", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000008_A"})

func init() { i := A_arbace_go_run_eval1938000008_A_class.Info(); i.IsInstance = A_arbace_go_run_eval1938000008_A_InstanceOf; i.Table = A_arbace_go_run_eval1938000008_A_members }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_class *jrt.Class

var A_arbace_go_run_fail_A_class *jrt.Class

var A_arbace_go_run_fail_fn__1938000012_A_class *jrt.Class

var A_arbace_go_run_imports_of_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_class *jrt.Class

var A_arbace_go_run_no_assembly_BANG__A_class *jrt.Class

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_class *jrt.Class

var A_arbace_go_run_no_linkname_BANG__A_class *jrt.Class

var A_arbace_go_run_package_file_QMARK__A_class *jrt.Class

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_class *jrt.Class

var A_arbace_go_run_run_A_class *jrt.Class

var A_arbace_go_run_run_define__1938000091_A_class *jrt.Class

var A_arbace_go_run_run_define__1938000091_fn__1938000092_A_class *jrt.Class

var A_arbace_go_run_run_extra__1938000089_A_class *jrt.Class

var A_arbace_go_run_run_fn__1938000087_A_class *jrt.Class

var A_arbace_go_run_run_init_order__1938000095_A_class *jrt.Class

var A_arbace_go_run_run_init_order__1938000095_fn__1938000096_A_class *jrt.Class

var A_arbace_go_run_run_load_BANG___1938000099_A_class *jrt.Class

func A_arbace_go_run__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_run__init_A_Load__O()}; return nil }

func A_arbace_go_run__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run__init_A_New()}; return nil }

var A_arbace_go_run__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_run__init_A_invoke, New: A_arbace_go_run__init_A_new}

var A_arbace_go_run__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_run.A_arbace_go_run__init_A", Source: "run.ae"})

func init() { i := A_arbace_go_run__init_A_class.Info(); i.IsInstance = A_arbace_go_run__init_A_InstanceOf; i.Init = A_arbace_go_run__init_A_Init; i.Table = A_arbace_go_run__init_A_members }
