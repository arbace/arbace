//line j2g_classes.ae:1
package aot_arbace_go_run

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_run__main_A_class, Name: "arbace.go.run$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000219_A_class, Name: "arbace.go.run$_main$fn__1938000219", Modifiers: 25, Simple: "fn__1938000219", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000219_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000222_A_class, Name: "arbace.go.run$_main$fn__1938000222", Modifiers: 25, Simple: "fn__1938000222", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000222_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000227_A_class, Name: "arbace.go.run$_main$fn__1938000227", Modifiers: 25, Simple: "fn__1938000227", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000227_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000229_A_class, Name: "arbace.go.run$_main$fn__1938000229", Modifiers: 25, Simple: "fn__1938000229", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000229_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_check_BANG__A_class, Name: "arbace.go.run$check_BANG_", Modifiers: 25, Simple: "check_BANG_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_check_BANG__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_check_BANG__fn__1938000065_A_class, Name: "arbace.go.run$check_BANG_$fn__1938000065", Modifiers: 25, Simple: "fn__1938000065", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_check_BANG__fn__1938000065_A", Source: "run.ae", Declaring: &A_arbace_go_run_check_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_A_class, Name: "arbace.go.run$dir_test_index", Modifiers: 25, Simple: "dir_test_index", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_class, Name: "arbace.go.run$dir_test_index$iter__1938000020__1938000024", Modifiers: 25, Simple: "iter__1938000020__1938000024", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A", Source: "run.ae", Declaring: &A_arbace_go_run_dir_test_index_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_class, Name: "arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025", Modifiers: 25, Simple: "fn__1938000025", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A", Source: "run.ae", Declaring: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_class, Name: "arbace.go.run$dir_test_index$iter__1938000020__1938000024$fn__1938000025$fn__1938000026", Modifiers: 25, Simple: "fn__1938000026", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A", Source: "run.ae", Declaring: &A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_dir_test_root_A_class, Name: "arbace.go.run$dir_test_root", Modifiers: 25, Simple: "dir_test_root", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_dir_test_root_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_A_class, Name: "arbace.go.run$errorcheck", Modifiers: 25, Simple: "errorcheck", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF6_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000163_A_class, Name: "arbace.go.run$errorcheck$fn__1938000163", Modifiers: 25, Simple: "fn__1938000163", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000163_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_class, Name: "arbace.go.run$errorcheck$fn__1938000163$fn__1938000164", Modifiers: 25, Simple: "fn__1938000164", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_fn__1938000163_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_class, Name: "arbace.go.run$errorcheck$fn__1938000163$fn__1938000164$fn__1938000166", Modifiers: 25, Simple: "fn__1938000166", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000170_A_class, Name: "arbace.go.run$errorcheck$fn__1938000170", Modifiers: 25, Simple: "fn__1938000170", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000170_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000172_A_class, Name: "arbace.go.run$errorcheck$fn__1938000172", Modifiers: 25, Simple: "fn__1938000172", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000172_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000174_A_class, Name: "arbace.go.run$errorcheck$fn__1938000174", Modifiers: 25, Simple: "fn__1938000174", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000174_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000177_A_class, Name: "arbace.go.run$errorcheck$fn__1938000177", Modifiers: 25, Simple: "fn__1938000177", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000177_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_fn__1938000179_A_class, Name: "arbace.go.run$errorcheck$fn__1938000179", Modifiers: 25, Simple: "fn__1938000179", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_fn__1938000179_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_class, Name: "arbace.go.run$errorcheck$iter__1938000181__1938000185", Modifiers: 25, Simple: "iter__1938000181__1938000185", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_class, Name: "arbace.go.run$errorcheck$iter__1938000181__1938000185$fn__1938000186", Modifiers: 25, Simple: "fn__1938000186", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_class, Name: "arbace.go.run$errorcheck$iter__1938000181__1938000185$fn__1938000186$fn__1938000187", Modifiers: 25, Simple: "fn__1938000187", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_class, Name: "arbace.go.run$errorcheck$iter__1938000193__1938000197", Modifiers: 25, Simple: "iter__1938000193__1938000197", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_class, Name: "arbace.go.run$errorcheck$iter__1938000193__1938000197$fn__1938000198", Modifiers: 25, Simple: "fn__1938000198", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_class, Name: "arbace.go.run$errorcheck$iter__1938000193__1938000197$fn__1938000198$fn__1938000199", Modifiers: 25, Simple: "fn__1938000199", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_pos__1938000203_A_class, Name: "arbace.go.run$errorcheck$pos__1938000203", Modifiers: 25, Simple: "pos__1938000203", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_pos__1938000203_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_errorcheck_vmsg__1938000191_A_class, Name: "arbace.go.run$errorcheck$vmsg__1938000191", Modifiers: 25, Simple: "vmsg__1938000191", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_errorcheck_vmsg__1938000191_A", Source: "run.ae", Declaring: &A_arbace_go_run_errorcheck_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_class, Name: "arbace.go.run$eval1938000004$loading__1927001464__auto____1938000005", Modifiers: 25, Simple: "loading__1927001464__auto____1938000005", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A", Source: "run.ae", Declaring: &A_arbace_go_run_eval1938000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_eval1938000008_fn__1938000009_A_class, Name: "arbace.go.run$eval1938000008$fn__1938000009", Modifiers: 25, Simple: "fn__1938000009", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000008_fn__1938000009_A", Source: "run.ae", Declaring: &A_arbace_go_run_eval1938000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_fail_A_class, Name: "arbace.go.run$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_fail_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_fail_fn__1938000012_A_class, Name: "arbace.go.run$fail$fn__1938000012", Modifiers: 25, Simple: "fn__1938000012", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_fail_fn__1938000012_A", Source: "run.ae", Declaring: &A_arbace_go_run_fail_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_A_class, Name: "arbace.go.run$imports_of", Modifiers: 25, Simple: "imports_of", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074", Modifiers: 25, Simple: "iter__1938000068__1938000074", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075", Modifiers: 25, Simple: "fn__1938000075", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076", Modifiers: 25, Simple: "iter__1938000070__1938000076", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077", Modifiers: 25, Simple: "fn__1938000077", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_class, Name: "arbace.go.run$imports_of$iter__1938000068__1938000074$fn__1938000075$iter__1938000070__1938000076$fn__1938000077$fn__1938000078", Modifiers: 25, Simple: "fn__1938000078", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A", Source: "run.ae", Declaring: &A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_no_assembly_BANG__A_class, Name: "arbace.go.run$no_assembly_BANG_", Modifiers: 25, Simple: "no_assembly_BANG_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_no_assembly_BANG__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_class, Name: "arbace.go.run$no_assembly_BANG_$fn__1938000032", Modifiers: 25, Simple: "fn__1938000032", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_no_assembly_BANG__fn__1938000032_A", Source: "run.ae", Declaring: &A_arbace_go_run_no_assembly_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_no_linkname_BANG__A_class, Name: "arbace.go.run$no_linkname_BANG_", Modifiers: 25, Simple: "no_linkname_BANG_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_no_linkname_BANG__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_package_file_QMARK__A_class, Name: "arbace.go.run$package_file_QMARK_", Modifiers: 25, Simple: "package_file_QMARK_", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_package_file_QMARK__A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_package_file_QMARK__fn__1938000016_A_class, Name: "arbace.go.run$package_file_QMARK_$fn__1938000016", Modifiers: 25, Simple: "fn__1938000016", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_package_file_QMARK__fn__1938000016_A", Source: "run.ae", Declaring: &A_arbace_go_run_package_file_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_A_class, Name: "arbace.go.run$raw_lines", Modifiers: 25, Simple: "raw_lines", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_fn__1938000122_A_class, Name: "arbace.go.run$raw_lines$fn__1938000122", Modifiers: 25, Simple: "fn__1938000122", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_fn__1938000122_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_fn__1938000134_A_class, Name: "arbace.go.run$raw_lines$fn__1938000134", Modifiers: 25, Simple: "fn__1938000134", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_fn__1938000134_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_fn__1938000137_A_class, Name: "arbace.go.run$raw_lines$fn__1938000137", Modifiers: 25, Simple: "fn__1938000137", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_fn__1938000137_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_class, Name: "arbace.go.run$raw_lines$fn__1938000137$iter__1938000139__1938000143", Modifiers: 25, Simple: "iter__1938000139__1938000143", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_fn__1938000137_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_class, Name: "arbace.go.run$raw_lines$fn__1938000137$iter__1938000139__1938000143$fn__1938000144", Modifiers: 25, Simple: "fn__1938000144", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_class, Name: "arbace.go.run$raw_lines$fn__1938000137$iter__1938000139__1938000143$fn__1938000144$fn__1938000145", Modifiers: 25, Simple: "fn__1938000145", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_lines__1938000129_A_class, Name: "arbace.go.run$raw_lines$lines__1938000129", Modifiers: 25, Simple: "lines__1938000129", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_lines__1938000129_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_class, Name: "arbace.go.run$raw_lines$lines__1938000129$fn__1938000130", Modifiers: 25, Simple: "fn__1938000130", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_lines__1938000129_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_raw_lines_walk_meta__1938000116_A_class, Name: "arbace.go.run$raw_lines$walk_meta__1938000116", Modifiers: 25, Simple: "walk_meta__1938000116", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_raw_lines_walk_meta__1938000116_A", Source: "run.ae", Declaring: &A_arbace_go_run_raw_lines_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_A_class, Name: "arbace.go.run$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_define__1938000091_A_class, Name: "arbace.go.run$run$define__1938000091", Modifiers: 25, Simple: "define__1938000091", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_define__1938000091_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_define__1938000091_fn__1938000092_A_class, Name: "arbace.go.run$run$define__1938000091$fn__1938000092", Modifiers: 25, Simple: "fn__1938000092", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_define__1938000091_fn__1938000092_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_define__1938000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_define__1938000091_fn__1938000094_A_class, Name: "arbace.go.run$run$define__1938000091$fn__1938000094", Modifiers: 25, Simple: "fn__1938000094", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_define__1938000091_fn__1938000094_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_define__1938000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_extra__1938000089_A_class, Name: "arbace.go.run$run$extra__1938000089", Modifiers: 25, Simple: "extra__1938000089", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_extra__1938000089_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_fn__1938000087_A_class, Name: "arbace.go.run$run$fn__1938000087", Modifiers: 25, Simple: "fn__1938000087", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_fn__1938000087_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_init_order__1938000097_A_class, Name: "arbace.go.run$run$init_order__1938000097", Modifiers: 25, Simple: "init_order__1938000097", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_init_order__1938000097_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_class, Name: "arbace.go.run$run$init_order__1938000097$fn__1938000098", Modifiers: 25, Simple: "fn__1938000098", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_init_order__1938000097_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_load_BANG___1938000101_A_class, Name: "arbace.go.run$run$load_BANG___1938000101", Modifiers: 25, Simple: "load_BANG___1938000101", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_load_BANG___1938000101_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_A_New()}; return nil }

var A_arbace_go_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_A_new}

var A_arbace_go_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_run.A_arbace_go_run_A"})

func init() { i := A_arbace_go_run_A_class.Info(); i.IsInstance = A_arbace_go_run_A_InstanceOf; i.Init = A_arbace_go_run_A_Init; i.Table = A_arbace_go_run_A_members }

var A_arbace_go_run__main_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000219_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000222_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000227_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000229_A_class *jrt.Class

var A_arbace_go_run_check_BANG__A_class *jrt.Class

var A_arbace_go_run_check_BANG__fn__1938000065_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_A_class *jrt.Class

var A_arbace_go_run_dir_test_index_iter__1938000020__1938000024_fn__1938000025_fn__1938000026_A_class *jrt.Class

var A_arbace_go_run_dir_test_root_A_class *jrt.Class

var A_arbace_go_run_errorcheck_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000163_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000163_fn__1938000164_fn__1938000166_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000170_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000172_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000174_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000177_A_class *jrt.Class

var A_arbace_go_run_errorcheck_fn__1938000179_A_class *jrt.Class

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_A_class *jrt.Class

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_A_class *jrt.Class

var A_arbace_go_run_errorcheck_iter__1938000181__1938000185_fn__1938000186_fn__1938000187_A_class *jrt.Class

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_A_class *jrt.Class

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_A_class *jrt.Class

var A_arbace_go_run_errorcheck_iter__1938000193__1938000197_fn__1938000198_fn__1938000199_A_class *jrt.Class

var A_arbace_go_run_errorcheck_pos__1938000203_A_class *jrt.Class

var A_arbace_go_run_errorcheck_vmsg__1938000191_A_class *jrt.Class

func A_arbace_go_run_eval1938000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_eval1938000004_A_New()}; return nil }

var A_arbace_go_run_eval1938000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_eval1938000004_A_new}

var A_arbace_go_run_eval1938000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run$eval1938000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_run_A_class, Simple: "eval1938000004", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000004_A"})

func init() { i := A_arbace_go_run_eval1938000004_A_class.Info(); i.IsInstance = A_arbace_go_run_eval1938000004_A_InstanceOf; i.Table = A_arbace_go_run_eval1938000004_A_members }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_class *jrt.Class

func A_arbace_go_run_eval1938000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_eval1938000008_A_New()}; return nil }

var A_arbace_go_run_eval1938000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_eval1938000008_A_new}

var A_arbace_go_run_eval1938000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run$eval1938000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_run_A_class, Simple: "eval1938000008", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000008_A"})

func init() { i := A_arbace_go_run_eval1938000008_A_class.Info(); i.IsInstance = A_arbace_go_run_eval1938000008_A_InstanceOf; i.Table = A_arbace_go_run_eval1938000008_A_members }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_class *jrt.Class

var A_arbace_go_run_fail_A_class *jrt.Class

var A_arbace_go_run_fail_fn__1938000012_A_class *jrt.Class

var A_arbace_go_run_imports_of_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_A_class *jrt.Class

var A_arbace_go_run_imports_of_iter__1938000068__1938000074_fn__1938000075_iter__1938000070__1938000076_fn__1938000077_fn__1938000078_A_class *jrt.Class

var A_arbace_go_run_no_assembly_BANG__A_class *jrt.Class

var A_arbace_go_run_no_assembly_BANG__fn__1938000032_A_class *jrt.Class

var A_arbace_go_run_no_linkname_BANG__A_class *jrt.Class

var A_arbace_go_run_package_file_QMARK__A_class *jrt.Class

var A_arbace_go_run_package_file_QMARK__fn__1938000016_A_class *jrt.Class

var A_arbace_go_run_raw_lines_A_class *jrt.Class

var A_arbace_go_run_raw_lines_fn__1938000122_A_class *jrt.Class

var A_arbace_go_run_raw_lines_fn__1938000134_A_class *jrt.Class

var A_arbace_go_run_raw_lines_fn__1938000137_A_class *jrt.Class

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_A_class *jrt.Class

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_A_class *jrt.Class

var A_arbace_go_run_raw_lines_fn__1938000137_iter__1938000139__1938000143_fn__1938000144_fn__1938000145_A_class *jrt.Class

var A_arbace_go_run_raw_lines_lines__1938000129_A_class *jrt.Class

var A_arbace_go_run_raw_lines_lines__1938000129_fn__1938000130_A_class *jrt.Class

var A_arbace_go_run_raw_lines_walk_meta__1938000116_A_class *jrt.Class

var A_arbace_go_run_run_A_class *jrt.Class

var A_arbace_go_run_run_define__1938000091_A_class *jrt.Class

var A_arbace_go_run_run_define__1938000091_fn__1938000092_A_class *jrt.Class

var A_arbace_go_run_run_define__1938000091_fn__1938000094_A_class *jrt.Class

var A_arbace_go_run_run_extra__1938000089_A_class *jrt.Class

var A_arbace_go_run_run_fn__1938000087_A_class *jrt.Class

var A_arbace_go_run_run_init_order__1938000097_A_class *jrt.Class

var A_arbace_go_run_run_init_order__1938000097_fn__1938000098_A_class *jrt.Class

var A_arbace_go_run_run_load_BANG___1938000101_A_class *jrt.Class

func A_arbace_go_run__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_run__init_A_Load__O()}; return nil }

func A_arbace_go_run__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run__init_A_New()}; return nil }

var A_arbace_go_run__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_run__init_A_invoke, New: A_arbace_go_run__init_A_new}

var A_arbace_go_run__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_run.A_arbace_go_run__init_A", Source: "run.ae"})

func init() { i := A_arbace_go_run__init_A_class.Info(); i.IsInstance = A_arbace_go_run__init_A_InstanceOf; i.Init = A_arbace_go_run__init_A_Init; i.Table = A_arbace_go_run__init_A_members }
