//line j2g_classes.ae:1
package aot_arbace_go_run

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_run__main_A_class, Name: "arbace.go.run$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000024_A_class, Name: "arbace.go.run$_main$fn__1938000024", Modifiers: 25, Simple: "fn__1938000024", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000024_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run__main_fn__1938000026_A_class, Name: "arbace.go.run$_main$fn__1938000026", Modifiers: 25, Simple: "fn__1938000026", Go: "arbace/aot_arbace_go_run.A_arbace_go_run__main_fn__1938000026_A", Source: "run.ae", Declaring: &A_arbace_go_run__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_class, Name: "arbace.go.run$eval1938000004$loading__1927001464__auto____1938000005", Modifiers: 25, Simple: "loading__1927001464__auto____1938000005", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A", Source: "run.ae", Declaring: &A_arbace_go_run_eval1938000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_eval1938000008_fn__1938000009_A_class, Name: "arbace.go.run$eval1938000008$fn__1938000009", Modifiers: 25, Simple: "fn__1938000009", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000008_fn__1938000009_A", Source: "run.ae", Declaring: &A_arbace_go_run_eval1938000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_fail_A_class, Name: "arbace.go.run$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_fail_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_fail_fn__1938000012_A_class, Name: "arbace.go.run$fail$fn__1938000012", Modifiers: 25, Simple: "fn__1938000012", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_fail_fn__1938000012_A", Source: "run.ae", Declaring: &A_arbace_go_run_fail_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_A_class, Name: "arbace.go.run$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_A", Source: "run.ae", Declaring: &A_arbace_go_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_run_run_fn__1938000016_A_class, Name: "arbace.go.run$run$fn__1938000016", Modifiers: 25, Simple: "fn__1938000016", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_run_fn__1938000016_A", Source: "run.ae", Declaring: &A_arbace_go_run_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_A_New()}; return nil }

var A_arbace_go_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_A_new}

var A_arbace_go_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_run.A_arbace_go_run_A"})

func init() { i := A_arbace_go_run_A_class.Info(); i.IsInstance = A_arbace_go_run_A_InstanceOf; i.Init = A_arbace_go_run_A_Init; i.Table = A_arbace_go_run_A_members }

var A_arbace_go_run__main_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000024_A_class *jrt.Class

var A_arbace_go_run__main_fn__1938000026_A_class *jrt.Class

func A_arbace_go_run_eval1938000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_eval1938000004_A_New()}; return nil }

var A_arbace_go_run_eval1938000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_eval1938000004_A_new}

var A_arbace_go_run_eval1938000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run$eval1938000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_run_A_class, Simple: "eval1938000004", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000004_A"})

func init() { i := A_arbace_go_run_eval1938000004_A_class.Info(); i.IsInstance = A_arbace_go_run_eval1938000004_A_InstanceOf; i.Table = A_arbace_go_run_eval1938000004_A_members }

var A_arbace_go_run_eval1938000004_loading__1927001464__auto____1938000005_A_class *jrt.Class

func A_arbace_go_run_eval1938000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run_eval1938000008_A_New()}; return nil }

var A_arbace_go_run_eval1938000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_run_eval1938000008_A_new}

var A_arbace_go_run_eval1938000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run$eval1938000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_run_A_class, Simple: "eval1938000008", Go: "arbace/aot_arbace_go_run.A_arbace_go_run_eval1938000008_A"})

func init() { i := A_arbace_go_run_eval1938000008_A_class.Info(); i.IsInstance = A_arbace_go_run_eval1938000008_A_InstanceOf; i.Table = A_arbace_go_run_eval1938000008_A_members }

var A_arbace_go_run_eval1938000008_fn__1938000009_A_class *jrt.Class

var A_arbace_go_run_fail_A_class *jrt.Class

var A_arbace_go_run_fail_fn__1938000012_A_class *jrt.Class

var A_arbace_go_run_run_A_class *jrt.Class

var A_arbace_go_run_run_fn__1938000016_A_class *jrt.Class

func A_arbace_go_run__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_run__init_A_Load__O()}; return nil }

func A_arbace_go_run__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_run__init_A_New()}; return nil }

var A_arbace_go_run__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_run__init_A_invoke, New: A_arbace_go_run__init_A_new}

var A_arbace_go_run__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.run__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_run.A_arbace_go_run__init_A", Source: "run.ae"})

func init() { i := A_arbace_go_run__init_A_class.Info(); i.IsInstance = A_arbace_go_run__init_A_InstanceOf; i.Init = A_arbace_go_run__init_A_Init; i.Table = A_arbace_go_run__init_A_members }
