//line a2g_classes.ae:1
package aot_arbace_a2g_decls

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_decls_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_A_New()}; return nil }

var A_arbace_a2g_decls_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_decls_A_new}

var A_arbace_a2g_decls_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_A"})

func init() { i := A_arbace_a2g_decls_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_A_InstanceOf; i.Init = A_arbace_a2g_decls_A_Init; i.Table = A_arbace_a2g_decls_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_A_class, reflect.TypeFor[A_arbace_a2g_decls_A]()) }

func A_arbace_a2g_decls_at_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_at_line_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_at_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_at_line_A_New()}; return nil }

func A_arbace_a2g_decls_at_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_at_line_A_fn_class)}; return nil }

var A_arbace_a2g_decls_at_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_at_line_A_invoke, New: A_arbace_a2g_decls_at_line_A_new, Get: A_arbace_a2g_decls_at_line_A_get}

var A_arbace_a2g_decls_at_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$at_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "at_line", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_at_line_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_at_line_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_at_line_A_InstanceOf; i.Init = A_arbace_a2g_decls_at_line_A_Init; i.Table = A_arbace_a2g_decls_at_line_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_at_line_A_class, reflect.TypeFor[A_arbace_a2g_decls_at_line_A]()) }

func A_arbace_a2g_decls_at_line_fn__992000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_at_line_fn__992000041_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_at_line_fn__992000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_at_line_fn__992000041_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_at_line_fn__992000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_at_line_fn__992000041_A_fn_class)}; return nil }

var A_arbace_a2g_decls_at_line_fn__992000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_at_line_fn__992000041_A_invoke, New: A_arbace_a2g_decls_at_line_fn__992000041_A_new, Get: A_arbace_a2g_decls_at_line_fn__992000041_A_get}

var A_arbace_a2g_decls_at_line_fn__992000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$at_line$fn__992000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_at_line_A_class, Simple: "fn__992000041", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_at_line_fn__992000041_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_at_line_fn__992000041_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_at_line_fn__992000041_A_InstanceOf; i.Init = A_arbace_a2g_decls_at_line_fn__992000041_A_Init; i.Table = A_arbace_a2g_decls_at_line_fn__992000041_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_at_line_fn__992000041_A_class, reflect.TypeFor[A_arbace_a2g_decls_at_line_fn__992000041_A]()) }

func A_arbace_a2g_decls_body_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_body_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_body_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_body_of_A_New()}; return nil }

func A_arbace_a2g_decls_body_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_body_of_A_fn_class)}; return nil }

var A_arbace_a2g_decls_body_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_body_of_A_invoke, New: A_arbace_a2g_decls_body_of_A_new, Get: A_arbace_a2g_decls_body_of_A_get}

var A_arbace_a2g_decls_body_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$body_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "body_of", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_body_of_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_body_of_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_body_of_A_InstanceOf; i.Init = A_arbace_a2g_decls_body_of_A_Init; i.Table = A_arbace_a2g_decls_body_of_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_body_of_A_class, reflect.TypeFor[A_arbace_a2g_decls_body_of_A]()) }

func A_arbace_a2g_decls_captured_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_captured_fields_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_captured_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_captured_fields_A_New()}; return nil }

func A_arbace_a2g_decls_captured_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_captured_fields_A_fn_class)}; return nil }

var A_arbace_a2g_decls_captured_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_captured_fields_A_invoke, New: A_arbace_a2g_decls_captured_fields_A_new, Get: A_arbace_a2g_decls_captured_fields_A_get}

var A_arbace_a2g_decls_captured_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$captured_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "captured_fields", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_captured_fields_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_captured_fields_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_captured_fields_A_InstanceOf; i.Init = A_arbace_a2g_decls_captured_fields_A_Init; i.Table = A_arbace_a2g_decls_captured_fields_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_captured_fields_A_class, reflect.TypeFor[A_arbace_a2g_decls_captured_fields_A]()) }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_fn_class)}; return nil }

var A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_invoke, New: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_new, Get: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_get}

var A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$captured_fields$iter__992000028__992000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_captured_fields_A_class, Simple: "iter__992000028__992000032", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_InstanceOf; i.Init = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_Init; i.Table = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_class, reflect.TypeFor[A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A]()) }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_fn_class)}; return nil }

var A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_invoke, New: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_new, Get: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_get}

var A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$captured_fields$iter__992000028__992000032$fn__992000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_A_class, Simple: "fn__992000033", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_InstanceOf; i.Init = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_Init; i.Table = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_class, reflect.TypeFor[A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A]()) }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_fn_class)}; return nil }

var A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_invoke, New: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_new, Get: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_get}

var A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$captured_fields$iter__992000028__992000032$fn__992000033$fn__992000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_A_class, Simple: "fn__992000034", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_InstanceOf; i.Init = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_Init; i.Table = A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A_class, reflect.TypeFor[A_arbace_a2g_decls_captured_fields_iter__992000028__992000032_fn__992000033_fn__992000034_A]()) }

func A_arbace_a2g_decls_class_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_fields_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_fields_A_New()}; return nil }

func A_arbace_a2g_decls_class_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_fields_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_fields_A_invoke, New: A_arbace_a2g_decls_class_fields_A_new, Get: A_arbace_a2g_decls_class_fields_A_get}

var A_arbace_a2g_decls_class_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "class_fields", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_fields_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_fields_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_fields_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_fields_A_Init; i.Table = A_arbace_a2g_decls_class_fields_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_fields_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_fields_A]()) }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_New()}; return nil }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_invoke, New: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_new, Get: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_get}

var A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_fields$iter__992000060__992000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_fields_A_class, Simple: "iter__992000060__992000064", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_Init; i.Table = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A]()) }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_invoke, New: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_new, Get: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_get}

var A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_fields$iter__992000060__992000064$fn__992000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_A_class, Simple: "fn__992000065", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_Init; i.Table = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A]()) }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_invoke, New: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_new, Get: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_get}

var A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_fields$iter__992000060__992000064$fn__992000065$fn__992000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_A_class, Simple: "fn__992000066", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_Init; i.Table = A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_fields_iter__992000060__992000064_fn__992000065_fn__992000066_A]()) }

func A_arbace_a2g_decls_class_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_A_New()}; return nil }

func A_arbace_a2g_decls_class_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_A_invoke, New: A_arbace_a2g_decls_class_forms_A_new, Get: A_arbace_a2g_decls_class_forms_A_get}

var A_arbace_a2g_decls_class_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "class_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_A_Init; i.Table = A_arbace_a2g_decls_class_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_A]()) }

func A_arbace_a2g_decls_class_forms_fn__992000639_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_fn__992000639_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000639_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_fn__992000639_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000639_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_fn__992000639_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_fn__992000639_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_fn__992000639_A_invoke, New: A_arbace_a2g_decls_class_forms_fn__992000639_A_new, Get: A_arbace_a2g_decls_class_forms_fn__992000639_A_get}

var A_arbace_a2g_decls_class_forms_fn__992000639_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$fn__992000639", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "fn__992000639", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_fn__992000639_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_fn__992000639_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_fn__992000639_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_fn__992000639_A_Init; i.Table = A_arbace_a2g_decls_class_forms_fn__992000639_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_fn__992000639_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_fn__992000639_A]()) }

func A_arbace_a2g_decls_class_forms_fn__992000641_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_fn__992000641_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000641_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_fn__992000641_A_New()}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000641_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_fn__992000641_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_fn__992000641_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_fn__992000641_A_invoke, New: A_arbace_a2g_decls_class_forms_fn__992000641_A_new, Get: A_arbace_a2g_decls_class_forms_fn__992000641_A_get}

var A_arbace_a2g_decls_class_forms_fn__992000641_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$fn__992000641", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "fn__992000641", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_fn__992000641_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_fn__992000641_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_fn__992000641_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_fn__992000641_A_Init; i.Table = A_arbace_a2g_decls_class_forms_fn__992000641_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_fn__992000641_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_fn__992000641_A]()) }

func A_arbace_a2g_decls_class_forms_fn__992000643_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_fn__992000643_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000643_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_fn__992000643_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000643_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_fn__992000643_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_fn__992000643_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_fn__992000643_A_invoke, New: A_arbace_a2g_decls_class_forms_fn__992000643_A_new, Get: A_arbace_a2g_decls_class_forms_fn__992000643_A_get}

var A_arbace_a2g_decls_class_forms_fn__992000643_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$fn__992000643", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "fn__992000643", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_fn__992000643_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_fn__992000643_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_fn__992000643_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_fn__992000643_A_Init; i.Table = A_arbace_a2g_decls_class_forms_fn__992000643_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_fn__992000643_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_fn__992000643_A]()) }

func A_arbace_a2g_decls_class_forms_fn__992000645_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_fn__992000645_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000645_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_fn__992000645_A_New()}; return nil }

func A_arbace_a2g_decls_class_forms_fn__992000645_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_fn__992000645_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_fn__992000645_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_fn__992000645_A_invoke, New: A_arbace_a2g_decls_class_forms_fn__992000645_A_new, Get: A_arbace_a2g_decls_class_forms_fn__992000645_A_get}

var A_arbace_a2g_decls_class_forms_fn__992000645_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$fn__992000645", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "fn__992000645", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_fn__992000645_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_fn__992000645_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_fn__992000645_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_fn__992000645_A_Init; i.Table = A_arbace_a2g_decls_class_forms_fn__992000645_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_fn__992000645_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_fn__992000645_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000579__992000583", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "iter__992000579__992000583", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000579__992000583$fn__992000584", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_A_class, Simple: "fn__992000584", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000579__992000583$fn__992000584$fn__992000585", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_A_class, Simple: "fn__992000585", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000579__992000583_fn__992000584_fn__992000585_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000589__992000593", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "iter__992000589__992000593", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000589__992000593$fn__992000594", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_A_class, Simple: "fn__992000594", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000589__992000593$fn__992000594$fn__992000595", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_A_class, Simple: "fn__992000595", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000589__992000593_fn__992000594_fn__992000595_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000599__992000603", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "iter__992000599__992000603", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000599__992000603$fn__992000604", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_A_class, Simple: "fn__992000604", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000599__992000603$fn__992000604$fn__992000605", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_A_class, Simple: "fn__992000605", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000599__992000603_fn__992000604_fn__992000605_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000609__992000613", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "iter__992000609__992000613", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000609__992000613$fn__992000614", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_A_class, Simple: "fn__992000614", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000609__992000613$fn__992000614$fn__992000615", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_A_class, Simple: "fn__992000615", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000609__992000613_fn__992000614_fn__992000615_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000619__992000623", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "iter__992000619__992000623", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000619__992000623$fn__992000624", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_A_class, Simple: "fn__992000624", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000619__992000623$fn__992000624$fn__992000625", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_A_class, Simple: "fn__992000625", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000619__992000623_fn__992000624_fn__992000625_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000629__992000633", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_forms_A_class, Simple: "iter__992000629__992000633", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000629__992000633$fn__992000634", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_A_class, Simple: "fn__992000634", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A]()) }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_invoke, New: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_new, Get: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_get}

var A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_forms$iter__992000629__992000633$fn__992000634$fn__992000635", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_A_class, Simple: "fn__992000635", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_Init; i.Table = A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_forms_iter__992000629__992000633_fn__992000634_fn__992000635_A]()) }

func A_arbace_a2g_decls_class_methods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_methods_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_methods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_methods_A_New()}; return nil }

func A_arbace_a2g_decls_class_methods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_methods_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_methods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_methods_A_invoke, New: A_arbace_a2g_decls_class_methods_A_new, Get: A_arbace_a2g_decls_class_methods_A_get}

var A_arbace_a2g_decls_class_methods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_methods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "class_methods", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_methods_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_methods_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_methods_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_methods_A_Init; i.Table = A_arbace_a2g_decls_class_methods_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_methods_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_methods_A]()) }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_invoke, New: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_new, Get: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_get}

var A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_methods$iter__992000071__992000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_class_methods_A_class, Simple: "iter__992000071__992000075", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_Init; i.Table = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A]()) }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_invoke, New: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_new, Get: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_get}

var A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_methods$iter__992000071__992000075$fn__992000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_A_class, Simple: "fn__992000076", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_Init; i.Table = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A]()) }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_fn_class)}; return nil }

var A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_invoke, New: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_new, Get: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_get}

var A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$class_methods$iter__992000071__992000075$fn__992000076$fn__992000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_A_class, Simple: "fn__992000077", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_InstanceOf; i.Init = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_Init; i.Table = A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A_class, reflect.TypeFor[A_arbace_a2g_decls_class_methods_iter__992000071__992000075_fn__992000076_fn__992000077_A]()) }

func A_arbace_a2g_decls_clj_const_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_clj_const_fields_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_clj_const_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_clj_const_fields_A_New()}; return nil }

func A_arbace_a2g_decls_clj_const_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_clj_const_fields_A_fn_class)}; return nil }

var A_arbace_a2g_decls_clj_const_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_clj_const_fields_A_invoke, New: A_arbace_a2g_decls_clj_const_fields_A_new, Get: A_arbace_a2g_decls_clj_const_fields_A_get}

var A_arbace_a2g_decls_clj_const_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$clj_const_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "clj_const_fields", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_clj_const_fields_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_clj_const_fields_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_clj_const_fields_A_InstanceOf; i.Init = A_arbace_a2g_decls_clj_const_fields_A_Init; i.Table = A_arbace_a2g_decls_clj_const_fields_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_clj_const_fields_A_class, reflect.TypeFor[A_arbace_a2g_decls_clj_const_fields_A]()) }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_fn_class)}; return nil }

var A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_invoke, New: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_new, Get: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_get}

var A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$clj_const_fields$iter__992000486__992000490", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_clj_const_fields_A_class, Simple: "iter__992000486__992000490", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_InstanceOf; i.Init = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_Init; i.Table = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_class, reflect.TypeFor[A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A]()) }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_fn_class)}; return nil }

var A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_invoke, New: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_new, Get: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_get}

var A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$clj_const_fields$iter__992000486__992000490$fn__992000491", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_A_class, Simple: "fn__992000491", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_InstanceOf; i.Init = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_Init; i.Table = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_class, reflect.TypeFor[A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A]()) }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_fn_class)}; return nil }

var A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_invoke, New: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_new, Get: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_get}

var A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$clj_const_fields$iter__992000486__992000490$fn__992000491$fn__992000492", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_A_class, Simple: "fn__992000492", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_InstanceOf; i.Init = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_Init; i.Table = A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A_class, reflect.TypeFor[A_arbace_a2g_decls_clj_const_fields_iter__992000486__992000490_fn__992000491_fn__992000492_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_A_get}

var A_arbace_a2g_decls_ctor_call_translator_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "ctor_call_translator", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_A_class, Simple: "fn__992000126", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$fn__992000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class, Simple: "fn__992000127", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000127_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$fn__992000142", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class, Simple: "fn__992000142", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000142_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$fn__992000144", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class, Simple: "fn__992000144", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_fn__992000144_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000132__992000136", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class, Simple: "iter__992000132__992000136", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000132__992000136$fn__992000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_A_class, Simple: "fn__992000137", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000132__992000136$fn__992000137$fn__992000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_A_class, Simple: "fn__992000138", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000132__992000136_fn__992000137_fn__992000138_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000149__992000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_A_class, Simple: "iter__992000149__992000153", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000149__992000153$fn__992000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_A_class, Simple: "fn__992000154", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A]()) }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_invoke, New: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_new, Get: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_get}

var A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000149__992000153$fn__992000154$fn__992000155", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_A_class, Simple: "fn__992000155", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_Init; i.Table = A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_call_translator_fn__992000126_iter__992000149__992000153_fn__992000154_fn__992000155_A]()) }

func A_arbace_a2g_decls_ctor_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_desc_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_ctor_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_desc_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_desc_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_desc_A_invoke, New: A_arbace_a2g_decls_ctor_desc_A_new, Get: A_arbace_a2g_decls_ctor_desc_A_get}

var A_arbace_a2g_decls_ctor_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "ctor_desc", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_desc_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_desc_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_desc_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_desc_A_Init; i.Table = A_arbace_a2g_decls_ctor_desc_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_desc_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_desc_A]()) }

func A_arbace_a2g_decls_ctor_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_ctor_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_A_invoke, New: A_arbace_a2g_decls_ctor_forms_A_new, Get: A_arbace_a2g_decls_ctor_forms_A_get}

var A_arbace_a2g_decls_ctor_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "ctor_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_A]()) }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_fn__992000195_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_fn__992000195_A_New_O_O_O_O_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11])}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_fn__992000195_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_fn__992000195_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_fn__992000195_A_invoke, New: A_arbace_a2g_decls_ctor_forms_fn__992000195_A_new, Get: A_arbace_a2g_decls_ctor_forms_fn__992000195_A_get}

var A_arbace_a2g_decls_ctor_forms_fn__992000195_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$fn__992000195", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_A_class, Simple: "fn__992000195", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_fn__992000195_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_fn__992000195_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_fn__992000195_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_fn__992000195_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_fn__992000195_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_fn__992000195_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_fn__992000195_A]()) }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_New_O_O_O_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10])}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_invoke, New: A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_new, Get: A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_get}

var A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$fn__992000195$fn__992000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_fn__992000195_A_class, Simple: "fn__992000196", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A]()) }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_invoke, New: A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_new, Get: A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_get}

var A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$fn__992000195$fn__992000196$fn__992000215", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_A_class, Simple: "fn__992000215", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_fn__992000195_fn__992000196_fn__992000215_A]()) }

func A_arbace_a2g_decls_ctor_forms_fn__992000243_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_fn__992000243_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000243_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_fn__992000243_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_forms_fn__992000243_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_fn__992000243_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_fn__992000243_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_fn__992000243_A_invoke, New: A_arbace_a2g_decls_ctor_forms_fn__992000243_A_new, Get: A_arbace_a2g_decls_ctor_forms_fn__992000243_A_get}

var A_arbace_a2g_decls_ctor_forms_fn__992000243_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$fn__992000243", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_forms_A_class, Simple: "fn__992000243", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_fn__992000243_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_fn__992000243_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_fn__992000243_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_fn__992000243_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_fn__992000243_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_fn__992000243_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_fn__992000243_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000165__992000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_forms_A_class, Simple: "iter__992000165__992000169", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000165__992000169$fn__992000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_A_class, Simple: "fn__992000170", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000165__992000169$fn__992000170$fn__992000171", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_A_class, Simple: "fn__992000171", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000165__992000169_fn__992000170_fn__992000171_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000175__992000179", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_forms_A_class, Simple: "iter__992000175__992000179", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000175__992000179$fn__992000180", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_A_class, Simple: "fn__992000180", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000175__992000179$fn__992000180$fn__992000181", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_A_class, Simple: "fn__992000181", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000175__992000179_fn__992000180_fn__992000181_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_New()}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000185__992000189", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_forms_A_class, Simple: "iter__992000185__992000189", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000185__992000189$fn__992000190", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_A_class, Simple: "fn__992000190", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000185__992000189$fn__992000190$fn__992000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_A_class, Simple: "fn__992000191", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000185__992000189_fn__992000190_fn__992000191_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000233__992000237", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_ctor_forms_A_class, Simple: "iter__992000233__992000237", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000233__992000237$fn__992000238", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_A_class, Simple: "fn__992000238", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A]()) }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_invoke, New: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_new, Get: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_get}

var A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ctor_forms$iter__992000233__992000237$fn__992000238$fn__992000239", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_A_class, Simple: "fn__992000239", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_InstanceOf; i.Init = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_Init; i.Table = A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A_class, reflect.TypeFor[A_arbace_a2g_decls_ctor_forms_iter__992000233__992000237_fn__992000238_fn__992000239_A]()) }

func A_arbace_a2g_decls_derived_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_derived_body_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_decls_derived_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_derived_body_A_New()}; return nil }

func A_arbace_a2g_decls_derived_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_derived_body_A_fn_class)}; return nil }

var A_arbace_a2g_decls_derived_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_derived_body_A_invoke, New: A_arbace_a2g_decls_derived_body_A_new, Get: A_arbace_a2g_decls_derived_body_A_get}

var A_arbace_a2g_decls_derived_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$derived_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "derived_body", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_derived_body_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_derived_body_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_derived_body_A_InstanceOf; i.Init = A_arbace_a2g_decls_derived_body_A_Init; i.Table = A_arbace_a2g_decls_derived_body_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_derived_body_A_class, reflect.TypeFor[A_arbace_a2g_decls_derived_body_A]()) }

func A_arbace_a2g_decls_derived_body_fn__992000272_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_derived_body_fn__992000272_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_derived_body_fn__992000272_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_derived_body_fn__992000272_A_New()}; return nil }

func A_arbace_a2g_decls_derived_body_fn__992000272_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_derived_body_fn__992000272_A_fn_class)}; return nil }

var A_arbace_a2g_decls_derived_body_fn__992000272_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_derived_body_fn__992000272_A_invoke, New: A_arbace_a2g_decls_derived_body_fn__992000272_A_new, Get: A_arbace_a2g_decls_derived_body_fn__992000272_A_get}

var A_arbace_a2g_decls_derived_body_fn__992000272_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$derived_body$fn__992000272", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_decls_derived_body_A_class, Simple: "fn__992000272", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_derived_body_fn__992000272_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_derived_body_fn__992000272_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_derived_body_fn__992000272_A_InstanceOf; i.Init = A_arbace_a2g_decls_derived_body_fn__992000272_A_Init; i.Table = A_arbace_a2g_decls_derived_body_fn__992000272_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_derived_body_fn__992000272_A_class, reflect.TypeFor[A_arbace_a2g_decls_derived_body_fn__992000272_A]()) }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_fn_class)}; return nil }

var A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_invoke, New: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_new, Get: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_get}

var A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$derived_body$iter__992000274__992000278", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_derived_body_A_class, Simple: "iter__992000274__992000278", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_InstanceOf; i.Init = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_Init; i.Table = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_class, reflect.TypeFor[A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A]()) }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_fn_class)}; return nil }

var A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_invoke, New: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_new, Get: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_get}

var A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$derived_body$iter__992000274__992000278$fn__992000279", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_A_class, Simple: "fn__992000279", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_InstanceOf; i.Init = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_Init; i.Table = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_class, reflect.TypeFor[A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A]()) }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_fn_class)}; return nil }

var A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_invoke, New: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_new, Get: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_get}

var A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$derived_body$iter__992000274__992000278$fn__992000279$fn__992000280", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_A_class, Simple: "fn__992000280", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_InstanceOf; i.Init = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_Init; i.Table = A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A_class, reflect.TypeFor[A_arbace_a2g_decls_derived_body_iter__992000274__992000278_fn__992000279_fn__992000280_A]()) }

func A_arbace_a2g_decls_dispatch_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_A_New()}; return nil }

func A_arbace_a2g_decls_dispatch_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_A_new, Get: A_arbace_a2g_decls_dispatch_forms_A_get}

var A_arbace_a2g_decls_dispatch_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "dispatch_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_New()}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000371__992000375", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_A_class, Simple: "iter__992000371__992000375", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000371__992000375$fn__992000376", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_A_class, Simple: "fn__992000376", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000371__992000375$fn__992000376$fn__992000377", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_A_class, Simple: "fn__992000377", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000371__992000375_fn__992000376_fn__992000377_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_A_class, Simple: "iter__992000381__992000385", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_A_class, Simple: "fn__992000386", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_New_O_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4], args[5].(int32), args[6])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_class, Simple: "fn__992000387", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_New()}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387$iter__992000397__992000401", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_A_class, Simple: "iter__992000397__992000401", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387$iter__992000397__992000401$fn__992000402", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_A_class, Simple: "fn__992000402", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387$iter__992000397__992000401$fn__992000402$fn__992000403", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_A_class, Simple: "fn__992000403", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_fn__992000387_iter__992000397__992000401_fn__992000402_fn__992000403_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_New()}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$iter__992000417__992000421", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_A_class, Simple: "iter__992000417__992000421", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$iter__992000417__992000421$fn__992000422", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_A_class, Simple: "fn__992000422", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$iter__992000417__992000421$fn__992000422$fn__992000423", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_A_class, Simple: "fn__992000423", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000381__992000385_fn__992000386_iter__992000417__992000421_fn__992000422_fn__992000423_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_New()}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000429__992000433", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_A_class, Simple: "iter__992000429__992000433", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000429__992000433$fn__992000434", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_A_class, Simple: "fn__992000434", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A]()) }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_fn_class)}; return nil }

var A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_invoke, New: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_new, Get: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_get}

var A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$dispatch_forms$iter__992000429__992000433$fn__992000434$fn__992000435", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_A_class, Simple: "fn__992000435", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_InstanceOf; i.Init = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_Init; i.Table = A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A_class, reflect.TypeFor[A_arbace_a2g_decls_dispatch_forms_iter__992000429__992000433_fn__992000434_fn__992000435_A]()) }

func A_arbace_a2g_decls_ensure_terminated_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_ensure_terminated_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_ensure_terminated_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_ensure_terminated_A_New()}; return nil }

func A_arbace_a2g_decls_ensure_terminated_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_ensure_terminated_A_fn_class)}; return nil }

var A_arbace_a2g_decls_ensure_terminated_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_ensure_terminated_A_invoke, New: A_arbace_a2g_decls_ensure_terminated_A_new, Get: A_arbace_a2g_decls_ensure_terminated_A_get}

var A_arbace_a2g_decls_ensure_terminated_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$ensure_terminated", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "ensure_terminated", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_ensure_terminated_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_ensure_terminated_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_ensure_terminated_A_InstanceOf; i.Init = A_arbace_a2g_decls_ensure_terminated_A_Init; i.Table = A_arbace_a2g_decls_ensure_terminated_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_ensure_terminated_A_class, reflect.TypeFor[A_arbace_a2g_decls_ensure_terminated_A]()) }

func A_arbace_a2g_decls_eval992000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_eval992000004_A_New()}; return nil }

var A_arbace_a2g_decls_eval992000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_decls_eval992000004_A_new}

var A_arbace_a2g_decls_eval992000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$eval992000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_decls_A_class, Simple: "eval992000004", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_eval992000004_A"})

func init() { i := A_arbace_a2g_decls_eval992000004_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_eval992000004_A_InstanceOf; i.Table = A_arbace_a2g_decls_eval992000004_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_eval992000004_A_class, reflect.TypeFor[A_arbace_a2g_decls_eval992000004_A]()) }

func A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_New()}; return nil }

func A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_fn_class)}; return nil }

var A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_invoke, New: A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_new, Get: A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_get}

var A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$eval992000004$loading__1927001464__auto____992000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_eval992000004_A_class, Simple: "loading__1927001464__auto____992000005", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_InstanceOf; i.Init = A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_Init; i.Table = A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_class, reflect.TypeFor[A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A]()) }

func A_arbace_a2g_decls_eval992000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_eval992000008_A_New()}; return nil }

var A_arbace_a2g_decls_eval992000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_decls_eval992000008_A_new}

var A_arbace_a2g_decls_eval992000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$eval992000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_decls_A_class, Simple: "eval992000008", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_eval992000008_A"})

func init() { i := A_arbace_a2g_decls_eval992000008_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_eval992000008_A_InstanceOf; i.Table = A_arbace_a2g_decls_eval992000008_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_eval992000008_A_class, reflect.TypeFor[A_arbace_a2g_decls_eval992000008_A]()) }

func A_arbace_a2g_decls_eval992000008_fn__992000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_eval992000008_fn__992000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_eval992000008_fn__992000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_eval992000008_fn__992000009_A_New()}; return nil }

func A_arbace_a2g_decls_eval992000008_fn__992000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_eval992000008_fn__992000009_A_fn_class)}; return nil }

var A_arbace_a2g_decls_eval992000008_fn__992000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_eval992000008_fn__992000009_A_invoke, New: A_arbace_a2g_decls_eval992000008_fn__992000009_A_new, Get: A_arbace_a2g_decls_eval992000008_fn__992000009_A_get}

var A_arbace_a2g_decls_eval992000008_fn__992000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$eval992000008$fn__992000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_eval992000008_A_class, Simple: "fn__992000009", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_eval992000008_fn__992000009_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_eval992000008_fn__992000009_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_eval992000008_fn__992000009_A_InstanceOf; i.Init = A_arbace_a2g_decls_eval992000008_fn__992000009_A_Init; i.Table = A_arbace_a2g_decls_eval992000008_fn__992000009_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_eval992000008_fn__992000009_A_class, reflect.TypeFor[A_arbace_a2g_decls_eval992000008_fn__992000009_A]()) }

func A_arbace_a2g_decls_extra_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_extra_fields_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_extra_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_extra_fields_A_New()}; return nil }

func A_arbace_a2g_decls_extra_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_extra_fields_A_fn_class)}; return nil }

var A_arbace_a2g_decls_extra_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_extra_fields_A_invoke, New: A_arbace_a2g_decls_extra_fields_A_new, Get: A_arbace_a2g_decls_extra_fields_A_get}

var A_arbace_a2g_decls_extra_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$extra_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "extra_fields", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_extra_fields_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_extra_fields_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_extra_fields_A_InstanceOf; i.Init = A_arbace_a2g_decls_extra_fields_A_Init; i.Table = A_arbace_a2g_decls_extra_fields_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_extra_fields_A_class, reflect.TypeFor[A_arbace_a2g_decls_extra_fields_A]()) }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_fn_class)}; return nil }

var A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_invoke, New: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_new, Get: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_get}

var A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$extra_fields$iter__992000088__992000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_extra_fields_A_class, Simple: "iter__992000088__992000092", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_InstanceOf; i.Init = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_Init; i.Table = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_class, reflect.TypeFor[A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A]()) }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_fn_class)}; return nil }

var A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_invoke, New: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_new, Get: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_get}

var A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$extra_fields$iter__992000088__992000092$fn__992000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_A_class, Simple: "fn__992000093", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_InstanceOf; i.Init = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_Init; i.Table = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_class, reflect.TypeFor[A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A]()) }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_fn_class)}; return nil }

var A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_invoke, New: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_new, Get: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_get}

var A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$extra_fields$iter__992000088__992000092$fn__992000093$fn__992000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_A_class, Simple: "fn__992000094", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_InstanceOf; i.Init = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_Init; i.Table = A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A_class, reflect.TypeFor[A_arbace_a2g_decls_extra_fields_iter__992000088__992000092_fn__992000093_fn__992000094_A]()) }

func A_arbace_a2g_decls_field_go_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_field_go_type_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_field_go_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_field_go_type_A_New()}; return nil }

func A_arbace_a2g_decls_field_go_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_field_go_type_A_fn_class)}; return nil }

var A_arbace_a2g_decls_field_go_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_field_go_type_A_invoke, New: A_arbace_a2g_decls_field_go_type_A_new, Get: A_arbace_a2g_decls_field_go_type_A_get}

var A_arbace_a2g_decls_field_go_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$field_go_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "field_go_type", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_field_go_type_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_field_go_type_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_field_go_type_A_InstanceOf; i.Init = A_arbace_a2g_decls_field_go_type_A_Init; i.Table = A_arbace_a2g_decls_field_go_type_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_field_go_type_A_class, reflect.TypeFor[A_arbace_a2g_decls_field_go_type_A]()) }

func A_arbace_a2g_decls_forwarder_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_forwarder_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_decls_forwarder_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_forwarder_A_New()}; return nil }

func A_arbace_a2g_decls_forwarder_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_forwarder_A_fn_class)}; return nil }

var A_arbace_a2g_decls_forwarder_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_forwarder_A_invoke, New: A_arbace_a2g_decls_forwarder_A_new, Get: A_arbace_a2g_decls_forwarder_A_get}

var A_arbace_a2g_decls_forwarder_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$forwarder", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "forwarder", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_forwarder_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_forwarder_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_forwarder_A_InstanceOf; i.Init = A_arbace_a2g_decls_forwarder_A_Init; i.Table = A_arbace_a2g_decls_forwarder_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_forwarder_A_class, reflect.TypeFor[A_arbace_a2g_decls_forwarder_A]()) }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_New()}; return nil }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_fn_class)}; return nil }

var A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_invoke, New: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_new, Get: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_get}

var A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$forwarder$iter__992000355__992000359", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_forwarder_A_class, Simple: "iter__992000355__992000359", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_InstanceOf; i.Init = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_Init; i.Table = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_class, reflect.TypeFor[A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A]()) }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_fn_class)}; return nil }

var A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_invoke, New: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_new, Get: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_get}

var A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$forwarder$iter__992000355__992000359$fn__992000360", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_A_class, Simple: "fn__992000360", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_InstanceOf; i.Init = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_Init; i.Table = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_class, reflect.TypeFor[A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A]()) }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_fn_class)}; return nil }

var A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_invoke, New: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_new, Get: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_get}

var A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$forwarder$iter__992000355__992000359$fn__992000360$fn__992000361", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_A_class, Simple: "fn__992000361", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_InstanceOf; i.Init = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_Init; i.Table = A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A_class, reflect.TypeFor[A_arbace_a2g_decls_forwarder_iter__992000355__992000359_fn__992000360_fn__992000361_A]()) }

func A_arbace_a2g_decls_gt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_gt_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_gt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_gt_A_New()}; return nil }

func A_arbace_a2g_decls_gt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_gt_A_fn_class)}; return nil }

var A_arbace_a2g_decls_gt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_gt_A_invoke, New: A_arbace_a2g_decls_gt_A_new, Get: A_arbace_a2g_decls_gt_A_get}

var A_arbace_a2g_decls_gt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$gt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "gt", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_gt_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_gt_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_gt_A_InstanceOf; i.Init = A_arbace_a2g_decls_gt_A_Init; i.Table = A_arbace_a2g_decls_gt_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_gt_A_class, reflect.TypeFor[A_arbace_a2g_decls_gt_A]()) }

func A_arbace_a2g_decls_has_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_has_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_has_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_has_QMARK__A_New()}; return nil }

func A_arbace_a2g_decls_has_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_has_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_decls_has_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_has_QMARK__A_invoke, New: A_arbace_a2g_decls_has_QMARK__A_new, Get: A_arbace_a2g_decls_has_QMARK__A_get}

var A_arbace_a2g_decls_has_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$has_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "has_QMARK_", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_has_QMARK__A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_has_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_decls_has_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_decls_has_QMARK__A_Init; i.Table = A_arbace_a2g_decls_has_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_decls_has_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_decls_has_QMARK__A]()) }

func A_arbace_a2g_decls_hw_markers_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_hw_markers_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_hw_markers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_hw_markers_A_New()}; return nil }

func A_arbace_a2g_decls_hw_markers_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_hw_markers_A_fn_class)}; return nil }

var A_arbace_a2g_decls_hw_markers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_hw_markers_A_invoke, New: A_arbace_a2g_decls_hw_markers_A_new, Get: A_arbace_a2g_decls_hw_markers_A_get}

var A_arbace_a2g_decls_hw_markers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$hw_markers", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "hw_markers", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_hw_markers_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_hw_markers_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_hw_markers_A_InstanceOf; i.Init = A_arbace_a2g_decls_hw_markers_A_Init; i.Table = A_arbace_a2g_decls_hw_markers_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_hw_markers_A_class, reflect.TypeFor[A_arbace_a2g_decls_hw_markers_A]()) }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_New()}; return nil }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_fn_class)}; return nil }

var A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_invoke, New: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_new, Get: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_get}

var A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$hw_markers$iter__992000109__992000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_hw_markers_A_class, Simple: "iter__992000109__992000113", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_InstanceOf; i.Init = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_Init; i.Table = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_class, reflect.TypeFor[A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A]()) }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_fn_class)}; return nil }

var A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_invoke, New: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_new, Get: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_get}

var A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$hw_markers$iter__992000109__992000113$fn__992000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_A_class, Simple: "fn__992000114", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_InstanceOf; i.Init = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_Init; i.Table = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_class, reflect.TypeFor[A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A]()) }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_fn_class)}; return nil }

var A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_invoke, New: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_new, Get: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_get}

var A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$hw_markers$iter__992000109__992000113$fn__992000114$fn__992000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_A_class, Simple: "fn__992000115", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_InstanceOf; i.Init = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_Init; i.Table = A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A_class, reflect.TypeFor[A_arbace_a2g_decls_hw_markers_iter__992000109__992000113_fn__992000114_fn__992000115_A]()) }

func A_arbace_a2g_decls_iface_method_elem_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_iface_method_elem_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_iface_method_elem_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_iface_method_elem_A_New()}; return nil }

func A_arbace_a2g_decls_iface_method_elem_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_iface_method_elem_A_fn_class)}; return nil }

var A_arbace_a2g_decls_iface_method_elem_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_iface_method_elem_A_invoke, New: A_arbace_a2g_decls_iface_method_elem_A_new, Get: A_arbace_a2g_decls_iface_method_elem_A_get}

var A_arbace_a2g_decls_iface_method_elem_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$iface_method_elem", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "iface_method_elem", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_iface_method_elem_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_iface_method_elem_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_iface_method_elem_A_InstanceOf; i.Init = A_arbace_a2g_decls_iface_method_elem_A_Init; i.Table = A_arbace_a2g_decls_iface_method_elem_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_iface_method_elem_A_class, reflect.TypeFor[A_arbace_a2g_decls_iface_method_elem_A]()) }

func A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_iface_method_elem_fn__992000102_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_fn_class)}; return nil }

var A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_invoke, New: A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_new, Get: A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_get}

var A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$iface_method_elem$fn__992000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_iface_method_elem_A_class, Simple: "fn__992000102", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_iface_method_elem_fn__992000102_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_InstanceOf; i.Init = A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_Init; i.Table = A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_iface_method_elem_fn__992000102_A_class, reflect.TypeFor[A_arbace_a2g_decls_iface_method_elem_fn__992000102_A]()) }

func A_arbace_a2g_decls_init_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_init_forms_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_init_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_init_forms_A_New()}; return nil }

func A_arbace_a2g_decls_init_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_init_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_init_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_init_forms_A_invoke, New: A_arbace_a2g_decls_init_forms_A_new, Get: A_arbace_a2g_decls_init_forms_A_get}

var A_arbace_a2g_decls_init_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$init_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "init_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_init_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_init_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_init_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_init_forms_A_Init; i.Table = A_arbace_a2g_decls_init_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_init_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_init_forms_A]()) }

func A_arbace_a2g_decls_init_forms_fn__992000461_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_init_forms_fn__992000461_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_init_forms_fn__992000461_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_init_forms_fn__992000461_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_decls_init_forms_fn__992000461_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_init_forms_fn__992000461_A_fn_class)}; return nil }

var A_arbace_a2g_decls_init_forms_fn__992000461_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_init_forms_fn__992000461_A_invoke, New: A_arbace_a2g_decls_init_forms_fn__992000461_A_new, Get: A_arbace_a2g_decls_init_forms_fn__992000461_A_get}

var A_arbace_a2g_decls_init_forms_fn__992000461_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$init_forms$fn__992000461", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_init_forms_A_class, Simple: "fn__992000461", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_init_forms_fn__992000461_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_init_forms_fn__992000461_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_init_forms_fn__992000461_A_InstanceOf; i.Init = A_arbace_a2g_decls_init_forms_fn__992000461_A_Init; i.Table = A_arbace_a2g_decls_init_forms_fn__992000461_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_init_forms_fn__992000461_A_class, reflect.TypeFor[A_arbace_a2g_decls_init_forms_fn__992000461_A]()) }

func A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_fn_class)}; return nil }

var A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_invoke, New: A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_new, Get: A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_get}

var A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$init_forms$fn__992000461$fn__992000462", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_init_forms_fn__992000461_A_class, Simple: "fn__992000462", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_InstanceOf; i.Init = A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_Init; i.Table = A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A_class, reflect.TypeFor[A_arbace_a2g_decls_init_forms_fn__992000461_fn__992000462_A]()) }

func A_arbace_a2g_decls_instance_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_instance_forms_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_instance_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_instance_forms_A_New()}; return nil }

func A_arbace_a2g_decls_instance_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_instance_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_instance_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_instance_forms_A_invoke, New: A_arbace_a2g_decls_instance_forms_A_new, Get: A_arbace_a2g_decls_instance_forms_A_get}

var A_arbace_a2g_decls_instance_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$instance_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "instance_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_instance_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_instance_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_instance_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_instance_forms_A_Init; i.Table = A_arbace_a2g_decls_instance_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_instance_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_instance_forms_A]()) }

func A_arbace_a2g_decls_interface_closure_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_interface_closure_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_interface_closure_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_interface_closure_A_New()}; return nil }

func A_arbace_a2g_decls_interface_closure_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_interface_closure_A_fn_class)}; return nil }

var A_arbace_a2g_decls_interface_closure_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_interface_closure_A_invoke, New: A_arbace_a2g_decls_interface_closure_A_new, Get: A_arbace_a2g_decls_interface_closure_A_get}

var A_arbace_a2g_decls_interface_closure_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$interface_closure", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "interface_closure", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_interface_closure_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_interface_closure_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_interface_closure_A_InstanceOf; i.Init = A_arbace_a2g_decls_interface_closure_A_Init; i.Table = A_arbace_a2g_decls_interface_closure_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_interface_closure_A_class, reflect.TypeFor[A_arbace_a2g_decls_interface_closure_A]()) }

func A_arbace_a2g_decls_interface_closure_fn__992000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_interface_closure_fn__992000106_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_interface_closure_fn__992000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_interface_closure_fn__992000106_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_interface_closure_fn__992000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_interface_closure_fn__992000106_A_fn_class)}; return nil }

var A_arbace_a2g_decls_interface_closure_fn__992000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_interface_closure_fn__992000106_A_invoke, New: A_arbace_a2g_decls_interface_closure_fn__992000106_A_new, Get: A_arbace_a2g_decls_interface_closure_fn__992000106_A_get}

var A_arbace_a2g_decls_interface_closure_fn__992000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$interface_closure$fn__992000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_interface_closure_A_class, Simple: "fn__992000106", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_interface_closure_fn__992000106_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_interface_closure_fn__992000106_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_interface_closure_fn__992000106_A_InstanceOf; i.Init = A_arbace_a2g_decls_interface_closure_fn__992000106_A_Init; i.Table = A_arbace_a2g_decls_interface_closure_fn__992000106_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_interface_closure_fn__992000106_A_class, reflect.TypeFor[A_arbace_a2g_decls_interface_closure_fn__992000106_A]()) }

func A_arbace_a2g_decls_markers_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_markers_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_markers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_markers_A_New()}; return nil }

func A_arbace_a2g_decls_markers_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_markers_A_fn_class)}; return nil }

var A_arbace_a2g_decls_markers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_markers_A_invoke, New: A_arbace_a2g_decls_markers_A_new, Get: A_arbace_a2g_decls_markers_A_get}

var A_arbace_a2g_decls_markers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$markers", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "markers", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_markers_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_markers_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_markers_A_InstanceOf; i.Init = A_arbace_a2g_decls_markers_A_Init; i.Table = A_arbace_a2g_decls_markers_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_markers_A_class, reflect.TypeFor[A_arbace_a2g_decls_markers_A]()) }

func A_arbace_a2g_decls_markers_fn__992000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_markers_fn__992000121_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_markers_fn__992000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_markers_fn__992000121_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_markers_fn__992000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_markers_fn__992000121_A_fn_class)}; return nil }

var A_arbace_a2g_decls_markers_fn__992000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_markers_fn__992000121_A_invoke, New: A_arbace_a2g_decls_markers_fn__992000121_A_new, Get: A_arbace_a2g_decls_markers_fn__992000121_A_get}

var A_arbace_a2g_decls_markers_fn__992000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$markers$fn__992000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_markers_A_class, Simple: "fn__992000121", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_markers_fn__992000121_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_markers_fn__992000121_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_markers_fn__992000121_A_InstanceOf; i.Init = A_arbace_a2g_decls_markers_fn__992000121_A_Init; i.Table = A_arbace_a2g_decls_markers_fn__992000121_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_markers_fn__992000121_A_class, reflect.TypeFor[A_arbace_a2g_decls_markers_fn__992000121_A]()) }

func A_arbace_a2g_decls_member_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_member_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_member_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_member_line_A_New()}; return nil }

func A_arbace_a2g_decls_member_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_member_line_A_fn_class)}; return nil }

var A_arbace_a2g_decls_member_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_member_line_A_invoke, New: A_arbace_a2g_decls_member_line_A_new, Get: A_arbace_a2g_decls_member_line_A_get}

var A_arbace_a2g_decls_member_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$member_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "member_line", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_member_line_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_member_line_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_member_line_A_InstanceOf; i.Init = A_arbace_a2g_decls_member_line_A_Init; i.Table = A_arbace_a2g_decls_member_line_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_member_line_A_class, reflect.TypeFor[A_arbace_a2g_decls_member_line_A]()) }

func A_arbace_a2g_decls_method_code_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_code_forms_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_decls_method_code_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_code_forms_A_New()}; return nil }

func A_arbace_a2g_decls_method_code_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_code_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_code_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_code_forms_A_invoke, New: A_arbace_a2g_decls_method_code_forms_A_new, Get: A_arbace_a2g_decls_method_code_forms_A_get}

var A_arbace_a2g_decls_method_code_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_code_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "method_code_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_code_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_code_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_code_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_code_forms_A_Init; i.Table = A_arbace_a2g_decls_method_code_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_code_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_code_forms_A]()) }

func A_arbace_a2g_decls_method_code_forms_fn__992000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_code_forms_fn__992000057_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_code_forms_fn__992000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_code_forms_fn__992000057_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_a2g_decls_method_code_forms_fn__992000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_code_forms_fn__992000057_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_code_forms_fn__992000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_code_forms_fn__992000057_A_invoke, New: A_arbace_a2g_decls_method_code_forms_fn__992000057_A_new, Get: A_arbace_a2g_decls_method_code_forms_fn__992000057_A_get}

var A_arbace_a2g_decls_method_code_forms_fn__992000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_code_forms$fn__992000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_code_forms_A_class, Simple: "fn__992000057", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_code_forms_fn__992000057_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_code_forms_fn__992000057_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_code_forms_fn__992000057_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_code_forms_fn__992000057_A_Init; i.Table = A_arbace_a2g_decls_method_code_forms_fn__992000057_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_code_forms_fn__992000057_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_code_forms_fn__992000057_A]()) }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_New()}; return nil }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_invoke, New: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_new, Get: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_get}

var A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_code_forms$iter__992000047__992000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_method_code_forms_A_class, Simple: "iter__992000047__992000051", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_Init; i.Table = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A]()) }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_invoke, New: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_new, Get: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_get}

var A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_code_forms$iter__992000047__992000051$fn__992000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_A_class, Simple: "fn__992000052", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_Init; i.Table = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A]()) }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_invoke, New: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_new, Get: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_get}

var A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_code_forms$iter__992000047__992000051$fn__992000052$fn__992000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_A_class, Simple: "fn__992000053", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_Init; i.Table = A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_code_forms_iter__992000047__992000051_fn__992000052_fn__992000053_A]()) }

func A_arbace_a2g_decls_method_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_method_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_A_New()}; return nil }

func A_arbace_a2g_decls_method_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_A_invoke, New: A_arbace_a2g_decls_method_forms_A_new, Get: A_arbace_a2g_decls_method_forms_A_get}

var A_arbace_a2g_decls_method_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "method_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_A_Init; i.Table = A_arbace_a2g_decls_method_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_A]()) }

func A_arbace_a2g_decls_method_forms_fn__992000325_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_fn__992000325_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_fn__992000325_A_New_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_fn__992000325_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_fn__992000325_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_fn__992000325_A_invoke, New: A_arbace_a2g_decls_method_forms_fn__992000325_A_new, Get: A_arbace_a2g_decls_method_forms_fn__992000325_A_get}

var A_arbace_a2g_decls_method_forms_fn__992000325_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$fn__992000325", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_A_class, Simple: "fn__992000325", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_fn__992000325_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_fn__992000325_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_fn__992000325_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_fn__992000325_A_Init; i.Table = A_arbace_a2g_decls_method_forms_fn__992000325_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_fn__992000325_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_fn__992000325_A]()) }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_New()}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_invoke, New: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_new, Get: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_get}

var A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$fn__992000325$iter__992000326__992000330", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_method_forms_fn__992000325_A_class, Simple: "iter__992000326__992000330", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_Init; i.Table = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A]()) }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_invoke, New: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_new, Get: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_get}

var A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$fn__992000325$iter__992000326__992000330$fn__992000331", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_A_class, Simple: "fn__992000331", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_Init; i.Table = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A]()) }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_invoke, New: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_new, Get: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_get}

var A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$fn__992000325$iter__992000326__992000330$fn__992000331$fn__992000332", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_A_class, Simple: "fn__992000332", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_Init; i.Table = A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_fn__992000325_iter__992000326__992000330_fn__992000331_fn__992000332_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_New()}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000295__992000299", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_method_forms_A_class, Simple: "iter__992000295__992000299", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000295__992000299$fn__992000300", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_A_class, Simple: "fn__992000300", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000295__992000299$fn__992000300$fn__992000301", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_A_class, Simple: "fn__992000301", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000295__992000299_fn__992000300_fn__992000301_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_New()}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000305__992000309", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_method_forms_A_class, Simple: "iter__992000305__992000309", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000305__992000309$fn__992000310", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_A_class, Simple: "fn__992000310", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000305__992000309$fn__992000310$fn__992000311", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_A_class, Simple: "fn__992000311", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000305__992000309_fn__992000310_fn__992000311_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_New()}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000315__992000319", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_method_forms_A_class, Simple: "iter__992000315__992000319", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000315__992000319$fn__992000320", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_A_class, Simple: "fn__992000320", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000315__992000319$fn__992000320$fn__992000321", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_A_class, Simple: "fn__992000321", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000315__992000319_fn__992000320_fn__992000321_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_New()}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000337__992000341", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_method_forms_A_class, Simple: "iter__992000337__992000341", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000337__992000341$fn__992000342", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_A_class, Simple: "fn__992000342", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A]()) }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_fn_class)}; return nil }

var A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_invoke, New: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_new, Get: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_get}

var A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$method_forms$iter__992000337__992000341$fn__992000342$fn__992000343", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_A_class, Simple: "fn__992000343", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_InstanceOf; i.Init = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_Init; i.Table = A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A_class, reflect.TypeFor[A_arbace_a2g_decls_method_forms_iter__992000337__992000341_fn__992000342_fn__992000343_A]()) }

func A_arbace_a2g_decls_needs_entry_guard_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_needs_entry_guard_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_needs_entry_guard_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_needs_entry_guard_QMARK__A_New()}; return nil }

func A_arbace_a2g_decls_needs_entry_guard_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_needs_entry_guard_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_decls_needs_entry_guard_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_needs_entry_guard_QMARK__A_invoke, New: A_arbace_a2g_decls_needs_entry_guard_QMARK__A_new, Get: A_arbace_a2g_decls_needs_entry_guard_QMARK__A_get}

var A_arbace_a2g_decls_needs_entry_guard_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$needs_entry_guard_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "needs_entry_guard_QMARK_", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_needs_entry_guard_QMARK__A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_needs_entry_guard_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_decls_needs_entry_guard_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_decls_needs_entry_guard_QMARK__A_Init; i.Table = A_arbace_a2g_decls_needs_entry_guard_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_decls_needs_entry_guard_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_decls_needs_entry_guard_QMARK__A]()) }

func A_arbace_a2g_decls_new_fn_state_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_new_fn_state_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_new_fn_state_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_new_fn_state_A_New()}; return nil }

func A_arbace_a2g_decls_new_fn_state_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_new_fn_state_A_fn_class)}; return nil }

var A_arbace_a2g_decls_new_fn_state_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_new_fn_state_A_invoke, New: A_arbace_a2g_decls_new_fn_state_A_new, Get: A_arbace_a2g_decls_new_fn_state_A_get}

var A_arbace_a2g_decls_new_fn_state_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$new_fn_state", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "new_fn_state", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_new_fn_state_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_new_fn_state_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_new_fn_state_A_InstanceOf; i.Init = A_arbace_a2g_decls_new_fn_state_A_Init; i.Table = A_arbace_a2g_decls_new_fn_state_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_new_fn_state_A_class, reflect.TypeFor[A_arbace_a2g_decls_new_fn_state_A]()) }

func A_arbace_a2g_decls_object_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_object_forms_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_object_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_object_forms_A_New()}; return nil }

func A_arbace_a2g_decls_object_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_object_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_object_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_object_forms_A_invoke, New: A_arbace_a2g_decls_object_forms_A_new, Get: A_arbace_a2g_decls_object_forms_A_get}

var A_arbace_a2g_decls_object_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$object_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "object_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_object_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_object_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_object_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_object_forms_A_Init; i.Table = A_arbace_a2g_decls_object_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_object_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_object_forms_A]()) }

func A_arbace_a2g_decls_object_forms_fn__992000368_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_object_forms_fn__992000368_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_object_forms_fn__992000368_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_object_forms_fn__992000368_A_New()}; return nil }

func A_arbace_a2g_decls_object_forms_fn__992000368_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_object_forms_fn__992000368_A_fn_class)}; return nil }

var A_arbace_a2g_decls_object_forms_fn__992000368_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_object_forms_fn__992000368_A_invoke, New: A_arbace_a2g_decls_object_forms_fn__992000368_A_new, Get: A_arbace_a2g_decls_object_forms_fn__992000368_A_get}

var A_arbace_a2g_decls_object_forms_fn__992000368_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$object_forms$fn__992000368", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_object_forms_A_class, Simple: "fn__992000368", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_object_forms_fn__992000368_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_object_forms_fn__992000368_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_object_forms_fn__992000368_A_InstanceOf; i.Init = A_arbace_a2g_decls_object_forms_fn__992000368_A_Init; i.Table = A_arbace_a2g_decls_object_forms_fn__992000368_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_object_forms_fn__992000368_A_class, reflect.TypeFor[A_arbace_a2g_decls_object_forms_fn__992000368_A]()) }

func A_arbace_a2g_decls_param_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_param_list_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_param_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_param_list_A_New()}; return nil }

func A_arbace_a2g_decls_param_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_param_list_A_fn_class)}; return nil }

var A_arbace_a2g_decls_param_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_param_list_A_invoke, New: A_arbace_a2g_decls_param_list_A_new, Get: A_arbace_a2g_decls_param_list_A_get}

var A_arbace_a2g_decls_param_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$param_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "param_list", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_param_list_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_param_list_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_param_list_A_InstanceOf; i.Init = A_arbace_a2g_decls_param_list_A_Init; i.Table = A_arbace_a2g_decls_param_list_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_param_list_A_class, reflect.TypeFor[A_arbace_a2g_decls_param_list_A]()) }

func A_arbace_a2g_decls_param_list_fn__992000015_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_param_list_fn__992000015_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_param_list_fn__992000015_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_param_list_fn__992000015_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_param_list_fn__992000015_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_param_list_fn__992000015_A_fn_class)}; return nil }

var A_arbace_a2g_decls_param_list_fn__992000015_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_param_list_fn__992000015_A_invoke, New: A_arbace_a2g_decls_param_list_fn__992000015_A_new, Get: A_arbace_a2g_decls_param_list_fn__992000015_A_get}

var A_arbace_a2g_decls_param_list_fn__992000015_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$param_list$fn__992000015", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_param_list_A_class, Simple: "fn__992000015", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_param_list_fn__992000015_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_param_list_fn__992000015_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_param_list_fn__992000015_A_InstanceOf; i.Init = A_arbace_a2g_decls_param_list_fn__992000015_A_Init; i.Table = A_arbace_a2g_decls_param_list_fn__992000015_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_param_list_fn__992000015_A_class, reflect.TypeFor[A_arbace_a2g_decls_param_list_fn__992000015_A]()) }

func A_arbace_a2g_decls_reached_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reached_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_reached_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reached_QMARK__A_New()}; return nil }

func A_arbace_a2g_decls_reached_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reached_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_decls_reached_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reached_QMARK__A_invoke, New: A_arbace_a2g_decls_reached_QMARK__A_new, Get: A_arbace_a2g_decls_reached_QMARK__A_get}

var A_arbace_a2g_decls_reached_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reached_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "reached_QMARK_", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reached_QMARK__A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reached_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reached_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_decls_reached_QMARK__A_Init; i.Table = A_arbace_a2g_decls_reached_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reached_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_decls_reached_QMARK__A]()) }

func A_arbace_a2g_decls_record_object_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_decls_record_object_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_A_New()}; return nil }

func A_arbace_a2g_decls_record_object_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_A_invoke, New: A_arbace_a2g_decls_record_object_body_A_new, Get: A_arbace_a2g_decls_record_object_body_A_get}

var A_arbace_a2g_decls_record_object_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "record_object_body", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_A]()) }

func A_arbace_a2g_decls_record_object_body_fld__992000248_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_fld__992000248_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_record_object_body_fld__992000248_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_fld__992000248_A_New()}; return nil }

func A_arbace_a2g_decls_record_object_body_fld__992000248_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_fld__992000248_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_fld__992000248_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_fld__992000248_A_invoke, New: A_arbace_a2g_decls_record_object_body_fld__992000248_A_new, Get: A_arbace_a2g_decls_record_object_body_fld__992000248_A_get}

var A_arbace_a2g_decls_record_object_body_fld__992000248_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body$fld__992000248", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_record_object_body_A_class, Simple: "fld__992000248", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_fld__992000248_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_fld__992000248_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_fld__992000248_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_fld__992000248_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_fld__992000248_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_fld__992000248_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_fld__992000248_A]()) }

func A_arbace_a2g_decls_record_object_body_fn__992000257_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_fn__992000257_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_record_object_body_fn__992000257_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_fn__992000257_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_record_object_body_fn__992000257_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_fn__992000257_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_fn__992000257_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_fn__992000257_A_invoke, New: A_arbace_a2g_decls_record_object_body_fn__992000257_A_new, Get: A_arbace_a2g_decls_record_object_body_fn__992000257_A_get}

var A_arbace_a2g_decls_record_object_body_fn__992000257_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body$fn__992000257", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_record_object_body_A_class, Simple: "fn__992000257", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_fn__992000257_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_fn__992000257_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_fn__992000257_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_fn__992000257_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_fn__992000257_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_fn__992000257_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_fn__992000257_A]()) }

func A_arbace_a2g_decls_record_object_body_fn__992000259_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_fn__992000259_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_record_object_body_fn__992000259_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_fn__992000259_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_record_object_body_fn__992000259_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_fn__992000259_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_fn__992000259_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_fn__992000259_A_invoke, New: A_arbace_a2g_decls_record_object_body_fn__992000259_A_new, Get: A_arbace_a2g_decls_record_object_body_fn__992000259_A_get}

var A_arbace_a2g_decls_record_object_body_fn__992000259_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body$fn__992000259", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_record_object_body_A_class, Simple: "fn__992000259", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_fn__992000259_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_fn__992000259_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_fn__992000259_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_fn__992000259_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_fn__992000259_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_fn__992000259_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_fn__992000259_A]()) }

func A_arbace_a2g_decls_record_object_body_fn__992000261_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_fn__992000261_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_record_object_body_fn__992000261_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_fn__992000261_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_record_object_body_fn__992000261_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_fn__992000261_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_fn__992000261_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_fn__992000261_A_invoke, New: A_arbace_a2g_decls_record_object_body_fn__992000261_A_new, Get: A_arbace_a2g_decls_record_object_body_fn__992000261_A_get}

var A_arbace_a2g_decls_record_object_body_fn__992000261_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body$fn__992000261", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_record_object_body_A_class, Simple: "fn__992000261", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_fn__992000261_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_fn__992000261_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_fn__992000261_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_fn__992000261_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_fn__992000261_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_fn__992000261_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_fn__992000261_A]()) }

func A_arbace_a2g_decls_record_object_body_hash__992000250_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_hash__992000250_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_record_object_body_hash__992000250_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_hash__992000250_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_record_object_body_hash__992000250_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_hash__992000250_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_hash__992000250_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_hash__992000250_A_invoke, New: A_arbace_a2g_decls_record_object_body_hash__992000250_A_new, Get: A_arbace_a2g_decls_record_object_body_hash__992000250_A_get}

var A_arbace_a2g_decls_record_object_body_hash__992000250_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body$hash__992000250", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_record_object_body_A_class, Simple: "hash__992000250", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_hash__992000250_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_hash__992000250_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_hash__992000250_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_hash__992000250_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_hash__992000250_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_hash__992000250_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_hash__992000250_A]()) }

func A_arbace_a2g_decls_record_object_body_js__992000246_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_js__992000246_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_record_object_body_js__992000246_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_js__992000246_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_record_object_body_js__992000246_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_js__992000246_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_js__992000246_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_js__992000246_A_invoke, New: A_arbace_a2g_decls_record_object_body_js__992000246_A_new, Get: A_arbace_a2g_decls_record_object_body_js__992000246_A_get}

var A_arbace_a2g_decls_record_object_body_js__992000246_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body$js__992000246", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_record_object_body_A_class, Simple: "js__992000246", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_js__992000246_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_js__992000246_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_js__992000246_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_js__992000246_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_js__992000246_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_js__992000246_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_js__992000246_A]()) }

func A_arbace_a2g_decls_record_object_body_strof__992000253_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_record_object_body_strof__992000253_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_record_object_body_strof__992000253_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_record_object_body_strof__992000253_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_record_object_body_strof__992000253_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_record_object_body_strof__992000253_A_fn_class)}; return nil }

var A_arbace_a2g_decls_record_object_body_strof__992000253_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_record_object_body_strof__992000253_A_invoke, New: A_arbace_a2g_decls_record_object_body_strof__992000253_A_new, Get: A_arbace_a2g_decls_record_object_body_strof__992000253_A_get}

var A_arbace_a2g_decls_record_object_body_strof__992000253_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$record_object_body$strof__992000253", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_record_object_body_A_class, Simple: "strof__992000253", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_record_object_body_strof__992000253_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_record_object_body_strof__992000253_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_record_object_body_strof__992000253_A_InstanceOf; i.Init = A_arbace_a2g_decls_record_object_body_strof__992000253_A_Init; i.Table = A_arbace_a2g_decls_record_object_body_strof__992000253_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_record_object_body_strof__992000253_A_class, reflect.TypeFor[A_arbace_a2g_decls_record_object_body_strof__992000253_A]()) }

func A_arbace_a2g_decls_reflected_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_A_New()}; return nil }

func A_arbace_a2g_decls_reflected_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_A_invoke, New: A_arbace_a2g_decls_reflected_forms_A_new, Get: A_arbace_a2g_decls_reflected_forms_A_get}

var A_arbace_a2g_decls_reflected_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "reflected_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000508__992000512", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_reflected_forms_A_class, Simple: "iter__992000508__992000512", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000508__992000512$fn__992000513", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_A_class, Simple: "fn__992000513", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000508__992000512$fn__992000513$fn__992000514", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_A_class, Simple: "fn__992000514", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000508__992000512_fn__992000513_fn__992000514_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000518__992000522", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_reflected_forms_A_class, Simple: "iter__992000518__992000522", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000518__992000522$fn__992000523", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_A_class, Simple: "fn__992000523", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000518__992000522$fn__992000523$fn__992000524", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_A_class, Simple: "fn__992000524", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000518__992000522_fn__992000523_fn__992000524_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000528__992000532", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_reflected_forms_A_class, Simple: "iter__992000528__992000532", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000528__992000532$fn__992000533", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_A_class, Simple: "fn__992000533", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000528__992000532$fn__992000533$fn__992000534", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_A_class, Simple: "fn__992000534", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000528__992000532_fn__992000533_fn__992000534_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_reflected_forms_A_class, Simple: "iter__992000538__992000542", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_A_class, Simple: "fn__992000543", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_class, Simple: "fn__992000544", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_New()}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544$iter__992000548__992000552", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_A_class, Simple: "iter__992000548__992000552", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544$iter__992000548__992000552$fn__992000553", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_A_class, Simple: "fn__992000553", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544$iter__992000548__992000552$fn__992000553$fn__992000554", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_A_class, Simple: "fn__992000554", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_fn__992000544_iter__992000548__992000552_fn__992000553_fn__992000554_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_New()}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$iter__992000562__992000566", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_A_class, Simple: "iter__992000562__992000566", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$iter__992000562__992000566$fn__992000567", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_A_class, Simple: "fn__992000567", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A]()) }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_fn_class)}; return nil }

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_invoke, New: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_new, Get: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_get}

var A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$iter__992000562__992000566$fn__992000567$fn__992000568", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_A_class, Simple: "fn__992000568", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_InstanceOf; i.Init = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_Init; i.Table = A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A_class, reflect.TypeFor[A_arbace_a2g_decls_reflected_forms_iter__992000538__992000542_fn__992000543_iter__992000562__992000566_fn__992000567_fn__992000568_A]()) }

func A_arbace_a2g_decls_result_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_result_meta_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_result_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_result_meta_A_New()}; return nil }

func A_arbace_a2g_decls_result_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_result_meta_A_fn_class)}; return nil }

var A_arbace_a2g_decls_result_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_result_meta_A_invoke, New: A_arbace_a2g_decls_result_meta_A_new, Get: A_arbace_a2g_decls_result_meta_A_get}

var A_arbace_a2g_decls_result_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$result_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "result_meta", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_result_meta_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_result_meta_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_result_meta_A_InstanceOf; i.Init = A_arbace_a2g_decls_result_meta_A_Init; i.Table = A_arbace_a2g_decls_result_meta_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_result_meta_A_class, reflect.TypeFor[A_arbace_a2g_decls_result_meta_A]()) }

func A_arbace_a2g_decls_static_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_static_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_A_New()}; return nil }

func A_arbace_a2g_decls_static_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_A_invoke, New: A_arbace_a2g_decls_static_forms_A_new, Get: A_arbace_a2g_decls_static_forms_A_get}

var A_arbace_a2g_decls_static_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "static_forms", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_A_Init; i.Table = A_arbace_a2g_decls_static_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_A]()) }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_invoke, New: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_new, Get: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_get}

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms$iter__992000440__992000444", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_static_forms_A_class, Simple: "iter__992000440__992000444", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_Init; i.Table = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A]()) }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_invoke, New: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_new, Get: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_get}

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_A_class, Simple: "fn__992000445", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_Init; i.Table = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A]()) }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_invoke, New: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_new, Get: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_get}

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000446", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_class, Simple: "fn__992000446", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_Init; i.Table = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A]()) }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_invoke, New: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_new, Get: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_get}

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000446$fn__992000448", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_class, Simple: "fn__992000448", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_Init; i.Table = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000448_A]()) }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_invoke, New: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_new, Get: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_get}

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000446$fn__992000450", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_A_class, Simple: "fn__992000450", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_Init; i.Table = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000446_fn__992000450_A]()) }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_invoke, New: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_new, Get: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_get}

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000454", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_class, Simple: "fn__992000454", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_Init; i.Table = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000454_A]()) }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_New_O(args[0])}; return nil }

func A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_fn_class)}; return nil }

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_invoke, New: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_new, Get: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_get}

var A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000456", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_A_class, Simple: "fn__992000456", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_InstanceOf; i.Init = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_Init; i.Table = A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A_class, reflect.TypeFor[A_arbace_a2g_decls_static_forms_iter__992000440__992000444_fn__992000445_fn__992000456_A]()) }

func A_arbace_a2g_decls_stub_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_stub_body_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_stub_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_stub_body_A_New()}; return nil }

func A_arbace_a2g_decls_stub_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_stub_body_A_fn_class)}; return nil }

var A_arbace_a2g_decls_stub_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_stub_body_A_invoke, New: A_arbace_a2g_decls_stub_body_A_new, Get: A_arbace_a2g_decls_stub_body_A_get}

var A_arbace_a2g_decls_stub_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$stub_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "stub_body", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_stub_body_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_stub_body_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_stub_body_A_InstanceOf; i.Init = A_arbace_a2g_decls_stub_body_A_Init; i.Table = A_arbace_a2g_decls_stub_body_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_stub_body_A_class, reflect.TypeFor[A_arbace_a2g_decls_stub_body_A]()) }

func A_arbace_a2g_decls_super_iface_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_super_iface_type_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_super_iface_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_super_iface_type_A_New()}; return nil }

func A_arbace_a2g_decls_super_iface_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_super_iface_type_A_fn_class)}; return nil }

var A_arbace_a2g_decls_super_iface_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_super_iface_type_A_invoke, New: A_arbace_a2g_decls_super_iface_type_A_new, Get: A_arbace_a2g_decls_super_iface_type_A_get}

var A_arbace_a2g_decls_super_iface_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$super_iface_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "super_iface_type", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_super_iface_type_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_super_iface_type_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_super_iface_type_A_InstanceOf; i.Init = A_arbace_a2g_decls_super_iface_type_A_Init; i.Table = A_arbace_a2g_decls_super_iface_type_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_super_iface_type_A_class, reflect.TypeFor[A_arbace_a2g_decls_super_iface_type_A]()) }

func A_arbace_a2g_decls_super_struct_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_super_struct_type_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_super_struct_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_super_struct_type_A_New()}; return nil }

func A_arbace_a2g_decls_super_struct_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_super_struct_type_A_fn_class)}; return nil }

var A_arbace_a2g_decls_super_struct_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_super_struct_type_A_invoke, New: A_arbace_a2g_decls_super_struct_type_A_new, Get: A_arbace_a2g_decls_super_struct_type_A_get}

var A_arbace_a2g_decls_super_struct_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$super_struct_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "super_struct_type", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_super_struct_type_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_super_struct_type_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_super_struct_type_A_InstanceOf; i.Init = A_arbace_a2g_decls_super_struct_type_A_Init; i.Table = A_arbace_a2g_decls_super_struct_type_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_super_struct_type_A_class, reflect.TypeFor[A_arbace_a2g_decls_super_struct_type_A]()) }

func A_arbace_a2g_decls_tag_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_tag_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_tag_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_tag_A_New()}; return nil }

func A_arbace_a2g_decls_tag_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_tag_A_fn_class)}; return nil }

var A_arbace_a2g_decls_tag_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_tag_A_invoke, New: A_arbace_a2g_decls_tag_A_new, Get: A_arbace_a2g_decls_tag_A_get}

var A_arbace_a2g_decls_tag_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$tag", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "tag", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_tag_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_tag_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_tag_A_InstanceOf; i.Init = A_arbace_a2g_decls_tag_A_Init; i.Table = A_arbace_a2g_decls_tag_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_tag_A_class, reflect.TypeFor[A_arbace_a2g_decls_tag_A]()) }

func A_arbace_a2g_decls_terminating_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_terminating_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_terminating_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_terminating_QMARK__A_New()}; return nil }

func A_arbace_a2g_decls_terminating_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_terminating_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_decls_terminating_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_terminating_QMARK__A_invoke, New: A_arbace_a2g_decls_terminating_QMARK__A_new, Get: A_arbace_a2g_decls_terminating_QMARK__A_get}

var A_arbace_a2g_decls_terminating_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$terminating_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "terminating_QMARK_", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_terminating_QMARK__A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_terminating_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_decls_terminating_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_decls_terminating_QMARK__A_Init; i.Table = A_arbace_a2g_decls_terminating_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_decls_terminating_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_decls_terminating_QMARK__A]()) }

func A_arbace_a2g_decls_touches_statics_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_touches_statics_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_decls_touches_statics_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_touches_statics_QMARK__A_New()}; return nil }

func A_arbace_a2g_decls_touches_statics_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_touches_statics_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_decls_touches_statics_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_touches_statics_QMARK__A_invoke, New: A_arbace_a2g_decls_touches_statics_QMARK__A_new, Get: A_arbace_a2g_decls_touches_statics_QMARK__A_get}

var A_arbace_a2g_decls_touches_statics_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$touches_statics_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "touches_statics_QMARK_", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_touches_statics_QMARK__A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_touches_statics_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_decls_touches_statics_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_decls_touches_statics_QMARK__A_Init; i.Table = A_arbace_a2g_decls_touches_statics_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_decls_touches_statics_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_decls_touches_statics_QMARK__A]()) }

func A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_fn_class)}; return nil }

var A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_invoke, New: A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_new, Get: A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_get}

var A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$touches_statics_QMARK_$w__992000285", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_decls_touches_statics_QMARK__A_class, Simple: "w__992000285", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_InstanceOf; i.Init = A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_Init; i.Table = A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A_class, reflect.TypeFor[A_arbace_a2g_decls_touches_statics_QMARK__w__992000285_A]()) }

func A_arbace_a2g_decls_with_ret_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_decls_with_ret_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_decls_with_ret_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls_with_ret_A_New()}; return nil }

func A_arbace_a2g_decls_with_ret_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_decls_with_ret_A_fn_class)}; return nil }

var A_arbace_a2g_decls_with_ret_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_decls_with_ret_A_invoke, New: A_arbace_a2g_decls_with_ret_A_new, Get: A_arbace_a2g_decls_with_ret_A_get}

var A_arbace_a2g_decls_with_ret_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls$with_ret", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_decls_A_class, Simple: "with_ret", Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls_with_ret_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls_with_ret_A_class.Info(); i.IsInstance = A_arbace_a2g_decls_with_ret_A_InstanceOf; i.Init = A_arbace_a2g_decls_with_ret_A_Init; i.Table = A_arbace_a2g_decls_with_ret_A_members; jrt.RegisterGoType(A_arbace_a2g_decls_with_ret_A_class, reflect.TypeFor[A_arbace_a2g_decls_with_ret_A]()) }

func A_arbace_a2g_decls__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_decls__init_A_Load__O(); case 1: return A_arbace_a2g_decls__init_A_Unit0__O(); case 2: return A_arbace_a2g_decls__init_A_Unit1__O(); case 3: return A_arbace_a2g_decls__init_A_Unit10__O(); case 4: return A_arbace_a2g_decls__init_A_Unit11__O(); case 5: return A_arbace_a2g_decls__init_A_Unit12__O(); case 6: return A_arbace_a2g_decls__init_A_Unit13__O(); case 7: return A_arbace_a2g_decls__init_A_Unit14__O(); case 8: return A_arbace_a2g_decls__init_A_Unit15__O(); case 9: return A_arbace_a2g_decls__init_A_Unit16__O(); case 10: return A_arbace_a2g_decls__init_A_Unit17__O(); case 11: return A_arbace_a2g_decls__init_A_Unit18__O(); case 12: return A_arbace_a2g_decls__init_A_Unit19__O(); case 13: return A_arbace_a2g_decls__init_A_Unit2__O(); case 14: return A_arbace_a2g_decls__init_A_Unit20__O(); case 15: return A_arbace_a2g_decls__init_A_Unit21__O(); case 16: return A_arbace_a2g_decls__init_A_Unit22__O(); case 17: return A_arbace_a2g_decls__init_A_Unit23__O(); case 18: return A_arbace_a2g_decls__init_A_Unit24__O(); case 19: return A_arbace_a2g_decls__init_A_Unit25__O(); case 20: return A_arbace_a2g_decls__init_A_Unit26__O(); case 21: return A_arbace_a2g_decls__init_A_Unit27__O(); case 22: return A_arbace_a2g_decls__init_A_Unit28__O(); case 23: return A_arbace_a2g_decls__init_A_Unit29__O(); case 24: return A_arbace_a2g_decls__init_A_Unit3__O(); case 25: return A_arbace_a2g_decls__init_A_Unit30__O(); case 26: return A_arbace_a2g_decls__init_A_Unit31__O(); case 27: return A_arbace_a2g_decls__init_A_Unit32__O(); case 28: return A_arbace_a2g_decls__init_A_Unit33__O(); case 29: return A_arbace_a2g_decls__init_A_Unit34__O(); case 30: return A_arbace_a2g_decls__init_A_Unit35__O(); case 31: return A_arbace_a2g_decls__init_A_Unit36__O(); case 32: return A_arbace_a2g_decls__init_A_Unit37__O(); case 33: return A_arbace_a2g_decls__init_A_Unit38__O(); case 34: return A_arbace_a2g_decls__init_A_Unit39__O(); case 35: return A_arbace_a2g_decls__init_A_Unit4__O(); case 36: return A_arbace_a2g_decls__init_A_Unit40__O(); case 37: return A_arbace_a2g_decls__init_A_Unit41__O(); case 38: return A_arbace_a2g_decls__init_A_Unit42__O(); case 39: return A_arbace_a2g_decls__init_A_Unit43__O(); case 40: return A_arbace_a2g_decls__init_A_Unit44__O(); case 41: return A_arbace_a2g_decls__init_A_Unit45__O(); case 42: return A_arbace_a2g_decls__init_A_Unit46__O(); case 43: return A_arbace_a2g_decls__init_A_Unit47__O(); case 44: return A_arbace_a2g_decls__init_A_Unit5__O(); case 45: return A_arbace_a2g_decls__init_A_Unit6__O(); case 46: return A_arbace_a2g_decls__init_A_Unit7__O(); case 47: return A_arbace_a2g_decls__init_A_Unit8__O(); case 48: return A_arbace_a2g_decls__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_decls__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_decls__init_A_New()}; return nil }

var A_arbace_a2g_decls__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_decls__init_A_invoke, New: A_arbace_a2g_decls__init_A_new}

var A_arbace_a2g_decls__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.decls__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_decls.A_arbace_a2g_decls__init_A", Source: "decls.ae"})

func init() { i := A_arbace_a2g_decls__init_A_class.Info(); i.IsInstance = A_arbace_a2g_decls__init_A_InstanceOf; i.Init = A_arbace_a2g_decls__init_A_Init; i.Table = A_arbace_a2g_decls__init_A_members; jrt.RegisterGoType(A_arbace_a2g_decls__init_A_class, reflect.TypeFor[A_arbace_a2g_decls__init_A]()) }
