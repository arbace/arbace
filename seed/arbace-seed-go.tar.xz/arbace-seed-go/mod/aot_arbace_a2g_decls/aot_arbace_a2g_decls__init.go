//line aot_arbace_a2g_decls__init.ae:1
package aot_arbace_a2g_decls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_decls__init_A_Unit0__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_decls__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_decls__init_A_const_1) }
//line :1:1
func A_arbace_a2g_decls__init_A_Unit1__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_decls__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_decls__init_A_Unit2__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_Init(); tmp2 = A_arbace_a2g_decls_eval992000004_loading__1927001464__auto____992000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_decls__init_A_Unit3__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_decls__init_A_const_1)).Equals_O__Z(A_arbace_a2g_decls__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_decls_eval992000008_fn__992000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_decls_eval992000008_fn__992000009_A_Init(); tmp2 = A_arbace_a2g_decls_eval992000008_fn__992000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_decls__init_A_Load__O() any { A_arbace_a2g_decls__init_A_Init(); A_arbace_a2g_decls__init_A_Unit0__O(); A_arbace_a2g_decls__init_A_Unit1__O(); A_arbace_a2g_decls__init_A_Unit2__O(); A_arbace_a2g_decls__init_A_Unit3__O(); A_arbace_a2g_decls__init_A_Unit4__O(); A_arbace_a2g_decls__init_A_Unit5__O(); A_arbace_a2g_decls__init_A_Unit6__O(); A_arbace_a2g_decls__init_A_Unit7__O(); A_arbace_a2g_decls__init_A_Unit8__O(); A_arbace_a2g_decls__init_A_Unit9__O(); A_arbace_a2g_decls__init_A_Unit10__O(); A_arbace_a2g_decls__init_A_Unit11__O(); A_arbace_a2g_decls__init_A_Unit12__O(); A_arbace_a2g_decls__init_A_Unit13__O(); A_arbace_a2g_decls__init_A_Unit14__O(); A_arbace_a2g_decls__init_A_Unit15__O(); A_arbace_a2g_decls__init_A_Unit16__O(); A_arbace_a2g_decls__init_A_Unit17__O(); A_arbace_a2g_decls__init_A_Unit18__O(); A_arbace_a2g_decls__init_A_Unit19__O(); A_arbace_a2g_decls__init_A_Unit20__O(); A_arbace_a2g_decls__init_A_Unit21__O(); A_arbace_a2g_decls__init_A_Unit22__O(); A_arbace_a2g_decls__init_A_Unit23__O(); A_arbace_a2g_decls__init_A_Unit24__O(); A_arbace_a2g_decls__init_A_Unit25__O(); A_arbace_a2g_decls__init_A_Unit26__O(); A_arbace_a2g_decls__init_A_Unit27__O(); A_arbace_a2g_decls__init_A_Unit28__O(); A_arbace_a2g_decls__init_A_Unit29__O(); A_arbace_a2g_decls__init_A_Unit30__O(); A_arbace_a2g_decls__init_A_Unit31__O(); A_arbace_a2g_decls__init_A_Unit32__O(); A_arbace_a2g_decls__init_A_Unit33__O(); A_arbace_a2g_decls__init_A_Unit34__O(); A_arbace_a2g_decls__init_A_Unit35__O(); A_arbace_a2g_decls__init_A_Unit36__O(); A_arbace_a2g_decls__init_A_Unit37__O(); A_arbace_a2g_decls__init_A_Unit38__O(); A_arbace_a2g_decls__init_A_Unit39__O(); A_arbace_a2g_decls__init_A_Unit40__O(); A_arbace_a2g_decls__init_A_Unit41__O(); A_arbace_a2g_decls__init_A_Unit42__O(); A_arbace_a2g_decls__init_A_Unit43__O(); A_arbace_a2g_decls__init_A_Unit44__O(); A_arbace_a2g_decls__init_A_Unit45__O(); A_arbace_a2g_decls__init_A_Unit46__O(); A_arbace_a2g_decls__init_A_Unit47__O(); return nil }











func A_arbace_a2g_decls__init_A_Unit4__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_4; var tmp2 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp2 = lang.PersistentHashSet_EMPTY; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_a2g_decls__init_A_const_4; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_5)); return jrt.NN(A_arbace_a2g_decls__init_A_const_4).SetDynamic_Z__Var(true).Ref() }

func A_arbace_a2g_decls__init_A_Unit5__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_6; var tmp2 any = A_arbace_a2g_decls_tag_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_tag_A_Init(); tmp3 = A_arbace_a2g_decls_tag_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_7)); return A_arbace_a2g_decls__init_A_const_6.Ref() }

func A_arbace_a2g_decls__init_A_Unit6__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_8; var tmp2 any = A_arbace_a2g_decls_has_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_has_QMARK__A_Init(); tmp3 = A_arbace_a2g_decls_has_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_9)); return A_arbace_a2g_decls__init_A_const_8.Ref() }

func A_arbace_a2g_decls__init_A_Unit7__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_10; var tmp2 any = A_arbace_a2g_decls_gt_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_gt_A_Init(); tmp3 = A_arbace_a2g_decls_gt_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_11)); return A_arbace_a2g_decls__init_A_const_10.Ref() }

func A_arbace_a2g_decls__init_A_Unit8__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_12; var tmp2 any = A_arbace_a2g_decls_param_list_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_param_list_A_Init(); tmp3 = A_arbace_a2g_decls_param_list_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_13)); return A_arbace_a2g_decls__init_A_const_12.Ref() }





func A_arbace_a2g_decls__init_A_Unit9__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_14; var tmp2 any = A_arbace_a2g_decls_result_meta_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_result_meta_A_Init(); tmp3 = A_arbace_a2g_decls_result_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_15)); return A_arbace_a2g_decls__init_A_const_14.Ref() }

func A_arbace_a2g_decls__init_A_Unit10__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_16; var tmp2 any = A_arbace_a2g_decls_with_ret_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_with_ret_A_Init(); tmp3 = A_arbace_a2g_decls_with_ret_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_17)); return A_arbace_a2g_decls__init_A_const_16.Ref() }

func A_arbace_a2g_decls__init_A_Unit11__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_18; var tmp2 any = A_arbace_a2g_decls_new_fn_state_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_new_fn_state_A_Init(); tmp3 = A_arbace_a2g_decls_new_fn_state_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_19)); return A_arbace_a2g_decls__init_A_const_18.Ref() }






func A_arbace_a2g_decls__init_A_Unit12__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_20; var tmp2 any = A_arbace_a2g_decls_terminating_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_terminating_QMARK__A_Init(); tmp3 = A_arbace_a2g_decls_terminating_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_21)); return A_arbace_a2g_decls__init_A_const_20.Ref() }










func A_arbace_a2g_decls__init_A_Unit13__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_22; var tmp2 any = A_arbace_a2g_decls_ensure_terminated_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_ensure_terminated_A_Init(); tmp3 = A_arbace_a2g_decls_ensure_terminated_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_23)); return A_arbace_a2g_decls__init_A_const_22.Ref() }







func A_arbace_a2g_decls__init_A_Unit14__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(61, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_24; var tmp2 any = A_arbace_a2g_decls_stub_body_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_stub_body_A_Init(); tmp3 = A_arbace_a2g_decls_stub_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_25)); return A_arbace_a2g_decls__init_A_const_24.Ref() }



func A_arbace_a2g_decls__init_A_Unit15__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_26; var tmp2 any = A_arbace_a2g_decls_captured_fields_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_captured_fields_A_Init(); tmp3 = A_arbace_a2g_decls_captured_fields_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_27)); return A_arbace_a2g_decls__init_A_const_26.Ref() }









func A_arbace_a2g_decls__init_A_Unit16__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_28; var tmp2 any = A_arbace_a2g_decls_member_line_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_member_line_A_Init(); tmp3 = A_arbace_a2g_decls_member_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_29)); return A_arbace_a2g_decls__init_A_const_28.Ref() }




func A_arbace_a2g_decls__init_A_Unit17__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_30; var tmp2 any = A_arbace_a2g_decls_at_line_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_at_line_A_Init(); tmp3 = A_arbace_a2g_decls_at_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_31)); return A_arbace_a2g_decls__init_A_const_30.Ref() }






func A_arbace_a2g_decls__init_A_Unit18__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_32; var tmp2 any = A_arbace_a2g_decls_method_code_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_method_code_forms_A_Init(); tmp3 = A_arbace_a2g_decls_method_code_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_33)); return A_arbace_a2g_decls__init_A_const_32.Ref() }

























func A_arbace_a2g_decls__init_A_Unit19__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_34; var tmp2 any = A_arbace_a2g_decls_class_fields_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_class_fields_A_Init(); tmp3 = A_arbace_a2g_decls_class_fields_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_35)); return A_arbace_a2g_decls__init_A_const_34.Ref() }




func A_arbace_a2g_decls__init_A_Unit20__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_36; var tmp2 any = A_arbace_a2g_decls_class_methods_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_class_methods_A_Init(); tmp3 = A_arbace_a2g_decls_class_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_37)); return A_arbace_a2g_decls__init_A_const_36.Ref() }









func A_arbace_a2g_decls__init_A_Unit21__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_38; var tmp2 any = A_arbace_a2g_decls_body_of_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_body_of_A_Init(); tmp3 = A_arbace_a2g_decls_body_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_39)); return A_arbace_a2g_decls__init_A_const_38.Ref() }

func A_arbace_a2g_decls__init_A_Unit22__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_40; var tmp2 any = A_arbace_a2g_decls_reached_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_reached_QMARK__A_Init(); tmp3 = A_arbace_a2g_decls_reached_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_41)); return A_arbace_a2g_decls__init_A_const_40.Ref() }




func A_arbace_a2g_decls__init_A_Unit23__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_42; var tmp2 any = A_arbace_a2g_decls_super_struct_type_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_super_struct_type_A_Init(); tmp3 = A_arbace_a2g_decls_super_struct_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_43)); return A_arbace_a2g_decls__init_A_const_42.Ref() }







func A_arbace_a2g_decls__init_A_Unit24__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(143, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_44; var tmp2 any = A_arbace_a2g_decls_super_iface_type_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_super_iface_type_A_Init(); tmp3 = A_arbace_a2g_decls_super_iface_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_45)); return A_arbace_a2g_decls__init_A_const_44.Ref() }





func A_arbace_a2g_decls__init_A_Unit25__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_46; var tmp2 any = A_arbace_a2g_decls_field_go_type_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_field_go_type_A_Init(); tmp3 = A_arbace_a2g_decls_field_go_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_47)); return A_arbace_a2g_decls__init_A_const_46.Ref() }












func A_arbace_a2g_decls__init_A_Unit26__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_48; var tmp2 any = A_arbace_a2g_decls_extra_fields_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_extra_fields_A_Init(); tmp3 = A_arbace_a2g_decls_extra_fields_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_49)); return A_arbace_a2g_decls__init_A_const_48.Ref() }










func A_arbace_a2g_decls__init_A_Unit27__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_50; var tmp2 any = A_arbace_a2g_decls_iface_method_elem_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_iface_method_elem_A_Init(); tmp3 = A_arbace_a2g_decls_iface_method_elem_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_51)); return A_arbace_a2g_decls__init_A_const_50.Ref() }




func A_arbace_a2g_decls__init_A_Unit28__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(178, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_52; var tmp2 any = A_arbace_a2g_decls_interface_closure_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_interface_closure_A_Init(); tmp3 = A_arbace_a2g_decls_interface_closure_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_53)); return A_arbace_a2g_decls__init_A_const_52.Ref() }





func A_arbace_a2g_decls__init_A_Unit29__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(184, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_54; var tmp2 any = A_arbace_a2g_decls_hw_markers_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_hw_markers_A_Init(); tmp3 = A_arbace_a2g_decls_hw_markers_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_55)); return A_arbace_a2g_decls__init_A_const_54.Ref() }





func A_arbace_a2g_decls__init_A_Unit30__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_56; var tmp2 any = A_arbace_a2g_decls_markers_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_markers_A_Init(); tmp3 = A_arbace_a2g_decls_markers_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_57)); return A_arbace_a2g_decls__init_A_const_56.Ref() }












func A_arbace_a2g_decls__init_A_Unit31__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(203, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_58; var tmp2 any = A_arbace_a2g_decls_ctor_desc_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_ctor_desc_A_Init(); tmp3 = A_arbace_a2g_decls_ctor_desc_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_59)); return A_arbace_a2g_decls__init_A_const_58.Ref() }

func A_arbace_a2g_decls__init_A_Unit32__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(205, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_60; var tmp2 any = A_arbace_a2g_decls_ctor_call_translator_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_ctor_call_translator_A_Init(); tmp3 = A_arbace_a2g_decls_ctor_call_translator_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_61)); return A_arbace_a2g_decls__init_A_const_60.Ref() }


























































func A_arbace_a2g_decls__init_A_Unit33__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(264, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_62; var tmp2 any = A_arbace_a2g_decls_ctor_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_ctor_forms_A_Init(); tmp3 = A_arbace_a2g_decls_ctor_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_63)); return A_arbace_a2g_decls__init_A_const_62.Ref() }


















































































func A_arbace_a2g_decls__init_A_Unit34__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(347, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_64; var tmp2 any = A_arbace_a2g_decls_record_object_body_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_record_object_body_A_Init(); tmp3 = A_arbace_a2g_decls_record_object_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_65)); return A_arbace_a2g_decls__init_A_const_64.Ref() }
























































func A_arbace_a2g_decls__init_A_Unit35__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(404, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_66; var tmp2 any = A_arbace_a2g_decls_derived_body_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_derived_body_A_Init(); tmp3 = A_arbace_a2g_decls_derived_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_67)); return A_arbace_a2g_decls__init_A_const_66.Ref() }













































func A_arbace_a2g_decls__init_A_Unit36__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(450, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_68; var tmp2 any = A_arbace_a2g_decls_touches_statics_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_touches_statics_QMARK__A_Init(); tmp3 = A_arbace_a2g_decls_touches_statics_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_69)); return A_arbace_a2g_decls__init_A_const_68.Ref() }


















func A_arbace_a2g_decls__init_A_Unit37__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(469, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_70; var tmp2 any = A_arbace_a2g_decls_needs_entry_guard_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_needs_entry_guard_QMARK__A_Init(); tmp3 = A_arbace_a2g_decls_needs_entry_guard_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_71)); return A_arbace_a2g_decls__init_A_const_70.Ref() }










func A_arbace_a2g_decls__init_A_Unit38__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(480, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_72; var tmp2 any = A_arbace_a2g_decls_method_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_method_forms_A_Init(); tmp3 = A_arbace_a2g_decls_method_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_73)); return A_arbace_a2g_decls__init_A_const_72.Ref() }



































































func A_arbace_a2g_decls__init_A_Unit39__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(548, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_74; var tmp2 any = A_arbace_a2g_decls_forwarder_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_forwarder_A_Init(); tmp3 = A_arbace_a2g_decls_forwarder_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_75)); return A_arbace_a2g_decls__init_A_const_74.Ref() }














func A_arbace_a2g_decls__init_A_Unit40__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(563, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_76; var tmp2 any = A_arbace_a2g_decls_object_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_object_forms_A_Init(); tmp3 = A_arbace_a2g_decls_object_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_77)); return A_arbace_a2g_decls__init_A_const_76.Ref() }





























func A_arbace_a2g_decls__init_A_Unit41__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(593, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_78; var tmp2 any = A_arbace_a2g_decls_dispatch_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_dispatch_forms_A_Init(); tmp3 = A_arbace_a2g_decls_dispatch_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_79)); return A_arbace_a2g_decls__init_A_const_78.Ref() }
























func A_arbace_a2g_decls__init_A_Unit42__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(618, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_80; var tmp2 any = A_arbace_a2g_decls_static_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_static_forms_A_Init(); tmp3 = A_arbace_a2g_decls_static_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_80; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_81)); return A_arbace_a2g_decls__init_A_const_80.Ref() }




















func A_arbace_a2g_decls__init_A_Unit43__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(639, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_82; var tmp2 any = A_arbace_a2g_decls_init_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_init_forms_A_Init(); tmp3 = A_arbace_a2g_decls_init_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_82; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_83)); return A_arbace_a2g_decls__init_A_const_82.Ref() }




























func A_arbace_a2g_decls__init_A_Unit44__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(668, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_84; var tmp2 any = A_arbace_a2g_decls_clj_const_fields_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_clj_const_fields_A_Init(); tmp3 = A_arbace_a2g_decls_clj_const_fields_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_84; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_85)); return A_arbace_a2g_decls__init_A_const_84.Ref() }






func A_arbace_a2g_decls__init_A_Unit45__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(675, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_86; var tmp2 any = A_arbace_a2g_decls_instance_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_instance_forms_A_Init(); tmp3 = A_arbace_a2g_decls_instance_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_86; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_87)); return A_arbace_a2g_decls__init_A_const_86.Ref() }








































func A_arbace_a2g_decls__init_A_Unit46__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(716, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_88; var tmp2 any = A_arbace_a2g_decls_reflected_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_reflected_forms_A_Init(); tmp3 = A_arbace_a2g_decls_reflected_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_88; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_89)); return A_arbace_a2g_decls__init_A_const_88.Ref() }






























func A_arbace_a2g_decls__init_A_Unit47__O() any { A_arbace_a2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V(747, 1); var tmp1 *lang.Var = A_arbace_a2g_decls__init_A_const_90; var tmp2 any = A_arbace_a2g_decls_class_forms_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_decls_class_forms_A_Init(); tmp3 = A_arbace_a2g_decls_class_forms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_decls__init_A_const_90; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_decls__init_A_const_91)); return A_arbace_a2g_decls__init_A_const_90.Ref() }



type A_arbace_a2g_decls__init_A struct{ jrt.Object }

var A_arbace_a2g_decls__init_A_const_0 *lang.Var

var A_arbace_a2g_decls__init_A_const_1 any

var A_arbace_a2g_decls__init_A_const_2 any

var A_arbace_a2g_decls__init_A_const_3 any

var A_arbace_a2g_decls__init_A_const_4 *lang.Var

var A_arbace_a2g_decls__init_A_const_5 any

var A_arbace_a2g_decls__init_A_const_6 *lang.Var

var A_arbace_a2g_decls__init_A_const_7 any

var A_arbace_a2g_decls__init_A_const_8 *lang.Var

var A_arbace_a2g_decls__init_A_const_9 any

var A_arbace_a2g_decls__init_A_const_10 *lang.Var

var A_arbace_a2g_decls__init_A_const_11 any

var A_arbace_a2g_decls__init_A_const_12 *lang.Var

var A_arbace_a2g_decls__init_A_const_13 any

var A_arbace_a2g_decls__init_A_const_14 *lang.Var

var A_arbace_a2g_decls__init_A_const_15 any

var A_arbace_a2g_decls__init_A_const_16 *lang.Var

var A_arbace_a2g_decls__init_A_const_17 any

var A_arbace_a2g_decls__init_A_const_18 *lang.Var

var A_arbace_a2g_decls__init_A_const_19 any

var A_arbace_a2g_decls__init_A_const_20 *lang.Var

var A_arbace_a2g_decls__init_A_const_21 any

var A_arbace_a2g_decls__init_A_const_22 *lang.Var

var A_arbace_a2g_decls__init_A_const_23 any

var A_arbace_a2g_decls__init_A_const_24 *lang.Var

var A_arbace_a2g_decls__init_A_const_25 any

var A_arbace_a2g_decls__init_A_const_26 *lang.Var

var A_arbace_a2g_decls__init_A_const_27 any

var A_arbace_a2g_decls__init_A_const_28 *lang.Var

var A_arbace_a2g_decls__init_A_const_29 any

var A_arbace_a2g_decls__init_A_const_30 *lang.Var

var A_arbace_a2g_decls__init_A_const_31 any

var A_arbace_a2g_decls__init_A_const_32 *lang.Var

var A_arbace_a2g_decls__init_A_const_33 any

var A_arbace_a2g_decls__init_A_const_34 *lang.Var

var A_arbace_a2g_decls__init_A_const_35 any

var A_arbace_a2g_decls__init_A_const_36 *lang.Var

var A_arbace_a2g_decls__init_A_const_37 any

var A_arbace_a2g_decls__init_A_const_38 *lang.Var

var A_arbace_a2g_decls__init_A_const_39 any

var A_arbace_a2g_decls__init_A_const_40 *lang.Var

var A_arbace_a2g_decls__init_A_const_41 any

var A_arbace_a2g_decls__init_A_const_42 *lang.Var

var A_arbace_a2g_decls__init_A_const_43 any

var A_arbace_a2g_decls__init_A_const_44 *lang.Var

var A_arbace_a2g_decls__init_A_const_45 any

var A_arbace_a2g_decls__init_A_const_46 *lang.Var

var A_arbace_a2g_decls__init_A_const_47 any

var A_arbace_a2g_decls__init_A_const_48 *lang.Var

var A_arbace_a2g_decls__init_A_const_49 any

var A_arbace_a2g_decls__init_A_const_50 *lang.Var

var A_arbace_a2g_decls__init_A_const_51 any

var A_arbace_a2g_decls__init_A_const_52 *lang.Var

var A_arbace_a2g_decls__init_A_const_53 any

var A_arbace_a2g_decls__init_A_const_54 *lang.Var

var A_arbace_a2g_decls__init_A_const_55 any

var A_arbace_a2g_decls__init_A_const_56 *lang.Var

var A_arbace_a2g_decls__init_A_const_57 any

var A_arbace_a2g_decls__init_A_const_58 *lang.Var

var A_arbace_a2g_decls__init_A_const_59 any

var A_arbace_a2g_decls__init_A_const_60 *lang.Var

var A_arbace_a2g_decls__init_A_const_61 any

var A_arbace_a2g_decls__init_A_const_62 *lang.Var

var A_arbace_a2g_decls__init_A_const_63 any

var A_arbace_a2g_decls__init_A_const_64 *lang.Var

var A_arbace_a2g_decls__init_A_const_65 any

var A_arbace_a2g_decls__init_A_const_66 *lang.Var

var A_arbace_a2g_decls__init_A_const_67 any

var A_arbace_a2g_decls__init_A_const_68 *lang.Var

var A_arbace_a2g_decls__init_A_const_69 any

var A_arbace_a2g_decls__init_A_const_70 *lang.Var

var A_arbace_a2g_decls__init_A_const_71 any

var A_arbace_a2g_decls__init_A_const_72 *lang.Var

var A_arbace_a2g_decls__init_A_const_73 any

var A_arbace_a2g_decls__init_A_const_74 *lang.Var

var A_arbace_a2g_decls__init_A_const_75 any

var A_arbace_a2g_decls__init_A_const_76 *lang.Var

var A_arbace_a2g_decls__init_A_const_77 any

var A_arbace_a2g_decls__init_A_const_78 *lang.Var

var A_arbace_a2g_decls__init_A_const_79 any

var A_arbace_a2g_decls__init_A_const_80 *lang.Var

var A_arbace_a2g_decls__init_A_const_81 any

var A_arbace_a2g_decls__init_A_const_82 *lang.Var

var A_arbace_a2g_decls__init_A_const_83 any

var A_arbace_a2g_decls__init_A_const_84 *lang.Var

var A_arbace_a2g_decls__init_A_const_85 any

var A_arbace_a2g_decls__init_A_const_86 *lang.Var

var A_arbace_a2g_decls__init_A_const_87 any

var A_arbace_a2g_decls__init_A_const_88 *lang.Var

var A_arbace_a2g_decls__init_A_const_89 any

var A_arbace_a2g_decls__init_A_const_90 *lang.Var

var A_arbace_a2g_decls__init_A_const_91 any

var A_arbace_a2g_decls__init_A_init jrt.ClassInit

func A_arbace_a2g_decls__init_A_Init() { if !A_arbace_a2g_decls__init_A_init.Done() { A_arbace_a2g_decls__init_A_init.Run(A_arbace_a2g_decls__init_A_clinit) } }

func A_arbace_a2g_decls__init_A_clinit() { A_arbace_a2g_decls__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_650); A_arbace_a2g_decls__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27))); A_arbace_a2g_decls__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_a2g_decls__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_decls__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_25, Lit_131); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_651).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_decls__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_655)); A_arbace_a2g_decls__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_25, Lit_30); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_decls__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_25, Lit_31); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_decls__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_569).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_25, Lit_35); A_arbace_a2g_decls__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_336).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_25, Lit_225); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_decls__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_658).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_659).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_660, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_25, Lit_36); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_decls__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_661).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_25, Lit_150); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_decls__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_342).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_661).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_25, Lit_103); A_arbace_a2g_decls__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_663).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_664).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_25, Lit_62); A_arbace_a2g_decls__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_569).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_665, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_25, Lit_121); A_arbace_a2g_decls__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_666).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_667).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_668, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_25, Lit_200); A_arbace_a2g_decls__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(61).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_25, Lit_106); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_decls__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_669).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_670, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_25, Lit_93); A_arbace_a2g_decls__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_671, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_25, Lit_218); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_a2g_decls__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_666).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_672, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_25, Lit_286); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_a2g_decls__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_673).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_674).Ref(), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_675, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_25, Lit_303); A_arbace_a2g_decls__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(113).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_25, Lit_311); A_arbace_a2g_decls__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_676, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(118).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_25, Lit_195); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_a2g_decls__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_25, Lit_196); A_arbace_a2g_decls__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_25, Lit_355); A_arbace_a2g_decls__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_678, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(135).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_25, Lit_357); A_arbace_a2g_decls__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(143).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_25, Lit_327); A_arbace_a2g_decls__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_569).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_679, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(149).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_25, Lit_356); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_a2g_decls__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_680, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(162).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_25, Lit_349); A_arbace_a2g_decls__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_25, Lit_166); A_arbace_a2g_decls__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_681, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(178).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_25, Lit_164); A_arbace_a2g_decls__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_682, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(184).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_25, Lit_359); A_arbace_a2g_decls__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_683, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(190).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_25, Lit_170); A_arbace_a2g_decls__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(203).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_25, Lit_211); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_a2g_decls__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_343).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_684, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(205).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_25, Lit_360); A_arbace_a2g_decls__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_685, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(264).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_25, Lit_257); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_a2g_decls__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_686).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_687, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(347).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_25, Lit_291); A_arbace_a2g_decls__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_686).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_688, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(404).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_25, Lit_282); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_a2g_decls__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_673).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_689).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_690, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(450).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_25, Lit_293); A_arbace_a2g_decls__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_673).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_691, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(469).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_25, Lit_361); A_arbace_a2g_decls__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_677).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_692, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(480).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_25, Lit_310); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_656).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_a2g_decls__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_693).Ref()), lang.Symbol_Intern_String_String__Symbol(nil, Lit_694).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_695, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(548).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_25, Lit_363); A_arbace_a2g_decls__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_696, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(563).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_25, Lit_362); A_arbace_a2g_decls__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_697, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(593).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_80 = lang.RT_Var_String_String__Var(Lit_25, Lit_350); A_arbace_a2g_decls__init_A_const_81 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(618).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_82 = lang.RT_Var_String_String__Var(Lit_25, Lit_352); A_arbace_a2g_decls__init_A_const_83 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_698, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(639).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_84 = lang.RT_Var_String_String__Var(Lit_25, Lit_351); A_arbace_a2g_decls__init_A_const_85 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(668).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_86 = lang.RT_Var_String_String__Var(Lit_25, Lit_346); A_arbace_a2g_decls__init_A_const_87 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_699, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(675).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_88 = lang.RT_Var_String_String__Var(Lit_25, Lit_700); A_arbace_a2g_decls__init_A_const_89 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_701, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(716).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)); A_arbace_a2g_decls__init_A_const_90 = lang.RT_Var_String_String__Var(Lit_25, Lit_702); A_arbace_a2g_decls__init_A_const_91 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_657).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_662).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_703, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), jrt.Integer_ValueOf_I__Integer(747).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_652).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_653).Ref(), Lit_654)) }

func A_arbace_a2g_decls__init_A_New() *A_arbace_a2g_decls__init_A { A_arbace_a2g_decls__init_A_Init(); t := &A_arbace_a2g_decls__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_decls__init_A) Ctor() {}

func (t *A_arbace_a2g_decls__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_decls__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_decls__init_A_class }

func (t *A_arbace_a2g_decls__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_decls__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_decls__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_decls__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_decls__init_A); return ok }

func A_arbace_a2g_decls__init_A_Cast(x any) *A_arbace_a2g_decls__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_decls__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_decls__init_A_class)) }; return v }
