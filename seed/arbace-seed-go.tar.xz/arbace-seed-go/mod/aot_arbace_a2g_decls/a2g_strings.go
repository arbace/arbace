//line a2g_strings.ae:1
package aot_arbace_a2g_decls

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_11 *jrt.String = jrt.Intern("a")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_13 *jrt.String = jrt.Intern("m")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_15 *jrt.String = jrt.Intern("nm")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_17 *jrt.String = jrt.Intern("jrt")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.code")

var Lit_19 *jrt.String = jrt.Intern("c")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_21 *jrt.String = jrt.Intern("Opcodes")

var Lit_22 *jrt.String = jrt.Intern("commute")

var Lit_23 *jrt.String = jrt.Intern("deref")

var Lit_24 *jrt.String = jrt.Intern("conj")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.decls")

var Lit_26 *jrt.String = jrt.Intern("doc")

var Lit_27 *jrt.String = jrt.Intern("a2g's declarations (A2G-SPEC §4.5, §5, §6, §7.11-§7.13): what a translated class becomes in\n  Go forms: its struct or interface, class interface C_I and accessor Self_C (non-leaf\n  classes), markers, method implementations, dispatch methods and forwarders, constructors,\n  statics and lazy class initialization, the Object protocol, instanceof and cast, and its\n  registration with member tables (a2g_classes).")

var Lit_28 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_29 *jrt.String = jrt.Intern("with-meta")

var Lit_30 *jrt.String = jrt.Intern("tag")

var Lit_31 *jrt.String = jrt.Intern("has?")

var Lit_32 *jrt.String = jrt.Intern("go-type")

var Lit_33 *jrt.String = jrt.Intern("vec")

var Lit_34 *jrt.String = jrt.Intern("map")

var Lit_35 *jrt.String = jrt.Intern("gt")

var Lit_36 *jrt.String = jrt.Intern("result-meta")

var Lit_37 *jrt.String = jrt.Intern("vary-meta")

var Lit_38 *jrt.String = jrt.Intern("assoc")

var Lit_39 *jrt.String = jrt.Intern("next")

var Lit_40 *jrt.String = jrt.Intern("to-array")

var Lit_41 *jrt.String = jrt.Intern("seq")

var Lit_42 *jrt.String = jrt.Intern("first")

var Lit_43 *jrt.String = jrt.Intern("merge")

var Lit_44 *jrt.String = jrt.Intern("pkg")

var Lit_45 *jrt.String = jrt.Intern("class")

var Lit_46 *jrt.String = jrt.Intern("fn-id")

var Lit_47 *jrt.String = jrt.Intern("gensym")

var Lit_48 *jrt.String = jrt.Intern("targets")

var Lit_49 *jrt.String = jrt.Intern("try-frame")

var Lit_50 *jrt.String = jrt.Intern("captured")

var Lit_51 *jrt.String = jrt.Intern("names")

var Lit_52 *jrt.String = jrt.Intern("atom")

var Lit_53 *jrt.String = jrt.Intern("taken")

var Lit_54 *jrt.String = jrt.Intern("used")

var Lit_55 *jrt.String = jrt.Intern("counter")

var Lit_56 *jrt.String = jrt.Intern("label-used")

var Lit_57 *jrt.String = jrt.Intern("into")

var Lit_58 *jrt.String = jrt.Intern("reserved-locals")

var Lit_59 *jrt.String = jrt.Intern("seq?")

var Lit_60 *jrt.String = jrt.Intern("panic")

var Lit_61 *jrt.String = jrt.Intern("let")

var Lit_62 *jrt.String = jrt.Intern("terminating?")

var Lit_63 *jrt.String = jrt.Intern("do")

var Lit_64 *jrt.String = jrt.Intern("return")

var Lit_65 *jrt.String = jrt.Intern("last")

var Lit_66 *jrt.String = jrt.Intern("if")

var Lit_67 *jrt.String = jrt.Intern("not")

var Lit_68 *jrt.String = jrt.Intern("concat")

var Lit_69 *jrt.String = jrt.Intern("list")

var Lit_70 *jrt.String = jrt.Intern("jrt-sym")

var Lit_71 *jrt.String = jrt.Intern("replace")

var Lit_72 *jrt.String = jrt.Intern("decl")

var Lit_73 *jrt.String = jrt.Intern("anon")

var Lit_74 *jrt.String = jrt.Intern("local")

var Lit_75 *jrt.String = jrt.Intern("nesting")

var Lit_76 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_77 *jrt.String = jrt.Intern("chunk-first")

var Lit_78 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_79 *jrt.String = jrt.Intern("chunk-append")

var Lit_80 *jrt.String = jrt.Intern("id")

var Lit_81 *jrt.String = jrt.Intern("symbol")

var Lit_82 *jrt.String = jrt.Intern("field-name")

var Lit_83 *jrt.String = jrt.Intern("sym")

var Lit_84 *jrt.String = jrt.Intern("chunk-cons")

var Lit_85 *jrt.String = jrt.Intern("cons")

var Lit_86 *jrt.String = jrt.Intern("chunk")

var Lit_87 *jrt.String = jrt.Intern("chunk-rest")

var Lit_88 *jrt.String = jrt.Intern("rest")

var Lit_89 *jrt.String = jrt.Intern("captures")

var Lit_90 *jrt.String = jrt.Intern("state")

var Lit_91 *jrt.String = jrt.Intern("line")

var Lit_92 *jrt.String = jrt.Intern("member")

var Lit_93 *jrt.String = jrt.Intern("member-line")

var Lit_94 *jrt.String = jrt.Intern("a2g")

var Lit_95 *jrt.String = jrt.Intern("this")

var Lit_96 *jrt.String = jrt.Intern("static")

var Lit_97 *jrt.String = jrt.Intern("ret")

var Lit_98 *jrt.String = jrt.Intern("*f*")

var Lit_99 *jrt.String = jrt.Intern("with-block")

var Lit_100 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_101 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_102 *jrt.String = jrt.Intern("hash-map")

var Lit_103 *jrt.String = jrt.Intern("new-fn-state")

var Lit_104 *jrt.String = jrt.Intern("*line*")

var Lit_105 *jrt.String = jrt.Intern("method-ret")

var Lit_106 *jrt.String = jrt.Intern("captured-fields")

var Lit_107 *jrt.String = jrt.Intern("method-name")

var Lit_108 *jrt.String = jrt.Intern("name")

var Lit_109 *jrt.String = jrt.Intern("sync")

var Lit_110 *jrt.String = jrt.Intern("flags")

var Lit_111 *jrt.String = jrt.Intern("method-fn")

var Lit_112 *jrt.String = jrt.Intern("binding-sym")

var Lit_113 *jrt.String = jrt.Intern("params")

var Lit_114 *jrt.String = jrt.Intern("stmt!")

var Lit_115 *jrt.String = jrt.Intern("ret!")

var Lit_116 *jrt.String = jrt.Intern("csym")

var Lit_117 *jrt.String = jrt.Intern("emit!")

var Lit_118 *jrt.String = jrt.Intern("jsym")

var Lit_119 *jrt.String = jrt.Intern("defer")

var Lit_120 *jrt.String = jrt.Intern("body")

var Lit_121 *jrt.String = jrt.Intern("ensure-terminated")

var Lit_122 *jrt.String = jrt.Intern("not=")

var Lit_123 *jrt.String = jrt.Intern("desc-in-world?")

var Lit_124 *jrt.String = jrt.Intern("desc")

var Lit_125 *jrt.String = jrt.Intern("fields")

var Lit_126 *jrt.String = jrt.Intern("mdesc-in-world?")

var Lit_127 *jrt.String = jrt.Intern("ctor-real-desc")

var Lit_128 *jrt.String = jrt.Intern("methods")

var Lit_129 *jrt.String = jrt.Intern("bodies")

var Lit_130 *jrt.String = jrt.Intern("contains?")

var Lit_131 *jrt.String = jrt.Intern("*reached*")

var Lit_132 *jrt.String = jrt.Intern("super")

var Lit_133 *jrt.String = jrt.Intern("class-sym")

var Lit_134 *jrt.String = jrt.Intern("volatile-field?")

var Lit_135 *jrt.String = jrt.Intern("atomic")

var Lit_136 *jrt.String = jrt.Intern("Int32")

var Lit_137 *jrt.String = jrt.Intern("Uint64")

var Lit_138 *jrt.String = jrt.Intern("Uint32")

var Lit_139 *jrt.String = jrt.Intern("pointer-desc?")

var Lit_140 *jrt.String = jrt.Intern("Int64")

var Lit_141 *jrt.String = jrt.Intern("Bool")

var Lit_142 *jrt.String = jrt.Intern("Pointer")

var Lit_143 *jrt.String = jrt.Intern("second")

var Lit_144 *jrt.String = jrt.Intern("outer-instance?")

var Lit_145 *jrt.String = jrt.Intern("in-world?")

var Lit_146 *jrt.String = jrt.Intern("type")

var Lit_147 *jrt.String = jrt.Intern("outer")

var Lit_148 *jrt.String = jrt.Intern("this0-name")

var Lit_149 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_150 *jrt.String = jrt.Intern("with-ret")

var Lit_151 *jrt.String = jrt.Intern("method-base")

var Lit_152 *jrt.String = jrt.Intern("map-indexed")

var Lit_153 *jrt.String = jrt.Intern("filter")

var Lit_154 *jrt.String = jrt.Intern("interface?")

var Lit_155 *jrt.String = jrt.Intern("all-supertypes")

var Lit_156 *jrt.String = jrt.Intern("go-name")

var Lit_157 *jrt.String = jrt.Intern("set")

var Lit_158 *jrt.String = jrt.Intern("starts-with?")

var Lit_159 *jrt.String = jrt.Intern("subs")

var Lit_160 *jrt.String = jrt.Intern("struct-methods")

var Lit_161 *jrt.String = jrt.Intern("*w*")

var Lit_162 *jrt.String = jrt.Intern("translated?")

var Lit_163 *jrt.String = jrt.Intern("else")

var Lit_164 *jrt.String = jrt.Intern("hw-markers")

var Lit_165 *jrt.String = jrt.Intern("remove")

var Lit_166 *jrt.String = jrt.Intern("interface-closure")

var Lit_167 *jrt.String = jrt.Intern("leaf?")

var Lit_168 *jrt.String = jrt.Intern("kind")

var Lit_169 *jrt.String = jrt.Intern("some")

var Lit_170 *jrt.String = jrt.Intern("ctor-desc")

var Lit_171 *jrt.String = jrt.Intern("ctor-base")

var Lit_172 *jrt.String = jrt.Intern("operands")

var Lit_173 *jrt.String = jrt.Intern("cap-params")

var Lit_174 *jrt.String = jrt.Intern("ctor")

var Lit_175 *jrt.String = jrt.Intern("enum-args")

var Lit_176 *jrt.String = jrt.Intern("anon-args")

var Lit_177 *jrt.String = jrt.Intern("x")

var Lit_178 *jrt.String = jrt.Intern("local-val")

var Lit_179 *jrt.String = jrt.Intern("op")

var Lit_180 *jrt.String = jrt.Intern("b")

var Lit_181 *jrt.String = jrt.Intern("method-desc-classes")

var Lit_182 *jrt.String = jrt.Intern("missing-expr")

var Lit_183 *jrt.String = jrt.Intern("super-outer")

var Lit_184 *jrt.String = jrt.Intern("enum")

var Lit_185 *jrt.String = jrt.Intern("enum-body")

var Lit_186 *jrt.String = jrt.Intern("enum-params")

var Lit_187 *jrt.String = jrt.Intern("outer-param")

var Lit_188 *jrt.String = jrt.Intern("super-outer-param")

var Lit_189 *jrt.String = jrt.Intern("args")

var Lit_190 *jrt.String = jrt.Intern("apply")

var Lit_191 *jrt.String = jrt.Intern("super-outer-is-outer")

var Lit_192 *jrt.String = jrt.Intern("super-outer-path")

var Lit_193 *jrt.String = jrt.Intern("reduce")

var Lit_194 *jrt.String = jrt.Intern("use-sym!")

var Lit_195 *jrt.String = jrt.Intern("body-of")

var Lit_196 *jrt.String = jrt.Intern("reached?")

var Lit_197 *jrt.String = jrt.Intern("fresh-raw")

var Lit_198 *jrt.String = jrt.Intern("empty?")

var Lit_199 *jrt.String = jrt.Intern("zipmap")

var Lit_200 *jrt.String = jrt.Intern("stub-body")

var Lit_201 *jrt.String = jrt.Intern("derived")

var Lit_202 *jrt.String = jrt.Intern("calls-super")

var Lit_203 *jrt.String = jrt.Intern("record")

var Lit_204 *jrt.String = jrt.Intern("compact")

var Lit_205 *jrt.String = jrt.Intern("record-canonical")

var Lit_206 *jrt.String = jrt.Intern("nested-call")

var Lit_207 *jrt.String = jrt.Intern("vector")

var Lit_208 *jrt.String = jrt.Intern("set!")

var Lit_209 *jrt.String = jrt.Intern("inst")

var Lit_210 *jrt.String = jrt.Intern("call")

var Lit_211 *jrt.String = jrt.Intern("ctor-call-translator")

var Lit_212 *jrt.String = jrt.Intern("init")

var Lit_213 *jrt.String = jrt.Intern("prologue")

var Lit_214 *jrt.String = jrt.Intern("ctor-call")

var Lit_215 *jrt.String = jrt.Intern("()V")

var Lit_216 *jrt.String = jrt.Intern("components")

var Lit_217 *jrt.String = jrt.Intern("list*")

var Lit_218 *jrt.String = jrt.Intern("at-line")

var Lit_219 *jrt.String = jrt.Intern("range")

var Lit_220 *jrt.String = jrt.Intern("munge-name")

var Lit_221 *jrt.String = jrt.Intern("ctor-call-fn")

var Lit_222 *jrt.String = jrt.Intern("*")

var Lit_223 *jrt.String = jrt.Intern("go")

var Lit_224 *jrt.String = jrt.Intern("method")

var Lit_225 *jrt.String = jrt.Intern("param-list")

var Lit_226 *jrt.String = jrt.Intern("func")

var Lit_227 *jrt.String = jrt.Intern("new-name")

var Lit_228 *jrt.String = jrt.Intern("trivial-init?")

var Lit_229 *jrt.String = jrt.Intern("addr")

var Lit_230 *jrt.String = jrt.Intern("lit")

var Lit_231 *jrt.String = jrt.Intern("nil?")

var Lit_232 *jrt.String = jrt.Intern("conv")

var Lit_233 *jrt.String = jrt.Intern("int32")

var Lit_234 *jrt.String = jrt.Intern("bit-xor")

var Lit_235 *jrt.String = jrt.Intern("int64")

var Lit_236 *jrt.String = jrt.Intern(">>")

var Lit_237 *jrt.String = jrt.Intern("uint64")

var Lit_238 *jrt.String = jrt.Intern("coerce")

var Lit_239 *jrt.String = jrt.Intern("+")

var Lit_240 *jrt.String = jrt.Intern(".*\\$")

var Lit_241 *jrt.String = jrt.Intern("string-lit")

var Lit_242 *jrt.String = jrt.Intern("when")

var Lit_243 *jrt.String = jrt.Intern("==")

var Lit_244 *jrt.String = jrt.Intern("any")

var Lit_245 *jrt.String = jrt.Intern("or")

var Lit_246 *jrt.String = jrt.Intern("!=")

var Lit_247 *jrt.String = jrt.Intern("other")

var Lit_248 *jrt.String = jrt.Intern("assert")

var Lit_249 *jrt.String = jrt.Intern("true?")

var Lit_250 *jrt.String = jrt.Intern("and")

var Lit_251 *jrt.String = jrt.Intern("bridge")

var Lit_252 *jrt.String = jrt.Intern("bridge-of")

var Lit_253 *jrt.String = jrt.Intern("special")

var Lit_254 *jrt.String = jrt.Intern("hand-written?")

var Lit_255 *jrt.String = jrt.Intern("enum-values")

var Lit_256 *jrt.String = jrt.Intern("record-object-method")

var Lit_257 *jrt.String = jrt.Intern("record-object-body")

var Lit_258 *jrt.String = jrt.Intern("record-accessor")

var Lit_259 *jrt.String = jrt.Intern("component")

var Lit_260 *jrt.String = jrt.Intern("ref?")

var Lit_261 *jrt.String = jrt.Intern("assignable?")

var Lit_262 *jrt.String = jrt.Intern("cast-val")

var Lit_263 *jrt.String = jrt.Intern("expr")

var Lit_264 *jrt.String = jrt.Intern("owner")

var Lit_265 *jrt.String = jrt.Intern("impl-name")

var Lit_266 *jrt.String = jrt.Intern(".Copy")

var Lit_267 *jrt.String = jrt.Intern("enum-$values")

var Lit_268 *jrt.String = jrt.Intern("enum-valueOf")

var Lit_269 *jrt.String = jrt.Intern("constants")

var Lit_270 *jrt.String = jrt.Intern("volatile!")

var Lit_271 *jrt.String = jrt.Intern("map?")

var Lit_272 *jrt.String = jrt.Intern("run!")

var Lit_273 *jrt.String = jrt.Intern("vector?")

var Lit_274 *jrt.String = jrt.Intern("var-deref")

var Lit_275 *jrt.String = jrt.Intern("set-static")

var Lit_276 *jrt.String = jrt.Intern("get-static")

var Lit_277 *jrt.String = jrt.Intern("var-invoke")

var Lit_278 *jrt.String = jrt.Intern("vreset!")

var Lit_279 *jrt.String = jrt.Intern("declarer")

var Lit_280 *jrt.String = jrt.Intern("field")

var Lit_281 *jrt.String = jrt.Intern("vals")

var Lit_282 *jrt.String = jrt.Intern("touches-statics?")

var Lit_283 *jrt.String = jrt.Intern("benign-init?")

var Lit_284 *jrt.String = jrt.Intern("superclass-chain")

var Lit_285 *jrt.String = jrt.Intern("static?")

var Lit_286 *jrt.String = jrt.Intern("method-code-forms")

var Lit_287 *jrt.String = jrt.Intern("fail")

var Lit_288 *jrt.String = jrt.Intern("ex-data")

var Lit_289 *jrt.String = jrt.Intern("ex-info")

var Lit_290 *jrt.String = jrt.Intern("funcs")

var Lit_291 *jrt.String = jrt.Intern("derived-body")

var Lit_292 *jrt.String = jrt.Intern("analysis-failed")

var Lit_293 *jrt.String = jrt.Intern("needs-entry-guard?")

var Lit_294 *jrt.String = jrt.Intern("default")

var Lit_295 *jrt.String = jrt.Intern("jrt-impl")

var Lit_296 *jrt.String = jrt.Intern("impl-of")

var Lit_297 *jrt.String = jrt.Intern("toString")

var Lit_298 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_299 *jrt.String = jrt.Intern("clone")

var Lit_300 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_301 *jrt.String = jrt.Intern("object")

var Lit_302 *jrt.String = jrt.Intern("Ref")

var Lit_303 *jrt.String = jrt.Intern("class-fields")

var Lit_304 *jrt.String = jrt.Intern("GetClass__Class")

var Lit_305 *jrt.String = jrt.Intern("ToString__String")

var Lit_306 *jrt.String = jrt.Intern("Clone__O")

var Lit_307 *jrt.String = jrt.Intern("CloneShallow")

var Lit_308 *jrt.String = jrt.Intern(".ClearHeader")

var Lit_309 *jrt.String = jrt.Intern("promoted")

var Lit_310 *jrt.String = jrt.Intern("forwarder")

var Lit_311 *jrt.String = jrt.Intern("class-methods")

var Lit_312 *jrt.String = jrt.Intern("vmethods")

var Lit_313 *jrt.String = jrt.Intern("sort")

var Lit_314 *jrt.String = jrt.Intern("object-keys")

var Lit_315 *jrt.String = jrt.Intern("const-value")

var Lit_316 *jrt.String = jrt.Intern("static-field-name")

var Lit_317 *jrt.String = jrt.Intern("some?")

var Lit_318 *jrt.String = jrt.Intern("prim?")

var Lit_319 *jrt.String = jrt.Intern("char?")

var Lit_320 *jrt.String = jrt.Intern("float-lit")

var Lit_321 *jrt.String = jrt.Intern("F")

var Lit_322 *jrt.String = jrt.Intern("D")

var Lit_323 *jrt.String = jrt.Intern("string?")

var Lit_324 *jrt.String = jrt.Intern("const")

var Lit_325 *jrt.String = jrt.Intern("val")

var Lit_326 *jrt.String = jrt.Intern("var")

var Lit_327 *jrt.String = jrt.Intern("field-go-type")

var Lit_328 *jrt.String = jrt.Intern("clj-consts")

var Lit_329 *jrt.String = jrt.Intern("ns")

var Lit_330 *jrt.String = jrt.Intern("text")

var Lit_331 *jrt.String = jrt.Intern("clinit")

var Lit_332 *jrt.String = jrt.Intern(".Done")

var Lit_333 *jrt.String = jrt.Intern(".Run")

var Lit_334 *jrt.String = jrt.Intern("ok")

var Lit_335 *jrt.String = jrt.Intern("values")

var Lit_336 *jrt.String = jrt.Intern("d")

var Lit_337 *jrt.String = jrt.Intern("dyn")

var Lit_338 *jrt.String = jrt.Intern(".DynImplements")

var Lit_339 *jrt.String = jrt.Intern("compiled-pkg?")

var Lit_340 *jrt.String = jrt.Intern("bool")

var Lit_341 *jrt.String = jrt.Intern("_")

var Lit_342 *jrt.String = jrt.Intern("v")

var Lit_343 *jrt.String = jrt.Intern("info")

var Lit_344 *jrt.String = jrt.Intern("abstract-m?")

var Lit_345 *jrt.String = jrt.Intern("private?")

var Lit_346 *jrt.String = jrt.Intern("instance-forms")

var Lit_347 *jrt.String = jrt.Intern("comment")

var Lit_348 *jrt.String = jrt.Intern("interface")

var Lit_349 *jrt.String = jrt.Intern("iface-method-elem")

var Lit_350 *jrt.String = jrt.Intern("static-forms")

var Lit_351 *jrt.String = jrt.Intern("clj-const-fields")

var Lit_352 *jrt.String = jrt.Intern("init-forms")

var Lit_353 *jrt.String = jrt.Intern("mapcat")

var Lit_354 *jrt.String = jrt.Intern("struct")

var Lit_355 *jrt.String = jrt.Intern("super-struct-type")

var Lit_356 *jrt.String = jrt.Intern("extra-fields")

var Lit_357 *jrt.String = jrt.Intern("super-iface-type")

var Lit_358 *jrt.String = jrt.Intern("virtual-member?")

var Lit_359 *jrt.String = jrt.Intern("markers")

var Lit_360 *jrt.String = jrt.Intern("ctor-forms")

var Lit_361 *jrt.String = jrt.Intern("method-forms")

var Lit_362 *jrt.String = jrt.Intern("dispatch-forms")

var Lit_363 *jrt.String = jrt.Intern("object-forms")

var Lit_364 *jrt.String = jrt.Intern("arbace.a2g.decls$at_line")

var Lit_365 *jrt.String = jrt.Intern("arbace.a2g.decls$at_line$fn__992000041")

var Lit_366 *jrt.String = jrt.Intern("arbace.a2g.decls$body_of")

var Lit_367 *jrt.String = jrt.Intern("arbace.a2g.decls$captured_fields")

var Lit_368 *jrt.String = jrt.Intern("arbace.a2g.decls$captured_fields$iter__992000028__992000032")

var Lit_369 *jrt.String = jrt.Intern("arbace.a2g.decls$captured_fields$iter__992000028__992000032$fn__992000033")

var Lit_370 *jrt.String = jrt.Intern(".-")

var Lit_371 *jrt.String = jrt.Intern("val$")

var Lit_372 *jrt.String = jrt.Intern("arbace.a2g.decls$captured_fields$iter__992000028__992000032$fn__992000033$fn__992000034")

var Lit_373 *jrt.String = jrt.Intern("arbace.a2g.decls$class_fields")

var Lit_374 *jrt.String = jrt.Intern("arbace.a2g.decls$class_fields$iter__992000060__992000064")

var Lit_375 *jrt.String = jrt.Intern("arbace.a2g.decls$class_fields$iter__992000060__992000064$fn__992000065")

var Lit_376 *jrt.String = jrt.Intern("arbace.a2g.decls$class_fields$iter__992000060__992000064$fn__992000065$fn__992000066")

var Lit_377 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms")

var Lit_378 *jrt.String = jrt.Intern("---- ")

var Lit_379 *jrt.String = jrt.Intern("/")

var Lit_380 *jrt.String = jrt.Intern(".")

var Lit_381 *jrt.String = jrt.Intern("Object_I")

var Lit_382 *jrt.String = jrt.Intern("Is_")

var Lit_383 *jrt.String = jrt.Intern("_I")

var Lit_384 *jrt.String = jrt.Intern("Self_")

var Lit_385 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$fn__992000639")

var Lit_386 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$fn__992000641")

var Lit_387 *jrt.String = jrt.Intern("<init>")

var Lit_388 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$fn__992000643")

var Lit_389 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$fn__992000645")

var Lit_390 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000579__992000583")

var Lit_391 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000579__992000583$fn__992000584")

var Lit_392 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000579__992000583$fn__992000584$fn__992000585")

var Lit_393 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000589__992000593")

var Lit_394 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000589__992000593$fn__992000594")

var Lit_395 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000589__992000593$fn__992000594$fn__992000595")

var Lit_396 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000599__992000603")

var Lit_397 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000599__992000603$fn__992000604")

var Lit_398 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000599__992000603$fn__992000604$fn__992000605")

var Lit_399 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000609__992000613")

var Lit_400 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000609__992000613$fn__992000614")

var Lit_401 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000609__992000613$fn__992000614$fn__992000615")

var Lit_402 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000619__992000623")

var Lit_403 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000619__992000623$fn__992000624")

var Lit_404 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000619__992000623$fn__992000624$fn__992000625")

var Lit_405 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000629__992000633")

var Lit_406 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000629__992000633$fn__992000634")

var Lit_407 *jrt.String = jrt.Intern("arbace.a2g.decls$class_forms$iter__992000629__992000633$fn__992000634$fn__992000635")

var Lit_408 *jrt.String = jrt.Intern("arbace.a2g.decls$class_methods")

var Lit_409 *jrt.String = jrt.Intern("arbace.a2g.decls$class_methods$iter__992000071__992000075")

var Lit_410 *jrt.String = jrt.Intern("arbace.a2g.decls$class_methods$iter__992000071__992000075$fn__992000076")

var Lit_411 *jrt.String = jrt.Intern("<clinit>")

var Lit_412 *jrt.String = jrt.Intern("arbace.a2g.decls$class_methods$iter__992000071__992000075$fn__992000076$fn__992000077")

var Lit_413 *jrt.String = jrt.Intern("arbace.a2g.decls$clj_const_fields")

var Lit_414 *jrt.String = jrt.Intern("arbace.a2g.decls$clj_const_fields$iter__992000486__992000490")

var Lit_415 *jrt.String = jrt.Intern("arbace.a2g.decls$clj_const_fields$iter__992000486__992000490$fn__992000491")

var Lit_416 *jrt.String = jrt.Intern("arbace.a2g.decls$clj_const_fields$iter__992000486__992000490$fn__992000491$fn__992000492")

var Lit_417 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator")

var Lit_418 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126")

var Lit_419 *jrt.String = jrt.Intern("constructor ")

var Lit_420 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_421 *jrt.String = jrt.Intern("V")

var Lit_422 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_423 *jrt.String = jrt.Intern("superclass ")

var Lit_424 *jrt.String = jrt.Intern("L")

var Lit_425 *jrt.String = jrt.Intern(";")

var Lit_426 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$fn__992000127")

var Lit_427 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$fn__992000142")

var Lit_428 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$fn__992000144")

var Lit_429 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000132__992000136")

var Lit_430 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000132__992000136$fn__992000137")

var Lit_431 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000132__992000136$fn__992000137$fn__992000138")

var Lit_432 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000149__992000153")

var Lit_433 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000149__992000153$fn__992000154")

var Lit_434 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_call_translator$fn__992000126$iter__992000149__992000153$fn__992000154$fn__992000155")

var Lit_435 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_desc")

var Lit_436 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms")

var Lit_437 *jrt.String = jrt.Intern("this_0")

var Lit_438 *jrt.String = jrt.Intern("x0")

var Lit_439 *jrt.String = jrt.Intern("enumName")

var Lit_440 *jrt.String = jrt.Intern("enumOrdinal")

var Lit_441 *jrt.String = jrt.Intern("_Init")

var Lit_442 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$fn__992000195")

var Lit_443 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$fn__992000195$fn__992000196")

var Lit_444 *jrt.String = jrt.Intern("NN")

var Lit_445 *jrt.String = jrt.Intern("A2g_NotNull")

var Lit_446 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$fn__992000195$fn__992000196$fn__992000215")

var Lit_447 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$fn__992000243")

var Lit_448 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000165__992000169")

var Lit_449 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000165__992000169$fn__992000170")

var Lit_450 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000165__992000169$fn__992000170$fn__992000171")

var Lit_451 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000175__992000179")

var Lit_452 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000175__992000179$fn__992000180")

var Lit_453 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000175__992000179$fn__992000180$fn__992000181")

var Lit_454 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000185__992000189")

var Lit_455 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000185__992000189$fn__992000190")

var Lit_456 *jrt.String = jrt.Intern("val_")

var Lit_457 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000185__992000189$fn__992000190$fn__992000191")

var Lit_458 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000233__992000237")

var Lit_459 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000233__992000237$fn__992000238")

var Lit_460 *jrt.String = jrt.Intern("p")

var Lit_461 *jrt.String = jrt.Intern("arbace.a2g.decls$ctor_forms$iter__992000233__992000237$fn__992000238$fn__992000239")

var Lit_462 *jrt.String = jrt.Intern("arbace.a2g.decls$derived_body")

var Lit_463 *jrt.String = jrt.Intern(".Impl_")

var Lit_464 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_465 *jrt.String = jrt.Intern("__VALUES")

var Lit_466 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_467 *jrt.String = jrt.Intern("_class")

var Lit_468 *jrt.String = jrt.Intern("_Cast")

var Lit_469 *jrt.String = jrt.Intern("Enum_ValueOf_Class_String__Enum")

var Lit_470 *jrt.String = jrt.Intern("A2g_NotTranslated")

var Lit_471 *jrt.String = jrt.Intern("derived ")

var Lit_472 *jrt.String = jrt.Intern("arbace.a2g.decls$derived_body$fn__992000272")

var Lit_473 *jrt.String = jrt.Intern("arbace.a2g.decls$derived_body$iter__992000274__992000278")

var Lit_474 *jrt.String = jrt.Intern("arbace.a2g.decls$derived_body$iter__992000274__992000278$fn__992000279")

var Lit_475 *jrt.String = jrt.Intern("arbace.a2g.decls$derived_body$iter__992000274__992000278$fn__992000279$fn__992000280")

var Lit_476 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms")

var Lit_477 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000371__992000375")

var Lit_478 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000371__992000375$fn__992000376")

var Lit_479 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000371__992000375$fn__992000376$fn__992000377")

var Lit_480 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385")

var Lit_481 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386")

var Lit_482 *jrt.String = jrt.Intern("abstract ")

var Lit_483 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387")

var Lit_484 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387$iter__992000397__992000401")

var Lit_485 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387$iter__992000397__992000401$fn__992000402")

var Lit_486 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$fn__992000387$iter__992000397__992000401$fn__992000402$fn__992000403")

var Lit_487 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$iter__992000417__992000421")

var Lit_488 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$iter__992000417__992000421$fn__992000422")

var Lit_489 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000381__992000385$fn__992000386$iter__992000417__992000421$fn__992000422$fn__992000423")

var Lit_490 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000429__992000433")

var Lit_491 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000429__992000433$fn__992000434")

var Lit_492 *jrt.String = jrt.Intern("arbace.a2g.decls$dispatch_forms$iter__992000429__992000433$fn__992000434$fn__992000435")

var Lit_493 *jrt.String = jrt.Intern("arbace.a2g.decls$ensure_terminated")

var Lit_494 *jrt.String = jrt.Intern("a2g: unreachable")

var Lit_495 *jrt.String = jrt.Intern("arbace.a2g.decls$eval992000004$loading__1927001464__auto____992000005")

var Lit_496 *jrt.String = jrt.Intern("arbace.a2g.decls$eval992000008$fn__992000009")

var Lit_497 *jrt.String = jrt.Intern("arbace.a2g.decls$extra_fields")

var Lit_498 *jrt.String = jrt.Intern("arbace.a2g.decls$extra_fields$iter__992000088__992000092")

var Lit_499 *jrt.String = jrt.Intern("arbace.a2g.decls$extra_fields$iter__992000088__992000092$fn__992000093")

var Lit_500 *jrt.String = jrt.Intern("arbace.a2g.decls$extra_fields$iter__992000088__992000092$fn__992000093$fn__992000094")

var Lit_501 *jrt.String = jrt.Intern("arbace.a2g.decls$field_go_type")

var Lit_502 *jrt.String = jrt.Intern("B")

var Lit_503 *jrt.String = jrt.Intern("C")

var Lit_504 *jrt.String = jrt.Intern("I")

var Lit_505 *jrt.String = jrt.Intern("J")

var Lit_506 *jrt.String = jrt.Intern("S")

var Lit_507 *jrt.String = jrt.Intern("Z")

var Lit_508 *jrt.String = jrt.Intern("Volatile")

var Lit_509 *jrt.String = jrt.Intern("arbace.a2g.decls$forwarder")

var Lit_510 *jrt.String = jrt.Intern("arbace.a2g.decls$forwarder$iter__992000355__992000359")

var Lit_511 *jrt.String = jrt.Intern("arbace.a2g.decls$forwarder$iter__992000355__992000359$fn__992000360")

var Lit_512 *jrt.String = jrt.Intern("arbace.a2g.decls$forwarder$iter__992000355__992000359$fn__992000360$fn__992000361")

var Lit_513 *jrt.String = jrt.Intern("arbace.a2g.decls$gt")

var Lit_514 *jrt.String = jrt.Intern("arbace.a2g.decls$has_QMARK_")

var Lit_515 *jrt.String = jrt.Intern("arbace.a2g.decls$hw_markers")

var Lit_516 *jrt.String = jrt.Intern("arbace.a2g.decls$hw_markers$iter__992000109__992000113")

var Lit_517 *jrt.String = jrt.Intern("arbace.a2g.decls$hw_markers$iter__992000109__992000113$fn__992000114")

var Lit_518 *jrt.String = jrt.Intern("arbace.a2g.decls$hw_markers$iter__992000109__992000113$fn__992000114$fn__992000115")

var Lit_519 *jrt.String = jrt.Intern("arbace.a2g.decls$iface_method_elem")

var Lit_520 *jrt.String = jrt.Intern("arbace.a2g.decls$iface_method_elem$fn__992000102")

var Lit_521 *jrt.String = jrt.Intern("arbace.a2g.decls$init_forms")

var Lit_522 *jrt.String = jrt.Intern("_init")

var Lit_523 *jrt.String = jrt.Intern("ClassInit")

var Lit_524 *jrt.String = jrt.Intern("_clinit")

var Lit_525 *jrt.String = jrt.Intern("arbace.a2g.decls$init_forms$fn__992000461")

var Lit_526 *jrt.String = jrt.Intern("arbace.a2g.decls$init_forms$fn__992000461$fn__992000462")

var Lit_527 *jrt.String = jrt.Intern(".<clinit>")

var Lit_528 *jrt.String = jrt.Intern("Clojure constant ")

var Lit_529 *jrt.String = jrt.Intern("#'")

var Lit_530 *jrt.String = jrt.Intern("arbace.a2g.decls$instance_forms")

var Lit_531 *jrt.String = jrt.Intern("IsDynamic")

var Lit_532 *jrt.String = jrt.Intern("Dynamic")

var Lit_533 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_534 *jrt.String = jrt.Intern("ClassCast")

var Lit_535 *jrt.String = jrt.Intern("arbace.a2g.decls$interface_closure")

var Lit_536 *jrt.String = jrt.Intern("arbace.a2g.decls$interface_closure$fn__992000106")

var Lit_537 *jrt.String = jrt.Intern("arbace.a2g.decls$markers")

var Lit_538 *jrt.String = jrt.Intern("arbace.a2g.decls$markers$fn__992000121")

var Lit_539 *jrt.String = jrt.Intern("arbace.a2g.decls$member_line")

var Lit_540 *jrt.String = jrt.Intern("arbace.a2g.decls$method_code_forms")

var Lit_541 *jrt.String = jrt.Intern("arbace.a2g.decls$method_code_forms$fn__992000057")

var Lit_542 *jrt.String = jrt.Intern("MonitorEnter")

var Lit_543 *jrt.String = jrt.Intern("MonitorExit")

var Lit_544 *jrt.String = jrt.Intern("arbace.a2g.decls$method_code_forms$iter__992000047__992000051")

var Lit_545 *jrt.String = jrt.Intern("arbace.a2g.decls$method_code_forms$iter__992000047__992000051$fn__992000052")

var Lit_546 *jrt.String = jrt.Intern("arbace.a2g.decls$method_code_forms$iter__992000047__992000051$fn__992000052$fn__992000053")

var Lit_547 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms")

var Lit_548 *jrt.String = jrt.Intern("_native")

var Lit_549 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$fn__992000325")

var Lit_550 *jrt.String = jrt.Intern(": ")

var Lit_551 *jrt.String = jrt.Intern("a2g: translating ")

var Lit_552 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$fn__992000325$iter__992000326__992000330")

var Lit_553 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$fn__992000325$iter__992000326__992000330$fn__992000331")

var Lit_554 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$fn__992000325$iter__992000326__992000330$fn__992000331$fn__992000332")

var Lit_555 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000295__992000299")

var Lit_556 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000295__992000299$fn__992000300")

var Lit_557 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000295__992000299$fn__992000300$fn__992000301")

var Lit_558 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000305__992000309")

var Lit_559 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000305__992000309$fn__992000310")

var Lit_560 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000305__992000309$fn__992000310$fn__992000311")

var Lit_561 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000315__992000319")

var Lit_562 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000315__992000319$fn__992000320")

var Lit_563 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000315__992000319$fn__992000320$fn__992000321")

var Lit_564 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000337__992000341")

var Lit_565 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000337__992000341$fn__992000342")

var Lit_566 *jrt.String = jrt.Intern("arbace.a2g.decls$method_forms$iter__992000337__992000341$fn__992000342$fn__992000343")

var Lit_567 *jrt.String = jrt.Intern("arbace.a2g.decls$needs_entry_guard_QMARK_")

var Lit_568 *jrt.String = jrt.Intern("arbace.a2g.decls$new_fn_state")

var Lit_569 *jrt.String = jrt.Intern("f")

var Lit_570 *jrt.String = jrt.Intern("arbace.a2g.decls$object_forms")

var Lit_571 *jrt.String = jrt.Intern("Ljava/lang/Cloneable;")

var Lit_572 *jrt.String = jrt.Intern("Class")

var Lit_573 *jrt.String = jrt.Intern("String")

var Lit_574 *jrt.String = jrt.Intern("Object_toString")

var Lit_575 *jrt.String = jrt.Intern("A2g_ObjectClone")

var Lit_576 *jrt.String = jrt.Intern("CloneNotSupported")

var Lit_577 *jrt.String = jrt.Intern("arbace.a2g.decls$object_forms$fn__992000368")

var Lit_578 *jrt.String = jrt.Intern("a2g$class")

var Lit_579 *jrt.String = jrt.Intern("arbace.a2g.decls$param_list")

var Lit_580 *jrt.String = jrt.Intern("arbace.a2g.decls$param_list$fn__992000015")

var Lit_581 *jrt.String = jrt.Intern("arbace.a2g.decls$reached_QMARK_")

var Lit_582 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body")

var Lit_583 *jrt.String = jrt.Intern("hashCode")

var Lit_584 *jrt.String = jrt.Intern("")

var Lit_585 *jrt.String = jrt.Intern("[")

var Lit_586 *jrt.String = jrt.Intern("]")

var Lit_587 *jrt.String = jrt.Intern("Concat")

var Lit_588 *jrt.String = jrt.Intern("equals")

var Lit_589 *jrt.String = jrt.Intern("GetClass")

var Lit_590 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_591 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body$fld__992000248")

var Lit_592 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body$fn__992000257")

var Lit_593 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body$fn__992000259")

var Lit_594 *jrt.String = jrt.Intern("=")

var Lit_595 *jrt.String = jrt.Intern(", ")

var Lit_596 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body$fn__992000261")

var Lit_597 *jrt.String = jrt.Intern("A2g_DoubleBits")

var Lit_598 *jrt.String = jrt.Intern("A2g_FloatBits")

var Lit_599 *jrt.String = jrt.Intern("A2g_ObjEquals")

var Lit_600 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body$hash__992000250")

var Lit_601 *jrt.String = jrt.Intern("A2g_BoolHash")

var Lit_602 *jrt.String = jrt.Intern("A2g_ObjHash")

var Lit_603 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body$js__992000246")

var Lit_604 *jrt.String = jrt.Intern("arbace.a2g.decls$record_object_body$strof__992000253")

var Lit_605 *jrt.String = jrt.Intern("StrOfInt")

var Lit_606 *jrt.String = jrt.Intern("StrOfChar")

var Lit_607 *jrt.String = jrt.Intern("StrOfDouble")

var Lit_608 *jrt.String = jrt.Intern("StrOfFloat")

var Lit_609 *jrt.String = jrt.Intern("StrOfLong")

var Lit_610 *jrt.String = jrt.Intern("StrOfBool")

var Lit_611 *jrt.String = jrt.Intern("StrOfObj")

var Lit_612 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms")

var Lit_613 *jrt.String = jrt.Intern(" (declared from reflection)")

var Lit_614 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000508__992000512")

var Lit_615 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000508__992000512$fn__992000513")

var Lit_616 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000508__992000512$fn__992000513$fn__992000514")

var Lit_617 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000518__992000522")

var Lit_618 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000518__992000522$fn__992000523")

var Lit_619 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000518__992000522$fn__992000523$fn__992000524")

var Lit_620 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000528__992000532")

var Lit_621 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000528__992000532$fn__992000533")

var Lit_622 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000528__992000532$fn__992000533$fn__992000534")

var Lit_623 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542")

var Lit_624 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543")

var Lit_625 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544")

var Lit_626 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544$iter__992000548__992000552")

var Lit_627 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544$iter__992000548__992000552$fn__992000553")

var Lit_628 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$fn__992000544$iter__992000548__992000552$fn__992000553$fn__992000554")

var Lit_629 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$iter__992000562__992000566")

var Lit_630 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$iter__992000562__992000566$fn__992000567")

var Lit_631 *jrt.String = jrt.Intern("arbace.a2g.decls$reflected_forms$iter__992000538__992000542$fn__992000543$iter__992000562__992000566$fn__992000567$fn__992000568")

var Lit_632 *jrt.String = jrt.Intern("arbace.a2g.decls$result_meta")

var Lit_633 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms")

var Lit_634 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms$iter__992000440__992000444")

var Lit_635 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445")

var Lit_636 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000446")

var Lit_637 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000446$fn__992000448")

var Lit_638 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000446$fn__992000450")

var Lit_639 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000454")

var Lit_640 *jrt.String = jrt.Intern("arbace.a2g.decls$static_forms$iter__992000440__992000444$fn__992000445$fn__992000456")

var Lit_641 *jrt.String = jrt.Intern("arbace.a2g.decls$stub_body")

var Lit_642 *jrt.String = jrt.Intern("arbace.a2g.decls$super_iface_type")

var Lit_643 *jrt.String = jrt.Intern("arbace.a2g.decls$super_struct_type")

var Lit_644 *jrt.String = jrt.Intern("Object")

var Lit_645 *jrt.String = jrt.Intern("arbace.a2g.decls$tag")

var Lit_646 *jrt.String = jrt.Intern("arbace.a2g.decls$terminating_QMARK_")

var Lit_647 *jrt.String = jrt.Intern("arbace.a2g.decls$touches_statics_QMARK_")

var Lit_648 *jrt.String = jrt.Intern("arbace.a2g.decls$touches_statics_QMARK_$w__992000285")

var Lit_649 *jrt.String = jrt.Intern("arbace.a2g.decls$with_ret")

var Lit_650 *jrt.String = jrt.Intern("in-ns")

var Lit_651 *jrt.String = jrt.Intern("dynamic")

var Lit_652 *jrt.String = jrt.Intern("column")

var Lit_653 *jrt.String = jrt.Intern("file")

var Lit_654 *jrt.String = jrt.Intern("arbace/a2g/decls.ae")

var Lit_655 *jrt.String = jrt.Intern("The set of reached method keys [class name desc].")

var Lit_656 *jrt.String = jrt.Intern("private")

var Lit_657 *jrt.String = jrt.Intern("arglists")

var Lit_658 *jrt.String = jrt.Intern("descs")

var Lit_659 *jrt.String = jrt.Intern("syms")

var Lit_660 *jrt.String = jrt.Intern("Go parameter symbols tagged with the Go types of descs, named after the analyzer's\n  bindings when given.")

var Lit_661 *jrt.String = jrt.Intern("r")

var Lit_662 *jrt.String = jrt.Intern("n")

var Lit_663 *jrt.String = jrt.Intern("&")

var Lit_664 *jrt.String = jrt.Intern("more")

var Lit_665 *jrt.String = jrt.Intern("Is Go form f a terminating statement (Go spec, \"Terminating statements\"): a return or\n  panic, a block (let, do) ending in one, an if whose two branches end in one?")

var Lit_666 *jrt.String = jrt.Intern("forms")

var Lit_667 *jrt.String = jrt.Intern("has-results")

var Lit_668 *jrt.String = jrt.Intern("Go needs a terminating statement in a function with results: a final panic when the last\n  form is not one.")

var Lit_669 *jrt.String = jrt.Intern("tsym")

var Lit_670 *jrt.String = jrt.Intern("binding id -> Go form reading the captured local from the class's field (local and\n  anonymous classes), for code of class n.")

var Lit_671 *jrt.String = jrt.Intern("The class forms line of method or constructor m (its member form's), or nil.")

var Lit_672 *jrt.String = jrt.Intern("Declaration forms with the line of member m (A2G-SPEC §4.3).")

var Lit_673 *jrt.String = jrt.Intern("ab")

var Lit_674 *jrt.String = jrt.Intern("keys")

var Lit_675 *jrt.String = jrt.Intern("The Go statements of method m's body (analyzed body ab) of class n.")

var Lit_676 *jrt.String = jrt.Intern("The methods of translated class n that exist in Go (descriptors in the world).")

var Lit_677 *jrt.String = jrt.Intern("mm")

var Lit_678 *jrt.String = jrt.Intern("The Go struct type a class embeds: its superclass's struct (jrt.Object at the root).")

var Lit_679 *jrt.String = jrt.Intern("The Go type of a field, atomic for a volatile one (§8.2).")

var Lit_680 *jrt.String = jrt.Intern("The outer instance and captured locals' fields of an inner, local or anonymous class.")

var Lit_681 *jrt.String = jrt.Intern("The interfaces a class or interface n implements (directly and through its supertypes),\n  in the world.")

var Lit_682 *jrt.String = jrt.Intern("The Is_ markers jrt's hand-written struct (and its ancestors) has.")

var Lit_683 *jrt.String = jrt.Intern("The interfaces whose marker class n's struct declares: those not already marked by its\n  superclass's struct.")

var Lit_684 *jrt.String = jrt.Intern("Translates the constructor call node of a constructor of class n (super. or this.):\n  the superclass's or this class's constructor body on the embedded struct.")

var Lit_685 *jrt.String = jrt.Intern("The allocation function C_New_... (concrete classes) and the constructor body Ctor_... of\n  constructor mm of class n.")

var Lit_686 *jrt.String = jrt.Intern("ps")

var Lit_687 *jrt.String = jrt.Intern("A record's derived toString, hashCode or equals, as java.lang.runtime.ObjectMethods makes\n  them: Name[c=v, ...]; 31 * h + the component's hash, in order; the same class and equal\n  components (wrapper compare for primitives, Objects.equals for references).")

var Lit_688 *jrt.String = jrt.Intern("Go statements of a derived method (enum values/valueOf/$values, bridges, record members).\n  The code's names are qualified as package pkg sees them (a bridge's casts in arbace/lang name\n  jrt's classes: the suite's Java fixtures, ConcreteClass).")

var Lit_689 *jrt.String = jrt.Intern("classes")

var Lit_690 *jrt.String = jrt.Intern("Does analyzed code ab access a static field of a class in classes (directly: the guarded\n  accesses of other classes run their own initialization)?")

var Lit_691 *jrt.String = jrt.Intern("Does static method mm of class n (body ab) start with n's initialization guard (§6.2)? Not\n  when the initialization is benign (unobservable but through n's statics, model/benign-init?)\n  and the body reads none of the statics of n and its superclasses: then delaying the\n  initialization to the first guarded access cannot be told apart (A2G-NOTES, phase 2D).")

var Lit_692 *jrt.String = jrt.Intern("The Go method (instance) or function (static) of method mm of class n: its body when\n  reached, a stub otherwise.")

var Lit_693 *jrt.String = jrt.Intern("k")

var Lit_694 *jrt.String = jrt.Intern("impl")

var Lit_695 *jrt.String = jrt.Intern("A dispatch method of concrete class n for virtual method k: calls the implementation.")

var Lit_696 *jrt.String = jrt.Intern("Ref, GetClass__Class, ToString__String, Clone__O, CloneShallow of concrete class n (§5.8).")

var Lit_697 *jrt.String = jrt.Intern("The dispatch methods and forwarders of concrete class n (§5.4).")

var Lit_698 *jrt.String = jrt.Intern("C_init, C_Init and C_clinit of a class with non-trivial initialization (§6.2).")

var Lit_699 *jrt.String = jrt.Intern("C_InstanceOf and C_Cast (§5.7).")

var Lit_700 *jrt.String = jrt.Intern("reflected-forms")

var Lit_701 *jrt.String = jrt.Intern("A JDK interface declared from reflection (no class forms): its Go interface with the\n  methods in the world, its default and static methods as stubs (no code to translate), and\n  instanceof/cast.")

var Lit_702 *jrt.String = jrt.Intern("class-forms")

var Lit_703 *jrt.String = jrt.Intern("All Go forms of translated class n (in package pkg), in order.")
