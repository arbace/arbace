//line aot_arbace_c_dg__init.ae:1
package aot_arbace_c_dg

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_dg__init_A_Unit0__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c_dg__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_dg__init_A_const_1) }
//line :1:1
func A_arbace_c_dg__init_A_Unit1__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c_dg__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_2)) }
//line :1:1
func A_arbace_c_dg__init_A_Unit2__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_dg_eval551000004_loading__1927001464__auto____551000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_dg_eval551000004_loading__1927001464__auto____551000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_281, false, nil); A_arbace_c_dg_eval551000004_loading__1927001464__auto____551000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_c_dg__init_A_Unit3__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c_dg__init_A_const_1)).Equals_O__Z(A_arbace_c_dg__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_dg_eval551000008_fn__551000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_dg_eval551000008_fn__551000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_282, false, nil); A_arbace_c_dg_eval551000008_fn__551000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_c_dg__init_A_Load__O() any { A_arbace_c_dg__init_A_Init(); jrt.StartCheck(); A_arbace_c_dg__init_A_Unit0__O(); A_arbace_c_dg__init_A_Unit1__O(); A_arbace_c_dg__init_A_Unit2__O(); A_arbace_c_dg__init_A_Unit3__O(); A_arbace_c_dg__init_A_Unit4__O(); A_arbace_c_dg__init_A_Unit5__O(); A_arbace_c_dg__init_A_Unit6__O(); A_arbace_c_dg__init_A_Unit7__O(); A_arbace_c_dg__init_A_Unit8__O(); A_arbace_c_dg__init_A_Unit9__O(); A_arbace_c_dg__init_A_Unit10__O(); A_arbace_c_dg__init_A_Unit11__O(); A_arbace_c_dg__init_A_Unit12__O(); A_arbace_c_dg__init_A_Unit13__O(); A_arbace_c_dg__init_A_Unit14__O(); A_arbace_c_dg__init_A_Unit15__O(); A_arbace_c_dg__init_A_Unit16__O(); A_arbace_c_dg__init_A_Unit17__O(); A_arbace_c_dg__init_A_Unit18__O(); A_arbace_c_dg__init_A_Unit19__O(); A_arbace_c_dg__init_A_Unit20__O(); A_arbace_c_dg__init_A_Unit21__O(); A_arbace_c_dg__init_A_Unit22__O(); A_arbace_c_dg__init_A_Unit23__O(); A_arbace_c_dg__init_A_Unit24__O(); A_arbace_c_dg__init_A_Unit25__O(); A_arbace_c_dg__init_A_Unit26__O(); A_arbace_c_dg__init_A_Unit27__O(); A_arbace_c_dg__init_A_Unit28__O(); A_arbace_c_dg__init_A_Unit29__O(); A_arbace_c_dg__init_A_Unit30__O(); A_arbace_c_dg__init_A_Unit31__O(); A_arbace_c_dg__init_A_Unit32__O(); A_arbace_c_dg__init_A_Unit33__O(); A_arbace_c_dg__init_A_Unit34__O(); A_arbace_c_dg__init_A_Unit35__O(); A_arbace_c_dg__init_A_Unit36__O(); A_arbace_c_dg__init_A_Unit37__O(); A_arbace_c_dg__init_A_Unit38__O(); A_arbace_c_dg__init_A_Unit39__O(); A_arbace_c_dg__init_A_Unit40__O(); A_arbace_c_dg__init_A_Unit41__O(); A_arbace_c_dg__init_A_Unit42__O(); A_arbace_c_dg__init_A_Unit43__O(); A_arbace_c_dg__init_A_Unit44__O(); A_arbace_c_dg__init_A_Unit45__O(); return nil }















func A_arbace_c_dg__init_A_Unit4__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); return A_arbace_c_dg__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }




func A_arbace_c_dg__init_A_Unit5__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_5; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c_dg_scan_braced_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_dg_scan_braced_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_283, false, nil); A_arbace_c_dg_scan_braced_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_6)); return A_arbace_c_dg__init_A_const_5 }














func A_arbace_c_dg__init_A_Unit6__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_c_dg_read_quoted_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_dg_read_quoted_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_284, false, nil); A_arbace_c_dg_read_quoted_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_8)); return A_arbace_c_dg__init_A_const_7 }












func A_arbace_c_dg__init_A_Unit7__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c_dg_tcl_words_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_dg_tcl_words_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_285, false, nil); A_arbace_c_dg_tcl_words_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_10)); return A_arbace_c_dg__init_A_const_9 }






















func A_arbace_c_dg__init_A_Unit8__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c_dg_line_starts_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_dg_line_starts_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_286, false, nil); A_arbace_c_dg_line_starts_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_12)); return A_arbace_c_dg__init_A_const_11 }





func A_arbace_c_dg__init_A_Unit9__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c_dg_line_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_dg_line_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_287, false, nil); A_arbace_c_dg_line_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_14)); return A_arbace_c_dg__init_A_const_13 }








func A_arbace_c_dg__init_A_Unit10__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c_dg_directives_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_dg_directives_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_288, false, nil); A_arbace_c_dg_directives_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_16)); return A_arbace_c_dg__init_A_const_15 }
















func A_arbace_c_dg__init_A_Unit11__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); A_arbace_c_dg__init_A_const_17.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_18)); return A_arbace_c_dg__init_A_const_17.SetDynamic_Z__Var(true).Ref() }




func A_arbace_c_dg__init_A_Unit12__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c_dg_sel_atom_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_dg_sel_atom_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_289, false, nil); A_arbace_c_dg_sel_atom_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_20)); return A_arbace_c_dg__init_A_const_19 }





func A_arbace_c_dg__init_A_Unit13__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c_dg_eval_selector_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_dg_eval_selector_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_290, false, nil); A_arbace_c_dg_eval_selector_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_22)); return A_arbace_c_dg__init_A_const_21 }





func A_arbace_c_dg__init_A_Unit14__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c_dg_sel_info_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_dg_sel_info_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_291, false, nil); A_arbace_c_dg_sel_info_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_24)); return A_arbace_c_dg__init_A_const_23 }














func A_arbace_c_dg__init_A_Unit15__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c_dg_line_names_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_dg_line_names_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_292, false, nil); A_arbace_c_dg_line_names_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_26)); return A_arbace_c_dg__init_A_const_25 }




func A_arbace_c_dg__init_A_Unit16__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c_dg_resolve_line_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_dg_resolve_line_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_293, false, nil); A_arbace_c_dg_resolve_line_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_28)); return A_arbace_c_dg__init_A_const_27 }












func A_arbace_c_dg__init_A_Unit17__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); A_arbace_c_dg__init_A_const_29.BindRoot_O__V(A_arbace_c_dg__init_A_const_30); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_31)); return A_arbace_c_dg__init_A_const_29 }

func A_arbace_c_dg__init_A_Unit18__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c_dg_analyze_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_dg_analyze_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_294, false, nil); A_arbace_c_dg_analyze_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_33)); return A_arbace_c_dg__init_A_const_32 }



















































func A_arbace_c_dg__init_A_Unit19__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c_dg_error_line_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_dg_error_line_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_295, false, nil); A_arbace_c_dg_error_line_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_35)); return A_arbace_c_dg__init_A_const_34 }





func A_arbace_c_dg__init_A_Unit20__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c_dg_slurp_latin1_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_dg_slurp_latin1_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_296, false, nil); A_arbace_c_dg_slurp_latin1_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_37)); return A_arbace_c_dg__init_A_const_36 }

func A_arbace_c_dg__init_A_Unit21__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(221, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c_dg_one_line_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_dg_one_line_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_297, false, nil); A_arbace_c_dg_one_line_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_39)); return A_arbace_c_dg__init_A_const_38 }

func A_arbace_c_dg__init_A_Unit22__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c_dg_read_file_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_dg_read_file_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_298, false, nil); A_arbace_c_dg_read_file_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_41)); return A_arbace_c_dg__init_A_const_40 }









































































func A_arbace_c_dg__init_A_Unit23__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c_dg_gcc_lines_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_dg_gcc_lines_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_299, false, nil); A_arbace_c_dg_gcc_lines_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_43)); return A_arbace_c_dg__init_A_const_42 }

























func A_arbace_c_dg__init_A_Unit24__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c_dg_gcc_agrees_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_dg_gcc_agrees_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_300, false, nil); A_arbace_c_dg_gcc_agrees_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_45)); return A_arbace_c_dg__init_A_const_44 }




















func A_arbace_c_dg__init_A_Unit25__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(344, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c_dg_msg_of_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_dg_msg_of_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_301, false, nil); A_arbace_c_dg_msg_of_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_47)); return A_arbace_c_dg__init_A_const_46 }


func A_arbace_c_dg__init_A_Unit26__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(347, 1); A_arbace_c_dg__init_A_const_48.BindRoot_O__V(A_arbace_c_dg__init_A_const_49); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_50)); return A_arbace_c_dg__init_A_const_48 }


func A_arbace_c_dg__init_A_Unit27__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c_dg_syntax_expectation_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c_dg_syntax_expectation_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_302, false, nil); A_arbace_c_dg_syntax_expectation_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_52)); return A_arbace_c_dg__init_A_const_51 }





func A_arbace_c_dg__init_A_Unit28__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c_dg_verdict_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c_dg_verdict_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_303, false, nil); A_arbace_c_dg_verdict_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_54)); return A_arbace_c_dg__init_A_const_53 }




















































func A_arbace_c_dg__init_A_Unit29__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(409, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c_dg_msg_mismatch_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c_dg_msg_mismatch_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_304, false, nil); A_arbace_c_dg_msg_mismatch_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_56)); return A_arbace_c_dg__init_A_const_55 }

















func A_arbace_c_dg__init_A_Unit30__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(427, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c_dg_load_wording_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c_dg_load_wording_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_305, false, nil); A_arbace_c_dg_load_wording_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_58)); return A_arbace_c_dg__init_A_const_57 }






func A_arbace_c_dg__init_A_Unit31__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c_dg_family_explains_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c_dg_family_explains_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_306, false, nil); A_arbace_c_dg_family_explains_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_60)); return A_arbace_c_dg__init_A_const_59 }







func A_arbace_c_dg__init_A_Unit32__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c_dg_unexplained_messages_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c_dg_unexplained_messages_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_307, false, nil); A_arbace_c_dg_unexplained_messages_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_62)); return A_arbace_c_dg__init_A_const_61 }





func A_arbace_c_dg__init_A_Unit33__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(448, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c_dg_message_verdict_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c_dg_message_verdict_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_308, false, nil); A_arbace_c_dg_message_verdict_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_64)); return A_arbace_c_dg__init_A_const_63 }

























func A_arbace_c_dg__init_A_Unit34__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(474, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c_dg_esc_name_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c_dg_esc_name_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_309, false, nil); A_arbace_c_dg_esc_name_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_66)); return A_arbace_c_dg__init_A_const_65 }

func A_arbace_c_dg__init_A_Unit35__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(476, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c_dg_entries_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c_dg_entries_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_310, false, nil); A_arbace_c_dg_entries_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_68)); return A_arbace_c_dg__init_A_const_67 }









func A_arbace_c_dg__init_A_Unit36__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(486, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c_dg_base_of_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c_dg_base_of_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_311, false, nil); A_arbace_c_dg_base_of_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_70)); return A_arbace_c_dg__init_A_const_69 }

func A_arbace_c_dg__init_A_Unit37__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(488, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c_dg_directives_cmd_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c_dg_directives_cmd_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_312, false, nil); A_arbace_c_dg_directives_cmd_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_72)); return A_arbace_c_dg__init_A_const_71 }





























func A_arbace_c_dg__init_A_Unit38__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(518, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c_dg_retry_timeouts_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c_dg_retry_timeouts_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_313, false, nil); A_arbace_c_dg_retry_timeouts_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_74)); return A_arbace_c_dg__init_A_const_73 }












func A_arbace_c_dg__init_A_Unit39__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c_dg_read_cmd_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c_dg_read_cmd_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_314, false, nil); A_arbace_c_dg_read_cmd_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_76)); return A_arbace_c_dg__init_A_const_75 }





















func A_arbace_c_dg__init_A_Unit40__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(553, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c_dg_gcc_cmd_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c_dg_gcc_cmd_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_315, false, nil); A_arbace_c_dg_gcc_cmd_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_78)); return A_arbace_c_dg__init_A_const_77 }























func A_arbace_c_dg__init_A_Unit41__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(577, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c_dg_control_result_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c_dg_control_result_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_316, false, nil); A_arbace_c_dg_control_result_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_80)); return A_arbace_c_dg__init_A_const_79 }
















func A_arbace_c_dg__init_A_Unit42__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(594, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c_dg_control_rows_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c_dg_control_rows_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_317, false, nil); A_arbace_c_dg_control_rows_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_82)); return A_arbace_c_dg__init_A_const_81 }














func A_arbace_c_dg__init_A_Unit43__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(609, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_c_dg_classify_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c_dg_classify_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_318, false, nil); A_arbace_c_dg_classify_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_84)); return A_arbace_c_dg__init_A_const_83 }



func A_arbace_c_dg__init_A_Unit44__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(613, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_85; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__78 any = A_arbace_c_dg_judge_cmd_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c_dg_judge_cmd_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_319, true, nil); A_arbace_c_dg_judge_cmd_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__78, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_86)); return A_arbace_c_dg__init_A_const_85 }

































































































































func A_arbace_c_dg__init_A_Unit45__O() any { A_arbace_c_dg__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(743, 1); var tmp1 *lang.Var = A_arbace_c_dg__init_A_const_87; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__80 any = A_arbace_c_dg__main_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c_dg__main_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_320, true, nil); A_arbace_c_dg__main_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__80, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_dg__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_dg__init_A_const_88)); return A_arbace_c_dg__init_A_const_87 }



type A_arbace_c_dg__init_A struct{ jrt.Object }

var A_arbace_c_dg__init_A_const_pool *jrt.RefArray

var A_arbace_c_dg__init_A_const_0 *lang.Var

var A_arbace_c_dg__init_A_const_1 any

var A_arbace_c_dg__init_A_const_2 any

var A_arbace_c_dg__init_A_const_3 any

var A_arbace_c_dg__init_A_const_4 *lang.Var

var A_arbace_c_dg__init_A_const_5 *lang.Var

var A_arbace_c_dg__init_A_const_6 any

var A_arbace_c_dg__init_A_const_7 *lang.Var

var A_arbace_c_dg__init_A_const_8 any

var A_arbace_c_dg__init_A_const_9 *lang.Var

var A_arbace_c_dg__init_A_const_10 any

var A_arbace_c_dg__init_A_const_11 *lang.Var

var A_arbace_c_dg__init_A_const_12 any

var A_arbace_c_dg__init_A_const_13 *lang.Var

var A_arbace_c_dg__init_A_const_14 any

var A_arbace_c_dg__init_A_const_15 *lang.Var

var A_arbace_c_dg__init_A_const_16 any

var A_arbace_c_dg__init_A_const_17 *lang.Var

var A_arbace_c_dg__init_A_const_18 any

var A_arbace_c_dg__init_A_const_19 *lang.Var

var A_arbace_c_dg__init_A_const_20 any

var A_arbace_c_dg__init_A_const_21 *lang.Var

var A_arbace_c_dg__init_A_const_22 any

var A_arbace_c_dg__init_A_const_23 *lang.Var

var A_arbace_c_dg__init_A_const_24 any

var A_arbace_c_dg__init_A_const_25 *lang.Var

var A_arbace_c_dg__init_A_const_26 any

var A_arbace_c_dg__init_A_const_27 *lang.Var

var A_arbace_c_dg__init_A_const_28 any

var A_arbace_c_dg__init_A_const_29 *lang.Var

var A_arbace_c_dg__init_A_const_30 any

var A_arbace_c_dg__init_A_const_31 any

var A_arbace_c_dg__init_A_const_32 *lang.Var

var A_arbace_c_dg__init_A_const_33 any

var A_arbace_c_dg__init_A_const_34 *lang.Var

var A_arbace_c_dg__init_A_const_35 any

var A_arbace_c_dg__init_A_const_36 *lang.Var

var A_arbace_c_dg__init_A_const_37 any

var A_arbace_c_dg__init_A_const_38 *lang.Var

var A_arbace_c_dg__init_A_const_39 any

var A_arbace_c_dg__init_A_const_40 *lang.Var

var A_arbace_c_dg__init_A_const_41 any

var A_arbace_c_dg__init_A_const_42 *lang.Var

var A_arbace_c_dg__init_A_const_43 any

var A_arbace_c_dg__init_A_const_44 *lang.Var

var A_arbace_c_dg__init_A_const_45 any

var A_arbace_c_dg__init_A_const_46 *lang.Var

var A_arbace_c_dg__init_A_const_47 any

var A_arbace_c_dg__init_A_const_48 *lang.Var

var A_arbace_c_dg__init_A_const_49 any

var A_arbace_c_dg__init_A_const_50 any

var A_arbace_c_dg__init_A_const_51 *lang.Var

var A_arbace_c_dg__init_A_const_52 any

var A_arbace_c_dg__init_A_const_53 *lang.Var

var A_arbace_c_dg__init_A_const_54 any

var A_arbace_c_dg__init_A_const_55 *lang.Var

var A_arbace_c_dg__init_A_const_56 any

var A_arbace_c_dg__init_A_const_57 *lang.Var

var A_arbace_c_dg__init_A_const_58 any

var A_arbace_c_dg__init_A_const_59 *lang.Var

var A_arbace_c_dg__init_A_const_60 any

var A_arbace_c_dg__init_A_const_61 *lang.Var

var A_arbace_c_dg__init_A_const_62 any

var A_arbace_c_dg__init_A_const_63 *lang.Var

var A_arbace_c_dg__init_A_const_64 any

var A_arbace_c_dg__init_A_const_65 *lang.Var

var A_arbace_c_dg__init_A_const_66 any

var A_arbace_c_dg__init_A_const_67 *lang.Var

var A_arbace_c_dg__init_A_const_68 any

var A_arbace_c_dg__init_A_const_69 *lang.Var

var A_arbace_c_dg__init_A_const_70 any

var A_arbace_c_dg__init_A_const_71 *lang.Var

var A_arbace_c_dg__init_A_const_72 any

var A_arbace_c_dg__init_A_const_73 *lang.Var

var A_arbace_c_dg__init_A_const_74 any

var A_arbace_c_dg__init_A_const_75 *lang.Var

var A_arbace_c_dg__init_A_const_76 any

var A_arbace_c_dg__init_A_const_77 *lang.Var

var A_arbace_c_dg__init_A_const_78 any

var A_arbace_c_dg__init_A_const_79 *lang.Var

var A_arbace_c_dg__init_A_const_80 any

var A_arbace_c_dg__init_A_const_81 *lang.Var

var A_arbace_c_dg__init_A_const_82 any

var A_arbace_c_dg__init_A_const_83 *lang.Var

var A_arbace_c_dg__init_A_const_84 any

var A_arbace_c_dg__init_A_const_85 *lang.Var

var A_arbace_c_dg__init_A_const_86 any

var A_arbace_c_dg__init_A_const_87 *lang.Var

var A_arbace_c_dg__init_A_const_88 any

var A_arbace_c_dg__init_A_init jrt.ClassInit

func A_arbace_c_dg__init_A_Init() { if !A_arbace_c_dg__init_A_init.Done() { A_arbace_c_dg__init_A_init.Run(A_arbace_c_dg__init_A_clinit) } }

func A_arbace_c_dg__init_A_clinit() { A_arbace_c_dg__init_A_clinit_p0(); A_arbace_c_dg__init_A_clinit_p1(); A_arbace_c_dg__init_A_clinit_p2(); A_arbace_c_dg__init_A_clinit_p3(); A_arbace_c_dg__init_A_clinit_p4(); A_arbace_c_dg__init_A_clinit_p5(); A_arbace_c_dg__init_A_clinit_p6() }

func A_arbace_c_dg__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_dg__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_280, 141); A_arbace_c_dg__init_A_const_0 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[52]); A_arbace_c_dg__init_A_const_1 = A_arbace_c_dg__init_A_const_pool.A[53]; A_arbace_c_dg__init_A_const_2 = A_arbace_c_dg__init_A_const_pool.A[54]; A_arbace_c_dg__init_A_const_3 = A_arbace_c_dg__init_A_const_pool.A[55]; A_arbace_c_dg__init_A_const_4 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[56]); A_arbace_c_dg__init_A_const_5 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[57]); A_arbace_c_dg__init_A_const_6 = A_arbace_c_dg__init_A_const_pool.A[58]; A_arbace_c_dg__init_A_const_7 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[59]); A_arbace_c_dg__init_A_const_8 = A_arbace_c_dg__init_A_const_pool.A[60]; A_arbace_c_dg__init_A_const_9 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[61]); A_arbace_c_dg__init_A_const_10 = A_arbace_c_dg__init_A_const_pool.A[62]; A_arbace_c_dg__init_A_const_11 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[63]); A_arbace_c_dg__init_A_const_12 = A_arbace_c_dg__init_A_const_pool.A[64] }

func A_arbace_c_dg__init_A_clinit_p1() { A_arbace_c_dg__init_A_const_13 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[65]); A_arbace_c_dg__init_A_const_14 = A_arbace_c_dg__init_A_const_pool.A[66]; A_arbace_c_dg__init_A_const_15 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[67]); A_arbace_c_dg__init_A_const_16 = A_arbace_c_dg__init_A_const_pool.A[68]; A_arbace_c_dg__init_A_const_17 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[69]); A_arbace_c_dg__init_A_const_18 = A_arbace_c_dg__init_A_const_pool.A[70]; A_arbace_c_dg__init_A_const_19 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[71]); A_arbace_c_dg__init_A_const_20 = A_arbace_c_dg__init_A_const_pool.A[72]; A_arbace_c_dg__init_A_const_21 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[73]); A_arbace_c_dg__init_A_const_22 = A_arbace_c_dg__init_A_const_pool.A[74]; A_arbace_c_dg__init_A_const_23 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[75]); A_arbace_c_dg__init_A_const_24 = A_arbace_c_dg__init_A_const_pool.A[76]; A_arbace_c_dg__init_A_const_25 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[77]) }

func A_arbace_c_dg__init_A_clinit_p2() { A_arbace_c_dg__init_A_const_26 = A_arbace_c_dg__init_A_const_pool.A[78]; A_arbace_c_dg__init_A_const_27 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[79]); A_arbace_c_dg__init_A_const_28 = A_arbace_c_dg__init_A_const_pool.A[80]; A_arbace_c_dg__init_A_const_29 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[81]); A_arbace_c_dg__init_A_const_30 = A_arbace_c_dg__init_A_const_pool.A[82]; A_arbace_c_dg__init_A_const_31 = A_arbace_c_dg__init_A_const_pool.A[83]; A_arbace_c_dg__init_A_const_32 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[84]); A_arbace_c_dg__init_A_const_33 = A_arbace_c_dg__init_A_const_pool.A[85]; A_arbace_c_dg__init_A_const_34 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[86]); A_arbace_c_dg__init_A_const_35 = A_arbace_c_dg__init_A_const_pool.A[87]; A_arbace_c_dg__init_A_const_36 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[88]); A_arbace_c_dg__init_A_const_37 = A_arbace_c_dg__init_A_const_pool.A[89]; A_arbace_c_dg__init_A_const_38 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[90]); A_arbace_c_dg__init_A_const_39 = A_arbace_c_dg__init_A_const_pool.A[91] }

func A_arbace_c_dg__init_A_clinit_p3() { A_arbace_c_dg__init_A_const_40 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[92]); A_arbace_c_dg__init_A_const_41 = A_arbace_c_dg__init_A_const_pool.A[93]; A_arbace_c_dg__init_A_const_42 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[94]); A_arbace_c_dg__init_A_const_43 = A_arbace_c_dg__init_A_const_pool.A[95]; A_arbace_c_dg__init_A_const_44 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[96]); A_arbace_c_dg__init_A_const_45 = A_arbace_c_dg__init_A_const_pool.A[97]; A_arbace_c_dg__init_A_const_46 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[98]); A_arbace_c_dg__init_A_const_47 = A_arbace_c_dg__init_A_const_pool.A[99]; A_arbace_c_dg__init_A_const_48 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[100]); A_arbace_c_dg__init_A_const_49 = A_arbace_c_dg__init_A_const_pool.A[101]; A_arbace_c_dg__init_A_const_50 = A_arbace_c_dg__init_A_const_pool.A[102]; A_arbace_c_dg__init_A_const_51 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[103]); A_arbace_c_dg__init_A_const_52 = A_arbace_c_dg__init_A_const_pool.A[104] }

func A_arbace_c_dg__init_A_clinit_p4() { A_arbace_c_dg__init_A_const_53 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[105]); A_arbace_c_dg__init_A_const_54 = A_arbace_c_dg__init_A_const_pool.A[106]; A_arbace_c_dg__init_A_const_55 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[107]); A_arbace_c_dg__init_A_const_56 = A_arbace_c_dg__init_A_const_pool.A[108]; A_arbace_c_dg__init_A_const_57 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[109]); A_arbace_c_dg__init_A_const_58 = A_arbace_c_dg__init_A_const_pool.A[110]; A_arbace_c_dg__init_A_const_59 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[111]); A_arbace_c_dg__init_A_const_60 = A_arbace_c_dg__init_A_const_pool.A[112]; A_arbace_c_dg__init_A_const_61 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[113]); A_arbace_c_dg__init_A_const_62 = A_arbace_c_dg__init_A_const_pool.A[114]; A_arbace_c_dg__init_A_const_63 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[115]); A_arbace_c_dg__init_A_const_64 = A_arbace_c_dg__init_A_const_pool.A[116]; A_arbace_c_dg__init_A_const_65 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[117]) }

func A_arbace_c_dg__init_A_clinit_p5() { A_arbace_c_dg__init_A_const_66 = A_arbace_c_dg__init_A_const_pool.A[118]; A_arbace_c_dg__init_A_const_67 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[119]); A_arbace_c_dg__init_A_const_68 = A_arbace_c_dg__init_A_const_pool.A[120]; A_arbace_c_dg__init_A_const_69 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[121]); A_arbace_c_dg__init_A_const_70 = A_arbace_c_dg__init_A_const_pool.A[122]; A_arbace_c_dg__init_A_const_71 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[123]); A_arbace_c_dg__init_A_const_72 = A_arbace_c_dg__init_A_const_pool.A[124]; A_arbace_c_dg__init_A_const_73 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[125]); A_arbace_c_dg__init_A_const_74 = A_arbace_c_dg__init_A_const_pool.A[126]; A_arbace_c_dg__init_A_const_75 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[127]); A_arbace_c_dg__init_A_const_76 = A_arbace_c_dg__init_A_const_pool.A[128]; A_arbace_c_dg__init_A_const_77 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[129]); A_arbace_c_dg__init_A_const_78 = A_arbace_c_dg__init_A_const_pool.A[130] }

func A_arbace_c_dg__init_A_clinit_p6() { A_arbace_c_dg__init_A_const_79 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[131]); A_arbace_c_dg__init_A_const_80 = A_arbace_c_dg__init_A_const_pool.A[132]; A_arbace_c_dg__init_A_const_81 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[133]); A_arbace_c_dg__init_A_const_82 = A_arbace_c_dg__init_A_const_pool.A[134]; A_arbace_c_dg__init_A_const_83 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[135]); A_arbace_c_dg__init_A_const_84 = A_arbace_c_dg__init_A_const_pool.A[136]; A_arbace_c_dg__init_A_const_85 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[137]); A_arbace_c_dg__init_A_const_86 = A_arbace_c_dg__init_A_const_pool.A[138]; A_arbace_c_dg__init_A_const_87 = lang.Var_Cast(A_arbace_c_dg__init_A_const_pool.A[139]); A_arbace_c_dg__init_A_const_88 = A_arbace_c_dg__init_A_const_pool.A[140] }

func A_arbace_c_dg__init_A_New() *A_arbace_c_dg__init_A { A_arbace_c_dg__init_A_Init(); t := &A_arbace_c_dg__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c_dg__init_A) Ctor() {}

func (t *A_arbace_c_dg__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_dg__init_A) GetClass__Class() *jrt.Class { return A_arbace_c_dg__init_A_class }

func (t *A_arbace_c_dg__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_dg__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_dg__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_dg__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_dg__init_A); return ok }

func A_arbace_c_dg__init_A_Cast(x any) *A_arbace_c_dg__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_dg__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_dg__init_A_class)) }; return v }
