//line j2g_strings.ae:1
package aot_arbace_c_dg

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.repr.ckn2,asyn2,rcyn18,arbace.repr.c.hostyn4,hostyn19,arbace.repr.c.parseyn5,parseyn16,arbace.repr.c.ppyn2,ppyn17,arbace.repr.c.lexyn3,lexyn19,arbace.repr.c.annotyn5,annotyn22,arbace.repr.c.pedanticyn8,pedanticyn13,arbace.stringyn3,strkn3,dockn4,elsekn4,namekn4,linekn5,wordskn7,unknownkn7,applieskn5,xfailkn3,anykn6,actionkn5,unsupkn6,expectkn5,errorkn4,msgskn6,excesskn7,sourceskn8,requireskn5,skipskn5,otherkn11,unsupportedkn7,compilekn2,fckn4,readkn10,preprocesskn6,errorskn8,pedantickn4,basekn5,panickn5,crashkn8,warningskn7,pp-onlykn3,stdkn13,no-c2y-compatkn13,no-c23-compatkn8,deadlinekn7,timeoutkn6,statuskn5,lineskn9,all-textskn5,textskn9,unlocatedkn5,straykn7,messagekn7,refusedkn2,okkn10,read-errorkn12,parse-errorskn7,warningkn4,notekn5,fatalkn11,fatal-otherkn3,yeskn6,differkn4,failkn4,passkn7,stoppedkn4,bothkn6,missedkn5,extrakn8,familieskn12,wrong-reasonkn3,gcckn7,checkerkn5,fileskn3,whykn4,optskn4,argskn11,sel-unknownkn9,uncertainkn14,opts-uncertainkn7,retriedkn3,tagkn6,agreeskn7,missingkn9,no-statuskn7,subjectkn9,referencekn4,leftkn10,not-judgedkn6,passeskn7,differskn2,idkn2,dgkn5,levelkn5,matchv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn11,arbace.c.dgm2,R18,s921,The C23 corpus's dg actions and the read level's error judge (doc/C23-SURVEY.md, \"As built: C7\n  (write-ahead)\"; bin/ci dg, its driver bin/lib/ci/dg): gcc's testsuite files carry DejaGnu directives in\n  comments, `{ dg-do run }`, `{ dg-options \"-std=c23\" }`, `{ dg-error \"re\" \"\" { target c } .-1 }`.\n  `analyze` reads them (Tcl's lists: braces, quotes, backslashes) into a file's action, options and\n  expected diagnostics by line and kind; `read-file` reads and checks a file as bin/ci diagnose does and\n  keeps the checker's errors by line; `gcc-lines` parses gcc 15.2's own diagnostics of the file (made by\n  bin/lib/ci/dg), which validate the directives (the host's gcc is the reference, CS14 (a)); `verdict`\n  judges the checker's errors against the directives: every expected error line has an error of the\n  checker's, and the checker gives none on a line that expects none. Commands: directives, read, gcc, judge.c92,c123,c125,R19,v11,arbace.core4,subsc34,v11,arbace.core3,notv11,arbace.core3,strv11,arbace.c.dg11,read-quotedv11,arbace.c.dg11,scan-bracedV1,l0,c10,v11,arbace.c.dg11,line-startsv11,arbace.core10,re-matcherp20,\\{\\s*dg-([a-z0-9-]+)R20,R21,v11,arbace.c.dg7,line-ofR22,v11,arbace.c.dg9,tcl-wordsv18,arbace.repr.c.host11,target-atomR23,v11,arbace.c.dg15,*unknown-names*v11,arbace.core5,swap!v18,arbace.repr.c.host13,eval-selectorv11,arbace.c.dg8,sel-atomm4,R24,TR25,Fv13,arbace.string4,trimv11,arbace.c.dg13,eval-selectorl5,l6,l0,R24,R25,m4,R24,TR25,Fv11,arbace.core10,re-matchesp3,\\d+R26,p13,\\.([+-])(\\d+)v11,arbace.core1,+v11,arbace.core1,-v11,arbace.c.dg10,directivesv11,arbace.core6,reducev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR27,v11,arbace.c.dg8,sel-infov11,arbace.core5,assocv11,arbace.core7,keywordv11,arbace.core7,re-findp10,^\\s*targetp5,c\\+\\+R28,v11,arbace.core9,contains?v11,arbace.c.dg13,message-kindsv11,arbace.c.dg12,resolve-linev11,arbace.core9,update-inv11,arbace.core4,fnilv11,arbace.core3,incR29,R30,R31,R32,v11,arbace.core6,updateR33,v11,arbace.core4,intov13,arbace.string5,splitp3,\\s+R34,S11,s13,message-kindss18,additional-optionss12,prune-outputs7,requires8,xfail-ifs20,set-compiler-env-vars7,timeouts7,skip-ifs5,finals11,add-optionss7,optionsR35,v11,arbace.core3,vecR36,v11,arbace.core6,dissocR37,R38,v11,arbace.core8,distinctv11,arbace.core10,sorted-mapp28,^(?:(.*?):)?(\\d+):(?:\\d+:)? v17,arbace.repr.c.lex10,read-bytesv13,arbace.string7,replacep8,[\\t\\n\\r]R39,v18,arbace.repr.c.host6,configR40,R41,v16,arbace.repr.c.pp10,preprocessR42,R43,R44,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,concatR45,R46,v11,arbace.core6,filterv13,arbace.string12,starts-with?R47,m2,R48,Tv13,arbace.repr.c6,read-cv11,arbace.core19,pop-thread-bindingsv22,arbace.repr.c.pedantic5,notesR49,R50,R51,R52,v11,arbace.core7,ex-datam2,R53,Tv11,arbace.core8,hash-setv11,arbace.core3,mapv11,arbace.core4,keepv11,arbace.c.dg10,error-lineR54,R55,v11,arbace.core11,frequenciesv11,arbace.core6,secondR56,v11,arbace.c.dg8,one-linev11,arbace.core4,takel8,v11,arbace.core8,group-byv11,arbace.core4,compR57,R58,R59,v11,arbace.core6,removeR60,R53,v11,arbace.core4,someR61,R48,R62,v19,arbace.repr.c.annot9,port-dumpV2,nV1,s14,stack overflowv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv19,arbace.repr.c.parse10,*deadline*v19,arbace.repr.c.parse9,*recover*R63,R64,p57,^(.*?):(\\d+):(?:\\d+:)? (fatal error|error|warning|note): R65,R66,v11,arbace.core4,not=R67,R68,p27,^[^ :][^ :]*: fatal error: p21,^[^ :][^ :]*: error: v13,arbace.string11,split-linesv11,arbace.core3,setv11,arbace.core6,get-inV2,R29,R30,V2,R25,R30,V2,R26,R30,v11,arbace.core4,keysv11,arbace.core6,empty?R69,R70,v11,arbace.c.dg9,syntax-reV2,R26,R30,V3,R71,R46,s11,no read rowS3,R53,R61,R46,V2,R29,R30,V2,R25,R30,v11,arbace.core6,every?v11,arbace.c.dg19,syntax-expectation?v11,arbace.core4,sortV1,R72,v11,arbace.core5,applyv11,arbace.core3,maxR71,R73,v11,arbace.core9,not-emptyv13,arbace.string6,blank?R74,v11,arbace.c.dg6,msg-ofR75,R76,v11,arbace.core6,vectorv11,arbace.core10,re-patternp27,^(?:[^ ]*?:)?\\d+:(?:\\d+:)? v11,arbace.core10,not-every?v11,arbace.core11,read-stringv11,arbace.core5,slurpR77,R78,v11,arbace.c.dg12,load-wordingR79,R80,R81,v11,arbace.c.dg16,family-explains?v11,arbace.c.dg12,msg-mismatchv11,arbace.c.dg20,unexplained-messagesv11,arbace.core4,map?R82,v11,arbace.core6,pr-strv11,arbace.core7,filtervv11,arbace.c.dg7,base-ofv11,arbace.c.dg12,slurp-latin1v18,arbace.repr.c.host15,dg-options-infop3,/+$v11,arbace.core4,atomv11,arbace.c.dg7,analyzeR83,R84,R85,R86,R87,v11,arbace.c.dg7,entriesv11,arbace.core3,valv11,arbace.core7,printlnl10,v11,arbace.core4,spitv13,arbace.string4,joinv11,arbace.core4,nameV2,R29,R30,v11,arbace.core10,sorted-setv11,arbace.core6,mapcatv11,arbace.core4,mapvR88,v18,arbace.repr.c.host9,load-hostv11,arbace.c.dg9,read-filem2,R89,C29,java.util.concurrent.CallableR72,v11,arbace.core4,juxtv11,arbace.core8,identityv11,arbace.c.dg14,retry-timeoutsv11,arbace.c.dg8,esc-namev11,arbace.c.dg9,gcc-linesR90,v11,arbace.c.dg10,gcc-agreesR91,m2,R92,Tm2,R92,TR93,R94,R95,R96,v11,arbace.c.dg7,verdictV1,R72,v11,arbace.c.dg15,message-verdictV1,R72,R97,R98,R99,v11,arbace.c.dg14,control-resultS2,R97,R96,S2,R97,R96,R100,R101,R102,v11,arbace.core4,dropl2,V1,R37,V1,R72,v11,arbace.c.dg8,classifyV1,R37,V1,R72,v11,arbace.c.dg12,control-rowsv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core6,formatp18,[^A-Za-z0-9_ '#-]+p3,\\s+l3,v11,arbace.core7,sort-byv11,arbace.core5,countl12,l40,v11,arbace.core15,shutdown-agentsv11,arbace.c.dg9,judge-cmdv11,arbace.c.dg14,directives-cmdv11,arbace.c.dg7,gcc-cmdv11,arbace.c.dg8,read-cmd")

var Lit_1 *jrt.String = jrt.Intern("directives")

var Lit_2 *jrt.String = jrt.Intern("gcc")

var Lit_3 *jrt.String = jrt.Intern("read")

var Lit_4 *jrt.String = jrt.Intern("judge")

var Lit_5 *jrt.String = jrt.Intern("dg: directives, read, gcc or judge")

var Lit_6 *jrt.String = jrt.Intern("arbace.c.dg$analyze$fn__551000056")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.dg$analyze$fn__551000070")

var Lit_8 *jrt.String = jrt.Intern("arbace.c.dg$analyze$fn__551000072")

var Lit_9 *jrt.String = jrt.Intern("arbace.c.dg$analyze$fn__551000074")

var Lit_10 *jrt.String = jrt.Intern("arbace.c.dg$analyze$fn__551000076")

var Lit_11 *jrt.String = jrt.Intern("arbace.c.dg$analyze$fn__551000078")

var Lit_12 *jrt.String = jrt.Intern("do")

var Lit_13 *jrt.String = jrt.Intern("excess-errors")

var Lit_14 *jrt.String = jrt.Intern("additional-sources")

var Lit_15 *jrt.String = jrt.Intern("require-effective-target")

var Lit_16 *jrt.String = jrt.Intern("skip-if")

var Lit_17 *jrt.String = jrt.Intern("/")

var Lit_18 *jrt.String = jrt.Intern("/base.txt")

var Lit_19 *jrt.String = jrt.Intern(" ")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.dg$classify$fn__551000448")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.dg$classify$fn__551000448$fn__551000449")

var Lit_22 *jrt.String = jrt.Intern("arbace.c.dg$control_result$split__551000404")

var Lit_23 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000408__551000412")

var Lit_24 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000418__551000422")

var Lit_25 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000428__551000432")

var Lit_26 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$fn__551000444")

var Lit_27 *jrt.String = jrt.Intern("test/c/controls.edn")

var Lit_28 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000408__551000412$fn__551000413")

var Lit_29 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000408__551000412$fn__551000413$fn__551000414")

var Lit_30 *jrt.String = jrt.Intern("/dg.edn")

var Lit_31 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000418__551000422$fn__551000423")

var Lit_32 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000418__551000422$fn__551000423$fn__551000424")

var Lit_33 *jrt.String = jrt.Intern("/read.edn")

var Lit_34 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000428__551000432$fn__551000433")

var Lit_35 *jrt.String = jrt.Intern("arbace.c.dg$control_rows$iter__551000428__551000432$fn__551000433$fn__551000434")

var Lit_36 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_37 *jrt.String = jrt.Intern("control ")

var Lit_38 *jrt.String = jrt.Intern(" (test/c/controls.edn)")

var Lit_39 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000291__551000295")

var Lit_40 *jrt.String = jrt.Intern("/gcc.list")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000307__551000311")

var Lit_42 *jrt.String = jrt.Intern("[\n")

var Lit_43 *jrt.String = jrt.Intern("\n]\n")

var Lit_44 *jrt.String = jrt.Intern("\n")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$fn__551000324")

var Lit_46 *jrt.String = jrt.Intern("/subset")

var Lit_47 *jrt.String = jrt.Intern("CI_DG_ONLY")

var Lit_48 *jrt.String = jrt.Intern(": ")

var Lit_49 *jrt.String = jrt.Intern(" files; actions ")

var Lit_50 *jrt.String = jrt.Intern("; with dg-error ")

var Lit_51 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$fn__551000329")

var Lit_52 *jrt.String = jrt.Intern(" names in the dg-do, dg-error and xfail selectors that test/c/dg-targets.edn does not list (taken to hold), in ")

var Lit_53 *jrt.String = jrt.Intern(" files")

var Lit_54 *jrt.String = jrt.Intern(" files keep option lines whose selector test/c/dg-targets.edn cannot decide: ")

var Lit_55 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$fn__551000332")

var Lit_56 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000291__551000295$fn__551000296")

var Lit_57 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000291__551000295$fn__551000296$fn__551000297")

var Lit_58 *jrt.String = jrt.Intern("")

var Lit_59 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000291__551000295$fn__551000296$fn__551000302")

var Lit_60 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000291__551000295$fn__551000296$fn__551000297$fn__551000298")

var Lit_61 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000307__551000311$fn__551000312")

var Lit_62 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd$iter__551000307__551000311$fn__551000312$fn__551000313")

var Lit_63 *jrt.String = jrt.Intern("\t")

var Lit_64 *jrt.String = jrt.Intern("/files.edn")

var Lit_65 *jrt.String = jrt.Intern("arbace.c.dg$entries$fn__551000284")

var Lit_66 *jrt.String = jrt.Intern("arbace.c.dg$entries$fn__551000286")

var Lit_67 *jrt.String = jrt.Intern("#")

var Lit_68 *jrt.String = jrt.Intern("__")

var Lit_69 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_70 *jrt.String = jrt.Intern("java.util.concurrent.Callable")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.dg$family_explains_QMARK_$fn__551000253")

var Lit_72 *jrt.String = jrt.Intern("arbace.c.dg$family_explains_QMARK_$fn__551000255")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.dg$gcc_agrees$fn__551000210")

var Lit_74 *jrt.String = jrt.Intern("/gcc")

var Lit_75 *jrt.String = jrt.Intern("arbace.c.dg$gcc_cmd$iter__551000380__551000384")

var Lit_76 *jrt.String = jrt.Intern("/gcc.edn")

var Lit_77 *jrt.String = jrt.Intern(": gcc ")

var Lit_78 *jrt.String = jrt.Intern(" files; directives agree ")

var Lit_79 *jrt.String = jrt.Intern(", differ ")

var Lit_80 *jrt.String = jrt.Intern("arbace.c.dg$gcc_cmd$fn__551000390")

var Lit_81 *jrt.String = jrt.Intern("arbace.c.dg$gcc_cmd$fn__551000392")

var Lit_82 *jrt.String = jrt.Intern("arbace.c.dg$gcc_cmd$iter__551000380__551000384$fn__551000385")

var Lit_83 *jrt.String = jrt.Intern("arbace.c.dg$gcc_cmd$iter__551000380__551000384$fn__551000385$fn__551000386")

var Lit_84 *jrt.String = jrt.Intern("/gcc/")

var Lit_85 *jrt.String = jrt.Intern(".txt")

var Lit_86 *jrt.String = jrt.Intern(".status")

var Lit_87 *jrt.String = jrt.Intern("arbace.c.dg$gcc_lines$fn__551000202")

var Lit_88 *jrt.String = jrt.Intern("error")

var Lit_89 *jrt.String = jrt.Intern("warning")

var Lit_90 *jrt.String = jrt.Intern("fatal error")

var Lit_91 *jrt.String = jrt.Intern("note")

var Lit_92 *jrt.String = jrt.Intern("--record")

var Lit_93 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000465")

var Lit_94 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000467")

var Lit_95 *jrt.String = jrt.Intern("test/c/check-dg-linux-amd64.edn")

var Lit_96 *jrt.String = jrt.Intern("test/c/dg-known.edn")

var Lit_97 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000469__551000475")

var Lit_98 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$by_id__551000497")

var Lit_99 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000501__551000507")

var Lit_100 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000527")

var Lit_101 *jrt.String = jrt.Intern("%-16s %4d files: pass %d of %d supported%s%s")

var Lit_102 *jrt.String = jrt.Intern(", unsupported ")

var Lit_103 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000530")

var Lit_104 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000535")

var Lit_105 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000538")

var Lit_106 *jrt.String = jrt.Intern("%-16s %4d files: pass %d of %d supported, unsupported %d")

var Lit_107 *jrt.String = jrt.Intern("total")

var Lit_108 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000543__551000549")

var Lit_109 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000565__551000571")

var Lit_110 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000587__551000591")

var Lit_111 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000604")

var Lit_112 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fam__551000609")

var Lit_113 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000611__551000619")

var Lit_114 *jrt.String = jrt.Intern("dg-error messages: %d of %d passes with expected errors have %d lines whose regex matches none of the checker's messages, all explained by test/c/dg-wording.edn's families")

var Lit_115 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000639")

var Lit_116 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000641")

var Lit_117 *jrt.String = jrt.Intern("  wrong-reason files %d, unexplained message files %d")

var Lit_118 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000647")

var Lit_119 *jrt.String = jrt.Intern("  %-16s %3d files")

var Lit_120 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000649")

var Lit_121 *jrt.String = jrt.Intern("  family %-40s %3d lines")

var Lit_122 *jrt.String = jrt.Intern("\"")

var Lit_123 *jrt.String = jrt.Intern("/msg-mismatch.edn")

var Lit_124 *jrt.String = jrt.Intern("passes whose directives gcc does not agree with:")

var Lit_125 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000662")

var Lit_126 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000670")

var Lit_127 *jrt.String = jrt.Intern(";; the read level's error judge over the C23 corpus (bin/ci dg --record): each file, [ID RESULT REASON],\n")

var Lit_128 *jrt.String = jrt.Intern(";; the checker's errors against the dg directives by line and kind; its classes test/c/divergences-dg.edn.\n[\n")

var Lit_129 *jrt.String = jrt.Intern("recorded")

var Lit_130 *jrt.String = jrt.Intern("CI_DG_ESSENTIAL")

var Lit_131 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000676")

var Lit_132 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000683__551000687")

var Lit_133 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000699__551000703")

var Lit_134 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000715")

var Lit_135 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000717")

var Lit_136 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000719")

var Lit_137 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000721")

var Lit_138 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000723")

var Lit_139 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000725")

var Lit_140 *jrt.String = jrt.Intern("of")

var Lit_141 *jrt.String = jrt.Intern("listed files pass")

var Lit_142 *jrt.String = jrt.Intern("recorded files absent from the run")

var Lit_143 *jrt.String = jrt.Intern("FAIL")

var Lit_144 *jrt.String = jrt.Intern("/judge-rows.edn")

var Lit_145 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$by_id__551000497$fn__551000498")

var Lit_146 *jrt.String = jrt.Intern("ci dg judge: --record records whole groups: the run judged was a subset (CI_DG_ONLY)")

var Lit_147 *jrt.String = jrt.Intern(", ")

var Lit_148 *jrt.String = jrt.Intern("wrong-reason")

var Lit_149 *jrt.String = jrt.Intern("message")

var Lit_150 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000662$fn__551000666")

var Lit_151 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$fn__551000676$fn__551000680")

var Lit_152 *jrt.String = jrt.Intern("absent from the run")

var Lit_153 *jrt.String = jrt.Intern("listed, not found in its group")

var Lit_154 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000469__551000475$fn__551000476")

var Lit_155 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000469__551000475$fn__551000476$iter__551000471__551000477")

var Lit_156 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000469__551000475$fn__551000476$iter__551000471__551000477$fn__551000478")

var Lit_157 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000469__551000475$fn__551000476$iter__551000471__551000477$fn__551000478$fn__551000479")

var Lit_158 *jrt.String = jrt.Intern(" (unsupported on this target)")

var Lit_159 *jrt.String = jrt.Intern("known ")

var Lit_160 *jrt.String = jrt.Intern(" (")

var Lit_161 *jrt.String = jrt.Intern(")")

var Lit_162 *jrt.String = jrt.Intern(" [gcc: ")

var Lit_163 *jrt.String = jrt.Intern("]")

var Lit_164 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000501__551000507$fn__551000508")

var Lit_165 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000501__551000507$fn__551000508$iter__551000503__551000509")

var Lit_166 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000501__551000507$fn__551000508$iter__551000503__551000509$fn__551000510")

var Lit_167 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000501__551000507$fn__551000508$iter__551000503__551000509$fn__551000510$fn__551000511")

var Lit_168 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000543__551000549$fn__551000550")

var Lit_169 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000543__551000549$fn__551000550$iter__551000545__551000551")

var Lit_170 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000543__551000549$fn__551000550$iter__551000545__551000551$fn__551000552")

var Lit_171 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000543__551000549$fn__551000550$iter__551000545__551000551$fn__551000552$fn__551000553")

var Lit_172 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000565__551000571$fn__551000572")

var Lit_173 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000565__551000571$fn__551000572$iter__551000567__551000573")

var Lit_174 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000565__551000571$fn__551000572$iter__551000567__551000573$fn__551000574")

var Lit_175 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000565__551000571$fn__551000572$iter__551000567__551000573$fn__551000574$fn__551000575")

var Lit_176 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000587__551000591$fn__551000592")

var Lit_177 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000587__551000591$fn__551000592$fn__551000593")

var Lit_178 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000611__551000619$fn__551000620")

var Lit_179 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000611__551000619$fn__551000620$iter__551000613__551000624")

var Lit_180 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000611__551000619$fn__551000620$iter__551000613__551000624$fn__551000625")

var Lit_181 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000611__551000619$fn__551000620$iter__551000613__551000624$fn__551000625$iter__551000615__551000629")

var Lit_182 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000611__551000619$fn__551000620$iter__551000613__551000624$fn__551000625$iter__551000615__551000629$fn__551000630")

var Lit_183 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000611__551000619$fn__551000620$iter__551000613__551000624$fn__551000625$iter__551000615__551000629$fn__551000630$fn__551000631")

var Lit_184 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000683__551000687$fn__551000688")

var Lit_185 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000683__551000687$fn__551000688$fn__551000689")

var Lit_186 *jrt.String = jrt.Intern("regression: recorded ")

var Lit_187 *jrt.String = jrt.Intern(", now ")

var Lit_188 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000699__551000703$fn__551000704")

var Lit_189 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd$iter__551000699__551000703$fn__551000704$fn__551000705")

var Lit_190 *jrt.String = jrt.Intern("test/c/dg-wording.edn")

var Lit_191 *jrt.String = jrt.Intern("arbace.c.dg$message_verdict$fn__551000270")

var Lit_192 *jrt.String = jrt.Intern("s")

var Lit_193 *jrt.String = jrt.Intern("arbace.c.dg$message_verdict$fn__551000270$fn__551000274")

var Lit_194 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch$iter__551000223__551000227")

var Lit_195 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch$iter__551000223__551000227$fn__551000228")

var Lit_196 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch$iter__551000223__551000227$fn__551000228$fn__551000229")

var Lit_197 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch$iter__551000223__551000227$fn__551000228$hit_QMARK___551000243")

var Lit_198 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch$iter__551000223__551000227$fn__551000228$fn__551000229$hit_QMARK___551000234")

var Lit_199 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch$iter__551000223__551000227$fn__551000228$fn__551000229$hit_QMARK___551000234$fn__551000235")

var Lit_200 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch$iter__551000223__551000227$fn__551000228$hit_QMARK___551000243$fn__551000244")

var Lit_201 *jrt.String = jrt.Intern(" expecting: ")

var Lit_202 *jrt.String = jrt.Intern("test/c/host")

var Lit_203 *jrt.String = jrt.Intern("REPR_C_THREADS")

var Lit_204 *jrt.String = jrt.Intern("3")

var Lit_205 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$fn__551000349")

var Lit_206 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$fn__551000355")

var Lit_207 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$iter__551000357__551000361")

var Lit_208 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$fn__551000373")

var Lit_209 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$fn__551000375")

var Lit_210 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$fn__551000349$fn__551000350")

var Lit_211 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$fn__551000349$fn__551000350$fn__551000351")

var Lit_212 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$iter__551000357__551000361$fn__551000362")

var Lit_213 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd$iter__551000357__551000361$fn__551000362$fn__551000363")

var Lit_214 *jrt.String = jrt.Intern("REPR_C_READ_BUDGET")

var Lit_215 *jrt.String = jrt.Intern("120")

var Lit_216 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000093")

var Lit_217 *jrt.String = jrt.Intern("arbace.c.dg$read_file$main_file_QMARK___551000113")

var Lit_218 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115")

var Lit_219 *jrt.String = jrt.Intern("the evaluated read's budget spent")

var Lit_220 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000192")

var Lit_221 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000194")

var Lit_222 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000199")

var Lit_223 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000093$iter__551000094__551000098")

var Lit_224 *jrt.String = jrt.Intern("the preprocessor stopped: ")

var Lit_225 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000093$fn__551000110")

var Lit_226 *jrt.String = jrt.Intern("panic")

var Lit_227 *jrt.String = jrt.Intern("panic:")

var Lit_228 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000093$iter__551000094__551000098$fn__551000099")

var Lit_229 *jrt.String = jrt.Intern("arbace.c.dg$read_file$fn__551000093$iter__551000094__551000098$fn__551000099$fn__551000100")

var Lit_230 *jrt.String = jrt.Intern("concatenation")

var Lit_231 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$fn__551000116")

var Lit_232 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$fn__551000119")

var Lit_233 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128")

var Lit_234 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$fn__551000160")

var Lit_235 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000165__551000169")

var Lit_236 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$fn__551000181")

var Lit_237 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$fn__551000186")

var Lit_238 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129")

var Lit_239 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129$fn__551000130")

var Lit_240 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129$iter__551000148__551000152")

var Lit_241 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129$fn__551000130$iter__551000134__551000138")

var Lit_242 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129$fn__551000130$iter__551000134__551000138$fn__551000139")

var Lit_243 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129$fn__551000130$iter__551000134__551000138$fn__551000139$fn__551000140")

var Lit_244 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129$iter__551000148__551000152$fn__551000153")

var Lit_245 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000124__551000128$fn__551000129$iter__551000148__551000152$fn__551000153$fn__551000154")

var Lit_246 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000165__551000169$fn__551000170")

var Lit_247 *jrt.String = jrt.Intern("arbace.c.dg$read_file$tally__551000115$iter__551000165__551000169$fn__551000170$fn__551000171")

var Lit_248 *jrt.String = jrt.Intern(".")

var Lit_249 *jrt.String = jrt.Intern("+")

var Lit_250 *jrt.String = jrt.Intern("arbace.c.dg$retry_timeouts$fn__551000339")

var Lit_251 *jrt.String = jrt.Intern("arbace.c.dg$retry_timeouts$fn__551000339$fn__551000343")

var Lit_252 *jrt.String = jrt.Intern("dg: ")

var Lit_253 *jrt.String = jrt.Intern(" spent its read's budget; read again alone: ")

var Lit_254 *jrt.String = jrt.Intern("xfail")

var Lit_255 *jrt.String = jrt.Intern("target")

var Lit_256 *jrt.String = jrt.Intern("ISO-8859-1")

var Lit_257 *jrt.String = jrt.Intern("arbace.c.dg$tcl_words$fn__551000026")

var Lit_258 *jrt.String = jrt.Intern("arbace.c.dg$tcl_words$fn__551000034")

var Lit_259 *jrt.String = jrt.Intern("arbace.c.dg$unexplained_messages$fn__551000260")

var Lit_260 *jrt.String = jrt.Intern("arbace.c.dg$unexplained_messages$fn__551000260$fn__551000264")

var Lit_261 *jrt.String = jrt.Intern(" error")

var Lit_262 *jrt.String = jrt.Intern(" not located in the main file: ")

var Lit_263 *jrt.String = jrt.Intern("the read failed")

var Lit_264 *jrt.String = jrt.Intern(" with no message")

var Lit_265 *jrt.String = jrt.Intern("arbace.c.dg$verdict$fn__551000218")

var Lit_266 *jrt.String = jrt.Intern("missed ")

var Lit_267 *jrt.String = jrt.Intern(" extra ")

var Lit_268 *jrt.String = jrt.Intern("arbace.c.dg$verdict$fn__551000220")

var Lit_269 *jrt.String = jrt.Intern(" after the read's last error at ")

var Lit_270 *jrt.String = jrt.Intern(" (read errors ")

var Lit_271 *jrt.String = jrt.Intern(", the checker not run)")

var Lit_272 *jrt.String = jrt.Intern("extra ")

var Lit_273 *jrt.String = jrt.Intern(" got: ")

var Lit_274 *jrt.String = jrt.Intern("no error ")

var Lit_275 *jrt.String = jrt.Intern("(dg-excess-errors)")

var Lit_276 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringyn1,ikn4,linekn6,columnkn4,fileyn6,startskn7,dynamicyn3,selyn4,specyn2,dlkn5,errorkn7,warningkn4,notekn5,bogusyn16,java.lang.Stringyn1,xyn1,hyn1,eyn6,actionyn2,dgyn3,gccyn6,missedyn1,ryn3,famyn3,fidyn3,resyn5,textsyn7,wordingyn4,workyn2,idyn2,rsyn7,passed?yn6,rereadyn3,dgsyn3,rdskn4,keysyn7,subjectyn9,referenceyn3,idsyn7,classesyn3,rowyn12,classes-fileyn1,&yn4,argsyn4,verbv11,arbace.core5,in-nsMyn11,arbace.c.dgm2,R0,s921,The C23 corpus's dg actions and the read level's error judge (doc/C23-SURVEY.md, \"As built: C7\n  (write-ahead)\"; bin/ci dg, its driver bin/lib/ci/dg): gcc's testsuite files carry DejaGnu directives in\n  comments, `{ dg-do run }`, `{ dg-options \"-std=c23\" }`, `{ dg-error \"re\" \"\" { target c } .-1 }`.\n  `analyze` reads them (Tcl's lists: braces, quotes, backslashes) into a file's action, options and\n  expected diagnostics by line and kind; `read-file` reads and checks a file as bin/ci diagnose does and\n  keeps the checker's errors by line; `gcc-lines` parses gcc 15.2's own diagnostics of the file (made by\n  bin/lib/ci/dg), which validate the directives (the host's gcc is the reference, CS14 (a)); `verdict`\n  judges the checker's errors against the directives: every expected error line has an error of the\n  checker's, and the checker gives none on a line that expects none. Commands: directives, read, gcc, judge.m2,R0,s921,The C23 corpus's dg actions and the read level's error judge (doc/C23-SURVEY.md, \"As built: C7\n  (write-ahead)\"; bin/ci dg, its driver bin/lib/ci/dg): gcc's testsuite files carry DejaGnu directives in\n  comments, `{ dg-do run }`, `{ dg-options \"-std=c23\" }`, `{ dg-error \"re\" \"\" { target c } .-1 }`.\n  `analyze` reads them (Tcl's lists: braces, quotes, backslashes) into a file's action, options and\n  expected diagnostics by line and kind; `read-file` reads and checks a file as bin/ci diagnose does and\n  keeps the checker's errors by line; `gcc-lines` parses gcc 15.2's own diagnostics of the file (made by\n  bin/lib/ci/dg), which validate the directives (the host's gcc is the reference, CS14 (a)); `verdict`\n  judges the checker's errors against the directives: every expected error line has an error of the\n  checker's, and the checker gives none on a line that expects none. Commands: directives, read, gcc, judge.R1,v11,arbace.core20,*warn-on-reflection*v11,arbace.c.dg11,scan-bracedm12,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s122,From index `i` (just after an opening brace) to its matching brace: [content index-after], nil when\n  the text ends first.R7,i26,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg11,read-quotedm12,R2,TR3,L1,V2,Myn1,sm2,R4,R5,R6,R0,s214,The quoted word starting at index `i` (the quote): [text index-after]. As Tcl reads it, a backslash before a\n  character that is no letter or digit is dropped (`\\\\\\(` is `\\(`, the regex's escaped paren; CS193 (a)).R7,i41,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg9,tcl-wordsm10,R3,L1,V1,Myn1,sm2,R4,R5,R0,s138,The words of a Tcl list: bare words, \"quoted\" (a backslash before a quote, brace or backslash\n  dropped) and {braced} (taken as they are).R7,i54,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg11,line-startsm10,R2,TR3,L1,V1,Myn4,textm2,R4,R5,R7,i77,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg7,line-ofm12,R2,TR3,L1,V2,R10,R6,R0,s52,The 1-based line of index `i` given the line starts.R7,i83,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg10,directivesm10,R3,L1,V1,Myn4,textm2,R4,R5,R0,s100,Every `{ dg-NAME ... }` of a file: [{:name \"error\" :line L :words [...]}], the words after the name.R7,i92,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg15,*unknown-names*m10,R11,TR7,i109,R8,i1,R9,s14,arbace/c/dg.aeR0,s151,CS210 (b): an atom of the names the table does not list that this selector evaluation took to hold (bound by directives-cmd\n  per file; nil elsewhere).v11,arbace.c.dg8,sel-atomm10,R2,TR3,L1,V1,Myn1,wm2,R4,R5,R7,i114,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg13,eval-selectorm10,R3,L1,V1,Myn4,bodym2,R4,R5,R0,s139,A selector expression of DejaGnu's target lists on the reference host (test/c/dg-targets.edn): host/eval-selector with\n  sel-atom's values.R7,i120,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg8,sel-infom10,R3,L1,V1,R12,R0,s213,A selector word (`target c`, `xfail *-*-*`, ...): {:applies bool :xfail bool}. A target selector is evaluated on the\n  reference host (`eval-selector`, test/c/dg-targets.edn, the C++ names false); the others hold.R7,i126,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg12,resolve-linem10,R2,TR3,L1,V2,R13,R14,R7,i141,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg13,message-kindsm10,s5,errorR15,s7,warningR16,s7,messageR17,s4,noteR17,s5,bogusR18,m6,R7,i149,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg7,analyzem10,R3,L1,V1,Myn4,textm2,R4,R5,R0,s328,A file's dg data: {:action (:run :compile :link :assemble :preprocess), :expect {kind [line ...]},\n  :xfail {kind [line ...]}, :any {kind n} (a line of 0), :excess bool, :sources [names], :requires [...],\n  :skips [...], :other [directive names]}. `dg-do` takes the first whose selector applies; the default\n  action is compile.R7,i151,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg10,error-linem10,R3,L1,V1,Myn1,em2,R4,R5,R0,s136,[file-or-nil line] of a diagnostic's text (`LINE: msg` of the checker's, `LINE:COL: msg` or `FILE:LINE:COL: msg`), nil when it has none.R7,i202,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg12,slurp-latin1m10,R2,TR3,L1,MV1,Myn4,pathm2,R4,R5,m2,R4,R19,R7,i208,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg8,one-linem10,R2,TR3,L1,MV1,R20,m2,R4,R19,R7,i210,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg9,read-filem10,R3,L1,V4,R21,Myn4,basem2,R4,R5,R22,R23,R0,s247,A corpus entry (ppcheck's files.edn) read and checked, as bin/ci diagnose does: {:status (:ok, :read-error,\n  :refused, :timeout, :crash), :lines {line n} (the main file's errors by line), :other n (errors of\n  other files), :message first-error}.R7,i212,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg9,gcc-linesm10,R3,L1,V2,Myn3,outm2,R4,R5,Myn9,base-namem2,R4,R5,R0,s352,gcc's diagnostics (-fdiagnostics-plain-output) of a file as {:error {line n} :warning {line n} :note {line n}},\n  the lines of `base-name` alone, and :other (errors of other files), :fatal (any fatal error), :fatal-other (the fatal errors\n  not at a line of `base-name`: another file's, or `cc1: fatal error: ...` with no line; review 031's finding C).R7,i286,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg10,gcc-agreesm10,R3,L1,V2,R24,R25,R0,s195,Whether the directives' errors are gcc's own errors: :yes, or the way they differ (:missing lines gcc\n  did not give, :extra lines gcc gave that no directive expects), as [:differ missing extra].R7,i312,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg6,msg-ofm10,R2,TR3,L1,V2,R24,R26,R7,i333,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg9,syntax-rep373,expected|before|stray|unterminated|missing terminating|universal character|not valid in an identifier|invalid suffix|invalid digit|empty character constant|character constant|digit separator|#error|#warning|#embed|__VA_OPT__|pasting|parenthes|No such file|exponent has no digits|too many decimal points|UCS codespace|preprocessing|macro|directive|__has_|#if|#elif|missing 'm8,R2,TR7,i336,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg19,syntax-expectation?m10,R3,L1,V1,Myn2,rem2,R4,R5,R0,s156,Whether a dg-error's message expects a syntax, lexical or preprocessor diagnostic, one a read error (the reader's,\n  before the checker runs) can stand for.R7,i339,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg7,verdictm10,R3,L1,V2,R24,R27,R0,s636,The checker's read judged against the file's directives: [:pass], or [:fail kind detail] with kind one\n  of :refused :timeout :crash (the read gave no judgment; also a missing read row and a preprocessor's panic),\n  :missed (an expected error line without one of the checker's), :extra (an error on a line that expects none),\n  :both, :stopped (the read gave errors the directives cannot account for: errors not located in the main\n  file, with no line-0 directive or dg-excess-errors to take them; a read that failed with no message; or a\n  read error that ends the file before its later expected lines: the missed lines are after it).R7,i345,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg12,msg-mismatchm10,R3,L1,V2,R24,R27,R0,s466,CS193 (a): for a file that passes, its expected error lines whose dg-error regexes match none of the checker's\n  messages on that line: a vector of [line [regex...] [message...]]. A report, not a verdict: the checker's wordings\n  differ from gcc's. A file whose read failed is compared too (review 031's finding B): the lines its read errors stand for\n  against the read error's text (a syntax message), so a read error cannot stand for a semantic message unnoticed.R7,i398,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg12,load-wordingm10,R3,L2,V0,V1,Myn4,pathm2,R4,R5,R0,s99,test/c/dg-wording.edn (or `path`): {:families [...] :wrong-reason {FID reason}}; empty when absent.R7,i416,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg16,family-explains?m12,R2,TR3,L1,V4,R28,R29,R30,R31,R0,s224,Whether family `fam` explains a line of the file `fid`: the file is one of its :files (every family names them since CS238 (a)),\n  one of its regexes `res` matches the family's :gcc, one of the messages `texts` its :checker.R7,i423,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg20,unexplained-messagesm10,R3,L2,V3,R32,R24,R27,V4,R32,R29,R24,R27,R0,s114,msg-mismatch's lines that no family of `wording` explains in the file `fid`: [[line [regex...] [message...]] ...].R7,i431,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg15,message-verdictm10,R3,L1,V4,R32,R29,R24,R27,R0,s465,For a file whose lines the checker has right: nil when its dg-error regexes match the checker's messages (or a family of\n  `wording` explains the difference), else [:wrong-reason reason] for a file the table lists as wrong-reason (the right line,\n  another reason than gcc's), else [:message detail]. A wrong-reason entry may be {:lines [...] :why REASON} (review 031's\n  finding E): an unexplained line outside its lines is a [:message ...] failure as in any file.R7,i437,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg8,esc-namem10,R2,TR3,L1,MV1,Myn1,nm2,R4,R5,m2,R4,R19,R7,i463,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg7,entriesm12,R2,TR3,L1,V2,R33,R34,R0,s170,The files of a group (ppcheck's files.edn); with CI_DG_ONLY, a list file of `GROUP/NAME` ids (blank lines and # lines\n  apart), only those (bin/ci dg --essential, CS146).R7,i465,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg7,base-ofm10,R2,TR3,L1,V2,R33,R34,R7,i475,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg14,directives-cmdm8,R3,L1,V2,R33,R34,R7,i477,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg14,retry-timeoutsm10,R3,L1,V3,R35,R36,R37,R0,s268,The quiet retry (review 027, finding 6; goi's and java-check's): each read of `rs` ([name result]) that spent its budget,\n  of a file `passed?` (the committed record passes it), read again alone, once, by `reread` (name -> result); that read\n  stands, marked :retried.R7,i507,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg8,read-cmdm8,R3,L1,V2,R33,R34,R7,i520,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg7,gcc-cmdm8,R3,L1,V2,R33,R34,R7,i542,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg14,control-resultm10,R3,L1,V4,R32,R38,R39,m2,R40,V2,R41,R42,R0,s341,A :dg control judged: :differs, :passes (the judge passes what differs), :not-judged (a file of a group the run judged\n  is not in it: no directives or no read row of the reference), :left (the subject's or the reference's group not judged,\n  or the subject not read: its own row says so). dgs and rds: GROUP -> its dg.edn and read.edn maps.R7,i566,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg12,control-rowsm12,R2,TR3,L1,V3,R33,R43,R32,R0,s75,Each :dg control's result printed; the failing ones as rows [ID :fail WHY].R7,i583,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg8,classifym10,R2,TR3,L1,V2,R44,R45,R7,i598,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg9,judge-cmdm10,R3,L1,V4,R33,R46,R47,R48,R0,s81,judge WORK CLASSES [--record FILE] ID...: each file's row [ID RESULT REASON] ... R7,i602,R8,i1,R9,s14,arbace/c/dg.aev11,arbace.c.dg5,-mainm8,R3,L1,V3,R49,R47,R48,R7,i732,R8,i1,R9,s14,arbace/c/dg.ae")

var Lit_277 *jrt.String = jrt.Intern("arbace.c.dg$eval551000004$loading__1927001464__auto____551000005")

var Lit_278 *jrt.String = jrt.Intern("arbace.c.dg$eval551000008$fn__551000009")

var Lit_279 *jrt.String = jrt.Intern("arbace.c.dg$scan_braced")

var Lit_280 *jrt.String = jrt.Intern("arbace.c.dg$read_quoted")

var Lit_281 *jrt.String = jrt.Intern("arbace.c.dg$tcl_words")

var Lit_282 *jrt.String = jrt.Intern("arbace.c.dg$line_starts")

var Lit_283 *jrt.String = jrt.Intern("arbace.c.dg$line_of")

var Lit_284 *jrt.String = jrt.Intern("arbace.c.dg$directives")

var Lit_285 *jrt.String = jrt.Intern("arbace.c.dg$sel_atom")

var Lit_286 *jrt.String = jrt.Intern("arbace.c.dg$eval_selector")

var Lit_287 *jrt.String = jrt.Intern("arbace.c.dg$sel_info")

var Lit_288 *jrt.String = jrt.Intern("arbace.c.dg$resolve_line")

var Lit_289 *jrt.String = jrt.Intern("arbace.c.dg$analyze")

var Lit_290 *jrt.String = jrt.Intern("arbace.c.dg$error_line")

var Lit_291 *jrt.String = jrt.Intern("arbace.c.dg$slurp_latin1")

var Lit_292 *jrt.String = jrt.Intern("arbace.c.dg$one_line")

var Lit_293 *jrt.String = jrt.Intern("arbace.c.dg$read_file")

var Lit_294 *jrt.String = jrt.Intern("arbace.c.dg$gcc_lines")

var Lit_295 *jrt.String = jrt.Intern("arbace.c.dg$gcc_agrees")

var Lit_296 *jrt.String = jrt.Intern("arbace.c.dg$msg_of")

var Lit_297 *jrt.String = jrt.Intern("arbace.c.dg$syntax_expectation_QMARK_")

var Lit_298 *jrt.String = jrt.Intern("arbace.c.dg$verdict")

var Lit_299 *jrt.String = jrt.Intern("arbace.c.dg$msg_mismatch")

var Lit_300 *jrt.String = jrt.Intern("arbace.c.dg$load_wording")

var Lit_301 *jrt.String = jrt.Intern("arbace.c.dg$family_explains_QMARK_")

var Lit_302 *jrt.String = jrt.Intern("arbace.c.dg$unexplained_messages")

var Lit_303 *jrt.String = jrt.Intern("arbace.c.dg$message_verdict")

var Lit_304 *jrt.String = jrt.Intern("arbace.c.dg$esc_name")

var Lit_305 *jrt.String = jrt.Intern("arbace.c.dg$entries")

var Lit_306 *jrt.String = jrt.Intern("arbace.c.dg$base_of")

var Lit_307 *jrt.String = jrt.Intern("arbace.c.dg$directives_cmd")

var Lit_308 *jrt.String = jrt.Intern("arbace.c.dg$retry_timeouts")

var Lit_309 *jrt.String = jrt.Intern("arbace.c.dg$read_cmd")

var Lit_310 *jrt.String = jrt.Intern("arbace.c.dg$gcc_cmd")

var Lit_311 *jrt.String = jrt.Intern("arbace.c.dg$control_result")

var Lit_312 *jrt.String = jrt.Intern("arbace.c.dg$control_rows")

var Lit_313 *jrt.String = jrt.Intern("arbace.c.dg$classify")

var Lit_314 *jrt.String = jrt.Intern("arbace.c.dg$judge_cmd")

var Lit_315 *jrt.String = jrt.Intern("arbace.c.dg$_main")
