//line j2g_classes.ae:1
package aot_arbace_test_tap

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_class, Name: "arbace.test.tap$eval1888000004$loading__1927001464__auto____1888000005", Modifiers: 25, Simple: "loading__1927001464__auto____1888000005", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_eval1888000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_eval1888000008_fn__1888000009_A_class, Name: "arbace.test.tap$eval1888000008$fn__1888000009", Modifiers: 25, Simple: "fn__1888000009", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000008_fn__1888000009_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_eval1888000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_eval1888000022_fn__1888000023_A_class, Name: "arbace.test.tap$eval1888000022$fn__1888000023", Modifiers: 25, Simple: "fn__1888000023", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000022_fn__1888000023_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_eval1888000022_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_eval1888000029_fn__1888000030_A_class, Name: "arbace.test.tap$eval1888000029$fn__1888000030", Modifiers: 25, Simple: "fn__1888000030", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000029_fn__1888000030_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_eval1888000029_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_eval1888000033_fn__1888000034_A_class, Name: "arbace.test.tap$eval1888000033$fn__1888000034", Modifiers: 25, Simple: "fn__1888000034", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000033_fn__1888000034_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_eval1888000033_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_eval1888000037_fn__1888000038_A_class, Name: "arbace.test.tap$eval1888000037$fn__1888000038", Modifiers: 25, Simple: "fn__1888000038", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000037_fn__1888000038_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_eval1888000037_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_eval1888000041_fn__1888000042_A_class, Name: "arbace.test.tap$eval1888000041$fn__1888000042", Modifiers: 25, Simple: "fn__1888000042", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000041_fn__1888000042_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_eval1888000041_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_print_diagnostics_A_class, Name: "arbace.test.tap$print_diagnostics", Modifiers: 25, Simple: "print_diagnostics", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_diagnostics_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_print_diagnostics_fn__1888000026_A_class, Name: "arbace.test.tap$print_diagnostics$fn__1888000026", Modifiers: 25, Simple: "fn__1888000026", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_diagnostics_fn__1888000026_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_print_diagnostics_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_print_tap_diagnostic_A_class, Name: "arbace.test.tap$print_tap_diagnostic", Modifiers: 25, Simple: "print_tap_diagnostic", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_diagnostic_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_print_tap_fail_A_class, Name: "arbace.test.tap$print_tap_fail", Modifiers: 25, Simple: "print_tap_fail", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_fail_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_print_tap_pass_A_class, Name: "arbace.test.tap$print_tap_pass", Modifiers: 25, Simple: "print_tap_pass", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_pass_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_print_tap_plan_A_class, Name: "arbace.test.tap$print_tap_plan", Modifiers: 25, Simple: "print_tap_plan", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_plan_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_tap_with_tap_output_A_class, Name: "arbace.test.tap$with_tap_output", Modifiers: 25, Simple: "with_tap_output", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_with_tap_output_A", Source: "tap.ae", Declaring: &A_arbace_test_tap_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_test_tap_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_A_New()}; return nil }

var A_arbace_test_tap_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_A_new}

var A_arbace_test_tap_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_A"})

func init() { i := A_arbace_test_tap_A_class.Info(); i.IsInstance = A_arbace_test_tap_A_InstanceOf; i.Init = A_arbace_test_tap_A_Init; i.Table = A_arbace_test_tap_A_members }

func A_arbace_test_tap_eval1888000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000004_A_New()}; return nil }

var A_arbace_test_tap_eval1888000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000004_A_new}

var A_arbace_test_tap_eval1888000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000004", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000004_A"})

func init() { i := A_arbace_test_tap_eval1888000004_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000004_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000004_A_members }

var A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_class *jrt.Class

func A_arbace_test_tap_eval1888000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000008_A_New()}; return nil }

var A_arbace_test_tap_eval1888000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000008_A_new}

var A_arbace_test_tap_eval1888000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000008", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000008_A"})

func init() { i := A_arbace_test_tap_eval1888000008_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000008_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000008_A_members }

var A_arbace_test_tap_eval1888000008_fn__1888000009_A_class *jrt.Class

func A_arbace_test_tap_eval1888000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000022_A_New()}; return nil }

var A_arbace_test_tap_eval1888000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000022_A_new}

var A_arbace_test_tap_eval1888000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000022", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000022_A"})

func init() { i := A_arbace_test_tap_eval1888000022_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000022_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000022_A_members }

var A_arbace_test_tap_eval1888000022_fn__1888000023_A_class *jrt.Class

func A_arbace_test_tap_eval1888000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000029_A_New()}; return nil }

var A_arbace_test_tap_eval1888000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000029_A_new}

var A_arbace_test_tap_eval1888000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000029", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000029_A"})

func init() { i := A_arbace_test_tap_eval1888000029_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000029_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000029_A_members }

var A_arbace_test_tap_eval1888000029_fn__1888000030_A_class *jrt.Class

func A_arbace_test_tap_eval1888000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000033_A_New()}; return nil }

var A_arbace_test_tap_eval1888000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000033_A_new}

var A_arbace_test_tap_eval1888000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000033", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000033_A"})

func init() { i := A_arbace_test_tap_eval1888000033_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000033_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000033_A_members }

var A_arbace_test_tap_eval1888000033_fn__1888000034_A_class *jrt.Class

func A_arbace_test_tap_eval1888000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000037_A_New()}; return nil }

var A_arbace_test_tap_eval1888000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000037_A_new}

var A_arbace_test_tap_eval1888000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000037", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000037_A"})

func init() { i := A_arbace_test_tap_eval1888000037_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000037_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000037_A_members }

var A_arbace_test_tap_eval1888000037_fn__1888000038_A_class *jrt.Class

func A_arbace_test_tap_eval1888000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000041_A_New()}; return nil }

var A_arbace_test_tap_eval1888000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000041_A_new}

var A_arbace_test_tap_eval1888000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000041", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000041_A"})

func init() { i := A_arbace_test_tap_eval1888000041_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000041_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000041_A_members }

var A_arbace_test_tap_eval1888000041_fn__1888000042_A_class *jrt.Class

var A_arbace_test_tap_print_diagnostics_A_class *jrt.Class

var A_arbace_test_tap_print_diagnostics_fn__1888000026_A_class *jrt.Class

var A_arbace_test_tap_print_tap_diagnostic_A_class *jrt.Class

var A_arbace_test_tap_print_tap_fail_A_class *jrt.Class

var A_arbace_test_tap_print_tap_pass_A_class *jrt.Class

var A_arbace_test_tap_print_tap_plan_A_class *jrt.Class

var A_arbace_test_tap_with_tap_output_A_class *jrt.Class

func A_arbace_test_tap__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_test_tap__init_A_Load__O()}; return nil }

func A_arbace_test_tap__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap__init_A_New()}; return nil }

var A_arbace_test_tap__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_test_tap__init_A_invoke, New: A_arbace_test_tap__init_A_new}

var A_arbace_test_tap__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap__init_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap__init_A_class.Info(); i.IsInstance = A_arbace_test_tap__init_A_InstanceOf; i.Init = A_arbace_test_tap__init_A_Init; i.Table = A_arbace_test_tap__init_A_members }
