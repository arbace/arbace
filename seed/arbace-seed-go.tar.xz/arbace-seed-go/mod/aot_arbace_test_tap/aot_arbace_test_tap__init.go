//line aot_arbace_test_tap__init.ae:1
package aot_arbace_test_tap

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_test_tap__init_A_Load__O() any { A_arbace_test_tap__init_A_Init(); A_arbace_test_tap__init_A_Unit0__O(); A_arbace_test_tap__init_A_Unit1__O(); A_arbace_test_tap__init_A_Unit2__O(); A_arbace_test_tap__init_A_Unit3__O(); A_arbace_test_tap__init_A_Unit4__O(); A_arbace_test_tap__init_A_Unit5__O(); A_arbace_test_tap__init_A_Unit6__O(); A_arbace_test_tap__init_A_Unit7__O(); A_arbace_test_tap__init_A_Unit8__O(); A_arbace_test_tap__init_A_Unit9__O(); A_arbace_test_tap__init_A_Unit10__O(); A_arbace_test_tap__init_A_Unit11__O(); A_arbace_test_tap__init_A_Unit12__O(); A_arbace_test_tap__init_A_Unit13__O(); A_arbace_test_tap__init_A_Unit14__O(); A_arbace_test_tap__init_A_Unit15__O(); A_arbace_test_tap__init_A_Unit16__O(); A_arbace_test_tap__init_A_Unit17__O(); return nil }














func A_arbace_test_tap__init_A_Unit0__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); return lang.IFn_Cast(jrt.NN(A_arbace_test_tap__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap__init_A_const_1) }
//line :20:1
func A_arbace_test_tap__init_A_Unit1__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_test_tap__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_2)) }
//line :20:1
func A_arbace_test_tap__init_A_Unit2__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 any = A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_New(); var tmp2 *jrt.Class; A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_Init(); tmp2 = A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :20:1
func A_arbace_test_tap__init_A_Unit3__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_test_tap__init_A_const_1)).Equals_O__Z(A_arbace_test_tap__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_test_tap_eval1888000008_fn__1888000009_A_New(); var tmp2 *jrt.Class; A_arbace_test_tap_eval1888000008_fn__1888000009_A_Init(); tmp2 = A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





















func A_arbace_test_tap__init_A_Unit4__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_4; var tmp2 any = A_arbace_test_tap_print_tap_plan_A_New(); var tmp3 *jrt.Class; A_arbace_test_tap_print_tap_plan_A_Init(); tmp3 = A_arbace_test_tap_print_tap_plan_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_5)); return A_arbace_test_tap__init_A_const_4.Ref() }





func A_arbace_test_tap__init_A_Unit5__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_6; var tmp2 any = A_arbace_test_tap_print_tap_diagnostic_A_New(); var tmp3 *jrt.Class; A_arbace_test_tap_print_tap_diagnostic_A_Init(); tmp3 = A_arbace_test_tap_print_tap_diagnostic_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_7)); return A_arbace_test_tap__init_A_const_6.Ref() }







func A_arbace_test_tap__init_A_Unit6__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_8; var tmp2 any = A_arbace_test_tap_print_tap_pass_A_New(); var tmp3 *jrt.Class; A_arbace_test_tap_print_tap_pass_A_Init(); tmp3 = A_arbace_test_tap_print_tap_pass_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_9)); return A_arbace_test_tap__init_A_const_8.Ref() }





func A_arbace_test_tap__init_A_Unit7__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_10; var tmp2 any = A_arbace_test_tap_print_tap_fail_A_New(); var tmp3 *jrt.Class; A_arbace_test_tap_print_tap_fail_A_Init(); tmp3 = A_arbace_test_tap_print_tap_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_11)); return A_arbace_test_tap__init_A_const_10.Ref() }






func A_arbace_test_tap__init_A_Unit8__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var v__1927000386__auto____1 any; jrt.NN(A_arbace_test_tap__init_A_const_12).SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_12; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_13)); v__1927000386__auto____1 = A_arbace_test_tap__init_A_const_12.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_test_tap__init_A_const_14).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { jrt.NN(A_arbace_test_tap__init_A_const_12).SetDynamic_Z__Var(true); var tmp3 *lang.Var = A_arbace_test_tap__init_A_const_12; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_18)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_12; var tmp5 *jrt.String = Lit_57; var tmp6 lang.IFn = Up_Keyword_IFn(A_arbace_test_tap__init_A_const_15); var tmp7 any = A_arbace_test_tap__init_A_const_16.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, Up_Var_IRef(A_arbace_test_tap__init_A_const_17))); return A_arbace_test_tap__init_A_const_12.Ref() } }

func A_arbace_test_tap__init_A_Unit9__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_tap__init_A_const_12).Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_16.Ref(); var tmp3 any = A_arbace_test_tap_eval1888000022_fn__1888000023_A_New(); var tmp4 *jrt.Class; A_arbace_test_tap_eval1888000022_fn__1888000023_A_Init(); tmp4 = A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_tap__init_A_Unit10__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_19; var tmp2 any = A_arbace_test_tap_print_diagnostics_A_New(); var tmp3 *jrt.Class; A_arbace_test_tap_print_diagnostics_A_Init(); tmp3 = A_arbace_test_tap_print_diagnostics_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_20)); return A_arbace_test_tap__init_A_const_19.Ref() }















func A_arbace_test_tap__init_A_Unit11__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_tap__init_A_const_12).Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_21.Ref(); var tmp3 any = A_arbace_test_tap_eval1888000029_fn__1888000030_A_New(); var tmp4 *jrt.Class; A_arbace_test_tap_eval1888000029_fn__1888000030_A_Init(); tmp4 = A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_tap__init_A_Unit12__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_tap__init_A_const_12).Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_22.Ref(); var tmp3 any = A_arbace_test_tap_eval1888000033_fn__1888000034_A_New(); var tmp4 *jrt.Class; A_arbace_test_tap_eval1888000033_fn__1888000034_A_Init(); tmp4 = A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_tap__init_A_Unit13__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(103, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_tap__init_A_const_12).Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_23.Ref(); var tmp3 any = A_arbace_test_tap_eval1888000037_fn__1888000038_A_New(); var tmp4 *jrt.Class; A_arbace_test_tap_eval1888000037_fn__1888000038_A_Init(); tmp4 = A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_tap__init_A_Unit14__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_tap__init_A_const_12).Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_24.Ref(); var tmp3 any = A_arbace_test_tap_eval1888000041_fn__1888000042_A_New(); var tmp4 *jrt.Class; A_arbace_test_tap_eval1888000041_fn__1888000042_A_Init(); tmp4 = A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_tap__init_A_Unit15__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_25; var tmp2 any = A_arbace_test_tap_with_tap_output_A_New(); var tmp3 *jrt.Class; A_arbace_test_tap_with_tap_output_A_Init(); tmp3 = A_arbace_test_tap_with_tap_output_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_26)); return A_arbace_test_tap__init_A_const_25.Ref() }
//line :113:1
func A_arbace_test_tap__init_A_Unit16__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); jrt.NN(A_arbace_test_tap__init_A_const_25).SetMacro__V(); return nil }
//line :113:1
func A_arbace_test_tap__init_A_Unit17__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); return A_arbace_test_tap__init_A_const_25.Ref() }







type A_arbace_test_tap__init_A struct{ jrt.Object }

var A_arbace_test_tap__init_A_const_0 *lang.Var

var A_arbace_test_tap__init_A_const_1 any

var A_arbace_test_tap__init_A_const_2 any

var A_arbace_test_tap__init_A_const_3 any

var A_arbace_test_tap__init_A_const_4 *lang.Var

var A_arbace_test_tap__init_A_const_5 any

var A_arbace_test_tap__init_A_const_6 *lang.Var

var A_arbace_test_tap__init_A_const_7 any

var A_arbace_test_tap__init_A_const_8 *lang.Var

var A_arbace_test_tap__init_A_const_9 any

var A_arbace_test_tap__init_A_const_10 *lang.Var

var A_arbace_test_tap__init_A_const_11 any

var A_arbace_test_tap__init_A_const_12 *lang.Var

var A_arbace_test_tap__init_A_const_13 any

var A_arbace_test_tap__init_A_const_14 *lang.Var

var A_arbace_test_tap__init_A_const_15 *lang.Keyword

var A_arbace_test_tap__init_A_const_16 *lang.Keyword

var A_arbace_test_tap__init_A_const_17 *lang.Var

var A_arbace_test_tap__init_A_const_18 any

var A_arbace_test_tap__init_A_const_19 *lang.Var

var A_arbace_test_tap__init_A_const_20 any

var A_arbace_test_tap__init_A_const_21 *lang.Keyword

var A_arbace_test_tap__init_A_const_22 *lang.Keyword

var A_arbace_test_tap__init_A_const_23 *lang.Keyword

var A_arbace_test_tap__init_A_const_24 *lang.Keyword

var A_arbace_test_tap__init_A_const_25 *lang.Var

var A_arbace_test_tap__init_A_const_26 any

var A_arbace_test_tap__init_A_init jrt.ClassInit

func A_arbace_test_tap__init_A_Init() { if !A_arbace_test_tap__init_A_init.Done() { A_arbace_test_tap__init_A_init.Run(A_arbace_test_tap__init_A_clinit) } }

func A_arbace_test_tap__init_A_clinit() { A_arbace_test_tap__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_test_tap__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_test_tap__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_test_tap__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_test_tap__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_50); A_arbace_test_tap__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_82).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_83, lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)); A_arbace_test_tap__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_25); A_arbace_test_tap__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)); A_arbace_test_tap__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_11, Lit_45); A_arbace_test_tap__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(56).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)); A_arbace_test_tap__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_47); A_arbace_test_tap__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_94, lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)); A_arbace_test_tap__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_57); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_test_tap__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)); A_arbace_test_tap__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_test_tap__init_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_test_tap__init_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_96); A_arbace_test_tap__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_95).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_test_tap__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)); A_arbace_test_tap__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_test_tap__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)); A_arbace_test_tap__init_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_test_tap__init_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_test_tap__init_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_test_tap__init_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_98); A_arbace_test_tap__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_11, Lit_99); A_arbace_test_tap__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_101).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref(), Lit_85, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), jrt.Integer_ValueOf_I__Integer(113).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_87).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_88).Ref(), Lit_89)) }

func A_arbace_test_tap__init_A_New() *A_arbace_test_tap__init_A { A_arbace_test_tap__init_A_Init(); t := &A_arbace_test_tap__init_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap__init_A) Ctor() {}

func (t *A_arbace_test_tap__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap__init_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap__init_A_class }

func (t *A_arbace_test_tap__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap__init_A); return ok }

func A_arbace_test_tap__init_A_Cast(x any) *A_arbace_test_tap__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap__init_A_class)) }; return v }
