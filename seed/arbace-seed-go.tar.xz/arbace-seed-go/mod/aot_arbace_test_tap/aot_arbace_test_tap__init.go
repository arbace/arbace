//line aot_arbace_test_tap__init.ae:1
package aot_arbace_test_tap

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_test_tap__init_A_Load__O() any { A_arbace_test_tap__init_A_Init(); A_arbace_test_tap__init_A_Unit0__O(); A_arbace_test_tap__init_A_Unit1__O(); A_arbace_test_tap__init_A_Unit2__O(); A_arbace_test_tap__init_A_Unit3__O(); A_arbace_test_tap__init_A_Unit4__O(); A_arbace_test_tap__init_A_Unit5__O(); A_arbace_test_tap__init_A_Unit6__O(); A_arbace_test_tap__init_A_Unit7__O(); A_arbace_test_tap__init_A_Unit8__O(); A_arbace_test_tap__init_A_Unit9__O(); A_arbace_test_tap__init_A_Unit10__O(); A_arbace_test_tap__init_A_Unit11__O(); A_arbace_test_tap__init_A_Unit12__O(); A_arbace_test_tap__init_A_Unit13__O(); A_arbace_test_tap__init_A_Unit14__O(); A_arbace_test_tap__init_A_Unit15__O(); A_arbace_test_tap__init_A_Unit16__O(); A_arbace_test_tap__init_A_Unit17__O(); return nil }














func A_arbace_test_tap__init_A_Unit0__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); return lang.IFn_Cast(A_arbace_test_tap__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap__init_A_const_1) }
//line :20:1
func A_arbace_test_tap__init_A_Unit1__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_test_tap__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_2)) }
//line :20:1
func A_arbace_test_tap__init_A_Unit2__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 any = A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :20:1
func A_arbace_test_tap__init_A_Unit3__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_test_tap__init_A_const_1)).Equals_O__Z(A_arbace_test_tap__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_test_tap_eval1888000008_fn__1888000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





















func A_arbace_test_tap__init_A_Unit4__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_4; var tmp2 any = A_arbace_test_tap_print_tap_plan_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_test_tap_print_tap_plan_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_test_tap_print_tap_plan_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_5)); return A_arbace_test_tap__init_A_const_4 }





func A_arbace_test_tap__init_A_Unit5__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_6; var tmp2 any = A_arbace_test_tap_print_tap_diagnostic_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_test_tap_print_tap_diagnostic_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_test_tap_print_tap_diagnostic_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_7)); return A_arbace_test_tap__init_A_const_6 }







func A_arbace_test_tap__init_A_Unit6__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_8; var tmp2 any = A_arbace_test_tap_print_tap_pass_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_test_tap_print_tap_pass_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_test_tap_print_tap_pass_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_9)); return A_arbace_test_tap__init_A_const_8 }





func A_arbace_test_tap__init_A_Unit7__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_10; var tmp2 any = A_arbace_test_tap_print_tap_fail_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_test_tap_print_tap_fail_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_test_tap_print_tap_fail_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_11)); return A_arbace_test_tap__init_A_const_10 }






func A_arbace_test_tap__init_A_Unit8__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var v__1927000386__auto____1 any; A_arbace_test_tap__init_A_const_12.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_13)); v__1927000386__auto____1 = A_arbace_test_tap__init_A_const_12; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_test_tap__init_A_const_14.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { A_arbace_test_tap__init_A_const_12.SetDynamic_Z__Var(true); var tmp3 *lang.Var = A_arbace_test_tap__init_A_const_12; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_18)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_12; var tmp5 *jrt.String = Lit_17; var tmp6 lang.IFn = A_arbace_test_tap__init_A_const_15; var tmp7 any = A_arbace_test_tap__init_A_const_16; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, A_arbace_test_tap__init_A_const_17)); return A_arbace_test_tap__init_A_const_12 } }

func A_arbace_test_tap__init_A_Unit9__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_tap__init_A_const_12.Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_16; var tmp3 any = A_arbace_test_tap_eval1888000022_fn__1888000023_A_New(); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_tap__init_A_Unit10__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_19; var tmp2 any = A_arbace_test_tap_print_diagnostics_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_test_tap_print_diagnostics_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_test_tap_print_diagnostics_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_20)); return A_arbace_test_tap__init_A_const_19 }















func A_arbace_test_tap__init_A_Unit11__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_tap__init_A_const_12.Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_21; var tmp3 any = A_arbace_test_tap_eval1888000029_fn__1888000030_A_New(); var tmp4 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_tap__init_A_Unit12__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_tap__init_A_const_12.Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_22; var tmp3 any = A_arbace_test_tap_eval1888000033_fn__1888000034_A_New(); var tmp4 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_tap__init_A_Unit13__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(103, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_tap__init_A_const_12.Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_23; var tmp3 any = A_arbace_test_tap_eval1888000037_fn__1888000038_A_New(); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_tap__init_A_Unit14__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_tap__init_A_const_12.Get__O()); var tmp2 any = A_arbace_test_tap__init_A_const_24; var tmp3 any = A_arbace_test_tap_eval1888000041_fn__1888000042_A_New(); var tmp4 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class = fncls__12d; tmp4 = fncls__12d } else { tmp4 = fncls__12 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_tap__init_A_Unit15__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_test_tap__init_A_const_25; var tmp2 any = A_arbace_test_tap_with_tap_output_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_test_tap_with_tap_output_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, true); A_arbace_test_tap_with_tap_output_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test_tap__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_tap__init_A_const_26)); return A_arbace_test_tap__init_A_const_25 }
//line :113:1
func A_arbace_test_tap__init_A_Unit16__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); A_arbace_test_tap__init_A_const_25.SetMacro__V(); return nil }
//line :113:1
func A_arbace_test_tap__init_A_Unit17__O() any { A_arbace_test_tap__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); return A_arbace_test_tap__init_A_const_25 }







type A_arbace_test_tap__init_A struct{ jrt.Object }

var A_arbace_test_tap__init_A_const_pool *jrt.RefArray

var A_arbace_test_tap__init_A_const_0 *lang.Var

var A_arbace_test_tap__init_A_const_1 any

var A_arbace_test_tap__init_A_const_2 any

var A_arbace_test_tap__init_A_const_3 any

var A_arbace_test_tap__init_A_const_4 *lang.Var

var A_arbace_test_tap__init_A_const_5 any

var A_arbace_test_tap__init_A_const_6 *lang.Var

var A_arbace_test_tap__init_A_const_7 any

var A_arbace_test_tap__init_A_const_8 *lang.Var

var A_arbace_test_tap__init_A_const_9 any

var A_arbace_test_tap__init_A_const_10 *lang.Var

var A_arbace_test_tap__init_A_const_11 any

var A_arbace_test_tap__init_A_const_12 *lang.Var

var A_arbace_test_tap__init_A_const_13 any

var A_arbace_test_tap__init_A_const_14 *lang.Var

var A_arbace_test_tap__init_A_const_15 *lang.Keyword

var A_arbace_test_tap__init_A_const_16 *lang.Keyword

var A_arbace_test_tap__init_A_const_17 *lang.Var

var A_arbace_test_tap__init_A_const_18 any

var A_arbace_test_tap__init_A_const_19 *lang.Var

var A_arbace_test_tap__init_A_const_20 any

var A_arbace_test_tap__init_A_const_21 *lang.Keyword

var A_arbace_test_tap__init_A_const_22 *lang.Keyword

var A_arbace_test_tap__init_A_const_23 *lang.Keyword

var A_arbace_test_tap__init_A_const_24 *lang.Keyword

var A_arbace_test_tap__init_A_const_25 *lang.Var

var A_arbace_test_tap__init_A_const_26 any

var A_arbace_test_tap__init_A_init jrt.ClassInit

func A_arbace_test_tap__init_A_Init() { if !A_arbace_test_tap__init_A_init.Done() { A_arbace_test_tap__init_A_init.Run(A_arbace_test_tap__init_A_clinit) } }

func A_arbace_test_tap__init_A_clinit() { A_arbace_test_tap__init_A_clinit_p0(); A_arbace_test_tap__init_A_clinit_p1(); A_arbace_test_tap__init_A_clinit_p2() }

func A_arbace_test_tap__init_A_clinit_p0() { A_arbace_test_tap__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_10, 47); A_arbace_test_tap__init_A_const_0 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[20]); A_arbace_test_tap__init_A_const_1 = A_arbace_test_tap__init_A_const_pool.A[21]; A_arbace_test_tap__init_A_const_2 = A_arbace_test_tap__init_A_const_pool.A[22]; A_arbace_test_tap__init_A_const_3 = A_arbace_test_tap__init_A_const_pool.A[23]; A_arbace_test_tap__init_A_const_4 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[24]); A_arbace_test_tap__init_A_const_5 = A_arbace_test_tap__init_A_const_pool.A[25]; A_arbace_test_tap__init_A_const_6 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[26]); A_arbace_test_tap__init_A_const_7 = A_arbace_test_tap__init_A_const_pool.A[27]; A_arbace_test_tap__init_A_const_8 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[28]); A_arbace_test_tap__init_A_const_9 = A_arbace_test_tap__init_A_const_pool.A[29]; A_arbace_test_tap__init_A_const_10 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[30]); A_arbace_test_tap__init_A_const_11 = A_arbace_test_tap__init_A_const_pool.A[31]; A_arbace_test_tap__init_A_const_12 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[32]) }

func A_arbace_test_tap__init_A_clinit_p1() { A_arbace_test_tap__init_A_const_13 = A_arbace_test_tap__init_A_const_pool.A[33]; A_arbace_test_tap__init_A_const_14 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[34]); A_arbace_test_tap__init_A_const_15 = lang.Keyword_Cast(A_arbace_test_tap__init_A_const_pool.A[35]); A_arbace_test_tap__init_A_const_16 = lang.Keyword_Cast(A_arbace_test_tap__init_A_const_pool.A[36]); A_arbace_test_tap__init_A_const_17 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[37]); A_arbace_test_tap__init_A_const_18 = A_arbace_test_tap__init_A_const_pool.A[38]; A_arbace_test_tap__init_A_const_19 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[39]); A_arbace_test_tap__init_A_const_20 = A_arbace_test_tap__init_A_const_pool.A[40]; A_arbace_test_tap__init_A_const_21 = lang.Keyword_Cast(A_arbace_test_tap__init_A_const_pool.A[41]); A_arbace_test_tap__init_A_const_22 = lang.Keyword_Cast(A_arbace_test_tap__init_A_const_pool.A[42]); A_arbace_test_tap__init_A_const_23 = lang.Keyword_Cast(A_arbace_test_tap__init_A_const_pool.A[43]); A_arbace_test_tap__init_A_const_24 = lang.Keyword_Cast(A_arbace_test_tap__init_A_const_pool.A[44]) }

func A_arbace_test_tap__init_A_clinit_p2() { A_arbace_test_tap__init_A_const_25 = lang.Var_Cast(A_arbace_test_tap__init_A_const_pool.A[45]); A_arbace_test_tap__init_A_const_26 = A_arbace_test_tap__init_A_const_pool.A[46] }

func A_arbace_test_tap__init_A_New() *A_arbace_test_tap__init_A { A_arbace_test_tap__init_A_Init(); t := &A_arbace_test_tap__init_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap__init_A) Ctor() {}

func (t *A_arbace_test_tap__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap__init_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap__init_A_class }

func (t *A_arbace_test_tap__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap__init_A); return ok }

func A_arbace_test_tap__init_A_Cast(x any) *A_arbace_test_tap__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap__init_A_class)) }; return v }
