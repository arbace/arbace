//line j2g_up.ae:1
package aot_arbace_test_tap

import "arbace/lang"


func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }
