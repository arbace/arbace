//line a2g_classes.ae:1
package aot_arbace_test_tap

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_test_tap_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_A_New()}; return nil }

var A_arbace_test_tap_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_A_new}

var A_arbace_test_tap_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_A"})

func init() { i := A_arbace_test_tap_A_class.Info(); i.IsInstance = A_arbace_test_tap_A_InstanceOf; i.Init = A_arbace_test_tap_A_Init; i.Table = A_arbace_test_tap_A_members; jrt.RegisterGoType(A_arbace_test_tap_A_class, reflect.TypeFor[A_arbace_test_tap_A]()) }

func A_arbace_test_tap_eval1888000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000004_A_New()}; return nil }

var A_arbace_test_tap_eval1888000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000004_A_new}

var A_arbace_test_tap_eval1888000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000004", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000004_A"})

func init() { i := A_arbace_test_tap_eval1888000004_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000004_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000004_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000004_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000004_A]()) }

func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_New()}; return nil }

func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class)}; return nil }

var A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_invoke, New: A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_new, Get: A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_get}

var A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000004$loading__1927001464__auto____1888000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_tap_eval1888000004_A_class, Simple: "loading__1927001464__auto____1888000005", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_InstanceOf; i.Init = A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_Init; i.Table = A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A]()) }

func A_arbace_test_tap_eval1888000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000008_A_New()}; return nil }

var A_arbace_test_tap_eval1888000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000008_A_new}

var A_arbace_test_tap_eval1888000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000008", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000008_A"})

func init() { i := A_arbace_test_tap_eval1888000008_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000008_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000008_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000008_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000008_A]()) }

func A_arbace_test_tap_eval1888000008_fn__1888000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_eval1888000008_fn__1888000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_tap_eval1888000008_fn__1888000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000008_fn__1888000009_A_New()}; return nil }

func A_arbace_test_tap_eval1888000008_fn__1888000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class)}; return nil }

var A_arbace_test_tap_eval1888000008_fn__1888000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_eval1888000008_fn__1888000009_A_invoke, New: A_arbace_test_tap_eval1888000008_fn__1888000009_A_new, Get: A_arbace_test_tap_eval1888000008_fn__1888000009_A_get}

var A_arbace_test_tap_eval1888000008_fn__1888000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000008$fn__1888000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_tap_eval1888000008_A_class, Simple: "fn__1888000009", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000008_fn__1888000009_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_eval1888000008_fn__1888000009_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000008_fn__1888000009_A_InstanceOf; i.Init = A_arbace_test_tap_eval1888000008_fn__1888000009_A_Init; i.Table = A_arbace_test_tap_eval1888000008_fn__1888000009_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000008_fn__1888000009_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000008_fn__1888000009_A]()) }

func A_arbace_test_tap_eval1888000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000022_A_New()}; return nil }

var A_arbace_test_tap_eval1888000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000022_A_new}

var A_arbace_test_tap_eval1888000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000022", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000022_A"})

func init() { i := A_arbace_test_tap_eval1888000022_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000022_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000022_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000022_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000022_A]()) }

func A_arbace_test_tap_eval1888000022_fn__1888000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_eval1888000022_fn__1888000023_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_eval1888000022_fn__1888000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000022_fn__1888000023_A_New()}; return nil }

func A_arbace_test_tap_eval1888000022_fn__1888000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class)}; return nil }

var A_arbace_test_tap_eval1888000022_fn__1888000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_eval1888000022_fn__1888000023_A_invoke, New: A_arbace_test_tap_eval1888000022_fn__1888000023_A_new, Get: A_arbace_test_tap_eval1888000022_fn__1888000023_A_get}

var A_arbace_test_tap_eval1888000022_fn__1888000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000022$fn__1888000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_eval1888000022_A_class, Simple: "fn__1888000023", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000022_fn__1888000023_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_eval1888000022_fn__1888000023_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000022_fn__1888000023_A_InstanceOf; i.Init = A_arbace_test_tap_eval1888000022_fn__1888000023_A_Init; i.Table = A_arbace_test_tap_eval1888000022_fn__1888000023_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000022_fn__1888000023_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000022_fn__1888000023_A]()) }

func A_arbace_test_tap_eval1888000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000029_A_New()}; return nil }

var A_arbace_test_tap_eval1888000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000029_A_new}

var A_arbace_test_tap_eval1888000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000029", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000029_A"})

func init() { i := A_arbace_test_tap_eval1888000029_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000029_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000029_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000029_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000029_A]()) }

func A_arbace_test_tap_eval1888000029_fn__1888000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_eval1888000029_fn__1888000030_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_eval1888000029_fn__1888000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000029_fn__1888000030_A_New()}; return nil }

func A_arbace_test_tap_eval1888000029_fn__1888000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class)}; return nil }

var A_arbace_test_tap_eval1888000029_fn__1888000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_eval1888000029_fn__1888000030_A_invoke, New: A_arbace_test_tap_eval1888000029_fn__1888000030_A_new, Get: A_arbace_test_tap_eval1888000029_fn__1888000030_A_get}

var A_arbace_test_tap_eval1888000029_fn__1888000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000029$fn__1888000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_eval1888000029_A_class, Simple: "fn__1888000030", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000029_fn__1888000030_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_eval1888000029_fn__1888000030_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000029_fn__1888000030_A_InstanceOf; i.Init = A_arbace_test_tap_eval1888000029_fn__1888000030_A_Init; i.Table = A_arbace_test_tap_eval1888000029_fn__1888000030_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000029_fn__1888000030_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000029_fn__1888000030_A]()) }

func A_arbace_test_tap_eval1888000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000033_A_New()}; return nil }

var A_arbace_test_tap_eval1888000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000033_A_new}

var A_arbace_test_tap_eval1888000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000033", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000033_A"})

func init() { i := A_arbace_test_tap_eval1888000033_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000033_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000033_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000033_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000033_A]()) }

func A_arbace_test_tap_eval1888000033_fn__1888000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_eval1888000033_fn__1888000034_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_eval1888000033_fn__1888000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000033_fn__1888000034_A_New()}; return nil }

func A_arbace_test_tap_eval1888000033_fn__1888000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class)}; return nil }

var A_arbace_test_tap_eval1888000033_fn__1888000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_eval1888000033_fn__1888000034_A_invoke, New: A_arbace_test_tap_eval1888000033_fn__1888000034_A_new, Get: A_arbace_test_tap_eval1888000033_fn__1888000034_A_get}

var A_arbace_test_tap_eval1888000033_fn__1888000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000033$fn__1888000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_eval1888000033_A_class, Simple: "fn__1888000034", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000033_fn__1888000034_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_eval1888000033_fn__1888000034_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000033_fn__1888000034_A_InstanceOf; i.Init = A_arbace_test_tap_eval1888000033_fn__1888000034_A_Init; i.Table = A_arbace_test_tap_eval1888000033_fn__1888000034_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000033_fn__1888000034_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000033_fn__1888000034_A]()) }

func A_arbace_test_tap_eval1888000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000037_A_New()}; return nil }

var A_arbace_test_tap_eval1888000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000037_A_new}

var A_arbace_test_tap_eval1888000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000037", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000037_A"})

func init() { i := A_arbace_test_tap_eval1888000037_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000037_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000037_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000037_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000037_A]()) }

func A_arbace_test_tap_eval1888000037_fn__1888000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_eval1888000037_fn__1888000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_eval1888000037_fn__1888000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000037_fn__1888000038_A_New()}; return nil }

func A_arbace_test_tap_eval1888000037_fn__1888000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class)}; return nil }

var A_arbace_test_tap_eval1888000037_fn__1888000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_eval1888000037_fn__1888000038_A_invoke, New: A_arbace_test_tap_eval1888000037_fn__1888000038_A_new, Get: A_arbace_test_tap_eval1888000037_fn__1888000038_A_get}

var A_arbace_test_tap_eval1888000037_fn__1888000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000037$fn__1888000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_eval1888000037_A_class, Simple: "fn__1888000038", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000037_fn__1888000038_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_eval1888000037_fn__1888000038_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000037_fn__1888000038_A_InstanceOf; i.Init = A_arbace_test_tap_eval1888000037_fn__1888000038_A_Init; i.Table = A_arbace_test_tap_eval1888000037_fn__1888000038_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000037_fn__1888000038_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000037_fn__1888000038_A]()) }

func A_arbace_test_tap_eval1888000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000041_A_New()}; return nil }

var A_arbace_test_tap_eval1888000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_tap_eval1888000041_A_new}

var A_arbace_test_tap_eval1888000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_tap_A_class, Simple: "eval1888000041", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000041_A"})

func init() { i := A_arbace_test_tap_eval1888000041_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000041_A_InstanceOf; i.Table = A_arbace_test_tap_eval1888000041_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000041_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000041_A]()) }

func A_arbace_test_tap_eval1888000041_fn__1888000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_eval1888000041_fn__1888000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_eval1888000041_fn__1888000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_eval1888000041_fn__1888000042_A_New()}; return nil }

func A_arbace_test_tap_eval1888000041_fn__1888000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class)}; return nil }

var A_arbace_test_tap_eval1888000041_fn__1888000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_eval1888000041_fn__1888000042_A_invoke, New: A_arbace_test_tap_eval1888000041_fn__1888000042_A_new, Get: A_arbace_test_tap_eval1888000041_fn__1888000042_A_get}

var A_arbace_test_tap_eval1888000041_fn__1888000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$eval1888000041$fn__1888000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_eval1888000041_A_class, Simple: "fn__1888000042", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_eval1888000041_fn__1888000042_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_eval1888000041_fn__1888000042_A_class.Info(); i.IsInstance = A_arbace_test_tap_eval1888000041_fn__1888000042_A_InstanceOf; i.Init = A_arbace_test_tap_eval1888000041_fn__1888000042_A_Init; i.Table = A_arbace_test_tap_eval1888000041_fn__1888000042_A_members; jrt.RegisterGoType(A_arbace_test_tap_eval1888000041_fn__1888000042_A_class, reflect.TypeFor[A_arbace_test_tap_eval1888000041_fn__1888000042_A]()) }

func A_arbace_test_tap_print_diagnostics_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_print_diagnostics_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_print_diagnostics_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_print_diagnostics_A_New()}; return nil }

func A_arbace_test_tap_print_diagnostics_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_print_diagnostics_A_fn_class)}; return nil }

var A_arbace_test_tap_print_diagnostics_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_print_diagnostics_A_invoke, New: A_arbace_test_tap_print_diagnostics_A_new, Get: A_arbace_test_tap_print_diagnostics_A_get}

var A_arbace_test_tap_print_diagnostics_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$print_diagnostics", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_A_class, Simple: "print_diagnostics", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_diagnostics_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_print_diagnostics_A_class.Info(); i.IsInstance = A_arbace_test_tap_print_diagnostics_A_InstanceOf; i.Init = A_arbace_test_tap_print_diagnostics_A_Init; i.Table = A_arbace_test_tap_print_diagnostics_A_members; jrt.RegisterGoType(A_arbace_test_tap_print_diagnostics_A_class, reflect.TypeFor[A_arbace_test_tap_print_diagnostics_A]()) }

func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_print_diagnostics_fn__1888000026_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_print_diagnostics_fn__1888000026_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class)}; return nil }

var A_arbace_test_tap_print_diagnostics_fn__1888000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_print_diagnostics_fn__1888000026_A_invoke, New: A_arbace_test_tap_print_diagnostics_fn__1888000026_A_new, Get: A_arbace_test_tap_print_diagnostics_fn__1888000026_A_get}

var A_arbace_test_tap_print_diagnostics_fn__1888000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$print_diagnostics$fn__1888000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_tap_print_diagnostics_A_class, Simple: "fn__1888000026", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_diagnostics_fn__1888000026_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_print_diagnostics_fn__1888000026_A_class.Info(); i.IsInstance = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_InstanceOf; i.Init = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_Init; i.Table = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_members; jrt.RegisterGoType(A_arbace_test_tap_print_diagnostics_fn__1888000026_A_class, reflect.TypeFor[A_arbace_test_tap_print_diagnostics_fn__1888000026_A]()) }

func A_arbace_test_tap_print_tap_diagnostic_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_print_tap_diagnostic_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_print_tap_diagnostic_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_print_tap_diagnostic_A_New()}; return nil }

func A_arbace_test_tap_print_tap_diagnostic_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_print_tap_diagnostic_A_fn_class)}; return nil }

var A_arbace_test_tap_print_tap_diagnostic_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_print_tap_diagnostic_A_invoke, New: A_arbace_test_tap_print_tap_diagnostic_A_new, Get: A_arbace_test_tap_print_tap_diagnostic_A_get}

var A_arbace_test_tap_print_tap_diagnostic_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$print_tap_diagnostic", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_A_class, Simple: "print_tap_diagnostic", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_diagnostic_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_print_tap_diagnostic_A_class.Info(); i.IsInstance = A_arbace_test_tap_print_tap_diagnostic_A_InstanceOf; i.Init = A_arbace_test_tap_print_tap_diagnostic_A_Init; i.Table = A_arbace_test_tap_print_tap_diagnostic_A_members; jrt.RegisterGoType(A_arbace_test_tap_print_tap_diagnostic_A_class, reflect.TypeFor[A_arbace_test_tap_print_tap_diagnostic_A]()) }

func A_arbace_test_tap_print_tap_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_print_tap_fail_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_print_tap_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_print_tap_fail_A_New()}; return nil }

func A_arbace_test_tap_print_tap_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_print_tap_fail_A_fn_class)}; return nil }

var A_arbace_test_tap_print_tap_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_print_tap_fail_A_invoke, New: A_arbace_test_tap_print_tap_fail_A_new, Get: A_arbace_test_tap_print_tap_fail_A_get}

var A_arbace_test_tap_print_tap_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$print_tap_fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_A_class, Simple: "print_tap_fail", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_fail_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_print_tap_fail_A_class.Info(); i.IsInstance = A_arbace_test_tap_print_tap_fail_A_InstanceOf; i.Init = A_arbace_test_tap_print_tap_fail_A_Init; i.Table = A_arbace_test_tap_print_tap_fail_A_members; jrt.RegisterGoType(A_arbace_test_tap_print_tap_fail_A_class, reflect.TypeFor[A_arbace_test_tap_print_tap_fail_A]()) }

func A_arbace_test_tap_print_tap_pass_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_print_tap_pass_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_print_tap_pass_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_print_tap_pass_A_New()}; return nil }

func A_arbace_test_tap_print_tap_pass_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_print_tap_pass_A_fn_class)}; return nil }

var A_arbace_test_tap_print_tap_pass_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_print_tap_pass_A_invoke, New: A_arbace_test_tap_print_tap_pass_A_new, Get: A_arbace_test_tap_print_tap_pass_A_get}

var A_arbace_test_tap_print_tap_pass_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$print_tap_pass", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_A_class, Simple: "print_tap_pass", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_pass_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_print_tap_pass_A_class.Info(); i.IsInstance = A_arbace_test_tap_print_tap_pass_A_InstanceOf; i.Init = A_arbace_test_tap_print_tap_pass_A_Init; i.Table = A_arbace_test_tap_print_tap_pass_A_members; jrt.RegisterGoType(A_arbace_test_tap_print_tap_pass_A_class, reflect.TypeFor[A_arbace_test_tap_print_tap_pass_A]()) }

func A_arbace_test_tap_print_tap_plan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_print_tap_plan_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_tap_print_tap_plan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_print_tap_plan_A_New()}; return nil }

func A_arbace_test_tap_print_tap_plan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_print_tap_plan_A_fn_class)}; return nil }

var A_arbace_test_tap_print_tap_plan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_print_tap_plan_A_invoke, New: A_arbace_test_tap_print_tap_plan_A_new, Get: A_arbace_test_tap_print_tap_plan_A_get}

var A_arbace_test_tap_print_tap_plan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$print_tap_plan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_tap_A_class, Simple: "print_tap_plan", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_print_tap_plan_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_print_tap_plan_A_class.Info(); i.IsInstance = A_arbace_test_tap_print_tap_plan_A_InstanceOf; i.Init = A_arbace_test_tap_print_tap_plan_A_Init; i.Table = A_arbace_test_tap_print_tap_plan_A_members; jrt.RegisterGoType(A_arbace_test_tap_print_tap_plan_A_class, reflect.TypeFor[A_arbace_test_tap_print_tap_plan_A]()) }

func A_arbace_test_tap_with_tap_output_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_tap_with_tap_output_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_test_tap_with_tap_output_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap_with_tap_output_A_New()}; return nil }

func A_arbace_test_tap_with_tap_output_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_tap_with_tap_output_A_fn_class)}; return nil }

var A_arbace_test_tap_with_tap_output_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_tap_with_tap_output_A_invoke, New: A_arbace_test_tap_with_tap_output_A_new, Get: A_arbace_test_tap_with_tap_output_A_get}

var A_arbace_test_tap_with_tap_output_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap$with_tap_output", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_test_tap_A_class, Simple: "with_tap_output", Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap_with_tap_output_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap_with_tap_output_A_class.Info(); i.IsInstance = A_arbace_test_tap_with_tap_output_A_InstanceOf; i.Init = A_arbace_test_tap_with_tap_output_A_Init; i.Table = A_arbace_test_tap_with_tap_output_A_members; jrt.RegisterGoType(A_arbace_test_tap_with_tap_output_A_class, reflect.TypeFor[A_arbace_test_tap_with_tap_output_A]()) }

func A_arbace_test_tap__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_test_tap__init_A_Load__O(); case 1: return A_arbace_test_tap__init_A_Unit0__O(); case 2: return A_arbace_test_tap__init_A_Unit1__O(); case 3: return A_arbace_test_tap__init_A_Unit10__O(); case 4: return A_arbace_test_tap__init_A_Unit11__O(); case 5: return A_arbace_test_tap__init_A_Unit12__O(); case 6: return A_arbace_test_tap__init_A_Unit13__O(); case 7: return A_arbace_test_tap__init_A_Unit14__O(); case 8: return A_arbace_test_tap__init_A_Unit15__O(); case 9: return A_arbace_test_tap__init_A_Unit16__O(); case 10: return A_arbace_test_tap__init_A_Unit17__O(); case 11: return A_arbace_test_tap__init_A_Unit2__O(); case 12: return A_arbace_test_tap__init_A_Unit3__O(); case 13: return A_arbace_test_tap__init_A_Unit4__O(); case 14: return A_arbace_test_tap__init_A_Unit5__O(); case 15: return A_arbace_test_tap__init_A_Unit6__O(); case 16: return A_arbace_test_tap__init_A_Unit7__O(); case 17: return A_arbace_test_tap__init_A_Unit8__O(); case 18: return A_arbace_test_tap__init_A_Unit9__O()}; return nil }

func A_arbace_test_tap__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_tap__init_A_New()}; return nil }

var A_arbace_test_tap__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_test_tap__init_A_invoke, New: A_arbace_test_tap__init_A_new}

var A_arbace_test_tap__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.tap__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_tap.A_arbace_test_tap__init_A", Source: "tap.ae"})

func init() { i := A_arbace_test_tap__init_A_class.Info(); i.IsInstance = A_arbace_test_tap__init_A_InstanceOf; i.Init = A_arbace_test_tap__init_A_Init; i.Table = A_arbace_test_tap__init_A_members; jrt.RegisterGoType(A_arbace_test_tap__init_A_class, reflect.TypeFor[A_arbace_test_tap__init_A]()) }
