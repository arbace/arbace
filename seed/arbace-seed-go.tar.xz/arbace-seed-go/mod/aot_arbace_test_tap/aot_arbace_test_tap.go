//line aot_arbace_test_tap.ae:1
package aot_arbace_test_tap

import (
	"arbace/jrt"
	"arbace/lang"
)













func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_New() *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Ctor() {}
//line :20:1
func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_test_tap_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_test_tap_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_tap_A_const_3, A_arbace_test_tap_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :20:1
func A_arbace_test_tap_eval1888000008_fn__1888000009_A_New() *A_arbace_test_tap_eval1888000008_fn__1888000009_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000008_fn__1888000009_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Ctor() {}
//line :20:1
func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_tap_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_9), A_arbace_test_tap_A_const_7.GetRawRoot__O(), A_arbace_test_tap_A_const_8) }





















func A_arbace_test_tap_print_tap_plan_A_New() *A_arbace_test_tap_print_tap_plan_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_plan_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_test_tap_print_tap_plan_A) Ctor() {}
//line :42:1
func (t *A_arbace_test_tap_print_tap_plan_A) Invoke_O_O__O(self, n__0 any) any {



	return lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__0)).Ref())
}
func A_arbace_test_tap_print_tap_diagnostic_A_New() *A_arbace_test_tap_print_tap_diagnostic_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_diagnostic_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_test_tap_print_tap_diagnostic_A) Ctor() {}
//line :48:1
func (t *A_arbace_test_tap_print_tap_diagnostic_A) Invoke_O_O__O(self, data__0 any) any { { var tmp1 *jrt.Class = A_arbace_test_tap_A_const_15; var seq_1888000013__2 any = lang.IFn_Cast(A_arbace_test_tap_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(data__0, tmp1, Lit_4, jrt.RefArrayOf(jrt.Object_class, Lit_5))); var chunk_1888000014__3 any; var count_1888000015__4 int64 = 0; var i_1888000016__5 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i_1888000016__5, count_1888000015__4) { var line__6 any = lang.Indexed_Cast(chunk_1888000014__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1888000016__5))
		lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_6, line__6)
//line :53:1
		seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1888000016__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_test_tap_A_const_11.GetRawRoot__O()).Invoke_O__O(seq_1888000013__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1888000013__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_tap_A_const_12.GetRawRoot__O()).Invoke_O__O(seq_1888000013__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_test_tap_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_1888000013__7); seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = lang.IFn_Cast(A_arbace_test_tap_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_1888000013__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var line__8 any = lang.IFn_Cast(A_arbace_test_tap_A_const_14.GetRawRoot__O()).Invoke_O__O(seq_1888000013__7)
			lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_6, line__8)
//line :53:1
			seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = lang.IFn_Cast(A_arbace_test_tap_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_1888000013__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :48:1*/panic("j2g: unreachable") }







func A_arbace_test_tap_print_tap_pass_A_New() *A_arbace_test_tap_print_tap_pass_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_pass_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_test_tap_print_tap_pass_A) Ctor() {}
//line :56:1
func (t *A_arbace_test_tap_print_tap_pass_A) Invoke_O_O__O(self, msg__0 any) any {



	return lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_8, msg__0)
}
func A_arbace_test_tap_print_tap_fail_A_New() *A_arbace_test_tap_print_tap_fail_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_fail_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_test_tap_print_tap_fail_A) Ctor() {}
//line :62:1
func (t *A_arbace_test_tap_print_tap_fail_A) Invoke_O_O__O(self, msg__0 any) any {



	return lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_7, msg__0)
}



func A_arbace_test_tap_eval1888000022_fn__1888000023_A_New() *A_arbace_test_tap_eval1888000022_fn__1888000023_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000022_fn__1888000023_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Ctor() {}
//line :71:1
func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_22; lang.IFn_Cast(A_arbace_test_tap_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_23.Get__O()))
//line :71:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp3 = lang.IFn_Cast(A_arbace_test_tap_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_24.GetRawRoot__O()).Invoke_O__O(data__1))
//line :71:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke__O()
//line :71:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_tap_print_diagnostics_A_New() *A_arbace_test_tap_print_diagnostics_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_diagnostics_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_test_tap_print_diagnostics_A) Ctor() {}
//line :75:1
func (t *A_arbace_test_tap_print_diagnostics_A) Invoke_O_O__O(self, data__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_test_tap_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_28.Get__O())) {
		lang.IFn_Cast(A_arbace_test_tap_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_29.GetRawRoot__O()).Invoke__O()) }
	if jrt.J2g_Truth(A_arbace_test_tap_A_const_27.Invoke_O__O(data__0)) {
		lang.IFn_Cast(A_arbace_test_tap_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_27.Invoke_O__O(data__0)) }
	lang.IFn_Cast(A_arbace_test_tap_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_test_tap_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_30.Invoke_O__O(data__0)))).Ref())
	var tmp1 any = A_arbace_test_tap_A_const_25; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_test_tap_A_const_26.Invoke_O__O(data__0)) {
		return lang.IFn_Cast(A_arbace_test_tap_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_test_tap_A_const_24.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_31.Invoke_O__O(data__0)))).Ref()) } else {

			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_18.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_2, nil); var tmp4 any; var s__1927001093__auto____4 any = jrt.StringWriter_New()

			lang.IFn_Cast(A_arbace_test_tap_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_tap_A_const_22, s__1927001093__auto____4)); var tmp5 any = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_New_O_O(s__1927001093__auto____4, data__0); var tmp6 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class = fncls__1d; tmp6 = fncls__1d } else { tmp6 = fncls__1 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :84:1
			return tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref())
		} }
func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_New_O_O(p0, p1 any) *A_arbace_test_tap_print_diagnostics_fn__1888000026_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_diagnostics_fn__1888000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Ctor_O_O(c__s__1927001093__auto__, c__data any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_data = c__data }
//line :86:1
func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												if jrt.Throwable_InstanceOf(A_arbace_test_tap_A_const_31.Invoke_O__O(t.F_data)) {
													var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_33.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_test_tap_A_const_31; var tmp4 any; var t_ any = t.F_data; t.F_data = nil; tmp4 = t_; tmp2.Invoke_O_O__O(tmp3.Invoke_O__O(tmp4), A_arbace_test_tap_A_const_35.Get__O()) } else {
														var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_34.GetRawRoot__O()); var tmp6 *lang.Keyword = A_arbace_test_tap_A_const_31; var tmp7 any; var t__2 any = t.F_data; t.F_data = nil; tmp7 = t__2; tmp5.Invoke_O__O(tmp6.Invoke_O__O(tmp7)) }
//line :86:1
	{ var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_32.GetRawRoot__O()); var tmp9 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp9 = t__3; tmp1 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }




func A_arbace_test_tap_eval1888000029_fn__1888000030_A_New() *A_arbace_test_tap_eval1888000029_fn__1888000030_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000029_fn__1888000030_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Ctor() {}
//line :91:1
func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_22; lang.IFn_Cast(A_arbace_test_tap_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_23.Get__O()))
//line :91:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_test_tap_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_25)
		lang.IFn_Cast(A_arbace_test_tap_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_39.GetRawRoot__O()).Invoke_O__O(data__1))
		tmp3 = lang.IFn_Cast(A_arbace_test_tap_A_const_36.GetRawRoot__O()).Invoke_O__O(data__1)
//line :91:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke__O()
//line :91:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}




func A_arbace_test_tap_eval1888000033_fn__1888000034_A_New() *A_arbace_test_tap_eval1888000033_fn__1888000034_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000033_fn__1888000034_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Ctor() {}
//line :97:1
func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_22; lang.IFn_Cast(A_arbace_test_tap_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_23.Get__O()))
//line :97:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_test_tap_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_41)
		lang.IFn_Cast(A_arbace_test_tap_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_39.GetRawRoot__O()).Invoke_O__O(data__1))
		tmp3 = lang.IFn_Cast(A_arbace_test_tap_A_const_36.GetRawRoot__O()).Invoke_O__O(data__1)
//line :97:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke__O()
//line :97:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}




func A_arbace_test_tap_eval1888000037_fn__1888000038_A_New() *A_arbace_test_tap_eval1888000037_fn__1888000038_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000037_fn__1888000038_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Ctor() {}
//line :103:1
func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_22; lang.IFn_Cast(A_arbace_test_tap_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_23.Get__O()))
//line :103:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_test_tap_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_42)
		lang.IFn_Cast(A_arbace_test_tap_A_const_40.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_39.GetRawRoot__O()).Invoke_O__O(data__1))
		tmp3 = lang.IFn_Cast(A_arbace_test_tap_A_const_36.GetRawRoot__O()).Invoke_O__O(data__1)
//line :103:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke__O()
//line :103:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}




func A_arbace_test_tap_eval1888000041_fn__1888000042_A_New() *A_arbace_test_tap_eval1888000041_fn__1888000042_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000041_fn__1888000042_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Ctor() {}
//line :109:1
func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_22; lang.IFn_Cast(A_arbace_test_tap_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_23.Get__O()))
//line :109:1
	var tmp3 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_43.GetRawRoot__O()); var tmp5 jrt.Number_I; var na_2 any; var na_4 any = A_arbace_test_tap_A_const_25.Invoke_O__O(data__1); var na_5 any = A_arbace_test_tap_A_const_42.Invoke_O__O(data__1); var tmp6 bool; var tmp7 bool; tmp7 = jrt.Long_InstanceOf(na_4); if tmp7 { tmp7 = jrt.Long_InstanceOf(na_5) }; tmp6 = tmp7; if tmp6 { var n0_6 int64 = jrt.NN(jrt.Long_Cast(na_4)).LongValue__J(); var n1_7 int64 = jrt.NN(jrt.Long_Cast(na_5)).LongValue__J(); var nr_8 int64 = n0_6 + n1_7; if (n0_6^nr_8)&(n1_7^nr_8) >= 0 { na_2 = jrt.Long_ValueOf_J__Long_NoInit(nr_8).Ref() } else { na_2 = lang.Numbers_Add_O_O__Number_NoInit(na_4, na_5) } } else { var tmp8 bool; var tmp9 bool; tmp9 = jrt.Double_InstanceOf(na_4); if tmp9 { tmp9 = jrt.Double_InstanceOf(na_5) }; tmp8 = tmp9; if tmp8 { var n0_6_2 float64 = jrt.NN(jrt.Double_Cast(na_4)).DoubleValue__D(); var n1_7_2 float64 = jrt.NN(jrt.Double_Cast(na_5)).DoubleValue__D(); na_2 = jrt.Double_ValueOf_D__Double_NoInit(n0_6_2 + n1_7_2).Ref() } else { na_2 = lang.Numbers_Add_O_O__Number_NoInit(na_4, na_5) } }; var na_3 any = A_arbace_test_tap_A_const_41.Invoke_O__O(data__1); var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_2); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_3) }; tmp10 = tmp11; if tmp10 { var n0_9 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); var n1_10 int64 = jrt.NN(jrt.Long_Cast(na_3)).LongValue__J(); var nr_11 int64 = n0_9 + n1_10; if (n0_9^nr_11)&(n1_10^nr_11) >= 0 { tmp5 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_11)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_2, na_3) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_2); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_3) }; tmp12 = tmp13; if tmp12 { var n0_9_2 float64 = jrt.NN(jrt.Double_Cast(na_2)).DoubleValue__D(); var n1_10_2 float64 = jrt.NN(jrt.Double_Cast(na_3)).DoubleValue__D(); tmp5 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_9_2 + n1_10_2)) } else { tmp5 = lang.Numbers_Add_O_O__Number_NoInit(na_2, na_3) } }; tmp3 = tmp4.Invoke_O__O(tmp5) }
//line :109:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke__O()
//line :109:1
	if tmp14 != nil { panic(tmp14) }; return tmp3
}


func A_arbace_test_tap_with_tap_output_A_New() *A_arbace_test_tap_with_tap_output_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_with_tap_output_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_test_tap_with_tap_output_A) Ctor() {}
//line :113:1
func (t *A_arbace_test_tap_with_tap_output_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { return lang.IFn_Cast(A_arbace_test_tap_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_46), lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_tap_A_const_48.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_tap_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_49), lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_50))))), body__2)) }









type A_arbace_test_tap_A struct{ jrt.Object }

var A_arbace_test_tap_A_const_pool *jrt.RefArray

var A_arbace_test_tap_A_const_0 *lang.Var

var A_arbace_test_tap_A_const_1 *lang.Var

var A_arbace_test_tap_A_const_2 any

var A_arbace_test_tap_A_const_3 any

var A_arbace_test_tap_A_const_4 any

var A_arbace_test_tap_A_const_5 *lang.Var

var A_arbace_test_tap_A_const_6 *lang.Var

var A_arbace_test_tap_A_const_7 *lang.Var

var A_arbace_test_tap_A_const_8 any

var A_arbace_test_tap_A_const_9 *lang.Var

var A_arbace_test_tap_A_const_10 *lang.Var

var A_arbace_test_tap_A_const_11 *lang.Var

var A_arbace_test_tap_A_const_12 *lang.Var

var A_arbace_test_tap_A_const_13 *lang.Var

var A_arbace_test_tap_A_const_14 *lang.Var

var A_arbace_test_tap_A_const_15 *jrt.Class

var A_arbace_test_tap_A_const_16 *lang.Var

var A_arbace_test_tap_A_const_17 *lang.Var

var A_arbace_test_tap_A_const_18 *lang.Var

var A_arbace_test_tap_A_const_19 *lang.Var

var A_arbace_test_tap_A_const_20 *lang.Var

var A_arbace_test_tap_A_const_21 *lang.Var

var A_arbace_test_tap_A_const_22 *lang.Var

var A_arbace_test_tap_A_const_23 *lang.Var

var A_arbace_test_tap_A_const_24 *lang.Var

var A_arbace_test_tap_A_const_25 *lang.Keyword

var A_arbace_test_tap_A_const_26 *lang.Keyword

var A_arbace_test_tap_A_const_27 *lang.Keyword

var A_arbace_test_tap_A_const_28 *lang.Var

var A_arbace_test_tap_A_const_29 *lang.Var

var A_arbace_test_tap_A_const_30 *lang.Keyword

var A_arbace_test_tap_A_const_31 *lang.Keyword

var A_arbace_test_tap_A_const_32 *lang.Var

var A_arbace_test_tap_A_const_33 *lang.Var

var A_arbace_test_tap_A_const_34 *lang.Var

var A_arbace_test_tap_A_const_35 *lang.Var

var A_arbace_test_tap_A_const_36 *lang.Var

var A_arbace_test_tap_A_const_37 *lang.Var

var A_arbace_test_tap_A_const_38 *lang.Var

var A_arbace_test_tap_A_const_39 *lang.Var

var A_arbace_test_tap_A_const_40 *lang.Var

var A_arbace_test_tap_A_const_41 *lang.Keyword

var A_arbace_test_tap_A_const_42 *lang.Keyword

var A_arbace_test_tap_A_const_43 *lang.Var

var A_arbace_test_tap_A_const_44 *lang.Var

var A_arbace_test_tap_A_const_45 *lang.Var

var A_arbace_test_tap_A_const_46 any

var A_arbace_test_tap_A_const_47 *lang.Var

var A_arbace_test_tap_A_const_48 *lang.Var

var A_arbace_test_tap_A_const_49 any

var A_arbace_test_tap_A_const_50 any

var A_arbace_test_tap_A_init jrt.ClassInit

func A_arbace_test_tap_A_Init() { if !A_arbace_test_tap_A_init.Done() { A_arbace_test_tap_A_init.Run(A_arbace_test_tap_A_clinit) } }

func A_arbace_test_tap_A_clinit() { A_arbace_test_tap_A_clinit_p0(); A_arbace_test_tap_A_clinit_p1(); A_arbace_test_tap_A_clinit_p2(); A_arbace_test_tap_A_clinit_p3(); A_arbace_test_tap_A_clinit_p4() }

func A_arbace_test_tap_A_clinit_p0() { jrt.StartCheck(); A_arbace_test_tap_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 69); A_arbace_test_tap_A_const_0 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[18]); A_arbace_test_tap_A_const_1 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[19]); A_arbace_test_tap_A_const_2 = A_arbace_test_tap_A_const_pool.A[20]; A_arbace_test_tap_A_const_3 = A_arbace_test_tap_A_const_pool.A[21]; A_arbace_test_tap_A_const_4 = A_arbace_test_tap_A_const_pool.A[22]; A_arbace_test_tap_A_const_5 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[23]); A_arbace_test_tap_A_const_6 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[24]); A_arbace_test_tap_A_const_7 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[25]); A_arbace_test_tap_A_const_8 = A_arbace_test_tap_A_const_pool.A[26]; A_arbace_test_tap_A_const_9 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[27]); A_arbace_test_tap_A_const_10 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[28]); A_arbace_test_tap_A_const_11 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[29]) }

func A_arbace_test_tap_A_clinit_p1() { A_arbace_test_tap_A_const_12 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[30]); A_arbace_test_tap_A_const_13 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[31]); A_arbace_test_tap_A_const_14 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[32]); A_arbace_test_tap_A_const_15 = jrt.Class_Cast(A_arbace_test_tap_A_const_pool.A[33]); A_arbace_test_tap_A_const_16 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[34]); A_arbace_test_tap_A_const_17 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[35]); A_arbace_test_tap_A_const_18 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[36]); A_arbace_test_tap_A_const_19 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[37]); A_arbace_test_tap_A_const_20 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[38]); A_arbace_test_tap_A_const_21 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[39]); A_arbace_test_tap_A_const_22 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[40]); A_arbace_test_tap_A_const_23 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[41]) }

func A_arbace_test_tap_A_clinit_p2() { A_arbace_test_tap_A_const_24 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[42]); A_arbace_test_tap_A_const_25 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[43]); A_arbace_test_tap_A_const_26 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[44]); A_arbace_test_tap_A_const_27 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[45]); A_arbace_test_tap_A_const_28 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[46]); A_arbace_test_tap_A_const_29 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[47]); A_arbace_test_tap_A_const_30 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[48]); A_arbace_test_tap_A_const_31 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[49]); A_arbace_test_tap_A_const_32 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[50]); A_arbace_test_tap_A_const_33 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[51]); A_arbace_test_tap_A_const_34 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[52]); A_arbace_test_tap_A_const_35 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[53]) }

func A_arbace_test_tap_A_clinit_p3() { A_arbace_test_tap_A_const_36 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[54]); A_arbace_test_tap_A_const_37 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[55]); A_arbace_test_tap_A_const_38 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[56]); A_arbace_test_tap_A_const_39 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[57]); A_arbace_test_tap_A_const_40 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[58]); A_arbace_test_tap_A_const_41 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[59]); A_arbace_test_tap_A_const_42 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[60]); A_arbace_test_tap_A_const_43 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[61]); A_arbace_test_tap_A_const_44 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[62]); A_arbace_test_tap_A_const_45 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[63]); A_arbace_test_tap_A_const_46 = A_arbace_test_tap_A_const_pool.A[64]; A_arbace_test_tap_A_const_47 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[65]) }

func A_arbace_test_tap_A_clinit_p4() { A_arbace_test_tap_A_const_48 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[66]); A_arbace_test_tap_A_const_49 = A_arbace_test_tap_A_const_pool.A[67]; A_arbace_test_tap_A_const_50 = A_arbace_test_tap_A_const_pool.A[68] }

func A_arbace_test_tap_A_New() *A_arbace_test_tap_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_A) Ctor() {}

func (t *A_arbace_test_tap_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_A_class }

func (t *A_arbace_test_tap_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_A); return ok }

func A_arbace_test_tap_A_Cast(x any) *A_arbace_test_tap_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_A_class)) }; return v }



type A_arbace_test_tap_eval1888000004_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000004_A_New() *A_arbace_test_tap_eval1888000004_A { t := &A_arbace_test_tap_eval1888000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000004_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000004_A_class }

func (t *A_arbace_test_tap_eval1888000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000004_A); return ok }

func A_arbace_test_tap_eval1888000004_A_Cast(x any) *A_arbace_test_tap_eval1888000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000004_A_class)) }; return v }



type A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000008_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000008_A_New() *A_arbace_test_tap_eval1888000008_A { t := &A_arbace_test_tap_eval1888000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000008_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000008_A_class }

func (t *A_arbace_test_tap_eval1888000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000008_A); return ok }

func A_arbace_test_tap_eval1888000008_A_Cast(x any) *A_arbace_test_tap_eval1888000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000008_A_class)) }; return v }



type A_arbace_test_tap_eval1888000008_fn__1888000009_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000022_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000022_A_New() *A_arbace_test_tap_eval1888000022_A { t := &A_arbace_test_tap_eval1888000022_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000022_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000022_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000022_A_class }

func (t *A_arbace_test_tap_eval1888000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000022_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000022_A); return ok }

func A_arbace_test_tap_eval1888000022_A_Cast(x any) *A_arbace_test_tap_eval1888000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000022_A_class)) }; return v }



type A_arbace_test_tap_eval1888000022_fn__1888000023_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000029_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000029_A_New() *A_arbace_test_tap_eval1888000029_A { t := &A_arbace_test_tap_eval1888000029_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000029_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000029_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000029_A_class }

func (t *A_arbace_test_tap_eval1888000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000029_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000029_A); return ok }

func A_arbace_test_tap_eval1888000029_A_Cast(x any) *A_arbace_test_tap_eval1888000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000029_A_class)) }; return v }



type A_arbace_test_tap_eval1888000029_fn__1888000030_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000033_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000033_A_New() *A_arbace_test_tap_eval1888000033_A { t := &A_arbace_test_tap_eval1888000033_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000033_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000033_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000033_A_class }

func (t *A_arbace_test_tap_eval1888000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000033_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000033_A); return ok }

func A_arbace_test_tap_eval1888000033_A_Cast(x any) *A_arbace_test_tap_eval1888000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000033_A_class)) }; return v }



type A_arbace_test_tap_eval1888000033_fn__1888000034_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000037_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000037_A_New() *A_arbace_test_tap_eval1888000037_A { t := &A_arbace_test_tap_eval1888000037_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000037_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000037_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000037_A_class }

func (t *A_arbace_test_tap_eval1888000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000037_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000037_A); return ok }

func A_arbace_test_tap_eval1888000037_A_Cast(x any) *A_arbace_test_tap_eval1888000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000037_A_class)) }; return v }



type A_arbace_test_tap_eval1888000037_fn__1888000038_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000041_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000041_A_New() *A_arbace_test_tap_eval1888000041_A { t := &A_arbace_test_tap_eval1888000041_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000041_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000041_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000041_A_class }

func (t *A_arbace_test_tap_eval1888000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000041_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000041_A); return ok }

func A_arbace_test_tap_eval1888000041_A_Cast(x any) *A_arbace_test_tap_eval1888000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000041_A_class)) }; return v }



type A_arbace_test_tap_eval1888000041_fn__1888000042_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class *jrt.Class



type A_arbace_test_tap_print_diagnostics_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_diagnostics_A_fn_class *jrt.Class



type A_arbace_test_tap_print_diagnostics_fn__1888000026_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_data any }

var A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_diagnostic_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_diagnostic_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_fail_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_fail_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_pass_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_pass_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_plan_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_plan_A_fn_class *jrt.Class



type A_arbace_test_tap_with_tap_output_A struct{ j2g_header uint64 }

var A_arbace_test_tap_with_tap_output_A_fn_class *jrt.Class
