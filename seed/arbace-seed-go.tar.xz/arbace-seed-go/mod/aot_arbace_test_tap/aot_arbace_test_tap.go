//line aot_arbace_test_tap.ae:1
package aot_arbace_test_tap

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_stacktrace"
	"arbace/aot_arbace_test"
	"arbace/jrt"
	"arbace/lang"
)










func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_New() *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Ctor() {}
//line :20:1
func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_test_tap_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_test_tap_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_tap_A_const_1, A_arbace_test_tap_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :20:1
func A_arbace_test_tap_eval1888000008_fn__1888000009_A_New() *A_arbace_test_tap_eval1888000008_fn__1888000009_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000008_fn__1888000009_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Ctor() {}
//line :20:1
func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_5.GetRawRoot__O()); var tmp2 any; var root_10 any = A_arbace_test_tap_A_const_6.GetRawRoot__O(); var linked_11 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_10, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_12 lang.IFn; if linked_11 == nil { ifn_12 = lang.IFn_Cast(root_10) } else { ifn_12 = nil }; var arg_13 any = A_arbace_test_tap_A_const_7; if linked_11 == nil { tmp2 = ifn_12.Invoke_O__O(arg_13) } else { tmp2 = linked_11.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_10, arg_13) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_test_tap_A_const_8.GetRawRoot__O(), A_arbace_test_tap_A_const_9) }





















func A_arbace_test_tap_print_tap_plan_A_New() *A_arbace_test_tap_print_tap_plan_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_plan_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_test_tap_print_tap_plan_A) Ctor() {}
//line :42:1
func (t *A_arbace_test_tap_print_tap_plan_A) Invoke_O_O__O(self, n__0 any) any {



	return lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__0)).Ref())
}
func A_arbace_test_tap_print_tap_diagnostic_A_New() *A_arbace_test_tap_print_tap_diagnostic_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_diagnostic_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_test_tap_print_tap_diagnostic_A) Ctor() {}
//line :48:1
func (t *A_arbace_test_tap_print_tap_diagnostic_A) Invoke_O_O__O(self, data__0 any) any { { var seq_1888000013__2 any; var root_24 any = A_arbace_test_tap_A_const_11.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_26 lang.IFn




	if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var tmp1 *jrt.Class = A_arbace_test_tap_A_const_12; var arg_27 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(data__0, tmp1, Lit_4, jrt.RefArrayOf(jrt.Object_class, Lit_5)); if linked_25 == nil { seq_1888000013__2 = ifn_26.Invoke_O__O(arg_27) } else { seq_1888000013__2 = linked_25.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_24, arg_27) }
//line :48:1
	var chunk_1888000014__3 any; var count_1888000015__4 int64 = 0; var i_1888000016__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1888000016__5, count_1888000015__4) { var line__6 any = lang.Indexed_Cast(chunk_1888000014__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1888000016__5))
			lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_6, line__6)
//line :53:1
			seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1888000016__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_28 any = A_arbace_test_tap_A_const_11.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = seq_1888000013__2; if linked_29 == nil { temp__1927000414__auto____6 = ifn_30.Invoke_O__O(arg_31) } else { temp__1927000414__auto____6 = linked_29.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_28, arg_31) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1888000013__7 any = temp__1927000414__auto____6; var tmp2 any; var root_32 any = A_arbace_test_tap_A_const_13.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = seq_1888000013__7; if linked_33 == nil { tmp2 = ifn_34.Invoke_O__O(arg_35) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____8 any; var root_36 any = A_arbace_test_tap_A_const_14.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = seq_1888000013__7; if linked_37 == nil { c__1927000678__auto____8 = ifn_38.Invoke_O__O(arg_39) } else { c__1927000678__auto____8 = linked_37.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_36, arg_39) }; var tmp3 any; var root_49 any = A_arbace_test_tap_A_const_16.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = seq_1888000013__7; if linked_50 == nil { tmp3 = ifn_51.Invoke_O__O(arg_52) } else { tmp3 = linked_50.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_49, arg_52) }; seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = tmp3, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var line__8 any; var root_40 any = A_arbace_test_tap_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = seq_1888000013__7; if linked_41 == nil { line__8 = ifn_42.Invoke_O__O(arg_43) } else { line__8 = linked_41.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_40, arg_43) }
				lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_6, line__8)
//line :53:1
				var tmp4 any; var root_58 any = A_arbace_test_tap_A_const_17.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = seq_1888000013__7; if linked_59 == nil { tmp4 = ifn_60.Invoke_O__O(arg_61) } else { tmp4 = linked_59.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_58, arg_61) }; seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = tmp4, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :48:1*/panic("j2g: unreachable") }







func A_arbace_test_tap_print_tap_pass_A_New() *A_arbace_test_tap_print_tap_pass_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_pass_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_test_tap_print_tap_pass_A) Ctor() {}
//line :56:1
func (t *A_arbace_test_tap_print_tap_pass_A) Invoke_O_O__O(self, msg__0 any) any {



	return lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_8, msg__0)
}
func A_arbace_test_tap_print_tap_fail_A_New() *A_arbace_test_tap_print_tap_fail_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_tap_fail_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_test_tap_print_tap_fail_A) Ctor() {}
//line :62:1
func (t *A_arbace_test_tap_print_tap_fail_A) Invoke_O_O__O(self, msg__0 any) any {



	return lang.IFn_Cast(A_arbace_test_tap_A_const_10.GetRawRoot__O()).Invoke_O_O__O(Lit_7, msg__0)
}



func A_arbace_test_tap_eval1888000022_fn__1888000023_A_New() *A_arbace_test_tap_eval1888000022_fn__1888000023_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000022_fn__1888000023_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Ctor() {}
//line :71:1
func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Invoke_O_O__O(self, data__1 any) any {
	var root_88 any = A_arbace_test_tap_A_const_21.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_23; var arg_91 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_24.Get__O()); if linked_89 == nil { ifn_90.Invoke_O__O(arg_91) } else { linked_89.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_88, arg_91) }
//line :71:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_76 any = A_arbace_test_tap_A_const_18.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, A_arbace_test_tap_print_tap_diagnostic_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke_O__O(data__1); if linked_77 == nil { tmp3 = ifn_78.Invoke_O__O(arg_79) } else { tmp3 = linked_77.(*A_arbace_test_tap_print_tap_diagnostic_A).Invoke_O_O__O(root_76, arg_79) } }
//line :71:1
		return nil }(); var root_80 any = A_arbace_test_tap_A_const_20.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_82 lang.IFn
	if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; if linked_81 == nil { ifn_82.Invoke__O() } else { linked_81.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_80) }
//line :71:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_tap_print_diagnostics_A_New() *A_arbace_test_tap_print_diagnostics_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_diagnostics_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_test_tap_print_diagnostics_A) Ctor() {}
//line :75:1
func (t *A_arbace_test_tap_print_diagnostics_A) Invoke_O_O__O(self, data__0 any) any {
	var tmp1 any; var root_130 any = A_arbace_test_tap_A_const_11.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = A_arbace_test_tap_A_const_32.Get__O(); if linked_131 == nil { tmp1 = ifn_132.Invoke_O__O(arg_133) } else { tmp1 = linked_131.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_130, arg_133) }; if jrt.J2g_Truth(tmp1) {
		var root_137 any = A_arbace_test_tap_A_const_18.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_test_tap_print_tap_diagnostic_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_134 any = A_arbace_test_tap_A_const_33.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_test.A_arbace_test_testing_contexts_str_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; if linked_135 == nil { arg_140 = ifn_136.Invoke__O() } else { arg_140 = linked_135.(*aot_arbace_test.A_arbace_test_testing_contexts_str_A).Invoke_O__O(root_134) }; if linked_138 == nil { ifn_139.Invoke_O__O(arg_140) } else { linked_138.(*A_arbace_test_tap_print_tap_diagnostic_A).Invoke_O_O__O(root_137, arg_140) } }
	if jrt.J2g_Truth(A_arbace_test_tap_A_const_34.Invoke_O__O(data__0)) {
		var root_141 any = A_arbace_test_tap_A_const_18.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_test_tap_print_tap_diagnostic_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = A_arbace_test_tap_A_const_34.Invoke_O__O(data__0); if linked_142 == nil { ifn_143.Invoke_O__O(arg_144) } else { linked_142.(*A_arbace_test_tap_print_tap_diagnostic_A).Invoke_O_O__O(root_141, arg_144) } }
	var root_149 any = A_arbace_test_tap_A_const_18.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_test_tap_print_tap_diagnostic_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_35.Invoke_O__O(data__0)))).Ref(); if linked_150 == nil { ifn_151.Invoke_O__O(arg_152) } else { linked_150.(*A_arbace_test_tap_print_tap_diagnostic_A).Invoke_O_O__O(root_149, arg_152) }
	var tmp2 any = A_arbace_test_tap_A_const_25; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_test_tap_A_const_26.Invoke_O__O(data__0)) {
		var root_96 any = A_arbace_test_tap_A_const_18.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_test_tap_print_tap_diagnostic_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_test_tap_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_27.Invoke_O__O(data__0)))).Ref(); if linked_97 == nil { return ifn_98.Invoke_O__O(arg_99) } else { return linked_97.(*A_arbace_test_tap_print_tap_diagnostic_A).Invoke_O_O__O(root_96, arg_99) } } else {

			var root_126 any = A_arbace_test_tap_A_const_18.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_test_tap_print_tap_diagnostic_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_2, nil); var tmp4 any; var s__1927001093__auto____4 any = jrt.StringWriter_New(); var root_122 any = A_arbace_test_tap_A_const_21.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_124 lang.IFn

			if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = lang.IFn_Cast(A_arbace_test_tap_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_tap_A_const_23, s__1927001093__auto____4); if linked_123 == nil { ifn_124.Invoke_O__O(arg_125) } else { linked_123.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_122, arg_125) }; var tmp5 any = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_New_O_O(s__1927001093__auto____4, data__0); var tmp6 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class = fncls__116d; tmp6 = fncls__116d } else { tmp6 = fncls__116 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :85:1
			arg_129 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :84:1
			if linked_127 == nil { return ifn_128.Invoke_O__O(arg_129) } else { return linked_127.(*A_arbace_test_tap_print_tap_diagnostic_A).Invoke_O_O__O(root_126, arg_129)
			} } }
func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_New_O_O(p0, p1 any) *A_arbace_test_tap_print_diagnostics_fn__1888000026_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_print_diagnostics_fn__1888000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Ctor_O_O(c__s__1927001093__auto__, c__data any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_data = c__data }
//line :86:1
func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												if jrt.Throwable_InstanceOf(A_arbace_test_tap_A_const_27.Invoke_O__O(t.F_data)) {
													var root_107 any = A_arbace_test_tap_A_const_29.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any; var tmp2 *lang.Keyword = A_arbace_test_tap_A_const_27; var tmp3 any; var t_ any = t.F_data; t.F_data = nil; tmp3 = t_; arg_110 = tmp2.Invoke_O__O(tmp3); var arg_111 any = A_arbace_test_tap_A_const_30.Get__O(); if linked_108 == nil { ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { linked_108.(*aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) } } else {
														var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_31.GetRawRoot__O()); var tmp5 *lang.Keyword = A_arbace_test_tap_A_const_27; var tmp6 any; var t__2 any = t.F_data; t.F_data = nil; tmp6 = t__2; tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6)) }
//line :86:1
	{ var root_100 any = A_arbace_test_tap_A_const_28.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_103 = t__3; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_100, arg_103) } }; return nil }(); var root_104 any = A_arbace_test_tap_A_const_20.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; if linked_105 == nil { ifn_106.Invoke__O() } else { linked_105.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_104) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }




func A_arbace_test_tap_eval1888000029_fn__1888000030_A_New() *A_arbace_test_tap_eval1888000029_fn__1888000030_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000029_fn__1888000030_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Ctor() {}
//line :91:1
func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Invoke_O_O__O(self, data__1 any) any {
	var root_165 any = A_arbace_test_tap_A_const_21.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_23; var arg_168 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_24.Get__O()); if linked_166 == nil { ifn_167.Invoke_O__O(arg_168) } else { linked_166.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_165, arg_168) }
//line :91:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_169 any = A_arbace_test_tap_A_const_37.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_test.A_arbace_test_inc_report_counter_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = A_arbace_test_tap_A_const_25; if linked_170 == nil { ifn_171.Invoke_O__O(arg_172) } else { linked_170.(*aot_arbace_test.A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_169, arg_172) }
			var root_177 any = A_arbace_test_tap_A_const_38.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_test_tap_print_tap_pass_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var root_173 any = A_arbace_test_tap_A_const_39.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_test.A_arbace_test_testing_vars_str_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = data__1; if linked_174 == nil { arg_180 = ifn_175.Invoke_O__O(arg_176) } else { arg_180 = linked_174.(*aot_arbace_test.A_arbace_test_testing_vars_str_A).Invoke_O_O__O(root_173, arg_176) }; if linked_178 == nil { ifn_179.Invoke_O__O(arg_180) } else { linked_178.(*A_arbace_test_tap_print_tap_pass_A).Invoke_O_O__O(root_177, arg_180) }
			var root_153 any = A_arbace_test_tap_A_const_36.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_test_tap_print_diagnostics_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = data__1; if linked_154 == nil { tmp3 = ifn_155.Invoke_O__O(arg_156) } else { tmp3 = linked_154.(*A_arbace_test_tap_print_diagnostics_A).Invoke_O_O__O(root_153, arg_156) } }
//line :91:1
		return nil }(); var root_157 any = A_arbace_test_tap_A_const_20.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_159 lang.IFn
	if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; if linked_158 == nil { ifn_159.Invoke__O() } else { linked_158.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_157) }
//line :91:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}




func A_arbace_test_tap_eval1888000033_fn__1888000034_A_New() *A_arbace_test_tap_eval1888000033_fn__1888000034_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000033_fn__1888000034_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Ctor() {}
//line :97:1
func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Invoke_O_O__O(self, data__1 any) any {
	var root_193 any = A_arbace_test_tap_A_const_21.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_23; var arg_196 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_24.Get__O()); if linked_194 == nil { ifn_195.Invoke_O__O(arg_196) } else { linked_194.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_193, arg_196) }
//line :97:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_197 any = A_arbace_test_tap_A_const_37.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_test.A_arbace_test_inc_report_counter_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = A_arbace_test_tap_A_const_40; if linked_198 == nil { ifn_199.Invoke_O__O(arg_200) } else { linked_198.(*aot_arbace_test.A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_197, arg_200) }
			var root_205 any = A_arbace_test_tap_A_const_41.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, A_arbace_test_tap_print_tap_fail_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any; var root_201 any = A_arbace_test_tap_A_const_39.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_test.A_arbace_test_testing_vars_str_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = data__1; if linked_202 == nil { arg_208 = ifn_203.Invoke_O__O(arg_204) } else { arg_208 = linked_202.(*aot_arbace_test.A_arbace_test_testing_vars_str_A).Invoke_O_O__O(root_201, arg_204) }; if linked_206 == nil { ifn_207.Invoke_O__O(arg_208) } else { linked_206.(*A_arbace_test_tap_print_tap_fail_A).Invoke_O_O__O(root_205, arg_208) }
			var root_181 any = A_arbace_test_tap_A_const_36.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, A_arbace_test_tap_print_diagnostics_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = data__1; if linked_182 == nil { tmp3 = ifn_183.Invoke_O__O(arg_184) } else { tmp3 = linked_182.(*A_arbace_test_tap_print_diagnostics_A).Invoke_O_O__O(root_181, arg_184) } }
//line :97:1
		return nil }(); var root_185 any = A_arbace_test_tap_A_const_20.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_187 lang.IFn
	if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; if linked_186 == nil { ifn_187.Invoke__O() } else { linked_186.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_185) }
//line :97:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}




func A_arbace_test_tap_eval1888000037_fn__1888000038_A_New() *A_arbace_test_tap_eval1888000037_fn__1888000038_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000037_fn__1888000038_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Ctor() {}
//line :103:1
func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Invoke_O_O__O(self, data__1 any) any {
	var root_221 any = A_arbace_test_tap_A_const_21.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_23; var arg_224 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_24.Get__O()); if linked_222 == nil { ifn_223.Invoke_O__O(arg_224) } else { linked_222.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_221, arg_224) }
//line :103:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_225 any = A_arbace_test_tap_A_const_37.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_test.A_arbace_test_inc_report_counter_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = A_arbace_test_tap_A_const_42; if linked_226 == nil { ifn_227.Invoke_O__O(arg_228) } else { linked_226.(*aot_arbace_test.A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_225, arg_228) }
			var root_233 any = A_arbace_test_tap_A_const_41.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, A_arbace_test_tap_print_tap_fail_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var root_229 any = A_arbace_test_tap_A_const_39.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_test.A_arbace_test_testing_vars_str_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = data__1; if linked_230 == nil { arg_236 = ifn_231.Invoke_O__O(arg_232) } else { arg_236 = linked_230.(*aot_arbace_test.A_arbace_test_testing_vars_str_A).Invoke_O_O__O(root_229, arg_232) }; if linked_234 == nil { ifn_235.Invoke_O__O(arg_236) } else { linked_234.(*A_arbace_test_tap_print_tap_fail_A).Invoke_O_O__O(root_233, arg_236) }
			var root_209 any = A_arbace_test_tap_A_const_36.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, A_arbace_test_tap_print_diagnostics_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = data__1; if linked_210 == nil { tmp3 = ifn_211.Invoke_O__O(arg_212) } else { tmp3 = linked_210.(*A_arbace_test_tap_print_diagnostics_A).Invoke_O_O__O(root_209, arg_212) } }
//line :103:1
		return nil }(); var root_213 any = A_arbace_test_tap_A_const_20.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_215 lang.IFn
	if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; if linked_214 == nil { ifn_215.Invoke__O() } else { linked_214.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_213) }
//line :103:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}




func A_arbace_test_tap_eval1888000041_fn__1888000042_A_New() *A_arbace_test_tap_eval1888000041_fn__1888000042_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_eval1888000041_fn__1888000042_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Ctor() {}
//line :109:1
func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Invoke_O_O__O(self, data__1 any) any {
	var root_259 any = A_arbace_test_tap_A_const_21.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_test_tap_A_const_23; var arg_262 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_tap_A_const_24.Get__O()); if linked_260 == nil { ifn_261.Invoke_O__O(arg_262) } else { linked_260.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_259, arg_262) }
//line :109:1
	var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_247 any = A_arbace_test_tap_A_const_43.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, A_arbace_test_tap_print_tap_plan_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any; var na_237 any; var na_239 any = A_arbace_test_tap_A_const_25.Invoke_O__O(data__1); var na_240 any = A_arbace_test_tap_A_const_42.Invoke_O__O(data__1); var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_239); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_240) }; tmp4 = tmp5; if tmp4 { var n0_241 int64 = jrt.NN(jrt.Long_Cast(na_239)).LongValue__J(); var n1_242 int64 = jrt.NN(jrt.Long_Cast(na_240)).LongValue__J(); var nr_243 int64 = n0_241 + n1_242; if (n0_241^nr_243)&(n1_242^nr_243) >= 0 { na_237 = jrt.Long_ValueOf_J__Long_NoInit(nr_243).Ref() } else { na_237 = lang.Numbers_Add_O_O__Number_NoInit(na_239, na_240) } } else { var tmp6 bool; var tmp7 bool; tmp7 = jrt.Double_InstanceOf(na_239); if tmp7 { tmp7 = jrt.Double_InstanceOf(na_240) }; tmp6 = tmp7; if tmp6 { var n0_241_2 float64 = jrt.NN(jrt.Double_Cast(na_239)).DoubleValue__D(); var n1_242_2 float64 = jrt.NN(jrt.Double_Cast(na_240)).DoubleValue__D(); na_237 = jrt.Double_ValueOf_D__Double_NoInit(n0_241_2 + n1_242_2).Ref() } else { na_237 = lang.Numbers_Add_O_O__Number_NoInit(na_239, na_240) } }; var na_238 any = A_arbace_test_tap_A_const_40.Invoke_O__O(data__1); var tmp8 bool; var tmp9 bool; tmp9 = jrt.Long_InstanceOf(na_237); if tmp9 { tmp9 = jrt.Long_InstanceOf(na_238) }; tmp8 = tmp9; if tmp8 { var n0_244 int64 = jrt.NN(jrt.Long_Cast(na_237)).LongValue__J(); var n1_245 int64 = jrt.NN(jrt.Long_Cast(na_238)).LongValue__J(); var nr_246 int64 = n0_244 + n1_245; if (n0_244^nr_246)&(n1_245^nr_246) >= 0 { arg_250 = jrt.Long_ValueOf_J__Long_NoInit(nr_246).Ref() } else { arg_250 = lang.Numbers_Add_O_O__Number_NoInit(na_237, na_238) } } else { var tmp10 bool; var tmp11 bool; tmp11 = jrt.Double_InstanceOf(na_237); if tmp11 { tmp11 = jrt.Double_InstanceOf(na_238) }; tmp10 = tmp11; if tmp10 { var n0_244_2 float64 = jrt.NN(jrt.Double_Cast(na_237)).DoubleValue__D(); var n1_245_2 float64 = jrt.NN(jrt.Double_Cast(na_238)).DoubleValue__D(); arg_250 = jrt.Double_ValueOf_D__Double_NoInit(n0_244_2 + n1_245_2).Ref() } else { arg_250 = lang.Numbers_Add_O_O__Number_NoInit(na_237, na_238) } }; if linked_248 == nil { tmp3 = ifn_249.Invoke_O__O(arg_250) } else { tmp3 = linked_248.(*A_arbace_test_tap_print_tap_plan_A).Invoke_O_O__O(root_247, arg_250) } }
//line :109:1
		return nil }(); var root_251 any = A_arbace_test_tap_A_const_20.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_253 lang.IFn
	if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; if linked_252 == nil { ifn_253.Invoke__O() } else { linked_252.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_251) }
//line :109:1
	if tmp12 != nil { panic(tmp12) }; return tmp3
}


func A_arbace_test_tap_with_tap_output_A_New() *A_arbace_test_tap_with_tap_output_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_with_tap_output_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_test_tap_with_tap_output_A) Ctor() {}
//line :113:1
func (t *A_arbace_test_tap_with_tap_output_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_283 any = A_arbace_test_tap_A_const_11.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_44.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_46); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()); var tmp4 any; var root_272 any = A_arbace_test_tap_A_const_47.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = A_arbace_test_tap_A_const_48.GetRawRoot__O(); var arg_276 any; var root_268 any = A_arbace_test_tap_A_const_11.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any; var root_263 any = A_arbace_test_tap_A_const_44.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_49); var arg_267 any = lang.IFn_Cast(A_arbace_test_tap_A_const_45.GetRawRoot__O()).Invoke_O__O(A_arbace_test_tap_A_const_50); if linked_264 == nil { arg_271 = ifn_265.Invoke_O_O__O(arg_266, arg_267) } else { arg_271 = linked_264.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_263, arg_266, arg_267) }; if linked_269 == nil { arg_276 = ifn_270.Invoke_O__O(arg_271) } else { arg_276 = linked_269.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_268, arg_271) }; if linked_273 == nil { tmp4 = ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { tmp4 = linked_273.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_272, arg_275, arg_276) }; arg_286 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__2); if linked_284 == nil { return ifn_285.Invoke_O__O(arg_286) } else { return linked_284.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_283, arg_286) } }









type A_arbace_test_tap_A struct{ jrt.Object }

var A_arbace_test_tap_A_const_pool *jrt.RefArray

var A_arbace_test_tap_A_const_0 *lang.Var

var A_arbace_test_tap_A_const_1 any

var A_arbace_test_tap_A_const_2 any

var A_arbace_test_tap_A_const_3 *lang.Var

var A_arbace_test_tap_A_const_4 any

var A_arbace_test_tap_A_const_5 *lang.Var

var A_arbace_test_tap_A_const_6 *lang.Var

var A_arbace_test_tap_A_const_7 *lang.Var

var A_arbace_test_tap_A_const_8 *lang.Var

var A_arbace_test_tap_A_const_9 any

var A_arbace_test_tap_A_const_10 *lang.Var

var A_arbace_test_tap_A_const_11 *lang.Var

var A_arbace_test_tap_A_const_12 *jrt.Class

var A_arbace_test_tap_A_const_13 *lang.Var

var A_arbace_test_tap_A_const_14 *lang.Var

var A_arbace_test_tap_A_const_15 *lang.Var

var A_arbace_test_tap_A_const_16 *lang.Var

var A_arbace_test_tap_A_const_17 *lang.Var

var A_arbace_test_tap_A_const_18 *lang.Var

var A_arbace_test_tap_A_const_19 *lang.Var

var A_arbace_test_tap_A_const_20 *lang.Var

var A_arbace_test_tap_A_const_21 *lang.Var

var A_arbace_test_tap_A_const_22 *lang.Var

var A_arbace_test_tap_A_const_23 *lang.Var

var A_arbace_test_tap_A_const_24 *lang.Var

var A_arbace_test_tap_A_const_25 *lang.Keyword

var A_arbace_test_tap_A_const_26 *lang.Keyword

var A_arbace_test_tap_A_const_27 *lang.Keyword

var A_arbace_test_tap_A_const_28 *lang.Var

var A_arbace_test_tap_A_const_29 *lang.Var

var A_arbace_test_tap_A_const_30 *lang.Var

var A_arbace_test_tap_A_const_31 *lang.Var

var A_arbace_test_tap_A_const_32 *lang.Var

var A_arbace_test_tap_A_const_33 *lang.Var

var A_arbace_test_tap_A_const_34 *lang.Keyword

var A_arbace_test_tap_A_const_35 *lang.Keyword

var A_arbace_test_tap_A_const_36 *lang.Var

var A_arbace_test_tap_A_const_37 *lang.Var

var A_arbace_test_tap_A_const_38 *lang.Var

var A_arbace_test_tap_A_const_39 *lang.Var

var A_arbace_test_tap_A_const_40 *lang.Keyword

var A_arbace_test_tap_A_const_41 *lang.Var

var A_arbace_test_tap_A_const_42 *lang.Keyword

var A_arbace_test_tap_A_const_43 *lang.Var

var A_arbace_test_tap_A_const_44 *lang.Var

var A_arbace_test_tap_A_const_45 *lang.Var

var A_arbace_test_tap_A_const_46 any

var A_arbace_test_tap_A_const_47 *lang.Var

var A_arbace_test_tap_A_const_48 *lang.Var

var A_arbace_test_tap_A_const_49 any

var A_arbace_test_tap_A_const_50 any

var A_arbace_test_tap_A_init jrt.ClassInit

func A_arbace_test_tap_A_Init() { if !A_arbace_test_tap_A_init.Done() { A_arbace_test_tap_A_init.Run(A_arbace_test_tap_A_clinit) } }

func A_arbace_test_tap_A_clinit() { A_arbace_test_tap_A_clinit_p0(); A_arbace_test_tap_A_clinit_p1(); A_arbace_test_tap_A_clinit_p2(); A_arbace_test_tap_A_clinit_p3(); A_arbace_test_tap_A_clinit_p4() }

func A_arbace_test_tap_A_clinit_p0() { jrt.StartCheck(); A_arbace_test_tap_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 69); A_arbace_test_tap_A_const_0 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[18]); A_arbace_test_tap_A_const_1 = A_arbace_test_tap_A_const_pool.A[19]; A_arbace_test_tap_A_const_2 = A_arbace_test_tap_A_const_pool.A[20]; A_arbace_test_tap_A_const_3 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[21]); A_arbace_test_tap_A_const_4 = A_arbace_test_tap_A_const_pool.A[22]; A_arbace_test_tap_A_const_5 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[23]); A_arbace_test_tap_A_const_6 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[24]); A_arbace_test_tap_A_const_7 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[25]); A_arbace_test_tap_A_const_8 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[26]); A_arbace_test_tap_A_const_9 = A_arbace_test_tap_A_const_pool.A[27]; A_arbace_test_tap_A_const_10 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[28]); A_arbace_test_tap_A_const_11 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[29]) }

func A_arbace_test_tap_A_clinit_p1() { A_arbace_test_tap_A_const_12 = jrt.Class_Cast(A_arbace_test_tap_A_const_pool.A[30]); A_arbace_test_tap_A_const_13 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[31]); A_arbace_test_tap_A_const_14 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[32]); A_arbace_test_tap_A_const_15 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[33]); A_arbace_test_tap_A_const_16 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[34]); A_arbace_test_tap_A_const_17 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[35]); A_arbace_test_tap_A_const_18 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[36]); A_arbace_test_tap_A_const_19 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[37]); A_arbace_test_tap_A_const_20 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[38]); A_arbace_test_tap_A_const_21 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[39]); A_arbace_test_tap_A_const_22 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[40]); A_arbace_test_tap_A_const_23 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[41]) }

func A_arbace_test_tap_A_clinit_p2() { A_arbace_test_tap_A_const_24 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[42]); A_arbace_test_tap_A_const_25 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[43]); A_arbace_test_tap_A_const_26 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[44]); A_arbace_test_tap_A_const_27 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[45]); A_arbace_test_tap_A_const_28 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[46]); A_arbace_test_tap_A_const_29 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[47]); A_arbace_test_tap_A_const_30 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[48]); A_arbace_test_tap_A_const_31 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[49]); A_arbace_test_tap_A_const_32 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[50]); A_arbace_test_tap_A_const_33 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[51]); A_arbace_test_tap_A_const_34 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[52]); A_arbace_test_tap_A_const_35 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[53]) }

func A_arbace_test_tap_A_clinit_p3() { A_arbace_test_tap_A_const_36 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[54]); A_arbace_test_tap_A_const_37 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[55]); A_arbace_test_tap_A_const_38 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[56]); A_arbace_test_tap_A_const_39 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[57]); A_arbace_test_tap_A_const_40 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[58]); A_arbace_test_tap_A_const_41 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[59]); A_arbace_test_tap_A_const_42 = lang.Keyword_Cast(A_arbace_test_tap_A_const_pool.A[60]); A_arbace_test_tap_A_const_43 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[61]); A_arbace_test_tap_A_const_44 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[62]); A_arbace_test_tap_A_const_45 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[63]); A_arbace_test_tap_A_const_46 = A_arbace_test_tap_A_const_pool.A[64]; A_arbace_test_tap_A_const_47 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[65]) }

func A_arbace_test_tap_A_clinit_p4() { A_arbace_test_tap_A_const_48 = lang.Var_Cast(A_arbace_test_tap_A_const_pool.A[66]); A_arbace_test_tap_A_const_49 = A_arbace_test_tap_A_const_pool.A[67]; A_arbace_test_tap_A_const_50 = A_arbace_test_tap_A_const_pool.A[68] }

func A_arbace_test_tap_A_New() *A_arbace_test_tap_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_A) Ctor() {}

func (t *A_arbace_test_tap_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_A_class }

func (t *A_arbace_test_tap_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_A); return ok }

func A_arbace_test_tap_A_Cast(x any) *A_arbace_test_tap_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_A_class)) }; return v }



type A_arbace_test_tap_eval1888000004_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000004_A_New() *A_arbace_test_tap_eval1888000004_A { t := &A_arbace_test_tap_eval1888000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000004_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000004_A_class }

func (t *A_arbace_test_tap_eval1888000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000004_A); return ok }

func A_arbace_test_tap_eval1888000004_A_Cast(x any) *A_arbace_test_tap_eval1888000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000004_A_class)) }; return v }



type A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000008_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000008_A_New() *A_arbace_test_tap_eval1888000008_A { t := &A_arbace_test_tap_eval1888000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000008_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000008_A_class }

func (t *A_arbace_test_tap_eval1888000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000008_A); return ok }

func A_arbace_test_tap_eval1888000008_A_Cast(x any) *A_arbace_test_tap_eval1888000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000008_A_class)) }; return v }



type A_arbace_test_tap_eval1888000008_fn__1888000009_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000022_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000022_A_New() *A_arbace_test_tap_eval1888000022_A { t := &A_arbace_test_tap_eval1888000022_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000022_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000022_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000022_A_class }

func (t *A_arbace_test_tap_eval1888000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000022_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000022_A); return ok }

func A_arbace_test_tap_eval1888000022_A_Cast(x any) *A_arbace_test_tap_eval1888000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000022_A_class)) }; return v }



type A_arbace_test_tap_eval1888000022_fn__1888000023_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000029_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000029_A_New() *A_arbace_test_tap_eval1888000029_A { t := &A_arbace_test_tap_eval1888000029_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000029_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000029_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000029_A_class }

func (t *A_arbace_test_tap_eval1888000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000029_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000029_A); return ok }

func A_arbace_test_tap_eval1888000029_A_Cast(x any) *A_arbace_test_tap_eval1888000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000029_A_class)) }; return v }



type A_arbace_test_tap_eval1888000029_fn__1888000030_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000033_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000033_A_New() *A_arbace_test_tap_eval1888000033_A { t := &A_arbace_test_tap_eval1888000033_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000033_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000033_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000033_A_class }

func (t *A_arbace_test_tap_eval1888000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000033_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000033_A); return ok }

func A_arbace_test_tap_eval1888000033_A_Cast(x any) *A_arbace_test_tap_eval1888000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000033_A_class)) }; return v }



type A_arbace_test_tap_eval1888000033_fn__1888000034_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000037_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000037_A_New() *A_arbace_test_tap_eval1888000037_A { t := &A_arbace_test_tap_eval1888000037_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000037_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000037_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000037_A_class }

func (t *A_arbace_test_tap_eval1888000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000037_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000037_A); return ok }

func A_arbace_test_tap_eval1888000037_A_Cast(x any) *A_arbace_test_tap_eval1888000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000037_A_class)) }; return v }



type A_arbace_test_tap_eval1888000037_fn__1888000038_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class *jrt.Class



type A_arbace_test_tap_eval1888000041_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000041_A_New() *A_arbace_test_tap_eval1888000041_A { t := &A_arbace_test_tap_eval1888000041_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000041_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000041_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000041_A_class }

func (t *A_arbace_test_tap_eval1888000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000041_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000041_A); return ok }

func A_arbace_test_tap_eval1888000041_A_Cast(x any) *A_arbace_test_tap_eval1888000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000041_A_class)) }; return v }



type A_arbace_test_tap_eval1888000041_fn__1888000042_A struct{ j2g_header uint64 }

var A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class *jrt.Class



type A_arbace_test_tap_print_diagnostics_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_diagnostics_A_fn_class *jrt.Class



type A_arbace_test_tap_print_diagnostics_fn__1888000026_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_data any }

var A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_diagnostic_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_diagnostic_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_fail_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_fail_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_pass_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_pass_A_fn_class *jrt.Class



type A_arbace_test_tap_print_tap_plan_A struct{ j2g_header uint64 }

var A_arbace_test_tap_print_tap_plan_A_fn_class *jrt.Class



type A_arbace_test_tap_with_tap_output_A struct{ j2g_header uint64 }

var A_arbace_test_tap_with_tap_output_A_fn_class *jrt.Class
