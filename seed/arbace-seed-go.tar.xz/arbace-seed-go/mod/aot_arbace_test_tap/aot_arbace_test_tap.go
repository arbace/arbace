//line aot_arbace_test_tap.ae:1
package aot_arbace_test_tap

import (
	"arbace/jrt"
	"arbace/lang"
)













func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_New() *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A { A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_Init(); t := &A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Ctor() {}
//line :20:1
func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_test_tap_A_Init(); tmp4 = A_arbace_test_tap_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_test_tap_A_Init(); tmp6 = A_arbace_test_tap_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_4; tmp3 = tmp8.Invoke_O_O__O(tmp10, tmp11) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :20:1
func A_arbace_test_tap_eval1888000008_fn__1888000009_A_New() *A_arbace_test_tap_eval1888000008_fn__1888000009_A { A_arbace_test_tap_eval1888000008_fn__1888000009_A_Init(); t := &A_arbace_test_tap_eval1888000008_fn__1888000009_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Ctor() {}
//line :20:1
func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }





















func A_arbace_test_tap_print_tap_plan_A_New() *A_arbace_test_tap_print_tap_plan_A { A_arbace_test_tap_print_tap_plan_A_Init(); t := &A_arbace_test_tap_print_tap_plan_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_test_tap_print_tap_plan_A) Ctor() {}
//line :42:1
func (t *A_arbace_test_tap_print_tap_plan_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_78, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__0)).Ref())
}
func A_arbace_test_tap_print_tap_diagnostic_A_New() *A_arbace_test_tap_print_tap_diagnostic_A { A_arbace_test_tap_print_tap_diagnostic_A_Init(); t := &A_arbace_test_tap_print_tap_diagnostic_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_test_tap_print_tap_diagnostic_A) Ctor() {}
//line :48:1
func (t *A_arbace_test_tap_print_tap_diagnostic_A) Invoke_O_O__O(self, data__0 any) any { { var seq_1888000013__2 any; var tmp1 *lang.Var




	A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_15; var tmp4 *jrt.Class = tmp3; seq_1888000013__2 = tmp2.Invoke_O__O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(data__0, tmp4, Lit_70, jrt.RefArrayOf(jrt.Object_class, Lit_71)))
//line :48:1
	var chunk_1888000014__3 any; var count_1888000015__4 int64 = 0; var i_1888000016__5 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z(i_1888000016__5, count_1888000015__4) { var line__6 any = lang.Indexed_Cast(chunk_1888000014__3).Nth_I__O(lang.RT_IntCast_J__I(i_1888000016__5)); var tmp5 *lang.Var
			A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_10; lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(Lit_72, line__6)
//line :53:1
			seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, lang.Numbers_Unchecked_inc_J__J(i_1888000016__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp6 *lang.Var; A_arbace_test_tap_A_Init(); tmp6 = A_arbace_test_tap_A_const_11; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_1888000013__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1888000013__7 any = temp__1927000414__auto____6; var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_12; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_1888000013__7)) { var c__1927000678__auto____8 any; var tmp8 *lang.Var; A_arbace_test_tap_A_Init(); tmp8 = A_arbace_test_tap_A_const_13; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_1888000013__7); var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_16; seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_1888000013__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var line__8 any; var tmp10 *lang.Var; A_arbace_test_tap_A_Init(); tmp10 = A_arbace_test_tap_A_const_14; line__8 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_1888000013__7)
				var tmp11 *lang.Var; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_10; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(Lit_72, line__8)
//line :53:1
				var tmp12 *lang.Var; A_arbace_test_tap_A_Init(); tmp12 = A_arbace_test_tap_A_const_17; seq_1888000013__2, chunk_1888000014__3, count_1888000015__4, i_1888000016__5 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_1888000013__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :48:1*/panic("a2g: unreachable") }







func A_arbace_test_tap_print_tap_pass_A_New() *A_arbace_test_tap_print_tap_pass_A { A_arbace_test_tap_print_tap_pass_A_Init(); t := &A_arbace_test_tap_print_tap_pass_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_test_tap_print_tap_pass_A) Ctor() {}
//line :56:1
func (t *A_arbace_test_tap_print_tap_pass_A) Invoke_O_O__O(self, msg__0 any) any {



	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(Lit_76, msg__0)
}
func A_arbace_test_tap_print_tap_fail_A_New() *A_arbace_test_tap_print_tap_fail_A { A_arbace_test_tap_print_tap_fail_A_Init(); t := &A_arbace_test_tap_print_tap_fail_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_test_tap_print_tap_fail_A) Ctor() {}
//line :62:1
func (t *A_arbace_test_tap_print_tap_fail_A) Invoke_O_O__O(self, msg__0 any) any {



	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(Lit_74, msg__0)
}



func A_arbace_test_tap_eval1888000022_fn__1888000023_A_New() *A_arbace_test_tap_eval1888000022_fn__1888000023_A { A_arbace_test_tap_eval1888000022_fn__1888000023_A_Init(); t := &A_arbace_test_tap_eval1888000022_fn__1888000023_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Ctor() {}
//line :71:1
func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_22; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_23; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :71:1
	var tmp8 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_18; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_24; tmp8 = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(data__1)) }
//line :71:1
		return nil }(); var tmp13 *lang.Var
	A_arbace_test_tap_A_Init(); tmp13 = A_arbace_test_tap_A_const_19; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke__O()
//line :71:1
	if tmp12 != nil { panic(tmp12) }; return tmp8
}


func A_arbace_test_tap_print_diagnostics_A_New() *A_arbace_test_tap_print_diagnostics_A { A_arbace_test_tap_print_diagnostics_A_Init(); t := &A_arbace_test_tap_print_diagnostics_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_test_tap_print_diagnostics_A) Ctor() {}
//line :75:1
func (t *A_arbace_test_tap_print_diagnostics_A) Invoke_O_O__O(self, data__0 any) any {
	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_28; if jrt.A2g_Truth(tmp2.Invoke_O__O(jrt.NN(tmp3).Get__O())) {
		var tmp4 *lang.Var; A_arbace_test_tap_A_Init(); tmp4 = A_arbace_test_tap_A_const_18; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_test_tap_A_Init(); tmp6 = A_arbace_test_tap_A_const_29; tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O()) }
	var tmp7 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_27; if jrt.A2g_Truth(jrt.NN(tmp7).Invoke_O__O(data__0)) {
		var tmp8 *lang.Var; A_arbace_test_tap_A_Init(); tmp8 = A_arbace_test_tap_A_const_18; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp10 = A_arbace_test_tap_A_const_27; tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(data__0)) }
	var tmp11 *lang.Var; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_18; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp14 *lang.Var; A_arbace_test_tap_A_Init(); tmp14 = A_arbace_test_tap_A_const_24; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp16 = A_arbace_test_tap_A_const_30; tmp12.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp15.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(data__0)))).Ref())
	var tmp17 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp17 = A_arbace_test_tap_A_const_25; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp19 = A_arbace_test_tap_A_const_26; if lang.Util_Equiv_O_O__Z(tmp18, jrt.NN(tmp19).Invoke_O__O(data__0)) {
		var tmp20 *lang.Var; A_arbace_test_tap_A_Init(); tmp20 = A_arbace_test_tap_A_const_18; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp23 *lang.Var; A_arbace_test_tap_A_Init(); tmp23 = A_arbace_test_tap_A_const_24; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp25 = A_arbace_test_tap_A_const_31; return tmp21.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp24.Invoke_O__O(jrt.NN(tmp25).Invoke_O__O(data__0)))).Ref()) } else {

			var tmp26 *lang.Var; A_arbace_test_tap_A_Init(); tmp26 = A_arbace_test_tap_A_const_18; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp29 any; var s__1927001093__auto____4 any = jrt.StringWriter_New(); var tmp30 *lang.Var

			A_arbace_test_tap_A_Init(); tmp30 = A_arbace_test_tap_A_const_20; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_test_tap_A_Init(); tmp32 = A_arbace_test_tap_A_const_21; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_test_tap_A_Init(); tmp34 = A_arbace_test_tap_A_const_22; tmp31.Invoke_O__O(tmp33.Invoke_O_O__O(tmp34.Ref(), s__1927001093__auto____4)); var tmp35 any = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_New_O_O(s__1927001093__auto____4, data__0); var tmp36 *jrt.Class; A_arbace_test_tap_print_diagnostics_fn__1888000026_A_Init(); tmp36 = A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class; tmp29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil).Invoke__O()
//line :84:1
			return tmp27.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp28, jrt.RefArrayOf(jrt.Object_class, nil, tmp29)).Ref())
		} }
func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_New_O_O(p0, p1 any) *A_arbace_test_tap_print_diagnostics_fn__1888000026_A { A_arbace_test_tap_print_diagnostics_fn__1888000026_A_Init(); t := &A_arbace_test_tap_print_diagnostics_fn__1888000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Ctor_O_O(c__s__1927001093__auto__, c__data any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_data = c__data }
//line :86:1
func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Invoke_O__O(self any) any { var tmp1 any; tmp18 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp2 = A_arbace_test_tap_A_const_31; if jrt.Throwable_InstanceOf(jrt.NN(tmp2).Invoke_O__O(t.F_data)) {
													var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_33; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_31; var tmp6 *lang.Keyword = tmp5; var tmp7 any; var t_ any = t.F_data; t.F_data = nil; tmp7 = t_; var tmp8 any = jrt.NN(tmp6).Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_35; tmp4.Invoke_O_O__O(tmp8, jrt.NN(tmp9).Get__O()) } else {
														var tmp10 *lang.Var; A_arbace_test_tap_A_Init(); tmp10 = A_arbace_test_tap_A_const_34; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp12 = A_arbace_test_tap_A_const_31; var tmp13 *lang.Keyword = tmp12; var tmp14 any; var t__2 any = t.F_data; t.F_data = nil; tmp14 = t__2; tmp11.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(tmp14)) }
//line :86:1
		var tmp15 *lang.Var; A_arbace_test_tap_A_Init(); tmp15 = A_arbace_test_tap_A_const_32; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp17 = t__3; tmp1 = tmp16.Invoke_O__O(tmp17) }; return nil }(); var tmp19 *lang.Var; A_arbace_test_tap_A_Init(); tmp19 = A_arbace_test_tap_A_const_19; lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke__O(); if tmp18 != nil { panic(tmp18) }; return tmp1 }




func A_arbace_test_tap_eval1888000029_fn__1888000030_A_New() *A_arbace_test_tap_eval1888000029_fn__1888000030_A { A_arbace_test_tap_eval1888000029_fn__1888000030_A_Init(); t := &A_arbace_test_tap_eval1888000029_fn__1888000030_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Ctor() {}
//line :91:1
func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_22; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_23; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :91:1
	var tmp8 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_37; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_25; tmp10.Invoke_O__O(tmp11.Ref())
			var tmp12 *lang.Var; A_arbace_test_tap_A_Init(); tmp12 = A_arbace_test_tap_A_const_38; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_tap_A_Init(); tmp14 = A_arbace_test_tap_A_const_39; tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(data__1))
			var tmp15 *lang.Var; A_arbace_test_tap_A_Init(); tmp15 = A_arbace_test_tap_A_const_36; tmp8 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(data__1) }
//line :91:1
		return nil }(); var tmp17 *lang.Var
	A_arbace_test_tap_A_Init(); tmp17 = A_arbace_test_tap_A_const_19; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke__O()
//line :91:1
	if tmp16 != nil { panic(tmp16) }; return tmp8
}




func A_arbace_test_tap_eval1888000033_fn__1888000034_A_New() *A_arbace_test_tap_eval1888000033_fn__1888000034_A { A_arbace_test_tap_eval1888000033_fn__1888000034_A_Init(); t := &A_arbace_test_tap_eval1888000033_fn__1888000034_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Ctor() {}
//line :97:1
func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_22; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_23; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :97:1
	var tmp8 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_37; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_41; tmp10.Invoke_O__O(tmp11.Ref())
			var tmp12 *lang.Var; A_arbace_test_tap_A_Init(); tmp12 = A_arbace_test_tap_A_const_40; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_tap_A_Init(); tmp14 = A_arbace_test_tap_A_const_39; tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(data__1))
			var tmp15 *lang.Var; A_arbace_test_tap_A_Init(); tmp15 = A_arbace_test_tap_A_const_36; tmp8 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(data__1) }
//line :97:1
		return nil }(); var tmp17 *lang.Var
	A_arbace_test_tap_A_Init(); tmp17 = A_arbace_test_tap_A_const_19; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke__O()
//line :97:1
	if tmp16 != nil { panic(tmp16) }; return tmp8
}




func A_arbace_test_tap_eval1888000037_fn__1888000038_A_New() *A_arbace_test_tap_eval1888000037_fn__1888000038_A { A_arbace_test_tap_eval1888000037_fn__1888000038_A_Init(); t := &A_arbace_test_tap_eval1888000037_fn__1888000038_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Ctor() {}
//line :103:1
func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_22; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_23; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :103:1
	var tmp8 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_37; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_42; tmp10.Invoke_O__O(tmp11.Ref())
			var tmp12 *lang.Var; A_arbace_test_tap_A_Init(); tmp12 = A_arbace_test_tap_A_const_40; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_tap_A_Init(); tmp14 = A_arbace_test_tap_A_const_39; tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(data__1))
			var tmp15 *lang.Var; A_arbace_test_tap_A_Init(); tmp15 = A_arbace_test_tap_A_const_36; tmp8 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(data__1) }
//line :103:1
		return nil }(); var tmp17 *lang.Var
	A_arbace_test_tap_A_Init(); tmp17 = A_arbace_test_tap_A_const_19; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke__O()
//line :103:1
	if tmp16 != nil { panic(tmp16) }; return tmp8
}




func A_arbace_test_tap_eval1888000041_fn__1888000042_A_New() *A_arbace_test_tap_eval1888000041_fn__1888000042_A { A_arbace_test_tap_eval1888000041_fn__1888000042_A_Init(); t := &A_arbace_test_tap_eval1888000041_fn__1888000042_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Ctor() {}
//line :109:1
func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Invoke_O_O__O(self, data__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_22; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_23; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :109:1
	var tmp8 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_43; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_25; var tmp12 any = jrt.NN(tmp11).Invoke_O__O(data__1); var tmp13 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp13 = A_arbace_test_tap_A_const_42; var tmp14 any = lang.Numbers_Add_O_O__Number(tmp12, jrt.NN(tmp13).Invoke_O__O(data__1)); var tmp15 *lang.Keyword; A_arbace_test_tap_A_Init(); tmp15 = A_arbace_test_tap_A_const_41; tmp8 = tmp10.Invoke_O__O(lang.Numbers_Add_O_O__Number(tmp14, jrt.NN(tmp15).Invoke_O__O(data__1))) }
//line :109:1
		return nil }(); var tmp17 *lang.Var
	A_arbace_test_tap_A_Init(); tmp17 = A_arbace_test_tap_A_const_19; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke__O()
//line :109:1
	if tmp16 != nil { panic(tmp16) }; return tmp8
}


func A_arbace_test_tap_with_tap_output_A_New() *A_arbace_test_tap_with_tap_output_A { A_arbace_test_tap_with_tap_output_A_Init(); t := &A_arbace_test_tap_with_tap_output_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_test_tap_with_tap_output_A) Ctor() {}
//line :113:1
func (t *A_arbace_test_tap_with_tap_output_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var tmp1 *lang.Var; A_arbace_test_tap_A_Init(); tmp1 = A_arbace_test_tap_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_tap_A_Init(); tmp3 = A_arbace_test_tap_A_const_44; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_tap_A_Init(); tmp5 = A_arbace_test_tap_A_const_45; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_tap_A_Init(); tmp7 = A_arbace_test_tap_A_const_46; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_tap_A_Init(); tmp9 = A_arbace_test_tap_A_const_45; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_tap_A_Init(); tmp11 = A_arbace_test_tap_A_const_47; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_tap_A_Init(); tmp13 = A_arbace_test_tap_A_const_48; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_test_tap_A_Init(); tmp15 = A_arbace_test_tap_A_const_11; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_tap_A_Init(); tmp17 = A_arbace_test_tap_A_const_44; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_tap_A_Init(); tmp19 = A_arbace_test_tap_A_const_45; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_tap_A_Init(); tmp21 = A_arbace_test_tap_A_const_49; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_tap_A_Init(); tmp23 = A_arbace_test_tap_A_const_45; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_test_tap_A_Init(); tmp25 = A_arbace_test_tap_A_const_50; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, tmp24.Invoke_O__O(tmp25))))), body__2)) }









type A_arbace_test_tap_A struct{ jrt.Object }

var A_arbace_test_tap_A_const_0 *lang.Var

var A_arbace_test_tap_A_const_1 *lang.Var

var A_arbace_test_tap_A_const_2 any

var A_arbace_test_tap_A_const_3 any

var A_arbace_test_tap_A_const_4 any

var A_arbace_test_tap_A_const_5 *lang.Var

var A_arbace_test_tap_A_const_6 *lang.Var

var A_arbace_test_tap_A_const_7 *lang.Var

var A_arbace_test_tap_A_const_8 any

var A_arbace_test_tap_A_const_9 *lang.Var

var A_arbace_test_tap_A_const_10 *lang.Var

var A_arbace_test_tap_A_const_11 *lang.Var

var A_arbace_test_tap_A_const_12 *lang.Var

var A_arbace_test_tap_A_const_13 *lang.Var

var A_arbace_test_tap_A_const_14 *lang.Var

var A_arbace_test_tap_A_const_15 *jrt.Class

var A_arbace_test_tap_A_const_16 *lang.Var

var A_arbace_test_tap_A_const_17 *lang.Var

var A_arbace_test_tap_A_const_18 *lang.Var

var A_arbace_test_tap_A_const_19 *lang.Var

var A_arbace_test_tap_A_const_20 *lang.Var

var A_arbace_test_tap_A_const_21 *lang.Var

var A_arbace_test_tap_A_const_22 *lang.Var

var A_arbace_test_tap_A_const_23 *lang.Var

var A_arbace_test_tap_A_const_24 *lang.Var

var A_arbace_test_tap_A_const_25 *lang.Keyword

var A_arbace_test_tap_A_const_26 *lang.Keyword

var A_arbace_test_tap_A_const_27 *lang.Keyword

var A_arbace_test_tap_A_const_28 *lang.Var

var A_arbace_test_tap_A_const_29 *lang.Var

var A_arbace_test_tap_A_const_30 *lang.Keyword

var A_arbace_test_tap_A_const_31 *lang.Keyword

var A_arbace_test_tap_A_const_32 *lang.Var

var A_arbace_test_tap_A_const_33 *lang.Var

var A_arbace_test_tap_A_const_34 *lang.Var

var A_arbace_test_tap_A_const_35 *lang.Var

var A_arbace_test_tap_A_const_36 *lang.Var

var A_arbace_test_tap_A_const_37 *lang.Var

var A_arbace_test_tap_A_const_38 *lang.Var

var A_arbace_test_tap_A_const_39 *lang.Var

var A_arbace_test_tap_A_const_40 *lang.Var

var A_arbace_test_tap_A_const_41 *lang.Keyword

var A_arbace_test_tap_A_const_42 *lang.Keyword

var A_arbace_test_tap_A_const_43 *lang.Var

var A_arbace_test_tap_A_const_44 *lang.Var

var A_arbace_test_tap_A_const_45 *lang.Var

var A_arbace_test_tap_A_const_46 any

var A_arbace_test_tap_A_const_47 *lang.Var

var A_arbace_test_tap_A_const_48 *lang.Var

var A_arbace_test_tap_A_const_49 any

var A_arbace_test_tap_A_const_50 any

var A_arbace_test_tap_A_init jrt.ClassInit

func A_arbace_test_tap_A_Init() { if !A_arbace_test_tap_A_init.Done() { A_arbace_test_tap_A_init.Run(A_arbace_test_tap_A_clinit) } }

func A_arbace_test_tap_A_clinit() { A_arbace_test_tap_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_test_tap_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_test_tap_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_test_tap_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_test_tap_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_test_tap_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_test_tap_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_test_tap_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_test_tap_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_test_tap_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_test_tap_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_test_tap_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_test_tap_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_test_tap_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_test_tap_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_test_tap_A_const_15 = lang.RT_ClassForNameNonLoading_String__Class(Lit_22); A_arbace_test_tap_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_test_tap_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_test_tap_A_const_18 = lang.RT_Var_String_String__Var(Lit_11, Lit_25); A_arbace_test_tap_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_test_tap_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_test_tap_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_test_tap_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_test_tap_A_const_23 = lang.RT_Var_String_String__Var(Lit_3, Lit_30); A_arbace_test_tap_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_test_tap_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_test_tap_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_test_tap_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_test_tap_A_const_28 = lang.RT_Var_String_String__Var(Lit_3, Lit_35); A_arbace_test_tap_A_const_29 = lang.RT_Var_String_String__Var(Lit_3, Lit_36); A_arbace_test_tap_A_const_30 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_test_tap_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_test_tap_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_test_tap_A_const_33 = lang.RT_Var_String_String__Var(Lit_6, Lit_40); A_arbace_test_tap_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_test_tap_A_const_35 = lang.RT_Var_String_String__Var(Lit_3, Lit_42); A_arbace_test_tap_A_const_36 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_test_tap_A_const_37 = lang.RT_Var_String_String__Var(Lit_3, Lit_44); A_arbace_test_tap_A_const_38 = lang.RT_Var_String_String__Var(Lit_11, Lit_45); A_arbace_test_tap_A_const_39 = lang.RT_Var_String_String__Var(Lit_3, Lit_46); A_arbace_test_tap_A_const_40 = lang.RT_Var_String_String__Var(Lit_11, Lit_47); A_arbace_test_tap_A_const_41 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_test_tap_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_test_tap_A_const_43 = lang.RT_Var_String_String__Var(Lit_11, Lit_50); A_arbace_test_tap_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_test_tap_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_test_tap_A_const_46 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_53).Ref(); A_arbace_test_tap_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_test_tap_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_test_tap_A_const_49 = lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_56).Ref(); A_arbace_test_tap_A_const_50 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_57).Ref() }

func A_arbace_test_tap_A_New() *A_arbace_test_tap_A { A_arbace_test_tap_A_Init(); t := &A_arbace_test_tap_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_A) Ctor() {}

func (t *A_arbace_test_tap_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_A_class }

func (t *A_arbace_test_tap_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_A); return ok }

func A_arbace_test_tap_A_Cast(x any) *A_arbace_test_tap_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_A_class)) }; return v }



type A_arbace_test_tap_eval1888000004_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000004_A_New() *A_arbace_test_tap_eval1888000004_A { t := &A_arbace_test_tap_eval1888000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000004_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000004_A_class }

func (t *A_arbace_test_tap_eval1888000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000004_A); return ok }

func A_arbace_test_tap_eval1888000004_A_Cast(x any) *A_arbace_test_tap_eval1888000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000004_A_class)) }; return v }



type A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A struct{ jrt.Object }

func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Is_Compiler_AOTF0() {}

var A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class *jrt.Class

var A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_init jrt.ClassInit

func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_Init() { if !A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_init.Done() { A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_init.Run(A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_clinit) } }

func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_clinit() { A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_class }

func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A); return ok }

func A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_Cast(x any) *A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000004_loading__1927001464__auto____1888000005_A_class)) }; return v }



type A_arbace_test_tap_eval1888000008_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000008_A_New() *A_arbace_test_tap_eval1888000008_A { t := &A_arbace_test_tap_eval1888000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000008_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000008_A_class }

func (t *A_arbace_test_tap_eval1888000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000008_A); return ok }

func A_arbace_test_tap_eval1888000008_A_Cast(x any) *A_arbace_test_tap_eval1888000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000008_A_class)) }; return v }



type A_arbace_test_tap_eval1888000008_fn__1888000009_A struct{ jrt.Object }

func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Is_Compiler_AOTF0() {}

var A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class *jrt.Class

var A_arbace_test_tap_eval1888000008_fn__1888000009_A_init jrt.ClassInit

func A_arbace_test_tap_eval1888000008_fn__1888000009_A_Init() { if !A_arbace_test_tap_eval1888000008_fn__1888000009_A_init.Done() { A_arbace_test_tap_eval1888000008_fn__1888000009_A_init.Run(A_arbace_test_tap_eval1888000008_fn__1888000009_A_clinit) } }

func A_arbace_test_tap_eval1888000008_fn__1888000009_A_clinit() { A_arbace_test_tap_eval1888000008_fn__1888000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000008_fn__1888000009_A_class }

func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000008_fn__1888000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000008_fn__1888000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000008_fn__1888000009_A); return ok }

func A_arbace_test_tap_eval1888000008_fn__1888000009_A_Cast(x any) *A_arbace_test_tap_eval1888000008_fn__1888000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000008_fn__1888000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000008_fn__1888000009_A_class)) }; return v }



type A_arbace_test_tap_eval1888000022_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000022_A_New() *A_arbace_test_tap_eval1888000022_A { t := &A_arbace_test_tap_eval1888000022_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000022_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000022_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000022_A_class }

func (t *A_arbace_test_tap_eval1888000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000022_A); return ok }

func A_arbace_test_tap_eval1888000022_A_Cast(x any) *A_arbace_test_tap_eval1888000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000022_A_class)) }; return v }



type A_arbace_test_tap_eval1888000022_fn__1888000023_A struct{ jrt.Object }

func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class *jrt.Class

var A_arbace_test_tap_eval1888000022_fn__1888000023_A_init jrt.ClassInit

func A_arbace_test_tap_eval1888000022_fn__1888000023_A_Init() { if !A_arbace_test_tap_eval1888000022_fn__1888000023_A_init.Done() { A_arbace_test_tap_eval1888000022_fn__1888000023_A_init.Run(A_arbace_test_tap_eval1888000022_fn__1888000023_A_clinit) } }

func A_arbace_test_tap_eval1888000022_fn__1888000023_A_clinit() { A_arbace_test_tap_eval1888000022_fn__1888000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000022_fn__1888000023_A_class }

func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000022_fn__1888000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000022_fn__1888000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000022_fn__1888000023_A); return ok }

func A_arbace_test_tap_eval1888000022_fn__1888000023_A_Cast(x any) *A_arbace_test_tap_eval1888000022_fn__1888000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000022_fn__1888000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000022_fn__1888000023_A_class)) }; return v }



type A_arbace_test_tap_eval1888000029_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000029_A_New() *A_arbace_test_tap_eval1888000029_A { t := &A_arbace_test_tap_eval1888000029_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000029_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000029_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000029_A_class }

func (t *A_arbace_test_tap_eval1888000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000029_A); return ok }

func A_arbace_test_tap_eval1888000029_A_Cast(x any) *A_arbace_test_tap_eval1888000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000029_A_class)) }; return v }



type A_arbace_test_tap_eval1888000029_fn__1888000030_A struct{ jrt.Object }

func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class *jrt.Class

var A_arbace_test_tap_eval1888000029_fn__1888000030_A_init jrt.ClassInit

func A_arbace_test_tap_eval1888000029_fn__1888000030_A_Init() { if !A_arbace_test_tap_eval1888000029_fn__1888000030_A_init.Done() { A_arbace_test_tap_eval1888000029_fn__1888000030_A_init.Run(A_arbace_test_tap_eval1888000029_fn__1888000030_A_clinit) } }

func A_arbace_test_tap_eval1888000029_fn__1888000030_A_clinit() { A_arbace_test_tap_eval1888000029_fn__1888000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000029_fn__1888000030_A_class }

func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000029_fn__1888000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000029_fn__1888000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000029_fn__1888000030_A); return ok }

func A_arbace_test_tap_eval1888000029_fn__1888000030_A_Cast(x any) *A_arbace_test_tap_eval1888000029_fn__1888000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000029_fn__1888000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000029_fn__1888000030_A_class)) }; return v }



type A_arbace_test_tap_eval1888000033_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000033_A_New() *A_arbace_test_tap_eval1888000033_A { t := &A_arbace_test_tap_eval1888000033_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000033_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000033_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000033_A_class }

func (t *A_arbace_test_tap_eval1888000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000033_A); return ok }

func A_arbace_test_tap_eval1888000033_A_Cast(x any) *A_arbace_test_tap_eval1888000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000033_A_class)) }; return v }



type A_arbace_test_tap_eval1888000033_fn__1888000034_A struct{ jrt.Object }

func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class *jrt.Class

var A_arbace_test_tap_eval1888000033_fn__1888000034_A_init jrt.ClassInit

func A_arbace_test_tap_eval1888000033_fn__1888000034_A_Init() { if !A_arbace_test_tap_eval1888000033_fn__1888000034_A_init.Done() { A_arbace_test_tap_eval1888000033_fn__1888000034_A_init.Run(A_arbace_test_tap_eval1888000033_fn__1888000034_A_clinit) } }

func A_arbace_test_tap_eval1888000033_fn__1888000034_A_clinit() { A_arbace_test_tap_eval1888000033_fn__1888000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000033_fn__1888000034_A_class }

func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000033_fn__1888000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000033_fn__1888000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000033_fn__1888000034_A); return ok }

func A_arbace_test_tap_eval1888000033_fn__1888000034_A_Cast(x any) *A_arbace_test_tap_eval1888000033_fn__1888000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000033_fn__1888000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000033_fn__1888000034_A_class)) }; return v }



type A_arbace_test_tap_eval1888000037_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000037_A_New() *A_arbace_test_tap_eval1888000037_A { t := &A_arbace_test_tap_eval1888000037_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000037_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000037_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000037_A_class }

func (t *A_arbace_test_tap_eval1888000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000037_A); return ok }

func A_arbace_test_tap_eval1888000037_A_Cast(x any) *A_arbace_test_tap_eval1888000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000037_A_class)) }; return v }



type A_arbace_test_tap_eval1888000037_fn__1888000038_A struct{ jrt.Object }

func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class *jrt.Class

var A_arbace_test_tap_eval1888000037_fn__1888000038_A_init jrt.ClassInit

func A_arbace_test_tap_eval1888000037_fn__1888000038_A_Init() { if !A_arbace_test_tap_eval1888000037_fn__1888000038_A_init.Done() { A_arbace_test_tap_eval1888000037_fn__1888000038_A_init.Run(A_arbace_test_tap_eval1888000037_fn__1888000038_A_clinit) } }

func A_arbace_test_tap_eval1888000037_fn__1888000038_A_clinit() { A_arbace_test_tap_eval1888000037_fn__1888000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000037_fn__1888000038_A_class }

func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000037_fn__1888000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000037_fn__1888000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000037_fn__1888000038_A); return ok }

func A_arbace_test_tap_eval1888000037_fn__1888000038_A_Cast(x any) *A_arbace_test_tap_eval1888000037_fn__1888000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000037_fn__1888000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000037_fn__1888000038_A_class)) }; return v }



type A_arbace_test_tap_eval1888000041_A struct{ jrt.Object }

func A_arbace_test_tap_eval1888000041_A_New() *A_arbace_test_tap_eval1888000041_A { t := &A_arbace_test_tap_eval1888000041_A{}; t.Ctor(); return t }

func (t *A_arbace_test_tap_eval1888000041_A) Ctor() {}

func (t *A_arbace_test_tap_eval1888000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000041_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000041_A_class }

func (t *A_arbace_test_tap_eval1888000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000041_A); return ok }

func A_arbace_test_tap_eval1888000041_A_Cast(x any) *A_arbace_test_tap_eval1888000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000041_A_class)) }; return v }



type A_arbace_test_tap_eval1888000041_fn__1888000042_A struct{ jrt.Object }

func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class *jrt.Class

var A_arbace_test_tap_eval1888000041_fn__1888000042_A_init jrt.ClassInit

func A_arbace_test_tap_eval1888000041_fn__1888000042_A_Init() { if !A_arbace_test_tap_eval1888000041_fn__1888000042_A_init.Done() { A_arbace_test_tap_eval1888000041_fn__1888000042_A_init.Run(A_arbace_test_tap_eval1888000041_fn__1888000042_A_clinit) } }

func A_arbace_test_tap_eval1888000041_fn__1888000042_A_clinit() { A_arbace_test_tap_eval1888000041_fn__1888000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_eval1888000041_fn__1888000042_A_class }

func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_eval1888000041_fn__1888000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_eval1888000041_fn__1888000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_eval1888000041_fn__1888000042_A); return ok }

func A_arbace_test_tap_eval1888000041_fn__1888000042_A_Cast(x any) *A_arbace_test_tap_eval1888000041_fn__1888000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_eval1888000041_fn__1888000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_eval1888000041_fn__1888000042_A_class)) }; return v }



type A_arbace_test_tap_print_diagnostics_A struct{ jrt.Object }

func (t *A_arbace_test_tap_print_diagnostics_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_print_diagnostics_A_fn_class *jrt.Class

var A_arbace_test_tap_print_diagnostics_A_init jrt.ClassInit

func A_arbace_test_tap_print_diagnostics_A_Init() { if !A_arbace_test_tap_print_diagnostics_A_init.Done() { A_arbace_test_tap_print_diagnostics_A_init.Run(A_arbace_test_tap_print_diagnostics_A_clinit) } }

func A_arbace_test_tap_print_diagnostics_A_clinit() { A_arbace_test_tap_print_diagnostics_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_print_diagnostics_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_print_diagnostics_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_print_diagnostics_A_class }

func (t *A_arbace_test_tap_print_diagnostics_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_print_diagnostics_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_print_diagnostics_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_print_diagnostics_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_print_diagnostics_A); return ok }

func A_arbace_test_tap_print_diagnostics_A_Cast(x any) *A_arbace_test_tap_print_diagnostics_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_print_diagnostics_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_print_diagnostics_A_class)) }; return v }



type A_arbace_test_tap_print_diagnostics_fn__1888000026_A struct{ jrt.Object; F_s__1927001093__auto__, F_data any }

func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Is_Compiler_AOTF0() {}

var A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class *jrt.Class

var A_arbace_test_tap_print_diagnostics_fn__1888000026_A_init jrt.ClassInit

func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_Init() { if !A_arbace_test_tap_print_diagnostics_fn__1888000026_A_init.Done() { A_arbace_test_tap_print_diagnostics_fn__1888000026_A_init.Run(A_arbace_test_tap_print_diagnostics_fn__1888000026_A_clinit) } }

func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_clinit() { A_arbace_test_tap_print_diagnostics_fn__1888000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_print_diagnostics_fn__1888000026_A_class }

func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_print_diagnostics_fn__1888000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_print_diagnostics_fn__1888000026_A); return ok }

func A_arbace_test_tap_print_diagnostics_fn__1888000026_A_Cast(x any) *A_arbace_test_tap_print_diagnostics_fn__1888000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_print_diagnostics_fn__1888000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_print_diagnostics_fn__1888000026_A_class)) }; return v }



type A_arbace_test_tap_print_tap_diagnostic_A struct{ jrt.Object }

func (t *A_arbace_test_tap_print_tap_diagnostic_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_print_tap_diagnostic_A_fn_class *jrt.Class

var A_arbace_test_tap_print_tap_diagnostic_A_init jrt.ClassInit

func A_arbace_test_tap_print_tap_diagnostic_A_Init() { if !A_arbace_test_tap_print_tap_diagnostic_A_init.Done() { A_arbace_test_tap_print_tap_diagnostic_A_init.Run(A_arbace_test_tap_print_tap_diagnostic_A_clinit) } }

func A_arbace_test_tap_print_tap_diagnostic_A_clinit() { A_arbace_test_tap_print_tap_diagnostic_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_print_tap_diagnostic_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_print_tap_diagnostic_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_print_tap_diagnostic_A_class }

func (t *A_arbace_test_tap_print_tap_diagnostic_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_print_tap_diagnostic_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_print_tap_diagnostic_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_print_tap_diagnostic_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_print_tap_diagnostic_A); return ok }

func A_arbace_test_tap_print_tap_diagnostic_A_Cast(x any) *A_arbace_test_tap_print_tap_diagnostic_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_print_tap_diagnostic_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_print_tap_diagnostic_A_class)) }; return v }



type A_arbace_test_tap_print_tap_fail_A struct{ jrt.Object }

func (t *A_arbace_test_tap_print_tap_fail_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_print_tap_fail_A_fn_class *jrt.Class

var A_arbace_test_tap_print_tap_fail_A_init jrt.ClassInit

func A_arbace_test_tap_print_tap_fail_A_Init() { if !A_arbace_test_tap_print_tap_fail_A_init.Done() { A_arbace_test_tap_print_tap_fail_A_init.Run(A_arbace_test_tap_print_tap_fail_A_clinit) } }

func A_arbace_test_tap_print_tap_fail_A_clinit() { A_arbace_test_tap_print_tap_fail_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_print_tap_fail_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_print_tap_fail_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_print_tap_fail_A_class }

func (t *A_arbace_test_tap_print_tap_fail_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_print_tap_fail_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_print_tap_fail_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_print_tap_fail_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_print_tap_fail_A); return ok }

func A_arbace_test_tap_print_tap_fail_A_Cast(x any) *A_arbace_test_tap_print_tap_fail_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_print_tap_fail_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_print_tap_fail_A_class)) }; return v }



type A_arbace_test_tap_print_tap_pass_A struct{ jrt.Object }

func (t *A_arbace_test_tap_print_tap_pass_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_print_tap_pass_A_fn_class *jrt.Class

var A_arbace_test_tap_print_tap_pass_A_init jrt.ClassInit

func A_arbace_test_tap_print_tap_pass_A_Init() { if !A_arbace_test_tap_print_tap_pass_A_init.Done() { A_arbace_test_tap_print_tap_pass_A_init.Run(A_arbace_test_tap_print_tap_pass_A_clinit) } }

func A_arbace_test_tap_print_tap_pass_A_clinit() { A_arbace_test_tap_print_tap_pass_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_print_tap_pass_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_print_tap_pass_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_print_tap_pass_A_class }

func (t *A_arbace_test_tap_print_tap_pass_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_print_tap_pass_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_print_tap_pass_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_print_tap_pass_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_print_tap_pass_A); return ok }

func A_arbace_test_tap_print_tap_pass_A_Cast(x any) *A_arbace_test_tap_print_tap_pass_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_print_tap_pass_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_print_tap_pass_A_class)) }; return v }



type A_arbace_test_tap_print_tap_plan_A struct{ jrt.Object }

func (t *A_arbace_test_tap_print_tap_plan_A) Is_Compiler_AOTF1() {}

var A_arbace_test_tap_print_tap_plan_A_fn_class *jrt.Class

var A_arbace_test_tap_print_tap_plan_A_init jrt.ClassInit

func A_arbace_test_tap_print_tap_plan_A_Init() { if !A_arbace_test_tap_print_tap_plan_A_init.Done() { A_arbace_test_tap_print_tap_plan_A_init.Run(A_arbace_test_tap_print_tap_plan_A_clinit) } }

func A_arbace_test_tap_print_tap_plan_A_clinit() { A_arbace_test_tap_print_tap_plan_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_tap_print_tap_plan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_print_tap_plan_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_print_tap_plan_A_class }

func (t *A_arbace_test_tap_print_tap_plan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_print_tap_plan_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_print_tap_plan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_print_tap_plan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_print_tap_plan_A); return ok }

func A_arbace_test_tap_print_tap_plan_A_Cast(x any) *A_arbace_test_tap_print_tap_plan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_print_tap_plan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_print_tap_plan_A_class)) }; return v }



type A_arbace_test_tap_with_tap_output_A struct{ jrt.Object }

func (t *A_arbace_test_tap_with_tap_output_A) Is_Compiler_AOTR2() {}

var A_arbace_test_tap_with_tap_output_A_fn_class *jrt.Class

var A_arbace_test_tap_with_tap_output_A_init jrt.ClassInit

func A_arbace_test_tap_with_tap_output_A_Init() { if !A_arbace_test_tap_with_tap_output_A_init.Done() { A_arbace_test_tap_with_tap_output_A_init.Run(A_arbace_test_tap_with_tap_output_A_clinit) } }

func A_arbace_test_tap_with_tap_output_A_clinit() { A_arbace_test_tap_with_tap_output_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_tap_with_tap_output_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_tap_with_tap_output_A) GetClass__Class() *jrt.Class { return A_arbace_test_tap_with_tap_output_A_class }

func (t *A_arbace_test_tap_with_tap_output_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_tap_with_tap_output_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_tap_with_tap_output_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_tap_with_tap_output_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_tap_with_tap_output_A); return ok }

func A_arbace_test_tap_with_tap_output_A_Cast(x any) *A_arbace_test_tap_with_tap_output_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_tap_with_tap_output_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_tap_with_tap_output_A_class)) }; return v }
