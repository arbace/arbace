//line a2g_strings.ae:1
package aot_arbace_test_tap

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.test")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("t")

var Lit_6 *jrt.String = jrt.Intern("arbace.stacktrace")

var Lit_7 *jrt.String = jrt.Intern("stack")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.test.tap")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("arbace.test extensions for the Test Anything Protocol (TAP)\n\n  TAP is a simple text-based syntax for reporting test results.  TAP\n  was originally developed for Perl, and now has implementations in\n  several languages.  For more information on TAP, see\n  http://testanything.org/ and\n  http://search.cpan.org/~petdance/TAP-1.0.0/TAP.pm\n\n  To use this library, wrap any calls to\n  arbace.test/run-tests in the with-tap-output macro,\n  like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.tap)\n\n    (with-tap-output\n     (run-tests 'my.cool.library))")

var Lit_14 *jrt.String = jrt.Intern("author")

var Lit_15 *jrt.String = jrt.Intern("Stuart Sierra")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("println")

var Lit_18 *jrt.String = jrt.Intern("seq")

var Lit_19 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_20 *jrt.String = jrt.Intern("chunk-first")

var Lit_21 *jrt.String = jrt.Intern("first")

var Lit_22 *jrt.String = jrt.Intern("java.lang.String")

var Lit_23 *jrt.String = jrt.Intern("chunk-rest")

var Lit_24 *jrt.String = jrt.Intern("next")

var Lit_25 *jrt.String = jrt.Intern("print-tap-diagnostic")

var Lit_26 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_27 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_28 *jrt.String = jrt.Intern("hash-map")

var Lit_29 *jrt.String = jrt.Intern("*out*")

var Lit_30 *jrt.String = jrt.Intern("*test-out*")

var Lit_31 *jrt.String = jrt.Intern("pr-str")

var Lit_32 *jrt.String = jrt.Intern("pass")

var Lit_33 *jrt.String = jrt.Intern("type")

var Lit_34 *jrt.String = jrt.Intern("message")

var Lit_35 *jrt.String = jrt.Intern("*testing-contexts*")

var Lit_36 *jrt.String = jrt.Intern("testing-contexts-str")

var Lit_37 *jrt.String = jrt.Intern("expected")

var Lit_38 *jrt.String = jrt.Intern("actual")

var Lit_39 *jrt.String = jrt.Intern("str")

var Lit_40 *jrt.String = jrt.Intern("print-cause-trace")

var Lit_41 *jrt.String = jrt.Intern("prn")

var Lit_42 *jrt.String = jrt.Intern("*stack-trace-depth*")

var Lit_43 *jrt.String = jrt.Intern("print-diagnostics")

var Lit_44 *jrt.String = jrt.Intern("inc-report-counter")

var Lit_45 *jrt.String = jrt.Intern("print-tap-pass")

var Lit_46 *jrt.String = jrt.Intern("testing-vars-str")

var Lit_47 *jrt.String = jrt.Intern("print-tap-fail")

var Lit_48 *jrt.String = jrt.Intern("error")

var Lit_49 *jrt.String = jrt.Intern("fail")

var Lit_50 *jrt.String = jrt.Intern("print-tap-plan")

var Lit_51 *jrt.String = jrt.Intern("concat")

var Lit_52 *jrt.String = jrt.Intern("list")

var Lit_53 *jrt.String = jrt.Intern("binding")

var Lit_54 *jrt.String = jrt.Intern("apply")

var Lit_55 *jrt.String = jrt.Intern("vector")

var Lit_56 *jrt.String = jrt.Intern("report")

var Lit_57 *jrt.String = jrt.Intern("tap-report")

var Lit_58 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000004$loading__1927001464__auto____1888000005")

var Lit_59 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000008$fn__1888000009")

var Lit_60 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000022$fn__1888000023")

var Lit_61 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000029$fn__1888000030")

var Lit_62 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000033$fn__1888000034")

var Lit_63 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000037$fn__1888000038")

var Lit_64 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000041$fn__1888000042")

var Lit_65 *jrt.String = jrt.Intern("arbace.test.tap$print_diagnostics")

var Lit_66 *jrt.String = jrt.Intern("expected:")

var Lit_67 *jrt.String = jrt.Intern("  actual:")

var Lit_68 *jrt.String = jrt.Intern("arbace.test.tap$print_diagnostics$fn__1888000026")

var Lit_69 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_diagnostic")

var Lit_70 *jrt.String = jrt.Intern("split")

var Lit_71 *jrt.String = jrt.Intern("\n")

var Lit_72 *jrt.String = jrt.Intern("#")

var Lit_73 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_fail")

var Lit_74 *jrt.String = jrt.Intern("not ok")

var Lit_75 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_pass")

var Lit_76 *jrt.String = jrt.Intern("ok")

var Lit_77 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_plan")

var Lit_78 *jrt.String = jrt.Intern("1..")

var Lit_79 *jrt.String = jrt.Intern("arbace.test.tap$with_tap_output")

var Lit_80 *jrt.String = jrt.Intern("in-ns")

var Lit_81 *jrt.String = jrt.Intern("arglists")

var Lit_82 *jrt.String = jrt.Intern("n")

var Lit_83 *jrt.String = jrt.Intern("Prints a TAP plan line like '1..n'.  n is the number of tests")

var Lit_84 *jrt.String = jrt.Intern("added")

var Lit_85 *jrt.String = jrt.Intern("1.1")

var Lit_86 *jrt.String = jrt.Intern("line")

var Lit_87 *jrt.String = jrt.Intern("column")

var Lit_88 *jrt.String = jrt.Intern("file")

var Lit_89 *jrt.String = jrt.Intern("arbace/test/tap.ae")

var Lit_90 *jrt.String = jrt.Intern("data")

var Lit_91 *jrt.String = jrt.Intern("Prints a TAP diagnostic line.  data is a (possibly multi-line)\n  string.")

var Lit_92 *jrt.String = jrt.Intern("msg")

var Lit_93 *jrt.String = jrt.Intern("Prints a TAP 'ok' line.  msg is a string, with no line breaks")

var Lit_94 *jrt.String = jrt.Intern("Prints a TAP 'not ok' line.  msg is a string, with no line breaks")

var Lit_95 *jrt.String = jrt.Intern("dynamic")

var Lit_96 *jrt.String = jrt.Intern("default")

var Lit_97 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_98 *jrt.String = jrt.Intern("summary")

var Lit_99 *jrt.String = jrt.Intern("with-tap-output")

var Lit_100 *jrt.String = jrt.Intern("&")

var Lit_101 *jrt.String = jrt.Intern("body")

var Lit_102 *jrt.String = jrt.Intern("Execute body with modified test reporting functions that produce\n  TAP output")
