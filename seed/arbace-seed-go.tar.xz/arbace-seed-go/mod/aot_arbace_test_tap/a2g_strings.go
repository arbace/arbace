//line a2g_strings.ae:1
package aot_arbace_test_tap

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn11,arbace.testkn2,asyn1,tyn17,arbace.stacktraceyn5,stackkn3,dockn6,authorkn4,passkn4,typekn7,messagekn8,expectedkn6,actualkn5,errorkn4,failys11,arbace.core7,bindingys11,arbace.test6,reportys15,arbace.test.tap10,tap-reportv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.test.tapm4,R6,s552,arbace.test extensions for the Test Anything Protocol (TAP)\n\n  TAP is a simple text-based syntax for reporting test results.  TAP\n  was originally developed for Perl, and now has implementations in\n  several languages.  For more information on TAP, see\n  http://testanything.org/ and\n  http://search.cpan.org/~petdance/TAP-1.0.0/TAP.pm\n\n  To use this library, wrap any calls to\n  arbace.test/run-tests in the with-tap-output macro,\n  like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.tap)\n\n    (with-tap-output\n     (run-tests 'my.cool.library))R7,s13,Stuart Sierrav11,arbace.core13,*loaded-libs*v11,arbace.core7,printlnv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstC16,java.lang.Stringv11,arbace.core10,chunk-restv11,arbace.core4,nextv15,arbace.test.tap20,print-tap-diagnosticv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.test10,*test-out*v11,arbace.core6,pr-strR8,R9,R10,v11,arbace.test18,*testing-contexts*v11,arbace.test20,testing-contexts-strR11,R12,v11,arbace.core3,strv17,arbace.stacktrace17,print-cause-tracev11,arbace.core3,prnv11,arbace.test19,*stack-trace-depth*v15,arbace.test.tap17,print-diagnosticsv11,arbace.test18,inc-report-counterv15,arbace.test.tap14,print-tap-passv11,arbace.test16,testing-vars-strv15,arbace.test.tap14,print-tap-failR13,R14,v15,arbace.test.tap14,print-tap-planv11,arbace.core6,concatv11,arbace.core4,listR15,v11,arbace.core5,applyv11,arbace.core6,vectorR16,R17,")

var Lit_1 *jrt.String = jrt.Intern("expected:")

var Lit_2 *jrt.String = jrt.Intern("  actual:")

var Lit_3 *jrt.String = jrt.Intern("arbace.test.tap$print_diagnostics$fn__1888000026")

var Lit_4 *jrt.String = jrt.Intern("split")

var Lit_5 *jrt.String = jrt.Intern("\n")

var Lit_6 *jrt.String = jrt.Intern("#")

var Lit_7 *jrt.String = jrt.Intern("not ok")

var Lit_8 *jrt.String = jrt.Intern("ok")

var Lit_9 *jrt.String = jrt.Intern("1..")

var Lit_10 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn8,arglistsyn1,nkn5,addedkn4,linekn6,columnkn4,fileyn4,datayn3,msgkn7,dynamickn4,typekn7,defaultkn4,passkn5,errorkn4,failkn7,summaryyn1,&yn4,bodyv11,arbace.core5,in-nsMyn15,arbace.test.tapm4,R0,s552,arbace.test extensions for the Test Anything Protocol (TAP)\n\n  TAP is a simple text-based syntax for reporting test results.  TAP\n  was originally developed for Perl, and now has implementations in\n  several languages.  For more information on TAP, see\n  http://testanything.org/ and\n  http://search.cpan.org/~petdance/TAP-1.0.0/TAP.pm\n\n  To use this library, wrap any calls to\n  arbace.test/run-tests in the with-tap-output macro,\n  like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.tap)\n\n    (with-tap-output\n     (run-tests 'my.cool.library))R1,s13,Stuart Sierram4,R0,s552,arbace.test extensions for the Test Anything Protocol (TAP)\n\n  TAP is a simple text-based syntax for reporting test results.  TAP\n  was originally developed for Perl, and now has implementations in\n  several languages.  For more information on TAP, see\n  http://testanything.org/ and\n  http://search.cpan.org/~petdance/TAP-1.0.0/TAP.pm\n\n  To use this library, wrap any calls to\n  arbace.test/run-tests in the with-tap-output macro,\n  like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.tap)\n\n    (with-tap-output\n     (run-tests 'my.cool.library))R1,s13,Stuart SierraR2,v15,arbace.test.tap14,print-tap-planm12,R3,L1,V1,R4,R0,s61,Prints a TAP plan line like '1..n'.  n is the number of testsR5,s3,1.1R6,i42,R7,i1,R8,s18,arbace/test/tap.aev15,arbace.test.tap20,print-tap-diagnosticm12,R3,L1,V1,R9,R0,s72,Prints a TAP diagnostic line.  data is a (possibly multi-line)\n  string.R5,s3,1.1R6,i48,R7,i1,R8,s18,arbace/test/tap.aev15,arbace.test.tap14,print-tap-passm12,R3,L1,V1,R10,R0,s61,Prints a TAP 'ok' line.  msg is a string, with no line breaksR5,s3,1.1R6,i56,R7,i1,R8,s18,arbace/test/tap.aev15,arbace.test.tap14,print-tap-failm12,R3,L1,V1,R10,R0,s65,Prints a TAP 'not ok' line.  msg is a string, with no line breaksR5,s3,1.1R6,i62,R7,i1,R8,s18,arbace/test/tap.aev15,arbace.test.tap10,tap-reportm8,R11,TR6,i69,R7,i1,R8,s18,arbace/test/tap.aev11,arbace.core5,derefR12,R13,v11,arbace.core16,global-hierarchym8,R11,TR6,i69,R7,i1,R8,s18,arbace/test/tap.aev15,arbace.test.tap17,print-diagnosticsm8,R3,L1,V1,R9,R6,i75,R7,i1,R8,s18,arbace/test/tap.aeR14,R15,R16,R17,v15,arbace.test.tap15,with-tap-outputm12,R3,L1,V2,R18,R19,R0,s77,Execute body with modified test reporting functions that produce\n  TAP outputR5,s3,1.1R6,i113,R7,i1,R8,s18,arbace/test/tap.ae")

var Lit_11 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000004$loading__1927001464__auto____1888000005")

var Lit_12 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000008$fn__1888000009")

var Lit_13 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_plan")

var Lit_14 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_diagnostic")

var Lit_15 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_pass")

var Lit_16 *jrt.String = jrt.Intern("arbace.test.tap$print_tap_fail")

var Lit_17 *jrt.String = jrt.Intern("tap-report")

var Lit_18 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000022$fn__1888000023")

var Lit_19 *jrt.String = jrt.Intern("arbace.test.tap$print_diagnostics")

var Lit_20 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000029$fn__1888000030")

var Lit_21 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000033$fn__1888000034")

var Lit_22 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000037$fn__1888000038")

var Lit_23 *jrt.String = jrt.Intern("arbace.test.tap$eval1888000041$fn__1888000042")

var Lit_24 *jrt.String = jrt.Intern("arbace.test.tap$with_tap_output")
