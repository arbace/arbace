//line j2g_strings.ae:1
package aot_arbace_go_check_code_stmt

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn20,arbace.go.check.codekn8,arglistsyn2,cxyn2,nmyn2,tyyn1,fyn1,&kn2,asyn4,morekn3,dockn4,linekn6,columnkn4,fileyn1,xkn7,privateyn1,nyn4,whatyn2,nlyn9,rhs-formsyn5,nodesyn5,call?kn8,declaredyn7,contextyn7,bit-xoryn1,*yn11,bit-and-notyn1,%yn1,-yn7,bit-andyn2,>>yn1,/yn6,bit-oryn1,+yn2,<<yn3,incyn1,tyn2,tfyn4,inityn4,iotayn2,rfyn2,nfyn4,tailyn1,vyn7,node-idyn5,labelyn6,targetyn4,objsyn2,kwyn4,kindyn4,lastkn7,dynamicyn5,formsyn5,stmtsyn2,idyn1,syn2,psyn2,rsyn4,recvyn3,sigyn4,bodyyn5,namedv11,arbace.core5,in-nsR0,v20,arbace.go.check.code9,new-localm10,R1,L1,V6,R2,R3,R4,R5,R6,m2,R7,R8,R9,s58,A new local variable object (not yet declared in a scope).R10,i5,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code8,declare!m10,R1,L1,V4,R2,R3,R13,R5,R9,s75,Declares object x named nm in cx's block scope (redeclaration is an error).R10,i16,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code8,block-cxm8,R1,L1,V1,R2,R10,i27,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code6,blank?m10,R14,TR1,L1,V1,R5,R10,i31,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,lhs-placem10,R1,L1,V2,R2,R5,R9,s75,An assignment's left-hand side: a place node ({:op :place-...}), or :blank.R10,i33,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code12,values-formsm10,R14,TR1,L1,V1,R5,R10,i61,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,count-strm10,R14,TR1,L1,V2,R15,R16,R10,i63,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,mismatch!m10,R14,TR1,L1,V5,R5,R17,R18,R19,R20,R10,i65,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,call-form?m10,R1,L1,V1,R5,R9,s81,Whether a form is a Go call expression: a call, a conversion or a builtin's call.R10,i80,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,rhs-valuesm10,R1,L1,V4,R2,R5,R17,R18,R9,s218,The values of the right-hand side forms for nl targets: a vector of nodes (a single call or\n  comma-ok expression expanded), or nil after a count mismatch. hints: the targets' types for\n  elided literals (nil allowed).R10,i93,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,init-var*m8,R21,TR10,i110,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code8,init-varm10,R1,L1,V4,R2,R13,R15,R22,R9,s82,go/types' initVar: the value n for variable x (its type inferred from n when nil).R10,i112,R11,i1,R12,s28,arbace/go/check/code_stmt.aem10,R14,TR1,L1,V4,R2,R13,R15,R22,R10,i119,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,assign-stmtm10,R1,L1,V2,R2,R5,R9,s47,(set! place value), (set! (values p ...) init).R10,i132,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code13,op-assign-opsS11,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,m8,R14,TR10,i151,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code14,op-assign-stmtm10,R1,L1,V2,R2,R5,R9,s22,(set! place op value).R10,i154,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,incdec-stmtm8,R1,L1,V3,R2,R5,R34,R10,i169,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code12,target-namesm10,R14,TR1,L1,V1,R35,R10,i184,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code17,verify-const-val!m12,R14,TR1,L1,V3,R5,R3,R15,R9,s58,Compares a constant's computed value with its :val (§3.6).R10,i186,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,local-constm10,R1,L1,V4,R2,R36,R37,R38,R9,s45,A local constant (^:const binding): its node.R10,i199,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,zero-form?m10,R14,TR1,L1,V1,R5,R10,i223,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code14,short-var-declm10,R1,L1,V4,R2,R5,R36,R39,R9,s53,x := e, (values a b) := ...: [lhs-objects rhs-nodes].R10,i225,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code8,var-declm10,R1,L1,V4,R2,R5,R36,R39,R9,s70,var x T = e, var x T, var x = e, var a, b = f(): the declaration node.R10,i273,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code15,ambient-tparamsm12,R14,TR1,L1,V1,R2,R9,s79,The type parameters declared in the scopes enclosing cx's, up to the package's.R10,i293,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,local-typem10,R1,L1,V3,R2,R40,R36,R9,s43,A local type declaration Name T (let-type).R10,i302,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code4,stmtm8,R21,TR10,i336,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code5,stmt*m8,R21,TR10,i336,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code12,branch-stmtsm8,R21,TR10,i336,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code8,let-stmtm10,R1,L1,V3,R2,R5,R41,R9,s106,(let [bindings] body...): each pair a Go statement in the current block, the body the rest\n  of the block.R10,i338,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code13,let-type-stmtm8,R1,L1,V3,R2,R5,R41,R10,i381,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code7,clause?m10,R14,TR1,L1,V1,R5,R10,i388,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,init-stmtm12,R14,TR1,L1,V2,R2,R42,R9,s83,An init vector: [] none, [target expr] a := declaration, [stmt] a simple statement.R10,i390,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,conditionm8,R1,L1,V3,R2,R5,R16,R10,i399,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code6,branchm10,R1,L1,V3,R2,R5,R41,R9,s86,A branch (then, else, a cond value): one statement or (do ...), in a block of its own.R10,i407,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code7,if-stmtm8,R1,L1,V3,R2,R5,R41,R10,i415,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,when-stmtm8,R1,L1,V3,R2,R5,R41,R10,i425,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,cond-stmtm8,R1,L1,V3,R2,R5,R41,R10,i434,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code7,loop-cxm10,R14,TR1,L1,V3,R2,R43,R44,R10,i447,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,note-break!m10,R14,TR1,L1,V2,R2,R45,R10,i450,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,switch-stmtm8,R1,L1,V4,R2,R5,R41,R44,R10,i453,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code16,type-switch-stmtm8,R1,L1,V4,R2,R5,R41,R44,R10,i504,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,select-stmtm8,R1,L1,V4,R2,R5,R41,R44,R10,i565,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code14,per-iteration!m10,R14,TR1,L1,V2,R2,R46,R10,i592,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code8,for-stmtm8,R1,L1,V3,R2,R5,R44,R10,i596,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,while-stmtm8,R1,L1,V3,R2,R5,R44,R10,i610,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,range-typesm12,R14,TR1,L1,V2,R2,R13,R9,s73,[kind key-type value-type] of ranging over node x, or nil (cannot range).R10,i617,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,range-causem12,R14,TR1,L1,V2,R2,R13,R9,s68,Why x cannot be ranged over (go/types' rangeKeyVal's cause), or nil.R10,i648,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,range-stmtm8,R1,L1,V3,R2,R5,R44,R10,i677,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,return-stmtm8,R1,L1,V2,R2,R5,R10,i724,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code19,discarding-builtinsS18,s3,mins5,Slices10,StringDatas3,maxs3,news4,imags7,Alignofs4,reals4,makes3,Adds6,Strings6,Sizeofs6,appends9,SliceDatas8,Offsetofs3,lens3,caps7,complexm10,R14,TR10,i763,R11,i1,R12,s28,arbace/go/check/code_stmt.aeR9,s92,The built-in functions of kind expression (go/types' predeclaredFuncs), unsafe's among them.v20,arbace.go.check.code13,go-defer-stmtm8,R1,L1,V3,R2,R5,R47,R10,i768,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,send-stmtm8,R1,L1,V2,R2,R5,R10,i781,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,branch-stmtm10,R1,L1,V3,R2,R5,R48,R9,s135,break, continue, goto, fallthrough: their targets for the terminating analysis (the errors\n  are gc's branch checks', check-branches!).R10,i797,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,label-stmtm8,R1,L1,V4,R2,R5,R41,R49,R10,i811,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,expr-stmtm10,R1,L1,V2,R2,R5,R9,s75,An expression in a statement position: a call or a receive (else an error).R10,i827,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code11,panic-call?m10,R14,TR1,L1,V1,R5,R10,i840,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code15,statement-headsS26,s5,ranges5,defers5,labels6,returns2,>!s4,set!s3,fors11,fallthroughs4,dec!s4,conds2,ifs3,lets2,gos6,switchs6,selects5,breaks4,whens8,let-types8,continues2,dos4,inc!s5,whiles4,asets12,go/directives4,gotos11,type-switchm6,R10,i842,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code13,*stmt-parent*m10,R50,TR10,i847,R11,i1,R12,s28,arbace/go/check/code_stmt.aeR9,s133,The statement form (or function form) whose children stmt-list checks: a literal statement's\n  line is its child line (e/child-line).m10,R1,L1,V4,R2,R5,R41,R49,R9,s94,A statement form (tail: the function's last statement position; last: the last of its\n  list).R10,i852,R11,i1,R12,s28,arbace/go/check/code_stmt.aem8,R1,L1,V4,R2,R5,R41,R49,R10,i864,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,stmt-listm10,R1,L1,V3,R2,R51,R41,R9,s73,The statements of a list (tail: whether the list ends the function body).R10,i903,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code12,terminating?m8,R21,TR10,i927,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,*term-cx*m10,R50,TR10,i929,R11,i1,R12,s28,arbace/go/check/code_stmt.aeR9,s62,The function context of the terminating analysis (its breaks).v20,arbace.go.check.code17,list-terminating?m10,R14,TR1,L1,V1,R52,R10,i931,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code10,has-break?m10,R14,TR1,L1,V2,R2,R53,R10,i935,R11,i1,R12,s28,arbace/go/check/code_stmt.aem10,R1,L2,V1,R54,V2,R2,R54,R9,s79,go/types' isTerminating of a checked statement (breaks: the ids broken out of).R10,i937,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code15,declare-params!m12,R14,TR1,L1,V4,R2,R55,R56,R57,R9,s91,Declares a function's parameters and named results in its scope: [param-objs result-specs].R10,i970,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code14,report-unused!m8,R1,L1,V1,R2,R10,i983,R11,i1,R12,s28,arbace/go/check/code_stmt.aev20,arbace.go.check.code9,func-bodym10,R1,L2,V7,R2,R5,R58,R55,R56,R59,R60,V8,R2,R5,R58,R55,R56,R59,R60,R57,R9,s167,A function's body (a package function, a method, a literal): its node. cx is the enclosing\n  context (the file's for declarations); f the declaring form (for :go/end).R10,i988,R11,i1,R12,s28,arbace/go/check/code_stmt.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.code$new_local")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.code$declare_BANG_")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.code$block_cx")

var Lit_4 *jrt.String = jrt.Intern("arbace.go.check.code$blank_QMARK_")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.code$lhs_place")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.code$values_forms")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.code$count_str")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.code$mismatch_BANG_")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.code$call_form_QMARK_")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.code$rhs_values")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.code$init_var")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.code$init_var_STAR_")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.code$assign_stmt")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.code$op_assign_stmt")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.code$incdec_stmt")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.code$target_names")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.code$verify_const_val_BANG_")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.code$local_const")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.code$zero_form_QMARK_")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.code$short_var_decl")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.code$var_decl")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.code$ambient_tparams")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.code$local_type")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.code$let_stmt")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.code$let_type_stmt")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check.code$clause_QMARK_")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.code$init_stmt")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.code$condition")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.code$branch")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.code$if_stmt")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.code$when_stmt")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.code$cond_stmt")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.code$loop_cx")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.code$note_break_BANG_")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.code$switch_stmt")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.code$type_switch_stmt")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.code$select_stmt")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.code$per_iteration_BANG_")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.code$for_stmt")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.code$while_stmt")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.code$range_types")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.code$range_cause")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.code$range_stmt")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.code$return_stmt")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.code$go_defer_stmt")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.code$send_stmt")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check.code$branch_stmt")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.code$label_stmt")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.code$expr_stmt")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.code$panic_call_QMARK_")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.code$stmt")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check.code$stmt_STAR_")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.code$stmt_list")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.code$list_terminating_QMARK_")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.code$has_break_QMARK_")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check.code$terminating_QMARK_")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.code$declare_params_BANG_")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.check.code$report_unused_BANG_")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.code$func_body")
