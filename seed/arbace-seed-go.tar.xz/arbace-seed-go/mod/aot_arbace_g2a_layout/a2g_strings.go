//line a2g_strings.ae:1
package aot_arbace_g2a_layout

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.g2a.litkn2,asyn3,lityn13,arbace.stringyn3,strkn3,docks18,arbace.g2a.convert5,derefkn4,lineks18,arbace.g2a.convert1,lks18,arbace.g2a.convert3,rawkn5,lineskn4,elsekn3,brkks17,arbace.g2a.layout3,brkkn16,layout-late-listkn3,poskn4,fullks2,go6,breaksks2,go4,aposks2,go3,endks18,arbace.g2a.convert3,posks2,go3,poskn3,valkn3,tagkn4,textkn1,xv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn17,arbace.g2a.layoutm2,R6,s770,Writes Go forms (arbace.g2a.convert's in-memory forms) as Clojure text (doc/go/SPEC.md §10).\n\n  Mode :lines: every form that begins a Go line is written on that line of the .ae file. A\n  first pass (prepare) decides the breaks: a form whose Go line is after everything written\n  before it starts a new line; it then carries its line as the reader will give it back, a list\n  by itself (the reader's :line), a symbol, vector or @ form by explicit :line metadata, a\n  literal in its parent's :go/breaks (its index, or [index line] when its line is not the one\n  after the last written). Ordinary comments are written as ; comments at the end of\n  their Go line, or as ;; lines. Mode :full writes every node's positions as :go/pos and\n  :go/apos (§10.2) on the same layout.v11,arbace.core13,*loaded-libs*v11,arbace.core8,keyword?v17,arbace.g2a.layout10,private-nsv11,arbace.core9,namespacev11,arbace.core4,seq?R7,v14,arbace.g2a.lit4,lit?R8,v17,arbace.g2a.layout5,iobj?R9,v17,arbace.g2a.layout7,*stats*v11,arbace.core5,swap!v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core3,incl0,v11,arbace.core7,vector?R10,v17,arbace.g2a.layout6,*mode*R11,v11,arbace.core3,seqv11,arbace.core10,sorted-mapv11,arbace.core5,firstv17,arbace.g2a.layout9,form-linev11,arbace.core5,assocv11,arbace.core9,vary-metaR12,v17,arbace.g2a.layout4,prepR13,v11,arbace.core3,notv17,arbace.g2a.layout11,deref-form?R14,v17,arbace.g2a.layout5,note!R15,v11,arbace.core4,nextR16,v11,arbace.core5,applyR17,v11,arbace.core4,listR18,R19,v11,arbace.core9,with-metav17,arbace.g2a.layout9,key-orderv11,arbace.core7,sort-byv17,arbace.g2a.layout8,key-rankv11,arbace.core3,strv11,arbace.core4,intov11,arbace.core6,dissocv11,arbace.core6,removev17,arbace.g2a.layout8,private?R20,R21,R22,v17,arbace.g2a.layout11,public-metav17,arbace.g2a.layout9,sort-keysv11,arbace.core6,filterv11,arbace.core4,keysv11,arbace.core5,true?v11,arbace.core4,not=R23,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core6,empty?V1,R24,v11,arbace.core7,symbol?R24,v11,arbace.core10,chunk-restv13,arbace.string4,joinv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv17,arbace.g2a.layout4,textv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restR25,v11,arbace.core7,string?v14,arbace.g2a.lit11,string-textv11,arbace.core5,char?v14,arbace.g2a.lit9,char-textv11,arbace.core8,integer?v11,arbace.core8,boolean?v11,arbace.core6,ratio?v11,arbace.core7,ex-infov11,arbace.core5,classR26,v17,arbace.g2a.layout11,meta-prefixv11,arbace.core4,map?v17,arbace.g2a.layout9,atom-textv11,arbace.core6,secondv11,arbace.core3,mapv13,arbace.string12,starts-with?v11,arbace.core4,subsv13,arbace.string4,triml2,v17,arbace.g2a.layout7,preparev11,arbace.core9,volatile!v17,arbace.g2a.layout12,comment-textv11,arbace.core6,repeatv11,arbace.core7,vreset!v11,arbace.core11,map-indexedv11,arbace.core6,vectorl1,v11,arbace.core3,maxv11,arbace.core9,partition")

var Lit_1 *jrt.String = jrt.Intern("nil")

var Lit_2 *jrt.String = jrt.Intern("N")

var Lit_3 *jrt.String = jrt.Intern("##NaN")

var Lit_4 *jrt.String = jrt.Intern("##Inf")

var Lit_5 *jrt.String = jrt.Intern("##-Inf")

var Lit_6 *jrt.String = jrt.Intern("M")

var Lit_7 *jrt.String = jrt.Intern("can't write ")

var Lit_8 *jrt.String = jrt.Intern("//")

var Lit_9 *jrt.String = jrt.Intern(" ")

var Lit_10 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$fn__1123000051")

var Lit_11 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$fn__1123000053")

var Lit_12 *jrt.String = jrt.Intern("^")

var Lit_13 *jrt.String = jrt.Intern("^{")

var Lit_14 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063")

var Lit_15 *jrt.String = jrt.Intern("} ")

var Lit_16 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064")

var Lit_17 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064$fn__1123000065")

var Lit_18 *jrt.String = jrt.Intern("arbace.g2a.layout$prep$fn__1123000020")

var Lit_19 *jrt.String = jrt.Intern("arbace.g2a.layout$prep$fn__1123000020$fn__1123000024")

var Lit_20 *jrt.String = jrt.Intern("arbace.g2a.layout$public_meta$fn__1123000042")

var Lit_21 *jrt.String = jrt.Intern("arbace.g2a.layout$sort_keys$fn__1123000038")

var Lit_22 *jrt.String = jrt.Intern("@")

var Lit_23 *jrt.String = jrt.Intern("(")

var Lit_24 *jrt.String = jrt.Intern(")")

var Lit_25 *jrt.String = jrt.Intern("[")

var Lit_26 *jrt.String = jrt.Intern("]")

var Lit_27 *jrt.String = jrt.Intern("{")

var Lit_28 *jrt.String = jrt.Intern("}")

var Lit_29 *jrt.String = jrt.Intern("arbace.g2a.layout$text$iter__1123000071__1123000075")

var Lit_30 *jrt.String = jrt.Intern("arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076")

var Lit_31 *jrt.String = jrt.Intern("arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076$fn__1123000077")

var Lit_32 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file$flush_comments_BANG___1123000089")

var Lit_33 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file$newline_to_BANG___1123000091")

var Lit_34 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file$emit__1123000093")

var Lit_35 *jrt.String = jrt.Intern("\n")

var Lit_36 *jrt.String = jrt.Intern(" ;")

var Lit_37 *jrt.String = jrt.Intern(";;")

var Lit_38 *jrt.String = jrt.Intern(" ;;")

var Lit_39 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000113__1123000117")

var Lit_40 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000129__1123000133")

var Lit_41 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118")

var Lit_42 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118$fn__1123000119")

var Lit_43 *jrt.String = jrt.Intern("\n  ")

var Lit_44 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134")

var Lit_45 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134$fn__1123000135")

var Lit_46 *jrt.String = jrt.Intern("(load ")

var Lit_47 *jrt.String = jrt.Intern(")\n")

var Lit_48 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,kyn1,xkn5,lineskn7,dynamicyn6,cursoryn5,formskn8,declaredkn5,aliaskn6,externkn5,constkn3,varkn6,assignks2,go7,groupedkn3,tagkn3,valkn4,instks2,go3,viaks2,go3,tagyn2,ksyn6,Stringyn8,commentsyn6,ns-symyn8,pkg-formyn5,loadsv11,arbace.core5,in-nsMyn17,arbace.g2a.layoutm2,R0,s770,Writes Go forms (arbace.g2a.convert's in-memory forms) as Clojure text (doc/go/SPEC.md §10).\n\n  Mode :lines: every form that begins a Go line is written on that line of the .ae file. A\n  first pass (prepare) decides the breaks: a form whose Go line is after everything written\n  before it starts a new line; it then carries its line as the reader will give it back, a list\n  by itself (the reader's :line), a symbol, vector or @ form by explicit :line metadata, a\n  literal in its parent's :go/breaks (its index, or [index line] when its line is not the one\n  after the last written). Ordinary comments are written as ; comments at the end of\n  their Go line, or as ;; lines. Mode :full writes every node's positions as :go/pos and\n  :go/apos (§10.2) on the same layout.m2,R0,s770,Writes Go forms (arbace.g2a.convert's in-memory forms) as Clojure text (doc/go/SPEC.md §10).\n\n  Mode :lines: every form that begins a Go line is written on that line of the .ae file. A\n  first pass (prepare) decides the breaks: a form whose Go line is after everything written\n  before it starts a new line; it then carries its line as the reader will give it back, a list\n  by itself (the reader's :line), a symbol, vector or @ form by explicit :line metadata, a\n  literal in its parent's :go/breaks (its index, or [index line] when its line is not the one\n  after the last written). Ordinary comments are written as ; comments at the end of\n  their Go line, or as ;; lines. Mode :full writes every node's positions as :go/pos and\n  :go/apos (§10.2) on the same layout.R1,v17,arbace.g2a.layout10,private-nsm8,R2,TR3,i15,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout8,private?m10,R2,TR6,L1,V1,R7,R3,i17,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout5,iobj?m10,R2,TR6,L1,V1,R8,R3,i19,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout11,deref-form?m10,R2,TR6,L1,V1,R8,R3,i21,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout9,form-linem10,R6,L1,V1,R8,R0,s41,The Go line a form begins on, when known.R3,i23,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout6,*mode*R9,m8,R10,TR3,i30,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout7,*stats*m8,R10,TR3,i31,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout5,note!m10,R2,TR6,L1,V1,R7,R3,i33,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout4,prepm12,R2,TR6,L1,V2,R8,R11,R0,s84,Returns [x' cursor] for x written with the cursor (the last line written) at cursor.R3,i37,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout7,preparem10,R6,L1,V1,R12,R0,s58,The top-level forms with their breaks, starting at line 1.R3,i77,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout4,textm8,R13,TR3,i92,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout9,key-orderV13,R3,R14,R15,R16,R17,R18,R19,R20,R21,R22,R23,R24,R0,m8,R2,TR3,i94,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout8,key-rankm10,R2,TR6,L1,V1,R7,R3,i97,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout9,sort-keysm10,R2,TR6,L1,V1,R25,R3,i101,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout11,public-metam10,R6,L1,V1,R8,R0,s27,The metadata written for x.R3,i104,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout11,meta-prefixm10,R2,TR6,L1,V1,R8,R3,i116,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout9,atom-textm10,R2,TR6,L1,V1,R8,R3,i134,R4,i1,R5,s20,arbace/g2a/layout.aem10,R6,L1,V1,R8,R0,s58,x as text on one line (metadata values, the package file).R3,i154,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout12,comment-textm12,R2,TR6,L1,V1,Myn1,tm2,R20,R26,R0,s44,A Go comment line as the text after ; or ;;.R3,i167,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout10,write-filem10,R6,L1,V2,R12,R27,R0,s82,The text of a Go file's forms (prepared here) with its comments {line [text ...]}.R3,i174,R4,i1,R5,s20,arbace/g2a/layout.aev17,arbace.g2a.layout13,write-packagem10,R6,L1,V3,R28,R29,R30,R0,s83,The text of a package file: ns, go/package with one option per line, and the loads.R3,i231,R4,i1,R5,s20,arbace/g2a/layout.ae")

var Lit_49 *jrt.String = jrt.Intern("arbace.g2a.layout$eval1123000004$loading__1927001464__auto____1123000005")

var Lit_50 *jrt.String = jrt.Intern("arbace.g2a.layout$eval1123000008$fn__1123000009")

var Lit_51 *jrt.String = jrt.Intern("arbace.g2a.convert")

var Lit_52 *jrt.String = jrt.Intern("arbace.g2a.layout$private_QMARK_")

var Lit_53 *jrt.String = jrt.Intern("arbace.g2a.layout$iobj_QMARK_")

var Lit_54 *jrt.String = jrt.Intern("arbace.g2a.layout$deref_form_QMARK_")

var Lit_55 *jrt.String = jrt.Intern("arbace.g2a.layout$form_line")

var Lit_56 *jrt.String = jrt.Intern("arbace.g2a.layout$note_BANG_")

var Lit_57 *jrt.String = jrt.Intern("arbace.g2a.layout$prep")

var Lit_58 *jrt.String = jrt.Intern("arbace.g2a.layout$prepare")

var Lit_59 *jrt.String = jrt.Intern("arbace.g2a.layout$key_rank")

var Lit_60 *jrt.String = jrt.Intern("arbace.g2a.layout$sort_keys")

var Lit_61 *jrt.String = jrt.Intern("arbace.g2a.layout$public_meta")

var Lit_62 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix")

var Lit_63 *jrt.String = jrt.Intern("arbace.g2a.layout$atom_text")

var Lit_64 *jrt.String = jrt.Intern("arbace.g2a.layout$text")

var Lit_65 *jrt.String = jrt.Intern("arbace.g2a.layout$comment_text")

var Lit_66 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file")

var Lit_67 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package")
