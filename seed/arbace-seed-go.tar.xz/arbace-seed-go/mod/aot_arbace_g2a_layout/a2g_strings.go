//line a2g_strings.ae:1
package aot_arbace_g2a_layout

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.g2a.lit")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("lit")

var Lit_6 *jrt.String = jrt.Intern("arbace.string")

var Lit_7 *jrt.String = jrt.Intern("str")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.g2a.layout")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("Writes Go forms (arbace.g2a.convert's in-memory forms) as Clojure text (doc/go/SPEC.md §10).\n\n  Mode :lines: every form that begins a Go line is written on that line of the .ae file. A\n  first pass (prepare) decides the breaks: a form whose Go line is after everything written\n  before it starts a new line; it then carries its line as the reader will give it back, a list\n  by itself (the reader's :line), a symbol, vector or @ form by explicit :line metadata, a\n  literal in its parent's :go/breaks (its index, or [index line] when its line is not the one\n  after the last written). Ordinary comments are written as ; comments at the end of\n  their Go line, or as ;; lines. Mode :full writes every node's positions as :go/pos and\n  :go/apos (§10.2) on the same layout.")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("keyword?")

var Lit_16 *jrt.String = jrt.Intern("private-ns")

var Lit_17 *jrt.String = jrt.Intern("namespace")

var Lit_18 *jrt.String = jrt.Intern("seq?")

var Lit_19 *jrt.String = jrt.Intern("arbace.g2a.convert")

var Lit_20 *jrt.String = jrt.Intern("lit?")

var Lit_21 *jrt.String = jrt.Intern("line")

var Lit_22 *jrt.String = jrt.Intern("iobj?")

var Lit_23 *jrt.String = jrt.Intern("l")

var Lit_24 *jrt.String = jrt.Intern("*stats*")

var Lit_25 *jrt.String = jrt.Intern("swap!")

var Lit_26 *jrt.String = jrt.Intern("update")

var Lit_27 *jrt.String = jrt.Intern("fnil")

var Lit_28 *jrt.String = jrt.Intern("inc")

var Lit_29 *jrt.String = jrt.Intern("vector?")

var Lit_30 *jrt.String = jrt.Intern("raw")

var Lit_31 *jrt.String = jrt.Intern("*mode*")

var Lit_32 *jrt.String = jrt.Intern("lines")

var Lit_33 *jrt.String = jrt.Intern("seq")

var Lit_34 *jrt.String = jrt.Intern("sorted-map")

var Lit_35 *jrt.String = jrt.Intern("first")

var Lit_36 *jrt.String = jrt.Intern("form-line")

var Lit_37 *jrt.String = jrt.Intern("assoc")

var Lit_38 *jrt.String = jrt.Intern("vary-meta")

var Lit_39 *jrt.String = jrt.Intern("else")

var Lit_40 *jrt.String = jrt.Intern("prep")

var Lit_41 *jrt.String = jrt.Intern("brk")

var Lit_42 *jrt.String = jrt.Intern("not")

var Lit_43 *jrt.String = jrt.Intern("deref-form?")

var Lit_44 *jrt.String = jrt.Intern("note!")

var Lit_45 *jrt.String = jrt.Intern("layout-late-list")

var Lit_46 *jrt.String = jrt.Intern("next")

var Lit_47 *jrt.String = jrt.Intern("pos")

var Lit_48 *jrt.String = jrt.Intern("apply")

var Lit_49 *jrt.String = jrt.Intern("full")

var Lit_50 *jrt.String = jrt.Intern("list")

var Lit_51 *jrt.String = jrt.Intern("go")

var Lit_52 *jrt.String = jrt.Intern("breaks")

var Lit_53 *jrt.String = jrt.Intern("apos")

var Lit_54 *jrt.String = jrt.Intern("with-meta")

var Lit_55 *jrt.String = jrt.Intern("key-order")

var Lit_56 *jrt.String = jrt.Intern("sort-by")

var Lit_57 *jrt.String = jrt.Intern("key-rank")

var Lit_58 *jrt.String = jrt.Intern("into")

var Lit_59 *jrt.String = jrt.Intern("dissoc")

var Lit_60 *jrt.String = jrt.Intern("remove")

var Lit_61 *jrt.String = jrt.Intern("private?")

var Lit_62 *jrt.String = jrt.Intern("end")

var Lit_63 *jrt.String = jrt.Intern("public-meta")

var Lit_64 *jrt.String = jrt.Intern("sort-keys")

var Lit_65 *jrt.String = jrt.Intern("filter")

var Lit_66 *jrt.String = jrt.Intern("keys")

var Lit_67 *jrt.String = jrt.Intern("true?")

var Lit_68 *jrt.String = jrt.Intern("not=")

var Lit_69 *jrt.String = jrt.Intern("val")

var Lit_70 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_71 *jrt.String = jrt.Intern("chunk-first")

var Lit_72 *jrt.String = jrt.Intern("empty?")

var Lit_73 *jrt.String = jrt.Intern("tag")

var Lit_74 *jrt.String = jrt.Intern("symbol?")

var Lit_75 *jrt.String = jrt.Intern("chunk-rest")

var Lit_76 *jrt.String = jrt.Intern("join")

var Lit_77 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_78 *jrt.String = jrt.Intern("chunk-append")

var Lit_79 *jrt.String = jrt.Intern("text")

var Lit_80 *jrt.String = jrt.Intern("chunk-cons")

var Lit_81 *jrt.String = jrt.Intern("cons")

var Lit_82 *jrt.String = jrt.Intern("chunk")

var Lit_83 *jrt.String = jrt.Intern("rest")

var Lit_84 *jrt.String = jrt.Intern("string?")

var Lit_85 *jrt.String = jrt.Intern("string-text")

var Lit_86 *jrt.String = jrt.Intern("char?")

var Lit_87 *jrt.String = jrt.Intern("char-text")

var Lit_88 *jrt.String = jrt.Intern("integer?")

var Lit_89 *jrt.String = jrt.Intern("boolean?")

var Lit_90 *jrt.String = jrt.Intern("ratio?")

var Lit_91 *jrt.String = jrt.Intern("ex-info")

var Lit_92 *jrt.String = jrt.Intern("class")

var Lit_93 *jrt.String = jrt.Intern("x")

var Lit_94 *jrt.String = jrt.Intern("meta-prefix")

var Lit_95 *jrt.String = jrt.Intern("map?")

var Lit_96 *jrt.String = jrt.Intern("atom-text")

var Lit_97 *jrt.String = jrt.Intern("second")

var Lit_98 *jrt.String = jrt.Intern("map")

var Lit_99 *jrt.String = jrt.Intern("starts-with?")

var Lit_100 *jrt.String = jrt.Intern("subs")

var Lit_101 *jrt.String = jrt.Intern("trim")

var Lit_102 *jrt.String = jrt.Intern("prepare")

var Lit_103 *jrt.String = jrt.Intern("volatile!")

var Lit_104 *jrt.String = jrt.Intern("comment-text")

var Lit_105 *jrt.String = jrt.Intern("repeat")

var Lit_106 *jrt.String = jrt.Intern("vreset!")

var Lit_107 *jrt.String = jrt.Intern("map-indexed")

var Lit_108 *jrt.String = jrt.Intern("vector")

var Lit_109 *jrt.String = jrt.Intern("max")

var Lit_110 *jrt.String = jrt.Intern("partition")

var Lit_111 *jrt.String = jrt.Intern("arbace.g2a.layout$atom_text")

var Lit_112 *jrt.String = jrt.Intern("nil")

var Lit_113 *jrt.String = jrt.Intern("N")

var Lit_114 *jrt.String = jrt.Intern("##NaN")

var Lit_115 *jrt.String = jrt.Intern("##Inf")

var Lit_116 *jrt.String = jrt.Intern("##-Inf")

var Lit_117 *jrt.String = jrt.Intern("M")

var Lit_118 *jrt.String = jrt.Intern("can't write ")

var Lit_119 *jrt.String = jrt.Intern("arbace.g2a.layout$comment_text")

var Lit_120 *jrt.String = jrt.Intern("//")

var Lit_121 *jrt.String = jrt.Intern(" ")

var Lit_122 *jrt.String = jrt.Intern("arbace.g2a.layout$deref_form_QMARK_")

var Lit_123 *jrt.String = jrt.Intern("arbace.g2a.layout$eval1123000004$loading__1927001464__auto____1123000005")

var Lit_124 *jrt.String = jrt.Intern("arbace.g2a.layout$eval1123000008$fn__1123000009")

var Lit_125 *jrt.String = jrt.Intern("arbace.g2a.layout$form_line")

var Lit_126 *jrt.String = jrt.Intern("arbace.g2a.layout$iobj_QMARK_")

var Lit_127 *jrt.String = jrt.Intern("arbace.g2a.layout$key_rank")

var Lit_128 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix")

var Lit_129 *jrt.String = jrt.Intern("^")

var Lit_130 *jrt.String = jrt.Intern("^{")

var Lit_131 *jrt.String = jrt.Intern("} ")

var Lit_132 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$fn__1123000051")

var Lit_133 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$fn__1123000053")

var Lit_134 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063")

var Lit_135 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064")

var Lit_136 *jrt.String = jrt.Intern("arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064$fn__1123000065")

var Lit_137 *jrt.String = jrt.Intern("arbace.g2a.layout$note_BANG_")

var Lit_138 *jrt.String = jrt.Intern("arbace.g2a.layout$prep")

var Lit_139 *jrt.String = jrt.Intern("arbace.g2a.layout$prep$fn__1123000020")

var Lit_140 *jrt.String = jrt.Intern("arbace.g2a.layout$prep$fn__1123000020$fn__1123000024")

var Lit_141 *jrt.String = jrt.Intern("arbace.g2a.layout$prepare")

var Lit_142 *jrt.String = jrt.Intern("arbace.g2a.layout$private_QMARK_")

var Lit_143 *jrt.String = jrt.Intern("arbace.g2a.layout$public_meta")

var Lit_144 *jrt.String = jrt.Intern("arbace.g2a.layout$public_meta$fn__1123000042")

var Lit_145 *jrt.String = jrt.Intern("arbace.g2a.layout$sort_keys")

var Lit_146 *jrt.String = jrt.Intern("arbace.g2a.layout$sort_keys$fn__1123000038")

var Lit_147 *jrt.String = jrt.Intern("arbace.g2a.layout$text")

var Lit_148 *jrt.String = jrt.Intern("@")

var Lit_149 *jrt.String = jrt.Intern("(")

var Lit_150 *jrt.String = jrt.Intern(")")

var Lit_151 *jrt.String = jrt.Intern("[")

var Lit_152 *jrt.String = jrt.Intern("]")

var Lit_153 *jrt.String = jrt.Intern("{")

var Lit_154 *jrt.String = jrt.Intern("}")

var Lit_155 *jrt.String = jrt.Intern("arbace.g2a.layout$text$iter__1123000071__1123000075")

var Lit_156 *jrt.String = jrt.Intern("arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076")

var Lit_157 *jrt.String = jrt.Intern("arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076$fn__1123000077")

var Lit_158 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file")

var Lit_159 *jrt.String = jrt.Intern("\n")

var Lit_160 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file$emit__1123000093")

var Lit_161 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file$flush_comments_BANG___1123000089")

var Lit_162 *jrt.String = jrt.Intern(" ;")

var Lit_163 *jrt.String = jrt.Intern(";;")

var Lit_164 *jrt.String = jrt.Intern(" ;;")

var Lit_165 *jrt.String = jrt.Intern("arbace.g2a.layout$write_file$newline_to_BANG___1123000091")

var Lit_166 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package")

var Lit_167 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000113__1123000117")

var Lit_168 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118")

var Lit_169 *jrt.String = jrt.Intern("\n  ")

var Lit_170 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118$fn__1123000119")

var Lit_171 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000129__1123000133")

var Lit_172 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134")

var Lit_173 *jrt.String = jrt.Intern("(load ")

var Lit_174 *jrt.String = jrt.Intern(")\n")

var Lit_175 *jrt.String = jrt.Intern("arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134$fn__1123000135")

var Lit_176 *jrt.String = jrt.Intern("in-ns")

var Lit_177 *jrt.String = jrt.Intern("private")

var Lit_178 *jrt.String = jrt.Intern("column")

var Lit_179 *jrt.String = jrt.Intern("file")

var Lit_180 *jrt.String = jrt.Intern("arbace/g2a/layout.ae")

var Lit_181 *jrt.String = jrt.Intern("arglists")

var Lit_182 *jrt.String = jrt.Intern("k")

var Lit_183 *jrt.String = jrt.Intern("The Go line a form begins on, when known.")

var Lit_184 *jrt.String = jrt.Intern("dynamic")

var Lit_185 *jrt.String = jrt.Intern("cursor")

var Lit_186 *jrt.String = jrt.Intern("Returns [x' cursor] for x written with the cursor (the last line written) at cursor.")

var Lit_187 *jrt.String = jrt.Intern("forms")

var Lit_188 *jrt.String = jrt.Intern("The top-level forms with their breaks, starting at line 1.")

var Lit_189 *jrt.String = jrt.Intern("declared")

var Lit_190 *jrt.String = jrt.Intern("alias")

var Lit_191 *jrt.String = jrt.Intern("extern")

var Lit_192 *jrt.String = jrt.Intern("const")

var Lit_193 *jrt.String = jrt.Intern("var")

var Lit_194 *jrt.String = jrt.Intern("assign")

var Lit_195 *jrt.String = jrt.Intern("grouped")

var Lit_196 *jrt.String = jrt.Intern("inst")

var Lit_197 *jrt.String = jrt.Intern("via")

var Lit_198 *jrt.String = jrt.Intern("ks")

var Lit_199 *jrt.String = jrt.Intern("The metadata written for x.")

var Lit_200 *jrt.String = jrt.Intern("x as text on one line (metadata values, the package file).")

var Lit_201 *jrt.String = jrt.Intern("t")

var Lit_202 *jrt.String = jrt.Intern("String")

var Lit_203 *jrt.String = jrt.Intern("A Go comment line as the text after ; or ;;.")

var Lit_204 *jrt.String = jrt.Intern("write-file")

var Lit_205 *jrt.String = jrt.Intern("comments")

var Lit_206 *jrt.String = jrt.Intern("The text of a Go file's forms (prepared here) with its comments {line [text ...]}.")

var Lit_207 *jrt.String = jrt.Intern("write-package")

var Lit_208 *jrt.String = jrt.Intern("ns-sym")

var Lit_209 *jrt.String = jrt.Intern("pkg-form")

var Lit_210 *jrt.String = jrt.Intern("loads")

var Lit_211 *jrt.String = jrt.Intern("The text of a package file: ns, go/package with one option per line, and the loads.")
