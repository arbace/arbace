//line a2g_classes.ae:1
package aot_arbace_g2a_layout

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_g2a_layout_atom_text_A_class, Name: "arbace.g2a.layout$atom_text", Modifiers: 25, Simple: "atom_text", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_atom_text_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_comment_text_A_class, Name: "arbace.g2a.layout$comment_text", Modifiers: 25, Simple: "comment_text", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_comment_text_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_deref_form_QMARK__A_class, Name: "arbace.g2a.layout$deref_form_QMARK_", Modifiers: 25, Simple: "deref_form_QMARK_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_deref_form_QMARK__A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_class, Name: "arbace.g2a.layout$eval1123000004$loading__1927001464__auto____1123000005", Modifiers: 25, Simple: "loading__1927001464__auto____1123000005", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_eval1123000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_class, Name: "arbace.g2a.layout$eval1123000008$fn__1123000009", Modifiers: 25, Simple: "fn__1123000009", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000008_fn__1123000009_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_eval1123000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_form_line_A_class, Name: "arbace.g2a.layout$form_line", Modifiers: 25, Simple: "form_line", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_form_line_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_iobj_QMARK__A_class, Name: "arbace.g2a.layout$iobj_QMARK_", Modifiers: 25, Simple: "iobj_QMARK_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_iobj_QMARK__A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_key_rank_A_class, Name: "arbace.g2a.layout$key_rank", Modifiers: 25, Simple: "key_rank", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_key_rank_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_meta_prefix_A_class, Name: "arbace.g2a.layout$meta_prefix", Modifiers: 25, Simple: "meta_prefix", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_class, Name: "arbace.g2a.layout$meta_prefix$fn__1123000051", Modifiers: 25, Simple: "fn__1123000051", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_fn__1123000051_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_meta_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_class, Name: "arbace.g2a.layout$meta_prefix$fn__1123000053", Modifiers: 25, Simple: "fn__1123000053", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_fn__1123000053_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_meta_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class, Name: "arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063", Modifiers: 25, Simple: "iter__1123000059__1123000063", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_meta_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class, Name: "arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064", Modifiers: 25, Simple: "fn__1123000064", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_class, Name: "arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064$fn__1123000065", Modifiers: 25, Simple: "fn__1123000065", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_note_BANG__A_class, Name: "arbace.g2a.layout$note_BANG_", Modifiers: 25, Simple: "note_BANG_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_note_BANG__A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_prep_A_class, Name: "arbace.g2a.layout$prep", Modifiers: 25, Simple: "prep", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prep_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_prep_fn__1123000020_A_class, Name: "arbace.g2a.layout$prep$fn__1123000020", Modifiers: 25, Simple: "fn__1123000020", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prep_fn__1123000020_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_prep_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_class, Name: "arbace.g2a.layout$prep$fn__1123000020$fn__1123000024", Modifiers: 25, Simple: "fn__1123000024", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_prep_fn__1123000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_prepare_A_class, Name: "arbace.g2a.layout$prepare", Modifiers: 25, Simple: "prepare", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prepare_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_private_QMARK__A_class, Name: "arbace.g2a.layout$private_QMARK_", Modifiers: 25, Simple: "private_QMARK_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_private_QMARK__A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_public_meta_A_class, Name: "arbace.g2a.layout$public_meta", Modifiers: 25, Simple: "public_meta", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_public_meta_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_public_meta_fn__1123000042_A_class, Name: "arbace.g2a.layout$public_meta$fn__1123000042", Modifiers: 25, Simple: "fn__1123000042", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_public_meta_fn__1123000042_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_public_meta_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_sort_keys_A_class, Name: "arbace.g2a.layout$sort_keys", Modifiers: 25, Simple: "sort_keys", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_sort_keys_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_sort_keys_fn__1123000038_A_class, Name: "arbace.g2a.layout$sort_keys$fn__1123000038", Modifiers: 25, Simple: "fn__1123000038", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_sort_keys_fn__1123000038_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_sort_keys_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_text_A_class, Name: "arbace.g2a.layout$text", Modifiers: 25, Simple: "text", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class, Name: "arbace.g2a.layout$text$iter__1123000071__1123000075", Modifiers: 25, Simple: "iter__1123000071__1123000075", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_iter__1123000071__1123000075_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class, Name: "arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076", Modifiers: 25, Simple: "fn__1123000076", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_class, Name: "arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076$fn__1123000077", Modifiers: 25, Simple: "fn__1123000077", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_file_A_class, Name: "arbace.g2a.layout$write_file", Modifiers: 25, Simple: "write_file", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_file_emit__1123000093_A_class, Name: "arbace.g2a.layout$write_file$emit__1123000093", Modifiers: 25, Simple: "emit__1123000093", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_emit__1123000093_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_class, Name: "arbace.g2a.layout$write_file$flush_comments_BANG___1123000089", Modifiers: 25, Simple: "flush_comments_BANG___1123000089", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_class, Name: "arbace.g2a.layout$write_file$newline_to_BANG___1123000091", Modifiers: 25, Simple: "newline_to_BANG___1123000091", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_package_A_class, Name: "arbace.g2a.layout$write_package", Modifiers: 25, Simple: "write_package", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class, Name: "arbace.g2a.layout$write_package$iter__1123000113__1123000117", Modifiers: 25, Simple: "iter__1123000113__1123000117", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_package_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class, Name: "arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118", Modifiers: 25, Simple: "fn__1123000118", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_class, Name: "arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118$fn__1123000119", Modifiers: 25, Simple: "fn__1123000119", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class, Name: "arbace.g2a.layout$write_package$iter__1123000129__1123000133", Modifiers: 25, Simple: "iter__1123000129__1123000133", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_package_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class, Name: "arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134", Modifiers: 25, Simple: "fn__1123000134", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_class, Name: "arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134$fn__1123000135", Modifiers: 25, Simple: "fn__1123000135", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A", Source: "layout.ae", Declaring: &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_g2a_layout_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_A_New()}; return nil }

var A_arbace_g2a_layout_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_layout_A_new}

var A_arbace_g2a_layout_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_A"})

func init() { i := A_arbace_g2a_layout_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_A_InstanceOf; i.Init = A_arbace_g2a_layout_A_Init; i.Table = A_arbace_g2a_layout_A_members }

var A_arbace_g2a_layout_atom_text_A_class *jrt.Class

var A_arbace_g2a_layout_comment_text_A_class *jrt.Class

var A_arbace_g2a_layout_deref_form_QMARK__A_class *jrt.Class

func A_arbace_g2a_layout_eval1123000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_eval1123000004_A_New()}; return nil }

var A_arbace_g2a_layout_eval1123000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_layout_eval1123000004_A_new}

var A_arbace_g2a_layout_eval1123000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$eval1123000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_layout_A_class, Simple: "eval1123000004", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000004_A"})

func init() { i := A_arbace_g2a_layout_eval1123000004_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_eval1123000004_A_InstanceOf; i.Table = A_arbace_g2a_layout_eval1123000004_A_members }

var A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_class *jrt.Class

func A_arbace_g2a_layout_eval1123000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_eval1123000008_A_New()}; return nil }

var A_arbace_g2a_layout_eval1123000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_layout_eval1123000008_A_new}

var A_arbace_g2a_layout_eval1123000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$eval1123000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_layout_A_class, Simple: "eval1123000008", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000008_A"})

func init() { i := A_arbace_g2a_layout_eval1123000008_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_eval1123000008_A_InstanceOf; i.Table = A_arbace_g2a_layout_eval1123000008_A_members }

var A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_class *jrt.Class

var A_arbace_g2a_layout_form_line_A_class *jrt.Class

var A_arbace_g2a_layout_iobj_QMARK__A_class *jrt.Class

var A_arbace_g2a_layout_key_rank_A_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_A_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_class *jrt.Class

var A_arbace_g2a_layout_note_BANG__A_class *jrt.Class

var A_arbace_g2a_layout_prep_A_class *jrt.Class

var A_arbace_g2a_layout_prep_fn__1123000020_A_class *jrt.Class

var A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_class *jrt.Class

var A_arbace_g2a_layout_prepare_A_class *jrt.Class

var A_arbace_g2a_layout_private_QMARK__A_class *jrt.Class

var A_arbace_g2a_layout_public_meta_A_class *jrt.Class

var A_arbace_g2a_layout_public_meta_fn__1123000042_A_class *jrt.Class

var A_arbace_g2a_layout_sort_keys_A_class *jrt.Class

var A_arbace_g2a_layout_sort_keys_fn__1123000038_A_class *jrt.Class

var A_arbace_g2a_layout_text_A_class *jrt.Class

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class *jrt.Class

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class *jrt.Class

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_class *jrt.Class

var A_arbace_g2a_layout_write_file_A_class *jrt.Class

var A_arbace_g2a_layout_write_file_emit__1123000093_A_class *jrt.Class

var A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_class *jrt.Class

var A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_class *jrt.Class

var A_arbace_g2a_layout_write_package_A_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_class *jrt.Class

func A_arbace_g2a_layout__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_layout__init_A_Load__O()}; return nil }

func A_arbace_g2a_layout__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout__init_A_New()}; return nil }

var A_arbace_g2a_layout__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_layout__init_A_invoke, New: A_arbace_g2a_layout__init_A_new}

var A_arbace_g2a_layout__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout__init_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout__init_A_class.Info(); i.IsInstance = A_arbace_g2a_layout__init_A_InstanceOf; i.Init = A_arbace_g2a_layout__init_A_Init; i.Table = A_arbace_g2a_layout__init_A_members }
