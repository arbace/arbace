//line a2g_classes.ae:1
package aot_arbace_g2a_layout

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_layout_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_A_New()}; return nil }

var A_arbace_g2a_layout_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_layout_A_new}

var A_arbace_g2a_layout_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_A"})

func init() { i := A_arbace_g2a_layout_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_A_InstanceOf; i.Init = A_arbace_g2a_layout_A_Init; i.Table = A_arbace_g2a_layout_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_A_class, reflect.TypeFor[A_arbace_g2a_layout_A]()) }

func A_arbace_g2a_layout_atom_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_atom_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_atom_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_atom_text_A_New()}; return nil }

func A_arbace_g2a_layout_atom_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_atom_text_A_fn_class)}; return nil }

var A_arbace_g2a_layout_atom_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_atom_text_A_invoke, New: A_arbace_g2a_layout_atom_text_A_new, Get: A_arbace_g2a_layout_atom_text_A_get}

var A_arbace_g2a_layout_atom_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$atom_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "atom_text", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_atom_text_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_atom_text_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_atom_text_A_InstanceOf; i.Init = A_arbace_g2a_layout_atom_text_A_Init; i.Table = A_arbace_g2a_layout_atom_text_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_atom_text_A_class, reflect.TypeFor[A_arbace_g2a_layout_atom_text_A]()) }

func A_arbace_g2a_layout_comment_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_comment_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_comment_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_comment_text_A_New()}; return nil }

func A_arbace_g2a_layout_comment_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_comment_text_A_fn_class)}; return nil }

var A_arbace_g2a_layout_comment_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_comment_text_A_invoke, New: A_arbace_g2a_layout_comment_text_A_new, Get: A_arbace_g2a_layout_comment_text_A_get}

var A_arbace_g2a_layout_comment_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$comment_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "comment_text", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_comment_text_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_comment_text_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_comment_text_A_InstanceOf; i.Init = A_arbace_g2a_layout_comment_text_A_Init; i.Table = A_arbace_g2a_layout_comment_text_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_comment_text_A_class, reflect.TypeFor[A_arbace_g2a_layout_comment_text_A]()) }

func A_arbace_g2a_layout_deref_form_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_deref_form_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_deref_form_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_deref_form_QMARK__A_New()}; return nil }

func A_arbace_g2a_layout_deref_form_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_deref_form_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_layout_deref_form_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_deref_form_QMARK__A_invoke, New: A_arbace_g2a_layout_deref_form_QMARK__A_new, Get: A_arbace_g2a_layout_deref_form_QMARK__A_get}

var A_arbace_g2a_layout_deref_form_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$deref_form_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "deref_form_QMARK_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_deref_form_QMARK__A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_deref_form_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_layout_deref_form_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_layout_deref_form_QMARK__A_Init; i.Table = A_arbace_g2a_layout_deref_form_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_layout_deref_form_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_layout_deref_form_QMARK__A]()) }

func A_arbace_g2a_layout_eval1123000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_eval1123000004_A_New()}; return nil }

var A_arbace_g2a_layout_eval1123000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_layout_eval1123000004_A_new}

var A_arbace_g2a_layout_eval1123000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$eval1123000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_layout_A_class, Simple: "eval1123000004", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000004_A"})

func init() { i := A_arbace_g2a_layout_eval1123000004_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_eval1123000004_A_InstanceOf; i.Table = A_arbace_g2a_layout_eval1123000004_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_eval1123000004_A_class, reflect.TypeFor[A_arbace_g2a_layout_eval1123000004_A]()) }

func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_New()}; return nil }

func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_fn_class)}; return nil }

var A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_invoke, New: A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_new, Get: A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_get}

var A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$eval1123000004$loading__1927001464__auto____1123000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_eval1123000004_A_class, Simple: "loading__1927001464__auto____1123000005", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_InstanceOf; i.Init = A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_Init; i.Table = A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_class, reflect.TypeFor[A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A]()) }

func A_arbace_g2a_layout_eval1123000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_eval1123000008_A_New()}; return nil }

var A_arbace_g2a_layout_eval1123000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_layout_eval1123000008_A_new}

var A_arbace_g2a_layout_eval1123000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$eval1123000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_layout_A_class, Simple: "eval1123000008", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000008_A"})

func init() { i := A_arbace_g2a_layout_eval1123000008_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_eval1123000008_A_InstanceOf; i.Table = A_arbace_g2a_layout_eval1123000008_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_eval1123000008_A_class, reflect.TypeFor[A_arbace_g2a_layout_eval1123000008_A]()) }

func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_eval1123000008_fn__1123000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_New()}; return nil }

func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_fn_class)}; return nil }

var A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_invoke, New: A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_new, Get: A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_get}

var A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$eval1123000008$fn__1123000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_eval1123000008_A_class, Simple: "fn__1123000009", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_eval1123000008_fn__1123000009_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_InstanceOf; i.Init = A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_Init; i.Table = A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_class, reflect.TypeFor[A_arbace_g2a_layout_eval1123000008_fn__1123000009_A]()) }

func A_arbace_g2a_layout_form_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_form_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_form_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_form_line_A_New()}; return nil }

func A_arbace_g2a_layout_form_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_form_line_A_fn_class)}; return nil }

var A_arbace_g2a_layout_form_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_form_line_A_invoke, New: A_arbace_g2a_layout_form_line_A_new, Get: A_arbace_g2a_layout_form_line_A_get}

var A_arbace_g2a_layout_form_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$form_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "form_line", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_form_line_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_form_line_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_form_line_A_InstanceOf; i.Init = A_arbace_g2a_layout_form_line_A_Init; i.Table = A_arbace_g2a_layout_form_line_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_form_line_A_class, reflect.TypeFor[A_arbace_g2a_layout_form_line_A]()) }

func A_arbace_g2a_layout_iobj_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_iobj_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_iobj_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_iobj_QMARK__A_New()}; return nil }

func A_arbace_g2a_layout_iobj_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_iobj_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_layout_iobj_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_iobj_QMARK__A_invoke, New: A_arbace_g2a_layout_iobj_QMARK__A_new, Get: A_arbace_g2a_layout_iobj_QMARK__A_get}

var A_arbace_g2a_layout_iobj_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$iobj_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "iobj_QMARK_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_iobj_QMARK__A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_iobj_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_layout_iobj_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_layout_iobj_QMARK__A_Init; i.Table = A_arbace_g2a_layout_iobj_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_layout_iobj_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_layout_iobj_QMARK__A]()) }

func A_arbace_g2a_layout_key_rank_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_key_rank_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_key_rank_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_key_rank_A_New()}; return nil }

func A_arbace_g2a_layout_key_rank_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_key_rank_A_fn_class)}; return nil }

var A_arbace_g2a_layout_key_rank_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_key_rank_A_invoke, New: A_arbace_g2a_layout_key_rank_A_new, Get: A_arbace_g2a_layout_key_rank_A_get}

var A_arbace_g2a_layout_key_rank_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$key_rank", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "key_rank", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_key_rank_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_key_rank_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_key_rank_A_InstanceOf; i.Init = A_arbace_g2a_layout_key_rank_A_Init; i.Table = A_arbace_g2a_layout_key_rank_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_key_rank_A_class, reflect.TypeFor[A_arbace_g2a_layout_key_rank_A]()) }

func A_arbace_g2a_layout_meta_prefix_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_meta_prefix_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_meta_prefix_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_meta_prefix_A_New()}; return nil }

func A_arbace_g2a_layout_meta_prefix_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_meta_prefix_A_fn_class)}; return nil }

var A_arbace_g2a_layout_meta_prefix_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_meta_prefix_A_invoke, New: A_arbace_g2a_layout_meta_prefix_A_new, Get: A_arbace_g2a_layout_meta_prefix_A_get}

var A_arbace_g2a_layout_meta_prefix_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$meta_prefix", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "meta_prefix", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_meta_prefix_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_meta_prefix_A_InstanceOf; i.Init = A_arbace_g2a_layout_meta_prefix_A_Init; i.Table = A_arbace_g2a_layout_meta_prefix_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_meta_prefix_A_class, reflect.TypeFor[A_arbace_g2a_layout_meta_prefix_A]()) }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_meta_prefix_fn__1123000051_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_New_O(args[0])}; return nil }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_fn_class)}; return nil }

var A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_invoke, New: A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_new, Get: A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_get}

var A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$meta_prefix$fn__1123000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_meta_prefix_A_class, Simple: "fn__1123000051", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_fn__1123000051_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_InstanceOf; i.Init = A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_Init; i.Table = A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_class, reflect.TypeFor[A_arbace_g2a_layout_meta_prefix_fn__1123000051_A]()) }

func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_meta_prefix_fn__1123000053_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_New_O(args[0])}; return nil }

func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_fn_class)}; return nil }

var A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_invoke, New: A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_new, Get: A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_get}

var A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$meta_prefix$fn__1123000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_meta_prefix_A_class, Simple: "fn__1123000053", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_fn__1123000053_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_InstanceOf; i.Init = A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_Init; i.Table = A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_class, reflect.TypeFor[A_arbace_g2a_layout_meta_prefix_fn__1123000053_A]()) }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_New_O(args[0])}; return nil }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_fn_class)}; return nil }

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_invoke, New: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_new, Get: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_get}

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_meta_prefix_A_class, Simple: "iter__1123000059__1123000063", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_InstanceOf; i.Init = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_Init; i.Table = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class, reflect.TypeFor[A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A]()) }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_fn_class)}; return nil }

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_invoke, New: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_new, Get: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_get}

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class, Simple: "fn__1123000064", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_InstanceOf; i.Init = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_Init; i.Table = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class, reflect.TypeFor[A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A]()) }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_fn_class)}; return nil }

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_invoke, New: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_new, Get: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_get}

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$meta_prefix$iter__1123000059__1123000063$fn__1123000064$fn__1123000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class, Simple: "fn__1123000065", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_InstanceOf; i.Init = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_Init; i.Table = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_class, reflect.TypeFor[A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A]()) }

func A_arbace_g2a_layout_note_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_note_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_note_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_note_BANG__A_New()}; return nil }

func A_arbace_g2a_layout_note_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_note_BANG__A_fn_class)}; return nil }

var A_arbace_g2a_layout_note_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_note_BANG__A_invoke, New: A_arbace_g2a_layout_note_BANG__A_new, Get: A_arbace_g2a_layout_note_BANG__A_get}

var A_arbace_g2a_layout_note_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$note_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "note_BANG_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_note_BANG__A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_note_BANG__A_class.Info(); i.IsInstance = A_arbace_g2a_layout_note_BANG__A_InstanceOf; i.Init = A_arbace_g2a_layout_note_BANG__A_Init; i.Table = A_arbace_g2a_layout_note_BANG__A_members; jrt.RegisterGoType(A_arbace_g2a_layout_note_BANG__A_class, reflect.TypeFor[A_arbace_g2a_layout_note_BANG__A]()) }

func A_arbace_g2a_layout_prep_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_prep_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_layout_prep_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_prep_A_New()}; return nil }

func A_arbace_g2a_layout_prep_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_prep_A_fn_class)}; return nil }

var A_arbace_g2a_layout_prep_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_prep_A_invoke, New: A_arbace_g2a_layout_prep_A_new, Get: A_arbace_g2a_layout_prep_A_get}

var A_arbace_g2a_layout_prep_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$prep", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "prep", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prep_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_prep_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_prep_A_InstanceOf; i.Init = A_arbace_g2a_layout_prep_A_Init; i.Table = A_arbace_g2a_layout_prep_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_prep_A_class, reflect.TypeFor[A_arbace_g2a_layout_prep_A]()) }

func A_arbace_g2a_layout_prep_fn__1123000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_prep_fn__1123000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_prep_fn__1123000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_prep_fn__1123000020_A_New_O_O_Z(args[0], args[1], args[2].(bool))}; return nil }

func A_arbace_g2a_layout_prep_fn__1123000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_prep_fn__1123000020_A_fn_class)}; return nil }

var A_arbace_g2a_layout_prep_fn__1123000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Z)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_prep_fn__1123000020_A_invoke, New: A_arbace_g2a_layout_prep_fn__1123000020_A_new, Get: A_arbace_g2a_layout_prep_fn__1123000020_A_get}

var A_arbace_g2a_layout_prep_fn__1123000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$prep$fn__1123000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_prep_A_class, Simple: "fn__1123000020", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prep_fn__1123000020_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_prep_fn__1123000020_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_prep_fn__1123000020_A_InstanceOf; i.Init = A_arbace_g2a_layout_prep_fn__1123000020_A_Init; i.Table = A_arbace_g2a_layout_prep_fn__1123000020_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_prep_fn__1123000020_A_class, reflect.TypeFor[A_arbace_g2a_layout_prep_fn__1123000020_A]()) }

func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_New_O_O_O_O_Z(args[0], args[1], args[2], args[3], args[4].(bool))}; return nil }

func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_fn_class)}; return nil }

var A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Z)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_invoke, New: A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_new, Get: A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_get}

var A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$prep$fn__1123000020$fn__1123000024", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_prep_fn__1123000020_A_class, Simple: "fn__1123000024", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_InstanceOf; i.Init = A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_Init; i.Table = A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_class, reflect.TypeFor[A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A]()) }

func A_arbace_g2a_layout_prepare_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_prepare_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_prepare_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_prepare_A_New()}; return nil }

func A_arbace_g2a_layout_prepare_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_prepare_A_fn_class)}; return nil }

var A_arbace_g2a_layout_prepare_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_prepare_A_invoke, New: A_arbace_g2a_layout_prepare_A_new, Get: A_arbace_g2a_layout_prepare_A_get}

var A_arbace_g2a_layout_prepare_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$prepare", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "prepare", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_prepare_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_prepare_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_prepare_A_InstanceOf; i.Init = A_arbace_g2a_layout_prepare_A_Init; i.Table = A_arbace_g2a_layout_prepare_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_prepare_A_class, reflect.TypeFor[A_arbace_g2a_layout_prepare_A]()) }

func A_arbace_g2a_layout_private_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_private_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_private_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_private_QMARK__A_New()}; return nil }

func A_arbace_g2a_layout_private_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_private_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_layout_private_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_private_QMARK__A_invoke, New: A_arbace_g2a_layout_private_QMARK__A_new, Get: A_arbace_g2a_layout_private_QMARK__A_get}

var A_arbace_g2a_layout_private_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$private_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "private_QMARK_", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_private_QMARK__A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_private_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_layout_private_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_layout_private_QMARK__A_Init; i.Table = A_arbace_g2a_layout_private_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_layout_private_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_layout_private_QMARK__A]()) }

func A_arbace_g2a_layout_public_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_public_meta_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_public_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_public_meta_A_New()}; return nil }

func A_arbace_g2a_layout_public_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_public_meta_A_fn_class)}; return nil }

var A_arbace_g2a_layout_public_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_public_meta_A_invoke, New: A_arbace_g2a_layout_public_meta_A_new, Get: A_arbace_g2a_layout_public_meta_A_get}

var A_arbace_g2a_layout_public_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$public_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "public_meta", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_public_meta_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_public_meta_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_public_meta_A_InstanceOf; i.Init = A_arbace_g2a_layout_public_meta_A_Init; i.Table = A_arbace_g2a_layout_public_meta_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_public_meta_A_class, reflect.TypeFor[A_arbace_g2a_layout_public_meta_A]()) }

func A_arbace_g2a_layout_public_meta_fn__1123000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_public_meta_fn__1123000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_public_meta_fn__1123000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_public_meta_fn__1123000042_A_New()}; return nil }

func A_arbace_g2a_layout_public_meta_fn__1123000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_public_meta_fn__1123000042_A_fn_class)}; return nil }

var A_arbace_g2a_layout_public_meta_fn__1123000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_public_meta_fn__1123000042_A_invoke, New: A_arbace_g2a_layout_public_meta_fn__1123000042_A_new, Get: A_arbace_g2a_layout_public_meta_fn__1123000042_A_get}

var A_arbace_g2a_layout_public_meta_fn__1123000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$public_meta$fn__1123000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_public_meta_A_class, Simple: "fn__1123000042", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_public_meta_fn__1123000042_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_public_meta_fn__1123000042_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_public_meta_fn__1123000042_A_InstanceOf; i.Init = A_arbace_g2a_layout_public_meta_fn__1123000042_A_Init; i.Table = A_arbace_g2a_layout_public_meta_fn__1123000042_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_public_meta_fn__1123000042_A_class, reflect.TypeFor[A_arbace_g2a_layout_public_meta_fn__1123000042_A]()) }

func A_arbace_g2a_layout_sort_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_sort_keys_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_sort_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_sort_keys_A_New()}; return nil }

func A_arbace_g2a_layout_sort_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_sort_keys_A_fn_class)}; return nil }

var A_arbace_g2a_layout_sort_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_sort_keys_A_invoke, New: A_arbace_g2a_layout_sort_keys_A_new, Get: A_arbace_g2a_layout_sort_keys_A_get}

var A_arbace_g2a_layout_sort_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$sort_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "sort_keys", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_sort_keys_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_sort_keys_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_sort_keys_A_InstanceOf; i.Init = A_arbace_g2a_layout_sort_keys_A_Init; i.Table = A_arbace_g2a_layout_sort_keys_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_sort_keys_A_class, reflect.TypeFor[A_arbace_g2a_layout_sort_keys_A]()) }

func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_sort_keys_fn__1123000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_sort_keys_fn__1123000038_A_New()}; return nil }

func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_sort_keys_fn__1123000038_A_fn_class)}; return nil }

var A_arbace_g2a_layout_sort_keys_fn__1123000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_sort_keys_fn__1123000038_A_invoke, New: A_arbace_g2a_layout_sort_keys_fn__1123000038_A_new, Get: A_arbace_g2a_layout_sort_keys_fn__1123000038_A_get}

var A_arbace_g2a_layout_sort_keys_fn__1123000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$sort_keys$fn__1123000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_sort_keys_A_class, Simple: "fn__1123000038", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_sort_keys_fn__1123000038_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_sort_keys_fn__1123000038_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_sort_keys_fn__1123000038_A_InstanceOf; i.Init = A_arbace_g2a_layout_sort_keys_fn__1123000038_A_Init; i.Table = A_arbace_g2a_layout_sort_keys_fn__1123000038_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_sort_keys_fn__1123000038_A_class, reflect.TypeFor[A_arbace_g2a_layout_sort_keys_fn__1123000038_A]()) }

func A_arbace_g2a_layout_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_text_A_New()}; return nil }

func A_arbace_g2a_layout_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_text_A_fn_class)}; return nil }

var A_arbace_g2a_layout_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_text_A_invoke, New: A_arbace_g2a_layout_text_A_new, Get: A_arbace_g2a_layout_text_A_get}

var A_arbace_g2a_layout_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "text", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_text_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_text_A_InstanceOf; i.Init = A_arbace_g2a_layout_text_A_Init; i.Table = A_arbace_g2a_layout_text_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_text_A_class, reflect.TypeFor[A_arbace_g2a_layout_text_A]()) }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_New()}; return nil }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_fn_class)}; return nil }

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_invoke, New: A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_new, Get: A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_get}

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$text$iter__1123000071__1123000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_text_A_class, Simple: "iter__1123000071__1123000075", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_iter__1123000071__1123000075_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_InstanceOf; i.Init = A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_Init; i.Table = A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class, reflect.TypeFor[A_arbace_g2a_layout_text_iter__1123000071__1123000075_A]()) }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_fn_class)}; return nil }

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_invoke, New: A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_new, Get: A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_get}

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class, Simple: "fn__1123000076", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_InstanceOf; i.Init = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_Init; i.Table = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class, reflect.TypeFor[A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A]()) }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_fn_class)}; return nil }

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_invoke, New: A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_new, Get: A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_get}

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$text$iter__1123000071__1123000075$fn__1123000076$fn__1123000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class, Simple: "fn__1123000077", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_InstanceOf; i.Init = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_Init; i.Table = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_class, reflect.TypeFor[A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A]()) }

func A_arbace_g2a_layout_write_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_layout_write_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_file_A_New()}; return nil }

func A_arbace_g2a_layout_write_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_file_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_file_A_invoke, New: A_arbace_g2a_layout_write_file_A_new, Get: A_arbace_g2a_layout_write_file_A_get}

var A_arbace_g2a_layout_write_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "write_file", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_file_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_file_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_file_A_Init; i.Table = A_arbace_g2a_layout_write_file_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_file_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_file_A]()) }

func A_arbace_g2a_layout_write_file_emit__1123000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_file_emit__1123000093_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_write_file_emit__1123000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_file_emit__1123000093_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_layout_write_file_emit__1123000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_file_emit__1123000093_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_file_emit__1123000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_file_emit__1123000093_A_invoke, New: A_arbace_g2a_layout_write_file_emit__1123000093_A_new, Get: A_arbace_g2a_layout_write_file_emit__1123000093_A_get}

var A_arbace_g2a_layout_write_file_emit__1123000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_file$emit__1123000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_write_file_A_class, Simple: "emit__1123000093", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_emit__1123000093_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_file_emit__1123000093_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_file_emit__1123000093_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_file_emit__1123000093_A_Init; i.Table = A_arbace_g2a_layout_write_file_emit__1123000093_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_file_emit__1123000093_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_file_emit__1123000093_A]()) }

func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_invoke, New: A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_new, Get: A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_get}

var A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_file$flush_comments_BANG___1123000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_write_file_A_class, Simple: "flush_comments_BANG___1123000089", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_Init; i.Table = A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A]()) }

func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_invoke, New: A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_new, Get: A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_get}

var A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_file$newline_to_BANG___1123000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_write_file_A_class, Simple: "newline_to_BANG___1123000091", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_Init; i.Table = A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A]()) }

func A_arbace_g2a_layout_write_package_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_package_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_layout_write_package_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_package_A_New()}; return nil }

func A_arbace_g2a_layout_write_package_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_package_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_package_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_package_A_invoke, New: A_arbace_g2a_layout_write_package_A_new, Get: A_arbace_g2a_layout_write_package_A_get}

var A_arbace_g2a_layout_write_package_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_package", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_g2a_layout_A_class, Simple: "write_package", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_package_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_package_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_package_A_Init; i.Table = A_arbace_g2a_layout_write_package_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_package_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_package_A]()) }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_New()}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_invoke, New: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_new, Get: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_get}

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_package$iter__1123000113__1123000117", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_write_package_A_class, Simple: "iter__1123000113__1123000117", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_Init; i.Table = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A]()) }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_invoke, New: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_new, Get: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_get}

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class, Simple: "fn__1123000118", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_Init; i.Table = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A]()) }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_invoke, New: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_new, Get: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_get}

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_package$iter__1123000113__1123000117$fn__1123000118$fn__1123000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class, Simple: "fn__1123000119", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_Init; i.Table = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A]()) }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_New()}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_invoke, New: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_new, Get: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_get}

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_package$iter__1123000129__1123000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_layout_write_package_A_class, Simple: "iter__1123000129__1123000133", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_Init; i.Table = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A]()) }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_invoke, New: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_new, Get: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_get}

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class, Simple: "fn__1123000134", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_Init; i.Table = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A]()) }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_fn_class)}; return nil }

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_invoke, New: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_new, Get: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_get}

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout$write_package$iter__1123000129__1123000133$fn__1123000134$fn__1123000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class, Simple: "fn__1123000135", Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_class.Info(); i.IsInstance = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_InstanceOf; i.Init = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_Init; i.Table = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_members; jrt.RegisterGoType(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_class, reflect.TypeFor[A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A]()) }

func A_arbace_g2a_layout__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_layout__init_A_Load__O(); case 1: return A_arbace_g2a_layout__init_A_Unit0__O(); case 2: return A_arbace_g2a_layout__init_A_Unit1__O(); case 3: return A_arbace_g2a_layout__init_A_Unit10__O(); case 4: return A_arbace_g2a_layout__init_A_Unit11__O(); case 5: return A_arbace_g2a_layout__init_A_Unit12__O(); case 6: return A_arbace_g2a_layout__init_A_Unit13__O(); case 7: return A_arbace_g2a_layout__init_A_Unit14__O(); case 8: return A_arbace_g2a_layout__init_A_Unit15__O(); case 9: return A_arbace_g2a_layout__init_A_Unit16__O(); case 10: return A_arbace_g2a_layout__init_A_Unit17__O(); case 11: return A_arbace_g2a_layout__init_A_Unit18__O(); case 12: return A_arbace_g2a_layout__init_A_Unit19__O(); case 13: return A_arbace_g2a_layout__init_A_Unit2__O(); case 14: return A_arbace_g2a_layout__init_A_Unit20__O(); case 15: return A_arbace_g2a_layout__init_A_Unit21__O(); case 16: return A_arbace_g2a_layout__init_A_Unit22__O(); case 17: return A_arbace_g2a_layout__init_A_Unit23__O(); case 18: return A_arbace_g2a_layout__init_A_Unit24__O(); case 19: return A_arbace_g2a_layout__init_A_Unit3__O(); case 20: return A_arbace_g2a_layout__init_A_Unit4__O(); case 21: return A_arbace_g2a_layout__init_A_Unit5__O(); case 22: return A_arbace_g2a_layout__init_A_Unit6__O(); case 23: return A_arbace_g2a_layout__init_A_Unit7__O(); case 24: return A_arbace_g2a_layout__init_A_Unit8__O(); case 25: return A_arbace_g2a_layout__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_layout__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_layout__init_A_New()}; return nil }

var A_arbace_g2a_layout__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_layout__init_A_invoke, New: A_arbace_g2a_layout__init_A_new}

var A_arbace_g2a_layout__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.layout__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_layout.A_arbace_g2a_layout__init_A", Source: "layout.ae"})

func init() { i := A_arbace_g2a_layout__init_A_class.Info(); i.IsInstance = A_arbace_g2a_layout__init_A_InstanceOf; i.Init = A_arbace_g2a_layout__init_A_Init; i.Table = A_arbace_g2a_layout__init_A_members; jrt.RegisterGoType(A_arbace_g2a_layout__init_A_class, reflect.TypeFor[A_arbace_g2a_layout__init_A]()) }
