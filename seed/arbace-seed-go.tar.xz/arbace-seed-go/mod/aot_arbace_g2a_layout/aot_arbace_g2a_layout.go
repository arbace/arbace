//line aot_arbace_g2a_layout.ae:1
package aot_arbace_g2a_layout

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_New() *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A { A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_Init(); t := &A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_4; tmp3 = tmp8.Invoke_O_O__O(tmp10, tmp11) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :1:1
func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_New() *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A { A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_Init(); t := &A_arbace_g2a_layout_eval1123000008_fn__1123000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }















func A_arbace_g2a_layout_private_QMARK__A_New() *A_arbace_g2a_layout_private_QMARK__A { A_arbace_g2a_layout_private_QMARK__A_Init(); t := &A_arbace_g2a_layout_private_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_g2a_layout_private_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_g2a_layout_private_QMARK__A) Invoke_O_O__O(self, k__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_10; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(k__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_11; var tmp3 any = jrt.NN(tmp2).GetRawRoot__O(); var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_12; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(k__0))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_layout_iobj_QMARK__A_New() *A_arbace_g2a_layout_iobj_QMARK__A { A_arbace_g2a_layout_iobj_QMARK__A_Init(); t := &A_arbace_g2a_layout_iobj_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_g2a_layout_iobj_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_g2a_layout_iobj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.IObj_InstanceOf(x__0)).Ref() }

func A_arbace_g2a_layout_deref_form_QMARK__A_New() *A_arbace_g2a_layout_deref_form_QMARK__A { A_arbace_g2a_layout_deref_form_QMARK__A_Init(); t := &A_arbace_g2a_layout_deref_form_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_g2a_layout_deref_form_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_g2a_layout_deref_form_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_13; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_14; var tmp3 *lang.Keyword = tmp2; return jrt.NN(tmp3).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_layout_form_line_A_New() *A_arbace_g2a_layout_form_line_A { A_arbace_g2a_layout_form_line_A_Init(); t := &A_arbace_g2a_layout_form_line_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_g2a_layout_form_line_A) Ctor() {}
//line :23:1
func (t *A_arbace_g2a_layout_form_line_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) {
		var tmp2 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_16; return jrt.NN(tmp2).Invoke_O__O(x__0) } else {
//line :26:1
			var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp4 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_18; var tmp5 *lang.Keyword = tmp4; return jrt.NN(tmp5).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else {
//line :26:1
					return nil
				}
		}
}



func A_arbace_g2a_layout_note_BANG__A_New() *A_arbace_g2a_layout_note_BANG__A { A_arbace_g2a_layout_note_BANG__A_Init(); t := &A_arbace_g2a_layout_note_BANG__A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_g2a_layout_note_BANG__A) Ctor() {}
//line :33:1
func (t *A_arbace_g2a_layout_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_19; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_20; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_19; var tmp5 any = jrt.NN(tmp4).Get__O(); var tmp6 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_21; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_22; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp10 = A_arbace_g2a_layout_A_const_23; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 any; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_24; return tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, k__0, tmp9.Invoke_O_O__O(tmp11, tmp12)) } else { return nil } }



func A_arbace_g2a_layout_prep_A_New() *A_arbace_g2a_layout_prep_A { A_arbace_g2a_layout_prep_A_Init(); t := &A_arbace_g2a_layout_prep_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_g2a_layout_prep_A) Ctor() {}
//line :37:1
func (t *A_arbace_g2a_layout_prep_A) Invoke_O_O_O__O(self, x__0, cursor__1 any) any {


	var tmp1 any; var or__1927000174__auto____3 any; var tmp2 *lang.Var
	A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_13; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_25; tmp1 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0) }
//line :40:1
	if jrt.A2g_Truth(tmp1) {

		var tmp4 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_26; var tmp5 *lang.Keyword = tmp4; if jrt.A2g_Truth(jrt.NN(tmp5).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0))) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { var lines_QMARK___3 bool; var tmp6 *lang.Var

			A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_27; var tmp7 any = jrt.NN(tmp6).Get__O(); var tmp8 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_28; lines_QMARK___3 = lang.Util_Equiv_O_O__Z(tmp7, tmp8.Ref())
//line :42:1
			var m__4 any = lang.RT_Meta_O__IPersistentMap(x__0); var vec__1123000017__5 any; var tmp9 any = A_arbace_g2a_layout_prep_fn__1123000020_A_New_O_O_Z(cursor__1, x__0, lines_QMARK___3); var tmp10 *jrt.Class




			A_arbace_g2a_layout_prep_fn__1123000020_A_Init(); tmp10 = A_arbace_g2a_layout_prep_fn__1123000020_A_fn_class; vec__1123000017__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O()
//line :42:1
			var kids__6 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(0), nil); var cursor__7 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(1), nil); var breaks__8 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(2), nil); var apos__9 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(3), nil); var x_SINGLEQUOTE___10 any; var tmp11 *lang.Var



























			A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(x__0)) { var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_45; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp14 = A_arbace_g2a_layout_A_const_47; x_SINGLEQUOTE___10 = tmp13.Invoke_O_O__O(jrt.NN(tmp14).GetRawRoot__O(), kids__6) } else { x_SINGLEQUOTE___10 = kids__6 }
//line :42:1
			var m__11 any; var G__1123000028__11_ any = m__4; var G__1123000028__12_ any; var tmp15 any
			var and__1927000168__auto____12 bool = lines_QMARK___3




























			if and__1927000168__auto____12 { var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_29; tmp15 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(breaks__8) } else { tmp15 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12).Ref() }
//line :71:1
			if jrt.A2g_Truth(tmp15) {
				var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_33; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp19 = A_arbace_g2a_layout_A_const_48; G__1123000028__12_ = tmp18.Invoke_O_O_O__O(G__1123000028__11_, tmp19.Ref(), breaks__8) } else {
//line :71:1
					G__1123000028__12_ = G__1123000028__11_ }; var tmp20 any; var and__1927000168__auto____13 bool; var tmp21 *lang.Var

			A_arbace_g2a_layout_A_Init(); tmp21 = A_arbace_g2a_layout_A_const_27; var tmp22 any = jrt.NN(tmp21).Get__O(); var tmp23 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_46; and__1927000168__auto____13 = lang.Util_Equiv_O_O__Z(tmp22, tmp23.Ref()); if and__1927000168__auto____13 { var tmp24 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp24 = A_arbace_g2a_layout_A_const_29; tmp20 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(apos__9) } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13).Ref() }
//line :71:1
			if jrt.A2g_Truth(tmp20) {

				var tmp25 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_33; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp27 = A_arbace_g2a_layout_A_const_49; m__11 = tmp26.Invoke_O_O_O__O(G__1123000028__12_, tmp27.Ref(), apos__9) } else {
//line :71:1
					m__11 = G__1123000028__12_ }
//line :42:1
			var tmp28 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp28 = A_arbace_g2a_layout_A_const_50; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O_O__O(x_SINGLEQUOTE___10, m__11), cursor__7) } } else {
//line :40:1
				var tmp29 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp29 = A_arbace_g2a_layout_A_const_35; if tmp29 != nil { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { return nil
				}
			}
}



func A_arbace_g2a_layout_prep_fn__1123000020_A_New_O_O_Z(p0, p1 any, p2 bool) *A_arbace_g2a_layout_prep_fn__1123000020_A { A_arbace_g2a_layout_prep_fn__1123000020_A_Init(); t := &A_arbace_g2a_layout_prep_fn__1123000020_A{}; t.Ctor_O_O_Z(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) Ctor_O_O_Z(c__cursor, c__x any, c__lines_QMARK_ bool) { t.F_cursor = c__cursor; t.F_x = c__x; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :47:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var xs__2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_x; t.F_x = nil; tmp3 = t_; xs__2 = tmp2.Invoke_O__O(tmp3); var cursor__3 any; var t__2 any = t.F_cursor; t.F_cursor = nil; cursor__3 = t__2; var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); var breaks__5 any; lang.PersistentVector_Init(); breaks__5 = lang.PersistentVector_EMPTY.Ref(); var apos__6 any; var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_30; apos__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke__O(); L1: for { var temp__1927000408__auto____7 any; var tmp5 *lang.Var
										A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_31; temp__1927000408__auto____7 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(xs__2); if jrt.A2g_Truth(temp__1927000408__auto____7) { var c__8 any = temp__1927000408__auto____7; var l__9 any; var tmp6 *lang.Var
											A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_32; l__9 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(c__8)
//line :48:1
		var cursor0__10 any = cursor__3; var brk__11 any
		var and__1927000168__auto____11 any = l__9

		if jrt.A2g_Truth(and__1927000168__auto____11) { brk__11 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(l__9, cursor__3)).Ref() } else { brk__11 = and__1927000168__auto____11 }
//line :48:1
		var c__12 any; var tmp7 *lang.Var



		A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(c__8)) {
			var tmp8 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_33; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp10 = A_arbace_g2a_layout_A_const_37; c__12 = tmp9.Invoke_O_O_O__O(c__8, tmp10.Ref(), brk__11) } else {
//line :52:1
				var tmp11 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(c__8)) {


					var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_34; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_New_O_O_O_O_Z(l__9, brk__11, cursor__3, c__8, t.F_lines_QMARK_); var tmp15 *jrt.Class; A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_Init(); tmp15 = A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_fn_class; c__12 = tmp13.Invoke_O_O__O(c__8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)) } else {
//line :52:1
						var tmp16 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_35; if tmp16 != nil { c__12 = c__8 } else { c__12 = nil } } }
//line :48:1
		var cursor__13 any













		if jrt.A2g_Truth(brk__11) { cursor__13 = l__9 } else { cursor__13 = cursor__3 }
//line :48:1
		var vec__1123000021__14 any; var tmp17 *lang.Var














		A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_36; vec__1123000021__14 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(c__12, cursor__13)
//line :48:1
		var c__15 any = lang.RT_Nth_O_I_O__O(vec__1123000021__14, lang.RT_IntCast_J__I(0), nil); var cursor__16 any = lang.RT_Nth_O_I_O__O(vec__1123000021__14, lang.RT_IntCast_J__I(1), nil); var tmp18 int64 = lang.Numbers_Inc_J__J(i__1); var tmp19 *lang.Var















		A_arbace_g2a_layout_A_Init(); tmp19 = A_arbace_g2a_layout_A_const_43; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(xs__2); var tmp21 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp21 = A_arbace_g2a_layout_A_const_7; var tmp22 any = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(acc__4, c__15); var tmp23 any; var tmp24 any
		var and__1927000168__auto____17 any = brk__11

		if jrt.A2g_Truth(and__1927000168__auto____17) { var tmp25 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_15; tmp24 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(c__15) } else { tmp24 = and__1927000168__auto____17 }; if jrt.A2g_Truth(tmp24) { var tmp26 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp26 = A_arbace_g2a_layout_A_const_7; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 any; if lang.Util_Equiv_O_O__Z(l__9, lang.Numbers_Inc_O__Number(cursor0__10)) { tmp28 = jrt.Long_ValueOf_J__Long(i__1).Ref() } else { tmp28 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(i__1).Ref(), l__9) }; tmp23 = tmp27.Invoke_O_O__O(breaks__5, tmp28) } else { tmp23 = breaks__5 }
//line :64:1
		var tmp29 any = tmp23; var tmp30 any; var tmp31 any; var and__1927000168__auto____17_2 any; var tmp32 *lang.Var



		A_arbace_g2a_layout_A_Init(); tmp32 = A_arbace_g2a_layout_A_const_15; and__1927000168__auto____17_2 = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(c__15); if jrt.A2g_Truth(and__1927000168__auto____17_2) { var tmp33 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp33 = A_arbace_g2a_layout_A_const_44; tmp31 = jrt.NN(tmp33).Invoke_O__O(c__15) } else { tmp31 = and__1927000168__auto____17_2 }; if jrt.A2g_Truth(tmp31) { var tmp34 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp34 = A_arbace_g2a_layout_A_const_33; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any = jrt.Long_ValueOf_J__Long(i__1).Ref(); var tmp37 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp37 = A_arbace_g2a_layout_A_const_44; tmp30 = tmp35.Invoke_O_O_O__O(apos__6, tmp36, jrt.NN(tmp37).Invoke_O__O(c__15)) } else { tmp30 = apos__6 }
//line :64:1
		i__1, xs__2, cursor__3, acc__4, breaks__5, apos__6 = tmp18, tmp20, cursor__16, tmp22, tmp29, tmp30; continue L1 } else {
//line :48:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(acc__4, cursor__3, breaks__5, apos__6) } } }; /*line :47:1*/panic("a2g: unreachable") }







func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_New_O_O_O_O_Z(p0, p1, p2, p3 any, p4 bool) *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A { A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_Init(); t := &A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A{}; t.Ctor_O_O_O_O_Z(p0, p1, p2, p3, p4); return t }
//line :55:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) Ctor_O_O_O_O_Z(c__l, c__brk, c__cursor, c__c any, c__lines_QMARK_ bool) { t.F_l = c__l; t.F_brk = c__brk; t.F_cursor = c__cursor; t.F_c = c__c; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :55:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) Invoke_O_O__O(self, cm__1 any) any { var G__1123000025__2_ any; var tmp1 *lang.Var;
													A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_33; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_40; G__1123000025__2_ = tmp2.Invoke_O_O_O__O(cm__1, tmp3.Ref(), t.F_brk); var G__1123000025__3_ any; var tmp4 any; var and__1927000168__auto____3 bool = /*line :55:1*/t.F_lines_QMARK_; if and__1927000168__auto____3 {

		var and__1927000168__auto____4 any = t.F_brk; if jrt.A2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any; var tmp5 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_38; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_13; or__1927000174__auto____5 = tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(t.F_c)); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { var tmp8 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_39; tmp4 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(t.F_c) } } else { tmp4 = and__1927000168__auto____4 } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if /*line :56:1*/ jrt.A2g_Truth(tmp4) {

			var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_33; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_16; G__1123000025__3_ = tmp10.Invoke_O_O_O__O(G__1123000025__2_, tmp11.Ref(), t.F_l) } else {
//line :56:1
				G__1123000025__3_ = G__1123000025__2_ }; var tmp12 any; var and__1927000168__auto____4_2 bool = t.F_lines_QMARK_; if and__1927000168__auto____4_2 {


					var and__1927000168__auto____5 any = t.F_l; if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_38; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(t.F_brk); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool = lang.Numbers_Lt_O_O__Z(t.F_l, t.F_cursor); if and__1927000168__auto____7 { var tmp14 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp14 = A_arbace_g2a_layout_A_const_13; tmp12 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(t.F_c) } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp12 = and__1927000168__auto____6 } } else { tmp12 = and__1927000168__auto____5 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4_2).Ref() }; if /*line :56:1*/ jrt.A2g_Truth(tmp12) { var cm__4 any = G__1123000025__3_; var tmp15 *lang.Var



						A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_41; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_42; tmp16.Invoke_O__O(tmp17.Ref()); var tmp18 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp18 = A_arbace_g2a_layout_A_const_33; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_16; return tmp19.Invoke_O_O_O__O(cm__4, tmp20.Ref(), t.F_l) } else {
//line :56:1
							return G__1123000025__3_ } }




















func A_arbace_g2a_layout_prepare_A_New() *A_arbace_g2a_layout_prepare_A { A_arbace_g2a_layout_prepare_A_Init(); t := &A_arbace_g2a_layout_prepare_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_g2a_layout_prepare_A) Ctor() {}
//line :77:1
func (t *A_arbace_g2a_layout_prepare_A) Invoke_O_O__O(self, forms__0 any) any { { var fs__2 any = forms__0; var cursor__3 any = lang.RT_Box_J__Number(1); var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____5 any; var tmp1 *lang.Var



	A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_31; temp__1927000408__auto____5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(fs__2); if jrt.A2g_Truth(temp__1927000408__auto____5) { var f__6 any = temp__1927000408__auto____5; var l__7 any; var tmp2 *lang.Var
		A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_32; l__7 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(f__6)
//line :81:1
		var brk__8 any
		var and__1927000168__auto____8 any = l__7
		if jrt.A2g_Truth(and__1927000168__auto____8) { brk__8 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(l__7, cursor__3)).Ref() } else { brk__8 = and__1927000168__auto____8 }
//line :81:1
		var f__9 any; var tmp3 *lang.Var


		A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_34; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_33; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_40; f__9 = tmp4.Invoke_O_O_O_O__O(f__6, tmp6, tmp7.Ref(), brk__8)
//line :81:1
		var cursor__10 any



		if jrt.A2g_Truth(brk__8) { cursor__10 = l__7 } else { cursor__10 = cursor__3 }
//line :81:1
		var vec__1123000033__11 any; var tmp8 *lang.Var




		A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_36; vec__1123000033__11 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(f__9, cursor__10)
//line :81:1
		var f__12 any = lang.RT_Nth_O_I_O__O(vec__1123000033__11, lang.RT_IntCast_J__I(0), nil); var cursor__13 any = lang.RT_Nth_O_I_O__O(vec__1123000033__11, lang.RT_IntCast_J__I(1), nil); var tmp9 *lang.Var





		A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_43; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(fs__2); var tmp11 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_7; fs__2, cursor__3, acc__4 = tmp10, cursor__13, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(acc__4, f__12); continue L1 } else {
//line :81:1
			return acc__4 } } }; /*line :77:1*/panic("a2g: unreachable") }



















func A_arbace_g2a_layout_key_rank_A_New() *A_arbace_g2a_layout_key_rank_A { A_arbace_g2a_layout_key_rank_A_Init(); t := &A_arbace_g2a_layout_key_rank_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_g2a_layout_key_rank_A) Ctor() {}
//line :97:1
func (t *A_arbace_g2a_layout_key_rank_A) Invoke_O_O__O(self, k__0 any) any { var i__2 int32; var tmp1 *lang.Var;
										A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_51; i__2 = jrt.List_Cast(jrt.NN(tmp1).GetRawRoot__O()).IndexOf_O__I(k__0); if
										lang.Numbers_IsNeg_J__Z(int64(i__2)) { var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_51; return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(jrt.NN(tmp2).GetRawRoot__O())).Ref() } else { return jrt.Integer_ValueOf_I__Integer(i__2).Ref() } }

func A_arbace_g2a_layout_sort_keys_A_New() *A_arbace_g2a_layout_sort_keys_A { A_arbace_g2a_layout_sort_keys_A_Init(); t := &A_arbace_g2a_layout_sort_keys_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_g2a_layout_sort_keys_A) Ctor() {}
//line :101:1
func (t *A_arbace_g2a_layout_sort_keys_A) Invoke_O_O__O(self, ks__0 any) any {
	var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_52; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_g2a_layout_sort_keys_fn__1123000038_A_New(); var tmp4 *jrt.Class; A_arbace_g2a_layout_sort_keys_fn__1123000038_A_Init(); tmp4 = A_arbace_g2a_layout_sort_keys_fn__1123000038_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ks__0) }
//line :102:1
func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_New() *A_arbace_g2a_layout_sort_keys_fn__1123000038_A { A_arbace_g2a_layout_sort_keys_fn__1123000038_A_Init(); t := &A_arbace_g2a_layout_sort_keys_fn__1123000038_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) Ctor() {}
//line :102:1
func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_53; var tmp2 any = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(k__1); var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_54; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(k__1)) }

func A_arbace_g2a_layout_public_meta_A_New() *A_arbace_g2a_layout_public_meta_A { A_arbace_g2a_layout_public_meta_A_Init(); t := &A_arbace_g2a_layout_public_meta_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_g2a_layout_public_meta_A) Ctor() {}
//line :104:1
func (t *A_arbace_g2a_layout_public_meta_A) Invoke_O_O__O(self, x__0 any) any { var m__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) { m__2 = lang.RT_Meta_O__IPersistentMap(x__0) } else { m__2 = nil }; var lines_QMARK___3 bool; var tmp2 /*line :104:1*/*lang.Var;



	A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_27; var tmp3 any = jrt.NN(tmp2).Get__O(); var tmp4 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_28; lines_QMARK___3 = lang.Util_Equiv_O_O__Z(tmp3, tmp4.Ref()); var pm__4 any; var tmp5 /*line :104:1*/*lang.Var;




	A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_55; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_57; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_g2a_layout_public_meta_fn__1123000042_A_New(); var tmp12 *jrt.Class; A_arbace_g2a_layout_public_meta_fn__1123000042_A_Init(); tmp12 = A_arbace_g2a_layout_public_meta_fn__1123000042_A_fn_class; pm__4 = tmp6.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil)), m__2); var pm__5 any; if lines_QMARK___3 {
		pm__5 = pm__4 } else { var G__1123000047__5_ any; var tmp13 *lang.Var

			A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_56; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_16; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_48; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp19 = A_arbace_g2a_layout_A_const_59; G__1123000047__5_ = tmp14.Invoke_O_O_O_O__O(pm__4, tmp16, tmp18, tmp19.Ref()); var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_29; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp22 = A_arbace_g2a_layout_A_const_60; if jrt.A2g_Truth(tmp21.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(m__2))) {
				var tmp23 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_33; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_61; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp27 = A_arbace_g2a_layout_A_const_60; pm__5 = tmp24.Invoke_O_O_O__O(G__1123000047__5_, tmp26, jrt.NN(tmp27).Invoke_O__O(m__2)) } else {
//line :112:1
					pm__5 = G__1123000047__5_ } }; return pm__5 }
//line :109:1
func A_arbace_g2a_layout_public_meta_fn__1123000042_A_New() *A_arbace_g2a_layout_public_meta_fn__1123000042_A { A_arbace_g2a_layout_public_meta_fn__1123000042_A_Init(); t := &A_arbace_g2a_layout_public_meta_fn__1123000042_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) Ctor() {}
//line :109:1
func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) Invoke_O_O__O(self, p__1123000041__1 any) any { var vec__1123000043__2 any = p__1123000041__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1123000043__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1123000043__2, lang.RT_IntCast_J__I(1), nil); var or__1927000174__auto____5 any; var tmp1 *lang.Var; _ = ___4; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_58; or__1927000174__auto____5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(k__3); if jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var tmp2 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_40; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(k__3, tmp2.Ref())).Ref() } }






func A_arbace_g2a_layout_meta_prefix_A_New() *A_arbace_g2a_layout_meta_prefix_A { A_arbace_g2a_layout_meta_prefix_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_g2a_layout_meta_prefix_A) Ctor() {}
//line :116:1
func (t *A_arbace_g2a_layout_meta_prefix_A) Invoke_O_O__O(self, x__0 any) any { var pm__2 any; var tmp1 *lang.Var;
										A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_62; pm__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0); var tmp2 /*line :118:1*/*lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(pm__2)) { var ks__3 any; var tmp3 *lang.Var
											A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_63; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_65; ks__3 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(pm__2))
//line :118:1
		var flags__4 any; var tmp6 *lang.Var

		A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_64; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_New_O(pm__2); var tmp9 *jrt.Class; A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_Init(); tmp9 = A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_fn_class; flags__4 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), ks__3)
//line :118:1
		var rest_ks__5 any; var tmp10 *lang.Var


		A_arbace_g2a_layout_A_Init(); tmp10 = A_arbace_g2a_layout_A_const_57; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_New_O(pm__2); var tmp13 *jrt.Class; A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_Init(); tmp13 = A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_fn_class; rest_ks__5 = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), ks__3)
//line :118:1
		var sb__6 any = jrt.StringBuilder_New(); var seq_1123000055__7 any; var tmp14 *lang.Var




		A_arbace_g2a_layout_A_Init(); tmp14 = A_arbace_g2a_layout_A_const_29; seq_1123000055__7 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(flags__4)
//line :118:1
		var chunk_1123000056__8 any; var count_1123000057__9 int64 = 0; var i_1123000058__10 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z(i_1123000058__10, count_1123000057__9) { var k__11 any = lang.Indexed_Cast(chunk_1123000056__8).Nth_I__O(lang.RT_IntCast_J__I(i_1123000058__10)); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_129, nil, Lit_121), jrt.RefArrayOf(jrt.Object_class, nil, k__11, nil))); seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, i_1123000058__10 = seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, lang.Numbers_Unchecked_inc_J__J(i_1123000058__10); continue L1 } else { var temp__1927000414__auto____11 any; var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_29; temp__1927000414__auto____11 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_1123000055__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1123000055__12 any = temp__1927000414__auto____11; var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq_1123000055__12)) { var c__1927000678__auto____13 any; var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_70; c__1927000678__auto____13 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_1123000055__12); var tmp18 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp18 = A_arbace_g2a_layout_A_const_75; seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, i_1123000058__10 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_1123000055__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var k__13 any; var tmp19 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp19 = A_arbace_g2a_layout_A_const_31; k__13 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_1123000055__12); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_129, nil, Lit_121), jrt.RefArrayOf(jrt.Object_class, nil, k__13, nil))); var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_43; seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, i_1123000058__10 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_1123000055__12), nil, 0, 0; continue L1 } } }
//line :118:1
			break L1
		}




		var tmp21 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp21 = A_arbace_g2a_layout_A_const_71; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(rest_ks__5)) { } else { var tmp22 any; var and__1927000168__auto____7 bool; var tmp23 any

			A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_72; and__1927000168__auto____7 = lang.Util_Equiv_O_O__Z(rest_ks__5, tmp23); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var tmp24 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp24 = A_arbace_g2a_layout_A_const_73; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp26 = A_arbace_g2a_layout_A_const_74; and__1927000168__auto____8 = tmp25.Invoke_O__O(jrt.NN(tmp26).Invoke_O__O(pm__2)); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp27 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp27 = A_arbace_g2a_layout_A_const_71; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp29 = A_arbace_g2a_layout_A_const_62; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp31 = A_arbace_g2a_layout_A_const_74; tmp22 = tmp28.Invoke_O__O(tmp30.Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(pm__2))) } else { tmp22 = and__1927000168__auto____8 } } else { tmp22 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }
//line :124:1
			if jrt.A2g_Truth(tmp22) {


				var tmp32 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__6); var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_129, nil, Lit_121); var tmp34 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp34 = A_arbace_g2a_layout_A_const_74; jrt.NN(tmp32).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp34).Invoke_O__O(pm__2), nil))) } else {
//line :124:1
					var tmp35 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp35 = A_arbace_g2a_layout_A_const_35; if tmp35 != nil {




						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_130)
						var tmp36 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__6); var tmp37 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp37 = A_arbace_g2a_layout_A_const_76; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; var iter__1927001039__auto____7 any; var tmp40 any = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_New_O(pm__2); var tmp41 *jrt.Class; A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_Init(); tmp41 = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_fn_class; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); tmp39 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(rest_ks__5); jrt.NN(tmp36).Append_String__StringBuilder(jrt.String_Cast(tmp38.Invoke_O_O__O(Lit_121, tmp39)))
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_131) } } }
		var tmp42 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp42 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(sb__6) } else {
//line :118:1
			return nil } }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_New_O(p0 any) *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A { A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_fn__1123000051_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :120:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) Invoke_O_O__O(self, p1__1123000049_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_66; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1123000049_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_67; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_68; return tmp3.Invoke_O_O__O(p1__1123000049_SHARP___1, tmp4.Ref()) } else { return and__1927000168__auto____2 } }
func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_New_O(p0 any) *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A { A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_fn__1123000053_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :121:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) Invoke_O_O__O(self, p1__1123000050_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_66; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1123000050_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_67; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_68; return tmp3.Invoke_O_O__O(p1__1123000050_SHARP___1, tmp4.Ref()) } else { return and__1927000168__auto____2 } }








func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_New_O(p0 any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A{}; t.Ctor_O(p0); return t }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) Invoke_O_O__O(self, s__1123000060__1 any) any { var tmp1 any = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_New_O_O_O(s__1123000060__1, t.F_pm, self); var tmp2 *jrt.Class; A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_Init(); tmp2 = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :130:1
func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) Ctor_O_O_O(c__s__1123000060, c__pm, c__iter__1123000059 any) { t.F_s__1123000060 = c__s__1123000060; t.F_pm = c__pm; t.F_iter__1123000059 = c__iter__1123000059 }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) Invoke_O__O(self any) any { { var s__1123000060__1 any; var t_ any = t.F_s__1123000060; t.F_s__1123000060 = nil; s__1123000060__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_29; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1123000060__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000060__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1123000060__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_70; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1123000060__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000062__6 any; var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_77; b__1123000062__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_New_O_O_I_O(b__1123000062__6, t.F_pm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_Init(); tmp6 = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_80; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_82; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1123000062__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1123000059); var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1123000060__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_80; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_82; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1123000062__6), nil) } } else { var k__4 any; var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_31; k__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1123000060__3); var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_81; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_121, nil); var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_79; var tmp21 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, k__4, nil, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(k__4)))).Ref(); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__1123000059); var tmp23 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_83; return tmp18.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1123000060__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :130:1
func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) Ctor_O_O_I_O(c__b__1123000062, c__pm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1123000062 = c__b__1123000062; t.F_pm = c__pm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) Invoke_O__O(self any) any { { var i__1123000061__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000061__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000061__1)); var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_78; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1123000062; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_121, nil); var tmp6 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_79; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, k__2, nil, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(k__2)))).Ref()); i__1123000061__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000061__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_g2a_layout_atom_text_A_New() *A_arbace_g2a_layout_atom_text_A { A_arbace_g2a_layout_atom_text_A_Init(); t := &A_arbace_g2a_layout_atom_text_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_g2a_layout_atom_text_A) Ctor() {}
//line :134:1
func (t *A_arbace_g2a_layout_atom_text_A) Invoke_O_O__O(self, x__0 any) any {
	if lang.Util_Identical_O_O__Z(x__0, nil) { return Lit_112 } else { var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) {

		var tmp2 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_84; return jrt.NN(tmp2).Invoke_O__O(x__0) } else {
//line :135:1
			var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_73; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0)) {


				var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
					var tmp5 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_10; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__0)) {



						var tmp6 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
							var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_85; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(x__0)) {




								var tmp8 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_86; return lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
									var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_87; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(x__0)) {





										var tmp10 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp10 = A_arbace_g2a_layout_A_const_88; return lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(x__0)).Ref()) } else {
//line :135:1
											if lang.BigInt_InstanceOf(x__0) {






												return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_113), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :135:1
													if jrt.BigInteger_InstanceOf(x__0) {







														return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_113), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :135:1
															var tmp11 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_89; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(x__0)) {








																var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
																	var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_90; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(x__0)) {









																		var tmp14 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp14 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
																			if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D(x__0)











																				if jrt.Double_IsNaN_D__Z(d__2) { return Lit_114 } else { if jrt.Double_IsInfinite_D__Z(d__2) {
																					if lang.Numbers_IsPos_D__Z(d__2) { return Lit_115 } else { return Lit_116 } } else {
//line :147:1
																						var tmp15 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_35; if tmp15 != nil {

																							var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :147:1
																								return nil } } } } else {
//line :135:1
																									if jrt.BigDecimal_InstanceOf(x__0) {














																										return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_117), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :135:1
																											var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_91; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(x__0)) {















																												var tmp18 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp18 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
																													var tmp19 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp19 = A_arbace_g2a_layout_A_const_35; if tmp19 != nil { var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_92; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_118, nil); var tmp23 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_93; var tmp24 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var tmp25 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_94; panic(jrt.Thrown(jrt.Throwable_Cast(tmp21.Invoke_O_O__O(tmp24, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25.Ref(), x__0)))))) } else { return nil
																													}
																												}
																										}
																								}
																		}
																}
														}
												}
										}
								}
						}
				}
		}
	}
}



func A_arbace_g2a_layout_text_A_New() *A_arbace_g2a_layout_text_A { A_arbace_g2a_layout_text_A_Init(); t := &A_arbace_g2a_layout_text_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_g2a_layout_text_A) Ctor() {}
//line :154:1
func (t *A_arbace_g2a_layout_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_95; var tmp3 any = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0); var tmp4 any; var tmp5 *lang.Var
	A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__0)) {
		var tmp6 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_84; tmp4 = jrt.NN(tmp6).Invoke_O__O(x__0) } else {
//line :158:1
			var tmp7 any; var and__1927000168__auto____4 any; var tmp8 *lang.Var

			A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_13; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp9 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_26; var tmp10 *lang.Keyword = tmp9; tmp7 = jrt.NN(tmp10).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else { tmp7 = and__1927000168__auto____4 }
//line :158:1
			if jrt.A2g_Truth(tmp7) {

				var tmp11 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_26; var tmp12 *lang.Keyword = tmp11; tmp4 = jrt.NN(tmp12).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else {
//line :158:1
					var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(x__0)) {


						var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_148, nil); var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_79; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_98; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(x__0)))).Ref() } else {
//line :158:1
							var tmp18 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp18 = A_arbace_g2a_layout_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(x__0)) {



								var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_149, nil, Lit_150); var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_76; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp22 = A_arbace_g2a_layout_A_const_99; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp24 = A_arbace_g2a_layout_A_const_79; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp21.Invoke_O_O__O(Lit_121, tmp23.Invoke_O_O__O(jrt.NN(tmp24).GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :158:1
									var tmp25 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_25; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(x__0)) {




										var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_151, nil, Lit_152); var tmp27 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp27 = A_arbace_g2a_layout_A_const_76; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp29 = A_arbace_g2a_layout_A_const_99; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp31 = A_arbace_g2a_layout_A_const_79; tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp28.Invoke_O_O__O(Lit_121, tmp30.Invoke_O_O__O(jrt.NN(tmp31).GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :158:1
											var tmp32 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp32 = A_arbace_g2a_layout_A_const_96; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(x__0)) {





												var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_153, nil, Lit_154); var tmp34 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp34 = A_arbace_g2a_layout_A_const_76; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any; var iter__1927001039__auto____7 any; var tmp37 any = A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_New(); var tmp38 *jrt.Class; A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_Init(); tmp38 = A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_fn_class; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil); tmp36 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(x__0); tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp35.Invoke_O_O__O(Lit_121, tmp36), nil)).Ref() } else {
//line :158:1
													var tmp39 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp39 = A_arbace_g2a_layout_A_const_35; if tmp39 != nil {






														var tmp40 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp40 = A_arbace_g2a_layout_A_const_97; tmp4 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :158:1
															tmp4 = nil } } } } } } }
//line :157:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref()
}





func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_New() *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A { A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_Init(); t := &A_arbace_g2a_layout_text_iter__1123000071__1123000075_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) Ctor() {}
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) Invoke_O_O__O(self, s__1123000072__1 any) any { var tmp1 any = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_New_O_O(s__1123000072__1, self); var tmp2 *jrt.Class; A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_Init(); tmp2 = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :164:1
func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_New_O_O(p0, p1 any) *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A { A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_Init(); t := &A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) Ctor_O_O(c__s__1123000072, c__iter__1123000071 any) { t.F_s__1123000072 = c__s__1123000072; t.F_iter__1123000071 = c__iter__1123000071 }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) Invoke_O__O(self any) any { { var s__1123000072__1 any; var t_ any = t.F_s__1123000072; t.F_s__1123000072 = nil; s__1123000072__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_29; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1123000072__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000072__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1123000072__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_70; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1123000072__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000074__6 any; var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_77; b__1123000074__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_New_O_I_O(b__1123000074__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_Init(); tmp6 = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_80; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_82; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1123000074__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1123000071); var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1123000072__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_80; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_82; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1123000074__6), nil) } } else { var vec__1123000082__4 any; var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_31; vec__1123000082__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1123000072__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1123000082__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1123000082__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_81; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_121, nil); var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_79; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(k__5); var tmp22 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp22 = A_arbace_g2a_layout_A_const_79; var tmp23 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(v__6))).Ref(); var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__1123000071); var tmp25 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_83; return tmp18.Invoke_O_O__O(tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(s__1123000072__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :164:1
func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A { A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_Init(); t := &A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) Ctor_O_I_O(c__b__1123000074 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1123000074 = c__b__1123000074; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) Invoke_O__O(self any) any { { var i__1123000073__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1123000078__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000073__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1123000078__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1123000078__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_78; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1123000074; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_121, nil); var tmp6 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_79; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(k__3); var tmp8 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_79; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__1123000073__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000073__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_g2a_layout_comment_text_A_New() *A_arbace_g2a_layout_comment_text_A { A_arbace_g2a_layout_comment_text_A_Init(); t := &A_arbace_g2a_layout_comment_text_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_g2a_layout_comment_text_A) Ctor() {}
//line :167:1
func (t *A_arbace_g2a_layout_comment_text_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_100; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_120)) {
		var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_101; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_103; return tmp3.Invoke_O_O__O(t__0, tmp4) } else {
//line :170:1
			var tmp5 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_35; if tmp5 != nil {

				var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_121, nil); var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_102; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(t__0))).Ref() } else {
//line :170:1
					return nil
				}
		}
}
func A_arbace_g2a_layout_write_file_A_New() *A_arbace_g2a_layout_write_file_A { A_arbace_g2a_layout_write_file_A_Init(); t := &A_arbace_g2a_layout_write_file_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_g2a_layout_write_file_A) Ctor() {}
//line :174:1
func (t *A_arbace_g2a_layout_write_file_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any { var forms__3 any; var tmp1 *lang.Var;


	A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_104; forms__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(forms__0); var sb__4 any = /*line :174:1*/jrt.StringBuilder_New(); var line__5 any; var tmp2 *lang.Var;




	A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_105; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_111; line__5 = tmp3.Invoke_O__O(tmp4); var code_QMARK___6 any; var tmp5 /*line :174:1*/*lang.Var;





	A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_105; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; code_QMARK___6 = tmp6.Invoke_O__O(tmp7.Ref()); var depth__7 any; var tmp8 /*line :174:1*/*lang.Var;






	A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_105; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; A_arbace_g2a_layout_A_Init(); tmp10 = A_arbace_g2a_layout_A_const_24; depth__7 = tmp9.Invoke_O__O(tmp10); var flush_comments_BANG___8 any; var tmp11 any = /*line :174:1*/A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, comments__1, depth__7); var tmp12 *jrt.Class;








	A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_Init(); tmp12 = A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_fn_class; flush_comments_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var newline_to_BANG___9 any; var tmp13 any = /*line :174:1*/A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, flush_comments_BANG___8, depth__7); var tmp14 *jrt.Class;















	A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_Init(); tmp14 = A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_fn_class; newline_to_BANG___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var emit__10 any; var tmp15 any = /*line :174:1*/A_arbace_g2a_layout_write_file_emit__1123000093_A_New_O_O_O_O(newline_to_BANG___9, sb__4, code_QMARK___6, depth__7); var tmp16 *jrt.Class;























	A_arbace_g2a_layout_write_file_emit__1123000093_A_Init(); tmp16 = A_arbace_g2a_layout_write_file_emit__1123000093_A_fn_class; emit__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var seq_1123000105__11 any; var tmp17 /*line :174:1*/*lang.Var;












































	A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_29; seq_1123000105__11 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(forms__3); var chunk_1123000106__12 any; var count_1123000107__13 int64 = 0; var i_1123000108__14 int64 = 0; L1:
//line :174:1
	for {












































		if lang.Numbers_Lt_J_J__Z(i_1123000108__14, count_1123000107__13) { var f__15 any = lang.Indexed_Cast(chunk_1123000106__12).Nth_I__O(lang.RT_IntCast_J__I(i_1123000108__14)); var tmp18 *lang.Keyword
			A_arbace_g2a_layout_A_Init(); tmp18 = A_arbace_g2a_layout_A_const_40; var tmp19 *lang.Keyword = tmp18; if jrt.A2g_Truth(jrt.NN(tmp19).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__15))) {
				lang.IFn_Cast(emit__10).Invoke_O__O(f__15) } else {
					var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_6; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(code_QMARK___6)) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_121) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__15) }
//line :219:1
			seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, i_1123000108__14 = seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, lang.Numbers_Unchecked_inc_J__J(i_1123000108__14); continue L1 } else { var temp__1927000414__auto____15 any; var tmp21 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp21 = A_arbace_g2a_layout_A_const_29; temp__1927000414__auto____15 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_1123000105__11); if jrt.A2g_Truth(temp__1927000414__auto____15) { var seq_1123000105__16 any = temp__1927000414__auto____15; var tmp22 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp22 = A_arbace_g2a_layout_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_1123000105__16)) { var c__1927000678__auto____17 any; var tmp23 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_70; c__1927000678__auto____17 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_1123000105__16); var tmp24 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp24 = A_arbace_g2a_layout_A_const_75; seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, i_1123000108__14 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_1123000105__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__17 any; var tmp25 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_31; f__17 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_1123000105__16)
				var tmp26 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp26 = A_arbace_g2a_layout_A_const_40; var tmp27 *lang.Keyword = tmp26; if jrt.A2g_Truth(jrt.NN(tmp27).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__17))) {
					lang.IFn_Cast(emit__10).Invoke_O__O(f__17) } else {
						var tmp28 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp28 = A_arbace_g2a_layout_A_const_6; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(code_QMARK___6)) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_121) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__17) }
//line :219:1
				var tmp29 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp29 = A_arbace_g2a_layout_A_const_43; seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, i_1123000108__14 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_1123000105__16), nil, 0, 0; continue L1 } } }
//line :174:1
		break L1 }; var last_comment__11 any; var tmp30 *lang.Var;
















































	A_arbace_g2a_layout_A_Init(); tmp30 = A_arbace_g2a_layout_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(comments__1)) { var tmp31 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp31 = A_arbace_g2a_layout_A_const_45; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp33 = A_arbace_g2a_layout_A_const_112; var tmp34 any = jrt.NN(tmp33).GetRawRoot__O(); var tmp35 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp35 = A_arbace_g2a_layout_A_const_65; last_comment__11 = tmp32.Invoke_O_O__O(tmp34, lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(comments__1)) } else { A_arbace_g2a_layout_A_Init(); last_comment__11 = A_arbace_g2a_layout_A_const_24 }; var tmp36 /*line :224:1*/*lang.Var; A_arbace_g2a_layout_A_Init(); tmp36 = A_arbace_g2a_layout_A_const_6; if lang.Numbers_Gt_O_O__Z(last_comment__11, lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(line__5)) {
		var tmp37 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp37 = A_arbace_g2a_layout_A_const_108; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_g2a_layout_A_Init(); tmp39 = A_arbace_g2a_layout_A_const_24; tmp38.Invoke_O_O__O(depth__7, tmp39)
		lang.IFn_Cast(newline_to_BANG___9).Invoke_O__O(last_comment__11) };
	lang.IFn_Cast(flush_comments_BANG___8).Invoke__O();
	jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_159); var tmp40 /*line :229:1*/*lang.Var; A_arbace_g2a_layout_A_Init(); tmp40 = A_arbace_g2a_layout_A_const_54; return lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(sb__4) }
//line :183:1
func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A { A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_Init(); t := &A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :183:1
func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__comments, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_comments = c__comments; t.F_depth = c__depth }
//line :183:1
func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var tmp1 any = t.F_comments; var tmp2 *lang.Var;
													A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_6; temp__1927000414__auto____1 = lang.RT_Get_O_O__O(tmp1, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(t.F_line)); if jrt.A2g_Truth(temp__1927000414__auto____1) { var cs__2 any = temp__1927000414__auto____1; var tmp3 *lang.Var
														A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_6; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_code_QMARK_)) {
															var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_162, nil); var tmp6 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_76; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp8 = A_arbace_g2a_layout_A_const_99; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp10 = A_arbace_g2a_layout_A_const_106; return jrt.NN(tmp4).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7.Invoke_O_O__O(Lit_162, tmp9.Invoke_O_O__O(jrt.NN(tmp10).GetRawRoot__O(), cs__2))))).Ref() } else {
																var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_45; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp14 = A_arbace_g2a_layout_A_const_54; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_107; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp18 = A_arbace_g2a_layout_A_const_6; jrt.NN(tmp11).Append_O__StringBuilder(tmp13.Invoke_O_O__O(tmp15, tmp17.Invoke_O_O__O(lang.Numbers_Multiply_J_O__Number(2, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(t.F_depth)), Lit_121)))
																var tmp19 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_163, nil); var tmp21 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp21 = A_arbace_g2a_layout_A_const_76; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_99; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_106; return jrt.NN(tmp19).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp22.Invoke_O_O__O(Lit_164, tmp24.Invoke_O_O__O(jrt.NN(tmp25).GetRawRoot__O(), cs__2))))).Ref() } } else {
//line :184:1
					return nil } }





func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A { A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_Init(); t := &A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :190:1
func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__flush_comments_BANG_, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_flush_comments_BANG_ = c__flush_comments_BANG_; t.F_depth = c__depth }
//line :190:1
func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) Invoke_O_O__O(self, l__1 any) any { L1: for {
	var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_6; if lang.Numbers_Lt_O_O__Z(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_line), l__1) {
		lang.IFn_Cast(t.F_flush_comments_BANG_).Invoke__O()
		var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp2).Append_String__StringBuilder(Lit_159)
		var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_line); jrt.NN(tmp3).Reset_O__O(lang.Numbers_Inc_O__Number(jrt.NN(lang.Volatile_Cast(t.F_line)).Deref__O()))
		var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_108; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_code_QMARK_; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; tmp5.Invoke_O_O__O(tmp6, tmp7.Ref())
//line :191:1
		continue L1 }
//line :190:1
	break L1
}




	var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_45; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp11 = A_arbace_g2a_layout_A_const_54; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_107; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_6; return jrt.NN(tmp8).Append_O__StringBuilder(tmp10.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O__O(lang.Numbers_Multiply_J_O__Number(2, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(t.F_depth)), Lit_121))).Ref()
}
func A_arbace_g2a_layout_write_file_emit__1123000093_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_layout_write_file_emit__1123000093_A { A_arbace_g2a_layout_write_file_emit__1123000093_A_Init(); t := &A_arbace_g2a_layout_write_file_emit__1123000093_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :198:1
func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) Ctor_O_O_O_O(c__newline_to_BANG_, c__sb, c__code_QMARK_, c__depth any) { t.F_newline_to_BANG_ = c__newline_to_BANG_; t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_depth = c__depth }
//line :198:1
func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_17; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_15; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__1) }; if jrt.A2g_Truth(and__1927000168__auto____2) {
		var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(x__1)) { var tmp5 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_37; tmp1 = jrt.NN(tmp5).Invoke_O__O(x__1) } else { var tmp6 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_40; var tmp7 *lang.Keyword = tmp6; tmp1 = jrt.NN(tmp7).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__1)) } } else {
//line :199:1
			tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {

				var tmp8 lang.IFn = lang.IFn_Cast(t.F_newline_to_BANG_); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_32; tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(x__1)) }
	var tmp10 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp10 = A_arbace_g2a_layout_A_const_108; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = t.F_code_QMARK_; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; tmp11.Invoke_O_O__O(tmp12, tmp13.Ref())
//line :198:1
	var p__2 any; var tmp14 *lang.Var




	A_arbace_g2a_layout_A_Init(); tmp14 = A_arbace_g2a_layout_A_const_95; p__2 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__1)
	if jrt.A2g_Truth(p__2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(p__2) }
	var tmp15 any; var and__1927000168__auto____2_2 any; var tmp16 *lang.Var
	A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_13; and__1927000168__auto____2_2 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____2_2) { var tmp17 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_26; var tmp18 *lang.Keyword = tmp17; tmp15 = jrt.NN(tmp18).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__1)) } else { tmp15 = and__1927000168__auto____2_2 }
//line :205:1
	if jrt.A2g_Truth(tmp15) {
		var tmp19 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp20 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_26; var tmp21 *lang.Keyword = tmp20; return jrt.NN(tmp19).Append_String__StringBuilder(jrt.String_Cast(jrt.NN(tmp21).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__1)))).Ref() } else {
//line :205:1
			var tmp22 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp22 = A_arbace_g2a_layout_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(x__1)) {

				var tmp23 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp23).Append_String__StringBuilder(Lit_148); var tmp24 lang.IFn = lang.IFn_Cast(self); var tmp25 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp25 = A_arbace_g2a_layout_A_const_98; return tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :205:1
					var tmp26 any; var or__1927000174__auto____2_2 any; var tmp27 *lang.Var


					A_arbace_g2a_layout_A_Init(); tmp27 = A_arbace_g2a_layout_A_const_13; or__1927000174__auto____2_2 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(or__1927000174__auto____2_2) { tmp26 = or__1927000174__auto____2_2 } else { var tmp28 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp28 = A_arbace_g2a_layout_A_const_25; tmp26 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(x__1) }
//line :205:1
					if jrt.A2g_Truth(tmp26) {



						var tmp29 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp30 *jrt.String; var tmp31 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp31 = A_arbace_g2a_layout_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(x__1)) { tmp30 = Lit_149 } else { tmp30 = Lit_151 }; jrt.NN(tmp29).Append_String__StringBuilder(tmp30)
						var tmp32 *lang.Volatile = lang.Volatile_Cast(t.F_depth); jrt.NN(tmp32).Reset_O__O(lang.Numbers_Inc_O__Number(jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O()))
//line :205:1
						var seq_1123000094__2 any; var tmp33 *lang.Var





						A_arbace_g2a_layout_A_Init(); tmp33 = A_arbace_g2a_layout_A_const_29; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp35 = A_arbace_g2a_layout_A_const_109; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp37 = A_arbace_g2a_layout_A_const_110; seq_1123000094__2 = tmp34.Invoke_O__O(tmp36.Invoke_O_O__O(jrt.NN(tmp37).GetRawRoot__O(), x__1))
//line :205:1
						var chunk_1123000095__3 any; var count_1123000096__4 int64 = 0; var i_1123000097__5 int64 = 0; L1: for {





							if lang.Numbers_Lt_J_J__Z(i_1123000097__5, count_1123000096__4) { var vec__1123000098__6 any = lang.Indexed_Cast(chunk_1123000095__3).Nth_I__O(lang.RT_IntCast_J__I(i_1123000097__5)); var i__7 any = lang.RT_Nth_O_I_O__O(vec__1123000098__6, lang.RT_IntCast_J__I(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O(vec__1123000098__6, lang.RT_IntCast_J__I(1), nil); var tmp38 any; var and__1927000168__auto____9 bool = lang.Numbers_IsPos_O__Z(i__7)
								if and__1927000168__auto____9 {
									var tmp39 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp39 = A_arbace_g2a_layout_A_const_38; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; var tmp42 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp42 = A_arbace_g2a_layout_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(c__8)) { var tmp43 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp43 = A_arbace_g2a_layout_A_const_37; tmp41 = jrt.NN(tmp43).Invoke_O__O(c__8) } else { var and__1927000168__auto____10 any; var tmp44 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp44 = A_arbace_g2a_layout_A_const_17; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(c__8); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp45 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp45 = A_arbace_g2a_layout_A_const_40; var tmp46 *lang.Keyword = tmp45; tmp41 = jrt.NN(tmp46).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(c__8)) } else { tmp41 = and__1927000168__auto____10 } }; tmp38 = tmp40.Invoke_O__O(tmp41) } else {
//line :212:1
										tmp38 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.A2g_Truth(tmp38) {

											var tmp47 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp47).Append_String__StringBuilder(Lit_121) }
								lang.IFn_Cast(self).Invoke_O__O(c__8)
//line :211:1
								seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, i_1123000097__5 = seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, lang.Numbers_Unchecked_inc_J__J(i_1123000097__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp48 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp48 = A_arbace_g2a_layout_A_const_29; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O__O(seq_1123000094__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1123000094__7 any = temp__1927000414__auto____6; var tmp49 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp49 = A_arbace_g2a_layout_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(seq_1123000094__7)) { var c__1927000678__auto____8 any; var tmp50 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp50 = A_arbace_g2a_layout_A_const_70; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(seq_1123000094__7); var tmp51 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp51 = A_arbace_g2a_layout_A_const_75; seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, i_1123000097__5 = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(seq_1123000094__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1123000101__8 any; var tmp52 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp52 = A_arbace_g2a_layout_A_const_31; vec__1123000101__8 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(seq_1123000094__7); var i__9 any = lang.RT_Nth_O_I_O__O(vec__1123000101__8, lang.RT_IntCast_J__I(0), nil); var c__10 any = lang.RT_Nth_O_I_O__O(vec__1123000101__8, lang.RT_IntCast_J__I(1), nil); var tmp53 any; var and__1927000168__auto____11 bool = lang.Numbers_IsPos_O__Z(i__9)
									if and__1927000168__auto____11 {
										var tmp54 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp54 = A_arbace_g2a_layout_A_const_38; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 any; var tmp57 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp57 = A_arbace_g2a_layout_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(c__10)) { var tmp58 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp58 = A_arbace_g2a_layout_A_const_37; tmp56 = jrt.NN(tmp58).Invoke_O__O(c__10) } else { var and__1927000168__auto____12 any; var tmp59 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp59 = A_arbace_g2a_layout_A_const_17; and__1927000168__auto____12 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(c__10); if jrt.A2g_Truth(and__1927000168__auto____12) { var tmp60 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp60 = A_arbace_g2a_layout_A_const_40; var tmp61 *lang.Keyword = tmp60; tmp56 = jrt.NN(tmp61).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(c__10)) } else { tmp56 = and__1927000168__auto____12 } }; tmp53 = tmp55.Invoke_O__O(tmp56) } else {
//line :212:1
											tmp53 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() }; if jrt.A2g_Truth(tmp53) {

												var tmp62 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp62).Append_String__StringBuilder(Lit_121) }
									lang.IFn_Cast(self).Invoke_O__O(c__10)
//line :211:1
									var tmp63 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp63 = A_arbace_g2a_layout_A_const_43; seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, i_1123000097__5 = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_1123000094__7), nil, 0, 0; continue L1 } } }
//line :205:1
							break L1
						}









						var tmp64 *lang.Volatile = lang.Volatile_Cast(t.F_depth); jrt.NN(tmp64).Reset_O__O(lang.Numbers_Dec_O__Number(jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O()))
						var tmp65 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp66 *jrt.String; var tmp67 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp67 = A_arbace_g2a_layout_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(x__1)) { tmp66 = Lit_150 } else { tmp66 = Lit_152 }; return jrt.NN(tmp65).Append_String__StringBuilder(tmp66).Ref() } else {
//line :205:1
							var tmp68 *lang.Keyword; A_arbace_g2a_layout_A_Init(); tmp68 = A_arbace_g2a_layout_A_const_35; if tmp68 != nil {












								var tmp69 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp70 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp70 = A_arbace_g2a_layout_A_const_97; return jrt.NN(tmp69).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else {
//line :205:1
									return nil
								}
						}
				}
		}
}




















func A_arbace_g2a_layout_write_package_A_New() *A_arbace_g2a_layout_write_package_A { A_arbace_g2a_layout_write_package_A_Init(); t := &A_arbace_g2a_layout_write_package_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_g2a_layout_write_package_A) Ctor() {}
//line :231:1
func (t *A_arbace_g2a_layout_write_package_A) Invoke_O_O_O_O__O(self, ns_sym__0, pkg_form__1, loads__2 any) any { var vec__1123000110__4 any = pkg_form__1; var seq__1123000111__5 any; var tmp1 *lang.Var;


	A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_29; seq__1123000111__5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1123000110__4); var first__1123000112__6 any; var tmp2 /*line :231:1*/*lang.Var;


	A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_31; first__1123000112__6 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1123000111__5); var seq__1123000111__7 any; var tmp3 /*line :231:1*/*lang.Var;


	A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_43; seq__1123000111__7 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1123000111__5); var head__8 any = first__1123000112__6; var first__1123000112__9 any; var tmp4 /*line :231:1*/*lang.Var;


	A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_31; first__1123000112__9 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1123000111__7); var seq__1123000111__10 any; var tmp5 /*line :231:1*/*lang.Var;


	A_arbace_g2a_layout_A_Init(); tmp5 = A_arbace_g2a_layout_A_const_43; seq__1123000111__10 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1123000111__7); var nm__11 any = first__1123000112__9; var opts__12 any = seq__1123000111__10; var tmp6 /*line :231:1*/*jrt.RefArray = jrt.ConstRefArray("[0,10,s4:(ns ns35:\n  (:require [arbace.go :as go]))\n\ns1:(ns1: nns3:)\n\nn", []*jrt.Class{jrt.String_class}); var tmp7 *lang.Var;



	A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_45; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_54; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 any; var iter__1927001039__auto____23 any; var tmp12 any = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_New(); var tmp13 *jrt.Class;

	A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_Init(); tmp13 = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_fn_class; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____23); var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_113; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_103; tmp11 = tmp14.Invoke_O__O(tmp16.Invoke_O_O__O(tmp17, opts__12)); var tmp18 any = /*line :235:1*/tmp8.Invoke_O_O__O(tmp10, tmp11); var tmp19 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp19 = A_arbace_g2a_layout_A_const_45; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp21 = A_arbace_g2a_layout_A_const_54; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 any; var iter__1927001039__auto____23_2 any; var tmp24 any = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_New(); var tmp25 *jrt.Class;



	A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_Init(); tmp25 = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_fn_class; iter__1927001039__auto____23_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); tmp23 = lang.IFn_Cast(iter__1927001039__auto____23_2).Invoke_O__O(loads__2); return /*line :235:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__0, nil, nil, head__8, nil, nm__11, tmp18, nil, tmp20.Invoke_O_O__O(tmp22, tmp23))).Ref() }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_New() *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) Ctor() {}
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) Invoke_O_O__O(self, s__1123000114__1 any) any { var tmp1 any = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_New_O_O(s__1123000114__1, self); var tmp2 *jrt.Class; A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_Init(); tmp2 = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :237:1
func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_New_O_O(p0, p1 any) *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) Ctor_O_O(c__s__1123000114, c__iter__1123000113 any) { t.F_s__1123000114 = c__s__1123000114; t.F_iter__1123000113 = c__iter__1123000113 }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) Invoke_O__O(self any) any { { var s__1123000114__1 any; var t_ any = t.F_s__1123000114; t.F_s__1123000114 = nil; s__1123000114__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_29; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1123000114__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000114__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1123000114__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_70; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1123000114__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000116__6 any; var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_77; b__1123000116__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_New_O_I_O(b__1123000116__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_Init(); tmp6 = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_80; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_82; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1123000116__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1123000113); var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1123000114__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_80; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_82; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1123000116__6), nil) } } else { var vec__1123000124__4 any; var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_31; vec__1123000124__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1123000114__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1123000124__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1123000124__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_81; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_169, nil, Lit_121, nil); var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_79; var tmp21 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(v__6))).Ref(); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__1123000113); var tmp23 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_83; return tmp18.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1123000114__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :237:1
func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) Ctor_O_I_O(c__b__1123000116 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1123000116 = c__b__1123000116; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) Invoke_O__O(self any) any { { var i__1123000115__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000115__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1123000120__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000115__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1123000120__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1123000120__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_78; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1123000116; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_169, nil, Lit_121, nil); var tmp6 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_79; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__1123000115__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000115__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_New() *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) Ctor() {}
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) Invoke_O_O__O(self, s__1123000130__1 any) any { var tmp1 any = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_New_O_O(self, s__1123000130__1); var tmp2 *jrt.Class; A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_Init(); tmp2 = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :239:1
func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_New_O_O(p0, p1 any) *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) Ctor_O_O(c__iter__1123000129, c__s__1123000130 any) { t.F_iter__1123000129 = c__iter__1123000129; t.F_s__1123000130 = c__s__1123000130 }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) Invoke_O__O(self any) any { { var s__1123000130__1 any; var t_ any = t.F_s__1123000130; t.F_s__1123000130 = nil; s__1123000130__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp1 = A_arbace_g2a_layout_A_const_29; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1123000130__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000130__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_69; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1123000130__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp3 = A_arbace_g2a_layout_A_const_70; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1123000130__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000132__6 any; var tmp4 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp4 = A_arbace_g2a_layout_A_const_77; b__1123000132__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_New_I_O_O(size__1927001038__auto____5, b__1123000132__6, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_Init(); tmp6 = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp7 = A_arbace_g2a_layout_A_const_80; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp9 = A_arbace_g2a_layout_A_const_82; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1123000132__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1123000129); var tmp12 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp12 = A_arbace_g2a_layout_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1123000130__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp13 = A_arbace_g2a_layout_A_const_80; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp15 = A_arbace_g2a_layout_A_const_82; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1123000132__6), nil) } } else { var l__4 any; var tmp16 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp16 = A_arbace_g2a_layout_A_const_31; l__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1123000130__3); var tmp17 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp17 = A_arbace_g2a_layout_A_const_81; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_173, nil, Lit_174); var tmp20 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp20 = A_arbace_g2a_layout_A_const_86; var tmp21 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(l__4), nil)).Ref(); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__1123000129); var tmp23 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp23 = A_arbace_g2a_layout_A_const_83; return tmp18.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1123000130__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :239:1
func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1123000132, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1123000132 = c__b__1123000132; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) Invoke_O__O(self any) any { { var i__1123000131__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000131__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000131__1)); var tmp2 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp2 = A_arbace_g2a_layout_A_const_78; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1123000132; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_173, nil, Lit_174); var tmp6 *lang.Var; A_arbace_g2a_layout_A_Init(); tmp6 = A_arbace_g2a_layout_A_const_86; tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(l__2), nil)).Ref()); i__1123000131__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000131__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



































type A_arbace_g2a_layout_A struct{ jrt.Object }

var A_arbace_g2a_layout_A_const_0 *lang.Var

var A_arbace_g2a_layout_A_const_1 *lang.Var

var A_arbace_g2a_layout_A_const_2 any

var A_arbace_g2a_layout_A_const_3 any

var A_arbace_g2a_layout_A_const_4 any

var A_arbace_g2a_layout_A_const_5 *lang.Var

var A_arbace_g2a_layout_A_const_6 *lang.Var

var A_arbace_g2a_layout_A_const_7 *lang.Var

var A_arbace_g2a_layout_A_const_8 any

var A_arbace_g2a_layout_A_const_9 *lang.Var

var A_arbace_g2a_layout_A_const_10 *lang.Var

var A_arbace_g2a_layout_A_const_11 *lang.Var

var A_arbace_g2a_layout_A_const_12 *lang.Var

var A_arbace_g2a_layout_A_const_13 *lang.Var

var A_arbace_g2a_layout_A_const_14 *lang.Keyword

var A_arbace_g2a_layout_A_const_15 *lang.Var

var A_arbace_g2a_layout_A_const_16 *lang.Keyword

var A_arbace_g2a_layout_A_const_17 *lang.Var

var A_arbace_g2a_layout_A_const_18 *lang.Keyword

var A_arbace_g2a_layout_A_const_19 *lang.Var

var A_arbace_g2a_layout_A_const_20 *lang.Var

var A_arbace_g2a_layout_A_const_21 *lang.Var

var A_arbace_g2a_layout_A_const_22 *lang.Var

var A_arbace_g2a_layout_A_const_23 *lang.Var

var A_arbace_g2a_layout_A_const_24 any

var A_arbace_g2a_layout_A_const_25 *lang.Var

var A_arbace_g2a_layout_A_const_26 *lang.Keyword

var A_arbace_g2a_layout_A_const_27 *lang.Var

var A_arbace_g2a_layout_A_const_28 *lang.Keyword

var A_arbace_g2a_layout_A_const_29 *lang.Var

var A_arbace_g2a_layout_A_const_30 *lang.Var

var A_arbace_g2a_layout_A_const_31 *lang.Var

var A_arbace_g2a_layout_A_const_32 *lang.Var

var A_arbace_g2a_layout_A_const_33 *lang.Var

var A_arbace_g2a_layout_A_const_34 *lang.Var

var A_arbace_g2a_layout_A_const_35 *lang.Keyword

var A_arbace_g2a_layout_A_const_36 *lang.Var

var A_arbace_g2a_layout_A_const_37 *lang.Keyword

var A_arbace_g2a_layout_A_const_38 *lang.Var

var A_arbace_g2a_layout_A_const_39 *lang.Var

var A_arbace_g2a_layout_A_const_40 *lang.Keyword

var A_arbace_g2a_layout_A_const_41 *lang.Var

var A_arbace_g2a_layout_A_const_42 *lang.Keyword

var A_arbace_g2a_layout_A_const_43 *lang.Var

var A_arbace_g2a_layout_A_const_44 *lang.Keyword

var A_arbace_g2a_layout_A_const_45 *lang.Var

var A_arbace_g2a_layout_A_const_46 *lang.Keyword

var A_arbace_g2a_layout_A_const_47 *lang.Var

var A_arbace_g2a_layout_A_const_48 *lang.Keyword

var A_arbace_g2a_layout_A_const_49 *lang.Keyword

var A_arbace_g2a_layout_A_const_50 *lang.Var

var A_arbace_g2a_layout_A_const_51 *lang.Var

var A_arbace_g2a_layout_A_const_52 *lang.Var

var A_arbace_g2a_layout_A_const_53 *lang.Var

var A_arbace_g2a_layout_A_const_54 *lang.Var

var A_arbace_g2a_layout_A_const_55 *lang.Var

var A_arbace_g2a_layout_A_const_56 *lang.Var

var A_arbace_g2a_layout_A_const_57 *lang.Var

var A_arbace_g2a_layout_A_const_58 *lang.Var

var A_arbace_g2a_layout_A_const_59 *lang.Keyword

var A_arbace_g2a_layout_A_const_60 *lang.Keyword

var A_arbace_g2a_layout_A_const_61 *lang.Keyword

var A_arbace_g2a_layout_A_const_62 *lang.Var

var A_arbace_g2a_layout_A_const_63 *lang.Var

var A_arbace_g2a_layout_A_const_64 *lang.Var

var A_arbace_g2a_layout_A_const_65 *lang.Var

var A_arbace_g2a_layout_A_const_66 *lang.Var

var A_arbace_g2a_layout_A_const_67 *lang.Var

var A_arbace_g2a_layout_A_const_68 *lang.Keyword

var A_arbace_g2a_layout_A_const_69 *lang.Var

var A_arbace_g2a_layout_A_const_70 *lang.Var

var A_arbace_g2a_layout_A_const_71 *lang.Var

var A_arbace_g2a_layout_A_const_72 any

var A_arbace_g2a_layout_A_const_73 *lang.Var

var A_arbace_g2a_layout_A_const_74 *lang.Keyword

var A_arbace_g2a_layout_A_const_75 *lang.Var

var A_arbace_g2a_layout_A_const_76 *lang.Var

var A_arbace_g2a_layout_A_const_77 *lang.Var

var A_arbace_g2a_layout_A_const_78 *lang.Var

var A_arbace_g2a_layout_A_const_79 *lang.Var

var A_arbace_g2a_layout_A_const_80 *lang.Var

var A_arbace_g2a_layout_A_const_81 *lang.Var

var A_arbace_g2a_layout_A_const_82 *lang.Var

var A_arbace_g2a_layout_A_const_83 *lang.Var

var A_arbace_g2a_layout_A_const_84 *lang.Keyword

var A_arbace_g2a_layout_A_const_85 *lang.Var

var A_arbace_g2a_layout_A_const_86 *lang.Var

var A_arbace_g2a_layout_A_const_87 *lang.Var

var A_arbace_g2a_layout_A_const_88 *lang.Var

var A_arbace_g2a_layout_A_const_89 *lang.Var

var A_arbace_g2a_layout_A_const_90 *lang.Var

var A_arbace_g2a_layout_A_const_91 *lang.Var

var A_arbace_g2a_layout_A_const_92 *lang.Var

var A_arbace_g2a_layout_A_const_93 *lang.Var

var A_arbace_g2a_layout_A_const_94 *lang.Keyword

var A_arbace_g2a_layout_A_const_95 *lang.Var

var A_arbace_g2a_layout_A_const_96 *lang.Var

var A_arbace_g2a_layout_A_const_97 *lang.Var

var A_arbace_g2a_layout_A_const_98 *lang.Var

var A_arbace_g2a_layout_A_const_99 *lang.Var

var A_arbace_g2a_layout_A_const_100 *lang.Var

var A_arbace_g2a_layout_A_const_101 *lang.Var

var A_arbace_g2a_layout_A_const_102 *lang.Var

var A_arbace_g2a_layout_A_const_103 any

var A_arbace_g2a_layout_A_const_104 *lang.Var

var A_arbace_g2a_layout_A_const_105 *lang.Var

var A_arbace_g2a_layout_A_const_106 *lang.Var

var A_arbace_g2a_layout_A_const_107 *lang.Var

var A_arbace_g2a_layout_A_const_108 *lang.Var

var A_arbace_g2a_layout_A_const_109 *lang.Var

var A_arbace_g2a_layout_A_const_110 *lang.Var

var A_arbace_g2a_layout_A_const_111 any

var A_arbace_g2a_layout_A_const_112 *lang.Var

var A_arbace_g2a_layout_A_const_113 *lang.Var

var A_arbace_g2a_layout_A_init jrt.ClassInit

func A_arbace_g2a_layout_A_Init() { if !A_arbace_g2a_layout_A_init.Done() { A_arbace_g2a_layout_A_init.Run(A_arbace_g2a_layout_A_clinit) } }

func A_arbace_g2a_layout_A_clinit() { A_arbace_g2a_layout_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_g2a_layout_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_g2a_layout_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_layout_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_g2a_layout_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_g2a_layout_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_g2a_layout_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_g2a_layout_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_g2a_layout_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_g2a_layout_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_g2a_layout_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_g2a_layout_A_const_11 = lang.RT_Var_String_String__Var(Lit_11, Lit_16); A_arbace_g2a_layout_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_g2a_layout_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_g2a_layout_A_const_14 = lang.RT_Keyword_String_String__Keyword(Lit_19, Lit_9); A_arbace_g2a_layout_A_const_15 = lang.RT_Var_String_String__Var(Lit_3, Lit_20); A_arbace_g2a_layout_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_21); A_arbace_g2a_layout_A_const_17 = lang.RT_Var_String_String__Var(Lit_11, Lit_22); A_arbace_g2a_layout_A_const_18 = lang.RT_Keyword_String_String__Keyword(Lit_19, Lit_23); A_arbace_g2a_layout_A_const_19 = lang.RT_Var_String_String__Var(Lit_11, Lit_24); A_arbace_g2a_layout_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_g2a_layout_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_g2a_layout_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_g2a_layout_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_g2a_layout_A_const_24 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_g2a_layout_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_g2a_layout_A_const_26 = lang.RT_Keyword_String_String__Keyword(Lit_19, Lit_30); A_arbace_g2a_layout_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_31); A_arbace_g2a_layout_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_g2a_layout_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_g2a_layout_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_g2a_layout_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_g2a_layout_A_const_32 = lang.RT_Var_String_String__Var(Lit_11, Lit_36); A_arbace_g2a_layout_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_g2a_layout_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_g2a_layout_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_39); A_arbace_g2a_layout_A_const_36 = lang.RT_Var_String_String__Var(Lit_11, Lit_40); A_arbace_g2a_layout_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_g2a_layout_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_g2a_layout_A_const_39 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_g2a_layout_A_const_40 = lang.RT_Keyword_String_String__Keyword(Lit_11, Lit_41); A_arbace_g2a_layout_A_const_41 = lang.RT_Var_String_String__Var(Lit_11, Lit_44); A_arbace_g2a_layout_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_g2a_layout_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_g2a_layout_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_g2a_layout_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_g2a_layout_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_g2a_layout_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_g2a_layout_A_const_48 = lang.RT_Keyword_String_String__Keyword(Lit_51, Lit_52); A_arbace_g2a_layout_A_const_49 = lang.RT_Keyword_String_String__Keyword(Lit_51, Lit_53); A_arbace_g2a_layout_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_g2a_layout_A_const_51 = lang.RT_Var_String_String__Var(Lit_11, Lit_55); A_arbace_g2a_layout_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_g2a_layout_A_const_53 = lang.RT_Var_String_String__Var(Lit_11, Lit_57); A_arbace_g2a_layout_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_g2a_layout_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_g2a_layout_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_g2a_layout_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_g2a_layout_A_const_58 = lang.RT_Var_String_String__Var(Lit_11, Lit_61); A_arbace_g2a_layout_A_const_59 = lang.RT_Keyword_String_String__Keyword(Lit_51, Lit_62); A_arbace_g2a_layout_A_const_60 = lang.RT_Keyword_String_String__Keyword(Lit_19, Lit_47); A_arbace_g2a_layout_A_const_61 = lang.RT_Keyword_String_String__Keyword(Lit_51, Lit_47); A_arbace_g2a_layout_A_const_62 = lang.RT_Var_String_String__Var(Lit_11, Lit_63); A_arbace_g2a_layout_A_const_63 = lang.RT_Var_String_String__Var(Lit_11, Lit_64); A_arbace_g2a_layout_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_g2a_layout_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_g2a_layout_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_g2a_layout_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_g2a_layout_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_69); A_arbace_g2a_layout_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_g2a_layout_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_g2a_layout_A_const_71 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_g2a_layout_A_const_72 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref()); A_arbace_g2a_layout_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_g2a_layout_A_const_74 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_g2a_layout_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_g2a_layout_A_const_76 = lang.RT_Var_String_String__Var(Lit_6, Lit_76); A_arbace_g2a_layout_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_g2a_layout_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_g2a_layout_A_const_79 = lang.RT_Var_String_String__Var(Lit_11, Lit_79); A_arbace_g2a_layout_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_g2a_layout_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_g2a_layout_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_g2a_layout_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_g2a_layout_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_79); A_arbace_g2a_layout_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_g2a_layout_A_const_86 = lang.RT_Var_String_String__Var(Lit_3, Lit_85); A_arbace_g2a_layout_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_g2a_layout_A_const_88 = lang.RT_Var_String_String__Var(Lit_3, Lit_87); A_arbace_g2a_layout_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_g2a_layout_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_g2a_layout_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_g2a_layout_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_g2a_layout_A_const_93 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_g2a_layout_A_const_94 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_g2a_layout_A_const_95 = lang.RT_Var_String_String__Var(Lit_11, Lit_94); A_arbace_g2a_layout_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_g2a_layout_A_const_97 = lang.RT_Var_String_String__Var(Lit_11, Lit_96); A_arbace_g2a_layout_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_g2a_layout_A_const_99 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_g2a_layout_A_const_100 = lang.RT_Var_String_String__Var(Lit_6, Lit_99); A_arbace_g2a_layout_A_const_101 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_g2a_layout_A_const_102 = lang.RT_Var_String_String__Var(Lit_6, Lit_101); A_arbace_g2a_layout_A_const_103 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_g2a_layout_A_const_104 = lang.RT_Var_String_String__Var(Lit_11, Lit_102); A_arbace_g2a_layout_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_103); A_arbace_g2a_layout_A_const_106 = lang.RT_Var_String_String__Var(Lit_11, Lit_104); A_arbace_g2a_layout_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_105); A_arbace_g2a_layout_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_106); A_arbace_g2a_layout_A_const_109 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_g2a_layout_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_108); A_arbace_g2a_layout_A_const_111 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_g2a_layout_A_const_112 = lang.RT_Var_String_String__Var(Lit_0, Lit_109); A_arbace_g2a_layout_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_110) }

func A_arbace_g2a_layout_A_New() *A_arbace_g2a_layout_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_layout_A) Ctor() {}

func (t *A_arbace_g2a_layout_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_A_class }

func (t *A_arbace_g2a_layout_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_A); return ok }

func A_arbace_g2a_layout_A_Cast(x any) *A_arbace_g2a_layout_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_A_class)) }; return v }



type A_arbace_g2a_layout_atom_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_atom_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_atom_text_A_fn_class *jrt.Class

var A_arbace_g2a_layout_atom_text_A_init jrt.ClassInit

func A_arbace_g2a_layout_atom_text_A_Init() { if !A_arbace_g2a_layout_atom_text_A_init.Done() { A_arbace_g2a_layout_atom_text_A_init.Run(A_arbace_g2a_layout_atom_text_A_clinit) } }

func A_arbace_g2a_layout_atom_text_A_clinit() { A_arbace_g2a_layout_atom_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_atom_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_atom_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_atom_text_A_class }

func (t *A_arbace_g2a_layout_atom_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_atom_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_atom_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_atom_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_atom_text_A); return ok }

func A_arbace_g2a_layout_atom_text_A_Cast(x any) *A_arbace_g2a_layout_atom_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_atom_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_atom_text_A_class)) }; return v }



type A_arbace_g2a_layout_comment_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_comment_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_comment_text_A_fn_class *jrt.Class

var A_arbace_g2a_layout_comment_text_A_init jrt.ClassInit

func A_arbace_g2a_layout_comment_text_A_Init() { if !A_arbace_g2a_layout_comment_text_A_init.Done() { A_arbace_g2a_layout_comment_text_A_init.Run(A_arbace_g2a_layout_comment_text_A_clinit) } }

func A_arbace_g2a_layout_comment_text_A_clinit() { A_arbace_g2a_layout_comment_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_comment_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_comment_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_comment_text_A_class }

func (t *A_arbace_g2a_layout_comment_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_comment_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_comment_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_comment_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_comment_text_A); return ok }

func A_arbace_g2a_layout_comment_text_A_Cast(x any) *A_arbace_g2a_layout_comment_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_comment_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_comment_text_A_class)) }; return v }



type A_arbace_g2a_layout_deref_form_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_deref_form_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_deref_form_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_layout_deref_form_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_layout_deref_form_QMARK__A_Init() { if !A_arbace_g2a_layout_deref_form_QMARK__A_init.Done() { A_arbace_g2a_layout_deref_form_QMARK__A_init.Run(A_arbace_g2a_layout_deref_form_QMARK__A_clinit) } }

func A_arbace_g2a_layout_deref_form_QMARK__A_clinit() { A_arbace_g2a_layout_deref_form_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_deref_form_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_deref_form_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_deref_form_QMARK__A_class }

func (t *A_arbace_g2a_layout_deref_form_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_deref_form_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_deref_form_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_deref_form_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_deref_form_QMARK__A); return ok }

func A_arbace_g2a_layout_deref_form_QMARK__A_Cast(x any) *A_arbace_g2a_layout_deref_form_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_deref_form_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_deref_form_QMARK__A_class)) }; return v }



type A_arbace_g2a_layout_eval1123000004_A struct{ jrt.Object }

func A_arbace_g2a_layout_eval1123000004_A_New() *A_arbace_g2a_layout_eval1123000004_A { t := &A_arbace_g2a_layout_eval1123000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_layout_eval1123000004_A) Ctor() {}

func (t *A_arbace_g2a_layout_eval1123000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_eval1123000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_eval1123000004_A_class }

func (t *A_arbace_g2a_layout_eval1123000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_eval1123000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_eval1123000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_eval1123000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_eval1123000004_A); return ok }

func A_arbace_g2a_layout_eval1123000004_A_Cast(x any) *A_arbace_g2a_layout_eval1123000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_eval1123000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_eval1123000004_A_class)) }; return v }



type A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_fn_class *jrt.Class

var A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_init jrt.ClassInit

func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_Init() { if !A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_init.Done() { A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_init.Run(A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_clinit) } }

func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_clinit() { A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_class }

func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A); return ok }

func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_Cast(x any) *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_class)) }; return v }



type A_arbace_g2a_layout_eval1123000008_A struct{ jrt.Object }

func A_arbace_g2a_layout_eval1123000008_A_New() *A_arbace_g2a_layout_eval1123000008_A { t := &A_arbace_g2a_layout_eval1123000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_layout_eval1123000008_A) Ctor() {}

func (t *A_arbace_g2a_layout_eval1123000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_eval1123000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_eval1123000008_A_class }

func (t *A_arbace_g2a_layout_eval1123000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_eval1123000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_eval1123000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_eval1123000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_eval1123000008_A); return ok }

func A_arbace_g2a_layout_eval1123000008_A_Cast(x any) *A_arbace_g2a_layout_eval1123000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_eval1123000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_eval1123000008_A_class)) }; return v }



type A_arbace_g2a_layout_eval1123000008_fn__1123000009_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_fn_class *jrt.Class

var A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_init jrt.ClassInit

func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_Init() { if !A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_init.Done() { A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_init.Run(A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_clinit) } }

func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_clinit() { A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_class }

func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_eval1123000008_fn__1123000009_A); return ok }

func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_Cast(x any) *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_eval1123000008_fn__1123000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_class)) }; return v }



type A_arbace_g2a_layout_form_line_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_form_line_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_form_line_A_fn_class *jrt.Class

var A_arbace_g2a_layout_form_line_A_init jrt.ClassInit

func A_arbace_g2a_layout_form_line_A_Init() { if !A_arbace_g2a_layout_form_line_A_init.Done() { A_arbace_g2a_layout_form_line_A_init.Run(A_arbace_g2a_layout_form_line_A_clinit) } }

func A_arbace_g2a_layout_form_line_A_clinit() { A_arbace_g2a_layout_form_line_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_form_line_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_form_line_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_form_line_A_class }

func (t *A_arbace_g2a_layout_form_line_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_form_line_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_form_line_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_form_line_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_form_line_A); return ok }

func A_arbace_g2a_layout_form_line_A_Cast(x any) *A_arbace_g2a_layout_form_line_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_form_line_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_form_line_A_class)) }; return v }



type A_arbace_g2a_layout_iobj_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_iobj_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_iobj_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_layout_iobj_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_layout_iobj_QMARK__A_Init() { if !A_arbace_g2a_layout_iobj_QMARK__A_init.Done() { A_arbace_g2a_layout_iobj_QMARK__A_init.Run(A_arbace_g2a_layout_iobj_QMARK__A_clinit) } }

func A_arbace_g2a_layout_iobj_QMARK__A_clinit() { A_arbace_g2a_layout_iobj_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_iobj_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_iobj_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_iobj_QMARK__A_class }

func (t *A_arbace_g2a_layout_iobj_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_iobj_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_iobj_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_iobj_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_iobj_QMARK__A); return ok }

func A_arbace_g2a_layout_iobj_QMARK__A_Cast(x any) *A_arbace_g2a_layout_iobj_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_iobj_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_iobj_QMARK__A_class)) }; return v }



type A_arbace_g2a_layout_key_rank_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_key_rank_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_key_rank_A_fn_class *jrt.Class

var A_arbace_g2a_layout_key_rank_A_init jrt.ClassInit

func A_arbace_g2a_layout_key_rank_A_Init() { if !A_arbace_g2a_layout_key_rank_A_init.Done() { A_arbace_g2a_layout_key_rank_A_init.Run(A_arbace_g2a_layout_key_rank_A_clinit) } }

func A_arbace_g2a_layout_key_rank_A_clinit() { A_arbace_g2a_layout_key_rank_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_key_rank_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_key_rank_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_key_rank_A_class }

func (t *A_arbace_g2a_layout_key_rank_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_key_rank_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_key_rank_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_key_rank_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_key_rank_A); return ok }

func A_arbace_g2a_layout_key_rank_A_Cast(x any) *A_arbace_g2a_layout_key_rank_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_key_rank_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_key_rank_A_class)) }; return v }



type A_arbace_g2a_layout_meta_prefix_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_meta_prefix_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_meta_prefix_A_fn_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_A_init jrt.ClassInit

func A_arbace_g2a_layout_meta_prefix_A_Init() { if !A_arbace_g2a_layout_meta_prefix_A_init.Done() { A_arbace_g2a_layout_meta_prefix_A_init.Run(A_arbace_g2a_layout_meta_prefix_A_clinit) } }

func A_arbace_g2a_layout_meta_prefix_A_clinit() { A_arbace_g2a_layout_meta_prefix_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_meta_prefix_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_meta_prefix_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_meta_prefix_A_class }

func (t *A_arbace_g2a_layout_meta_prefix_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_meta_prefix_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_meta_prefix_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_meta_prefix_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_meta_prefix_A); return ok }

func A_arbace_g2a_layout_meta_prefix_A_Cast(x any) *A_arbace_g2a_layout_meta_prefix_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_meta_prefix_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_meta_prefix_A_class)) }; return v }



type A_arbace_g2a_layout_meta_prefix_fn__1123000051_A struct{ jrt.Object; F_pm any }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_fn_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_init jrt.ClassInit

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_Init() { if !A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_init.Done() { A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_init.Run(A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_clinit) } }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_clinit() { A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_class }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_meta_prefix_fn__1123000051_A); return ok }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_Cast(x any) *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_meta_prefix_fn__1123000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_class)) }; return v }



type A_arbace_g2a_layout_meta_prefix_fn__1123000053_A struct{ jrt.Object; F_pm any }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_fn_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_init jrt.ClassInit

func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_Init() { if !A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_init.Done() { A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_init.Run(A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_clinit) } }

func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_clinit() { A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_class }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_meta_prefix_fn__1123000053_A); return ok }

func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_Cast(x any) *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_meta_prefix_fn__1123000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_class)) }; return v }



type A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A struct{ jrt.Object; F_pm any }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_fn_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_init jrt.ClassInit

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_Init() { if !A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_init.Done() { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_init.Run(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_clinit) } }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_clinit() { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A); return ok }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_Cast(x any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_class)) }; return v }



type A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A struct{ jrt.Object; F_s__1123000060, F_pm, F_iter__1123000059 any }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_fn_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_init jrt.ClassInit

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_Init() { if !A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_init.Done() { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_init.Run(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_clinit) } }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_clinit() { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A); return ok }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_Cast(x any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_class)) }; return v }



type A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A struct{ jrt.Object; F_b__1123000062, F_pm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_fn_class *jrt.Class

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_init jrt.ClassInit

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_Init() { if !A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_init.Done() { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_init.Run(A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_clinit) } }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_clinit() { A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_class }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A); return ok }

func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_Cast(x any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_class)) }; return v }



type A_arbace_g2a_layout_note_BANG__A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_note_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_note_BANG__A_fn_class *jrt.Class

var A_arbace_g2a_layout_note_BANG__A_init jrt.ClassInit

func A_arbace_g2a_layout_note_BANG__A_Init() { if !A_arbace_g2a_layout_note_BANG__A_init.Done() { A_arbace_g2a_layout_note_BANG__A_init.Run(A_arbace_g2a_layout_note_BANG__A_clinit) } }

func A_arbace_g2a_layout_note_BANG__A_clinit() { A_arbace_g2a_layout_note_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_note_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_note_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_note_BANG__A_class }

func (t *A_arbace_g2a_layout_note_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_note_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_note_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_note_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_note_BANG__A); return ok }

func A_arbace_g2a_layout_note_BANG__A_Cast(x any) *A_arbace_g2a_layout_note_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_note_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_note_BANG__A_class)) }; return v }



type A_arbace_g2a_layout_prep_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_prep_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_layout_prep_A_fn_class *jrt.Class

var A_arbace_g2a_layout_prep_A_init jrt.ClassInit

func A_arbace_g2a_layout_prep_A_Init() { if !A_arbace_g2a_layout_prep_A_init.Done() { A_arbace_g2a_layout_prep_A_init.Run(A_arbace_g2a_layout_prep_A_clinit) } }

func A_arbace_g2a_layout_prep_A_clinit() { A_arbace_g2a_layout_prep_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_prep_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_prep_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_prep_A_class }

func (t *A_arbace_g2a_layout_prep_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_prep_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_prep_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_prep_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_prep_A); return ok }

func A_arbace_g2a_layout_prep_A_Cast(x any) *A_arbace_g2a_layout_prep_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_prep_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_prep_A_class)) }; return v }



type A_arbace_g2a_layout_prep_fn__1123000020_A struct{ jrt.Object; F_cursor, F_x any; F_lines_QMARK_ bool }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_prep_fn__1123000020_A_fn_class *jrt.Class

var A_arbace_g2a_layout_prep_fn__1123000020_A_init jrt.ClassInit

func A_arbace_g2a_layout_prep_fn__1123000020_A_Init() { if !A_arbace_g2a_layout_prep_fn__1123000020_A_init.Done() { A_arbace_g2a_layout_prep_fn__1123000020_A_init.Run(A_arbace_g2a_layout_prep_fn__1123000020_A_clinit) } }

func A_arbace_g2a_layout_prep_fn__1123000020_A_clinit() { A_arbace_g2a_layout_prep_fn__1123000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_prep_fn__1123000020_A_class }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_prep_fn__1123000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_prep_fn__1123000020_A); return ok }

func A_arbace_g2a_layout_prep_fn__1123000020_A_Cast(x any) *A_arbace_g2a_layout_prep_fn__1123000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_prep_fn__1123000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_prep_fn__1123000020_A_class)) }; return v }



type A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A struct{ jrt.Object; F_l, F_brk, F_cursor, F_c any; F_lines_QMARK_ bool }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_fn_class *jrt.Class

var A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_init jrt.ClassInit

func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_Init() { if !A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_init.Done() { A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_init.Run(A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_clinit) } }

func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_clinit() { A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_class }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A); return ok }

func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_Cast(x any) *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_class)) }; return v }



type A_arbace_g2a_layout_prepare_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_prepare_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_prepare_A_fn_class *jrt.Class

var A_arbace_g2a_layout_prepare_A_init jrt.ClassInit

func A_arbace_g2a_layout_prepare_A_Init() { if !A_arbace_g2a_layout_prepare_A_init.Done() { A_arbace_g2a_layout_prepare_A_init.Run(A_arbace_g2a_layout_prepare_A_clinit) } }

func A_arbace_g2a_layout_prepare_A_clinit() { A_arbace_g2a_layout_prepare_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_prepare_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_prepare_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_prepare_A_class }

func (t *A_arbace_g2a_layout_prepare_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_prepare_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_prepare_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_prepare_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_prepare_A); return ok }

func A_arbace_g2a_layout_prepare_A_Cast(x any) *A_arbace_g2a_layout_prepare_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_prepare_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_prepare_A_class)) }; return v }



type A_arbace_g2a_layout_private_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_private_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_private_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_layout_private_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_layout_private_QMARK__A_Init() { if !A_arbace_g2a_layout_private_QMARK__A_init.Done() { A_arbace_g2a_layout_private_QMARK__A_init.Run(A_arbace_g2a_layout_private_QMARK__A_clinit) } }

func A_arbace_g2a_layout_private_QMARK__A_clinit() { A_arbace_g2a_layout_private_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_private_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_private_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_private_QMARK__A_class }

func (t *A_arbace_g2a_layout_private_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_private_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_private_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_private_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_private_QMARK__A); return ok }

func A_arbace_g2a_layout_private_QMARK__A_Cast(x any) *A_arbace_g2a_layout_private_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_private_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_private_QMARK__A_class)) }; return v }



type A_arbace_g2a_layout_public_meta_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_public_meta_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_public_meta_A_fn_class *jrt.Class

var A_arbace_g2a_layout_public_meta_A_init jrt.ClassInit

func A_arbace_g2a_layout_public_meta_A_Init() { if !A_arbace_g2a_layout_public_meta_A_init.Done() { A_arbace_g2a_layout_public_meta_A_init.Run(A_arbace_g2a_layout_public_meta_A_clinit) } }

func A_arbace_g2a_layout_public_meta_A_clinit() { A_arbace_g2a_layout_public_meta_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_public_meta_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_public_meta_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_public_meta_A_class }

func (t *A_arbace_g2a_layout_public_meta_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_public_meta_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_public_meta_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_public_meta_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_public_meta_A); return ok }

func A_arbace_g2a_layout_public_meta_A_Cast(x any) *A_arbace_g2a_layout_public_meta_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_public_meta_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_public_meta_A_class)) }; return v }



type A_arbace_g2a_layout_public_meta_fn__1123000042_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_public_meta_fn__1123000042_A_fn_class *jrt.Class

var A_arbace_g2a_layout_public_meta_fn__1123000042_A_init jrt.ClassInit

func A_arbace_g2a_layout_public_meta_fn__1123000042_A_Init() { if !A_arbace_g2a_layout_public_meta_fn__1123000042_A_init.Done() { A_arbace_g2a_layout_public_meta_fn__1123000042_A_init.Run(A_arbace_g2a_layout_public_meta_fn__1123000042_A_clinit) } }

func A_arbace_g2a_layout_public_meta_fn__1123000042_A_clinit() { A_arbace_g2a_layout_public_meta_fn__1123000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_public_meta_fn__1123000042_A_class }

func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_public_meta_fn__1123000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_public_meta_fn__1123000042_A); return ok }

func A_arbace_g2a_layout_public_meta_fn__1123000042_A_Cast(x any) *A_arbace_g2a_layout_public_meta_fn__1123000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_public_meta_fn__1123000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_public_meta_fn__1123000042_A_class)) }; return v }



type A_arbace_g2a_layout_sort_keys_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_sort_keys_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_sort_keys_A_fn_class *jrt.Class

var A_arbace_g2a_layout_sort_keys_A_init jrt.ClassInit

func A_arbace_g2a_layout_sort_keys_A_Init() { if !A_arbace_g2a_layout_sort_keys_A_init.Done() { A_arbace_g2a_layout_sort_keys_A_init.Run(A_arbace_g2a_layout_sort_keys_A_clinit) } }

func A_arbace_g2a_layout_sort_keys_A_clinit() { A_arbace_g2a_layout_sort_keys_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_sort_keys_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_sort_keys_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_sort_keys_A_class }

func (t *A_arbace_g2a_layout_sort_keys_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_sort_keys_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_sort_keys_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_sort_keys_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_sort_keys_A); return ok }

func A_arbace_g2a_layout_sort_keys_A_Cast(x any) *A_arbace_g2a_layout_sort_keys_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_sort_keys_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_sort_keys_A_class)) }; return v }



type A_arbace_g2a_layout_sort_keys_fn__1123000038_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_sort_keys_fn__1123000038_A_fn_class *jrt.Class

var A_arbace_g2a_layout_sort_keys_fn__1123000038_A_init jrt.ClassInit

func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_Init() { if !A_arbace_g2a_layout_sort_keys_fn__1123000038_A_init.Done() { A_arbace_g2a_layout_sort_keys_fn__1123000038_A_init.Run(A_arbace_g2a_layout_sort_keys_fn__1123000038_A_clinit) } }

func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_clinit() { A_arbace_g2a_layout_sort_keys_fn__1123000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_146, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_sort_keys_fn__1123000038_A_class }

func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_sort_keys_fn__1123000038_A); return ok }

func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_Cast(x any) *A_arbace_g2a_layout_sort_keys_fn__1123000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_sort_keys_fn__1123000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_sort_keys_fn__1123000038_A_class)) }; return v }



type A_arbace_g2a_layout_text_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_text_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_text_A_fn_class *jrt.Class

var A_arbace_g2a_layout_text_A_init jrt.ClassInit

func A_arbace_g2a_layout_text_A_Init() { if !A_arbace_g2a_layout_text_A_init.Done() { A_arbace_g2a_layout_text_A_init.Run(A_arbace_g2a_layout_text_A_clinit) } }

func A_arbace_g2a_layout_text_A_clinit() { A_arbace_g2a_layout_text_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_text_A_class }

func (t *A_arbace_g2a_layout_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_text_A); return ok }

func A_arbace_g2a_layout_text_A_Cast(x any) *A_arbace_g2a_layout_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_text_A_class)) }; return v }



type A_arbace_g2a_layout_text_iter__1123000071__1123000075_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_fn_class *jrt.Class

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_init jrt.ClassInit

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_Init() { if !A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_init.Done() { A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_init.Run(A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_clinit) } }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_clinit() { A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_A); return ok }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_Cast(x any) *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_class)) }; return v }



type A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A struct{ jrt.Object; F_s__1123000072, F_iter__1123000071 any }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_fn_class *jrt.Class

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_init jrt.ClassInit

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_Init() { if !A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_init.Done() { A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_init.Run(A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_clinit) } }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_clinit() { A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A); return ok }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_Cast(x any) *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_class)) }; return v }



type A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A struct{ jrt.Object; F_b__1123000074 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_fn_class *jrt.Class

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_init jrt.ClassInit

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_Init() { if !A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_init.Done() { A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_init.Run(A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_clinit) } }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_clinit() { A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_class }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A); return ok }

func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_Cast(x any) *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_class)) }; return v }



type A_arbace_g2a_layout_write_file_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_write_file_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_layout_write_file_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_file_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_file_A_Init() { if !A_arbace_g2a_layout_write_file_A_init.Done() { A_arbace_g2a_layout_write_file_A_init.Run(A_arbace_g2a_layout_write_file_A_clinit) } }

func A_arbace_g2a_layout_write_file_A_clinit() { A_arbace_g2a_layout_write_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_file_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_file_A_class }

func (t *A_arbace_g2a_layout_write_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_file_A); return ok }

func A_arbace_g2a_layout_write_file_A_Cast(x any) *A_arbace_g2a_layout_write_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_file_A_class)) }; return v }



type A_arbace_g2a_layout_write_file_emit__1123000093_A struct{ jrt.Object; F_newline_to_BANG_, F_sb, F_code_QMARK_, F_depth any }

func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_write_file_emit__1123000093_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_file_emit__1123000093_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_file_emit__1123000093_A_Init() { if !A_arbace_g2a_layout_write_file_emit__1123000093_A_init.Done() { A_arbace_g2a_layout_write_file_emit__1123000093_A_init.Run(A_arbace_g2a_layout_write_file_emit__1123000093_A_clinit) } }

func A_arbace_g2a_layout_write_file_emit__1123000093_A_clinit() { A_arbace_g2a_layout_write_file_emit__1123000093_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_file_emit__1123000093_A_class }

func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_file_emit__1123000093_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_file_emit__1123000093_A); return ok }

func A_arbace_g2a_layout_write_file_emit__1123000093_A_Cast(x any) *A_arbace_g2a_layout_write_file_emit__1123000093_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_file_emit__1123000093_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_file_emit__1123000093_A_class)) }; return v }



type A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A struct{ jrt.Object; F_sb, F_code_QMARK_, F_line, F_comments, F_depth any }

func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_Init() { if !A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_init.Done() { A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_init.Run(A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_clinit) } }

func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_clinit() { A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_class }

func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A); return ok }

func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_Cast(x any) *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_class)) }; return v }



type A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A struct{ jrt.Object; F_sb, F_code_QMARK_, F_line, F_flush_comments_BANG_, F_depth any }

func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_Init() { if !A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_init.Done() { A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_init.Run(A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_clinit) } }

func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_clinit() { A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_165, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_class }

func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A); return ok }

func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_Cast(x any) *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_class)) }; return v }



type A_arbace_g2a_layout_write_package_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_write_package_A) Is_Compiler_AOTF3() {}

var A_arbace_g2a_layout_write_package_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_package_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_package_A_Init() { if !A_arbace_g2a_layout_write_package_A_init.Done() { A_arbace_g2a_layout_write_package_A_init.Run(A_arbace_g2a_layout_write_package_A_clinit) } }

func A_arbace_g2a_layout_write_package_A_clinit() { A_arbace_g2a_layout_write_package_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_package_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_package_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_package_A_class }

func (t *A_arbace_g2a_layout_write_package_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_package_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_package_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_package_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_package_A); return ok }

func A_arbace_g2a_layout_write_package_A_Cast(x any) *A_arbace_g2a_layout_write_package_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_package_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_package_A_class)) }; return v }



type A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_Init() { if !A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_init.Done() { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_init.Run(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_clinit) } }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_clinit() { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A); return ok }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_Cast(x any) *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_class)) }; return v }



type A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A struct{ jrt.Object; F_s__1123000114, F_iter__1123000113 any }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_Init() { if !A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_init.Done() { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_init.Run(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_clinit) } }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_clinit() { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A); return ok }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_Cast(x any) *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_class)) }; return v }



type A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A struct{ jrt.Object; F_b__1123000116 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_Init() { if !A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_init.Done() { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_init.Run(A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_clinit) } }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_clinit() { A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_class }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A); return ok }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_Cast(x any) *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_class)) }; return v }



type A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A struct{ jrt.Object }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_Init() { if !A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_init.Done() { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_init.Run(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_clinit) } }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_clinit() { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A); return ok }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_Cast(x any) *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_class)) }; return v }



type A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A struct{ jrt.Object; F_iter__1123000129, F_s__1123000130 any }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_Init() { if !A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_init.Done() { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_init.Run(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_clinit) } }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_clinit() { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A); return ok }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_Cast(x any) *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_class)) }; return v }



type A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A struct{ jrt.Object; F_size__1927001038__auto__ int32; F_b__1123000132, F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_fn_class *jrt.Class

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_init jrt.ClassInit

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_Init() { if !A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_init.Done() { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_init.Run(A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_clinit) } }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_clinit() { A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_175, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_class }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A); return ok }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_Cast(x any) *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_class)) }; return v }
