//line aot_arbace_g2a_layout.ae:1
package aot_arbace_g2a_layout

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_New() *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_layout_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_3, A_arbace_g2a_layout_A_const_4); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_New() *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_eval1123000008_fn__1123000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_layout_eval1123000008_fn__1123000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_9), A_arbace_g2a_layout_A_const_7.GetRawRoot__O(), A_arbace_g2a_layout_A_const_8) }















func A_arbace_g2a_layout_private_QMARK__A_New() *A_arbace_g2a_layout_private_QMARK__A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_private_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_g2a_layout_private_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_g2a_layout_private_QMARK__A) Invoke_O_O__O(self, k__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_10.GetRawRoot__O()).Invoke_O__O(k__0); if jrt.A2g_Truth(and__1927000168__auto____2) { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_g2a_layout_A_const_11.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_layout_A_const_12.GetRawRoot__O()).Invoke_O__O(k__0))).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_layout_iobj_QMARK__A_New() *A_arbace_g2a_layout_iobj_QMARK__A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_iobj_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_g2a_layout_iobj_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_g2a_layout_iobj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.IObj_InstanceOf(x__0)).Ref() }

func A_arbace_g2a_layout_deref_form_QMARK__A_New() *A_arbace_g2a_layout_deref_form_QMARK__A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_deref_form_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_g2a_layout_deref_form_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_g2a_layout_deref_form_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp1 *lang.Keyword = A_arbace_g2a_layout_A_const_14; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_g2a_layout_form_line_A_New() *A_arbace_g2a_layout_form_line_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_form_line_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_g2a_layout_form_line_A) Ctor() {}
//line :23:1
func (t *A_arbace_g2a_layout_form_line_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0)) {
		return A_arbace_g2a_layout_A_const_16.Invoke_O__O(x__0) } else {
//line :26:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp1 *lang.Keyword = A_arbace_g2a_layout_A_const_18; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else {
//line :26:1
					return nil
				}
		}
}



func A_arbace_g2a_layout_note_BANG__A_New() *A_arbace_g2a_layout_note_BANG__A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_note_BANG__A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_g2a_layout_note_BANG__A) Ctor() {}
//line :33:1
func (t *A_arbace_g2a_layout_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { if jrt.A2g_Truth(A_arbace_g2a_layout_A_const_19.Get__O()) { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_20.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_g2a_layout_A_const_19.Get__O(), A_arbace_g2a_layout_A_const_21.GetRawRoot__O(), k__0, lang.IFn_Cast(A_arbace_g2a_layout_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_23.GetRawRoot__O(), A_arbace_g2a_layout_A_const_24)) } else { return nil } }



func A_arbace_g2a_layout_prep_A_New() *A_arbace_g2a_layout_prep_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_prep_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_g2a_layout_prep_A) Ctor() {}
//line :37:1
func (t *A_arbace_g2a_layout_prep_A) Invoke_O_O_O__O(self, x__0, cursor__1 any) any {


	var tmp1 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)
	if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0) }
//line :40:1
	if jrt.A2g_Truth(tmp1) {

		var tmp2 *lang.Keyword = A_arbace_g2a_layout_A_const_26; if jrt.A2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0))) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { var lines_QMARK___3 bool = lang.Util_Equiv_O_O__Z(A_arbace_g2a_layout_A_const_27.Get__O(), A_arbace_g2a_layout_A_const_28); var m__4 any = lang.RT_Meta_O__IPersistentMap(x__0); var vec__1123000017__5 any; var tmp3 any = A_arbace_g2a_layout_prep_fn__1123000020_A_New_O_O_Z(cursor__1, x__0, lines_QMARK___3); var tmp4 *jrt.Class
			var fncls__2 /*line :42:1*/*jrt.Class = A_arbace_g2a_layout_prep_fn__1123000020_A_fn_class




			if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_g2a_layout_prep_fn__1123000020_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }; vec__1123000017__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :42:1
			var kids__6 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(0), nil); var cursor__7 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(1), nil); var breaks__8 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(2), nil); var apos__9 any = lang.RT_Nth_O_I_O__O(vec__1123000017__5, lang.RT_IntCast_J__I(3), nil); var x_SINGLEQUOTE___10 any



























			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)) { x_SINGLEQUOTE___10 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_47.GetRawRoot__O(), kids__6) } else { x_SINGLEQUOTE___10 = kids__6 }
//line :42:1
			var m__11 any; var G__1123000028__11_ any = m__4; var G__1123000028__12_ any; var tmp5 any
			var and__1927000168__auto____12 bool = lines_QMARK___3




























			if and__1927000168__auto____12 { tmp5 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(breaks__8) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12).Ref() }
//line :71:1
			if jrt.A2g_Truth(tmp5) {
				G__1123000028__12_ = lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(G__1123000028__11_, A_arbace_g2a_layout_A_const_48, breaks__8) } else {
//line :71:1
					G__1123000028__12_ = G__1123000028__11_ }; var tmp6 any; var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z(A_arbace_g2a_layout_A_const_27.Get__O(), A_arbace_g2a_layout_A_const_46)

			if and__1927000168__auto____13 { tmp6 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(apos__9) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____13).Ref() }
//line :71:1
			if jrt.A2g_Truth(tmp6) {

				m__11 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(G__1123000028__12_, A_arbace_g2a_layout_A_const_49, apos__9) } else {
//line :71:1
					m__11 = G__1123000028__12_ }
//line :42:1
			return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_layout_A_const_50.GetRawRoot__O()).Invoke_O_O__O(x_SINGLEQUOTE___10, m__11), cursor__7) } } else {
//line :40:1
				if A_arbace_g2a_layout_A_const_35 != nil { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { return nil
				}
			}
}



func A_arbace_g2a_layout_prep_fn__1123000020_A_New_O_O_Z(p0, p1 any, p2 bool) *A_arbace_g2a_layout_prep_fn__1123000020_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_prep_fn__1123000020_A{}; t.Ctor_O_O_Z(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) Ctor_O_O_Z(c__cursor, c__x any, c__lines_QMARK_ bool) { t.F_cursor = c__cursor; t.F_x = c__x; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :47:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var xs__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_x; t.F_x = nil; tmp2 = t_; xs__2 = tmp1.Invoke_O__O(tmp2); var cursor__3 any; var t__2 any = t.F_cursor; t.F_cursor = nil; cursor__3 = t__2; var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); var breaks__5 any; lang.PersistentVector_Init(); breaks__5 = lang.PersistentVector_EMPTY.Ref(); var apos__6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_30.GetRawRoot__O()).Invoke__O(); L1: for { var temp__1927000408__auto____7 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(xs__2)
										if jrt.A2g_Truth(temp__1927000408__auto____7) { var c__8 any = temp__1927000408__auto____7; var l__9 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_32.GetRawRoot__O()).Invoke_O__O(c__8); var cursor0__10 any = cursor__3; var brk__11 any
											var and__1927000168__auto____11 any = l__9

		if jrt.A2g_Truth(and__1927000168__auto____11) { brk__11 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(l__9, cursor__3)).Ref() } else { brk__11 = and__1927000168__auto____11 }
//line :48:1
		var c__12 any



		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__8)) {
			c__12 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(c__8, A_arbace_g2a_layout_A_const_37, brk__11) } else {
//line :52:1
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(c__8)) {


					var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_34.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_New_O_O_O_O_Z(l__9, brk__11, cursor__3, c__8, t.F_lines_QMARK_); var tmp5 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }; c__12 = tmp3.Invoke_O_O__O(c__8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)) } else {
//line :52:1
						if A_arbace_g2a_layout_A_const_35 != nil { c__12 = c__8 } else { c__12 = nil } } }
//line :48:1
		var cursor__13 any













		if jrt.A2g_Truth(brk__11) { cursor__13 = l__9 } else { cursor__13 = cursor__3 }
//line :48:1
		var vec__1123000021__14 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_36.GetRawRoot__O()).Invoke_O_O__O(c__12, cursor__13); var c__15 any = lang.RT_Nth_O_I_O__O(vec__1123000021__14, lang.RT_IntCast_J__I(0), nil); var cursor__16 any = lang.RT_Nth_O_I_O__O(vec__1123000021__14, lang.RT_IntCast_J__I(1), nil); var tmp6 int64 = lang.Numbers_Inc_J__J(i__1); var tmp7 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(xs__2); var tmp8 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__4, c__15); var tmp9 any; var tmp10 any
		var and__1927000168__auto____17 any = brk__11

















		if jrt.A2g_Truth(and__1927000168__auto____17) { tmp10 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__15) } else { tmp10 = and__1927000168__auto____17 }; if jrt.A2g_Truth(tmp10) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_7.GetRawRoot__O()); var tmp12 any; if lang.Util_Equiv_O_O__Z(l__9, lang.Numbers_Inc_O__Number(cursor0__10)) { tmp12 = jrt.Long_ValueOf_J__Long(i__1).Ref() } else { tmp12 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long(i__1).Ref(), l__9) }; tmp9 = tmp11.Invoke_O_O__O(breaks__5, tmp12) } else { tmp9 = breaks__5 }
//line :64:1
		var tmp13 any = tmp9; var tmp14 any; var tmp15 any; var and__1927000168__auto____17_2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__15)



		if jrt.A2g_Truth(and__1927000168__auto____17_2) { tmp15 = A_arbace_g2a_layout_A_const_44.Invoke_O__O(c__15) } else { tmp15 = and__1927000168__auto____17_2 }; if jrt.A2g_Truth(tmp15) { tmp14 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(apos__6, jrt.Long_ValueOf_J__Long(i__1).Ref(), A_arbace_g2a_layout_A_const_44.Invoke_O__O(c__15)) } else { tmp14 = apos__6 }
//line :64:1
		i__1, xs__2, cursor__3, acc__4, breaks__5, apos__6 = tmp6, tmp7, cursor__16, tmp8, tmp13, tmp14; continue L1 } else {
//line :48:1
			return lang.Tuple_Create_O_O_O_O__IPersistentVector(acc__4, cursor__3, breaks__5, apos__6) } } }; /*line :47:1*/panic("a2g: unreachable") }







func A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_New_O_O_O_O_Z(p0, p1, p2, p3 any, p4 bool) *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A{}; t.Ctor_O_O_O_O_Z(p0, p1, p2, p3, p4); return t }
//line :55:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) Ctor_O_O_O_O_Z(c__l, c__brk, c__cursor, c__c any, c__lines_QMARK_ bool) { t.F_l = c__l; t.F_brk = c__brk; t.F_cursor = c__cursor; t.F_c = c__c; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :55:1
func (t *A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A) Invoke_O_O__O(self, cm__1 any) any { var G__1123000025__2_ any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(cm__1, A_arbace_g2a_layout_A_const_40, t.F_brk); var G__1123000025__3_ any; var tmp1 any; var and__1927000168__auto____3 bool = t.F_lines_QMARK_; if and__1927000168__auto____3 {

	var and__1927000168__auto____4 any = t.F_brk; if jrt.A2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_38.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_c)); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_39.GetRawRoot__O()).Invoke_O__O(t.F_c) } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() }; if /*line :56:1*/ jrt.A2g_Truth(tmp1) {

		G__1123000025__3_ = lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(G__1123000025__2_, A_arbace_g2a_layout_A_const_16, t.F_l) } else {
//line :56:1
			G__1123000025__3_ = G__1123000025__2_ }; var tmp2 any; var and__1927000168__auto____4_2 bool = t.F_lines_QMARK_; if and__1927000168__auto____4_2 {


				var and__1927000168__auto____5 any = t.F_l; if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_38.GetRawRoot__O()).Invoke_O__O(t.F_brk); if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool = lang.Numbers_Lt_O_O__Z(t.F_l, t.F_cursor); if and__1927000168__auto____7 { tmp2 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_c) } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4_2).Ref() }; if /*line :56:1*/ jrt.A2g_Truth(tmp2) { var cm__4 any = G__1123000025__3_



					lang.IFn_Cast(A_arbace_g2a_layout_A_const_41.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_42); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(cm__4, A_arbace_g2a_layout_A_const_16, t.F_l) } else {
//line :56:1
						return G__1123000025__3_ } }




















func A_arbace_g2a_layout_prepare_A_New() *A_arbace_g2a_layout_prepare_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_prepare_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_g2a_layout_prepare_A) Ctor() {}
//line :77:1
func (t *A_arbace_g2a_layout_prepare_A) Invoke_O_O__O(self, forms__0 any) any { { var fs__2 any = forms__0; var cursor__3 any = lang.RT_Box_J__Number(1); var acc__4 any; lang.PersistentVector_Init(); acc__4 = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____5 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(fs__2)



	if jrt.A2g_Truth(temp__1927000408__auto____5) { var f__6 any = temp__1927000408__auto____5; var l__7 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_32.GetRawRoot__O()).Invoke_O__O(f__6); var brk__8 any
		var and__1927000168__auto____8 any = l__7
		if jrt.A2g_Truth(and__1927000168__auto____8) { brk__8 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(l__7, cursor__3)).Ref() } else { brk__8 = and__1927000168__auto____8 }
//line :81:1
		var f__9 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_34.GetRawRoot__O()).Invoke_O_O_O_O__O(f__6, A_arbace_g2a_layout_A_const_33.GetRawRoot__O(), A_arbace_g2a_layout_A_const_40, brk__8); var cursor__10 any



		if jrt.A2g_Truth(brk__8) { cursor__10 = l__7 } else { cursor__10 = cursor__3 }
//line :81:1
		var vec__1123000033__11 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_36.GetRawRoot__O()).Invoke_O_O__O(f__9, cursor__10); var f__12 any = lang.RT_Nth_O_I_O__O(vec__1123000033__11, lang.RT_IntCast_J__I(0), nil); var cursor__13 any = lang.RT_Nth_O_I_O__O(vec__1123000033__11, lang.RT_IntCast_J__I(1), nil)





		fs__2, cursor__3, acc__4 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(fs__2), cursor__13, lang.IFn_Cast(A_arbace_g2a_layout_A_const_7.GetRawRoot__O()).Invoke_O_O__O(acc__4, f__12); continue L1 } else {
//line :81:1
			return acc__4 } } }; /*line :77:1*/panic("a2g: unreachable") }



















func A_arbace_g2a_layout_key_rank_A_New() *A_arbace_g2a_layout_key_rank_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_key_rank_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_g2a_layout_key_rank_A) Ctor() {}
//line :97:1
func (t *A_arbace_g2a_layout_key_rank_A) Invoke_O_O__O(self, k__0 any) any { var i__2 int32 = jrt.List_Cast(A_arbace_g2a_layout_A_const_51.GetRawRoot__O()).IndexOf_O__I(k__0); if

	lang.Numbers_IsNeg_J__Z(int64(i__2)) { return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_g2a_layout_A_const_51.GetRawRoot__O())).Ref() } else { return jrt.Integer_ValueOf_I__Integer(i__2).Ref() } }

func A_arbace_g2a_layout_sort_keys_A_New() *A_arbace_g2a_layout_sort_keys_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_sort_keys_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_g2a_layout_sort_keys_A) Ctor() {}
//line :101:1
func (t *A_arbace_g2a_layout_sort_keys_A) Invoke_O_O__O(self, ks__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_52.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_layout_sort_keys_fn__1123000038_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_g2a_layout_sort_keys_fn__1123000038_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_g2a_layout_sort_keys_fn__1123000038_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ks__0) }
//line :102:1
func A_arbace_g2a_layout_sort_keys_fn__1123000038_A_New() *A_arbace_g2a_layout_sort_keys_fn__1123000038_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_sort_keys_fn__1123000038_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) Ctor() {}
//line :102:1
func (t *A_arbace_g2a_layout_sort_keys_fn__1123000038_A) Invoke_O_O__O(self, k__1 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_layout_A_const_53.GetRawRoot__O()).Invoke_O__O(k__1), lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(k__1)) }

func A_arbace_g2a_layout_public_meta_A_New() *A_arbace_g2a_layout_public_meta_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_public_meta_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_g2a_layout_public_meta_A) Ctor() {}
//line :104:1
func (t *A_arbace_g2a_layout_public_meta_A) Invoke_O_O__O(self, x__0 any) any { var m__2 any; if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(x__0)) { m__2 = lang.RT_Meta_O__IPersistentMap(x__0) } else { m__2 = nil }; var lines_QMARK___3 bool = /*line :104:1*/lang.Util_Equiv_O_O__Z(A_arbace_g2a_layout_A_const_27.Get__O(), A_arbace_g2a_layout_A_const_28); var pm__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_55.GetRawRoot__O()); var tmp2 *lang.PersistentArrayMap;




	lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_57.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_layout_public_meta_fn__1123000042_A_New(); var tmp6 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_layout_public_meta_fn__1123000042_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_g2a_layout_public_meta_fn__1123000042_A_fn_class = fncls__4d; tmp6 = fncls__4d } else { tmp6 = fncls__4 }; pm__4 = tmp1.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)), m__2); var pm__5 any; if lines_QMARK___3 {
		pm__5 = pm__4 } else { var G__1123000047__5_ any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_56.GetRawRoot__O()).Invoke_O_O_O_O__O(pm__4, A_arbace_g2a_layout_A_const_16, A_arbace_g2a_layout_A_const_48, A_arbace_g2a_layout_A_const_59)

			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_60.Invoke_O__O(m__2))) {
				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_33.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_layout_A_const_61; pm__5 = tmp7.Invoke_O_O_O__O(G__1123000047__5_, tmp8, A_arbace_g2a_layout_A_const_60.Invoke_O__O(m__2)) } else {
//line :112:1
					pm__5 = G__1123000047__5_ } }; return pm__5 }
//line :109:1
func A_arbace_g2a_layout_public_meta_fn__1123000042_A_New() *A_arbace_g2a_layout_public_meta_fn__1123000042_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_public_meta_fn__1123000042_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) Ctor() {}
//line :109:1
func (t *A_arbace_g2a_layout_public_meta_fn__1123000042_A) Invoke_O_O__O(self, p__1123000041__1 any) any { var vec__1123000043__2 any = p__1123000041__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1123000043__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1123000043__2, lang.RT_IntCast_J__I(1), nil); var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_58.GetRawRoot__O()).Invoke_O__O(k__3); _ = ___4; if jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(k__3, A_arbace_g2a_layout_A_const_40)).Ref() } }






func A_arbace_g2a_layout_meta_prefix_A_New() *A_arbace_g2a_layout_meta_prefix_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_g2a_layout_meta_prefix_A) Ctor() {}
//line :116:1
func (t *A_arbace_g2a_layout_meta_prefix_A) Invoke_O_O__O(self, x__0 any) any { var pm__2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_62.GetRawRoot__O()).Invoke_O__O(x__0); if

	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(pm__2)) { var ks__3 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_63.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_65.GetRawRoot__O()).Invoke_O__O(pm__2)); var flags__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_64.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_New_O(pm__2); var tmp3 *jrt.Class
		var fncls__5 /*line :118:1*/*jrt.Class = A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_fn_class

		if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; flags__4 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ks__3)
//line :118:1
		var rest_ks__5 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_57.GetRawRoot__O()); var tmp5 any = A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_New_O(pm__2); var tmp6 *jrt.Class
		var fncls__6 /*line :118:1*/*jrt.Class = A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_fn_class


		if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_fn_class = fncls__6d; tmp6 = fncls__6d } else { tmp6 = fncls__6 }; rest_ks__5 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ks__3)
//line :118:1
		var sb__6 any = jrt.StringBuilder_New(); var seq_1123000055__7 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(flags__4); var chunk_1123000056__8 any; var count_1123000057__9 int64 = 0; var i_1123000058__10 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z(i_1123000058__10, count_1123000057__9) { var k__11 any = lang.Indexed_Cast(chunk_1123000056__8).Nth_I__O(lang.RT_IntCast_J__I(i_1123000058__10)); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__11, nil))); seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, i_1123000058__10 = seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, lang.Numbers_Unchecked_inc_J__J(i_1123000058__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_1123000055__7); if jrt.A2g_Truth(temp__1927000414__auto____11) { var seq_1123000055__12 any = temp__1927000414__auto____11; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(seq_1123000055__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_70.GetRawRoot__O()).Invoke_O__O(seq_1123000055__12); seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, i_1123000058__10 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1123000055__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var k__13 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1123000055__12); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__13, nil))); seq_1123000055__7, chunk_1123000056__8, count_1123000057__9, i_1123000058__10 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq_1123000055__12), nil, 0, 0; continue L1 } } }
//line :118:1
			break L1
		}




		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_71.GetRawRoot__O()).Invoke_O__O(rest_ks__5)) { } else { var tmp7 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(rest_ks__5, A_arbace_g2a_layout_A_const_72)

			if and__1927000168__auto____7 { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_74.Invoke_O__O(pm__2)); if jrt.A2g_Truth(and__1927000168__auto____8) { tmp7 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_62.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_74.Invoke_O__O(pm__2))) } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }
//line :124:1
			if jrt.A2g_Truth(tmp7) {


				jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_g2a_layout_A_const_74.Invoke_O__O(pm__2), nil))) } else {
//line :124:1
					if A_arbace_g2a_layout_A_const_35 != nil {




						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_13)
						var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__6); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_76.GetRawRoot__O()); var tmp10 any; var iter__1927001039__auto____7 any; var tmp11 any = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_New_O(pm__2); var tmp12 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_fn_class = fncls__9d; tmp12 = fncls__9d } else { tmp12 = fncls__9 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(rest_ks__5); jrt.NN(tmp8).Append_String__StringBuilder(jrt.String_Cast(tmp9.Invoke_O_O__O(Lit_9, tmp10)))
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_15) } } }
		return lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(sb__6) } else {
//line :118:1
			return nil } }

func A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_New_O(p0 any) *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_fn__1123000051_A{}; t.Ctor_O(p0); return t }
//line :120:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :120:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000051_A) Invoke_O_O__O(self, p1__1123000049_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_66.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1123000049_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_67.GetRawRoot__O()).Invoke_O_O__O(p1__1123000049_SHARP___1, A_arbace_g2a_layout_A_const_68) } else { return and__1927000168__auto____2 } }
func A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_New_O(p0 any) *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_fn__1123000053_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :121:1
func (t *A_arbace_g2a_layout_meta_prefix_fn__1123000053_A) Invoke_O_O__O(self, p1__1123000050_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_66.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1123000050_SHARP___1)); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_67.GetRawRoot__O()).Invoke_O_O__O(p1__1123000050_SHARP___1, A_arbace_g2a_layout_A_const_68) } else { return and__1927000168__auto____2 } }








func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_New_O(p0 any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A{}; t.Ctor_O(p0); return t }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A) Invoke_O_O__O(self, s__1123000060__1 any) any { var tmp1 any = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_New_O_O_O(s__1123000060__1, t.F_pm, self); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :130:1
func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) Ctor_O_O_O(c__s__1123000060, c__pm, c__iter__1123000059 any) { t.F_s__1123000060 = c__s__1123000060; t.F_pm = c__pm; t.F_iter__1123000059 = c__iter__1123000059 }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A) Invoke_O__O(self any) any { { var s__1123000060__1 any; var t_ any = t.F_s__1123000060; t.F_s__1123000060 = nil; s__1123000060__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1123000060__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000060__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(s__1123000060__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_70.GetRawRoot__O()).Invoke_O__O(s__1123000060__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000062__6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_New_O_O_I_O(b__1123000062__6, t.F_pm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1123000059); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000062__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1123000060__3))) } else { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000062__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1123000060__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1123000059); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, k__4, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(k__4)))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(s__1123000060__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :130:1
func A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) Ctor_O_O_I_O(c__b__1123000062, c__pm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1123000062 = c__b__1123000062; t.F_pm = c__pm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :130:1
func (t *A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A) Invoke_O__O(self any) any { { var i__1123000061__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000061__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000061__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_78.GetRawRoot__O()); var tmp3 any = t.F_b__1123000062; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, k__2, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_pm).Invoke_O__O(k__2)))).Ref()); i__1123000061__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000061__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_g2a_layout_atom_text_A_New() *A_arbace_g2a_layout_atom_text_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_atom_text_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_g2a_layout_atom_text_A) Ctor() {}
//line :134:1
func (t *A_arbace_g2a_layout_atom_text_A) Invoke_O_O__O(self, x__0 any) any {
	if lang.Util_Identical_O_O__Z(x__0, nil) { return Lit_1 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0)) {

		return A_arbace_g2a_layout_A_const_84.Invoke_O__O(x__0) } else {
//line :135:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_73.GetRawRoot__O()).Invoke_O__O(x__0)) {


				return lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_10.GetRawRoot__O()).Invoke_O__O(x__0)) {



						return lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_85.GetRawRoot__O()).Invoke_O__O(x__0)) {




								return lang.IFn_Cast(A_arbace_g2a_layout_A_const_86.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
									if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_87.GetRawRoot__O()).Invoke_O__O(x__0)) {





										return lang.IFn_Cast(A_arbace_g2a_layout_A_const_88.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_O__I(x__0)).Ref()) } else {
//line :135:1
											if lang.BigInt_InstanceOf(x__0) {






												return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :135:1
													if jrt.BigInteger_InstanceOf(x__0) {







														return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :135:1
															if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_89.GetRawRoot__O()).Invoke_O__O(x__0)) {








																return lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
																	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_90.GetRawRoot__O()).Invoke_O__O(x__0)) {









																		return lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
																			if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D(x__0)











																				if jrt.Double_IsNaN_D__Z(d__2) { return Lit_3 } else { if jrt.Double_IsInfinite_D__Z(d__2) {
																					if lang.Numbers_IsPos_D__Z(d__2) { return Lit_4 } else { return Lit_5 } } else {
//line :147:1
																						if A_arbace_g2a_layout_A_const_35 != nil {

																							return lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :147:1
																								return nil } } } } else {
//line :135:1
																									if jrt.BigDecimal_InstanceOf(x__0) {














																										return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :135:1
																											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_91.GetRawRoot__O()).Invoke_O__O(x__0)) {















																												return lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :135:1
																													if A_arbace_g2a_layout_A_const_35 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_layout_A_const_92.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_7, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_93.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_layout_A_const_94, x__0)))))) } else { return nil
																													}
																												}
																										}
																								}
																		}
																}
														}
												}
										}
								}
						}
				}
		}
	}
}



func A_arbace_g2a_layout_text_A_New() *A_arbace_g2a_layout_text_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_text_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_g2a_layout_text_A) Ctor() {}
//line :154:1
func (t *A_arbace_g2a_layout_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_95.GetRawRoot__O()).Invoke_O__O(x__0); var tmp3 any
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0)) {
		tmp3 = A_arbace_g2a_layout_A_const_84.Invoke_O__O(x__0) } else {
//line :158:1
			var tmp4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)

			if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp5 *lang.Keyword = A_arbace_g2a_layout_A_const_26; tmp4 = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else { tmp4 = and__1927000168__auto____4 }
//line :158:1
			if jrt.A2g_Truth(tmp4) {

				var tmp6 *lang.Keyword = A_arbace_g2a_layout_A_const_26; tmp3 = tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) } else {
//line :158:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_39.GetRawRoot__O()).Invoke_O__O(x__0)) {


						tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_98.GetRawRoot__O()).Invoke_O__O(x__0)))).Ref() } else {
//line :158:1
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__0)) {



								tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_23, nil, Lit_24), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_76.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_g2a_layout_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_79.GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :158:1
									if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_25.GetRawRoot__O()).Invoke_O__O(x__0)) {




										tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_25, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_76.GetRawRoot__O()).Invoke_O_O__O(Lit_9, lang.IFn_Cast(A_arbace_g2a_layout_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_79.GetRawRoot__O(), x__0)), nil)).Ref() } else {
//line :158:1
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_96.GetRawRoot__O()).Invoke_O__O(x__0)) {





												var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil, Lit_28); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_76.GetRawRoot__O()); var tmp9 any; var iter__1927001039__auto____7 any; var tmp10 any = A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_New(); var tmp11 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_fn_class = fncls__12d; tmp11 = fncls__12d } else { tmp11 = fncls__12 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); tmp9 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(x__0); tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O_O__O(Lit_9, tmp9), nil)).Ref() } else {
//line :158:1
													if A_arbace_g2a_layout_A_const_35 != nil {






														tmp3 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_97.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :158:1
															tmp3 = nil } } } } } } }
//line :157:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)).Ref()
}





func A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_New() *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_text_iter__1123000071__1123000075_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) Ctor() {}
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_A) Invoke_O_O__O(self, s__1123000072__1 any) any { var tmp1 any = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_New_O_O(s__1123000072__1, self); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :164:1
func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_New_O_O(p0, p1 any) *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) Ctor_O_O(c__s__1123000072, c__iter__1123000071 any) { t.F_s__1123000072 = c__s__1123000072; t.F_iter__1123000071 = c__iter__1123000071 }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A) Invoke_O__O(self any) any { { var s__1123000072__1 any; var t_ any = t.F_s__1123000072; t.F_s__1123000072 = nil; s__1123000072__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1123000072__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000072__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(s__1123000072__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_70.GetRawRoot__O()).Invoke_O__O(s__1123000072__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000074__6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_New_O_I_O(b__1123000074__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_fn_class = fncls__10d; tmp2 = fncls__10d } else { tmp2 = fncls__10 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1123000071); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000074__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1123000072__3))) } else { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000074__6), nil) } } else { var vec__1123000082__4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1123000072__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1123000082__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1123000082__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1123000071); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(k__5), nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(v__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(s__1123000072__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :164:1
func A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) Ctor_O_I_O(c__b__1123000074 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1123000074 = c__b__1123000074; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :164:1
func (t *A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A) Invoke_O__O(self any) any { { var i__1123000073__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1123000078__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000073__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1123000078__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1123000078__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_78.GetRawRoot__O()); var tmp3 any = t.F_b__1123000074; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(k__3), nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__1123000073__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000073__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }


func A_arbace_g2a_layout_comment_text_A_New() *A_arbace_g2a_layout_comment_text_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_comment_text_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_g2a_layout_comment_text_A) Ctor() {}
//line :167:1
func (t *A_arbace_g2a_layout_comment_text_A) Invoke_O_O__O(self, t__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_100.GetRawRoot__O()).Invoke_O_O__O(t__0, Lit_8)) {
		return lang.IFn_Cast(A_arbace_g2a_layout_A_const_101.GetRawRoot__O()).Invoke_O_O__O(t__0, A_arbace_g2a_layout_A_const_103) } else {
//line :170:1
			if A_arbace_g2a_layout_A_const_35 != nil {

				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_102.GetRawRoot__O()).Invoke_O__O(t__0))).Ref() } else {
//line :170:1
					return nil
				}
		}
}
func A_arbace_g2a_layout_write_file_A_New() *A_arbace_g2a_layout_write_file_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_file_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_g2a_layout_write_file_A) Ctor() {}
//line :174:1
func (t *A_arbace_g2a_layout_write_file_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any { var forms__3 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_104.GetRawRoot__O()).Invoke_O__O(forms__0); var sb__4 any = jrt.StringBuilder_New(); var line__5 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_105.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_111); var code_QMARK___6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_105.GetRawRoot__O()); var tmp2 *jrt.Boolean;





	jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; code_QMARK___6 = tmp1.Invoke_O__O(tmp2.Ref()); var depth__7 any = /*line :174:1*/lang.IFn_Cast(A_arbace_g2a_layout_A_const_105.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout_A_const_24); var flush_comments_BANG___8 any; var tmp3 any = A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, comments__1, depth__7); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_fn_class; if








	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; flush_comments_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var newline_to_BANG___9 any; var tmp5 any = /*line :174:1*/A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_New_O_O_O_O_O(sb__4, code_QMARK___6, line__5, flush_comments_BANG___8, depth__7); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_fn_class; if















	fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; newline_to_BANG___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var emit__10 any; var tmp7 any = /*line :174:1*/A_arbace_g2a_layout_write_file_emit__1123000093_A_New_O_O_O_O(newline_to_BANG___9, sb__4, code_QMARK___6, depth__7); var tmp8 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_g2a_layout_write_file_emit__1123000093_A_fn_class; if























	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_g2a_layout_write_file_emit__1123000093_A_fn_class = fncls__15d; tmp8 = fncls__15d } else { tmp8 = fncls__15 }; emit__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var seq_1123000105__11 any = /*line :174:1*/lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(forms__3); var chunk_1123000106__12 any; var count_1123000107__13 int64 = 0; var i_1123000108__14 int64 = 0; L1: for {












































		if lang.Numbers_Lt_J_J__Z(i_1123000108__14, count_1123000107__13) { var f__15 any = lang.Indexed_Cast(chunk_1123000106__12).Nth_I__O(lang.RT_IntCast_J__I(i_1123000108__14)); var tmp9 *lang.Keyword = A_arbace_g2a_layout_A_const_40
			if jrt.A2g_Truth(tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__15))) {
				lang.IFn_Cast(emit__10).Invoke_O__O(f__15) } else {
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(code_QMARK___6)) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__15) }
//line :219:1
			seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, i_1123000108__14 = seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, lang.Numbers_Unchecked_inc_J__J(i_1123000108__14); continue L1 } else { var temp__1927000414__auto____15 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_1123000105__11); if jrt.A2g_Truth(temp__1927000414__auto____15) { var seq_1123000105__16 any = temp__1927000414__auto____15; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(seq_1123000105__16)) { var c__1927000678__auto____17 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_70.GetRawRoot__O()).Invoke_O__O(seq_1123000105__16); seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, i_1123000108__14 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1123000105__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var f__17 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1123000105__16); var tmp10 *lang.Keyword = A_arbace_g2a_layout_A_const_40
				if jrt.A2g_Truth(tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__17))) {
					lang.IFn_Cast(emit__10).Invoke_O__O(f__17) } else {
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(code_QMARK___6)) { jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__10).Invoke_O__O(f__17) }
//line :219:1
				seq_1123000105__11, chunk_1123000106__12, count_1123000107__13, i_1123000108__14 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq_1123000105__16), nil, 0, 0; continue L1 } } }
//line :174:1
		break L1 }; var last_comment__11 any; if
















































	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(comments__1)) { last_comment__11 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_112.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_layout_A_const_65.GetRawRoot__O()).Invoke_O__O(comments__1)) } else { last_comment__11 = A_arbace_g2a_layout_A_const_24 }; if
	lang.Numbers_Gt_O_O__Z(last_comment__11, lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(line__5)) {
		lang.IFn_Cast(A_arbace_g2a_layout_A_const_108.GetRawRoot__O()).Invoke_O_O__O(depth__7, A_arbace_g2a_layout_A_const_24)
		lang.IFn_Cast(newline_to_BANG___9).Invoke_O__O(last_comment__11) };
	lang.IFn_Cast(flush_comments_BANG___8).Invoke__O();
	jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(Lit_35); return /*line :229:1*/ lang.IFn_Cast(A_arbace_g2a_layout_A_const_54.GetRawRoot__O()).Invoke_O__O(sb__4) }
//line :183:1
func A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :183:1
func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__comments, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_comments = c__comments; t.F_depth = c__depth }
//line :183:1
func (t *A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A) Invoke_O__O(self any) any { var tmp1 any = t.F_comments; var temp__1927000414__auto____1 any = lang.RT_Get_O_O__O(tmp1, lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_line)); if
													jrt.A2g_Truth(temp__1927000414__auto____1) { var cs__2 any = temp__1927000414__auto____1
														if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_code_QMARK_)) {
															var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); return jrt.NN(tmp2).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_76.GetRawRoot__O()).Invoke_O_O__O(Lit_36, lang.IFn_Cast(A_arbace_g2a_layout_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_106.GetRawRoot__O(), cs__2))))).Ref() } else {
																var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp3).Append_O__StringBuilder(lang.IFn_Cast(A_arbace_g2a_layout_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_54.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_layout_A_const_107.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Multiply_J_O__Number(2, lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_depth)), Lit_9)))
																var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); return jrt.NN(tmp4).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_37, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_76.GetRawRoot__O()).Invoke_O_O__O(Lit_38, lang.IFn_Cast(A_arbace_g2a_layout_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_106.GetRawRoot__O(), cs__2))))).Ref() } } else {
//line :184:1
					return nil } }





func A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :190:1
func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__flush_comments_BANG_, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_flush_comments_BANG_ = c__flush_comments_BANG_; t.F_depth = c__depth }
//line :190:1
func (t *A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A) Invoke_O_O__O(self, l__1 any) any { L1: for {
	if lang.Numbers_Lt_O_O__Z(lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_line), l__1) {
		lang.IFn_Cast(t.F_flush_comments_BANG_).Invoke__O()
		var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp1).Append_String__StringBuilder(Lit_35)
		var tmp2 *lang.Volatile = lang.Volatile_Cast(t.F_line); jrt.NN(tmp2).Reset_O__O(lang.Numbers_Inc_O__Number(jrt.NN(lang.Volatile_Cast(t.F_line)).Deref__O()))
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_108.GetRawRoot__O()); var tmp4 any = t.F_code_QMARK_; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())
//line :191:1
		continue L1 }
//line :190:1
	break L1
}




	var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); return jrt.NN(tmp6).Append_O__StringBuilder(lang.IFn_Cast(A_arbace_g2a_layout_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_54.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_layout_A_const_107.GetRawRoot__O()).Invoke_O_O__O(lang.Numbers_Multiply_J_O__Number(2, lang.IFn_Cast(A_arbace_g2a_layout_A_const_6.GetRawRoot__O()).Invoke_O__O(t.F_depth)), Lit_9))).Ref()
}
func A_arbace_g2a_layout_write_file_emit__1123000093_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_g2a_layout_write_file_emit__1123000093_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_file_emit__1123000093_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :198:1
func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) Ctor_O_O_O_O(c__newline_to_BANG_, c__sb, c__code_QMARK_, c__depth any) { t.F_newline_to_BANG_ = c__newline_to_BANG_; t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_depth = c__depth }
//line :198:1
func (t *A_arbace_g2a_layout_write_file_emit__1123000093_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { and__1927000168__auto____2 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1) }; if jrt.A2g_Truth(and__1927000168__auto____2) {
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp1 = A_arbace_g2a_layout_A_const_37.Invoke_O__O(x__1) } else { var tmp2 *lang.Keyword = A_arbace_g2a_layout_A_const_40; tmp1 = tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__1)) } } else {
//line :199:1
			tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {

				var tmp3 lang.IFn = lang.IFn_Cast(t.F_newline_to_BANG_); tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_32.GetRawRoot__O()).Invoke_O__O(x__1)) }
	var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_108.GetRawRoot__O()); var tmp5 any = t.F_code_QMARK_; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; tmp4.Invoke_O_O__O(tmp5, tmp6.Ref())
//line :198:1
	var p__2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_95.GetRawRoot__O()).Invoke_O__O(x__1)





	if jrt.A2g_Truth(p__2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(p__2) }
	var tmp7 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)
	if jrt.A2g_Truth(and__1927000168__auto____2_2) { var tmp8 *lang.Keyword = A_arbace_g2a_layout_A_const_26; tmp7 = tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__1)) } else { tmp7 = and__1927000168__auto____2_2 }
//line :205:1
	if jrt.A2g_Truth(tmp7) {
		var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp10 *lang.Keyword = A_arbace_g2a_layout_A_const_26; return jrt.NN(tmp9).Append_String__StringBuilder(jrt.String_Cast(tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__1)))).Ref() } else {
//line :205:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_39.GetRawRoot__O()).Invoke_O__O(x__1)) {

				var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp11).Append_String__StringBuilder(Lit_22); return lang.IFn_Cast(self).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_98.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :205:1
					var tmp12 any; var or__1927000174__auto____2_2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)


					if jrt.A2g_Truth(or__1927000174__auto____2_2) { tmp12 = or__1927000174__auto____2_2 } else { tmp12 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_25.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :205:1
					if jrt.A2g_Truth(tmp12) {



						var tmp13 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp14 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp14 = Lit_23 } else { tmp14 = Lit_25 }; jrt.NN(tmp13).Append_String__StringBuilder(tmp14)
						var tmp15 *lang.Volatile = lang.Volatile_Cast(t.F_depth); jrt.NN(tmp15).Reset_O__O(lang.Numbers_Inc_O__Number(jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O()))
//line :205:1
						var seq_1123000094__2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_109.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_110.GetRawRoot__O(), x__1)); var chunk_1123000095__3 any; var count_1123000096__4 int64 = 0; var i_1123000097__5 int64 = 0; L1: for {





							if lang.Numbers_Lt_J_J__Z(i_1123000097__5, count_1123000096__4) { var vec__1123000098__6 any = lang.Indexed_Cast(chunk_1123000095__3).Nth_I__O(lang.RT_IntCast_J__I(i_1123000097__5)); var i__7 any = lang.RT_Nth_O_I_O__O(vec__1123000098__6, lang.RT_IntCast_J__I(0), nil); var c__8 any = lang.RT_Nth_O_I_O__O(vec__1123000098__6, lang.RT_IntCast_J__I(1), nil); var tmp16 any; var and__1927000168__auto____9 bool = lang.Numbers_IsPos_O__Z(i__7)
								if and__1927000168__auto____9 {
									var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_38.GetRawRoot__O()); var tmp18 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__8)) { tmp18 = A_arbace_g2a_layout_A_const_37.Invoke_O__O(c__8) } else { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(c__8); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp19 *lang.Keyword = A_arbace_g2a_layout_A_const_40; tmp18 = tmp19.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(c__8)) } else { tmp18 = and__1927000168__auto____10 } }; tmp16 = tmp17.Invoke_O__O(tmp18) } else {
//line :212:1
										tmp16 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____9).Ref() }; if jrt.A2g_Truth(tmp16) {

											var tmp20 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp20).Append_String__StringBuilder(Lit_9) }
								lang.IFn_Cast(self).Invoke_O__O(c__8)
//line :211:1
								seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, i_1123000097__5 = seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, lang.Numbers_Unchecked_inc_J__J(i_1123000097__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(seq_1123000094__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_1123000094__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(seq_1123000094__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_70.GetRawRoot__O()).Invoke_O__O(seq_1123000094__7); seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, i_1123000097__5 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(seq_1123000094__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1123000101__8 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1123000094__7); var i__9 any = lang.RT_Nth_O_I_O__O(vec__1123000101__8, lang.RT_IntCast_J__I(0), nil); var c__10 any = lang.RT_Nth_O_I_O__O(vec__1123000101__8, lang.RT_IntCast_J__I(1), nil); var tmp21 any; var and__1927000168__auto____11 bool = lang.Numbers_IsPos_O__Z(i__9)
									if and__1927000168__auto____11 {
										var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_38.GetRawRoot__O()); var tmp23 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_15.GetRawRoot__O()).Invoke_O__O(c__10)) { tmp23 = A_arbace_g2a_layout_A_const_37.Invoke_O__O(c__10) } else { var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_17.GetRawRoot__O()).Invoke_O__O(c__10); if jrt.A2g_Truth(and__1927000168__auto____12) { var tmp24 *lang.Keyword = A_arbace_g2a_layout_A_const_40; tmp23 = tmp24.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(c__10)) } else { tmp23 = and__1927000168__auto____12 } }; tmp21 = tmp22.Invoke_O__O(tmp23) } else {
//line :212:1
											tmp21 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() }; if jrt.A2g_Truth(tmp21) {

												var tmp25 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp25).Append_String__StringBuilder(Lit_9) }
									lang.IFn_Cast(self).Invoke_O__O(c__10)
//line :211:1
									seq_1123000094__2, chunk_1123000095__3, count_1123000096__4, i_1123000097__5 = lang.IFn_Cast(A_arbace_g2a_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq_1123000094__7), nil, 0, 0; continue L1 } } }
//line :205:1
							break L1
						}









						var tmp26 *lang.Volatile = lang.Volatile_Cast(t.F_depth); jrt.NN(tmp26).Reset_O__O(lang.Numbers_Dec_O__Number(jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O()))
						var tmp27 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp28 *jrt.String; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_13.GetRawRoot__O()).Invoke_O__O(x__1)) { tmp28 = Lit_24 } else { tmp28 = Lit_26 }; return jrt.NN(tmp27).Append_String__StringBuilder(tmp28).Ref() } else {
//line :205:1
							if A_arbace_g2a_layout_A_const_35 != nil {












								var tmp29 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); return jrt.NN(tmp29).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_layout_A_const_97.GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else {
//line :205:1
									return nil
								}
						}
				}
		}
}




















func A_arbace_g2a_layout_write_package_A_New() *A_arbace_g2a_layout_write_package_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_package_A{}; t.Ctor(); return t }
//line :231:1
func (t *A_arbace_g2a_layout_write_package_A) Ctor() {}
//line :231:1
func (t *A_arbace_g2a_layout_write_package_A) Invoke_O_O_O_O__O(self, ns_sym__0, pkg_form__1, loads__2 any) any { var vec__1123000110__4 any = pkg_form__1; var seq__1123000111__5 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(vec__1123000110__4); var first__1123000112__6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1123000111__5); var seq__1123000111__7 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq__1123000111__5); var head__8 any = first__1123000112__6; var first__1123000112__9 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(seq__1123000111__7); var seq__1123000111__10 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_43.GetRawRoot__O()).Invoke_O__O(seq__1123000111__7); var nm__11 any = first__1123000112__9; var opts__12 any = seq__1123000111__10; var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,10,s4:(ns ns35:\n  (:require [arbace.go :as go]))\n\ns1:(ns1: nns3:)\n\nn", []*jrt.Class{jrt.String_class}); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_45.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_layout_A_const_54.GetRawRoot__O(); var tmp4 any; var iter__1927001039__auto____23 any; var tmp5 any = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_New(); var tmp6 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_fn_class; if





	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_fn_class = fncls__18d; tmp6 = fncls__18d } else { tmp6 = fncls__18 }; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____23).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_113.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_layout_A_const_103, opts__12)); var tmp7 any = /*line :235:1*/tmp2.Invoke_O_O__O(tmp3, tmp4); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_45.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_layout_A_const_54.GetRawRoot__O(); var tmp10 any; var iter__1927001039__auto____23_2 any; var tmp11 any = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_New(); var tmp12 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_fn_class; if



	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_fn_class = fncls__21d; tmp12 = fncls__21d } else { tmp12 = fncls__21 }; iter__1927001039__auto____23_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____23_2).Invoke_O__O(loads__2); return /*line :235:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__0, nil, nil, head__8, nil, nm__11, tmp7, nil, tmp8.Invoke_O_O__O(tmp9, tmp10))).Ref() }

func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_New() *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) Ctor() {}
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A) Invoke_O_O__O(self, s__1123000114__1 any) any { var tmp1 any = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_New_O_O(s__1123000114__1, self); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :237:1
func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_New_O_O(p0, p1 any) *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A{}; t.Ctor_O_O(p0, p1); return t }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) Ctor_O_O(c__s__1123000114, c__iter__1123000113 any) { t.F_s__1123000114 = c__s__1123000114; t.F_iter__1123000113 = c__iter__1123000113 }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A) Invoke_O__O(self any) any { { var s__1123000114__1 any; var t_ any = t.F_s__1123000114; t.F_s__1123000114 = nil; s__1123000114__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1123000114__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000114__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(s__1123000114__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_70.GetRawRoot__O()).Invoke_O__O(s__1123000114__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000116__6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_New_O_I_O(b__1123000116__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1123000113); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000116__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1123000114__3))) } else { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000116__6), nil) } } else { var vec__1123000124__4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1123000114__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1123000124__4, lang.RT_IntCast_J__I(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O(vec__1123000124__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1123000113); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(v__6))).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(s__1123000114__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :237:1
func A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) Ctor_O_I_O(c__b__1123000116 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1123000116 = c__b__1123000116; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :237:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A) Invoke_O__O(self any) any { { var i__1123000115__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000115__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1123000120__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000115__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1123000120__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1123000120__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_78.GetRawRoot__O()); var tmp3 any = t.F_b__1123000116; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_43, nil, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_79.GetRawRoot__O()).Invoke_O__O(v__4))).Ref()); i__1123000115__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000115__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_New() *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) Ctor() {}
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A) Invoke_O_O__O(self, s__1123000130__1 any) any { var tmp1 any = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_New_O_O(self, s__1123000130__1); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :239:1
func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_New_O_O(p0, p1 any) *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) Ctor_O_O(c__iter__1123000129, c__s__1123000130 any) { t.F_iter__1123000129 = c__iter__1123000129; t.F_s__1123000130 = c__s__1123000130 }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A) Invoke_O__O(self any) any { { var s__1123000130__1 any; var t_ any = t.F_s__1123000130; t.F_s__1123000130 = nil; s__1123000130__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1123000130__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1123000130__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_layout_A_const_69.GetRawRoot__O()).Invoke_O__O(s__1123000130__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_70.GetRawRoot__O()).Invoke_O__O(s__1123000130__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1123000132__6 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_New_I_O_O(size__1927001038__auto____5, b__1123000132__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1123000129); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000132__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_75.GetRawRoot__O()).Invoke_O__O(s__1123000130__3))) } else { return lang.IFn_Cast(A_arbace_g2a_layout_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_82.GetRawRoot__O()).Invoke_O__O(b__1123000132__6), nil) } } else { var l__4 any = lang.IFn_Cast(A_arbace_g2a_layout_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1123000130__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1123000129); return lang.IFn_Cast(A_arbace_g2a_layout_A_const_81.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_86.GetRawRoot__O()).Invoke_O__O(l__4), nil)).Ref(), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_layout_A_const_83.GetRawRoot__O()).Invoke_O__O(s__1123000130__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :239:1
func A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1123000132, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1123000132 = c__b__1123000132; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :239:1
func (t *A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A) Invoke_O__O(self any) any { { var i__1123000131__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1123000131__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1123000131__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_layout_A_const_78.GetRawRoot__O()); var tmp3 any = t.F_b__1123000132; tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_layout_A_const_86.GetRawRoot__O()).Invoke_O__O(l__2), nil)).Ref()); i__1123000131__1 = lang.Numbers_Unchecked_inc_J__J(i__1123000131__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



































type A_arbace_g2a_layout_A struct{ jrt.Object }

var A_arbace_g2a_layout_A_const_pool *jrt.RefArray

var A_arbace_g2a_layout_A_const_0 *lang.Var

var A_arbace_g2a_layout_A_const_1 *lang.Var

var A_arbace_g2a_layout_A_const_2 any

var A_arbace_g2a_layout_A_const_3 any

var A_arbace_g2a_layout_A_const_4 any

var A_arbace_g2a_layout_A_const_5 *lang.Var

var A_arbace_g2a_layout_A_const_6 *lang.Var

var A_arbace_g2a_layout_A_const_7 *lang.Var

var A_arbace_g2a_layout_A_const_8 any

var A_arbace_g2a_layout_A_const_9 *lang.Var

var A_arbace_g2a_layout_A_const_10 *lang.Var

var A_arbace_g2a_layout_A_const_11 *lang.Var

var A_arbace_g2a_layout_A_const_12 *lang.Var

var A_arbace_g2a_layout_A_const_13 *lang.Var

var A_arbace_g2a_layout_A_const_14 *lang.Keyword

var A_arbace_g2a_layout_A_const_15 *lang.Var

var A_arbace_g2a_layout_A_const_16 *lang.Keyword

var A_arbace_g2a_layout_A_const_17 *lang.Var

var A_arbace_g2a_layout_A_const_18 *lang.Keyword

var A_arbace_g2a_layout_A_const_19 *lang.Var

var A_arbace_g2a_layout_A_const_20 *lang.Var

var A_arbace_g2a_layout_A_const_21 *lang.Var

var A_arbace_g2a_layout_A_const_22 *lang.Var

var A_arbace_g2a_layout_A_const_23 *lang.Var

var A_arbace_g2a_layout_A_const_24 any

var A_arbace_g2a_layout_A_const_25 *lang.Var

var A_arbace_g2a_layout_A_const_26 *lang.Keyword

var A_arbace_g2a_layout_A_const_27 *lang.Var

var A_arbace_g2a_layout_A_const_28 *lang.Keyword

var A_arbace_g2a_layout_A_const_29 *lang.Var

var A_arbace_g2a_layout_A_const_30 *lang.Var

var A_arbace_g2a_layout_A_const_31 *lang.Var

var A_arbace_g2a_layout_A_const_32 *lang.Var

var A_arbace_g2a_layout_A_const_33 *lang.Var

var A_arbace_g2a_layout_A_const_34 *lang.Var

var A_arbace_g2a_layout_A_const_35 *lang.Keyword

var A_arbace_g2a_layout_A_const_36 *lang.Var

var A_arbace_g2a_layout_A_const_37 *lang.Keyword

var A_arbace_g2a_layout_A_const_38 *lang.Var

var A_arbace_g2a_layout_A_const_39 *lang.Var

var A_arbace_g2a_layout_A_const_40 *lang.Keyword

var A_arbace_g2a_layout_A_const_41 *lang.Var

var A_arbace_g2a_layout_A_const_42 *lang.Keyword

var A_arbace_g2a_layout_A_const_43 *lang.Var

var A_arbace_g2a_layout_A_const_44 *lang.Keyword

var A_arbace_g2a_layout_A_const_45 *lang.Var

var A_arbace_g2a_layout_A_const_46 *lang.Keyword

var A_arbace_g2a_layout_A_const_47 *lang.Var

var A_arbace_g2a_layout_A_const_48 *lang.Keyword

var A_arbace_g2a_layout_A_const_49 *lang.Keyword

var A_arbace_g2a_layout_A_const_50 *lang.Var

var A_arbace_g2a_layout_A_const_51 *lang.Var

var A_arbace_g2a_layout_A_const_52 *lang.Var

var A_arbace_g2a_layout_A_const_53 *lang.Var

var A_arbace_g2a_layout_A_const_54 *lang.Var

var A_arbace_g2a_layout_A_const_55 *lang.Var

var A_arbace_g2a_layout_A_const_56 *lang.Var

var A_arbace_g2a_layout_A_const_57 *lang.Var

var A_arbace_g2a_layout_A_const_58 *lang.Var

var A_arbace_g2a_layout_A_const_59 *lang.Keyword

var A_arbace_g2a_layout_A_const_60 *lang.Keyword

var A_arbace_g2a_layout_A_const_61 *lang.Keyword

var A_arbace_g2a_layout_A_const_62 *lang.Var

var A_arbace_g2a_layout_A_const_63 *lang.Var

var A_arbace_g2a_layout_A_const_64 *lang.Var

var A_arbace_g2a_layout_A_const_65 *lang.Var

var A_arbace_g2a_layout_A_const_66 *lang.Var

var A_arbace_g2a_layout_A_const_67 *lang.Var

var A_arbace_g2a_layout_A_const_68 *lang.Keyword

var A_arbace_g2a_layout_A_const_69 *lang.Var

var A_arbace_g2a_layout_A_const_70 *lang.Var

var A_arbace_g2a_layout_A_const_71 *lang.Var

var A_arbace_g2a_layout_A_const_72 any

var A_arbace_g2a_layout_A_const_73 *lang.Var

var A_arbace_g2a_layout_A_const_74 *lang.Keyword

var A_arbace_g2a_layout_A_const_75 *lang.Var

var A_arbace_g2a_layout_A_const_76 *lang.Var

var A_arbace_g2a_layout_A_const_77 *lang.Var

var A_arbace_g2a_layout_A_const_78 *lang.Var

var A_arbace_g2a_layout_A_const_79 *lang.Var

var A_arbace_g2a_layout_A_const_80 *lang.Var

var A_arbace_g2a_layout_A_const_81 *lang.Var

var A_arbace_g2a_layout_A_const_82 *lang.Var

var A_arbace_g2a_layout_A_const_83 *lang.Var

var A_arbace_g2a_layout_A_const_84 *lang.Keyword

var A_arbace_g2a_layout_A_const_85 *lang.Var

var A_arbace_g2a_layout_A_const_86 *lang.Var

var A_arbace_g2a_layout_A_const_87 *lang.Var

var A_arbace_g2a_layout_A_const_88 *lang.Var

var A_arbace_g2a_layout_A_const_89 *lang.Var

var A_arbace_g2a_layout_A_const_90 *lang.Var

var A_arbace_g2a_layout_A_const_91 *lang.Var

var A_arbace_g2a_layout_A_const_92 *lang.Var

var A_arbace_g2a_layout_A_const_93 *lang.Var

var A_arbace_g2a_layout_A_const_94 *lang.Keyword

var A_arbace_g2a_layout_A_const_95 *lang.Var

var A_arbace_g2a_layout_A_const_96 *lang.Var

var A_arbace_g2a_layout_A_const_97 *lang.Var

var A_arbace_g2a_layout_A_const_98 *lang.Var

var A_arbace_g2a_layout_A_const_99 *lang.Var

var A_arbace_g2a_layout_A_const_100 *lang.Var

var A_arbace_g2a_layout_A_const_101 *lang.Var

var A_arbace_g2a_layout_A_const_102 *lang.Var

var A_arbace_g2a_layout_A_const_103 any

var A_arbace_g2a_layout_A_const_104 *lang.Var

var A_arbace_g2a_layout_A_const_105 *lang.Var

var A_arbace_g2a_layout_A_const_106 *lang.Var

var A_arbace_g2a_layout_A_const_107 *lang.Var

var A_arbace_g2a_layout_A_const_108 *lang.Var

var A_arbace_g2a_layout_A_const_109 *lang.Var

var A_arbace_g2a_layout_A_const_110 *lang.Var

var A_arbace_g2a_layout_A_const_111 any

var A_arbace_g2a_layout_A_const_112 *lang.Var

var A_arbace_g2a_layout_A_const_113 *lang.Var

var A_arbace_g2a_layout_A_init jrt.ClassInit

func A_arbace_g2a_layout_A_Init() { if !A_arbace_g2a_layout_A_init.Done() { A_arbace_g2a_layout_A_init.Run(A_arbace_g2a_layout_A_clinit) } }

func A_arbace_g2a_layout_A_clinit() { A_arbace_g2a_layout_A_clinit_p0(); A_arbace_g2a_layout_A_clinit_p1(); A_arbace_g2a_layout_A_clinit_p2(); A_arbace_g2a_layout_A_clinit_p3(); A_arbace_g2a_layout_A_clinit_p4(); A_arbace_g2a_layout_A_clinit_p5(); A_arbace_g2a_layout_A_clinit_p6(); A_arbace_g2a_layout_A_clinit_p7(); A_arbace_g2a_layout_A_clinit_p8(); A_arbace_g2a_layout_A_clinit_p9() }

func A_arbace_g2a_layout_A_clinit_p0() { A_arbace_g2a_layout_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 141); A_arbace_g2a_layout_A_const_0 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[27]); A_arbace_g2a_layout_A_const_1 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[28]); A_arbace_g2a_layout_A_const_2 = A_arbace_g2a_layout_A_const_pool.A[29]; A_arbace_g2a_layout_A_const_3 = A_arbace_g2a_layout_A_const_pool.A[30]; A_arbace_g2a_layout_A_const_4 = A_arbace_g2a_layout_A_const_pool.A[31]; A_arbace_g2a_layout_A_const_5 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[32]); A_arbace_g2a_layout_A_const_6 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[33]); A_arbace_g2a_layout_A_const_7 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[34]); A_arbace_g2a_layout_A_const_8 = A_arbace_g2a_layout_A_const_pool.A[35]; A_arbace_g2a_layout_A_const_9 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[36]); A_arbace_g2a_layout_A_const_10 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[37]); A_arbace_g2a_layout_A_const_11 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[38]) }

func A_arbace_g2a_layout_A_clinit_p1() { A_arbace_g2a_layout_A_const_12 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[39]); A_arbace_g2a_layout_A_const_13 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[40]); A_arbace_g2a_layout_A_const_14 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[41]); A_arbace_g2a_layout_A_const_15 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[42]); A_arbace_g2a_layout_A_const_16 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[43]); A_arbace_g2a_layout_A_const_17 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[44]); A_arbace_g2a_layout_A_const_18 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[45]); A_arbace_g2a_layout_A_const_19 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[46]); A_arbace_g2a_layout_A_const_20 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[47]); A_arbace_g2a_layout_A_const_21 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[48]); A_arbace_g2a_layout_A_const_22 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[49]); A_arbace_g2a_layout_A_const_23 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[50]) }

func A_arbace_g2a_layout_A_clinit_p2() { A_arbace_g2a_layout_A_const_24 = A_arbace_g2a_layout_A_const_pool.A[51]; A_arbace_g2a_layout_A_const_25 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[52]); A_arbace_g2a_layout_A_const_26 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[53]); A_arbace_g2a_layout_A_const_27 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[54]); A_arbace_g2a_layout_A_const_28 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[55]); A_arbace_g2a_layout_A_const_29 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[56]); A_arbace_g2a_layout_A_const_30 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[57]); A_arbace_g2a_layout_A_const_31 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[58]); A_arbace_g2a_layout_A_const_32 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[59]); A_arbace_g2a_layout_A_const_33 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[60]); A_arbace_g2a_layout_A_const_34 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[61]); A_arbace_g2a_layout_A_const_35 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[62]) }

func A_arbace_g2a_layout_A_clinit_p3() { A_arbace_g2a_layout_A_const_36 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[63]); A_arbace_g2a_layout_A_const_37 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[64]); A_arbace_g2a_layout_A_const_38 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[65]); A_arbace_g2a_layout_A_const_39 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[66]); A_arbace_g2a_layout_A_const_40 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[67]); A_arbace_g2a_layout_A_const_41 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[68]); A_arbace_g2a_layout_A_const_42 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[69]); A_arbace_g2a_layout_A_const_43 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[70]); A_arbace_g2a_layout_A_const_44 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[71]); A_arbace_g2a_layout_A_const_45 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[72]); A_arbace_g2a_layout_A_const_46 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[73]); A_arbace_g2a_layout_A_const_47 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[74]) }

func A_arbace_g2a_layout_A_clinit_p4() { A_arbace_g2a_layout_A_const_48 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[75]); A_arbace_g2a_layout_A_const_49 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[76]); A_arbace_g2a_layout_A_const_50 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[77]); A_arbace_g2a_layout_A_const_51 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[78]); A_arbace_g2a_layout_A_const_52 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[79]); A_arbace_g2a_layout_A_const_53 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[80]); A_arbace_g2a_layout_A_const_54 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[81]); A_arbace_g2a_layout_A_const_55 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[82]); A_arbace_g2a_layout_A_const_56 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[83]); A_arbace_g2a_layout_A_const_57 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[84]); A_arbace_g2a_layout_A_const_58 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[85]); A_arbace_g2a_layout_A_const_59 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[86]) }

func A_arbace_g2a_layout_A_clinit_p5() { A_arbace_g2a_layout_A_const_60 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[87]); A_arbace_g2a_layout_A_const_61 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[88]); A_arbace_g2a_layout_A_const_62 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[89]); A_arbace_g2a_layout_A_const_63 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[90]); A_arbace_g2a_layout_A_const_64 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[91]); A_arbace_g2a_layout_A_const_65 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[92]); A_arbace_g2a_layout_A_const_66 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[93]); A_arbace_g2a_layout_A_const_67 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[94]); A_arbace_g2a_layout_A_const_68 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[95]); A_arbace_g2a_layout_A_const_69 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[96]); A_arbace_g2a_layout_A_const_70 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[97]); A_arbace_g2a_layout_A_const_71 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[98]) }

func A_arbace_g2a_layout_A_clinit_p6() { A_arbace_g2a_layout_A_const_72 = A_arbace_g2a_layout_A_const_pool.A[99]; A_arbace_g2a_layout_A_const_73 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[100]); A_arbace_g2a_layout_A_const_74 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[101]); A_arbace_g2a_layout_A_const_75 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[102]); A_arbace_g2a_layout_A_const_76 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[103]); A_arbace_g2a_layout_A_const_77 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[104]); A_arbace_g2a_layout_A_const_78 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[105]); A_arbace_g2a_layout_A_const_79 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[106]); A_arbace_g2a_layout_A_const_80 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[107]); A_arbace_g2a_layout_A_const_81 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[108]); A_arbace_g2a_layout_A_const_82 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[109]); A_arbace_g2a_layout_A_const_83 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[110]) }

func A_arbace_g2a_layout_A_clinit_p7() { A_arbace_g2a_layout_A_const_84 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[111]); A_arbace_g2a_layout_A_const_85 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[112]); A_arbace_g2a_layout_A_const_86 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[113]); A_arbace_g2a_layout_A_const_87 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[114]); A_arbace_g2a_layout_A_const_88 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[115]); A_arbace_g2a_layout_A_const_89 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[116]); A_arbace_g2a_layout_A_const_90 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[117]); A_arbace_g2a_layout_A_const_91 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[118]); A_arbace_g2a_layout_A_const_92 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[119]); A_arbace_g2a_layout_A_const_93 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[120]); A_arbace_g2a_layout_A_const_94 = lang.Keyword_Cast(A_arbace_g2a_layout_A_const_pool.A[121]); A_arbace_g2a_layout_A_const_95 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[122]) }

func A_arbace_g2a_layout_A_clinit_p8() { A_arbace_g2a_layout_A_const_96 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[123]); A_arbace_g2a_layout_A_const_97 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[124]); A_arbace_g2a_layout_A_const_98 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[125]); A_arbace_g2a_layout_A_const_99 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[126]); A_arbace_g2a_layout_A_const_100 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[127]); A_arbace_g2a_layout_A_const_101 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[128]); A_arbace_g2a_layout_A_const_102 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[129]); A_arbace_g2a_layout_A_const_103 = A_arbace_g2a_layout_A_const_pool.A[130]; A_arbace_g2a_layout_A_const_104 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[131]); A_arbace_g2a_layout_A_const_105 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[132]); A_arbace_g2a_layout_A_const_106 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[133]); A_arbace_g2a_layout_A_const_107 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[134]) }

func A_arbace_g2a_layout_A_clinit_p9() { A_arbace_g2a_layout_A_const_108 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[135]); A_arbace_g2a_layout_A_const_109 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[136]); A_arbace_g2a_layout_A_const_110 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[137]); A_arbace_g2a_layout_A_const_111 = A_arbace_g2a_layout_A_const_pool.A[138]; A_arbace_g2a_layout_A_const_112 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[139]); A_arbace_g2a_layout_A_const_113 = lang.Var_Cast(A_arbace_g2a_layout_A_const_pool.A[140]) }

func A_arbace_g2a_layout_A_New() *A_arbace_g2a_layout_A { A_arbace_g2a_layout_A_Init(); t := &A_arbace_g2a_layout_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_layout_A) Ctor() {}

func (t *A_arbace_g2a_layout_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_A_class }

func (t *A_arbace_g2a_layout_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_A); return ok }

func A_arbace_g2a_layout_A_Cast(x any) *A_arbace_g2a_layout_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_A_class)) }; return v }



type A_arbace_g2a_layout_atom_text_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_atom_text_A_fn_class *jrt.Class



type A_arbace_g2a_layout_comment_text_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_comment_text_A_fn_class *jrt.Class



type A_arbace_g2a_layout_deref_form_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_deref_form_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_layout_eval1123000004_A struct{ jrt.Object }

func A_arbace_g2a_layout_eval1123000004_A_New() *A_arbace_g2a_layout_eval1123000004_A { t := &A_arbace_g2a_layout_eval1123000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_layout_eval1123000004_A) Ctor() {}

func (t *A_arbace_g2a_layout_eval1123000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_eval1123000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_eval1123000004_A_class }

func (t *A_arbace_g2a_layout_eval1123000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_eval1123000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_eval1123000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_eval1123000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_eval1123000004_A); return ok }

func A_arbace_g2a_layout_eval1123000004_A_Cast(x any) *A_arbace_g2a_layout_eval1123000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_eval1123000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_eval1123000004_A_class)) }; return v }



type A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_fn_class *jrt.Class



type A_arbace_g2a_layout_eval1123000008_A struct{ jrt.Object }

func A_arbace_g2a_layout_eval1123000008_A_New() *A_arbace_g2a_layout_eval1123000008_A { t := &A_arbace_g2a_layout_eval1123000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_layout_eval1123000008_A) Ctor() {}

func (t *A_arbace_g2a_layout_eval1123000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout_eval1123000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout_eval1123000008_A_class }

func (t *A_arbace_g2a_layout_eval1123000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout_eval1123000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout_eval1123000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout_eval1123000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout_eval1123000008_A); return ok }

func A_arbace_g2a_layout_eval1123000008_A_Cast(x any) *A_arbace_g2a_layout_eval1123000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout_eval1123000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout_eval1123000008_A_class)) }; return v }



type A_arbace_g2a_layout_eval1123000008_fn__1123000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_fn_class *jrt.Class



type A_arbace_g2a_layout_form_line_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_form_line_A_fn_class *jrt.Class



type A_arbace_g2a_layout_iobj_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_iobj_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_layout_key_rank_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_key_rank_A_fn_class *jrt.Class



type A_arbace_g2a_layout_meta_prefix_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_meta_prefix_A_fn_class *jrt.Class



type A_arbace_g2a_layout_meta_prefix_fn__1123000051_A struct{ a2g_header uint64; F_pm any }

var A_arbace_g2a_layout_meta_prefix_fn__1123000051_A_fn_class *jrt.Class



type A_arbace_g2a_layout_meta_prefix_fn__1123000053_A struct{ a2g_header uint64; F_pm any }

var A_arbace_g2a_layout_meta_prefix_fn__1123000053_A_fn_class *jrt.Class



type A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A struct{ a2g_header uint64; F_pm any }

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_A_fn_class *jrt.Class



type A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A struct{ a2g_header uint64; F_s__1123000060, F_pm, F_iter__1123000059 any }

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_A_fn_class *jrt.Class



type A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A struct{ a2g_header uint64; F_b__1123000062, F_pm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_layout_meta_prefix_iter__1123000059__1123000063_fn__1123000064_fn__1123000065_A_fn_class *jrt.Class



type A_arbace_g2a_layout_note_BANG__A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_note_BANG__A_fn_class *jrt.Class



type A_arbace_g2a_layout_prep_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_prep_A_fn_class *jrt.Class



type A_arbace_g2a_layout_prep_fn__1123000020_A struct{ a2g_header uint64; F_cursor, F_x any; F_lines_QMARK_ bool }

var A_arbace_g2a_layout_prep_fn__1123000020_A_fn_class *jrt.Class



type A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A struct{ a2g_header uint64; F_l, F_brk, F_cursor, F_c any; F_lines_QMARK_ bool }

var A_arbace_g2a_layout_prep_fn__1123000020_fn__1123000024_A_fn_class *jrt.Class



type A_arbace_g2a_layout_prepare_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_prepare_A_fn_class *jrt.Class



type A_arbace_g2a_layout_private_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_private_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_layout_public_meta_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_public_meta_A_fn_class *jrt.Class



type A_arbace_g2a_layout_public_meta_fn__1123000042_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_public_meta_fn__1123000042_A_fn_class *jrt.Class



type A_arbace_g2a_layout_sort_keys_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_sort_keys_A_fn_class *jrt.Class



type A_arbace_g2a_layout_sort_keys_fn__1123000038_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_sort_keys_fn__1123000038_A_fn_class *jrt.Class



type A_arbace_g2a_layout_text_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_text_A_fn_class *jrt.Class



type A_arbace_g2a_layout_text_iter__1123000071__1123000075_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_A_fn_class *jrt.Class



type A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A struct{ a2g_header uint64; F_s__1123000072, F_iter__1123000071 any }

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_A_fn_class *jrt.Class



type A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A struct{ a2g_header uint64; F_b__1123000074 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_layout_text_iter__1123000071__1123000075_fn__1123000076_fn__1123000077_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_file_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_write_file_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_file_emit__1123000093_A struct{ a2g_header uint64; F_newline_to_BANG_, F_sb, F_code_QMARK_, F_depth any }

var A_arbace_g2a_layout_write_file_emit__1123000093_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A struct{ a2g_header uint64; F_sb, F_code_QMARK_, F_line, F_comments, F_depth any }

var A_arbace_g2a_layout_write_file_flush_comments_BANG___1123000089_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A struct{ a2g_header uint64; F_sb, F_code_QMARK_, F_line, F_flush_comments_BANG_, F_depth any }

var A_arbace_g2a_layout_write_file_newline_to_BANG___1123000091_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_package_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_write_package_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A struct{ a2g_header uint64; F_s__1123000114, F_iter__1123000113 any }

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A struct{ a2g_header uint64; F_b__1123000116 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_layout_write_package_iter__1123000113__1123000117_fn__1123000118_fn__1123000119_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A struct{ a2g_header uint64 }

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A struct{ a2g_header uint64; F_iter__1123000129, F_s__1123000130 any }

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_A_fn_class *jrt.Class



type A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_b__1123000132, F_c__1927001037__auto__ any }

var A_arbace_g2a_layout_write_package_iter__1123000129__1123000133_fn__1123000134_fn__1123000135_A_fn_class *jrt.Class
