//line aot_arbace_g2a_layout__init.ae:1
package aot_arbace_g2a_layout

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_layout__init_A_Unit0__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_layout__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_layout__init_A_const_1) }
//line :1:1
func A_arbace_g2a_layout__init_A_Unit1__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_layout__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_layout__init_A_Unit2__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_Init(); tmp2 = A_arbace_g2a_layout_eval1123000004_loading__1927001464__auto____1123000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_layout__init_A_Unit3__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_layout__init_A_const_1)).Equals_O__Z(A_arbace_g2a_layout__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_Init(); tmp2 = A_arbace_g2a_layout_eval1123000008_fn__1123000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_layout__init_A_Load__O() any { A_arbace_g2a_layout__init_A_Init(); A_arbace_g2a_layout__init_A_Unit0__O(); A_arbace_g2a_layout__init_A_Unit1__O(); A_arbace_g2a_layout__init_A_Unit2__O(); A_arbace_g2a_layout__init_A_Unit3__O(); A_arbace_g2a_layout__init_A_Unit4__O(); A_arbace_g2a_layout__init_A_Unit5__O(); A_arbace_g2a_layout__init_A_Unit6__O(); A_arbace_g2a_layout__init_A_Unit7__O(); A_arbace_g2a_layout__init_A_Unit8__O(); A_arbace_g2a_layout__init_A_Unit9__O(); A_arbace_g2a_layout__init_A_Unit10__O(); A_arbace_g2a_layout__init_A_Unit11__O(); A_arbace_g2a_layout__init_A_Unit12__O(); A_arbace_g2a_layout__init_A_Unit13__O(); A_arbace_g2a_layout__init_A_Unit14__O(); A_arbace_g2a_layout__init_A_Unit15__O(); A_arbace_g2a_layout__init_A_Unit16__O(); A_arbace_g2a_layout__init_A_Unit17__O(); A_arbace_g2a_layout__init_A_Unit18__O(); A_arbace_g2a_layout__init_A_Unit19__O(); A_arbace_g2a_layout__init_A_Unit20__O(); A_arbace_g2a_layout__init_A_Unit21__O(); A_arbace_g2a_layout__init_A_Unit22__O(); A_arbace_g2a_layout__init_A_Unit23__O(); A_arbace_g2a_layout__init_A_Unit24__O(); return nil }









func A_arbace_g2a_layout__init_A_Unit4__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); jrt.NN(A_arbace_g2a_layout__init_A_const_4).BindRoot_O__V(Lit_19); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_5)); return A_arbace_g2a_layout__init_A_const_4.Ref() }

func A_arbace_g2a_layout__init_A_Unit5__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_6; var tmp2 any = A_arbace_g2a_layout_private_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_private_QMARK__A_Init(); tmp3 = A_arbace_g2a_layout_private_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_7)); return A_arbace_g2a_layout__init_A_const_6.Ref() }

func A_arbace_g2a_layout__init_A_Unit6__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_8; var tmp2 any = A_arbace_g2a_layout_iobj_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_iobj_QMARK__A_Init(); tmp3 = A_arbace_g2a_layout_iobj_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_9)); return A_arbace_g2a_layout__init_A_const_8.Ref() }

func A_arbace_g2a_layout__init_A_Unit7__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_10; var tmp2 any = A_arbace_g2a_layout_deref_form_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_deref_form_QMARK__A_Init(); tmp3 = A_arbace_g2a_layout_deref_form_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_11)); return A_arbace_g2a_layout__init_A_const_10.Ref() }

func A_arbace_g2a_layout__init_A_Unit8__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_12; var tmp2 any = A_arbace_g2a_layout_form_line_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_form_line_A_Init(); tmp3 = A_arbace_g2a_layout_form_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_13)); return A_arbace_g2a_layout__init_A_const_12.Ref() }






func A_arbace_g2a_layout__init_A_Unit9__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); jrt.NN(A_arbace_g2a_layout__init_A_const_14).BindRoot_O__V(A_arbace_g2a_layout__init_A_const_15.Ref()); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_14; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_16)); return jrt.NN(A_arbace_g2a_layout__init_A_const_14).SetDynamic_Z__Var(true).Ref() }
func A_arbace_g2a_layout__init_A_Unit10__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); jrt.NN(A_arbace_g2a_layout__init_A_const_17).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_17; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_18)); return jrt.NN(A_arbace_g2a_layout__init_A_const_17).SetDynamic_Z__Var(true).Ref() }

func A_arbace_g2a_layout__init_A_Unit11__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_19; var tmp2 any = A_arbace_g2a_layout_note_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_note_BANG__A_Init(); tmp3 = A_arbace_g2a_layout_note_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_20)); return A_arbace_g2a_layout__init_A_const_19.Ref() }



func A_arbace_g2a_layout__init_A_Unit12__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_21; var tmp2 any = A_arbace_g2a_layout_prep_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_prep_A_Init(); tmp3 = A_arbace_g2a_layout_prep_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_22)); return A_arbace_g2a_layout__init_A_const_21.Ref() }







































func A_arbace_g2a_layout__init_A_Unit13__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_23; var tmp2 any = A_arbace_g2a_layout_prepare_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_prepare_A_Init(); tmp3 = A_arbace_g2a_layout_prepare_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_24)); return A_arbace_g2a_layout__init_A_const_23.Ref() }














func A_arbace_g2a_layout__init_A_Unit14__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(92, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_25; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_26)); return A_arbace_g2a_layout__init_A_const_25.Ref() }

func A_arbace_g2a_layout__init_A_Unit15__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(94, 1); jrt.NN(A_arbace_g2a_layout__init_A_const_27).BindRoot_O__V(A_arbace_g2a_layout__init_A_const_28); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_27; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_29)); return A_arbace_g2a_layout__init_A_const_27.Ref() }


func A_arbace_g2a_layout__init_A_Unit16__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_30; var tmp2 any = A_arbace_g2a_layout_key_rank_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_key_rank_A_Init(); tmp3 = A_arbace_g2a_layout_key_rank_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_31)); return A_arbace_g2a_layout__init_A_const_30.Ref() }



func A_arbace_g2a_layout__init_A_Unit17__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_32; var tmp2 any = A_arbace_g2a_layout_sort_keys_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_sort_keys_A_Init(); tmp3 = A_arbace_g2a_layout_sort_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_33)); return A_arbace_g2a_layout__init_A_const_32.Ref() }


func A_arbace_g2a_layout__init_A_Unit18__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(104, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_34; var tmp2 any = A_arbace_g2a_layout_public_meta_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_public_meta_A_Init(); tmp3 = A_arbace_g2a_layout_public_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_35)); return A_arbace_g2a_layout__init_A_const_34.Ref() }











func A_arbace_g2a_layout__init_A_Unit19__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(116, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_36; var tmp2 any = A_arbace_g2a_layout_meta_prefix_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_meta_prefix_A_Init(); tmp3 = A_arbace_g2a_layout_meta_prefix_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_37)); return A_arbace_g2a_layout__init_A_const_36.Ref() }

















func A_arbace_g2a_layout__init_A_Unit20__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(134, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_38; var tmp2 any = A_arbace_g2a_layout_atom_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_atom_text_A_Init(); tmp3 = A_arbace_g2a_layout_atom_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_39)); return A_arbace_g2a_layout__init_A_const_38.Ref() }



















func A_arbace_g2a_layout__init_A_Unit21__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_25; var tmp2 any = A_arbace_g2a_layout_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_text_A_Init(); tmp3 = A_arbace_g2a_layout_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_40)); return A_arbace_g2a_layout__init_A_const_25.Ref() }












func A_arbace_g2a_layout__init_A_Unit22__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_41; var tmp2 any = A_arbace_g2a_layout_comment_text_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_comment_text_A_Init(); tmp3 = A_arbace_g2a_layout_comment_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_42)); return A_arbace_g2a_layout__init_A_const_41.Ref() }






func A_arbace_g2a_layout__init_A_Unit23__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(174, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_43; var tmp2 any = A_arbace_g2a_layout_write_file_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_write_file_A_Init(); tmp3 = A_arbace_g2a_layout_write_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_44)); return A_arbace_g2a_layout__init_A_const_43.Ref() }
























































func A_arbace_g2a_layout__init_A_Unit24__O() any { A_arbace_g2a_layout__init_A_Init(); lang.Compiler_AOT_At_I_I__V(231, 1); var tmp1 *lang.Var = A_arbace_g2a_layout__init_A_const_45; var tmp2 any = A_arbace_g2a_layout_write_package_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_layout_write_package_A_Init(); tmp3 = A_arbace_g2a_layout_write_package_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_layout__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_layout__init_A_const_46)); return A_arbace_g2a_layout__init_A_const_45.Ref() }



type A_arbace_g2a_layout__init_A struct{ jrt.Object }

var A_arbace_g2a_layout__init_A_const_0 *lang.Var

var A_arbace_g2a_layout__init_A_const_1 any

var A_arbace_g2a_layout__init_A_const_2 any

var A_arbace_g2a_layout__init_A_const_3 any

var A_arbace_g2a_layout__init_A_const_4 *lang.Var

var A_arbace_g2a_layout__init_A_const_5 any

var A_arbace_g2a_layout__init_A_const_6 *lang.Var

var A_arbace_g2a_layout__init_A_const_7 any

var A_arbace_g2a_layout__init_A_const_8 *lang.Var

var A_arbace_g2a_layout__init_A_const_9 any

var A_arbace_g2a_layout__init_A_const_10 *lang.Var

var A_arbace_g2a_layout__init_A_const_11 any

var A_arbace_g2a_layout__init_A_const_12 *lang.Var

var A_arbace_g2a_layout__init_A_const_13 any

var A_arbace_g2a_layout__init_A_const_14 *lang.Var

var A_arbace_g2a_layout__init_A_const_15 *lang.Keyword

var A_arbace_g2a_layout__init_A_const_16 any

var A_arbace_g2a_layout__init_A_const_17 *lang.Var

var A_arbace_g2a_layout__init_A_const_18 any

var A_arbace_g2a_layout__init_A_const_19 *lang.Var

var A_arbace_g2a_layout__init_A_const_20 any

var A_arbace_g2a_layout__init_A_const_21 *lang.Var

var A_arbace_g2a_layout__init_A_const_22 any

var A_arbace_g2a_layout__init_A_const_23 *lang.Var

var A_arbace_g2a_layout__init_A_const_24 any

var A_arbace_g2a_layout__init_A_const_25 *lang.Var

var A_arbace_g2a_layout__init_A_const_26 any

var A_arbace_g2a_layout__init_A_const_27 *lang.Var

var A_arbace_g2a_layout__init_A_const_28 any

var A_arbace_g2a_layout__init_A_const_29 any

var A_arbace_g2a_layout__init_A_const_30 *lang.Var

var A_arbace_g2a_layout__init_A_const_31 any

var A_arbace_g2a_layout__init_A_const_32 *lang.Var

var A_arbace_g2a_layout__init_A_const_33 any

var A_arbace_g2a_layout__init_A_const_34 *lang.Var

var A_arbace_g2a_layout__init_A_const_35 any

var A_arbace_g2a_layout__init_A_const_36 *lang.Var

var A_arbace_g2a_layout__init_A_const_37 any

var A_arbace_g2a_layout__init_A_const_38 *lang.Var

var A_arbace_g2a_layout__init_A_const_39 any

var A_arbace_g2a_layout__init_A_const_40 any

var A_arbace_g2a_layout__init_A_const_41 *lang.Var

var A_arbace_g2a_layout__init_A_const_42 any

var A_arbace_g2a_layout__init_A_const_43 *lang.Var

var A_arbace_g2a_layout__init_A_const_44 any

var A_arbace_g2a_layout__init_A_const_45 *lang.Var

var A_arbace_g2a_layout__init_A_const_46 any

var A_arbace_g2a_layout__init_A_init jrt.ClassInit

func A_arbace_g2a_layout__init_A_Init() { if !A_arbace_g2a_layout__init_A_init.Done() { A_arbace_g2a_layout__init_A_init.Run(A_arbace_g2a_layout__init_A_clinit) } }

func A_arbace_g2a_layout__init_A_clinit() { A_arbace_g2a_layout__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_176); A_arbace_g2a_layout__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_g2a_layout__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_g2a_layout__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_layout__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_16); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_layout__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_61); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_g2a_layout__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_11, Lit_22); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_g2a_layout__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_g2a_layout__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_36); A_arbace_g2a_layout__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_183, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_31); A_arbace_g2a_layout__init_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_184).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_g2a_layout__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_11, Lit_24); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_184).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_g2a_layout__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_11, Lit_44); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_g2a_layout__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_11, Lit_40); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_g2a_layout__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_186, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_11, Lit_102); A_arbace_g2a_layout__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_188, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_11, Lit_79); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_189).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_g2a_layout__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(92).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_55); A_arbace_g2a_layout__init_A_const_28 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_191).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_192).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_193).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_194).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_51, Lit_195).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_196).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_51, Lit_197).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_51, Lit_73).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref())); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_g2a_layout__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(94).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_57); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_g2a_layout__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_11, Lit_64); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_g2a_layout__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_198).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(101).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_11, Lit_63); A_arbace_g2a_layout__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_199, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(104).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_11, Lit_94); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_g2a_layout__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(116).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_11, Lit_96); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_g2a_layout__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(134).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_200, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(154).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_11, Lit_104); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_177).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_g2a_layout__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_201)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_73).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_202).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_203, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(167).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_11, Lit_204); A_arbace_g2a_layout__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_205).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_206, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(174).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)); A_arbace_g2a_layout__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_11, Lit_207); A_arbace_g2a_layout__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_181).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_208).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_209).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_210).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_211, lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(231).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_178).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_179).Ref(), Lit_180)) }

func A_arbace_g2a_layout__init_A_New() *A_arbace_g2a_layout__init_A { A_arbace_g2a_layout__init_A_Init(); t := &A_arbace_g2a_layout__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_layout__init_A) Ctor() {}

func (t *A_arbace_g2a_layout__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_layout__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_layout__init_A_class }

func (t *A_arbace_g2a_layout__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_layout__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_layout__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_layout__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_layout__init_A); return ok }

func A_arbace_g2a_layout__init_A_Cast(x any) *A_arbace_g2a_layout__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_layout__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_layout__init_A_class)) }; return v }
