//line rlwrap_linux.ae:1
//go:build linux

package main

import (
	"os"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)
// rlwrapFlags are clj's (Clojure's Alpine package): multi-line editing, completion on the words seen, \ and "
// as quote characters (clj's '\"'), Clojure's delimiters as word breaks.
var rlwrapFlags []string =


	[]string{"-m", "-r", "-q", "\\\"", "-b", "(){}[],^%#@\";:'"}
// startsREPL tells whether arbace.main runs its REPL with these arguments (arbace.main/main):
// no arguments, or init options (-i, -e and --report, each with its argument) followed by -r
// or --repl. Init options alone, -m, -h and a script (- included) do not start it.
//line :19:1
func startsREPL(args /*line :21:1*/[]string) bool {
	if len(args) == 0 {
		return true }
	for i := 0; i < len(args); {
		switch args[i] {
		case "--report", "-i", "--init", "-e", "--eval":
			i += 2
		case "-r", "--repl":
			return true
		default:
			return false} }
	return false }
// terminal tells whether fd is a terminal (isatty: TCGETS succeeds).
func terminal(fd uintptr) bool {
	var t syscall.Termios
	_, _, e := syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TCGETS), uintptr(unsafe.Pointer(&t)))
	return e == 0 }
// columns is the width of terminal fd (TIOCGWINSZ), 0 when unknown: rlwrap refuses a width of 0.
func columns(fd uintptr) int {
	var ws [4]uint16
	_, _, e := syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TIOCGWINSZ), uintptr(unsafe.Pointer(&ws)))
	if e != 0 {
		return 0 }
	return int(ws[1]) }
// parentIsRlwrap tells whether the parent process is rlwrap (rlwrap arbace, by hand).
func parentIsRlwrap() bool {
	b, err := os.ReadFile("/proc/" + strconv.Itoa(os.Getppid()) + "/comm")
	return err == nil && strings.TrimSpace(string(b)) == "rlwrap" }
// lookPath is the executable file name in one of PATH's absolute directories, or "".
func lookPath(name string) string {
	for _, dir := range strings.Split(os.Getenv("PATH"), ":") {
		if strings.HasPrefix(dir, "/") {
			p := dir + "/" + name
			fi, err := os.Stat(p)
			if err == nil && fi.Mode().IsRegular() && fi.Mode()&73 != 0 {
				return p } } }
	return "" }
// execRlwrap replaces the process with rlwrap running the executable, when the REPL is to run
// interactively (EXEC-NOTES.md, "Line editing: rlwrap"); otherwise, or when the exec fails, it
// returns and the program runs as it is. ARBACE_RLWRAP=off disables it; the executable sets
// ARBACE_RLWRAP=wrapped for its child, which therefore does not exec again.
//line :59:1
func execRlwrap() {


	{ mode := os.Getenv("ARBACE_RLWRAP")
		if mode == "off" || mode == "wrapped" {
			return } }
	{ term := os.Getenv("TERM")
		if term == "" || term == "dumb" {
			return } }
	if !startsREPL(os.Args[1:]) || !terminal(0) || !terminal(1) || columns(0) == 0 || parentIsRlwrap() {
		return }
	path := lookPath("rlwrap")
	if path == "" {
		return }
	exe, err := os.Executable()
	if err != nil {
		return }
	argv := append([]string{"rlwrap"}, rlwrapFlags...)
	argv = append(argv, exe)
	argv = append(argv, os.Args[1:]...)
	env := []string{}
	for _, kv := range os.Environ() {
		if !strings.HasPrefix(kv, "ARBACE_RLWRAP=") {
			env = append(env, kv) } }
	env = append(env, "ARBACE_RLWRAP=wrapped")

	syscall.Exec(path, argv, env)
}
