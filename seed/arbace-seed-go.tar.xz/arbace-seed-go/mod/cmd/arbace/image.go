//line image.ae:1
package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"reflect"
	"runtime/debug"
	"sort"
	"strings"
	"sync"
	"time"
	"unsafe"

	"arbace/jrt"
	"arbace/lang"
)








const imageMagic = "ARBACE-IMAGE-1\n"

const (
	tNil = iota
	tRef
	tObj
	tStr
	tLong
	tInt
	tDouble
	tTrue
	tFalse
	tChar
	tShort
	tByte
	tFloat
	tKeyword
	tVar
	tNs
	tClass
	tMethod
	tCtor
	tField
	tRefArray
	tPrimArray
	tStatic
	tPattern
	tSymbol
	tMapRebuild
	tSetRebuild
	tLazySeq
	tAtomicRef
	tAtomicInt
	tAtomicBool
	tPlainObj
)

var plainObjectType = reflect.TypeOf(jrt.Object_New())




var imageTypes map[string]reflect.Type

func registerImageTypes(ts []reflect.Type) {
	imageTypes = make(map[string]reflect.Type, len(ts))
	for _, t := range ts {
		imageTypes[t.String()] = t
	}
}

type fieldPlan struct{ index /*line :80:1*/[]int; off uintptr; t reflect.Type; kind reflect.Kind; zero bool }






type typePlan struct{ t reflect.Type; fields /*line :89:1*/[]fieldPlan; err string; inited bool }




var (
	plansMu    sync.Mutex
	plans      = map[reflect.Type]*typePlan{}
	objectType = reflect.TypeOf(jrt.Object{})
)

// imageSkipped are the fields the analysis fills for the bytecode back end only, which the Go
// build's evaluator never reads: not encoded, nil when decoded. ObjExpr.src, the fn's or type's
// whole form, is read by ObjExpr.compile's class generation; the clearing paths by emit's
// locals clearing
var imageSkipped = map[string]bool{"Compiler_ObjExpr.F_src": true, "Compiler_LocalBindingExpr.F_clearPath": true, "Compiler_LocalBindingExpr.F_clearRoot": true, "Compiler_ObjMethod.F_evalCM": true, "Compiler_FnExpr.F_evalArities": true}








func planOf(t reflect.Type) *typePlan {
	plansMu.Lock()
	defer plansMu.Unlock()
	if p, ok := plans[t]; ok {
		return p
	}
	p := &typePlan{t: t}
	var walk func(t reflect.Type, prefix []int, base uintptr)
	walk = func(t reflect.Type, prefix []int, base uintptr) {
		for i := 0; i < t.NumField(); i++ {
			f := t.Field(i)
			idx := append(append([]int(nil), prefix...), i)
			if f.Anonymous && f.Type == objectType {
				continue
			}
			if f.Anonymous && f.Type.Kind() == reflect.Struct {
				walk(f.Type, idx, base+f.Offset)
				continue
			}
			if !f.IsExported() {
				p.err = fmt.Sprintf("unexported field %s of %s", f.Name, t)
				return
			}
			switch f.Type.Kind() {
			case reflect.Interface, reflect.Pointer, reflect.Bool, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint16, reflect.Float32, reflect.Float64:

				p.fields = append(p.fields, fieldPlan{index: idx, off: base + f.Offset, t:  f.Type,
										kind:     f.Type.Kind(), zero: f.Name == "F__hash" || f.Name == "F__hasheq" ||
										imageSkipped[t.Name()+"."+f.Name]})
			default:
				p.err = fmt.Sprintf("field %s of %s has type %s", f.Name, t, f.Type)
				return
			}
		}
	}
	walk(t, nil, 0)
	plans[t] = p
	return p
}




var (
	staticsOnce sync.Once
	statics     []any
	staticIdx   map[any]int
)

func initStatics() {
	staticsOnce.Do(func() {
		lang.PersistentList_Init()
		lang.PersistentVector_Init()
		lang.PersistentArrayMap_Init()
		lang.PersistentHashMap_Init()
		lang.PersistentHashSet_Init()
		lang.PersistentTreeMap_Init()
		lang.PersistentTreeSet_Init()
		lang.PersistentQueue_Init()
		lang.Compiler_Init()
		lang.RT_Init()
		statics = []any{lang.PersistentList_EMPTY, lang.PersistentVector_EMPTY, lang.PersistentVector_EMPTY_NODE, lang.PersistentArrayMap_EMPTY, lang.PersistentHashMap_EMPTY, lang.PersistentHashSet_EMPTY, lang.PersistentTreeMap_EMPTY, lang.PersistentTreeSet_EMPTY, lang.PersistentQueue_EMPTY, lang.Compiler_NIL_EXPR, lang.Compiler_TRUE_EXPR, lang.Compiler_FALSE_EXPR, lang.RT_EMPTY_ARRAY, lang.PersistentHashMap_NOT_FOUND}






		staticIdx = make(map[any]int, len(statics))
		for i, s := range statics {
			if s != nil {
				staticIdx[s] = i
			}
		}
	},
	)
}



type encoder struct {
	name   string
	buf    bytes.Buffer
	ids    map[any]int
	nobj   int
	strs   map[string]int
	types  map[reflect.Type]int
	counts map[string]int
	path   []string
	// the classes the unit being encoded makes (its events): referred to by name only once
	// their event is made again
	defined map[string]bool
	tmp     [binary.MaxVarintLen64]byte
}

func (e *encoder) fail(msg string) {
	n := len(e.path)
	from := 0
	if n > 12 {
		from = n - 12
	}
	panic(fmt.Sprintf("image: %s: %s (in %s)", e.name, msg, strings.Join(e.path[from:], " < ")))
}

func newEncoder(name string) *encoder {
	initStatics()
	return &encoder{name: name, ids: map[any]int{}, strs:            map[string]int{},
				types:     map[reflect.Type]int{}, counts: map[string]int{},
	}
}
func (e *encoder) b(x byte) { e.buf.WriteByte(x) }
func (e *encoder) uv(x uint64) { e.buf.Write(e.tmp[:binary.PutUvarint(e.tmp[:], x)]) }
func (e *encoder) sv(x int64) { e.buf.Write(e.tmp[:binary.PutVarint(e.tmp[:], x)]) }

// a Go string through the source's table
func (e *encoder) str(s string) {
	if i, ok := e.strs[s]; ok {
		e.uv(uint64(i))
		return
	}
	i := len(e.strs)
	e.strs[s] = i
	e.uv(uint64(i))
	e.uv(uint64(len(s)))
	e.buf.WriteString(s)
}

// a nullable Java string as a table string (absent: index 0 reserved? no: a flag byte)
func (e *encoder) jstr(s *jrt.String) {
	if s == nil {
		e.b(0)
		return
	}
	e.b(1)
	e.str(s.String())
}

func (e *encoder) newID(x any) {
	e.ids[x] = e.nobj
	e.nobj++
}

func className(c *jrt.Class) string { return c.GetName__String().String() }

func (e *encoder) value(x any) {
	if x == nil {
		e.b(tNil)
		return
	}
	if rv := reflect.ValueOf(x); rv.Kind() == reflect.Pointer && rv.IsNil() {
		e.b(tNil)
		return
	}
	if id, ok := e.ids[x]; ok {
		e.b(tRef)
		e.uv(uint64(id))
		return
	}
	if i, ok := staticIdx[x]; ok {
		e.b(tStatic)
		e.uv(uint64(i))
		return
	}
	switch v := x.(type) {
	case *jrt.Boolean:
		if v.F_value {
			e.b(tTrue)
		} else {
			e.b(tFalse)
		}
		return
	case *jrt.Long:
		e.b(tLong)
		e.sv(v.F_value)
		return
	case *jrt.Integer:
		e.b(tInt)
		e.sv(int64(v.F_value))
		return
	case *jrt.Short:
		e.b(tShort)
		e.sv(int64(v.F_value))
		return
	case *jrt.Byte:
		e.b(tByte)
		e.sv(int64(v.F_value))
		return
	case *jrt.Character:
		e.b(tChar)
		e.uv(uint64(v.F_value))
		return
	case *jrt.Double:
		e.b(tDouble)
		e.uv(math.Float64bits(v.F_value))
		return
	case *jrt.Float:
		e.b(tFloat)
		e.uv(uint64(math.Float32bits(v.F_value)))
		return
	case *jrt.String:
		e.newID(x)
		e.b(tStr)
		e.str(v.String())
		e.counts["String"]++
		return
	case *lang.Keyword:
		e.newID(x)
		e.b(tKeyword)
		e.jstr(v.F_sym.F_ns)
		e.str(v.F_sym.F_name.String())
		return
	case *lang.Symbol:
		e.newID(x)
		e.b(tSymbol)
		e.jstr(v.F_ns)
		e.str(v.F_name.String())
		e.value(v.F__meta)
		e.counts["Symbol"]++
		return
	case *lang.Var:
		if v.F_ns == nil {
			panic(fmt.Sprintf("image: %s: a Var without a namespace (%v)", e.name, v.F_sym))
		}
		e.newID(x)
		e.b(tVar)
		e.str(v.F_ns.F_name.F_name.String())
		e.str(v.F_sym.F_name.String())
		return
	case *lang.Namespace:
		e.newID(x)
		e.b(tNs)
		e.str(v.F_name.F_name.String())
		return
	case *jrt.Class:
		e.newID(x)
		e.b(tClass)
		e.classRef(v)
		return
	case *jrt.Method:
		e.newID(x)
		e.b(tMethod)
		e.member(v.GetDeclaringClass__Class(), v.GetName__String().String(), v.GetParameterTypes__Class1())
		e.classRef(v.GetReturnType__Class())
		return
	case *jrt.Constructor:
		e.newID(x)
		e.b(tCtor)
		e.member(v.GetDeclaringClass__Class(), "", v.GetParameterTypes__Class1())
		return
	case *jrt.Field:
		e.newID(x)
		e.b(tField)
		e.member(v.GetDeclaringClass__Class(), v.GetName__String().String(), nil)
		return
	case *jrt.Pattern:
		e.newID(x)
		e.b(tPattern)
		e.str(v.F_pattern.String())
		e.sv(int64(v.F_flags0))
		return
	case *jrt.RefArray:
		e.newID(x)
		e.b(tRefArray)
		e.classRef(v.Comp)
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.value(y)
		}
		e.counts["Object[]"]++
		return
	case *jrt.ByteArray, *jrt.CharArray, *jrt.IntArray, *jrt.LongArray, *jrt.ShortArray,
		*jrt.BooleanArray, *jrt.FloatArray, *jrt.DoubleArray:
		e.newID(x)
		e.b(tPrimArray)
		e.primArray(x)
		return
	case *jrt.AtomicReference:
		if _, ok := v.Get__O().(*jrt.Thread); ok {
			e.fail("an AtomicReference holding a Thread (a transient being edited)")
		}
		e.newID(x)
		e.b(tAtomicRef)
		e.value(v.Get__O())
		return
	case *jrt.AtomicInteger:
		e.newID(x)
		e.b(tAtomicInt)
		e.sv(int64(v.Get__I()))
		return
	case *jrt.AtomicBoolean:
		e.newID(x)
		e.b(tAtomicBool)
		if v.Get__Z() {
			e.b(1)
		} else {
			e.b(0)
		}
		return
	case *lang.LazySeq:
		e.newID(x)
		e.b(tLazySeq)
		e.value(v.F__meta)
		e.value(v.Seq__ISeq())
		e.counts["LazySeq"]++
		return
	case *lang.PersistentHashMap:
		if unstableMap(v) {
			e.newID(x)
			e.b(tMapRebuild)
			e.value(v.F__meta)
			e.uv(uint64(v.F_count))
			for s := v.Seq__ISeq(); s != nil; s = s.Next__ISeq() {
				me := s.First__O().(lang.IMapEntry)
				e.value(me.Key__O())
				e.value(me.Val__O())
			}
			e.counts["PersistentHashMap (rebuilt)"]++
			return
		}
	case *lang.PersistentHashSet:
		if unstableSet(v) {
			e.newID(x)
			e.b(tSetRebuild)
			e.value(v.F__meta)
			e.uv(uint64(v.Count__I()))
			for s := v.Seq__ISeq(); s != nil; s = s.Next__ISeq() {
				e.value(s.First__O())
			}
			e.counts["PersistentHashSet (rebuilt)"]++
			return
		}
	}
	rv := reflect.ValueOf(x)
	if rv.Type() == plainObjectType {
		e.newID(x)
		e.b(tPlainObj)
		return
	}
	if rv.Kind() != reflect.Pointer || rv.Elem().Kind() != reflect.Struct {
		e.fail(fmt.Sprintf("cannot encode a %T", x))
	}
	t := rv.Elem().Type()
	p := planOf(t)
	if p.err != "" {
		e.fail(fmt.Sprintf("cannot encode a %T: %s", x, p.err))
	}
	if _, ok := imageTypes[t.String()]; !ok {
		e.fail(fmt.Sprintf("the type %s is not in the image's table", t))
	}
	e.newID(x)
	e.b(tObj)
	if i, ok := e.types[t]; ok {
		e.uv(uint64(i)) } else {

			i = len(e.types)
			e.types[t] = i
			e.uv(uint64(i))
			e.str(t.String())
		}
	e.sv(int64(jrt.PeekIdentityHash(x)))
	e.counts[t.String()]++
	ev := rv.Elem()
	e.path = append(e.path, t.Name())
	defer func() { e.path = e.path[:len(e.path)-1] }()
	for _, f := range p.fields {
		if f.zero {
			continue
		}
		fv := ev.FieldByIndex(f.index)
		switch f.kind {
		case reflect.Interface, reflect.Pointer:
			if fv.IsNil() {
				e.b(tNil)
			} else {
				e.value(fv.Interface())
			}
		case reflect.Bool:
			if fv.Bool() {
				e.b(1)
			} else {
				e.b(0)
			}
		case reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			e.sv(fv.Int())
		case reflect.Uint16:
			e.uv(fv.Uint())
		case reflect.Float32, reflect.Float64:
			e.uv(math.Float64bits(fv.Float()))
		}
	}
}

func (e *encoder) member(c *jrt.Class, name string, ps *jrt.RefArray) {
	e.classRef(c)
	e.str(name)
	if ps == nil {
		e.uv(0)
		return
	}
	e.uv(uint64(len(ps.A)))
	for _, p := range ps.A {
		e.classRef(p.(*jrt.Class))
	}
}

// a class by name, and whether the unit's events make it
func (e *encoder) classRef(c *jrt.Class) {
	n := className(c)
	e.str(n)
	if e.defined[n] {
		e.b(1)
	} else {
		e.b(0)
	}
}

func (e *encoder) primArray(x any) {
	switch v := x.(type) {
	case *jrt.ByteArray:
		e.b('B')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.b(byte(y))
		}
	case *jrt.BooleanArray:
		e.b('Z')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			if y {
				e.b(1)
			} else {
				e.b(0)
			}
		}
	case *jrt.CharArray:
		e.b('C')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.uv(uint64(y))
		}
	case *jrt.ShortArray:
		e.b('S')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.sv(int64(y))
		}
	case *jrt.IntArray:
		e.b('I')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.sv(int64(y))
		}
	case *jrt.LongArray:
		e.b('J')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.sv(y)
		}
	case *jrt.FloatArray:
		e.b('F')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.uv(uint64(math.Float32bits(y)))
		}
	case *jrt.DoubleArray:
		e.b('D')
		e.uv(uint64(len(v.A)))
		for _, y := range v.A {
			e.uv(math.Float64bits(y))
		}
	}
}

// whether a key's hash may differ in another process: it holds a var or a namespace, whose
// hashes are identity hashes (a class's identity hash is its name's, jrt.presetClassHash;
// the other objects of the graph keep theirs)
func unstableKey(k any, depth int) bool {
	switch v := k.(type) {
	case nil:
		return false
	case *lang.Var, *lang.Namespace:
		return true
	case *jrt.Class, *jrt.String, *lang.Keyword, *lang.Symbol, *jrt.Long, *jrt.Integer, *jrt.Character, *jrt.Boolean, *jrt.Double:
		return false
	case lang.IPersistentCollection:
		if depth > 8 {
			return true
		}
		for s := lang.RT_Seq_O__ISeq(v); s != nil; s = s.Next__ISeq() {
			if unstableKey(s.First__O(), depth+1) {
				return true
			}
		}
	}
	return false
}

func unstableMap(m *lang.PersistentHashMap) bool {
	for s := m.Seq__ISeq(); s != nil; s = s.Next__ISeq() {
		if unstableKey(s.First__O().(lang.IMapEntry).Key__O(), 0) {
			return true
		}
	}
	return false
}

func unstableSet(m *lang.PersistentHashSet) bool {
	for s := m.Seq__ISeq(); s != nil; s = s.Next__ISeq() {
		if unstableKey(s.First__O(), 0) {
			return true
		}
	}
	return false
}




type pending struct {
	kind         byte
	name, member string
	params       /*line :635:1*/[]string
	ret          string
	setters      []func(any)
	// the classes it names that the unit's events make
	deferred []string
}

type decoder struct {
	name, data string
	pos        int
	objs       /*line :646:1*/[]any
	pend       map[int]*pending
	strs       []string
	types      []reflect.Type
	planned    []*typePlan
	hidden     int
	// the index of the event of the current unit that makes each class
	eventOf map[string]int
	// time spent decoding (ARBACE_IMAGE_TIMES)
	spent time.Duration
	units int
	// when the last unit was returned, and its line: the time until the next is the unit's
	// evaluation (ARBACE_IMAGE_TIMES)
	last     time.Time
	lastLine any
}

// a class name as classRef wrote it, noting a class the unit's events make
func (d *decoder) classRef(p *pending) string {
	n := d.str()
	if d.byte_() != 0 {
		p.deferred = append(p.deferred, n)
	}
	return n
}

func (d *decoder) byte_() byte {
	b := d.data[d.pos]
	d.pos++
	return b
}

func (d *decoder) uv() uint64 {
	var x uint64
	var s uint
	for {
		b := d.data[d.pos]
		d.pos++
		if b < 128 {
			return x | uint64(b)<<s
		}
		x |= uint64(b&127) << s
		s += 7
	}
}

func (d *decoder) sv() int64 {
	u := d.uv()
	x := int64(u >> 1)
	if u&1 != 0 {
		x = ^x
	}
	return x
}

func (d *decoder) str() string {
	i := int(d.uv())
	if i < len(d.strs) {
		return d.strs[i]
	}
	n := int(d.uv())
	s := d.data[d.pos : d.pos+n]
	d.pos += n
	d.strs = append(d.strs, s)
	return s
}

func (d *decoder) jstr() *jrt.String {
	if d.byte_() == 0 {
		return nil
	}
	return jrt.Str(d.str())
}

func (d *decoder) slot() int {
	d.objs = append(d.objs, nil)
	return len(d.objs) - 1
}

// value decodes one value; set receives it, now or (a class or member not made yet) when it
// is resolved
func (d *decoder) value(set func(any)) {
	v, p := d.read()
	if p != nil {
		p.setters = append(p.setters, set)
	} else if v != nil {
		set(v)
	}
}

// read decodes one value: the value, or (a class or member not made yet) its pending
// resolution, to which the caller adds where it goes
func (d *decoder) read() (any, *pending) {
	switch tag := d.byte_(); tag {
	case tNil:
		return nil, nil
	case tRef:
		id := int(d.uv())
		if p, ok := d.pend[id]; ok {
			return nil, p
		}
		return d.objs[id], nil
	case tStatic:
		return statics[d.uv()], nil
	case tTrue:
		return jrt.Boolean_TRUE, nil
	case tFalse:
		return jrt.Boolean_FALSE, nil
	case tLong:
		return jrt.Long_ValueOf_J__Long(d.sv()), nil
	case tInt:
		return jrt.Integer_ValueOf_I__Integer(int32(d.sv())), nil
	case tShort:
		return jrt.Short_ValueOf_S__Short(int16(d.sv())), nil
	case tByte:
		return jrt.Byte_ValueOf_B__Byte(int8(d.sv())), nil
	case tChar:
		return jrt.Character_ValueOf_C__Character(uint16(d.uv())), nil
	case tDouble:
		return jrt.Double_ValueOf_D__Double(math.Float64frombits(d.uv())), nil
	case tFloat:
		return jrt.Float_ValueOf_F__Float(math.Float32frombits(uint32(d.uv()))), nil
	case tStr:
		id := d.slot()
		s := jrt.Str(d.str())
		d.objs[id] = s
		return s, nil
	case tKeyword:
		id := d.slot()
		ns := d.jstr()
		k := lang.Keyword_Intern_String_String__Keyword(ns, jrt.Str(d.str()))
		d.objs[id] = k
		return k, nil
	case tSymbol:
		id := d.slot()
		ns := d.jstr()
		s := lang.Symbol_Intern_String_String__Symbol(ns, jrt.Str(d.str()))
		d.objs[id] = s
		if m, _ := d.read(); m != nil {
			s.F__meta = m.(lang.IPersistentMap)
		}
		return s, nil
	case tVar:
		id := d.slot()
		ns := lang.Namespace_FindOrCreate_Symbol__Namespace(lang.Symbol_Intern_String__Symbol(jrt.Str(d.str())))
		sym := lang.Symbol_Intern_String__Symbol(jrt.Str(d.str()))
		v := ns.FindInternedVar_Symbol__Var(sym)
		if v == nil {
			v = lang.Var_Intern_Namespace_Symbol__Var(ns, sym)
		}
		d.objs[id] = v
		return v, nil
	case tNs:
		id := d.slot()
		ns := lang.Namespace_FindOrCreate_Symbol__Namespace(lang.Symbol_Intern_String__Symbol(jrt.Str(d.str())))
		d.objs[id] = ns
		return ns, nil
	case tClass:
		id := d.slot()
		p := &pending{kind: tClass}
		p.name = d.classRef(p)
		return d.pendingRef(id, p)
	case tMethod:
		id := d.slot()
		p := &pending{kind: tMethod}
		d.memberSpec(p)
		p.ret = d.classRef(p)
		return d.pendingRef(id, p)
	case tCtor:
		id := d.slot()
		p := &pending{kind: tCtor}
		d.memberSpec(p)
		return d.pendingRef(id, p)
	case tField:
		id := d.slot()
		p := &pending{kind: tField}
		d.memberSpec(p)
		return d.pendingRef(id, p)
	case tPattern:
		id := d.slot()
		pat := jrt.Pattern_Compile_String_I__Pattern(jrt.Str(d.str()), int32(d.sv()))
		d.objs[id] = pat
		return pat, nil
	case tRefArray:
		id := d.slot()
		cp := &pending{kind: tClass}
		cp.name = d.classRef(cp)
		n := int(d.uv())
		a := &jrt.RefArray{A: make([]any, n)}
		d.objs[id] = a
		if c, p := d.pendingRef(-1, cp); p != nil {
			p.setters = append(p.setters, func(c any) { a.Comp = c.(*jrt.Class) })
		} else {
			a.Comp = c.(*jrt.Class)
		}
		for i := 0; i < n; i++ {
			v, p := d.read()
			if p != nil {
				i := i
				p.setters = append(p.setters, func(v any) { a.A[i] = v })
			} else {
				a.A[i] = v
			}
		}
		return a, nil
	case tPrimArray:
		id := d.slot()
		a := d.primArray()
		d.objs[id] = a
		return a, nil
	case tPlainObj:
		id := d.slot()
		o := jrt.Object_New()
		d.objs[id] = o
		return o, nil
	case tAtomicRef:
		id := d.slot()
		a := jrt.AtomicReference_New()
		d.objs[id] = a
		d.value(func(v any) { a.Set_O__V(v) })
		return a, nil
	case tAtomicInt:
		id := d.slot()
		a := jrt.AtomicInteger_New_I(int32(d.sv()))
		d.objs[id] = a
		return a, nil
	case tAtomicBool:
		id := d.slot()
		a := jrt.AtomicBoolean_New_Z(d.byte_() != 0)
		d.objs[id] = a
		return a, nil
	case tLazySeq:
		id := d.slot()
		var meta lang.IPersistentMap
		var s lang.ISeq
		if m, _ := d.read(); m != nil {
			meta = m.(lang.IPersistentMap)
		}
		if x, _ := d.read(); x != nil {
			s = x.(lang.ISeq)
		}
		ls := lang.LazySeq_New_IPersistentMap_ISeq(meta, s)
		d.objs[id] = ls
		return ls, nil
	case tMapRebuild, tSetRebuild:
		id := d.slot()
		meta, _ := d.read()
		n := int(d.uv())
		k := n
		if tag == tMapRebuild {
			k = 2 * n
		}
		kvs := jrt.NewRefArray(jrt.Object_class, int32(k))
		for i := 0; i < k; i++ {
			i := i
			d.value(func(v any) { kvs.A[i] = v })
		}
		var r any
		if tag == tMapRebuild {
			m := lang.PersistentHashMap_Create_O1__PersistentHashMap(kvs)
			if meta != nil {
				m = m.WithMeta_IPersistentMap__PersistentHashMap(meta.(lang.IPersistentMap))
			}
			r = m
		} else {
			m := lang.PersistentHashSet_Create_O1__PersistentHashSet(kvs)
			if meta != nil {
				m = m.WithMeta_IPersistentMap__PersistentHashSet(meta.(lang.IPersistentMap))
			}
			r = m
		}
		d.objs[id] = r
		return r, nil
	case tObj:
		return d.object(), nil
	}
	panic(fmt.Sprintf("image: %s: bad tag at %d", d.name, d.pos-1))
}

// object decodes a struct of the program, its fields written in place
func (d *decoder) object() any {
	ti := int(d.uv())
	if ti == len(d.types) {
		tn := d.str()
		t, ok := imageTypes[tn]
		if !ok {
			panic(fmt.Sprintf("image: %s: unknown type %s", d.name, tn))
		}
		d.types = append(d.types, t)
		d.planned = append(d.planned, planOf(t))
	}
	p := d.planned[ti]
	if !p.inited {

		if o, ok := reflect.New(p.t).Interface().(jrt.Object_I); ok {
			if c := o.GetClass__Class(); c != nil && c.Info().Init != nil {
				c.Info().Init()
			}
		}
		p.inited = true
	}
	h := int32(d.sv())
	pv := reflect.New(p.t)
	x := pv.Interface()
	if h != 0 {
		jrt.SetIdentityHash(x, h)
	}
	id := d.slot()
	d.objs[id] = x
	base := pv.UnsafePointer()
	for i := range p.fields {
		f := &p.fields[i]
		if f.zero {
			continue
		}
		at := unsafe.Add(base, f.off)
		switch f.kind {
		case reflect.Interface, reflect.Pointer:
			v, pd := d.read()
			if pd != nil {
				pd.setters = append(pd.setters, func(v any) { setRef(at, f, v) })
			} else if v != nil {
				setRef(at, f, v)
			}
		case reflect.Bool:
			*(*bool)(at) = d.byte_() != 0
		case reflect.Int8:
			*(*int8)(at) = int8(d.sv())
		case reflect.Int16:
			*(*int16)(at) = int16(d.sv())
		case reflect.Int32:
			*(*int32)(at) = int32(d.sv())
		case reflect.Int64:
			*(*int64)(at) = d.sv()
		case reflect.Uint16:
			*(*uint16)(at) = uint16(d.uv())
		case reflect.Float32:
			*(*float32)(at) = float32(math.Float64frombits(d.uv()))
		case reflect.Float64:
			*(*float64)(at) = math.Float64frombits(d.uv())
		}
	}
	return x
}

// the words of an interface value
type ifaceWords struct{ tab, data unsafe.Pointer }




type itabKey struct{ iface, concrete reflect.Type }



var (
	itabsMu sync.Mutex
	itabs   = map[itabKey]unsafe.Pointer{}
)

// setRef stores v, a pointer to a Java object, in the reference field at: a pointer field its
// pointer, an interface field the interface's table for v's type (made once by reflect) and
// the pointer
func setRef(at unsafe.Pointer, f *fieldPlan, v any) {
	w := (*ifaceWords)(unsafe.Pointer(&v))
	if f.kind == reflect.Pointer {
		*(*unsafe.Pointer)(at) = w.data
		return
	}
	if f.t.NumMethod() == 0 {
		*(*any)(at) = v
		return
	}
	k := itabKey{f.t, reflect.TypeOf(v)}
	itabsMu.Lock()
	tab, ok := itabs[k]
	itabsMu.Unlock()
	if !ok {
		tmp := reflect.New(f.t)
		tmp.Elem().Set(reflect.ValueOf(v))
		tab = (*ifaceWords)(tmp.UnsafePointer()).tab
		itabsMu.Lock()
		itabs[k] = tab
		itabsMu.Unlock()
	}
	dst := (*ifaceWords)(at)
	dst.tab = tab
	dst.data = w.data
}

// a hidden slot (the encoder numbers nothing there): the array's class is pending under a
// negative key
func (d *decoder) slot2() int {
	d.hidden--
	return d.hidden
}

func (d *decoder) memberSpec(p *pending) {
	p.name = d.classRef(p)
	p.member = d.str()
	n := int(d.uv())
	p.params = make([]string, n)
	for i := range p.params {
		p.params[i] = d.classRef(p)
	}
}

// pendingRef: the class or member p names, or p itself, pending until it can be resolved
func (d *decoder) pendingRef(id int, p *pending) (any, *pending) {
	if len(p.deferred) == 0 {
		if v := p.lookup(); v != nil {
			if id >= 0 {
				d.objs[id] = v
			}
			return v, nil
		}
	}
	if d.pend == nil {
		d.pend = map[int]*pending{}
	}
	if id < 0 {
		id = d.slot2()
	}
	d.pend[id] = p
	return nil, p
}

var primClasses = map[string]*jrt.Class{}

func classByName(n string) *jrt.Class {
	if len(primClasses) == 0 {
		for _, c := range []*jrt.Class{jrt.Prim_boolean, jrt.Prim_byte, jrt.Prim_char, jrt.Prim_short, jrt.Prim_int, jrt.Prim_long, jrt.Prim_float, jrt.Prim_double, jrt.Prim_void} {

			primClasses[className(c)] = c
		}
	}
	if c, ok := primClasses[n]; ok {
		return c
	}
	return jrt.ForName(n)
}

func (p *pending) lookup() any {
	if v := p.lookup1(); v != nil || p.kind == tClass {
		return v
	}

	if c := classByName(p.name); c != nil {
		membersMu.Lock()
		delete(memberMap, c)
		membersMu.Unlock()
	}
	return p.lookup1()
}

func (p *pending) lookup1() any {
	c := classByName(p.name)
	if c == nil {
		return nil
	}
	if p.kind == tClass {
		return c
	}
	ps := make([]*jrt.Class, len(p.params))
	for i, n := range p.params {
		if ps[i] = classByName(n); ps[i] == nil {
			return nil
		}
	}
	same := func(a *jrt.RefArray) bool {
		if len(a.A) != len(ps) {
			return false
		}
		for i, x := range a.A {
			if x.(*jrt.Class) != ps[i] {
				return false
			}
		}
		return true
	}
	switch p.kind {
	case tMethod:
		for _, x := range members(c).methods {
			m := x.(*jrt.Method)
			if m.GetName__String().String() == p.member && same(m.GetParameterTypes__Class1()) &&
				className(m.GetReturnType__Class()) == p.ret {
					return m
				}
		}
	case tCtor:
		for _, x := range members(c).ctors {
			k := x.(*jrt.Constructor)
			if same(k.GetParameterTypes__Class1()) {
				return k
			}
		}
	case tField:
		for _, x := range members(c).fields {
			f := x.(*jrt.Field)
			if f.GetName__String().String() == p.member {
				return f
			}
		}
	}
	return nil
}

// a class's declared members, listed once per class (a class made at run time again is
// another Class)
type memberLists struct{ methods, ctors, fields /*line :1156:1*/[]any }


var (
	membersMu sync.Mutex
	memberMap = map[*jrt.Class]*memberLists{}
)

func members(c *jrt.Class) *memberLists {
	membersMu.Lock()
	defer membersMu.Unlock()
	if m, ok := memberMap[c]; ok {
		return m
	}
	m := &memberLists{methods: c.GetDeclaredMethods__Method1().A, ctors: c.GetDeclaredConstructors__Constructor1().A,
					fields:                                   c.GetDeclaredFields__Field1().A}
	memberMap[c] = m
	return m
}

// resolve resolves what the units decoded so far name, once the first k events of the
// current unit are made again
func (d *decoder) resolve(k int, strict bool) {
	for id, p := range d.pend {
		blocked := false
		for _, n := range p.deferred {
			if i, ok := d.eventOf[n]; ok && i >= k {
				blocked = true
			}
		}
		if blocked {
			continue
		}
		if v := p.lookup(); v != nil {
			if id >= 0 {
				d.objs[id] = v
			}
			for _, s := range p.setters {
				s(v)
			}
			delete(d.pend, id)
		}
	}
	if strict && len(d.pend) > 0 {
		var ns []string
		for _, p := range d.pend {
			ns = append(ns, p.name+" "+p.member)
		}
		sort.Strings(ns)
		panic(jrt.Thrown(jrt.IllegalStateException_New_String(jrt.Str(
			"image: " + d.name + ": not found: " + strings.Join(ns, ", "),
		),
		),
		)) } }
func (d *decoder) primArray() any {
	k := d.byte_()
	n := int(d.uv())
	switch k {
	case 'B':
		a := jrt.NewByteArray(int32(n))
		for i := range a.A {
			a.A[i] = int8(d.byte_())
		}
		return a
	case 'Z':
		a := jrt.NewBooleanArray(int32(n))
		for i := range a.A {
			a.A[i] = d.byte_() != 0
		}
		return a
	case 'C':
		a := jrt.NewCharArray(int32(n))
		for i := range a.A {
			a.A[i] = uint16(d.uv())
		}
		return a
	case 'S':
		a := jrt.NewShortArray(int32(n))
		for i := range a.A {
			a.A[i] = int16(d.sv())
		}
		return a
	case 'I':
		a := jrt.NewIntArray(int32(n))
		for i := range a.A {
			a.A[i] = int32(d.sv())
		}
		return a
	case 'J':
		a := jrt.NewLongArray(int32(n))
		for i := range a.A {
			a.A[i] = d.sv()
		}
		return a
	case 'F':
		a := jrt.NewFloatArray(int32(n))
		for i := range a.A {
			a.A[i] = math.Float32frombits(uint32(d.uv()))
		}
		return a
	case 'D':
		a := jrt.NewDoubleArray(int32(n))
		for i := range a.A {
			a.A[i] = math.Float64frombits(d.uv())
		}
		return a
	}
	panic("image: bad primitive array")
}




type image struct {
	mu       sync.Mutex
	prepare  string
	recs     map[string]*encoder
	done     map[string][]byte
	order    []string
	data     string
	index    map[string][2]int
	decoders map[string]*decoder
	// the garbage collector's setting before the start raised it
	gcPercent int
	gcRaised  bool
}

func (im *image) Mode() int32 {
	if im.prepare != "" {
		return 1
	}
	return 0
}

func (im *image) Begin(name string) bool {
	im.mu.Lock()
	defer im.mu.Unlock()
	if _, ok := im.done[name]; ok {
		return false
	}
	if _, ok := im.recs[name]; ok {
		return false
	}
	im.recs[name] = newEncoder(name)
	return true
}

func (im *image) Unit(name string, u *jrt.RefArray) {
	im.mu.Lock()
	e := im.recs[name]
	im.mu.Unlock()
	e.defined = unitClasses(u)
	e.value(u)
	e.defined = nil
}

// unitClasses: the names of the classes a unit's events make (an event is {kind, the class it
// makes or null, args...}; the unit's events are its element 6)
func unitClasses(u *jrt.RefArray) map[string]bool {
	m := map[string]bool{}
	if evs, ok := u.A[6].(*jrt.RefArray); ok {
		for _, ev := range evs.A {
			if n, ok := ev.(*jrt.RefArray).A[1].(*jrt.String); ok {
				m[n.String()] = true
			}
		}
	}
	return m
}

func (im *image) End(name string, ok bool) {
	im.mu.Lock()
	defer im.mu.Unlock()
	e := im.recs[name]
	delete(im.recs, name)
	if !ok {
		fmt.Fprintf(os.Stderr, "image: %s not recorded (its load failed)\n", name)
		return
	}
	im.done[name] = e.buf.Bytes()
	im.order = append(im.order, name)
	if os.Getenv("ARBACE_IMAGE_STATS") != "" {
		type kv struct{ k string; v int }



		var kvs []kv
		for k, v := range e.counts {
			kvs = append(kvs, kv{k, v})
		}
		sort.Slice(kvs, func(i, j int) bool { return kvs[i].v > kvs[j].v })
		fmt.Fprintf(os.Stderr, "image: %s: %d bytes, %d objects, %d strings, %d types\n", name, e.buf.Len(), e.nobj, len(e.strs), len(e.types))
		for i, x := range kvs {
			if i >= 25 {
				break
			}
			fmt.Fprintf(os.Stderr, "  %8d %s\n", x.v, x.k)
		}
	}
}

func (im *image) write() error {
	var out bytes.Buffer
	var tmp [binary.MaxVarintLen64]byte
	uv := func(x int) { out.Write(tmp[:binary.PutUvarint(tmp[:], uint64(x))]) }
	out.WriteString(imageMagic)
	names := append([]string(nil), im.order...)
	sort.Strings(names)
	uv(len(names))
	off := 0
	for _, n := range names {
		uv(len(n))
		out.WriteString(n)
		uv(off)
		uv(len(im.done[n]))
		off += len(im.done[n])
	}
	for _, n := range names {
		out.Write(im.done[n])
	}
	return os.WriteFile(im.prepare, out.Bytes(), 420)
}

func (im *image) readIndex() {
	if im.index != nil {
		return
	}
	im.index = map[string][2]int{}
	if !strings.HasPrefix(im.data, imageMagic) {
		return
	}
	d := &decoder{data: im.data, pos: len(imageMagic)}
	n := int(d.uv())
	type ent struct{ name string; off, len int }



	es := make([]ent, n)
	for i := range es {
		l := int(d.uv())
		es[i].name = d.data[d.pos : d.pos+l]
		d.pos += l
		es[i].off = int(d.uv())
		es[i].len = int(d.uv())
	}
	for _, e := range es {
		im.index[e.name] = [2]int{d.pos + e.off, d.pos + e.off + e.len}
	}
}

func (im *image) Has(name string) bool {
	if im.prepare != "" || im.data == "" {
		return false
	}
	im.mu.Lock()
	defer im.mu.Unlock()
	im.readIndex()
	_, ok := im.index[name]
	return ok
}

func (im *image) decoder(name string) *decoder {
	im.mu.Lock()
	defer im.mu.Unlock()
	im.readIndex()
	d := im.decoders[name]
	if d == nil {
		r := im.index[name]
		initStatics()
		d = &decoder{name: name, data: im.data[:r[1]], pos: r[0]}
		im.decoders[name] = d
	}
	return d
}

func (im *image) Next(name string) *jrt.RefArray {
	d := im.decoder(name)
	if imageTimes && !d.last.IsZero() {
		if t := time.Since(d.last); t > 3*time.Millisecond {
			fmt.Fprintf(os.Stderr, "image: %s:%v evaluated in %d ms\n", name, d.lastLine, t.Milliseconds())
		}
	}
	if d.pos >= len(d.data) {
		im.mu.Lock()
		delete(im.decoders, name)
		im.mu.Unlock()
		if imageTimes {
			fmt.Fprintf(os.Stderr, "image: %s: %d units, %d objects decoded in %d ms\n", name, d.units, len(d.objs), d.spent.Milliseconds())
		}
		return nil
	}
	if imageTimes {
		t0 := time.Now()
		defer func() { d.spent += time.Since(t0); d.units++ }()
	}
	var u *jrt.RefArray
	d.value(func(v any) { u = v.(*jrt.RefArray) })
	if imageTimes {
		defer func() { d.last = time.Now(); d.lastLine = u.A[1] }()
	}
	d.eventOf = map[string]int{}
	if evs, ok := u.A[6].(*jrt.RefArray); ok {
		for i, ev := range evs.A {
			if n, ok := ev.(*jrt.RefArray).A[1].(*jrt.String); ok {
				d.eventOf[n.String()] = i
			}
		}
	}
	return u
}

func (im *image) Resolve(name string, k int32, strict bool) {
	d := im.decoder(name)
	if imageTimes {
		t0 := time.Now()
		defer func() { d.spent += time.Since(t0) }()
	}
	d.resolve(int(k), strict)
}

var imageTimes = os.Getenv("ARBACE_IMAGE_TIMES") != ""

var theImage *image

// setupImage installs the image (ARBACE_NO_IMAGE: none, the namespaces are read and analyzed
// from their sources; ARBACE_PREPARE: record them into that file). While the program starts
// (until Main.main has loaded arbace.main) the garbage collector runs at GOGC=400 unless GOGC
// is set: the start allocates the decoded namespaces and the objects their evaluation makes,
// most of which stay
func setupImage(data string) {
	theImage = &image{prepare: os.Getenv("ARBACE_PREPARE"), recs: map[string]*encoder{},
					done:                              map[string][]byte{}, decoders: map[string]*decoder{}, data: data}
	if os.Getenv("ARBACE_NO_IMAGE") != "" {
		theImage.data = ""
	}
	if _, set := os.LookupEnv("GOGC"); !set {
		theImage.gcPercent = debug.SetGCPercent(400)
		theImage.gcRaised = true
	}
	jrt.Image = theImage
}

func (im *image) Started() {
	if im.gcRaised {
		im.gcRaised = false
		debug.SetGCPercent(im.gcPercent)
	}
}

func finishImage() {
	if theImage != nil && theImage.prepare != "" {
		if err := theImage.write(); err != nil {
			fmt.Fprintln(os.Stderr, "image:", err)
			os.Exit(1)
		}
	}
}
