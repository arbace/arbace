//line main.ae:1
package main

import (
	"embed"
	"io/fs"
	"os"

	"arbace/jrt"
	"arbace/lang"
)
// resources are the namespaces' sources RT.load reads (EVAL-NOTES.md, "Loading").
//
//go:embed res
//line :6:1
var resources embed.FS
// imageData is the image of prepared namespaces (EXEC-NOTES.md; image.go): empty until bin/arbace-go --build writes it.
//
//go:embed image.bin
//line :8:1
var imageData string
// arbaceVersion is Arbace's version, the map *arbace-version* reads from the system property arbace.version: empty in a2g's output, set by bin/arbace-go's link (go build -ldflags -X main.arbaceVersion=...).
var arbaceVersion string

func main() { execRlwrap(); if arbaceVersion != "" { jrt.System_SetProperty_String_String__String(jrt.Str("arbace.version"), jrt.Str(arbaceVersion)) }; { sub, err := fs.Sub(resources, "res"); if err == nil { jrt.SetHost(jrt.ProgramHost(sub)) } }; setupImage(imageData); args := jrt.NewRefArray(jrt.String_class, int32(len(os.Args)-1)); for i, a := range os.Args[1:] { args.A[i] = jrt.Str(a) }; status := jrt.RunMain(func() { lang.Main_Main_String1__V(args) }); finishImage(); os.Exit(status) }
