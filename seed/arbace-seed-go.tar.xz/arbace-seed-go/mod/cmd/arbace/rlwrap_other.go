//line rlwrap_other.ae:1
//go:build !linux

package main



// execRlwrap does nothing here (rlwrap_linux.go).
func execRlwrap() {}
