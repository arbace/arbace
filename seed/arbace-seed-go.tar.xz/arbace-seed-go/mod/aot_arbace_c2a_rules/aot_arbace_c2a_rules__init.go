//line aot_arbace_c2a_rules__init.ae:1
package aot_arbace_c2a_rules

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_rules__init_A_Unit0__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_c2a_rules__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_rules__init_A_const_1) }
//line :1:1
func A_arbace_c2a_rules__init_A_Unit1__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_c2a_rules__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_2)) }
//line :1:1
func A_arbace_c2a_rules__init_A_Unit2__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_Init(); tmp2 = A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_c2a_rules__init_A_Unit3__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2a_rules__init_A_const_1)).Equals_O__Z(A_arbace_c2a_rules__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_Init(); tmp2 = A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_c2a_rules__init_A_Load__O() any { A_arbace_c2a_rules__init_A_Init(); A_arbace_c2a_rules__init_A_Unit0__O(); A_arbace_c2a_rules__init_A_Unit1__O(); A_arbace_c2a_rules__init_A_Unit2__O(); A_arbace_c2a_rules__init_A_Unit3__O(); A_arbace_c2a_rules__init_A_Unit4__O(); A_arbace_c2a_rules__init_A_Unit5__O(); A_arbace_c2a_rules__init_A_Unit6__O(); A_arbace_c2a_rules__init_A_Unit7__O(); A_arbace_c2a_rules__init_A_Unit8__O(); A_arbace_c2a_rules__init_A_Unit9__O(); A_arbace_c2a_rules__init_A_Unit10__O(); A_arbace_c2a_rules__init_A_Unit11__O(); A_arbace_c2a_rules__init_A_Unit12__O(); A_arbace_c2a_rules__init_A_Unit13__O(); A_arbace_c2a_rules__init_A_Unit14__O(); A_arbace_c2a_rules__init_A_Unit15__O(); A_arbace_c2a_rules__init_A_Unit16__O(); A_arbace_c2a_rules__init_A_Unit17__O(); A_arbace_c2a_rules__init_A_Unit18__O(); return nil }













func A_arbace_c2a_rules__init_A_Unit4__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_4; var tmp2 any = A_arbace_c2a_rules_clojure_source_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_clojure_source_QMARK__A_Init(); tmp3 = A_arbace_c2a_rules_clojure_source_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_5)); return A_arbace_c2a_rules__init_A_const_4.Ref() }



func A_arbace_c2a_rules__init_A_Unit5__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); jrt.NN(A_arbace_c2a_rules__init_A_const_6).BindRoot_O__V(A_arbace_c2a_rules__init_A_const_7); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_8)); return A_arbace_c2a_rules__init_A_const_6.Ref() }



func A_arbace_c2a_rules__init_A_Unit6__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_9; var tmp2 any = A_arbace_c2a_rules_proxy_methods_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_proxy_methods_A_Init(); tmp3 = A_arbace_c2a_rules_proxy_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_10)); return A_arbace_c2a_rules__init_A_const_9.Ref() }






func A_arbace_c2a_rules__init_A_Unit7__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); jrt.NN(A_arbace_c2a_rules__init_A_const_11).BindRoot_O__V(Lit_178); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_11; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_12)); return A_arbace_c2a_rules__init_A_const_11.Ref() }

func A_arbace_c2a_rules__init_A_Unit8__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_13; var tmp2 any = A_arbace_c2a_rules_imports_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_imports_QMARK__A_Init(); tmp3 = A_arbace_c2a_rules_imports_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_14)); return A_arbace_c2a_rules__init_A_const_13.Ref() }

func A_arbace_c2a_rules__init_A_Unit9__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_15; var tmp2 any = A_arbace_c2a_rules_security_manager_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_security_manager_A_Init(); tmp3 = A_arbace_c2a_rules_security_manager_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_16)); return A_arbace_c2a_rules__init_A_const_15.Ref() }





























func A_arbace_c2a_rules__init_A_Unit10__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(68, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_17; var tmp2 any = A_arbace_c2a_rules_arbace_core_names_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_arbace_core_names_A_Init(); tmp3 = A_arbace_c2a_rules_arbace_core_names_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_18)); return A_arbace_c2a_rules__init_A_const_17.Ref() }






func A_arbace_c2a_rules__init_A_Unit11__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); jrt.NN(A_arbace_c2a_rules__init_A_const_19).BindRoot_O__V(A_arbace_c2a_rules__init_A_const_20); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_19; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_21)); return A_arbace_c2a_rules__init_A_const_19.Ref() }



func A_arbace_c2a_rules__init_A_Unit12__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(79, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_22; var tmp2 any = A_arbace_c2a_rules_defined_names_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_defined_names_A_Init(); tmp3 = A_arbace_c2a_rules_defined_names_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_23)); return A_arbace_c2a_rules__init_A_const_22.Ref() }
















func A_arbace_c2a_rules__init_A_Unit13__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_24; var tmp2 any = A_arbace_c2a_rules_insert_at_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_insert_at_A_Init(); tmp3 = A_arbace_c2a_rules_insert_at_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_25)); return A_arbace_c2a_rules__init_A_const_24.Ref() }

func A_arbace_c2a_rules__init_A_Unit14__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(98, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_26; var tmp2 any = A_arbace_c2a_rules_core_names_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_core_names_A_Init(); tmp3 = A_arbace_c2a_rules_core_names_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_27)); return A_arbace_c2a_rules__init_A_const_26.Ref() }



























func A_arbace_c2a_rules__init_A_Unit15__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_28; var tmp2 any = A_arbace_c2a_rules__init_A_const_30.Ref(); var tmp3 any = A_arbace_c2a_rules__init_A_const_31.Ref(); var tmp4 any = A_arbace_c2a_rules__init_A_const_32.Ref(); var tmp5 any = A_arbace_c2a_rules__init_A_const_33.Ref(); var tmp6 any = A_arbace_c2a_rules_fn__1094000090_A_New(); var tmp7 *jrt.Class; A_arbace_c2a_rules_fn__1094000090_A_Init(); tmp7 = A_arbace_c2a_rules_fn__1094000090_A_fn_class; var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_c2a_rules__init_A_const_34.Ref(); var tmp10 any = A_arbace_c2a_rules_fn__1094000092_A_New(); var tmp11 *jrt.Class; A_arbace_c2a_rules_fn__1094000092_A_Init(); tmp11 = A_arbace_c2a_rules_fn__1094000092_A_fn_class; var tmp12 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, Lit_179, tmp5, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))); var tmp13 any = A_arbace_c2a_rules__init_A_const_30.Ref(); var tmp14 any = A_arbace_c2a_rules__init_A_const_35.Ref(); var tmp15 any = A_arbace_c2a_rules__init_A_const_32.Ref(); var tmp16 any = A_arbace_c2a_rules__init_A_const_33.Ref(); var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_c2a_rules__init_A_const_36).GetRawRoot__O()); var tmp18 *jrt.Boolean; jrt.Boolean_Init(); tmp18 = jrt.Boolean_TRUE; var tmp19 any = tmp17.Invoke_O__O(tmp18.Ref()); var tmp20 any = A_arbace_c2a_rules__init_A_const_34.Ref(); var tmp21 any = A_arbace_c2a_rules_fn__1094000094_A_New(); var tmp22 *jrt.Class; A_arbace_c2a_rules_fn__1094000094_A_Init(); tmp22 = A_arbace_c2a_rules_fn__1094000094_A_fn_class; var tmp23 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, Lit_180, tmp16, tmp19, tmp20, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil))); var tmp24 any = A_arbace_c2a_rules__init_A_const_30.Ref(); var tmp25 any = A_arbace_c2a_rules__init_A_const_37.Ref(); var tmp26 any = A_arbace_c2a_rules__init_A_const_32.Ref(); var tmp27 any = A_arbace_c2a_rules__init_A_const_33.Ref(); var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_c2a_rules__init_A_const_36).GetRawRoot__O()); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp28.Invoke_O__O(tmp29.Ref()); var tmp31 any = A_arbace_c2a_rules__init_A_const_34.Ref(); var tmp32 any = A_arbace_c2a_rules_fn__1094000096_A_New(); var tmp33 *jrt.Class; A_arbace_c2a_rules_fn__1094000096_A_Init(); tmp33 = A_arbace_c2a_rules_fn__1094000096_A_fn_class; var tmp34 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp24, tmp25, tmp26, Lit_181, tmp27, tmp30, tmp31, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil))); var tmp35 any = A_arbace_c2a_rules__init_A_const_30.Ref(); var tmp36 any = A_arbace_c2a_rules__init_A_const_38.Ref(); var tmp37 any = A_arbace_c2a_rules__init_A_const_32.Ref(); var tmp38 any = A_arbace_c2a_rules__init_A_const_33.Ref(); var tmp39 any = jrt.NN(A_arbace_c2a_rules__init_A_const_4).GetRawRoot__O(); var tmp40 any = A_arbace_c2a_rules__init_A_const_34.Ref(); var tmp41 any = A_arbace_c2a_rules_fn__1094000098_A_New(); var tmp42 *jrt.Class; A_arbace_c2a_rules_fn__1094000098_A_Init(); tmp42 = A_arbace_c2a_rules_fn__1094000098_A_fn_class; var tmp43 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp35, tmp36, tmp37, Lit_182, tmp38, tmp39, tmp40, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil))); var tmp44 any = A_arbace_c2a_rules__init_A_const_30.Ref(); var tmp45 any = A_arbace_c2a_rules__init_A_const_39.Ref(); var tmp46 any = A_arbace_c2a_rules__init_A_const_32.Ref(); var tmp47 any = A_arbace_c2a_rules__init_A_const_33.Ref(); var tmp48 any = jrt.NN(A_arbace_c2a_rules__init_A_const_4).GetRawRoot__O(); var tmp49 any = A_arbace_c2a_rules__init_A_const_34.Ref(); var tmp50 any = A_arbace_c2a_rules_fn__1094000100_A_New(); var tmp51 *jrt.Class; A_arbace_c2a_rules_fn__1094000100_A_Init(); tmp51 = A_arbace_c2a_rules_fn__1094000100_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp12, tmp23, tmp34, tmp43, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp44, tmp45, tmp46, Lit_183, tmp47, tmp48, tmp49, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil))))); var tmp52 *lang.Var = A_arbace_c2a_rules__init_A_const_28; jrt.NN(tmp52).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_29)); return A_arbace_c2a_rules__init_A_const_28.Ref() }
































func A_arbace_c2a_rules__init_A_Unit16__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(159, 1); jrt.NN(A_arbace_c2a_rules__init_A_const_40).BindRoot_O__V(A_arbace_c2a_rules__init_A_const_41); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_40; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_42)); return A_arbace_c2a_rules__init_A_const_40.Ref() }




























func A_arbace_c2a_rules__init_A_Unit17__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(188, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_43; var tmp2 any = A_arbace_c2a_rules_applicable_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_applicable_A_Init(); tmp3 = A_arbace_c2a_rules_applicable_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_44)); return A_arbace_c2a_rules__init_A_const_43.Ref() }




func A_arbace_c2a_rules__init_A_Unit18__O() any { A_arbace_c2a_rules__init_A_Init(); lang.Compiler_AOT_At_I_I__V(193, 1); var tmp1 *lang.Var = A_arbace_c2a_rules__init_A_const_45; var tmp2 any = A_arbace_c2a_rules_translate_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_rules_translate_A_Init(); tmp3 = A_arbace_c2a_rules_translate_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_rules__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_rules__init_A_const_46)); return A_arbace_c2a_rules__init_A_const_45.Ref() }



type A_arbace_c2a_rules__init_A struct{ jrt.Object }

var A_arbace_c2a_rules__init_A_const_0 *lang.Var

var A_arbace_c2a_rules__init_A_const_1 any

var A_arbace_c2a_rules__init_A_const_2 any

var A_arbace_c2a_rules__init_A_const_3 any

var A_arbace_c2a_rules__init_A_const_4 *lang.Var

var A_arbace_c2a_rules__init_A_const_5 any

var A_arbace_c2a_rules__init_A_const_6 *lang.Var

var A_arbace_c2a_rules__init_A_const_7 any

var A_arbace_c2a_rules__init_A_const_8 any

var A_arbace_c2a_rules__init_A_const_9 *lang.Var

var A_arbace_c2a_rules__init_A_const_10 any

var A_arbace_c2a_rules__init_A_const_11 *lang.Var

var A_arbace_c2a_rules__init_A_const_12 any

var A_arbace_c2a_rules__init_A_const_13 *lang.Var

var A_arbace_c2a_rules__init_A_const_14 any

var A_arbace_c2a_rules__init_A_const_15 *lang.Var

var A_arbace_c2a_rules__init_A_const_16 any

var A_arbace_c2a_rules__init_A_const_17 *lang.Var

var A_arbace_c2a_rules__init_A_const_18 any

var A_arbace_c2a_rules__init_A_const_19 *lang.Var

var A_arbace_c2a_rules__init_A_const_20 any

var A_arbace_c2a_rules__init_A_const_21 any

var A_arbace_c2a_rules__init_A_const_22 *lang.Var

var A_arbace_c2a_rules__init_A_const_23 any

var A_arbace_c2a_rules__init_A_const_24 *lang.Var

var A_arbace_c2a_rules__init_A_const_25 any

var A_arbace_c2a_rules__init_A_const_26 *lang.Var

var A_arbace_c2a_rules__init_A_const_27 any

var A_arbace_c2a_rules__init_A_const_28 *lang.Var

var A_arbace_c2a_rules__init_A_const_29 any

var A_arbace_c2a_rules__init_A_const_30 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_31 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_32 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_33 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_34 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_35 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_36 *lang.Var

var A_arbace_c2a_rules__init_A_const_37 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_38 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_39 *lang.Keyword

var A_arbace_c2a_rules__init_A_const_40 *lang.Var

var A_arbace_c2a_rules__init_A_const_41 any

var A_arbace_c2a_rules__init_A_const_42 any

var A_arbace_c2a_rules__init_A_const_43 *lang.Var

var A_arbace_c2a_rules__init_A_const_44 any

var A_arbace_c2a_rules__init_A_const_45 *lang.Var

var A_arbace_c2a_rules__init_A_const_46 any

var A_arbace_c2a_rules__init_A_init jrt.ClassInit

func A_arbace_c2a_rules__init_A_Init() { if !A_arbace_c2a_rules__init_A_init.Done() { A_arbace_c2a_rules__init_A_init.Run(A_arbace_c2a_rules__init_A_clinit) } }

func A_arbace_c2a_rules__init_A_clinit() { A_arbace_c2a_rules__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_127); A_arbace_c2a_rules__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_c2a_rules__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_c2a_rules__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_rules__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_13, Lit_128); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_c2a_rules__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_13, Lit_23); A_arbace_c2a_rules__init_A_const_7 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(jrt.Pattern_Compile_String__Pattern(Lit_136).Ref(), Lit_137), lang.Tuple_Create_O_O__IPersistentVector(jrt.Pattern_Compile_String__Pattern(Lit_138).Ref(), Lit_139)); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_c2a_rules__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_13, Lit_71); A_arbace_c2a_rules__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_141, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_13, Lit_32); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_c2a_rules__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_13, Lit_33); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_c2a_rules__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_13, Lit_74); A_arbace_c2a_rules__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_140)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_145, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_13, Lit_73); A_arbace_c2a_rules__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_146, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(68).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_13, Lit_59); A_arbace_c2a_rules__init_A_const_20 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,12,s4:defns9:definlines9:defrecords8:defmultis12:definterfaces7:defonces11:defprotocols5:defn-s3:defs9:defstructs7:deftypes8:defmacro", []*jrt.Class{jrt.Object_class})).Ref(); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_c2a_rules__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_13, Lit_65); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_c2a_rules__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_140)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_147, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(79).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_13, Lit_62); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_c2a_rules__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_140)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_148).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_149)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_13, Lit_72); A_arbace_c2a_rules__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_140)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_41).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_150, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(98).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_13, Lit_77); A_arbace_c2a_rules__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(126).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_151)); A_arbace_c2a_rules__init_A_const_30 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_c2a_rules__init_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_152); A_arbace_c2a_rules__init_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_14); A_arbace_c2a_rules__init_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_c2a_rules__init_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_c2a_rules__init_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_5); A_arbace_c2a_rules__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_153); A_arbace_c2a_rules__init_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_c2a_rules__init_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_c2a_rules__init_A_const_39 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_c2a_rules__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_13, Lit_154); A_arbace_c2a_rules__init_A_const_41 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_160)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_161, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref())), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_162, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_163)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_164, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_165)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_166, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_167)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_168, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_169)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_170, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_171)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_172, lang.RT_Keyword_String_String__Keyword(nil, Lit_157).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_71).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_159).Ref(), Lit_173)))); A_arbace_c2a_rules__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(159).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_174)); A_arbace_c2a_rules__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_13, Lit_79); A_arbace_c2a_rules__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_175).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_176, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(188).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)); A_arbace_c2a_rules__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_13, Lit_80); A_arbace_c2a_rules__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_130).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_140).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_175).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_132).Ref(), jrt.Integer_ValueOf_I__Integer(193).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), Lit_135)) }

func A_arbace_c2a_rules__init_A_New() *A_arbace_c2a_rules__init_A { A_arbace_c2a_rules__init_A_Init(); t := &A_arbace_c2a_rules__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rules__init_A) Ctor() {}

func (t *A_arbace_c2a_rules__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules__init_A_class }

func (t *A_arbace_c2a_rules__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules__init_A); return ok }

func A_arbace_c2a_rules__init_A_Cast(x any) *A_arbace_c2a_rules__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules__init_A_class)) }; return v }
