//line a2g_classes.ae:1
package aot_arbace_c2a_rules

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_c2a_rules_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_A_New()}; return nil }

var A_arbace_c2a_rules_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rules_A_new}

var A_arbace_c2a_rules_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_A"})

func init() { i := A_arbace_c2a_rules_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_A_InstanceOf; i.Init = A_arbace_c2a_rules_A_Init; i.Table = A_arbace_c2a_rules_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_A_class, reflect.TypeFor[A_arbace_c2a_rules_A]()) }

func A_arbace_c2a_rules_applicable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_applicable_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_applicable_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_applicable_A_New()}; return nil }

func A_arbace_c2a_rules_applicable_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_applicable_A_fn_class)}; return nil }

var A_arbace_c2a_rules_applicable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_applicable_A_invoke, New: A_arbace_c2a_rules_applicable_A_new, Get: A_arbace_c2a_rules_applicable_A_get}

var A_arbace_c2a_rules_applicable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$applicable", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "applicable", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_applicable_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_applicable_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_applicable_A_InstanceOf; i.Init = A_arbace_c2a_rules_applicable_A_Init; i.Table = A_arbace_c2a_rules_applicable_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_applicable_A_class, reflect.TypeFor[A_arbace_c2a_rules_applicable_A]()) }

func A_arbace_c2a_rules_applicable_fn__1094000103_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_applicable_fn__1094000103_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_applicable_fn__1094000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_applicable_fn__1094000103_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_applicable_fn__1094000103_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_applicable_fn__1094000103_A_fn_class)}; return nil }

var A_arbace_c2a_rules_applicable_fn__1094000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_applicable_fn__1094000103_A_invoke, New: A_arbace_c2a_rules_applicable_fn__1094000103_A_new, Get: A_arbace_c2a_rules_applicable_fn__1094000103_A_get}

var A_arbace_c2a_rules_applicable_fn__1094000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$applicable$fn__1094000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_applicable_A_class, Simple: "fn__1094000103", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_applicable_fn__1094000103_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_applicable_fn__1094000103_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_applicable_fn__1094000103_A_InstanceOf; i.Init = A_arbace_c2a_rules_applicable_fn__1094000103_A_Init; i.Table = A_arbace_c2a_rules_applicable_fn__1094000103_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_applicable_fn__1094000103_A_class, reflect.TypeFor[A_arbace_c2a_rules_applicable_fn__1094000103_A]()) }

func A_arbace_c2a_rules_arbace_core_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_arbace_core_names_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rules_arbace_core_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_arbace_core_names_A_New()}; return nil }

func A_arbace_c2a_rules_arbace_core_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_arbace_core_names_A_fn_class)}; return nil }

var A_arbace_c2a_rules_arbace_core_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_arbace_core_names_A_invoke, New: A_arbace_c2a_rules_arbace_core_names_A_new, Get: A_arbace_c2a_rules_arbace_core_names_A_get}

var A_arbace_c2a_rules_arbace_core_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$arbace_core_names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "arbace_core_names", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_arbace_core_names_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_arbace_core_names_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_arbace_core_names_A_InstanceOf; i.Init = A_arbace_c2a_rules_arbace_core_names_A_Init; i.Table = A_arbace_c2a_rules_arbace_core_names_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_arbace_core_names_A_class, reflect.TypeFor[A_arbace_c2a_rules_arbace_core_names_A]()) }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_New()}; return nil }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_fn_class)}; return nil }

var A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_invoke, New: A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_new, Get: A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_get}

var A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$arbace_core_names$fn__1094000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_arbace_core_names_A_class, Simple: "fn__1094000056", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_InstanceOf; i.Init = A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_Init; i.Table = A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_class, reflect.TypeFor[A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A]()) }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_New()}; return nil }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_fn_class)}; return nil }

var A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_invoke, New: A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_new, Get: A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_get}

var A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$arbace_core_names$fn__1094000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_arbace_core_names_A_class, Simple: "fn__1094000058", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_InstanceOf; i.Init = A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_Init; i.Table = A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_class, reflect.TypeFor[A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A]()) }

func A_arbace_c2a_rules_clojure_source_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_clojure_source_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_clojure_source_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_clojure_source_QMARK__A_New()}; return nil }

func A_arbace_c2a_rules_clojure_source_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_clojure_source_QMARK__A_fn_class)}; return nil }

var A_arbace_c2a_rules_clojure_source_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_clojure_source_QMARK__A_invoke, New: A_arbace_c2a_rules_clojure_source_QMARK__A_new, Get: A_arbace_c2a_rules_clojure_source_QMARK__A_get}

var A_arbace_c2a_rules_clojure_source_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$clojure_source_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "clojure_source_QMARK_", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_clojure_source_QMARK__A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_clojure_source_QMARK__A_class.Info(); i.IsInstance = A_arbace_c2a_rules_clojure_source_QMARK__A_InstanceOf; i.Init = A_arbace_c2a_rules_clojure_source_QMARK__A_Init; i.Table = A_arbace_c2a_rules_clojure_source_QMARK__A_members; jrt.RegisterGoType(A_arbace_c2a_rules_clojure_source_QMARK__A_class, reflect.TypeFor[A_arbace_c2a_rules_clojure_source_QMARK__A]()) }

func A_arbace_c2a_rules_core_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_core_names_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_core_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_core_names_A_New()}; return nil }

func A_arbace_c2a_rules_core_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_core_names_A_fn_class)}; return nil }

var A_arbace_c2a_rules_core_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_core_names_A_invoke, New: A_arbace_c2a_rules_core_names_A_new, Get: A_arbace_c2a_rules_core_names_A_get}

var A_arbace_c2a_rules_core_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$core_names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "core_names", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_core_names_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_core_names_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_core_names_A_InstanceOf; i.Init = A_arbace_c2a_rules_core_names_A_Init; i.Table = A_arbace_c2a_rules_core_names_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_core_names_A_class, reflect.TypeFor[A_arbace_c2a_rules_core_names_A]()) }

func A_arbace_c2a_rules_defined_names_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_defined_names_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_defined_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_defined_names_A_New()}; return nil }

func A_arbace_c2a_rules_defined_names_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_defined_names_A_fn_class)}; return nil }

var A_arbace_c2a_rules_defined_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_defined_names_A_invoke, New: A_arbace_c2a_rules_defined_names_A_new, Get: A_arbace_c2a_rules_defined_names_A_get}

var A_arbace_c2a_rules_defined_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$defined_names", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "defined_names", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_defined_names_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_defined_names_A_InstanceOf; i.Init = A_arbace_c2a_rules_defined_names_A_Init; i.Table = A_arbace_c2a_rules_defined_names_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_defined_names_A_class, reflect.TypeFor[A_arbace_c2a_rules_defined_names_A]()) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_New_O(args[0])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_fn_class)}; return nil }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_invoke, New: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_new, Get: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_get}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_defined_names_A_class, Simple: "iter__1094000061__1094000065", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_InstanceOf; i.Init = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_Init; i.Table = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class, reflect.TypeFor[A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A]()) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_fn_class)}; return nil }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_invoke, New: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_new, Get: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_get}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class, Simple: "fn__1094000066", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_InstanceOf; i.Init = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_Init; i.Table = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class, reflect.TypeFor[A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A]()) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_fn_class)}; return nil }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_invoke, New: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_new, Get: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_get}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class, Simple: "fn__1094000067", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_InstanceOf; i.Init = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_Init; i.Table = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class, reflect.TypeFor[A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A]()) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_fn_class)}; return nil }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_invoke, New: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_new, Get: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_get}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067$fn__1094000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class, Simple: "fn__1094000071", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_InstanceOf; i.Init = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_Init; i.Table = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_class, reflect.TypeFor[A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A]()) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_fn_class)}; return nil }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_invoke, New: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_new, Get: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_get}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class, Simple: "fn__1094000077", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_InstanceOf; i.Init = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_Init; i.Table = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_class, reflect.TypeFor[A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A]()) }

func A_arbace_c2a_rules_eval1094000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_eval1094000004_A_New()}; return nil }

var A_arbace_c2a_rules_eval1094000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rules_eval1094000004_A_new}

var A_arbace_c2a_rules_eval1094000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$eval1094000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rules_A_class, Simple: "eval1094000004", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000004_A"})

func init() { i := A_arbace_c2a_rules_eval1094000004_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_eval1094000004_A_InstanceOf; i.Table = A_arbace_c2a_rules_eval1094000004_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_eval1094000004_A_class, reflect.TypeFor[A_arbace_c2a_rules_eval1094000004_A]()) }

func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_New()}; return nil }

func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_fn_class)}; return nil }

var A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_invoke, New: A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_new, Get: A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_get}

var A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$eval1094000004$loading__1927001464__auto____1094000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rules_eval1094000004_A_class, Simple: "loading__1927001464__auto____1094000005", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_InstanceOf; i.Init = A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_Init; i.Table = A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_class, reflect.TypeFor[A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A]()) }

func A_arbace_c2a_rules_eval1094000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_eval1094000008_A_New()}; return nil }

var A_arbace_c2a_rules_eval1094000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rules_eval1094000008_A_new}

var A_arbace_c2a_rules_eval1094000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$eval1094000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rules_A_class, Simple: "eval1094000008", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000008_A"})

func init() { i := A_arbace_c2a_rules_eval1094000008_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_eval1094000008_A_InstanceOf; i.Table = A_arbace_c2a_rules_eval1094000008_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_eval1094000008_A_class, reflect.TypeFor[A_arbace_c2a_rules_eval1094000008_A]()) }

func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_eval1094000008_fn__1094000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_New()}; return nil }

func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_fn_class)}; return nil }

var A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_invoke, New: A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_new, Get: A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_get}

var A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$eval1094000008$fn__1094000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_rules_eval1094000008_A_class, Simple: "fn__1094000009", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000008_fn__1094000009_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_InstanceOf; i.Init = A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_Init; i.Table = A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_class, reflect.TypeFor[A_arbace_c2a_rules_eval1094000008_fn__1094000009_A]()) }

func A_arbace_c2a_rules_fn__1094000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_fn__1094000090_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_fn__1094000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_fn__1094000090_A_New()}; return nil }

func A_arbace_c2a_rules_fn__1094000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_fn__1094000090_A_fn_class)}; return nil }

var A_arbace_c2a_rules_fn__1094000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_fn__1094000090_A_invoke, New: A_arbace_c2a_rules_fn__1094000090_A_new, Get: A_arbace_c2a_rules_fn__1094000090_A_get}

var A_arbace_c2a_rules_fn__1094000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$fn__1094000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "fn__1094000090", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000090_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_fn__1094000090_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_fn__1094000090_A_InstanceOf; i.Init = A_arbace_c2a_rules_fn__1094000090_A_Init; i.Table = A_arbace_c2a_rules_fn__1094000090_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_fn__1094000090_A_class, reflect.TypeFor[A_arbace_c2a_rules_fn__1094000090_A]()) }

func A_arbace_c2a_rules_fn__1094000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_fn__1094000092_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_fn__1094000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_fn__1094000092_A_New()}; return nil }

func A_arbace_c2a_rules_fn__1094000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_fn__1094000092_A_fn_class)}; return nil }

var A_arbace_c2a_rules_fn__1094000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_fn__1094000092_A_invoke, New: A_arbace_c2a_rules_fn__1094000092_A_new, Get: A_arbace_c2a_rules_fn__1094000092_A_get}

var A_arbace_c2a_rules_fn__1094000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$fn__1094000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "fn__1094000092", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000092_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_fn__1094000092_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_fn__1094000092_A_InstanceOf; i.Init = A_arbace_c2a_rules_fn__1094000092_A_Init; i.Table = A_arbace_c2a_rules_fn__1094000092_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_fn__1094000092_A_class, reflect.TypeFor[A_arbace_c2a_rules_fn__1094000092_A]()) }

func A_arbace_c2a_rules_fn__1094000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_fn__1094000094_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_fn__1094000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_fn__1094000094_A_New()}; return nil }

func A_arbace_c2a_rules_fn__1094000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_fn__1094000094_A_fn_class)}; return nil }

var A_arbace_c2a_rules_fn__1094000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_fn__1094000094_A_invoke, New: A_arbace_c2a_rules_fn__1094000094_A_new, Get: A_arbace_c2a_rules_fn__1094000094_A_get}

var A_arbace_c2a_rules_fn__1094000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$fn__1094000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "fn__1094000094", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000094_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_fn__1094000094_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_fn__1094000094_A_InstanceOf; i.Init = A_arbace_c2a_rules_fn__1094000094_A_Init; i.Table = A_arbace_c2a_rules_fn__1094000094_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_fn__1094000094_A_class, reflect.TypeFor[A_arbace_c2a_rules_fn__1094000094_A]()) }

func A_arbace_c2a_rules_fn__1094000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_fn__1094000096_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_fn__1094000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_fn__1094000096_A_New()}; return nil }

func A_arbace_c2a_rules_fn__1094000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_fn__1094000096_A_fn_class)}; return nil }

var A_arbace_c2a_rules_fn__1094000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_fn__1094000096_A_invoke, New: A_arbace_c2a_rules_fn__1094000096_A_new, Get: A_arbace_c2a_rules_fn__1094000096_A_get}

var A_arbace_c2a_rules_fn__1094000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$fn__1094000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "fn__1094000096", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000096_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_fn__1094000096_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_fn__1094000096_A_InstanceOf; i.Init = A_arbace_c2a_rules_fn__1094000096_A_Init; i.Table = A_arbace_c2a_rules_fn__1094000096_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_fn__1094000096_A_class, reflect.TypeFor[A_arbace_c2a_rules_fn__1094000096_A]()) }

func A_arbace_c2a_rules_fn__1094000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_fn__1094000098_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_fn__1094000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_fn__1094000098_A_New()}; return nil }

func A_arbace_c2a_rules_fn__1094000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_fn__1094000098_A_fn_class)}; return nil }

var A_arbace_c2a_rules_fn__1094000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_fn__1094000098_A_invoke, New: A_arbace_c2a_rules_fn__1094000098_A_new, Get: A_arbace_c2a_rules_fn__1094000098_A_get}

var A_arbace_c2a_rules_fn__1094000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$fn__1094000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "fn__1094000098", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000098_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_fn__1094000098_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_fn__1094000098_A_InstanceOf; i.Init = A_arbace_c2a_rules_fn__1094000098_A_Init; i.Table = A_arbace_c2a_rules_fn__1094000098_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_fn__1094000098_A_class, reflect.TypeFor[A_arbace_c2a_rules_fn__1094000098_A]()) }

func A_arbace_c2a_rules_fn__1094000100_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_fn__1094000100_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_fn__1094000100_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_fn__1094000100_A_New()}; return nil }

func A_arbace_c2a_rules_fn__1094000100_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_fn__1094000100_A_fn_class)}; return nil }

var A_arbace_c2a_rules_fn__1094000100_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_fn__1094000100_A_invoke, New: A_arbace_c2a_rules_fn__1094000100_A_new, Get: A_arbace_c2a_rules_fn__1094000100_A_get}

var A_arbace_c2a_rules_fn__1094000100_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$fn__1094000100", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "fn__1094000100", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000100_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_fn__1094000100_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_fn__1094000100_A_InstanceOf; i.Init = A_arbace_c2a_rules_fn__1094000100_A_Init; i.Table = A_arbace_c2a_rules_fn__1094000100_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_fn__1094000100_A_class, reflect.TypeFor[A_arbace_c2a_rules_fn__1094000100_A]()) }

func A_arbace_c2a_rules_imports_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_imports_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_imports_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_imports_QMARK__A_New()}; return nil }

func A_arbace_c2a_rules_imports_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_imports_QMARK__A_fn_class)}; return nil }

var A_arbace_c2a_rules_imports_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_imports_QMARK__A_invoke, New: A_arbace_c2a_rules_imports_QMARK__A_new, Get: A_arbace_c2a_rules_imports_QMARK__A_get}

var A_arbace_c2a_rules_imports_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$imports_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "imports_QMARK_", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_imports_QMARK__A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_imports_QMARK__A_class.Info(); i.IsInstance = A_arbace_c2a_rules_imports_QMARK__A_InstanceOf; i.Init = A_arbace_c2a_rules_imports_QMARK__A_Init; i.Table = A_arbace_c2a_rules_imports_QMARK__A_members; jrt.RegisterGoType(A_arbace_c2a_rules_imports_QMARK__A_class, reflect.TypeFor[A_arbace_c2a_rules_imports_QMARK__A]()) }

func A_arbace_c2a_rules_insert_at_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_insert_at_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_c2a_rules_insert_at_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_insert_at_A_New()}; return nil }

func A_arbace_c2a_rules_insert_at_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_insert_at_A_fn_class)}; return nil }

var A_arbace_c2a_rules_insert_at_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_insert_at_A_invoke, New: A_arbace_c2a_rules_insert_at_A_new, Get: A_arbace_c2a_rules_insert_at_A_get}

var A_arbace_c2a_rules_insert_at_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$insert_at", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "insert_at", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_insert_at_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_insert_at_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_insert_at_A_InstanceOf; i.Init = A_arbace_c2a_rules_insert_at_A_Init; i.Table = A_arbace_c2a_rules_insert_at_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_insert_at_A_class, reflect.TypeFor[A_arbace_c2a_rules_insert_at_A]()) }

func A_arbace_c2a_rules_proxy_methods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_proxy_methods_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_proxy_methods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_proxy_methods_A_New()}; return nil }

func A_arbace_c2a_rules_proxy_methods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_proxy_methods_A_fn_class)}; return nil }

var A_arbace_c2a_rules_proxy_methods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_proxy_methods_A_invoke, New: A_arbace_c2a_rules_proxy_methods_A_new, Get: A_arbace_c2a_rules_proxy_methods_A_get}

var A_arbace_c2a_rules_proxy_methods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$proxy_methods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "proxy_methods", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_proxy_methods_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_proxy_methods_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_proxy_methods_A_InstanceOf; i.Init = A_arbace_c2a_rules_proxy_methods_A_Init; i.Table = A_arbace_c2a_rules_proxy_methods_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_proxy_methods_A_class, reflect.TypeFor[A_arbace_c2a_rules_proxy_methods_A]()) }

func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_proxy_methods_fn__1094000014_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_New()}; return nil }

func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_fn_class)}; return nil }

var A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_invoke, New: A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_new, Get: A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_get}

var A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$proxy_methods$fn__1094000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_proxy_methods_A_class, Simple: "fn__1094000014", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_proxy_methods_fn__1094000014_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_InstanceOf; i.Init = A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_Init; i.Table = A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_class, reflect.TypeFor[A_arbace_c2a_rules_proxy_methods_fn__1094000014_A]()) }

func A_arbace_c2a_rules_security_manager_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_security_manager_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_security_manager_A_New()}; return nil }

func A_arbace_c2a_rules_security_manager_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_security_manager_A_fn_class)}; return nil }

var A_arbace_c2a_rules_security_manager_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_security_manager_A_invoke, New: A_arbace_c2a_rules_security_manager_A_new, Get: A_arbace_c2a_rules_security_manager_A_get}

var A_arbace_c2a_rules_security_manager_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$security_manager", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "security_manager", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_security_manager_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_security_manager_A_InstanceOf; i.Init = A_arbace_c2a_rules_security_manager_A_Init; i.Table = A_arbace_c2a_rules_security_manager_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_security_manager_A_class, reflect.TypeFor[A_arbace_c2a_rules_security_manager_A]()) }

func A_arbace_c2a_rules_security_manager_fn__1094000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_security_manager_fn__1094000030_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_security_manager_fn__1094000030_A_New_O(args[0])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_security_manager_fn__1094000030_A_fn_class)}; return nil }

var A_arbace_c2a_rules_security_manager_fn__1094000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_security_manager_fn__1094000030_A_invoke, New: A_arbace_c2a_rules_security_manager_fn__1094000030_A_new, Get: A_arbace_c2a_rules_security_manager_fn__1094000030_A_get}

var A_arbace_c2a_rules_security_manager_fn__1094000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$security_manager$fn__1094000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_security_manager_A_class, Simple: "fn__1094000030", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000030_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_security_manager_fn__1094000030_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_security_manager_fn__1094000030_A_InstanceOf; i.Init = A_arbace_c2a_rules_security_manager_fn__1094000030_A_Init; i.Table = A_arbace_c2a_rules_security_manager_fn__1094000030_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_security_manager_fn__1094000030_A_class, reflect.TypeFor[A_arbace_c2a_rules_security_manager_fn__1094000030_A]()) }

func A_arbace_c2a_rules_security_manager_fn__1094000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_security_manager_fn__1094000036_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_security_manager_fn__1094000036_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_security_manager_fn__1094000036_A_fn_class)}; return nil }

var A_arbace_c2a_rules_security_manager_fn__1094000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_security_manager_fn__1094000036_A_invoke, New: A_arbace_c2a_rules_security_manager_fn__1094000036_A_new, Get: A_arbace_c2a_rules_security_manager_fn__1094000036_A_get}

var A_arbace_c2a_rules_security_manager_fn__1094000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$security_manager$fn__1094000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_security_manager_A_class, Simple: "fn__1094000036", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000036_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_security_manager_fn__1094000036_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_security_manager_fn__1094000036_A_InstanceOf; i.Init = A_arbace_c2a_rules_security_manager_fn__1094000036_A_Init; i.Table = A_arbace_c2a_rules_security_manager_fn__1094000036_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_security_manager_fn__1094000036_A_class, reflect.TypeFor[A_arbace_c2a_rules_security_manager_fn__1094000036_A]()) }

func A_arbace_c2a_rules_security_manager_fn__1094000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_security_manager_fn__1094000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_security_manager_fn__1094000042_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_security_manager_fn__1094000042_A_fn_class)}; return nil }

var A_arbace_c2a_rules_security_manager_fn__1094000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_security_manager_fn__1094000042_A_invoke, New: A_arbace_c2a_rules_security_manager_fn__1094000042_A_new, Get: A_arbace_c2a_rules_security_manager_fn__1094000042_A_get}

var A_arbace_c2a_rules_security_manager_fn__1094000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$security_manager$fn__1094000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_security_manager_A_class, Simple: "fn__1094000042", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000042_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_security_manager_fn__1094000042_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_security_manager_fn__1094000042_A_InstanceOf; i.Init = A_arbace_c2a_rules_security_manager_fn__1094000042_A_Init; i.Table = A_arbace_c2a_rules_security_manager_fn__1094000042_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_security_manager_fn__1094000042_A_class, reflect.TypeFor[A_arbace_c2a_rules_security_manager_fn__1094000042_A]()) }

func A_arbace_c2a_rules_security_manager_fn__1094000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_security_manager_fn__1094000048_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_security_manager_fn__1094000048_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_fn__1094000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_security_manager_fn__1094000048_A_fn_class)}; return nil }

var A_arbace_c2a_rules_security_manager_fn__1094000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_security_manager_fn__1094000048_A_invoke, New: A_arbace_c2a_rules_security_manager_fn__1094000048_A_new, Get: A_arbace_c2a_rules_security_manager_fn__1094000048_A_get}

var A_arbace_c2a_rules_security_manager_fn__1094000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$security_manager$fn__1094000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_security_manager_A_class, Simple: "fn__1094000048", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000048_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_security_manager_fn__1094000048_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_security_manager_fn__1094000048_A_InstanceOf; i.Init = A_arbace_c2a_rules_security_manager_fn__1094000048_A_Init; i.Table = A_arbace_c2a_rules_security_manager_fn__1094000048_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_security_manager_fn__1094000048_A_class, reflect.TypeFor[A_arbace_c2a_rules_security_manager_fn__1094000048_A]()) }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_New_O(args[0])}; return nil }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_fn_class)}; return nil }

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_invoke, New: A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_new, Get: A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_get}

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$security_manager$in_import_QMARK___1094000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_security_manager_A_class, Simple: "in_import_QMARK___1094000021", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_InstanceOf; i.Init = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_Init; i.Table = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class, reflect.TypeFor[A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A]()) }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_New_O(args[0])}; return nil }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_fn_class)}; return nil }

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_invoke, New: A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_new, Get: A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_get}

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$security_manager$in_import_QMARK___1094000021$fn__1094000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class, Simple: "fn__1094000023", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_InstanceOf; i.Init = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_Init; i.Table = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_class, reflect.TypeFor[A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A]()) }

func A_arbace_c2a_rules_translate_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_translate_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_c2a_rules_translate_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_c2a_rules_translate_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_translate_A_New()}; return nil }

func A_arbace_c2a_rules_translate_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_translate_A_fn_class)}; return nil }

var A_arbace_c2a_rules_translate_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_translate_A_invoke, New: A_arbace_c2a_rules_translate_A_new, Get: A_arbace_c2a_rules_translate_A_get}

var A_arbace_c2a_rules_translate_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$translate", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_A_class, Simple: "translate", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_translate_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_translate_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_translate_A_InstanceOf; i.Init = A_arbace_c2a_rules_translate_A_Init; i.Table = A_arbace_c2a_rules_translate_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_translate_A_class, reflect.TypeFor[A_arbace_c2a_rules_translate_A]()) }

func A_arbace_c2a_rules_translate_fn__1094000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_rules_translate_fn__1094000106_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_rules_translate_fn__1094000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_translate_fn__1094000106_A_New_O(args[0])}; return nil }

func A_arbace_c2a_rules_translate_fn__1094000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_rules_translate_fn__1094000106_A_fn_class)}; return nil }

var A_arbace_c2a_rules_translate_fn__1094000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_rules_translate_fn__1094000106_A_invoke, New: A_arbace_c2a_rules_translate_fn__1094000106_A_new, Get: A_arbace_c2a_rules_translate_fn__1094000106_A_get}

var A_arbace_c2a_rules_translate_fn__1094000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$translate$fn__1094000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_rules_translate_A_class, Simple: "fn__1094000106", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_translate_fn__1094000106_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules_translate_fn__1094000106_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_translate_fn__1094000106_A_InstanceOf; i.Init = A_arbace_c2a_rules_translate_fn__1094000106_A_Init; i.Table = A_arbace_c2a_rules_translate_fn__1094000106_A_members; jrt.RegisterGoType(A_arbace_c2a_rules_translate_fn__1094000106_A_class, reflect.TypeFor[A_arbace_c2a_rules_translate_fn__1094000106_A]()) }

func A_arbace_c2a_rules__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_rules__init_A_Load__O(); case 1: return A_arbace_c2a_rules__init_A_Unit0__O(); case 2: return A_arbace_c2a_rules__init_A_Unit1__O(); case 3: return A_arbace_c2a_rules__init_A_Unit10__O(); case 4: return A_arbace_c2a_rules__init_A_Unit11__O(); case 5: return A_arbace_c2a_rules__init_A_Unit12__O(); case 6: return A_arbace_c2a_rules__init_A_Unit13__O(); case 7: return A_arbace_c2a_rules__init_A_Unit14__O(); case 8: return A_arbace_c2a_rules__init_A_Unit15__O(); case 9: return A_arbace_c2a_rules__init_A_Unit16__O(); case 10: return A_arbace_c2a_rules__init_A_Unit17__O(); case 11: return A_arbace_c2a_rules__init_A_Unit18__O(); case 12: return A_arbace_c2a_rules__init_A_Unit2__O(); case 13: return A_arbace_c2a_rules__init_A_Unit3__O(); case 14: return A_arbace_c2a_rules__init_A_Unit4__O(); case 15: return A_arbace_c2a_rules__init_A_Unit5__O(); case 16: return A_arbace_c2a_rules__init_A_Unit6__O(); case 17: return A_arbace_c2a_rules__init_A_Unit7__O(); case 18: return A_arbace_c2a_rules__init_A_Unit8__O(); case 19: return A_arbace_c2a_rules__init_A_Unit9__O()}; return nil }

func A_arbace_c2a_rules__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules__init_A_New()}; return nil }

var A_arbace_c2a_rules__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_rules__init_A_invoke, New: A_arbace_c2a_rules__init_A_new}

var A_arbace_c2a_rules__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules__init_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules__init_A_class.Info(); i.IsInstance = A_arbace_c2a_rules__init_A_InstanceOf; i.Init = A_arbace_c2a_rules__init_A_Init; i.Table = A_arbace_c2a_rules__init_A_members; jrt.RegisterGoType(A_arbace_c2a_rules__init_A_class, reflect.TypeFor[A_arbace_c2a_rules__init_A]()) }
