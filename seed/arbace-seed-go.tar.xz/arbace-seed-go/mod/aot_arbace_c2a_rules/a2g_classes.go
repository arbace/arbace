//line a2g_classes.ae:1
package aot_arbace_c2a_rules

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c2a_rules_applicable_A_class, Name: "arbace.c2a.rules$applicable", Modifiers: 25, Simple: "applicable", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_applicable_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_applicable_fn__1094000103_A_class, Name: "arbace.c2a.rules$applicable$fn__1094000103", Modifiers: 25, Simple: "fn__1094000103", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_applicable_fn__1094000103_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_applicable_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_arbace_core_names_A_class, Name: "arbace.c2a.rules$arbace_core_names", Modifiers: 25, Simple: "arbace_core_names", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_arbace_core_names_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_class, Name: "arbace.c2a.rules$arbace_core_names$fn__1094000056", Modifiers: 25, Simple: "fn__1094000056", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_arbace_core_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_class, Name: "arbace.c2a.rules$arbace_core_names$fn__1094000058", Modifiers: 25, Simple: "fn__1094000058", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_arbace_core_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_clojure_source_QMARK__A_class, Name: "arbace.c2a.rules$clojure_source_QMARK_", Modifiers: 25, Simple: "clojure_source_QMARK_", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_clojure_source_QMARK__A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_core_names_A_class, Name: "arbace.c2a.rules$core_names", Modifiers: 25, Simple: "core_names", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_core_names_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_defined_names_A_class, Name: "arbace.c2a.rules$defined_names", Modifiers: 25, Simple: "defined_names", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class, Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065", Modifiers: 25, Simple: "iter__1094000061__1094000065", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_defined_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class, Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066", Modifiers: 25, Simple: "fn__1094000066", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class, Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067", Modifiers: 25, Simple: "fn__1094000067", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_class, Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067$fn__1094000071", Modifiers: 25, Simple: "fn__1094000071", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_class, Name: "arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000077", Modifiers: 25, Simple: "fn__1094000077", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_class, Name: "arbace.c2a.rules$eval1094000004$loading__1927001464__auto____1094000005", Modifiers: 25, Simple: "loading__1927001464__auto____1094000005", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_eval1094000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_class, Name: "arbace.c2a.rules$eval1094000008$fn__1094000009", Modifiers: 25, Simple: "fn__1094000009", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000008_fn__1094000009_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_eval1094000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_fn__1094000090_A_class, Name: "arbace.c2a.rules$fn__1094000090", Modifiers: 25, Simple: "fn__1094000090", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000090_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_fn__1094000092_A_class, Name: "arbace.c2a.rules$fn__1094000092", Modifiers: 25, Simple: "fn__1094000092", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000092_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_fn__1094000094_A_class, Name: "arbace.c2a.rules$fn__1094000094", Modifiers: 25, Simple: "fn__1094000094", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000094_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_fn__1094000096_A_class, Name: "arbace.c2a.rules$fn__1094000096", Modifiers: 25, Simple: "fn__1094000096", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000096_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_fn__1094000098_A_class, Name: "arbace.c2a.rules$fn__1094000098", Modifiers: 25, Simple: "fn__1094000098", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000098_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_fn__1094000100_A_class, Name: "arbace.c2a.rules$fn__1094000100", Modifiers: 25, Simple: "fn__1094000100", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_fn__1094000100_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_imports_QMARK__A_class, Name: "arbace.c2a.rules$imports_QMARK_", Modifiers: 25, Simple: "imports_QMARK_", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_imports_QMARK__A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_insert_at_A_class, Name: "arbace.c2a.rules$insert_at", Modifiers: 25, Simple: "insert_at", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_insert_at_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_proxy_methods_A_class, Name: "arbace.c2a.rules$proxy_methods", Modifiers: 25, Simple: "proxy_methods", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_proxy_methods_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_class, Name: "arbace.c2a.rules$proxy_methods$fn__1094000014", Modifiers: 25, Simple: "fn__1094000014", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_proxy_methods_fn__1094000014_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_proxy_methods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_security_manager_A_class, Name: "arbace.c2a.rules$security_manager", Modifiers: 25, Simple: "security_manager", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_security_manager_fn__1094000030_A_class, Name: "arbace.c2a.rules$security_manager$fn__1094000030", Modifiers: 25, Simple: "fn__1094000030", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000030_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_security_manager_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_security_manager_fn__1094000036_A_class, Name: "arbace.c2a.rules$security_manager$fn__1094000036", Modifiers: 25, Simple: "fn__1094000036", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000036_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_security_manager_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_security_manager_fn__1094000042_A_class, Name: "arbace.c2a.rules$security_manager$fn__1094000042", Modifiers: 25, Simple: "fn__1094000042", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000042_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_security_manager_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_security_manager_fn__1094000048_A_class, Name: "arbace.c2a.rules$security_manager$fn__1094000048", Modifiers: 25, Simple: "fn__1094000048", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_fn__1094000048_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_security_manager_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class, Name: "arbace.c2a.rules$security_manager$in_import_QMARK___1094000021", Modifiers: 25, Simple: "in_import_QMARK___1094000021", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_security_manager_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_class, Name: "arbace.c2a.rules$security_manager$in_import_QMARK___1094000021$fn__1094000023", Modifiers: 25, Simple: "fn__1094000023", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_translate_A_class, Name: "arbace.c2a.rules$translate", Modifiers: 25, Simple: "translate", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_translate_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_rules_translate_fn__1094000106_A_class, Name: "arbace.c2a.rules$translate$fn__1094000106", Modifiers: 25, Simple: "fn__1094000106", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_translate_fn__1094000106_A", Source: "rules.ae", Declaring: &A_arbace_c2a_rules_translate_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_c2a_rules_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_A_New()}; return nil }

var A_arbace_c2a_rules_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rules_A_new}

var A_arbace_c2a_rules_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_A"})

func init() { i := A_arbace_c2a_rules_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_A_InstanceOf; i.Init = A_arbace_c2a_rules_A_Init; i.Table = A_arbace_c2a_rules_A_members }

var A_arbace_c2a_rules_applicable_A_class *jrt.Class

var A_arbace_c2a_rules_applicable_fn__1094000103_A_class *jrt.Class

var A_arbace_c2a_rules_arbace_core_names_A_class *jrt.Class

var A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_class *jrt.Class

var A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_class *jrt.Class

var A_arbace_c2a_rules_clojure_source_QMARK__A_class *jrt.Class

var A_arbace_c2a_rules_core_names_A_class *jrt.Class

var A_arbace_c2a_rules_defined_names_A_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_class *jrt.Class

func A_arbace_c2a_rules_eval1094000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_eval1094000004_A_New()}; return nil }

var A_arbace_c2a_rules_eval1094000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rules_eval1094000004_A_new}

var A_arbace_c2a_rules_eval1094000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$eval1094000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rules_A_class, Simple: "eval1094000004", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000004_A"})

func init() { i := A_arbace_c2a_rules_eval1094000004_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_eval1094000004_A_InstanceOf; i.Table = A_arbace_c2a_rules_eval1094000004_A_members }

var A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_class *jrt.Class

func A_arbace_c2a_rules_eval1094000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules_eval1094000008_A_New()}; return nil }

var A_arbace_c2a_rules_eval1094000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_rules_eval1094000008_A_new}

var A_arbace_c2a_rules_eval1094000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules$eval1094000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_rules_A_class, Simple: "eval1094000008", Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules_eval1094000008_A"})

func init() { i := A_arbace_c2a_rules_eval1094000008_A_class.Info(); i.IsInstance = A_arbace_c2a_rules_eval1094000008_A_InstanceOf; i.Table = A_arbace_c2a_rules_eval1094000008_A_members }

var A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000090_A_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000092_A_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000094_A_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000096_A_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000098_A_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000100_A_class *jrt.Class

var A_arbace_c2a_rules_imports_QMARK__A_class *jrt.Class

var A_arbace_c2a_rules_insert_at_A_class *jrt.Class

var A_arbace_c2a_rules_proxy_methods_A_class *jrt.Class

var A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_class *jrt.Class

var A_arbace_c2a_rules_security_manager_A_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000030_A_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000036_A_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000042_A_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000048_A_class *jrt.Class

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class *jrt.Class

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_class *jrt.Class

var A_arbace_c2a_rules_translate_A_class *jrt.Class

var A_arbace_c2a_rules_translate_fn__1094000106_A_class *jrt.Class

func A_arbace_c2a_rules__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_rules__init_A_Load__O()}; return nil }

func A_arbace_c2a_rules__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_rules__init_A_New()}; return nil }

var A_arbace_c2a_rules__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_rules__init_A_invoke, New: A_arbace_c2a_rules__init_A_new}

var A_arbace_c2a_rules__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.rules__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_rules.A_arbace_c2a_rules__init_A", Source: "rules.ae"})

func init() { i := A_arbace_c2a_rules__init_A_class.Info(); i.IsInstance = A_arbace_c2a_rules__init_A_InstanceOf; i.Init = A_arbace_c2a_rules__init_A_Init; i.Table = A_arbace_c2a_rules__init_A_members }
