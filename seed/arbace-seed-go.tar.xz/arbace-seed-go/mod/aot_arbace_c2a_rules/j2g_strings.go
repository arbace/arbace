//line j2g_strings.ae:1
package aot_arbace_c2a_rules

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn17,arbace.c2a.renamekn2,asyn6,renameyn15,arbace.c2a.textyn4,textyn13,arbace.stringyn3,strkn3,dockn4,cljckn3,cljkn4,kindkn5,addedkn4,elsekn5,to-aekn8,featureskn10,core-nameskn7,applieskn2,idkn7,rewritev11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.c2a.rulesm2,R8,s847,c2a's rules: the table of rewrites that translate Clojure source into Arbace source\n  (doc/C2A.md), and the dialect divergences they come from (doc/VENDOR-NOTES.md, \"Dialect\n  divergences\"), each with the rule that answers it or why none can.\n\n  A rule is a map:\n    :id       a keyword, its name on the command line (--skip ID)\n    :doc      what it rewrites\n    :applies  (fn [ctx]) whether it applies to a file; ctx holds :kind (:clj, :cljc, :java or\n              :text: a file renamed as text only), :to-ae (the file becomes a .ae file),\n              :features (the reader's platform features, #{:clj}) and :path\n    :rewrite  (fn [text ctx]) the file's new text\n  The rules apply in the table's order. Adding a rule (a later divergence of the dialects) is\n  adding an entry here, a unit test (test/c2a/c2a_test.ae) and a line in doc/C2A.md.v11,arbace.core13,*loaded-libs*v11,arbace.core9,contains?S2,R9,R10,R11,v11,arbace.core6,reducev13,arbace.string7,replacev16,arbace.c2a.rules11,proxy-namesS2,s6,imports7,:importv11,arbace.core3,notv15,arbace.c2a.text10,list-spansv11,arbace.core4,somev11,arbace.core6,filterv11,arbace.core6,empty?v11,arbace.core3,strv13,arbace.string9,includes?v16,arbace.c2a.rules2,smv16,arbace.c2a.rules8,imports?v11,arbace.core4,subsv15,arbace.c2a.text11,code-tokensv13,arbace.string12,starts-with?l0,v11,arbace.core4,intov11,arbace.core4,compv11,arbace.core4,valsv11,arbace.core3,mapR12,v11,arbace.core4,namev11,arbace.core10,ns-publicsR0,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv15,arbace.c2a.text7,skip-wsc94,R13,v15,arbace.c2a.text9,token-endv15,arbace.c2a.text8,form-endv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv16,arbace.c2a.rules9,def-headsv11,arbace.core4,sortv13,arbace.string4,joinv16,arbace.c2a.rules9,insert-atv13,arbace.string8,index-ofv11,arbace.core8,distinctv16,arbace.c2a.rules13,defined-namesS1,s2,nsS1,s14,:refer-clojureR9,R14,v15,arbace.c2a.text20,resolve-conditionalsR15,v17,arbace.c2a.rename6,renamev16,arbace.c2a.rules13,proxy-methodsv16,arbace.c2a.rules10,core-namesR16,v16,arbace.c2a.rules17,arbace-core-namesv16,arbace.c2a.rules16,security-managerR17,R18,v16,arbace.c2a.rules5,rulesR19,v16,arbace.c2a.rules10,applicablev16,arbace.c2a.rules9,translate")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2a.rules$applicable$fn__1094000103")

var Lit_2 *jrt.String = jrt.Intern("arbace.c2a.rules$arbace_core_names$fn__1094000056")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2a.rules$arbace_core_names$fn__1094000058")

var Lit_4 *jrt.String = jrt.Intern("arbace")

var Lit_5 *jrt.String = jrt.Intern(" ")

var Lit_6 *jrt.String = jrt.Intern("\n  (:refer-clojure :exclude [")

var Lit_7 *jrt.String = jrt.Intern("])")

var Lit_8 *jrt.String = jrt.Intern(":only")

var Lit_9 *jrt.String = jrt.Intern(":exclude")

var Lit_10 *jrt.String = jrt.Intern(" :exclude [")

var Lit_11 *jrt.String = jrt.Intern("]")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000077")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067$fn__1094000071")

var Lit_17 *jrt.String = jrt.Intern("#^")

var Lit_18 *jrt.String = jrt.Intern("arbace.c2a.rules$proxy_methods$fn__1094000014")

var Lit_19 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$in_import_QMARK___1094000021")

var Lit_20 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000030")

var Lit_21 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000036")

var Lit_22 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000042")

var Lit_23 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000048")

var Lit_24 *jrt.String = jrt.Intern("java.lang.")

var Lit_25 *jrt.String = jrt.Intern(".")

var Lit_26 *jrt.String = jrt.Intern("/")

var Lit_27 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$in_import_QMARK___1094000021$fn__1094000023")

var Lit_28 *jrt.String = jrt.Intern("arbace.c2a.rules$translate$fn__1094000106")

var Lit_29 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,ctxkn4,linekn6,columnkn4,fileyn1,syn4,headkn3,tagyn6,Stringyn1,iyn5,addedkn2,idkn19,reader-conditionalskn7,applieskn7,rewritekn6,renamekn13,proxy-methodskn10,core-nameskn16,security-managerkn10,divergencekn4,rulekn4,nonekn3,whyyn4,skipv11,arbace.core5,in-nsMyn16,arbace.c2a.rulesm2,R0,s847,c2a's rules: the table of rewrites that translate Clojure source into Arbace source\n  (doc/C2A.md), and the dialect divergences they come from (doc/VENDOR-NOTES.md, \"Dialect\n  divergences\"), each with the rule that answers it or why none can.\n\n  A rule is a map:\n    :id       a keyword, its name on the command line (--skip ID)\n    :doc      what it rewrites\n    :applies  (fn [ctx]) whether it applies to a file; ctx holds :kind (:clj, :cljc, :java or\n              :text: a file renamed as text only), :to-ae (the file becomes a .ae file),\n              :features (the reader's platform features, #{:clj}) and :path\n    :rewrite  (fn [text ctx]) the file's new text\n  The rules apply in the table's order. Adding a rule (a later divergence of the dialects) is\n  adding an entry here, a unit test (test/c2a/c2a_test.ae) and a line in doc/C2A.md.m2,R0,s847,c2a's rules: the table of rewrites that translate Clojure source into Arbace source\n  (doc/C2A.md), and the dialect divergences they come from (doc/VENDOR-NOTES.md, \"Dialect\n  divergences\"), each with the rule that answers it or why none can.\n\n  A rule is a map:\n    :id       a keyword, its name on the command line (--skip ID)\n    :doc      what it rewrites\n    :applies  (fn [ctx]) whether it applies to a file; ctx holds :kind (:clj, :cljc, :java or\n              :text: a file renamed as text only), :to-ae (the file becomes a .ae file),\n              :features (the reader's platform features, #{:clj}) and :path\n    :rewrite  (fn [text ctx]) the file's new text\n  The rules apply in the table's order. Adding a rule (a later divergence of the dialects) is\n  adding an entry here, a unit test (test/c2a/c2a_test.ae) and a line in doc/C2A.md.R1,v16,arbace.c2a.rules15,clojure-source?m10,R2,TR3,L1,V1,R4,R5,i19,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules11,proxy-namesV2,V2,p55,(?<![\\w$])__(init|update|get)ClojureFnMappings(?![\\w$])s20,__$1ArbaceFnMappingsV2,p33,(?<![\\w$])__clojureFnMap(?![\\w$])s13,__arbaceFnMapm8,R2,TR5,i23,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules13,proxy-methodsm10,R3,L1,V1,R8,R0,s71,The methods every proxy class has, and its field, as Arbace names them.R5,i27,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules2,smm8,R2,TR5,i34,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules8,imports?m10,R2,TR3,L1,V1,R9,R5,i36,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules16,security-managerm10,R3,L1,V1,Myn1,sm2,R10,R11,R0,s169,Unqualified uses of the class SecurityManager qualified as java.lang.SecurityManager, which\n  Arbace does not import by default; a file that imports it is left as it is.R5,i38,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules17,arbace-core-namesm10,R3,L1,V0,R0,s150,The public names arbace.core has and clojure.core has not (their metadata says\n  {:added \"arbace\"}: the Java forms' macros and operators), as strings.R5,i68,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules9,def-headsS12,s4,defns9,definlines9,defrecords8,defmultis12,definterfaces7,defonces11,defprotocols5,defn-s3,defs9,defstructs7,deftypes8,defmacrom8,R2,TR5,i75,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules13,defined-namesm12,R2,TR3,L1,V1,Myn1,sm2,R10,R11,R0,s85,The names the def forms of s define (the token after the head, its metadata skipped).R5,i79,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules9,insert-atm10,R2,TR3,L1,V3,Myn1,sm2,R10,R11,R12,Myn1,xm2,R10,R11,R5,i96,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules10,core-namesm10,R3,L1,V2,Myn1,sm2,R10,R11,R13,R0,s384,The names arbace.core adds (`added`, a set of strings) that the file defines, excluded from\n  its ns form's :refer-clojure, so they replace nothing (Arbace would warn \"return already\n  refers to: #'arbace.core/return\" and replace it): added to an :exclude, or a\n  (:refer-clojure :exclude [...]) added. A file without an ns form, or whose :refer-clojure\n  has :only, is left as it is.R5,i98,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules5,rulesm8,R5,i126,R6,i1,R7,s19,arbace/c2a/rules.aeR0,s35,The rules, in the order they apply.R14,R15,R0,R16,R17,R18,v11,arbace.core10,constantlyR19,R20,R21,v16,arbace.c2a.rules11,divergencesV8,m6,R22,s55,reduce without an init on an IReduceInit-only reducibleR23,R24,R25,s78,Arbace reduces what upstream rejects: code that runs on Clojure runs the same.m4,R22,s39,SecurityManager is not a default importR23,R21,m6,R22,s33,A multimethod's ambiguity messageR23,R24,R25,s85,A message's wording; code does not depend on it (a test comparing it must be edited).m6,R22,s38,bean ignores explicit BeanInfo classesR23,R24,R25,s62,What bean returns at run time; nothing in the source names it.m6,R22,s51,Optional modules (java.sql, java.xml, java.desktop)R23,R24,R25,s160,The JVM's runtime image, not the source (on arbace-for-java-26; on main since S4 the\n         three namespaces are removed, VENDOR-NOTES.md, \"Without the JVM\").m6,R22,s20,Source files are .aeR23,R15,R25,s133,c2a writes .ae files (a .cljc file's conditionals resolved); source paths of the\n         vendored namespaces are renamed by :rename.m6,R22,s61,Names arbace.core adds (the Java forms' macros and operators)R23,R20,R25,s81,A file defining one of them gets them excluded from its ns form's :refer-clojure.m6,R22,s66,Runtime-visible names (threads, error report files, proxy methods)R23,R19,R25,s150,The proxy methods and field are names code calls; thread names and report file\n         prefixes are data in strings, left alone (doc/C2A.md, limits).m8,R5,i159,R6,i1,R7,s19,arbace/c2a/rules.aeR0,s132,The dialect divergences of doc/VENDOR-NOTES.md, in its order: the rule answering each, or\n  :none and why no source rewrite applies.v16,arbace.c2a.rules10,applicablem10,R3,L1,V2,R4,R26,R0,s72,The rules that apply to a file, without the skipped ones (a set of ids).R5,i189,R6,i1,R7,s19,arbace/c2a/rules.aev16,arbace.c2a.rules9,translatem10,R3,L2,V2,R8,R4,V3,R8,R4,R26,R0,s109,Text s of a file translated by the rules that apply (ctx: see the namespace's doc), minus\n  the skipped ones.R5,i194,R6,i1,R7,s19,arbace/c2a/rules.ae")

var Lit_30 *jrt.String = jrt.Intern("arbace.c2a.rules$eval1094000004$loading__1927001464__auto____1094000005")

var Lit_31 *jrt.String = jrt.Intern("arbace.c2a.rules$eval1094000008$fn__1094000009")

var Lit_32 *jrt.String = jrt.Intern("arbace.c2a.rules$clojure_source_QMARK_")

var Lit_33 *jrt.String = jrt.Intern("arbace.c2a.rules$proxy_methods")

var Lit_34 *jrt.String = jrt.Intern("SecurityManager")

var Lit_35 *jrt.String = jrt.Intern("arbace.c2a.rules$imports_QMARK_")

var Lit_36 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager")

var Lit_37 *jrt.String = jrt.Intern("arbace.c2a.rules$arbace_core_names")

var Lit_38 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names")

var Lit_39 *jrt.String = jrt.Intern("arbace.c2a.rules$insert_at")

var Lit_40 *jrt.String = jrt.Intern("arbace.c2a.rules$core_names")

var Lit_41 *jrt.String = jrt.Intern("A .cljc file becoming a .ae file: each reader conditional (#?, #?@) replaced by the\n         text of the branch the reader selects on Arbace (features #{:clj}, then :default),\n         spliced for #?@, or by nothing; a .ae file is read without conditionals.")

var Lit_42 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000090")

var Lit_43 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000092")

var Lit_44 *jrt.String = jrt.Intern("The names of the vendored Clojure: clojure.* -> arbace.* for its namespaces, the\n         Java packages clojure.lang, clojure.asm (with commons, signature), clojure.java.api,\n         the keyword namespace clojure.error, the system properties clojure.*, spec; and\n         source paths clojure/<ns>.clj -> arbace/<ns>.ae (arbace.c2a.rename).")

var Lit_45 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000094")

var Lit_46 *jrt.String = jrt.Intern("A proxy's methods __initClojureFnMappings, __updateClojureFnMappings,\n         __getClojureFnMappings and its field __clojureFnMap: __initArbaceFnMappings and the\n         rest, __arbaceFnMap (VENDOR-NOTES.md, hand change 2).")

var Lit_47 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000096")

var Lit_48 *jrt.String = jrt.Intern("Names arbace.core adds to Clojure's core (the Java forms' macros and operators:\n         return, switch, label, lambda, ...) that a file defines: excluded in its ns form's\n         :refer-clojure, as a library does for a core name it redefines.")

var Lit_49 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000098")

var Lit_50 *jrt.String = jrt.Intern("SecurityManager unqualified -> java.lang.SecurityManager (not a default import in\n         Arbace, VENDOR-NOTES.md, hand change 11), unless the file imports it.")

var Lit_51 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000100")

var Lit_52 *jrt.String = jrt.Intern("arbace.c2a.rules$applicable")

var Lit_53 *jrt.String = jrt.Intern("arbace.c2a.rules$translate")
