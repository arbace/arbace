//line a2g_strings.ae:1
package aot_arbace_c2a_rules

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2a.rename")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("rename")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2a.text")

var Lit_7 *jrt.String = jrt.Intern("text")

var Lit_8 *jrt.String = jrt.Intern("arbace.string")

var Lit_9 *jrt.String = jrt.Intern("str")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2a.rules")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("c2a's rules: the table of rewrites that translate Clojure source into Arbace source\n  (doc/C2A.md), and the dialect divergences they come from (doc/VENDOR-NOTES.md, \"Dialect\n  divergences\"), each with the rule that answers it or why none can.\n\n  A rule is a map:\n    :id       a keyword, its name on the command line (--skip ID)\n    :doc      what it rewrites\n    :applies  (fn [ctx]) whether it applies to a file; ctx holds :kind (:clj, :cljc, :java or\n              :text: a file renamed as text only), :to-ae (the file becomes a .ae file),\n              :features (the reader's platform features, #{:clj}) and :path\n    :rewrite  (fn [text ctx]) the file's new text\n  The rules apply in the table's order. Adding a rule (a later divergence of the dialects) is\n  adding an entry here, a unit test (test/c2a/c2a_test.ae) and a line in doc/C2A.md.")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("contains?")

var Lit_18 *jrt.String = jrt.Intern("cljc")

var Lit_19 *jrt.String = jrt.Intern("clj")

var Lit_20 *jrt.String = jrt.Intern("kind")

var Lit_21 *jrt.String = jrt.Intern("reduce")

var Lit_22 *jrt.String = jrt.Intern("replace")

var Lit_23 *jrt.String = jrt.Intern("proxy-names")

var Lit_24 *jrt.String = jrt.Intern("import")

var Lit_25 *jrt.String = jrt.Intern(":import")

var Lit_26 *jrt.String = jrt.Intern("not")

var Lit_27 *jrt.String = jrt.Intern("list-spans")

var Lit_28 *jrt.String = jrt.Intern("some")

var Lit_29 *jrt.String = jrt.Intern("filter")

var Lit_30 *jrt.String = jrt.Intern("empty?")

var Lit_31 *jrt.String = jrt.Intern("includes?")

var Lit_32 *jrt.String = jrt.Intern("sm")

var Lit_33 *jrt.String = jrt.Intern("imports?")

var Lit_34 *jrt.String = jrt.Intern("subs")

var Lit_35 *jrt.String = jrt.Intern("code-tokens")

var Lit_36 *jrt.String = jrt.Intern("starts-with?")

var Lit_37 *jrt.String = jrt.Intern("into")

var Lit_38 *jrt.String = jrt.Intern("comp")

var Lit_39 *jrt.String = jrt.Intern("vals")

var Lit_40 *jrt.String = jrt.Intern("map")

var Lit_41 *jrt.String = jrt.Intern("added")

var Lit_42 *jrt.String = jrt.Intern("name")

var Lit_43 *jrt.String = jrt.Intern("ns-publics")

var Lit_44 *jrt.String = jrt.Intern("seq")

var Lit_45 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_46 *jrt.String = jrt.Intern("chunk-first")

var Lit_47 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_48 *jrt.String = jrt.Intern("skip-ws")

var Lit_49 *jrt.String = jrt.Intern("else")

var Lit_50 *jrt.String = jrt.Intern("token-end")

var Lit_51 *jrt.String = jrt.Intern("form-end")

var Lit_52 *jrt.String = jrt.Intern("chunk-append")

var Lit_53 *jrt.String = jrt.Intern("chunk-cons")

var Lit_54 *jrt.String = jrt.Intern("first")

var Lit_55 *jrt.String = jrt.Intern("cons")

var Lit_56 *jrt.String = jrt.Intern("chunk")

var Lit_57 *jrt.String = jrt.Intern("chunk-rest")

var Lit_58 *jrt.String = jrt.Intern("rest")

var Lit_59 *jrt.String = jrt.Intern("def-heads")

var Lit_60 *jrt.String = jrt.Intern("sort")

var Lit_61 *jrt.String = jrt.Intern("join")

var Lit_62 *jrt.String = jrt.Intern("insert-at")

var Lit_63 *jrt.String = jrt.Intern("index-of")

var Lit_64 *jrt.String = jrt.Intern("distinct")

var Lit_65 *jrt.String = jrt.Intern("defined-names")

var Lit_66 *jrt.String = jrt.Intern("ns")

var Lit_67 *jrt.String = jrt.Intern(":refer-clojure")

var Lit_68 *jrt.String = jrt.Intern("to-ae")

var Lit_69 *jrt.String = jrt.Intern("resolve-conditionals")

var Lit_70 *jrt.String = jrt.Intern("features")

var Lit_71 *jrt.String = jrt.Intern("proxy-methods")

var Lit_72 *jrt.String = jrt.Intern("core-names")

var Lit_73 *jrt.String = jrt.Intern("arbace-core-names")

var Lit_74 *jrt.String = jrt.Intern("security-manager")

var Lit_75 *jrt.String = jrt.Intern("applies")

var Lit_76 *jrt.String = jrt.Intern("id")

var Lit_77 *jrt.String = jrt.Intern("rules")

var Lit_78 *jrt.String = jrt.Intern("rewrite")

var Lit_79 *jrt.String = jrt.Intern("applicable")

var Lit_80 *jrt.String = jrt.Intern("translate")

var Lit_81 *jrt.String = jrt.Intern("arbace.c2a.rules$applicable")

var Lit_82 *jrt.String = jrt.Intern("arbace.c2a.rules$applicable$fn__1094000103")

var Lit_83 *jrt.String = jrt.Intern("arbace.c2a.rules$arbace_core_names")

var Lit_84 *jrt.String = jrt.Intern("arbace.c2a.rules$arbace_core_names$fn__1094000056")

var Lit_85 *jrt.String = jrt.Intern("arbace")

var Lit_86 *jrt.String = jrt.Intern("arbace.c2a.rules$arbace_core_names$fn__1094000058")

var Lit_87 *jrt.String = jrt.Intern("arbace.c2a.rules$clojure_source_QMARK_")

var Lit_88 *jrt.String = jrt.Intern("arbace.c2a.rules$core_names")

var Lit_89 *jrt.String = jrt.Intern(" ")

var Lit_90 *jrt.String = jrt.Intern("\n  (:refer-clojure :exclude [")

var Lit_91 *jrt.String = jrt.Intern("])")

var Lit_92 *jrt.String = jrt.Intern(":only")

var Lit_93 *jrt.String = jrt.Intern(":exclude")

var Lit_94 *jrt.String = jrt.Intern(" :exclude [")

var Lit_95 *jrt.String = jrt.Intern("]")

var Lit_96 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names")

var Lit_97 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065")

var Lit_98 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066")

var Lit_99 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067")

var Lit_100 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000067$fn__1094000071")

var Lit_101 *jrt.String = jrt.Intern("#^")

var Lit_102 *jrt.String = jrt.Intern("arbace.c2a.rules$defined_names$iter__1094000061__1094000065$fn__1094000066$fn__1094000077")

var Lit_103 *jrt.String = jrt.Intern("arbace.c2a.rules$eval1094000004$loading__1927001464__auto____1094000005")

var Lit_104 *jrt.String = jrt.Intern("arbace.c2a.rules$eval1094000008$fn__1094000009")

var Lit_105 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000090")

var Lit_106 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000092")

var Lit_107 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000094")

var Lit_108 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000096")

var Lit_109 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000098")

var Lit_110 *jrt.String = jrt.Intern("arbace.c2a.rules$fn__1094000100")

var Lit_111 *jrt.String = jrt.Intern("arbace.c2a.rules$imports_QMARK_")

var Lit_112 *jrt.String = jrt.Intern("arbace.c2a.rules$insert_at")

var Lit_113 *jrt.String = jrt.Intern("arbace.c2a.rules$proxy_methods")

var Lit_114 *jrt.String = jrt.Intern("arbace.c2a.rules$proxy_methods$fn__1094000014")

var Lit_115 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager")

var Lit_116 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000030")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000036")

var Lit_118 *jrt.String = jrt.Intern("java.lang.")

var Lit_119 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000042")

var Lit_120 *jrt.String = jrt.Intern(".")

var Lit_121 *jrt.String = jrt.Intern("/")

var Lit_122 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$fn__1094000048")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$in_import_QMARK___1094000021")

var Lit_124 *jrt.String = jrt.Intern("arbace.c2a.rules$security_manager$in_import_QMARK___1094000021$fn__1094000023")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2a.rules$translate")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2a.rules$translate$fn__1094000106")

var Lit_127 *jrt.String = jrt.Intern("in-ns")

var Lit_128 *jrt.String = jrt.Intern("clojure-source?")

var Lit_129 *jrt.String = jrt.Intern("private")

var Lit_130 *jrt.String = jrt.Intern("arglists")

var Lit_131 *jrt.String = jrt.Intern("ctx")

var Lit_132 *jrt.String = jrt.Intern("line")

var Lit_133 *jrt.String = jrt.Intern("column")

var Lit_134 *jrt.String = jrt.Intern("file")

var Lit_135 *jrt.String = jrt.Intern("arbace/c2a/rules.ae")

var Lit_136 *jrt.String = jrt.Intern("(?<![\\w$])__(init|update|get)ClojureFnMappings(?![\\w$])")

var Lit_137 *jrt.String = jrt.Intern("__$1ArbaceFnMappings")

var Lit_138 *jrt.String = jrt.Intern("(?<![\\w$])__clojureFnMap(?![\\w$])")

var Lit_139 *jrt.String = jrt.Intern("__arbaceFnMap")

var Lit_140 *jrt.String = jrt.Intern("s")

var Lit_141 *jrt.String = jrt.Intern("The methods every proxy class has, and its field, as Arbace names them.")

var Lit_142 *jrt.String = jrt.Intern("head")

var Lit_143 *jrt.String = jrt.Intern("tag")

var Lit_144 *jrt.String = jrt.Intern("String")

var Lit_145 *jrt.String = jrt.Intern("Unqualified uses of the class SecurityManager qualified as java.lang.SecurityManager, which\n  Arbace does not import by default; a file that imports it is left as it is.")

var Lit_146 *jrt.String = jrt.Intern("The public names arbace.core has and clojure.core has not (their metadata says\n  {:added \"arbace\"}: the class forms' macros and operators), as strings.")

var Lit_147 *jrt.String = jrt.Intern("The names the def forms of s define (the token after the head, its metadata skipped).")

var Lit_148 *jrt.String = jrt.Intern("i")

var Lit_149 *jrt.String = jrt.Intern("x")

var Lit_150 *jrt.String = jrt.Intern("The names arbace.core adds (`added`, a set of strings) that the file defines, excluded from\n  its ns form's :refer-clojure, so they replace nothing (Arbace would warn \"return already\n  refers to: #'arbace.core/return\" and replace it): added to an :exclude, or a\n  (:refer-clojure :exclude [...]) added. A file without an ns form, or whose :refer-clojure\n  has :only, is left as it is.")

var Lit_151 *jrt.String = jrt.Intern("The rules, in the order they apply.")

var Lit_152 *jrt.String = jrt.Intern("reader-conditionals")

var Lit_153 *jrt.String = jrt.Intern("constantly")

var Lit_154 *jrt.String = jrt.Intern("divergences")

var Lit_155 *jrt.String = jrt.Intern("divergence")

var Lit_156 *jrt.String = jrt.Intern("reduce without an init on an IReduceInit-only reducible")

var Lit_157 *jrt.String = jrt.Intern("rule")

var Lit_158 *jrt.String = jrt.Intern("none")

var Lit_159 *jrt.String = jrt.Intern("why")

var Lit_160 *jrt.String = jrt.Intern("Arbace reduces what upstream rejects: code that runs on Clojure runs the same.")

var Lit_161 *jrt.String = jrt.Intern("SecurityManager is not a default import")

var Lit_162 *jrt.String = jrt.Intern("A multimethod's ambiguity message")

var Lit_163 *jrt.String = jrt.Intern("A message's wording; code does not depend on it (a test comparing it must be edited).")

var Lit_164 *jrt.String = jrt.Intern("bean ignores explicit BeanInfo classes")

var Lit_165 *jrt.String = jrt.Intern("What bean returns at run time; nothing in the source names it.")

var Lit_166 *jrt.String = jrt.Intern("Optional modules (java.sql, java.xml, java.desktop)")

var Lit_167 *jrt.String = jrt.Intern("Which modules the runtime image holds, not the source.")

var Lit_168 *jrt.String = jrt.Intern("Source files are .ae")

var Lit_169 *jrt.String = jrt.Intern("c2a writes .ae files (a .cljc file's conditionals resolved); source paths of the\n         vendored namespaces are renamed by :rename.")

var Lit_170 *jrt.String = jrt.Intern("Names arbace.core adds (the class forms' macros and operators)")

var Lit_171 *jrt.String = jrt.Intern("A file defining one of them gets them excluded from its ns form's :refer-clojure.")

var Lit_172 *jrt.String = jrt.Intern("Runtime-visible names (threads, error report files, proxy methods)")

var Lit_173 *jrt.String = jrt.Intern("The proxy methods and field are names code calls; thread names and report file\n         prefixes are data in strings, left alone (doc/C2A.md, limits).")

var Lit_174 *jrt.String = jrt.Intern("The dialect divergences of doc/VENDOR-NOTES.md, in its order: the rule answering each, or\n  :none and why no source rewrite applies.")

var Lit_175 *jrt.String = jrt.Intern("skip")

var Lit_176 *jrt.String = jrt.Intern("The rules that apply to a file, without the skipped ones (a set of ids).")

var Lit_177 *jrt.String = jrt.Intern("Text s of a file translated by the rules that apply (ctx: see the namespace's doc), minus\n  the skipped ones.")

var Lit_178 *jrt.String = jrt.Intern("SecurityManager")

var Lit_179 *jrt.String = jrt.Intern("A .cljc file becoming a .ae file: each reader conditional (#?, #?@) replaced by the\n         text of the branch the reader selects on Arbace (features #{:clj}, then :default),\n         spliced for #?@, or by nothing; a .ae file is read without conditionals.")

var Lit_180 *jrt.String = jrt.Intern("The names of the vendored Clojure: clojure.* -> arbace.* for its namespaces, the\n         Java packages clojure.lang, clojure.asm (with commons, signature), clojure.java.api,\n         the keyword namespace clojure.error, the system properties clojure.*, spec; and\n         source paths clojure/<ns>.clj -> arbace/<ns>.ae (arbace.c2a.rename).")

var Lit_181 *jrt.String = jrt.Intern("A proxy's methods __initClojureFnMappings, __updateClojureFnMappings,\n         __getClojureFnMappings and its field __clojureFnMap: __initArbaceFnMappings and the\n         rest, __arbaceFnMap (VENDOR-NOTES.md, hand change 2).")

var Lit_182 *jrt.String = jrt.Intern("Names arbace.core adds to Clojure's core (the class forms' macros and operators:\n         return, switch, label, lambda, ...) that a file defines: excluded in its ns form's\n         :refer-clojure, as a library does for a core name it redefines.")

var Lit_183 *jrt.String = jrt.Intern("SecurityManager unqualified -> java.lang.SecurityManager (not a default import in\n         Arbace, VENDOR-NOTES.md, hand change 11), unless the file imports it.")
