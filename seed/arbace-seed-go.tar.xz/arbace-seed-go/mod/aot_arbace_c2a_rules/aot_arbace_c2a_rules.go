//line aot_arbace_c2a_rules.ae:1
package aot_arbace_c2a_rules

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_New() *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2a_rules_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_rules_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_c2a_rules_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2a_rules_A_const_3, A_arbace_c2a_rules_A_const_4, A_arbace_c2a_rules_A_const_5); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_New() *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_eval1094000008_fn__1094000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_rules_A_const_10), A_arbace_c2a_rules_A_const_8.GetRawRoot__O(), A_arbace_c2a_rules_A_const_9) }

















func A_arbace_c2a_rules_clojure_source_QMARK__A_New() *A_arbace_c2a_rules_clojure_source_QMARK__A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_clojure_source_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_11.GetRawRoot__O()); var tmp2 any = A_arbace_c2a_rules_A_const_12; return tmp1.Invoke_O_O__O(tmp2, A_arbace_c2a_rules_A_const_13.Invoke_O__O(ctx__0)) }







func A_arbace_c2a_rules_proxy_methods_A_New() *A_arbace_c2a_rules_proxy_methods_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_proxy_methods_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c2a_rules_proxy_methods_A) Ctor() {}
//line :27:1
func (t *A_arbace_c2a_rules_proxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), s__0, A_arbace_c2a_rules_A_const_16.GetRawRoot__O()) }
//line :30:1
func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_New() *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_proxy_methods_fn__1094000014_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) Ctor() {}
//line :30:1
func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) Invoke_O_O_O__O(self, s__1, p__1094000013__2 any) any { var vec__1094000015__3 any = p__1094000013__2; var re__4 any = lang.RT_Nth_O_I_O__O(vec__1094000015__3, lang.RT_IntCast_J__I(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O(vec__1094000015__3, lang.RT_IntCast_J__I(1), nil); return lang.IFn_Cast(A_arbace_c2a_rules_A_const_15.GetRawRoot__O()).Invoke_O_O_O__O(s__1, re__4, to__5) }





func A_arbace_c2a_rules_imports_QMARK__A_New() *A_arbace_c2a_rules_imports_QMARK__A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_imports_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_c2a_rules_imports_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_c2a_rules_imports_QMARK__A) Invoke_O_O__O(self, head__0 any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2a_rules_A_const_17, head__0) }

func A_arbace_c2a_rules_security_manager_A_New() *A_arbace_c2a_rules_security_manager_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_security_manager_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_c2a_rules_security_manager_A) Ctor() {}
//line :38:1
func (t *A_arbace_c2a_rules_security_manager_A) Invoke_O_O__O(self, s__0 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_c2a_rules_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_24.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_c2a_rules_A_const_25.GetRawRoot__O()))) { return s__0 } else { var import_spans__2 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_c2a_rules_A_const_26.GetRawRoot__O()); var in_import_QMARK___3 any; var tmp1 any = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_New_O(import_spans__2); var tmp2 *jrt.Class
		var fncls__3 /*line :42:1*/*jrt.Class = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_fn_class


		if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :42:1
		var tokens__4 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_21.GetRawRoot__O()); var tmp4 any = A_arbace_c2a_rules_security_manager_fn__1094000030_A_New_O(s__0); var tmp5 *jrt.Class
		var fncls__4 /*line :42:1*/*jrt.Class = A_arbace_c2a_rules_security_manager_fn__1094000030_A_fn_class



		if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_c2a_rules_security_manager_fn__1094000030_A_fn_class = fncls__4d; tmp5 = fncls__4d } else { tmp5 = fncls__4 }; tokens__4 = tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_c2a_rules_A_const_28.GetRawRoot__O()).Invoke_O__O(s__0))
//line :42:1
		var imported_QMARK___5 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_20.GetRawRoot__O()); var tmp7 any = A_arbace_c2a_rules_security_manager_fn__1094000036_A_New_O_O(s__0, in_import_QMARK___3); var tmp8 *jrt.Class
		var fncls__5 /*line :42:1*/*jrt.Class = A_arbace_c2a_rules_security_manager_fn__1094000036_A_fn_class




		if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_c2a_rules_security_manager_fn__1094000036_A_fn_class = fncls__5d; tmp8 = fncls__5d } else { tmp8 = fncls__5 }; imported_QMARK___5 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), tokens__4)
//line :42:1
		var uses__6 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_21.GetRawRoot__O()); var tmp10 any = A_arbace_c2a_rules_security_manager_fn__1094000042_A_New_O_O(s__0, in_import_QMARK___3); var tmp11 *jrt.Class
		var fncls__6 /*line :42:1*/*jrt.Class = A_arbace_c2a_rules_security_manager_fn__1094000042_A_fn_class







		if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_c2a_rules_security_manager_fn__1094000042_A_fn_class = fncls__6d; tmp11 = fncls__6d } else { tmp11 = fncls__6 }; uses__6 = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), tokens__4)




		var tmp12 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.A2g_Truth(or__1927000174__auto____7) { tmp12 = or__1927000174__auto____7 } else { tmp12 = lang.IFn_Cast(A_arbace_c2a_rules_A_const_22.GetRawRoot__O()).Invoke_O__O(uses__6) }; if jrt.A2g_Truth(tmp12) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_14.GetRawRoot__O()); var tmp14 any = A_arbace_c2a_rules_security_manager_fn__1094000048_A_New_O_O(sb__7, s__0); var tmp15 *jrt.Class
			var fncls__7 /*line :55:1*/*jrt.Class = A_arbace_c2a_rules_security_manager_fn__1094000048_A_fn_class


			if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_c2a_rules_security_manager_fn__1094000048_A_fn_class = fncls__7d; tmp15 = fncls__7d } else { tmp15 = fncls__7 }; end__8 = tmp13.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), A_arbace_c2a_rules_A_const_30, uses__6)




			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I(end__8), lang.RT_Count_O__I(s__0))
			return lang.IFn_Cast(A_arbace_c2a_rules_A_const_23.GetRawRoot__O()).Invoke_O__O(sb__7) } } }
//line :45:1
func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_New_O(p0 any) *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A{}; t.Ctor_O(p0); return t }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_20.GetRawRoot__O()); var tmp2 any = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_New_O(i__1); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_import_spans) }
//line :45:1
func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_New_O(p0 any) *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A{}; t.Ctor_O(p0); return t }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) Invoke_O_O__O(self, p__1094000022__1 any) any { var vec__1094000024__2 any = p__1094000022__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000024__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000024__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Numbers_Lte_O_O__Z(a__3, t.F_i); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_O__Z(t.F_i, b__4)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }
func A_arbace_c2a_rules_security_manager_fn__1094000030_A_New_O(p0 any) *A_arbace_c2a_rules_security_manager_fn__1094000030_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000030_A{}; t.Ctor_O(p0); return t }
//line :46:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :46:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) Invoke_O_O__O(self, p__1094000029__1 any) any { var vec__1094000031__2 any = p__1094000029__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000031__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000031__2, lang.RT_IntCast_J__I(1), nil); return lang.IFn_Cast(A_arbace_c2a_rules_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4), A_arbace_c2a_rules_A_const_25.GetRawRoot__O()) }
func A_arbace_c2a_rules_security_manager_fn__1094000036_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_security_manager_fn__1094000036_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000036_A{}; t.Ctor_O_O(p0, p1); return t }
//line :47:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :47:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) Invoke_O_O__O(self, p__1094000035__1 any) any { var vec__1094000037__2 any = p__1094000035__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000037__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000037__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.A2g_Truth(and__1927000168__auto____5) {
														return lang.IFn_Cast(A_arbace_c2a_rules_A_const_11.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2a_rules_A_const_25.GetRawRoot__O(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2a_rules_A_const_25.GetRawRoot__O())).Ref())), lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4)) } else {
//line :47:1
		return and__1927000168__auto____5 } }


func A_arbace_c2a_rules_security_manager_fn__1094000042_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_security_manager_fn__1094000042_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000042_A{}; t.Ctor_O_O(p0, p1); return t }
//line :50:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :50:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) Invoke_O_O__O(self, p__1094000041__1 any) any { var vec__1094000043__2 any = p__1094000041__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000043__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000043__2, lang.RT_IntCast_J__I(1), nil); var t__5 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4); var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3)); if

	jrt.A2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z(t__5, A_arbace_c2a_rules_A_const_25.GetRawRoot__O())
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_25), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2a_rules_A_const_25.GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_29.GetRawRoot__O()).Invoke_O_O__O(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_26), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2a_rules_A_const_25.GetRawRoot__O(), nil)).Ref()) } } } else {
//line :52:1
			return and__1927000168__auto____6 } }





func A_arbace_c2a_rules_security_manager_fn__1094000048_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_security_manager_fn__1094000048_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :58:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :58:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) Invoke_O_O_O__O(self, i__1, p__1094000047__2 any) any { var vec__1094000049__3 any = p__1094000047__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__1094000049__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1094000049__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
															jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I(i__1), lang.RT_IntCast_O__I(a__4)); var tmp3 /*line :60:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp3).Append_String__StringBuilder(Lit_24); return a__4 }







func A_arbace_c2a_rules_arbace_core_names_A_New() *A_arbace_c2a_rules_arbace_core_names_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_arbace_core_names_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_c2a_rules_arbace_core_names_A) Ctor() {}
//line :68:1
func (t *A_arbace_c2a_rules_arbace_core_names_A) Invoke_O__O(self any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_31.GetRawRoot__O()); var tmp2 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp2 = lang.PersistentHashSet_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_32.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_21.GetRawRoot__O()); var tmp6 any = A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_New(); var tmp7 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_fn_class = fncls__8d; tmp7 = fncls__8d } else { tmp7 = fncls__8 }; var tmp8 any = tmp5.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_34.GetRawRoot__O()); var tmp10 any = A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_New(); var tmp11 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_fn_class = fncls__9d; tmp11 = fncls__9d } else { tmp11 = fncls__9 }; return tmp1.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp8, tmp9.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))), lang.IFn_Cast(A_arbace_c2a_rules_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_37.GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_rules_A_const_38))) }
//line :72:1
func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_New() *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) Ctor() {}
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) Invoke_O_O__O(self, p1__1094000054_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2a_rules_A_const_35; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_4, tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1094000054_SHARP___1)))).Ref() }
//line :72:1
func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_New() *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) Ctor() {}
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) Invoke_O_O__O(self, p1__1094000055_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_36.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(p1__1094000055_SHARP___1).F_sym.Ref()) }






func A_arbace_c2a_rules_defined_names_A_New() *A_arbace_c2a_rules_defined_names_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_defined_names_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_c2a_rules_defined_names_A) Ctor() {}
//line :79:1
func (t *A_arbace_c2a_rules_defined_names_A) Invoke_O_O__O(self, s__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_New_O(s__0); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_fn_class; if


	fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_c2a_rules_A_const_55.GetRawRoot__O())) }
//line :82:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_New_O(p0 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) Invoke_O_O__O(self, s__1094000062__1 any) any { var tmp1 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_New_O_O_O(s__1094000062__1, self, t.F_s); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) Ctor_O_O_O(c__s__1094000062, c__iter__1094000061, c__s any) { t.F_s__1094000062 = c__s__1094000062; t.F_iter__1094000061 = c__iter__1094000061; t.F_s = c__s }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) Invoke_O__O(self any) any { { var s__1094000062__1 any; var t_ any = t.F_s__1094000062; t.F_s__1094000062 = nil; s__1094000062__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_39.GetRawRoot__O()).Invoke_O__O(s__1094000062__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1094000062__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_c2a_rules_A_const_40.GetRawRoot__O()).Invoke_O__O(s__1094000062__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1094000062__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1094000064__6 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_42.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_New_O_O_I_O(t.F_s, b__1094000064__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1094000061); return lang.IFn_Cast(A_arbace_c2a_rules_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_52.GetRawRoot__O()).Invoke_O__O(b__1094000064__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_53.GetRawRoot__O()).Invoke_O__O(s__1094000062__3))) } else { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_52.GetRawRoot__O()).Invoke_O__O(b__1094000064__6), nil) } } else { var vec__1094000074__4 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_50.GetRawRoot__O()).Invoke_O__O(s__1094000062__3); var a__5 any = lang.RT_Nth_O_I_O__O(vec__1094000074__4, lang.RT_IntCast_J__I(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O(vec__1094000074__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp5 any = t.F_s; var h__7 any = tmp4.Invoke_O_O__O(tmp5, lang.Numbers_Inc_O__Number(a__5)); var j__8 any; var tmp6 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_New_O_O(h__7, t.F_s); var tmp7 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_fn_class; _ = ___6

	if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_fn_class = fncls__12d; tmp7 = fncls__12d } else { tmp7 = fncls__12 }; j__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :82:1
	var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()); var tmp9 any = t.F_s; var t__9 any = tmp8.Invoke_O_O_O__O(tmp9, j__8, lang.IFn_Cast(A_arbace_c2a_rules_A_const_46.GetRawRoot__O()).Invoke_O_O__O(t.F_s, j__8)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_c2a_rules_A_const_39.GetRawRoot__O()).Invoke_O__O(t__9)) { var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1094000061); return lang.IFn_Cast(A_arbace_c2a_rules_A_const_51.GetRawRoot__O()).Invoke_O_O__O(t__9, tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_54.GetRawRoot__O()).Invoke_O__O(s__1094000062__3))) } else { s__1094000062__1 = lang.IFn_Cast(A_arbace_c2a_rules_A_const_54.GetRawRoot__O()).Invoke_O__O(s__1094000062__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :82:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) Ctor_O_O_I_O(c__s, c__b__1094000064 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_s = c__s; t.F_b__1094000064 = c__b__1094000064; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) Invoke_O__O(self any) any { { var i__1094000063__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1094000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1094000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1094000063__1)); var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000068__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1094000068__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp3 any = t.F_s; var h__5 any = tmp2.Invoke_O_O__O(tmp3, lang.Numbers_Inc_O__Number(a__3)); var j__6 any; var tmp4 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_New_O_O(h__5, t.F_s); var tmp5 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_fn_class; _ = ___4

	if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_fn_class = fncls__10d; tmp5 = fncls__10d } else { tmp5 = fncls__10 }; j__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()
//line :82:1
	var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()); var tmp7 any = t.F_s; var t__7 any = tmp6.Invoke_O_O_O__O(tmp7, j__6, lang.IFn_Cast(A_arbace_c2a_rules_A_const_46.GetRawRoot__O()).Invoke_O_O__O(t.F_s, j__6)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_c2a_rules_A_const_39.GetRawRoot__O()).Invoke_O__O(t__7)) { lang.IFn_Cast(A_arbace_c2a_rules_A_const_48.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1094000064, t__7); i__1094000063__1 = lang.Numbers_Unchecked_inc_J__J(i__1094000063__1); continue L1 } else { i__1094000063__1 = lang.Numbers_Unchecked_inc_J__J(i__1094000063__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp2 any = t.F_s; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_46.GetRawRoot__O()); var tmp4 any = t.F_s; var tmp5 any; var t_ any = t.F_h; t.F_h = nil; tmp5 = t_; j__1 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5)); L1: for {

	if lang.Numbers_Gte_O_J__Z(j__1, int64(lang.RT_Count_O__I(t.F_s))) { return j__1 } else { var tmp6 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_c2a_rules_A_const_44)).CharValue__C(), jrt.NN(tmp6).CharAt_I__C(lang.RT_IntCast_O__I(j__1))) {

		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp8 any = t.F_s; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_47.GetRawRoot__O()); var tmp10 any = t.F_s; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp12 any = t.F_s; j__1 = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, lang.Numbers_Inc_O__Number(j__1)))); continue L1 } else {
//line :86:1
			var tmp13 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp13).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I(j__1)) {



				var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp15 any = t.F_s; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_47.GetRawRoot__O()); var tmp17 any = t.F_s; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp19 any = t.F_s; j__1 = tmp14.Invoke_O_O__O(tmp15, tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(tmp19, lang.Numbers_Add_O_J__Number(j__1, 2)))); continue L1 } else {
//line :86:1
					if A_arbace_c2a_rules_A_const_45 != nil { return j__1 } else { return nil } } } } } }; /*line :84:1*/panic("a2g: unreachable") }
//line :84:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp2 any = t.F_s; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_46.GetRawRoot__O()); var tmp4 any = t.F_s; var tmp5 any; var t_ any = t.F_h; t.F_h = nil; tmp5 = t_; j__1 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5)); L1: for {

	if lang.Numbers_Gte_O_J__Z(j__1, int64(lang.RT_Count_O__I(t.F_s))) { return j__1 } else { var tmp6 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_c2a_rules_A_const_44)).CharValue__C(), jrt.NN(tmp6).CharAt_I__C(lang.RT_IntCast_O__I(j__1))) {

		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp8 any = t.F_s; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_47.GetRawRoot__O()); var tmp10 any = t.F_s; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp12 any = t.F_s; j__1 = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, lang.Numbers_Inc_O__Number(j__1)))); continue L1 } else {
//line :86:1
			var tmp13 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp13).StartsWith_String_I__Z(Lit_17, lang.RT_IntCast_O__I(j__1)) {



				var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp15 any = t.F_s; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_47.GetRawRoot__O()); var tmp17 any = t.F_s; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()); var tmp19 any = t.F_s; j__1 = tmp14.Invoke_O_O__O(tmp15, tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(tmp19, lang.Numbers_Add_O_J__Number(j__1, 2)))); continue L1 } else {
//line :86:1
					if A_arbace_c2a_rules_A_const_45 != nil { return j__1 } else { return nil } } } } } }; /*line :84:1*/panic("a2g: unreachable") }











func A_arbace_c2a_rules_insert_at_A_New() *A_arbace_c2a_rules_insert_at_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_insert_at_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_c2a_rules_insert_at_A) Ctor() {}
//line :96:1
func (t *A_arbace_c2a_rules_insert_at_A) Invoke_O_O_O_O__O(self, s__0, i__1, x__2 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(s__0, A_arbace_c2a_rules_A_const_30, i__1), x__2, lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1))).Ref() }

func A_arbace_c2a_rules_core_names_A_New() *A_arbace_c2a_rules_core_names_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_core_names_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_c2a_rules_core_names_A) Ctor() {}
//line :98:1
func (t *A_arbace_c2a_rules_core_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_21.GetRawRoot__O()).Invoke_O_O__O(added__1, lang.IFn_Cast(A_arbace_c2a_rules_A_const_61.GetRawRoot__O()).Invoke_O__O(s__0)))); var vec__1094000083__4 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_c2a_rules_A_const_62)); var ns_a__5 any = lang.RT_Nth_O_I_O__O(vec__1094000083__4, lang.RT_IntCast_J__I(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O(vec__1094000083__4, lang.RT_IntCast_J__I(1), nil); var tmp1 any; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_22.GetRawRoot__O()).Invoke_O__O(names__3); if








	jrt.A2g_Truth(or__1927000174__auto____7) { tmp1 = or__1927000174__auto____7 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(ns_a__5, nil)).Ref() }; if jrt.A2g_Truth(tmp1) { return s__0 } else { var ns_text__7 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(s__0, ns_a__5, ns_b__6); var names_text__8 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_57.GetRawRoot__O()).Invoke_O_O__O(Lit_5, names__3); var vec__1094000086__9 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_50.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_19.GetRawRoot__O()).Invoke_O_O__O(ns_text__7, A_arbace_c2a_rules_A_const_63)); var ra__10 any = lang.RT_Nth_O_I_O__O(vec__1094000086__9, lang.RT_IntCast_J__I(0), nil); var rb__11 any = lang.RT_Nth_O_I_O__O(vec__1094000086__9, lang.RT_IntCast_J__I(1), nil)




		if lang.Util_Identical_O_O__Z(ra__10, nil) {

			return lang.IFn_Cast(A_arbace_c2a_rules_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Dec_O__Number(ns_b__6), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref()) } else {
//line :112:1
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_c2a_rules_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(ns_text__7, ra__10, rb__11), Lit_8)) { return s__0 } else { if A_arbace_c2a_rules_A_const_45 != nil { var rc__12 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(ns_text__7, ra__10, rb__11); var ex__13 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_59.GetRawRoot__O()).Invoke_O_O__O(rc__12, Lit_9)







					if lang.Util_Identical_O_O__Z(ex__13, nil) {
						return lang.IFn_Cast(A_arbace_c2a_rules_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(ns_a__5, ra__10), lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(rc__12)))), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref()) } else {
//line :120:1
							var v__14 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_43.GetRawRoot__O()).Invoke_O_O__O(rc__12, lang.Numbers_Add_O_J__Number(ex__13, int64(lang.RT_Count_O__I(Lit_9)))); var ve__15 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_47.GetRawRoot__O()).Invoke_O_O__O(rc__12, v__14)



							return lang.IFn_Cast(A_arbace_c2a_rules_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(ns_a__5, ra__10), lang.Numbers_Dec_O__Number(ve__15)), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8)).Ref()) } } else {
//line :112:1
								return nil } } } } }



















func A_arbace_c2a_rules_fn__1094000090_A_New() *A_arbace_c2a_rules_fn__1094000090_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_fn__1094000090_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_c2a_rules_fn__1094000090_A) Ctor() {}
//line :132:1
func (t *A_arbace_c2a_rules_fn__1094000090_A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 any = A_arbace_c2a_rules_A_const_64; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_c2a_rules_A_const_13.Invoke_O__O(ctx__0)); if and__1927000168__auto____2 { return A_arbace_c2a_rules_A_const_65.Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }
func A_arbace_c2a_rules_fn__1094000092_A_New() *A_arbace_c2a_rules_fn__1094000092_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_fn__1094000092_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_c2a_rules_fn__1094000092_A) Ctor() {}
//line :133:1
func (t *A_arbace_c2a_rules_fn__1094000092_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_66.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_c2a_rules_A_const_67.Invoke_O__O(ctx__1)) }






func A_arbace_c2a_rules_fn__1094000094_A_New() *A_arbace_c2a_rules_fn__1094000094_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_fn__1094000094_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_c2a_rules_fn__1094000094_A) Ctor() {}
//line :140:1
func (t *A_arbace_c2a_rules_fn__1094000094_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_68.GetRawRoot__O()).Invoke_O__O(s__0) }





func A_arbace_c2a_rules_fn__1094000096_A_New() *A_arbace_c2a_rules_fn__1094000096_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_fn__1094000096_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_c2a_rules_fn__1094000096_A) Ctor() {}
//line :146:1
func (t *A_arbace_c2a_rules_fn__1094000096_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_69.GetRawRoot__O()).Invoke_O__O(s__0) }





func A_arbace_c2a_rules_fn__1094000098_A_New() *A_arbace_c2a_rules_fn__1094000098_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_fn__1094000098_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_c2a_rules_fn__1094000098_A) Ctor() {}
//line :152:1
func (t *A_arbace_c2a_rules_fn__1094000098_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_70.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____3 any = A_arbace_c2a_rules_A_const_71.Invoke_O__O(ctx__1); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = lang.IFn_Cast(A_arbace_c2a_rules_A_const_72.GetRawRoot__O()).Invoke__O() }; return tmp1.Invoke_O_O__O(s__0, tmp2) }




func A_arbace_c2a_rules_fn__1094000100_A_New() *A_arbace_c2a_rules_fn__1094000100_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_fn__1094000100_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_c2a_rules_fn__1094000100_A) Ctor() {}
//line :157:1
func (t *A_arbace_c2a_rules_fn__1094000100_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_73.GetRawRoot__O()).Invoke_O__O(s__0) }






























func A_arbace_c2a_rules_applicable_A_New() *A_arbace_c2a_rules_applicable_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_applicable_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_c2a_rules_applicable_A) Ctor() {}
//line :188:1
func (t *A_arbace_c2a_rules_applicable_A) Invoke_O_O_O__O(self, ctx__0, skip__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_c2a_rules_applicable_fn__1094000103_A_New_O_O(ctx__0, skip__1); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c2a_rules_applicable_fn__1094000103_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_c2a_rules_applicable_fn__1094000103_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_c2a_rules_A_const_76.GetRawRoot__O()) }
//line :191:1
func A_arbace_c2a_rules_applicable_fn__1094000103_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_applicable_fn__1094000103_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_applicable_fn__1094000103_A{}; t.Ctor_O_O(p0, p1); return t }
//line :191:1
func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) Ctor_O_O(c__ctx, c__skip any) { t.F_ctx = c__ctx; t.F_skip = c__skip }
//line :191:1
func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) Invoke_O_O__O(self, p1__1094000102_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_11.GetRawRoot__O()); var tmp2 any = t.F_skip; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_c2a_rules_A_const_18.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_c2a_rules_A_const_75.Invoke_O__O(p1__1094000102_SHARP___1))); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_74.Invoke_O__O(p1__1094000102_SHARP___1)).Invoke_O__O(t.F_ctx) } else { return and__1927000168__auto____2 } }

func A_arbace_c2a_rules_translate_A_New() *A_arbace_c2a_rules_translate_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_translate_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_c2a_rules_translate_A) Ctor() {}
//line :193:1
func (t *A_arbace_c2a_rules_translate_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_c2a_rules_translate_fn__1094000106_A_New_O(ctx__1); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_c2a_rules_translate_fn__1094000106_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_c2a_rules_translate_fn__1094000106_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), s__0, lang.IFn_Cast(A_arbace_c2a_rules_A_const_78.GetRawRoot__O()).Invoke_O_O__O(ctx__1, skip__2)) }
//line :193:1
func (t *A_arbace_c2a_rules_translate_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_rules_A_const_79.GetRawRoot__O()); var tmp2 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp2 = lang.PersistentHashSet_EMPTY; return tmp1.Invoke_O_O_O__O(s__0, ctx__1, tmp2.Ref())
}
func A_arbace_c2a_rules_translate_fn__1094000106_A_New_O(p0 any) *A_arbace_c2a_rules_translate_fn__1094000106_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_translate_fn__1094000106_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :198:1
func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { return lang.IFn_Cast(A_arbace_c2a_rules_A_const_77.Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

















type A_arbace_c2a_rules_A struct{ jrt.Object }

var A_arbace_c2a_rules_A_const_pool *jrt.RefArray

var A_arbace_c2a_rules_A_const_0 *lang.Var

var A_arbace_c2a_rules_A_const_1 *lang.Var

var A_arbace_c2a_rules_A_const_2 any

var A_arbace_c2a_rules_A_const_3 any

var A_arbace_c2a_rules_A_const_4 any

var A_arbace_c2a_rules_A_const_5 any

var A_arbace_c2a_rules_A_const_6 *lang.Var

var A_arbace_c2a_rules_A_const_7 *lang.Var

var A_arbace_c2a_rules_A_const_8 *lang.Var

var A_arbace_c2a_rules_A_const_9 any

var A_arbace_c2a_rules_A_const_10 *lang.Var

var A_arbace_c2a_rules_A_const_11 *lang.Var

var A_arbace_c2a_rules_A_const_12 any

var A_arbace_c2a_rules_A_const_13 *lang.Keyword

var A_arbace_c2a_rules_A_const_14 *lang.Var

var A_arbace_c2a_rules_A_const_15 *lang.Var

var A_arbace_c2a_rules_A_const_16 *lang.Var

var A_arbace_c2a_rules_A_const_17 any

var A_arbace_c2a_rules_A_const_18 *lang.Var

var A_arbace_c2a_rules_A_const_19 *lang.Var

var A_arbace_c2a_rules_A_const_20 *lang.Var

var A_arbace_c2a_rules_A_const_21 *lang.Var

var A_arbace_c2a_rules_A_const_22 *lang.Var

var A_arbace_c2a_rules_A_const_23 *lang.Var

var A_arbace_c2a_rules_A_const_24 *lang.Var

var A_arbace_c2a_rules_A_const_25 *lang.Var

var A_arbace_c2a_rules_A_const_26 *lang.Var

var A_arbace_c2a_rules_A_const_27 *lang.Var

var A_arbace_c2a_rules_A_const_28 *lang.Var

var A_arbace_c2a_rules_A_const_29 *lang.Var

var A_arbace_c2a_rules_A_const_30 any

var A_arbace_c2a_rules_A_const_31 *lang.Var

var A_arbace_c2a_rules_A_const_32 *lang.Var

var A_arbace_c2a_rules_A_const_33 *lang.Var

var A_arbace_c2a_rules_A_const_34 *lang.Var

var A_arbace_c2a_rules_A_const_35 *lang.Keyword

var A_arbace_c2a_rules_A_const_36 *lang.Var

var A_arbace_c2a_rules_A_const_37 *lang.Var

var A_arbace_c2a_rules_A_const_38 any

var A_arbace_c2a_rules_A_const_39 *lang.Var

var A_arbace_c2a_rules_A_const_40 *lang.Var

var A_arbace_c2a_rules_A_const_41 *lang.Var

var A_arbace_c2a_rules_A_const_42 *lang.Var

var A_arbace_c2a_rules_A_const_43 *lang.Var

var A_arbace_c2a_rules_A_const_44 any

var A_arbace_c2a_rules_A_const_45 *lang.Keyword

var A_arbace_c2a_rules_A_const_46 *lang.Var

var A_arbace_c2a_rules_A_const_47 *lang.Var

var A_arbace_c2a_rules_A_const_48 *lang.Var

var A_arbace_c2a_rules_A_const_49 *lang.Var

var A_arbace_c2a_rules_A_const_50 *lang.Var

var A_arbace_c2a_rules_A_const_51 *lang.Var

var A_arbace_c2a_rules_A_const_52 *lang.Var

var A_arbace_c2a_rules_A_const_53 *lang.Var

var A_arbace_c2a_rules_A_const_54 *lang.Var

var A_arbace_c2a_rules_A_const_55 *lang.Var

var A_arbace_c2a_rules_A_const_56 *lang.Var

var A_arbace_c2a_rules_A_const_57 *lang.Var

var A_arbace_c2a_rules_A_const_58 *lang.Var

var A_arbace_c2a_rules_A_const_59 *lang.Var

var A_arbace_c2a_rules_A_const_60 *lang.Var

var A_arbace_c2a_rules_A_const_61 *lang.Var

var A_arbace_c2a_rules_A_const_62 any

var A_arbace_c2a_rules_A_const_63 any

var A_arbace_c2a_rules_A_const_64 *lang.Keyword

var A_arbace_c2a_rules_A_const_65 *lang.Keyword

var A_arbace_c2a_rules_A_const_66 *lang.Var

var A_arbace_c2a_rules_A_const_67 *lang.Keyword

var A_arbace_c2a_rules_A_const_68 *lang.Var

var A_arbace_c2a_rules_A_const_69 *lang.Var

var A_arbace_c2a_rules_A_const_70 *lang.Var

var A_arbace_c2a_rules_A_const_71 *lang.Keyword

var A_arbace_c2a_rules_A_const_72 *lang.Var

var A_arbace_c2a_rules_A_const_73 *lang.Var

var A_arbace_c2a_rules_A_const_74 *lang.Keyword

var A_arbace_c2a_rules_A_const_75 *lang.Keyword

var A_arbace_c2a_rules_A_const_76 *lang.Var

var A_arbace_c2a_rules_A_const_77 *lang.Keyword

var A_arbace_c2a_rules_A_const_78 *lang.Var

var A_arbace_c2a_rules_A_const_79 *lang.Var

var A_arbace_c2a_rules_A_init jrt.ClassInit

func A_arbace_c2a_rules_A_Init() { if !A_arbace_c2a_rules_A_init.Done() { A_arbace_c2a_rules_A_init.Run(A_arbace_c2a_rules_A_clinit) } }

func A_arbace_c2a_rules_A_clinit() { A_arbace_c2a_rules_A_clinit_p0(); A_arbace_c2a_rules_A_clinit_p1(); A_arbace_c2a_rules_A_clinit_p2(); A_arbace_c2a_rules_A_clinit_p3(); A_arbace_c2a_rules_A_clinit_p4(); A_arbace_c2a_rules_A_clinit_p5(); A_arbace_c2a_rules_A_clinit_p6() }

func A_arbace_c2a_rules_A_clinit_p0() { A_arbace_c2a_rules_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 100); A_arbace_c2a_rules_A_const_0 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[20]); A_arbace_c2a_rules_A_const_1 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[21]); A_arbace_c2a_rules_A_const_2 = A_arbace_c2a_rules_A_const_pool.A[22]; A_arbace_c2a_rules_A_const_3 = A_arbace_c2a_rules_A_const_pool.A[23]; A_arbace_c2a_rules_A_const_4 = A_arbace_c2a_rules_A_const_pool.A[24]; A_arbace_c2a_rules_A_const_5 = A_arbace_c2a_rules_A_const_pool.A[25]; A_arbace_c2a_rules_A_const_6 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[26]); A_arbace_c2a_rules_A_const_7 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[27]); A_arbace_c2a_rules_A_const_8 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[28]); A_arbace_c2a_rules_A_const_9 = A_arbace_c2a_rules_A_const_pool.A[29]; A_arbace_c2a_rules_A_const_10 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[30]); A_arbace_c2a_rules_A_const_11 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[31]); A_arbace_c2a_rules_A_const_12 = A_arbace_c2a_rules_A_const_pool.A[32] }

func A_arbace_c2a_rules_A_clinit_p1() { A_arbace_c2a_rules_A_const_13 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[33]); A_arbace_c2a_rules_A_const_14 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[34]); A_arbace_c2a_rules_A_const_15 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[35]); A_arbace_c2a_rules_A_const_16 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[36]); A_arbace_c2a_rules_A_const_17 = A_arbace_c2a_rules_A_const_pool.A[37]; A_arbace_c2a_rules_A_const_18 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[38]); A_arbace_c2a_rules_A_const_19 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[39]); A_arbace_c2a_rules_A_const_20 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[40]); A_arbace_c2a_rules_A_const_21 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[41]); A_arbace_c2a_rules_A_const_22 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[42]); A_arbace_c2a_rules_A_const_23 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[43]); A_arbace_c2a_rules_A_const_24 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[44]) }

func A_arbace_c2a_rules_A_clinit_p2() { A_arbace_c2a_rules_A_const_25 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[45]); A_arbace_c2a_rules_A_const_26 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[46]); A_arbace_c2a_rules_A_const_27 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[47]); A_arbace_c2a_rules_A_const_28 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[48]); A_arbace_c2a_rules_A_const_29 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[49]); A_arbace_c2a_rules_A_const_30 = A_arbace_c2a_rules_A_const_pool.A[50]; A_arbace_c2a_rules_A_const_31 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[51]); A_arbace_c2a_rules_A_const_32 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[52]); A_arbace_c2a_rules_A_const_33 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[53]); A_arbace_c2a_rules_A_const_34 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[54]); A_arbace_c2a_rules_A_const_35 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[55]); A_arbace_c2a_rules_A_const_36 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[56]) }

func A_arbace_c2a_rules_A_clinit_p3() { A_arbace_c2a_rules_A_const_37 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[57]); A_arbace_c2a_rules_A_const_38 = A_arbace_c2a_rules_A_const_pool.A[58]; A_arbace_c2a_rules_A_const_39 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[59]); A_arbace_c2a_rules_A_const_40 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[60]); A_arbace_c2a_rules_A_const_41 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[61]); A_arbace_c2a_rules_A_const_42 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[62]); A_arbace_c2a_rules_A_const_43 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[63]); A_arbace_c2a_rules_A_const_44 = A_arbace_c2a_rules_A_const_pool.A[64]; A_arbace_c2a_rules_A_const_45 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[65]); A_arbace_c2a_rules_A_const_46 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[66]); A_arbace_c2a_rules_A_const_47 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[67]); A_arbace_c2a_rules_A_const_48 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[68]) }

func A_arbace_c2a_rules_A_clinit_p4() { A_arbace_c2a_rules_A_const_49 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[69]); A_arbace_c2a_rules_A_const_50 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[70]); A_arbace_c2a_rules_A_const_51 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[71]); A_arbace_c2a_rules_A_const_52 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[72]); A_arbace_c2a_rules_A_const_53 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[73]); A_arbace_c2a_rules_A_const_54 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[74]); A_arbace_c2a_rules_A_const_55 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[75]); A_arbace_c2a_rules_A_const_56 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[76]); A_arbace_c2a_rules_A_const_57 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[77]); A_arbace_c2a_rules_A_const_58 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[78]); A_arbace_c2a_rules_A_const_59 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[79]); A_arbace_c2a_rules_A_const_60 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[80]) }

func A_arbace_c2a_rules_A_clinit_p5() { A_arbace_c2a_rules_A_const_61 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[81]); A_arbace_c2a_rules_A_const_62 = A_arbace_c2a_rules_A_const_pool.A[82]; A_arbace_c2a_rules_A_const_63 = A_arbace_c2a_rules_A_const_pool.A[83]; A_arbace_c2a_rules_A_const_64 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[84]); A_arbace_c2a_rules_A_const_65 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[85]); A_arbace_c2a_rules_A_const_66 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[86]); A_arbace_c2a_rules_A_const_67 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[87]); A_arbace_c2a_rules_A_const_68 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[88]); A_arbace_c2a_rules_A_const_69 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[89]); A_arbace_c2a_rules_A_const_70 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[90]); A_arbace_c2a_rules_A_const_71 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[91]); A_arbace_c2a_rules_A_const_72 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[92]) }

func A_arbace_c2a_rules_A_clinit_p6() { A_arbace_c2a_rules_A_const_73 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[93]); A_arbace_c2a_rules_A_const_74 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[94]); A_arbace_c2a_rules_A_const_75 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[95]); A_arbace_c2a_rules_A_const_76 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[96]); A_arbace_c2a_rules_A_const_77 = lang.Keyword_Cast(A_arbace_c2a_rules_A_const_pool.A[97]); A_arbace_c2a_rules_A_const_78 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[98]); A_arbace_c2a_rules_A_const_79 = lang.Var_Cast(A_arbace_c2a_rules_A_const_pool.A[99]) }

func A_arbace_c2a_rules_A_New() *A_arbace_c2a_rules_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rules_A) Ctor() {}

func (t *A_arbace_c2a_rules_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_A_class }

func (t *A_arbace_c2a_rules_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_A); return ok }

func A_arbace_c2a_rules_A_Cast(x any) *A_arbace_c2a_rules_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_A_class)) }; return v }



type A_arbace_c2a_rules_applicable_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_applicable_A_fn_class *jrt.Class



type A_arbace_c2a_rules_applicable_fn__1094000103_A struct{ a2g_header uint64; F_ctx, F_skip any }

var A_arbace_c2a_rules_applicable_fn__1094000103_A_fn_class *jrt.Class



type A_arbace_c2a_rules_arbace_core_names_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_arbace_core_names_A_fn_class *jrt.Class



type A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_fn_class *jrt.Class



type A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_fn_class *jrt.Class



type A_arbace_c2a_rules_clojure_source_QMARK__A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_clojure_source_QMARK__A_fn_class *jrt.Class



type A_arbace_c2a_rules_core_names_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_core_names_A_fn_class *jrt.Class



type A_arbace_c2a_rules_defined_names_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_defined_names_A_fn_class *jrt.Class



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A struct{ a2g_header uint64; F_s any }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_fn_class *jrt.Class



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A struct{ a2g_header uint64; F_s__1094000062, F_iter__1094000061, F_s any }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_fn_class *jrt.Class



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A struct{ a2g_header uint64; F_s, F_b__1094000064 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_fn_class *jrt.Class



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A struct{ a2g_header uint64; F_h, F_s any }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_fn_class *jrt.Class



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A struct{ a2g_header uint64; F_h, F_s any }

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_fn_class *jrt.Class



type A_arbace_c2a_rules_eval1094000004_A struct{ jrt.Object }

func A_arbace_c2a_rules_eval1094000004_A_New() *A_arbace_c2a_rules_eval1094000004_A { t := &A_arbace_c2a_rules_eval1094000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rules_eval1094000004_A) Ctor() {}

func (t *A_arbace_c2a_rules_eval1094000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_eval1094000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_eval1094000004_A_class }

func (t *A_arbace_c2a_rules_eval1094000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_eval1094000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_eval1094000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_eval1094000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_eval1094000004_A); return ok }

func A_arbace_c2a_rules_eval1094000004_A_Cast(x any) *A_arbace_c2a_rules_eval1094000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_eval1094000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_eval1094000004_A_class)) }; return v }



type A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_fn_class *jrt.Class



type A_arbace_c2a_rules_eval1094000008_A struct{ jrt.Object }

func A_arbace_c2a_rules_eval1094000008_A_New() *A_arbace_c2a_rules_eval1094000008_A { t := &A_arbace_c2a_rules_eval1094000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rules_eval1094000008_A) Ctor() {}

func (t *A_arbace_c2a_rules_eval1094000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_eval1094000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_eval1094000008_A_class }

func (t *A_arbace_c2a_rules_eval1094000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_eval1094000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_eval1094000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_eval1094000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_eval1094000008_A); return ok }

func A_arbace_c2a_rules_eval1094000008_A_Cast(x any) *A_arbace_c2a_rules_eval1094000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_eval1094000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_eval1094000008_A_class)) }; return v }



type A_arbace_c2a_rules_eval1094000008_fn__1094000009_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_fn_class *jrt.Class



type A_arbace_c2a_rules_fn__1094000090_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_fn__1094000090_A_fn_class *jrt.Class



type A_arbace_c2a_rules_fn__1094000092_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_fn__1094000092_A_fn_class *jrt.Class



type A_arbace_c2a_rules_fn__1094000094_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_fn__1094000094_A_fn_class *jrt.Class



type A_arbace_c2a_rules_fn__1094000096_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_fn__1094000096_A_fn_class *jrt.Class



type A_arbace_c2a_rules_fn__1094000098_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_fn__1094000098_A_fn_class *jrt.Class



type A_arbace_c2a_rules_fn__1094000100_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_fn__1094000100_A_fn_class *jrt.Class



type A_arbace_c2a_rules_imports_QMARK__A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_imports_QMARK__A_fn_class *jrt.Class



type A_arbace_c2a_rules_insert_at_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_insert_at_A_fn_class *jrt.Class



type A_arbace_c2a_rules_proxy_methods_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_proxy_methods_A_fn_class *jrt.Class



type A_arbace_c2a_rules_proxy_methods_fn__1094000014_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_fn_class *jrt.Class



type A_arbace_c2a_rules_security_manager_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_security_manager_A_fn_class *jrt.Class



type A_arbace_c2a_rules_security_manager_fn__1094000030_A struct{ a2g_header uint64; F_s any }

var A_arbace_c2a_rules_security_manager_fn__1094000030_A_fn_class *jrt.Class



type A_arbace_c2a_rules_security_manager_fn__1094000036_A struct{ a2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_c2a_rules_security_manager_fn__1094000036_A_fn_class *jrt.Class



type A_arbace_c2a_rules_security_manager_fn__1094000042_A struct{ a2g_header uint64; F_s, F_in_import_QMARK_ any }

var A_arbace_c2a_rules_security_manager_fn__1094000042_A_fn_class *jrt.Class



type A_arbace_c2a_rules_security_manager_fn__1094000048_A struct{ a2g_header uint64; F_sb, F_s any }

var A_arbace_c2a_rules_security_manager_fn__1094000048_A_fn_class *jrt.Class



type A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A struct{ a2g_header uint64; F_import_spans any }

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_fn_class *jrt.Class



type A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A struct{ a2g_header uint64; F_i any }

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_fn_class *jrt.Class



type A_arbace_c2a_rules_translate_A struct{ a2g_header uint64 }

var A_arbace_c2a_rules_translate_A_fn_class *jrt.Class



type A_arbace_c2a_rules_translate_fn__1094000106_A struct{ a2g_header uint64; F_ctx any }

var A_arbace_c2a_rules_translate_fn__1094000106_A_fn_class *jrt.Class
