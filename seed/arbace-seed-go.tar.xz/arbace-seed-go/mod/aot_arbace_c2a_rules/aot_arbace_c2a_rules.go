//line aot_arbace_c2a_rules.ae:1
package aot_arbace_c2a_rules

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_New() *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A { A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_Init(); t := &A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp14 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp7 = A_arbace_c2a_rules_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_c2a_rules_A_Init(); tmp9 = A_arbace_c2a_rules_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_c2a_rules_A_Init(); tmp11 = A_arbace_c2a_rules_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_c2a_rules_A_Init(); tmp13 = A_arbace_c2a_rules_A_const_5; tmp3 = tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp13) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp14 != nil { panic(tmp14) }; return tmp3 }
//line :1:1
func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_New() *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A { A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_Init(); t := &A_arbace_c2a_rules_eval1094000008_fn__1094000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_7; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_10; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp7 = A_arbace_c2a_rules_A_const_8; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_c2a_rules_A_Init(); tmp9 = A_arbace_c2a_rules_A_const_9; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }

















func A_arbace_c2a_rules_clojure_source_QMARK__A_New() *A_arbace_c2a_rules_clojure_source_QMARK__A { A_arbace_c2a_rules_clojure_source_QMARK__A_Init(); t := &A_arbace_c2a_rules_clojure_source_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) Invoke_O_O__O(self, ctx__0 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_12; var tmp4 any = tmp3; var tmp5 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_13; return tmp2.Invoke_O_O__O(tmp4, jrt.NN(tmp5).Invoke_O__O(ctx__0)) }







func A_arbace_c2a_rules_proxy_methods_A_New() *A_arbace_c2a_rules_proxy_methods_A { A_arbace_c2a_rules_proxy_methods_A_Init(); t := &A_arbace_c2a_rules_proxy_methods_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c2a_rules_proxy_methods_A) Ctor() {}
//line :27:1
func (t *A_arbace_c2a_rules_proxy_methods_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_14; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_New(); var tmp4 *jrt.Class; A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_Init(); tmp4 = A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_16; return tmp2.Invoke_O_O_O__O(tmp5, s__0, jrt.NN(tmp6).GetRawRoot__O()) }
//line :30:1
func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_New() *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A { A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_Init(); t := &A_arbace_c2a_rules_proxy_methods_fn__1094000014_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) Ctor() {}
//line :30:1
func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) Invoke_O_O_O__O(self, s__1, p__1094000013__2 any) any { var vec__1094000015__3 any = p__1094000013__2; var re__4 any = lang.RT_Nth_O_I_O__O(vec__1094000015__3, lang.RT_IntCast_J__I(0), nil); var to__5 any = lang.RT_Nth_O_I_O__O(vec__1094000015__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(s__1, re__4, to__5) }





func A_arbace_c2a_rules_imports_QMARK__A_New() *A_arbace_c2a_rules_imports_QMARK__A { A_arbace_c2a_rules_imports_QMARK__A_Init(); t := &A_arbace_c2a_rules_imports_QMARK__A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_c2a_rules_imports_QMARK__A) Ctor() {}
//line :36:1
func (t *A_arbace_c2a_rules_imports_QMARK__A) Invoke_O_O__O(self, head__0 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_17; return tmp2.Invoke_O_O__O(tmp3, head__0) }

func A_arbace_c2a_rules_security_manager_A_New() *A_arbace_c2a_rules_security_manager_A { A_arbace_c2a_rules_security_manager_A_Init(); t := &A_arbace_c2a_rules_security_manager_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_c2a_rules_security_manager_A) Ctor() {}
//line :38:1
func (t *A_arbace_c2a_rules_security_manager_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_24; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_25; if jrt.A2g_Truth(tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(s__0, jrt.NN(tmp5).GetRawRoot__O()))) { return s__0 } else { var import_spans__2 any; var tmp6 *lang.Var

		A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_19; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp8 = A_arbace_c2a_rules_A_const_26; import_spans__2 = tmp7.Invoke_O_O__O(s__0, jrt.NN(tmp8).GetRawRoot__O())
//line :42:1
		var in_import_QMARK___3 any; var tmp9 any = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_New_O(import_spans__2); var tmp10 *jrt.Class


		A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_Init(); tmp10 = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_fn_class; in_import_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)
//line :42:1
		var tokens__4 any; var tmp11 *lang.Var



		A_arbace_c2a_rules_A_Init(); tmp11 = A_arbace_c2a_rules_A_const_21; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = A_arbace_c2a_rules_security_manager_fn__1094000030_A_New_O(s__0); var tmp14 *jrt.Class; A_arbace_c2a_rules_security_manager_fn__1094000030_A_Init(); tmp14 = A_arbace_c2a_rules_security_manager_fn__1094000030_A_fn_class; var tmp15 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp16 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp16 = A_arbace_c2a_rules_A_const_28; tokens__4 = tmp12.Invoke_O_O__O(tmp15, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__0))
//line :42:1
		var imported_QMARK___5 any; var tmp17 *lang.Var




		A_arbace_c2a_rules_A_Init(); tmp17 = A_arbace_c2a_rules_A_const_20; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = A_arbace_c2a_rules_security_manager_fn__1094000036_A_New_O_O(s__0, in_import_QMARK___3); var tmp20 *jrt.Class; A_arbace_c2a_rules_security_manager_fn__1094000036_A_Init(); tmp20 = A_arbace_c2a_rules_security_manager_fn__1094000036_A_fn_class; imported_QMARK___5 = tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), tokens__4)
//line :42:1
		var uses__6 any; var tmp21 *lang.Var







		A_arbace_c2a_rules_A_Init(); tmp21 = A_arbace_c2a_rules_A_const_21; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any = A_arbace_c2a_rules_security_manager_fn__1094000042_A_New_O_O(s__0, in_import_QMARK___3); var tmp24 *jrt.Class; A_arbace_c2a_rules_security_manager_fn__1094000042_A_Init(); tmp24 = A_arbace_c2a_rules_security_manager_fn__1094000042_A_fn_class; uses__6 = tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), tokens__4)




		var tmp25 any; var or__1927000174__auto____7 any = imported_QMARK___5; if jrt.A2g_Truth(or__1927000174__auto____7) { tmp25 = or__1927000174__auto____7 } else { var tmp26 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp26 = A_arbace_c2a_rules_A_const_22; tmp25 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(uses__6) }; if jrt.A2g_Truth(tmp25) { return s__0 } else { var sb__7 any = jrt.StringBuilder_New(); var end__8 any; var tmp27 *lang.Var


			A_arbace_c2a_rules_A_Init(); tmp27 = A_arbace_c2a_rules_A_const_14; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any = A_arbace_c2a_rules_security_manager_fn__1094000048_A_New_O_O(sb__7, s__0); var tmp30 *jrt.Class; A_arbace_c2a_rules_security_manager_fn__1094000048_A_Init(); tmp30 = A_arbace_c2a_rules_security_manager_fn__1094000048_A_fn_class; var tmp31 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); var tmp32 any; A_arbace_c2a_rules_A_Init(); tmp32 = A_arbace_c2a_rules_A_const_30; end__8 = tmp28.Invoke_O_O_O__O(tmp31, tmp32, uses__6)




			jrt.NN(jrt.StringBuilder_Cast(sb__7)).Append_CharSequence_I_I__StringBuilder(jrt.CharSequence_Cast(s__0), lang.RT_IntCast_O__I(end__8), lang.RT_Count_O__I(s__0))
			var tmp33 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp33 = A_arbace_c2a_rules_A_const_23; return lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(sb__7) } } }
//line :45:1
func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_New_O(p0 any) *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A { A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_Init(); t := &A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A{}; t.Ctor_O(p0); return t }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) Ctor_O(c__import_spans any) { t.F_import_spans = c__import_spans }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_New_O(i__1); var tmp4 *jrt.Class; A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_Init(); tmp4 = A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_import_spans) }
//line :45:1
func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_New_O(p0 any) *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A { A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_Init(); t := &A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A{}; t.Ctor_O(p0); return t }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :45:1
func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) Invoke_O_O__O(self, p__1094000022__1 any) any { var vec__1094000024__2 any = p__1094000022__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000024__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000024__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 bool = lang.Numbers_Lte_O_O__Z(a__3, t.F_i); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_O__Z(t.F_i, b__4)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }
func A_arbace_c2a_rules_security_manager_fn__1094000030_A_New_O(p0 any) *A_arbace_c2a_rules_security_manager_fn__1094000030_A { A_arbace_c2a_rules_security_manager_fn__1094000030_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000030_A{}; t.Ctor_O(p0); return t }
//line :46:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :46:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) Invoke_O_O__O(self, p__1094000029__1 any) any { var vec__1094000031__2 any = p__1094000029__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000031__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000031__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_24; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_27; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4); var tmp5 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_25; return tmp2.Invoke_O_O__O(tmp4, jrt.NN(tmp5).GetRawRoot__O()) }
func A_arbace_c2a_rules_security_manager_fn__1094000036_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_security_manager_fn__1094000036_A { A_arbace_c2a_rules_security_manager_fn__1094000036_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000036_A{}; t.Ctor_O_O(p0, p1); return t }
//line :47:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :47:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) Invoke_O_O__O(self, p__1094000035__1 any) any { var vec__1094000037__2 any = p__1094000035__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000037__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000037__2, lang.RT_IntCast_J__I(1), nil); var and__1927000168__auto____5 any = lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3); if jrt.A2g_Truth(and__1927000168__auto____5) {
														var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_25; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_118, nil); var tmp6 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_25; var tmp7 any = lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp6).GetRawRoot__O())).Ref())); var tmp8 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp8 = A_arbace_c2a_rules_A_const_27; return tmp2.Invoke_O_O__O(tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4)) } else {
//line :47:1
		return and__1927000168__auto____5 } }


func A_arbace_c2a_rules_security_manager_fn__1094000042_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_security_manager_fn__1094000042_A { A_arbace_c2a_rules_security_manager_fn__1094000042_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000042_A{}; t.Ctor_O_O(p0, p1); return t }
//line :50:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) Ctor_O_O(c__s, c__in_import_QMARK_ any) { t.F_s = c__s; t.F_in_import_QMARK_ = c__in_import_QMARK_ }
//line :50:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) Invoke_O_O__O(self, p__1094000041__1 any) any { var vec__1094000043__2 any = p__1094000041__1; var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000043__2, lang.RT_IntCast_J__I(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O(vec__1094000043__2, lang.RT_IntCast_J__I(1), nil); var t__5 any; var tmp1 *lang.Var;
														A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_27; t__5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_s, a__3, b__4); var and__1927000168__auto____6 any; var tmp2 /*line :50:1*/*lang.Var;

	A_arbace_c2a_rules_A_Init(); tmp2 = A_arbace_c2a_rules_A_const_18; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_in_import_QMARK_).Invoke_O__O(a__3)); if jrt.A2g_Truth(and__1927000168__auto____6) { var or__1927000174__auto____7 bool; var tmp3 *lang.Var
		A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_25; or__1927000174__auto____7 = lang.Util_Equiv_O_O__Z(t__5, jrt.NN(tmp3).GetRawRoot__O()); if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_120); var tmp5 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_25; or__1927000174__auto____8 = lang.Util_Equiv_O_O__Z(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, jrt.NN(tmp5).GetRawRoot__O(), nil)).Ref()); if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var tmp6 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_29; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_121); var tmp9 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp9 = A_arbace_c2a_rules_A_const_25; return tmp7.Invoke_O_O__O(t__5, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, jrt.NN(tmp9).GetRawRoot__O(), nil)).Ref()) } } } else {
//line :52:1
			return and__1927000168__auto____6 } }





func A_arbace_c2a_rules_security_manager_fn__1094000048_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_security_manager_fn__1094000048_A { A_arbace_c2a_rules_security_manager_fn__1094000048_A_Init(); t := &A_arbace_c2a_rules_security_manager_fn__1094000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :58:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) Ctor_O_O(c__sb, c__s any) { t.F_sb = c__sb; t.F_s = c__s }
//line :58:1
func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) Invoke_O_O_O__O(self, i__1, p__1094000047__2 any) any { var vec__1094000049__3 any = p__1094000047__2; var a__4 any = lang.RT_Nth_O_I_O__O(vec__1094000049__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1094000049__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); _ = ___5;
															jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I(i__1), lang.RT_IntCast_O__I(a__4)); var tmp3 /*line :60:1*/*jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp3).Append_String__StringBuilder(Lit_118); return a__4 }







func A_arbace_c2a_rules_arbace_core_names_A_New() *A_arbace_c2a_rules_arbace_core_names_A { A_arbace_c2a_rules_arbace_core_names_A_Init(); t := &A_arbace_c2a_rules_arbace_core_names_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_c2a_rules_arbace_core_names_A) Ctor() {}
//line :68:1
func (t *A_arbace_c2a_rules_arbace_core_names_A) Invoke_O__O(self any) any {



	var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp3 = lang.PersistentHashSet_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_32; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp7 = A_arbace_c2a_rules_A_const_21; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_New(); var tmp10 *jrt.Class; A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_Init(); tmp10 = A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_fn_class; var tmp11 any = tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)); var tmp12 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp12 = A_arbace_c2a_rules_A_const_34; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_New(); var tmp15 *jrt.Class; A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_Init(); tmp15 = A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_fn_class; var tmp16 any = tmp6.Invoke_O_O__O(tmp11, tmp13.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil))); var tmp17 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp17 = A_arbace_c2a_rules_A_const_33; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp19 = A_arbace_c2a_rules_A_const_37; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_c2a_rules_A_Init(); tmp21 = A_arbace_c2a_rules_A_const_38; return tmp2.Invoke_O_O_O__O(tmp4, tmp16, tmp18.Invoke_O__O(tmp20.Invoke_O__O(tmp21))) }
//line :72:1
func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_New() *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A { A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_Init(); t := &A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) Ctor() {}
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) Invoke_O_O__O(self, p1__1094000054_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_35; var tmp2 *lang.Keyword = tmp1; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_85, jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__1094000054_SHARP___1)))).Ref() }
//line :72:1
func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_New() *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A { A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_Init(); t := &A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) Ctor() {}
//line :72:1
func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) Invoke_O_O__O(self, p1__1094000055_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_36; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(p1__1094000055_SHARP___1).F_sym.Ref()) }






func A_arbace_c2a_rules_defined_names_A_New() *A_arbace_c2a_rules_defined_names_A { A_arbace_c2a_rules_defined_names_A_Init(); t := &A_arbace_c2a_rules_defined_names_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_c2a_rules_defined_names_A) Ctor() {}
//line :79:1
func (t *A_arbace_c2a_rules_defined_names_A) Invoke_O_O__O(self, s__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_New_O(s__0); var tmp2 *jrt.Class;


	A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_Init(); tmp2 = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_19; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_55; return tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(s__0, jrt.NN(tmp6).GetRawRoot__O())) }
//line :82:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_New_O(p0 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) Invoke_O_O__O(self, s__1094000062__1 any) any { var tmp1 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_New_O_O_O(s__1094000062__1, self, t.F_s); var tmp2 *jrt.Class; A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_Init(); tmp2 = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :82:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) Ctor_O_O_O(c__s__1094000062, c__iter__1094000061, c__s any) { t.F_s__1094000062 = c__s__1094000062; t.F_iter__1094000061 = c__iter__1094000061; t.F_s = c__s }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) Invoke_O__O(self any) any { { var s__1094000062__1 any; var t_ any = t.F_s__1094000062; t.F_s__1094000062 = nil; s__1094000062__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_39; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1094000062__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1094000062__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp2 = A_arbace_c2a_rules_A_const_40; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1094000062__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_41; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1094000062__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1094000064__6 any; var tmp4 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_42; b__1094000064__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_New_O_O_I_O(t.F_s, b__1094000064__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_Init(); tmp6 = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp7 = A_arbace_c2a_rules_A_const_49; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp9 = A_arbace_c2a_rules_A_const_52; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1094000064__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1094000061); var tmp12 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp12 = A_arbace_c2a_rules_A_const_53; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1094000062__3))) } else { var tmp13 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp13 = A_arbace_c2a_rules_A_const_49; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp15 = A_arbace_c2a_rules_A_const_52; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1094000064__6), nil) } } else { var vec__1094000074__4 any; var tmp16 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp16 = A_arbace_c2a_rules_A_const_50; vec__1094000074__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1094000062__3); var a__5 any = lang.RT_Nth_O_I_O__O(vec__1094000074__4, lang.RT_IntCast_J__I(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O(vec__1094000074__4, lang.RT_IntCast_J__I(1), nil); var h__7 any; var tmp17 *lang.Var; _ = ___6
															A_arbace_c2a_rules_A_Init(); tmp17 = A_arbace_c2a_rules_A_const_43; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = t.F_s; h__7 = tmp18.Invoke_O_O__O(tmp19, lang.Numbers_Inc_O__Number(a__5))
//line :82:1
	var j__8 any; var tmp20 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_New_O_O(h__7, t.F_s); var tmp21 *jrt.Class

	A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_Init(); tmp21 = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_fn_class; j__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil).Invoke__O()
//line :82:1
	var t__9 any; var tmp22 *lang.Var









	A_arbace_c2a_rules_A_Init(); tmp22 = A_arbace_c2a_rules_A_const_27; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any = t.F_s; var tmp25 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp25 = A_arbace_c2a_rules_A_const_46; t__9 = tmp23.Invoke_O_O_O__O(tmp24, j__8, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(t.F_s, j__8))
//line :82:1
	var tmp26 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp26 = A_arbace_c2a_rules_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(t__9)) { var tmp27 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp27 = A_arbace_c2a_rules_A_const_51; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 lang.IFn = lang.IFn_Cast(t.F_iter__1094000061); var tmp30 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp30 = A_arbace_c2a_rules_A_const_54; return tmp28.Invoke_O_O__O(t__9, tmp29.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(s__1094000062__3))) } else { var tmp31 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp31 = A_arbace_c2a_rules_A_const_54; s__1094000062__1 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(s__1094000062__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :82:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) Ctor_O_O_I_O(c__s, c__b__1094000064 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_s = c__s; t.F_b__1094000064 = c__b__1094000064; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :82:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) Invoke_O__O(self any) any { { var i__1094000063__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1094000063__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1094000068__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1094000063__1)); var a__3 any = lang.RT_Nth_O_I_O__O(vec__1094000068__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__1094000068__2, lang.RT_IntCast_J__I(1), nil); var h__5 any; var tmp2 *lang.Var; _ = ___4
																	A_arbace_c2a_rules_A_Init(); tmp2 = A_arbace_c2a_rules_A_const_43; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_s; h__5 = tmp3.Invoke_O_O__O(tmp4, lang.Numbers_Inc_O__Number(a__3))
//line :82:1
	var j__6 any; var tmp5 any = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_New_O_O(h__5, t.F_s); var tmp6 *jrt.Class

	A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_Init(); tmp6 = A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_fn_class; j__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :82:1
	var t__7 any; var tmp7 *lang.Var









	A_arbace_c2a_rules_A_Init(); tmp7 = A_arbace_c2a_rules_A_const_27; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_s; var tmp10 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp10 = A_arbace_c2a_rules_A_const_46; t__7 = tmp8.Invoke_O_O_O__O(tmp9, j__6, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(t.F_s, j__6))
//line :82:1
	var tmp11 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp11 = A_arbace_c2a_rules_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(t__7)) { var tmp12 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp12 = A_arbace_c2a_rules_A_const_48; lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(t.F_b__1094000064, t__7); i__1094000063__1 = lang.Numbers_Unchecked_inc_J__J(i__1094000063__1); continue L1 } else { i__1094000063__1 = lang.Numbers_Unchecked_inc_J__J(i__1094000063__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A{}; t.Ctor_O_O(p0, p1); return t }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_43; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_s; var tmp4 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_46; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_s; var tmp7 any; var t_ any = t.F_h; t.F_h = nil; tmp7 = t_; j__1 = tmp2.Invoke_O_O__O(tmp3, tmp5.Invoke_O_O__O(tmp6, tmp7)); L1: for {

	if lang.Numbers_Gte_O_J__Z(j__1, int64(lang.RT_Count_O__I(t.F_s))) { return j__1 } else { var tmp8 any; A_arbace_c2a_rules_A_Init(); tmp8 = A_arbace_c2a_rules_A_const_44; var tmp9 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(tmp8)).CharValue__C(), jrt.NN(tmp9).CharAt_I__C(lang.RT_IntCast_O__I(j__1))) {

		var tmp10 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp10 = A_arbace_c2a_rules_A_const_43; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = t.F_s; var tmp13 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp13 = A_arbace_c2a_rules_A_const_47; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_s; var tmp16 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp16 = A_arbace_c2a_rules_A_const_43; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = t.F_s; j__1 = tmp11.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O__O(tmp15, tmp17.Invoke_O_O__O(tmp18, lang.Numbers_Inc_O__Number(j__1)))); continue L1 } else {
//line :86:1
			var tmp19 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp19).StartsWith_String_I__Z(Lit_101, lang.RT_IntCast_O__I(j__1)) {



				var tmp20 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp20 = A_arbace_c2a_rules_A_const_43; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any = t.F_s; var tmp23 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp23 = A_arbace_c2a_rules_A_const_47; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any = t.F_s; var tmp26 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp26 = A_arbace_c2a_rules_A_const_43; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 any = t.F_s; j__1 = tmp21.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp25, tmp27.Invoke_O_O__O(tmp28, lang.Numbers_Add_O_J__Number(j__1, 2)))); continue L1 } else {
//line :86:1
					var tmp29 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp29 = A_arbace_c2a_rules_A_const_45; if tmp29 != nil { return j__1 } else { return nil } } } } } }; /*line :84:1*/panic("a2g: unreachable") }
//line :84:1
func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_Init(); t := &A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) Ctor_O_O(c__h, c__s any) { t.F_h = c__h; t.F_s = c__s }
//line :84:1
func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_43; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_s; var tmp4 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_46; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_s; var tmp7 any; var t_ any = t.F_h; t.F_h = nil; tmp7 = t_; j__1 = tmp2.Invoke_O_O__O(tmp3, tmp5.Invoke_O_O__O(tmp6, tmp7)); L1: for {

	if lang.Numbers_Gte_O_J__Z(j__1, int64(lang.RT_Count_O__I(t.F_s))) { return j__1 } else { var tmp8 any; A_arbace_c2a_rules_A_Init(); tmp8 = A_arbace_c2a_rules_A_const_44; var tmp9 *jrt.String = jrt.String_Cast(t.F_s); if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(tmp8)).CharValue__C(), jrt.NN(tmp9).CharAt_I__C(lang.RT_IntCast_O__I(j__1))) {

		var tmp10 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp10 = A_arbace_c2a_rules_A_const_43; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = t.F_s; var tmp13 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp13 = A_arbace_c2a_rules_A_const_47; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_s; var tmp16 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp16 = A_arbace_c2a_rules_A_const_43; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any = t.F_s; j__1 = tmp11.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O__O(tmp15, tmp17.Invoke_O_O__O(tmp18, lang.Numbers_Inc_O__Number(j__1)))); continue L1 } else {
//line :86:1
			var tmp19 *jrt.String = jrt.String_Cast(t.F_s); if jrt.NN(tmp19).StartsWith_String_I__Z(Lit_101, lang.RT_IntCast_O__I(j__1)) {



				var tmp20 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp20 = A_arbace_c2a_rules_A_const_43; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any = t.F_s; var tmp23 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp23 = A_arbace_c2a_rules_A_const_47; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any = t.F_s; var tmp26 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp26 = A_arbace_c2a_rules_A_const_43; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 any = t.F_s; j__1 = tmp21.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp25, tmp27.Invoke_O_O__O(tmp28, lang.Numbers_Add_O_J__Number(j__1, 2)))); continue L1 } else {
//line :86:1
					var tmp29 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp29 = A_arbace_c2a_rules_A_const_45; if tmp29 != nil { return j__1 } else { return nil } } } } } }; /*line :84:1*/panic("a2g: unreachable") }











func A_arbace_c2a_rules_insert_at_A_New() *A_arbace_c2a_rules_insert_at_A { A_arbace_c2a_rules_insert_at_A_Init(); t := &A_arbace_c2a_rules_insert_at_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_c2a_rules_insert_at_A) Ctor() {}
//line :96:1
func (t *A_arbace_c2a_rules_insert_at_A) Invoke_O_O_O_O__O(self, s__0, i__1, x__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp2 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp2 = A_arbace_c2a_rules_A_const_27; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_30; var tmp5 any = tmp3.Invoke_O_O_O__O(s__0, tmp4, i__1); var tmp6 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_27; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp5, x__2, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1))).Ref() }

func A_arbace_c2a_rules_core_names_A_New() *A_arbace_c2a_rules_core_names_A { A_arbace_c2a_rules_core_names_A_Init(); t := &A_arbace_c2a_rules_core_names_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_c2a_rules_core_names_A) Ctor() {}
//line :98:1
func (t *A_arbace_c2a_rules_core_names_A) Invoke_O_O_O__O(self, s__0, added__1 any) any { var names__3 any; var tmp1 *lang.Var;






	A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_56; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_60; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_21; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp7 = A_arbace_c2a_rules_A_const_61; names__3 = tmp2.Invoke_O__O(tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(added__1, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(s__0)))); var vec__1094000083__4 any; var tmp8 /*line :98:1*/*lang.Var;







	A_arbace_c2a_rules_A_Init(); tmp8 = A_arbace_c2a_rules_A_const_50; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp10 = A_arbace_c2a_rules_A_const_19; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_c2a_rules_A_Init(); tmp12 = A_arbace_c2a_rules_A_const_62; vec__1094000083__4 = tmp9.Invoke_O__O(tmp11.Invoke_O_O__O(s__0, tmp12)); var ns_a__5 any = /*line :98:1*/lang.RT_Nth_O_I_O__O(vec__1094000083__4, lang.RT_IntCast_J__I(0), nil); var ns_b__6 any = lang.RT_Nth_O_I_O__O(vec__1094000083__4, lang.RT_IntCast_J__I(1), nil); var tmp13 any; var or__1927000174__auto____7 any; var tmp14 *lang.Var;








	A_arbace_c2a_rules_A_Init(); tmp14 = A_arbace_c2a_rules_A_const_22; or__1927000174__auto____7 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(names__3); if jrt.A2g_Truth(or__1927000174__auto____7) { tmp13 = or__1927000174__auto____7 } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(ns_a__5, nil)).Ref() }; if jrt.A2g_Truth(tmp13) { return s__0 } else { var ns_text__7 any; var tmp15 *lang.Var

		A_arbace_c2a_rules_A_Init(); tmp15 = A_arbace_c2a_rules_A_const_27; ns_text__7 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O_O__O(s__0, ns_a__5, ns_b__6)
//line :107:1
		var names_text__8 any; var tmp16 *lang.Var


		A_arbace_c2a_rules_A_Init(); tmp16 = A_arbace_c2a_rules_A_const_57; names_text__8 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O__O(Lit_89, names__3)
//line :107:1
		var vec__1094000086__9 any; var tmp17 *lang.Var



		A_arbace_c2a_rules_A_Init(); tmp17 = A_arbace_c2a_rules_A_const_50; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp19 = A_arbace_c2a_rules_A_const_19; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_c2a_rules_A_Init(); tmp21 = A_arbace_c2a_rules_A_const_63; vec__1094000086__9 = tmp18.Invoke_O__O(tmp20.Invoke_O_O__O(ns_text__7, tmp21))
//line :107:1
		var ra__10 any = lang.RT_Nth_O_I_O__O(vec__1094000086__9, lang.RT_IntCast_J__I(0), nil); var rb__11 any = lang.RT_Nth_O_I_O__O(vec__1094000086__9, lang.RT_IntCast_J__I(1), nil)




		if lang.Util_Identical_O_O__Z(ra__10, nil) {

			var tmp22 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp22 = A_arbace_c2a_rules_A_const_58; return lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Dec_O__Number(ns_b__6), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_90, nil, Lit_91), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref()) } else {
//line :112:1
				var tmp23 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp23 = A_arbace_c2a_rules_A_const_24; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp25 = A_arbace_c2a_rules_A_const_27; if jrt.A2g_Truth(tmp24.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O_O__O(ns_text__7, ra__10, rb__11), Lit_92)) { return s__0 } else { var tmp26 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp26 = A_arbace_c2a_rules_A_const_45; if tmp26 != nil { var rc__12 any; var tmp27 *lang.Var





					A_arbace_c2a_rules_A_Init(); tmp27 = A_arbace_c2a_rules_A_const_27; rc__12 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O_O__O(ns_text__7, ra__10, rb__11)
//line :112:1
					var ex__13 any; var tmp28 *lang.Var






					A_arbace_c2a_rules_A_Init(); tmp28 = A_arbace_c2a_rules_A_const_59; ex__13 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O_O__O(rc__12, Lit_93)
					if lang.Util_Identical_O_O__Z(ex__13, nil) {
						var tmp29 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp29 = A_arbace_c2a_rules_A_const_58; return lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Add_O_J__Number(lang.Numbers_Add_O_O__Number(ns_a__5, ra__10), lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(rc__12)))), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_94, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8, nil)).Ref()) } else {
//line :120:1
							var v__14 any; var tmp30 *lang.Var

							A_arbace_c2a_rules_A_Init(); tmp30 = A_arbace_c2a_rules_A_const_43; v__14 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(rc__12, lang.Numbers_Add_O_J__Number(ex__13, int64(lang.RT_Count_O__I(Lit_93))))
//line :120:1
							var ve__15 any; var tmp31 *lang.Var


							A_arbace_c2a_rules_A_Init(); tmp31 = A_arbace_c2a_rules_A_const_47; ve__15 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O_O__O(rc__12, v__14)
							var tmp32 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp32 = A_arbace_c2a_rules_A_const_58; return lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Add_O_O__Number(lang.Numbers_Add_O_O__Number(ns_a__5, ra__10), lang.Numbers_Dec_O__Number(ve__15)), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, names_text__8)).Ref()) } } else {
//line :112:1
								return nil } } } } }



















func A_arbace_c2a_rules_fn__1094000090_A_New() *A_arbace_c2a_rules_fn__1094000090_A { A_arbace_c2a_rules_fn__1094000090_A_Init(); t := &A_arbace_c2a_rules_fn__1094000090_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_c2a_rules_fn__1094000090_A) Ctor() {}
//line :132:1
func (t *A_arbace_c2a_rules_fn__1094000090_A) Invoke_O_O__O(self, ctx__0 any) any { var and__1927000168__auto____2 bool; var tmp1 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_64; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_13; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(ctx__0)); if and__1927000168__auto____2 { var tmp4 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_65; return jrt.NN(tmp4).Invoke_O__O(ctx__0) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }
func A_arbace_c2a_rules_fn__1094000092_A_New() *A_arbace_c2a_rules_fn__1094000092_A { A_arbace_c2a_rules_fn__1094000092_A_Init(); t := &A_arbace_c2a_rules_fn__1094000092_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_c2a_rules_fn__1094000092_A) Ctor() {}
//line :133:1
func (t *A_arbace_c2a_rules_fn__1094000092_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_66; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_67; return tmp2.Invoke_O_O__O(s__0, jrt.NN(tmp3).Invoke_O__O(ctx__1)) }






func A_arbace_c2a_rules_fn__1094000094_A_New() *A_arbace_c2a_rules_fn__1094000094_A { A_arbace_c2a_rules_fn__1094000094_A_Init(); t := &A_arbace_c2a_rules_fn__1094000094_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_c2a_rules_fn__1094000094_A) Ctor() {}
//line :140:1
func (t *A_arbace_c2a_rules_fn__1094000094_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_68; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0) }





func A_arbace_c2a_rules_fn__1094000096_A_New() *A_arbace_c2a_rules_fn__1094000096_A { A_arbace_c2a_rules_fn__1094000096_A_Init(); t := &A_arbace_c2a_rules_fn__1094000096_A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_c2a_rules_fn__1094000096_A) Ctor() {}
//line :146:1
func (t *A_arbace_c2a_rules_fn__1094000096_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_69; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0) }





func A_arbace_c2a_rules_fn__1094000098_A_New() *A_arbace_c2a_rules_fn__1094000098_A { A_arbace_c2a_rules_fn__1094000098_A_Init(); t := &A_arbace_c2a_rules_fn__1094000098_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_c2a_rules_fn__1094000098_A) Ctor() {}
//line :152:1
func (t *A_arbace_c2a_rules_fn__1094000098_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_70; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____3 any; var tmp4 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp4 = A_arbace_c2a_rules_A_const_71; or__1927000174__auto____3 = jrt.NN(tmp4).Invoke_O__O(ctx__1); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var tmp5 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp5 = A_arbace_c2a_rules_A_const_72; tmp3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke__O() }; return tmp2.Invoke_O_O__O(s__0, tmp3) }




func A_arbace_c2a_rules_fn__1094000100_A_New() *A_arbace_c2a_rules_fn__1094000100_A { A_arbace_c2a_rules_fn__1094000100_A_Init(); t := &A_arbace_c2a_rules_fn__1094000100_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_c2a_rules_fn__1094000100_A) Ctor() {}
//line :157:1
func (t *A_arbace_c2a_rules_fn__1094000100_A) Invoke_O_O_O__O(self, s__0, ___1 any) any { var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_73; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0) }






























func A_arbace_c2a_rules_applicable_A_New() *A_arbace_c2a_rules_applicable_A { A_arbace_c2a_rules_applicable_A_Init(); t := &A_arbace_c2a_rules_applicable_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_c2a_rules_applicable_A) Ctor() {}
//line :188:1
func (t *A_arbace_c2a_rules_applicable_A) Invoke_O_O_O__O(self, ctx__0, skip__1 any) any {


	var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_c2a_rules_applicable_fn__1094000103_A_New_O_O(ctx__0, skip__1); var tmp4 *jrt.Class; A_arbace_c2a_rules_applicable_fn__1094000103_A_Init(); tmp4 = A_arbace_c2a_rules_applicable_fn__1094000103_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_76; return tmp2.Invoke_O_O__O(tmp5, jrt.NN(tmp6).GetRawRoot__O()) }
//line :191:1
func A_arbace_c2a_rules_applicable_fn__1094000103_A_New_O_O(p0, p1 any) *A_arbace_c2a_rules_applicable_fn__1094000103_A { A_arbace_c2a_rules_applicable_fn__1094000103_A_Init(); t := &A_arbace_c2a_rules_applicable_fn__1094000103_A{}; t.Ctor_O_O(p0, p1); return t }
//line :191:1
func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) Ctor_O_O(c__ctx, c__skip any) { t.F_ctx = c__ctx; t.F_skip = c__skip }
//line :191:1
func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) Invoke_O_O__O(self, p1__1094000102_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp3 = A_arbace_c2a_rules_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_skip; var tmp6 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_75; and__1927000168__auto____2 = tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, jrt.NN(tmp6).Invoke_O__O(p1__1094000102_SHARP___1))); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp7 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp7 = A_arbace_c2a_rules_A_const_74; return lang.IFn_Cast(jrt.NN(tmp7).Invoke_O__O(p1__1094000102_SHARP___1)).Invoke_O__O(t.F_ctx) } else { return and__1927000168__auto____2 } }

func A_arbace_c2a_rules_translate_A_New() *A_arbace_c2a_rules_translate_A { A_arbace_c2a_rules_translate_A_Init(); t := &A_arbace_c2a_rules_translate_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_c2a_rules_translate_A) Ctor() {}
//line :193:1
func (t *A_arbace_c2a_rules_translate_A) Invoke_O_O_O_O__O(self, s__0, ctx__1, skip__2 any) any {




	var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_14; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_c2a_rules_translate_fn__1094000106_A_New_O(ctx__1); var tmp4 *jrt.Class; A_arbace_c2a_rules_translate_fn__1094000106_A_Init(); tmp4 = A_arbace_c2a_rules_translate_fn__1094000106_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp6 = A_arbace_c2a_rules_A_const_78; return tmp2.Invoke_O_O_O__O(tmp5, s__0, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(ctx__1, skip__2)) }
//line :193:1
func (t *A_arbace_c2a_rules_translate_A) Invoke_O_O_O__O(self, s__0, ctx__1 any) any {


	var tmp1 *lang.Var; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_79; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp3 = lang.PersistentHashSet_EMPTY; return tmp2.Invoke_O_O_O__O(s__0, ctx__1, tmp3.Ref())
}
func A_arbace_c2a_rules_translate_fn__1094000106_A_New_O(p0 any) *A_arbace_c2a_rules_translate_fn__1094000106_A { A_arbace_c2a_rules_translate_fn__1094000106_A_Init(); t := &A_arbace_c2a_rules_translate_fn__1094000106_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :198:1
func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) Invoke_O_O_O__O(self, s__1, r__2 any) any { var tmp1 *lang.Keyword; A_arbace_c2a_rules_A_Init(); tmp1 = A_arbace_c2a_rules_A_const_77; return lang.IFn_Cast(jrt.NN(tmp1).Invoke_O__O(r__2)).Invoke_O_O__O(s__1, t.F_ctx) }

















type A_arbace_c2a_rules_A struct{ jrt.Object }

var A_arbace_c2a_rules_A_const_0 *lang.Var

var A_arbace_c2a_rules_A_const_1 *lang.Var

var A_arbace_c2a_rules_A_const_2 any

var A_arbace_c2a_rules_A_const_3 any

var A_arbace_c2a_rules_A_const_4 any

var A_arbace_c2a_rules_A_const_5 any

var A_arbace_c2a_rules_A_const_6 *lang.Var

var A_arbace_c2a_rules_A_const_7 *lang.Var

var A_arbace_c2a_rules_A_const_8 *lang.Var

var A_arbace_c2a_rules_A_const_9 any

var A_arbace_c2a_rules_A_const_10 *lang.Var

var A_arbace_c2a_rules_A_const_11 *lang.Var

var A_arbace_c2a_rules_A_const_12 any

var A_arbace_c2a_rules_A_const_13 *lang.Keyword

var A_arbace_c2a_rules_A_const_14 *lang.Var

var A_arbace_c2a_rules_A_const_15 *lang.Var

var A_arbace_c2a_rules_A_const_16 *lang.Var

var A_arbace_c2a_rules_A_const_17 any

var A_arbace_c2a_rules_A_const_18 *lang.Var

var A_arbace_c2a_rules_A_const_19 *lang.Var

var A_arbace_c2a_rules_A_const_20 *lang.Var

var A_arbace_c2a_rules_A_const_21 *lang.Var

var A_arbace_c2a_rules_A_const_22 *lang.Var

var A_arbace_c2a_rules_A_const_23 *lang.Var

var A_arbace_c2a_rules_A_const_24 *lang.Var

var A_arbace_c2a_rules_A_const_25 *lang.Var

var A_arbace_c2a_rules_A_const_26 *lang.Var

var A_arbace_c2a_rules_A_const_27 *lang.Var

var A_arbace_c2a_rules_A_const_28 *lang.Var

var A_arbace_c2a_rules_A_const_29 *lang.Var

var A_arbace_c2a_rules_A_const_30 any

var A_arbace_c2a_rules_A_const_31 *lang.Var

var A_arbace_c2a_rules_A_const_32 *lang.Var

var A_arbace_c2a_rules_A_const_33 *lang.Var

var A_arbace_c2a_rules_A_const_34 *lang.Var

var A_arbace_c2a_rules_A_const_35 *lang.Keyword

var A_arbace_c2a_rules_A_const_36 *lang.Var

var A_arbace_c2a_rules_A_const_37 *lang.Var

var A_arbace_c2a_rules_A_const_38 any

var A_arbace_c2a_rules_A_const_39 *lang.Var

var A_arbace_c2a_rules_A_const_40 *lang.Var

var A_arbace_c2a_rules_A_const_41 *lang.Var

var A_arbace_c2a_rules_A_const_42 *lang.Var

var A_arbace_c2a_rules_A_const_43 *lang.Var

var A_arbace_c2a_rules_A_const_44 any

var A_arbace_c2a_rules_A_const_45 *lang.Keyword

var A_arbace_c2a_rules_A_const_46 *lang.Var

var A_arbace_c2a_rules_A_const_47 *lang.Var

var A_arbace_c2a_rules_A_const_48 *lang.Var

var A_arbace_c2a_rules_A_const_49 *lang.Var

var A_arbace_c2a_rules_A_const_50 *lang.Var

var A_arbace_c2a_rules_A_const_51 *lang.Var

var A_arbace_c2a_rules_A_const_52 *lang.Var

var A_arbace_c2a_rules_A_const_53 *lang.Var

var A_arbace_c2a_rules_A_const_54 *lang.Var

var A_arbace_c2a_rules_A_const_55 *lang.Var

var A_arbace_c2a_rules_A_const_56 *lang.Var

var A_arbace_c2a_rules_A_const_57 *lang.Var

var A_arbace_c2a_rules_A_const_58 *lang.Var

var A_arbace_c2a_rules_A_const_59 *lang.Var

var A_arbace_c2a_rules_A_const_60 *lang.Var

var A_arbace_c2a_rules_A_const_61 *lang.Var

var A_arbace_c2a_rules_A_const_62 any

var A_arbace_c2a_rules_A_const_63 any

var A_arbace_c2a_rules_A_const_64 *lang.Keyword

var A_arbace_c2a_rules_A_const_65 *lang.Keyword

var A_arbace_c2a_rules_A_const_66 *lang.Var

var A_arbace_c2a_rules_A_const_67 *lang.Keyword

var A_arbace_c2a_rules_A_const_68 *lang.Var

var A_arbace_c2a_rules_A_const_69 *lang.Var

var A_arbace_c2a_rules_A_const_70 *lang.Var

var A_arbace_c2a_rules_A_const_71 *lang.Keyword

var A_arbace_c2a_rules_A_const_72 *lang.Var

var A_arbace_c2a_rules_A_const_73 *lang.Var

var A_arbace_c2a_rules_A_const_74 *lang.Keyword

var A_arbace_c2a_rules_A_const_75 *lang.Keyword

var A_arbace_c2a_rules_A_const_76 *lang.Var

var A_arbace_c2a_rules_A_const_77 *lang.Keyword

var A_arbace_c2a_rules_A_const_78 *lang.Var

var A_arbace_c2a_rules_A_const_79 *lang.Var

var A_arbace_c2a_rules_A_init jrt.ClassInit

func A_arbace_c2a_rules_A_Init() { if !A_arbace_c2a_rules_A_init.Done() { A_arbace_c2a_rules_A_init.Run(A_arbace_c2a_rules_A_clinit) } }

func A_arbace_c2a_rules_A_clinit() { A_arbace_c2a_rules_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_c2a_rules_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_c2a_rules_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_rules_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_c2a_rules_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_c2a_rules_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_c2a_rules_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_c2a_rules_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_c2a_rules_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_c2a_rules_A_const_9 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_c2a_rules_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_c2a_rules_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_c2a_rules_A_const_12 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref())).Ref(); A_arbace_c2a_rules_A_const_13 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_c2a_rules_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_c2a_rules_A_const_15 = lang.RT_Var_String_String__Var(Lit_8, Lit_22); A_arbace_c2a_rules_A_const_16 = lang.RT_Var_String_String__Var(Lit_13, Lit_23); A_arbace_c2a_rules_A_const_17 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_24, Lit_25)).Ref(); A_arbace_c2a_rules_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_c2a_rules_A_const_19 = lang.RT_Var_String_String__Var(Lit_6, Lit_27); A_arbace_c2a_rules_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_c2a_rules_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_c2a_rules_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_c2a_rules_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_c2a_rules_A_const_24 = lang.RT_Var_String_String__Var(Lit_8, Lit_31); A_arbace_c2a_rules_A_const_25 = lang.RT_Var_String_String__Var(Lit_13, Lit_32); A_arbace_c2a_rules_A_const_26 = lang.RT_Var_String_String__Var(Lit_13, Lit_33); A_arbace_c2a_rules_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_c2a_rules_A_const_28 = lang.RT_Var_String_String__Var(Lit_6, Lit_35); A_arbace_c2a_rules_A_const_29 = lang.RT_Var_String_String__Var(Lit_8, Lit_36); A_arbace_c2a_rules_A_const_30 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_c2a_rules_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_c2a_rules_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_c2a_rules_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_c2a_rules_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_c2a_rules_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_c2a_rules_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_c2a_rules_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_c2a_rules_A_const_38 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_rules_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_c2a_rules_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_c2a_rules_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_c2a_rules_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_c2a_rules_A_const_43 = lang.RT_Var_String_String__Var(Lit_6, Lit_48); A_arbace_c2a_rules_A_const_44 = jrt.Character_ValueOf_C__Character(94).Ref(); A_arbace_c2a_rules_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_c2a_rules_A_const_46 = lang.RT_Var_String_String__Var(Lit_6, Lit_50); A_arbace_c2a_rules_A_const_47 = lang.RT_Var_String_String__Var(Lit_6, Lit_51); A_arbace_c2a_rules_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_c2a_rules_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_c2a_rules_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_c2a_rules_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_c2a_rules_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_c2a_rules_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_c2a_rules_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_c2a_rules_A_const_55 = lang.RT_Var_String_String__Var(Lit_13, Lit_59); A_arbace_c2a_rules_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_c2a_rules_A_const_57 = lang.RT_Var_String_String__Var(Lit_8, Lit_61); A_arbace_c2a_rules_A_const_58 = lang.RT_Var_String_String__Var(Lit_13, Lit_62); A_arbace_c2a_rules_A_const_59 = lang.RT_Var_String_String__Var(Lit_8, Lit_63); A_arbace_c2a_rules_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_c2a_rules_A_const_61 = lang.RT_Var_String_String__Var(Lit_13, Lit_65); A_arbace_c2a_rules_A_const_62 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_66)).Ref(); A_arbace_c2a_rules_A_const_63 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_67)).Ref(); A_arbace_c2a_rules_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_c2a_rules_A_const_65 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_c2a_rules_A_const_66 = lang.RT_Var_String_String__Var(Lit_6, Lit_69); A_arbace_c2a_rules_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_70); A_arbace_c2a_rules_A_const_68 = lang.RT_Var_String_String__Var(Lit_3, Lit_5); A_arbace_c2a_rules_A_const_69 = lang.RT_Var_String_String__Var(Lit_13, Lit_71); A_arbace_c2a_rules_A_const_70 = lang.RT_Var_String_String__Var(Lit_13, Lit_72); A_arbace_c2a_rules_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_c2a_rules_A_const_72 = lang.RT_Var_String_String__Var(Lit_13, Lit_73); A_arbace_c2a_rules_A_const_73 = lang.RT_Var_String_String__Var(Lit_13, Lit_74); A_arbace_c2a_rules_A_const_74 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_c2a_rules_A_const_75 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_c2a_rules_A_const_76 = lang.RT_Var_String_String__Var(Lit_13, Lit_77); A_arbace_c2a_rules_A_const_77 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_c2a_rules_A_const_78 = lang.RT_Var_String_String__Var(Lit_13, Lit_79); A_arbace_c2a_rules_A_const_79 = lang.RT_Var_String_String__Var(Lit_13, Lit_80) }

func A_arbace_c2a_rules_A_New() *A_arbace_c2a_rules_A { A_arbace_c2a_rules_A_Init(); t := &A_arbace_c2a_rules_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rules_A) Ctor() {}

func (t *A_arbace_c2a_rules_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_A_class }

func (t *A_arbace_c2a_rules_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_A); return ok }

func A_arbace_c2a_rules_A_Cast(x any) *A_arbace_c2a_rules_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_A_class)) }; return v }



type A_arbace_c2a_rules_applicable_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_applicable_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_applicable_A_fn_class *jrt.Class

var A_arbace_c2a_rules_applicable_A_init jrt.ClassInit

func A_arbace_c2a_rules_applicable_A_Init() { if !A_arbace_c2a_rules_applicable_A_init.Done() { A_arbace_c2a_rules_applicable_A_init.Run(A_arbace_c2a_rules_applicable_A_clinit) } }

func A_arbace_c2a_rules_applicable_A_clinit() { A_arbace_c2a_rules_applicable_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_applicable_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_applicable_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_applicable_A_class }

func (t *A_arbace_c2a_rules_applicable_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_applicable_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_applicable_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_applicable_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_applicable_A); return ok }

func A_arbace_c2a_rules_applicable_A_Cast(x any) *A_arbace_c2a_rules_applicable_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_applicable_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_applicable_A_class)) }; return v }



type A_arbace_c2a_rules_applicable_fn__1094000103_A struct{ jrt.Object; F_ctx, F_skip any }

func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_applicable_fn__1094000103_A_fn_class *jrt.Class

var A_arbace_c2a_rules_applicable_fn__1094000103_A_init jrt.ClassInit

func A_arbace_c2a_rules_applicable_fn__1094000103_A_Init() { if !A_arbace_c2a_rules_applicable_fn__1094000103_A_init.Done() { A_arbace_c2a_rules_applicable_fn__1094000103_A_init.Run(A_arbace_c2a_rules_applicable_fn__1094000103_A_clinit) } }

func A_arbace_c2a_rules_applicable_fn__1094000103_A_clinit() { A_arbace_c2a_rules_applicable_fn__1094000103_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_applicable_fn__1094000103_A_class }

func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_applicable_fn__1094000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_applicable_fn__1094000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_applicable_fn__1094000103_A); return ok }

func A_arbace_c2a_rules_applicable_fn__1094000103_A_Cast(x any) *A_arbace_c2a_rules_applicable_fn__1094000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_applicable_fn__1094000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_applicable_fn__1094000103_A_class)) }; return v }



type A_arbace_c2a_rules_arbace_core_names_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_arbace_core_names_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rules_arbace_core_names_A_fn_class *jrt.Class

var A_arbace_c2a_rules_arbace_core_names_A_init jrt.ClassInit

func A_arbace_c2a_rules_arbace_core_names_A_Init() { if !A_arbace_c2a_rules_arbace_core_names_A_init.Done() { A_arbace_c2a_rules_arbace_core_names_A_init.Run(A_arbace_c2a_rules_arbace_core_names_A_clinit) } }

func A_arbace_c2a_rules_arbace_core_names_A_clinit() { A_arbace_c2a_rules_arbace_core_names_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_arbace_core_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_arbace_core_names_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_arbace_core_names_A_class }

func (t *A_arbace_c2a_rules_arbace_core_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_arbace_core_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_arbace_core_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_arbace_core_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_arbace_core_names_A); return ok }

func A_arbace_c2a_rules_arbace_core_names_A_Cast(x any) *A_arbace_c2a_rules_arbace_core_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_arbace_core_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_arbace_core_names_A_class)) }; return v }



type A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_fn_class *jrt.Class

var A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_init jrt.ClassInit

func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_Init() { if !A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_init.Done() { A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_init.Run(A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_clinit) } }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_clinit() { A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_class }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A); return ok }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_Cast(x any) *A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_arbace_core_names_fn__1094000056_A_class)) }; return v }



type A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_fn_class *jrt.Class

var A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_init jrt.ClassInit

func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_Init() { if !A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_init.Done() { A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_init.Run(A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_clinit) } }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_clinit() { A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_class }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A); return ok }

func A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_Cast(x any) *A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_arbace_core_names_fn__1094000058_A_class)) }; return v }



type A_arbace_c2a_rules_clojure_source_QMARK__A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_clojure_source_QMARK__A_fn_class *jrt.Class

var A_arbace_c2a_rules_clojure_source_QMARK__A_init jrt.ClassInit

func A_arbace_c2a_rules_clojure_source_QMARK__A_Init() { if !A_arbace_c2a_rules_clojure_source_QMARK__A_init.Done() { A_arbace_c2a_rules_clojure_source_QMARK__A_init.Run(A_arbace_c2a_rules_clojure_source_QMARK__A_clinit) } }

func A_arbace_c2a_rules_clojure_source_QMARK__A_clinit() { A_arbace_c2a_rules_clojure_source_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_clojure_source_QMARK__A_class }

func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_clojure_source_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_clojure_source_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_clojure_source_QMARK__A); return ok }

func A_arbace_c2a_rules_clojure_source_QMARK__A_Cast(x any) *A_arbace_c2a_rules_clojure_source_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_clojure_source_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_clojure_source_QMARK__A_class)) }; return v }



type A_arbace_c2a_rules_core_names_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_core_names_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_core_names_A_fn_class *jrt.Class

var A_arbace_c2a_rules_core_names_A_init jrt.ClassInit

func A_arbace_c2a_rules_core_names_A_Init() { if !A_arbace_c2a_rules_core_names_A_init.Done() { A_arbace_c2a_rules_core_names_A_init.Run(A_arbace_c2a_rules_core_names_A_clinit) } }

func A_arbace_c2a_rules_core_names_A_clinit() { A_arbace_c2a_rules_core_names_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_core_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_core_names_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_core_names_A_class }

func (t *A_arbace_c2a_rules_core_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_core_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_core_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_core_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_core_names_A); return ok }

func A_arbace_c2a_rules_core_names_A_Cast(x any) *A_arbace_c2a_rules_core_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_core_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_core_names_A_class)) }; return v }



type A_arbace_c2a_rules_defined_names_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_defined_names_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_defined_names_A_fn_class *jrt.Class

var A_arbace_c2a_rules_defined_names_A_init jrt.ClassInit

func A_arbace_c2a_rules_defined_names_A_Init() { if !A_arbace_c2a_rules_defined_names_A_init.Done() { A_arbace_c2a_rules_defined_names_A_init.Run(A_arbace_c2a_rules_defined_names_A_clinit) } }

func A_arbace_c2a_rules_defined_names_A_clinit() { A_arbace_c2a_rules_defined_names_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_defined_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_defined_names_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_defined_names_A_class }

func (t *A_arbace_c2a_rules_defined_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_defined_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_defined_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_defined_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_defined_names_A); return ok }

func A_arbace_c2a_rules_defined_names_A_Cast(x any) *A_arbace_c2a_rules_defined_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_defined_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_defined_names_A_class)) }; return v }



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A struct{ jrt.Object; F_s any }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_fn_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_init jrt.ClassInit

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_Init() { if !A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_init.Done() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_init.Run(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_clinit) } }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_clinit() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A); return ok }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_Cast(x any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_A_class)) }; return v }



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A struct{ jrt.Object; F_s__1094000062, F_iter__1094000061, F_s any }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_fn_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_init jrt.ClassInit

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_Init() { if !A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_init.Done() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_init.Run(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_clinit) } }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_clinit() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A); return ok }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_Cast(x any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_A_class)) }; return v }



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A struct{ jrt.Object; F_s, F_b__1094000064 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_fn_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_init jrt.ClassInit

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_Init() { if !A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_init.Done() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_init.Run(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_clinit) } }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_clinit() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_99, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A); return ok }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_Cast(x any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_A_class)) }; return v }



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A struct{ jrt.Object; F_h, F_s any }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_fn_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_init jrt.ClassInit

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_Init() { if !A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_init.Done() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_init.Run(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_clinit) } }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_clinit() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_100, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_class }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A); return ok }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_Cast(x any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000067_fn__1094000071_A_class)) }; return v }



type A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A struct{ jrt.Object; F_h, F_s any }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_fn_class *jrt.Class

var A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_init jrt.ClassInit

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_Init() { if !A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_init.Done() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_init.Run(A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_clinit) } }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_clinit() { A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_class }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A); return ok }

func A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_Cast(x any) *A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_defined_names_iter__1094000061__1094000065_fn__1094000066_fn__1094000077_A_class)) }; return v }



type A_arbace_c2a_rules_eval1094000004_A struct{ jrt.Object }

func A_arbace_c2a_rules_eval1094000004_A_New() *A_arbace_c2a_rules_eval1094000004_A { t := &A_arbace_c2a_rules_eval1094000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rules_eval1094000004_A) Ctor() {}

func (t *A_arbace_c2a_rules_eval1094000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_eval1094000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_eval1094000004_A_class }

func (t *A_arbace_c2a_rules_eval1094000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_eval1094000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_eval1094000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_eval1094000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_eval1094000004_A); return ok }

func A_arbace_c2a_rules_eval1094000004_A_Cast(x any) *A_arbace_c2a_rules_eval1094000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_eval1094000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_eval1094000004_A_class)) }; return v }



type A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_fn_class *jrt.Class

var A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_init jrt.ClassInit

func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_Init() { if !A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_init.Done() { A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_init.Run(A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_clinit) } }

func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_clinit() { A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_class }

func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A); return ok }

func A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_Cast(x any) *A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_eval1094000004_loading__1927001464__auto____1094000005_A_class)) }; return v }



type A_arbace_c2a_rules_eval1094000008_A struct{ jrt.Object }

func A_arbace_c2a_rules_eval1094000008_A_New() *A_arbace_c2a_rules_eval1094000008_A { t := &A_arbace_c2a_rules_eval1094000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_rules_eval1094000008_A) Ctor() {}

func (t *A_arbace_c2a_rules_eval1094000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_eval1094000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_eval1094000008_A_class }

func (t *A_arbace_c2a_rules_eval1094000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_eval1094000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_eval1094000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_eval1094000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_eval1094000008_A); return ok }

func A_arbace_c2a_rules_eval1094000008_A_Cast(x any) *A_arbace_c2a_rules_eval1094000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_eval1094000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_eval1094000008_A_class)) }; return v }



type A_arbace_c2a_rules_eval1094000008_fn__1094000009_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_fn_class *jrt.Class

var A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_init jrt.ClassInit

func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_Init() { if !A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_init.Done() { A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_init.Run(A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_clinit) } }

func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_clinit() { A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_class }

func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_eval1094000008_fn__1094000009_A); return ok }

func A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_Cast(x any) *A_arbace_c2a_rules_eval1094000008_fn__1094000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_eval1094000008_fn__1094000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_eval1094000008_fn__1094000009_A_class)) }; return v }



type A_arbace_c2a_rules_fn__1094000090_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_fn__1094000090_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_fn__1094000090_A_fn_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000090_A_init jrt.ClassInit

func A_arbace_c2a_rules_fn__1094000090_A_Init() { if !A_arbace_c2a_rules_fn__1094000090_A_init.Done() { A_arbace_c2a_rules_fn__1094000090_A_init.Run(A_arbace_c2a_rules_fn__1094000090_A_clinit) } }

func A_arbace_c2a_rules_fn__1094000090_A_clinit() { A_arbace_c2a_rules_fn__1094000090_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_fn__1094000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_fn__1094000090_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_fn__1094000090_A_class }

func (t *A_arbace_c2a_rules_fn__1094000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_fn__1094000090_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_fn__1094000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_fn__1094000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_fn__1094000090_A); return ok }

func A_arbace_c2a_rules_fn__1094000090_A_Cast(x any) *A_arbace_c2a_rules_fn__1094000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_fn__1094000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_fn__1094000090_A_class)) }; return v }



type A_arbace_c2a_rules_fn__1094000092_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_fn__1094000092_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_fn__1094000092_A_fn_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000092_A_init jrt.ClassInit

func A_arbace_c2a_rules_fn__1094000092_A_Init() { if !A_arbace_c2a_rules_fn__1094000092_A_init.Done() { A_arbace_c2a_rules_fn__1094000092_A_init.Run(A_arbace_c2a_rules_fn__1094000092_A_clinit) } }

func A_arbace_c2a_rules_fn__1094000092_A_clinit() { A_arbace_c2a_rules_fn__1094000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_fn__1094000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_fn__1094000092_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_fn__1094000092_A_class }

func (t *A_arbace_c2a_rules_fn__1094000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_fn__1094000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_fn__1094000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_fn__1094000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_fn__1094000092_A); return ok }

func A_arbace_c2a_rules_fn__1094000092_A_Cast(x any) *A_arbace_c2a_rules_fn__1094000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_fn__1094000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_fn__1094000092_A_class)) }; return v }



type A_arbace_c2a_rules_fn__1094000094_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_fn__1094000094_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_fn__1094000094_A_fn_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000094_A_init jrt.ClassInit

func A_arbace_c2a_rules_fn__1094000094_A_Init() { if !A_arbace_c2a_rules_fn__1094000094_A_init.Done() { A_arbace_c2a_rules_fn__1094000094_A_init.Run(A_arbace_c2a_rules_fn__1094000094_A_clinit) } }

func A_arbace_c2a_rules_fn__1094000094_A_clinit() { A_arbace_c2a_rules_fn__1094000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_fn__1094000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_fn__1094000094_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_fn__1094000094_A_class }

func (t *A_arbace_c2a_rules_fn__1094000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_fn__1094000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_fn__1094000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_fn__1094000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_fn__1094000094_A); return ok }

func A_arbace_c2a_rules_fn__1094000094_A_Cast(x any) *A_arbace_c2a_rules_fn__1094000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_fn__1094000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_fn__1094000094_A_class)) }; return v }



type A_arbace_c2a_rules_fn__1094000096_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_fn__1094000096_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_fn__1094000096_A_fn_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000096_A_init jrt.ClassInit

func A_arbace_c2a_rules_fn__1094000096_A_Init() { if !A_arbace_c2a_rules_fn__1094000096_A_init.Done() { A_arbace_c2a_rules_fn__1094000096_A_init.Run(A_arbace_c2a_rules_fn__1094000096_A_clinit) } }

func A_arbace_c2a_rules_fn__1094000096_A_clinit() { A_arbace_c2a_rules_fn__1094000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_fn__1094000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_fn__1094000096_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_fn__1094000096_A_class }

func (t *A_arbace_c2a_rules_fn__1094000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_fn__1094000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_fn__1094000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_fn__1094000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_fn__1094000096_A); return ok }

func A_arbace_c2a_rules_fn__1094000096_A_Cast(x any) *A_arbace_c2a_rules_fn__1094000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_fn__1094000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_fn__1094000096_A_class)) }; return v }



type A_arbace_c2a_rules_fn__1094000098_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_fn__1094000098_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_fn__1094000098_A_fn_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000098_A_init jrt.ClassInit

func A_arbace_c2a_rules_fn__1094000098_A_Init() { if !A_arbace_c2a_rules_fn__1094000098_A_init.Done() { A_arbace_c2a_rules_fn__1094000098_A_init.Run(A_arbace_c2a_rules_fn__1094000098_A_clinit) } }

func A_arbace_c2a_rules_fn__1094000098_A_clinit() { A_arbace_c2a_rules_fn__1094000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_fn__1094000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_fn__1094000098_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_fn__1094000098_A_class }

func (t *A_arbace_c2a_rules_fn__1094000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_fn__1094000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_fn__1094000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_fn__1094000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_fn__1094000098_A); return ok }

func A_arbace_c2a_rules_fn__1094000098_A_Cast(x any) *A_arbace_c2a_rules_fn__1094000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_fn__1094000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_fn__1094000098_A_class)) }; return v }



type A_arbace_c2a_rules_fn__1094000100_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_fn__1094000100_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_fn__1094000100_A_fn_class *jrt.Class

var A_arbace_c2a_rules_fn__1094000100_A_init jrt.ClassInit

func A_arbace_c2a_rules_fn__1094000100_A_Init() { if !A_arbace_c2a_rules_fn__1094000100_A_init.Done() { A_arbace_c2a_rules_fn__1094000100_A_init.Run(A_arbace_c2a_rules_fn__1094000100_A_clinit) } }

func A_arbace_c2a_rules_fn__1094000100_A_clinit() { A_arbace_c2a_rules_fn__1094000100_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_fn__1094000100_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_fn__1094000100_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_fn__1094000100_A_class }

func (t *A_arbace_c2a_rules_fn__1094000100_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_fn__1094000100_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_fn__1094000100_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_fn__1094000100_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_fn__1094000100_A); return ok }

func A_arbace_c2a_rules_fn__1094000100_A_Cast(x any) *A_arbace_c2a_rules_fn__1094000100_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_fn__1094000100_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_fn__1094000100_A_class)) }; return v }



type A_arbace_c2a_rules_imports_QMARK__A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_imports_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_imports_QMARK__A_fn_class *jrt.Class

var A_arbace_c2a_rules_imports_QMARK__A_init jrt.ClassInit

func A_arbace_c2a_rules_imports_QMARK__A_Init() { if !A_arbace_c2a_rules_imports_QMARK__A_init.Done() { A_arbace_c2a_rules_imports_QMARK__A_init.Run(A_arbace_c2a_rules_imports_QMARK__A_clinit) } }

func A_arbace_c2a_rules_imports_QMARK__A_clinit() { A_arbace_c2a_rules_imports_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_imports_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_imports_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_imports_QMARK__A_class }

func (t *A_arbace_c2a_rules_imports_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_imports_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_imports_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_imports_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_imports_QMARK__A); return ok }

func A_arbace_c2a_rules_imports_QMARK__A_Cast(x any) *A_arbace_c2a_rules_imports_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_imports_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_imports_QMARK__A_class)) }; return v }



type A_arbace_c2a_rules_insert_at_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_insert_at_A) Is_Compiler_AOTF3() {}

var A_arbace_c2a_rules_insert_at_A_fn_class *jrt.Class

var A_arbace_c2a_rules_insert_at_A_init jrt.ClassInit

func A_arbace_c2a_rules_insert_at_A_Init() { if !A_arbace_c2a_rules_insert_at_A_init.Done() { A_arbace_c2a_rules_insert_at_A_init.Run(A_arbace_c2a_rules_insert_at_A_clinit) } }

func A_arbace_c2a_rules_insert_at_A_clinit() { A_arbace_c2a_rules_insert_at_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_insert_at_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_insert_at_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_insert_at_A_class }

func (t *A_arbace_c2a_rules_insert_at_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_insert_at_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_insert_at_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_insert_at_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_insert_at_A); return ok }

func A_arbace_c2a_rules_insert_at_A_Cast(x any) *A_arbace_c2a_rules_insert_at_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_insert_at_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_insert_at_A_class)) }; return v }



type A_arbace_c2a_rules_proxy_methods_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_proxy_methods_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_proxy_methods_A_fn_class *jrt.Class

var A_arbace_c2a_rules_proxy_methods_A_init jrt.ClassInit

func A_arbace_c2a_rules_proxy_methods_A_Init() { if !A_arbace_c2a_rules_proxy_methods_A_init.Done() { A_arbace_c2a_rules_proxy_methods_A_init.Run(A_arbace_c2a_rules_proxy_methods_A_clinit) } }

func A_arbace_c2a_rules_proxy_methods_A_clinit() { A_arbace_c2a_rules_proxy_methods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_proxy_methods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_proxy_methods_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_proxy_methods_A_class }

func (t *A_arbace_c2a_rules_proxy_methods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_proxy_methods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_proxy_methods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_proxy_methods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_proxy_methods_A); return ok }

func A_arbace_c2a_rules_proxy_methods_A_Cast(x any) *A_arbace_c2a_rules_proxy_methods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_proxy_methods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_proxy_methods_A_class)) }; return v }



type A_arbace_c2a_rules_proxy_methods_fn__1094000014_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_fn_class *jrt.Class

var A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_init jrt.ClassInit

func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_Init() { if !A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_init.Done() { A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_init.Run(A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_clinit) } }

func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_clinit() { A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_class }

func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_proxy_methods_fn__1094000014_A); return ok }

func A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_Cast(x any) *A_arbace_c2a_rules_proxy_methods_fn__1094000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_proxy_methods_fn__1094000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_proxy_methods_fn__1094000014_A_class)) }; return v }



type A_arbace_c2a_rules_security_manager_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_security_manager_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_security_manager_A_fn_class *jrt.Class

var A_arbace_c2a_rules_security_manager_A_init jrt.ClassInit

func A_arbace_c2a_rules_security_manager_A_Init() { if !A_arbace_c2a_rules_security_manager_A_init.Done() { A_arbace_c2a_rules_security_manager_A_init.Run(A_arbace_c2a_rules_security_manager_A_clinit) } }

func A_arbace_c2a_rules_security_manager_A_clinit() { A_arbace_c2a_rules_security_manager_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_security_manager_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_security_manager_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_security_manager_A_class }

func (t *A_arbace_c2a_rules_security_manager_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_security_manager_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_security_manager_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_security_manager_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_security_manager_A); return ok }

func A_arbace_c2a_rules_security_manager_A_Cast(x any) *A_arbace_c2a_rules_security_manager_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_security_manager_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_security_manager_A_class)) }; return v }



type A_arbace_c2a_rules_security_manager_fn__1094000030_A struct{ jrt.Object; F_s any }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_security_manager_fn__1094000030_A_fn_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000030_A_init jrt.ClassInit

func A_arbace_c2a_rules_security_manager_fn__1094000030_A_Init() { if !A_arbace_c2a_rules_security_manager_fn__1094000030_A_init.Done() { A_arbace_c2a_rules_security_manager_fn__1094000030_A_init.Run(A_arbace_c2a_rules_security_manager_fn__1094000030_A_clinit) } }

func A_arbace_c2a_rules_security_manager_fn__1094000030_A_clinit() { A_arbace_c2a_rules_security_manager_fn__1094000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_security_manager_fn__1094000030_A_class }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_security_manager_fn__1094000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000030_A); return ok }

func A_arbace_c2a_rules_security_manager_fn__1094000030_A_Cast(x any) *A_arbace_c2a_rules_security_manager_fn__1094000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_security_manager_fn__1094000030_A_class)) }; return v }



type A_arbace_c2a_rules_security_manager_fn__1094000036_A struct{ jrt.Object; F_s, F_in_import_QMARK_ any }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_security_manager_fn__1094000036_A_fn_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000036_A_init jrt.ClassInit

func A_arbace_c2a_rules_security_manager_fn__1094000036_A_Init() { if !A_arbace_c2a_rules_security_manager_fn__1094000036_A_init.Done() { A_arbace_c2a_rules_security_manager_fn__1094000036_A_init.Run(A_arbace_c2a_rules_security_manager_fn__1094000036_A_clinit) } }

func A_arbace_c2a_rules_security_manager_fn__1094000036_A_clinit() { A_arbace_c2a_rules_security_manager_fn__1094000036_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_security_manager_fn__1094000036_A_class }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_security_manager_fn__1094000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000036_A); return ok }

func A_arbace_c2a_rules_security_manager_fn__1094000036_A_Cast(x any) *A_arbace_c2a_rules_security_manager_fn__1094000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_security_manager_fn__1094000036_A_class)) }; return v }



type A_arbace_c2a_rules_security_manager_fn__1094000042_A struct{ jrt.Object; F_s, F_in_import_QMARK_ any }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_security_manager_fn__1094000042_A_fn_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000042_A_init jrt.ClassInit

func A_arbace_c2a_rules_security_manager_fn__1094000042_A_Init() { if !A_arbace_c2a_rules_security_manager_fn__1094000042_A_init.Done() { A_arbace_c2a_rules_security_manager_fn__1094000042_A_init.Run(A_arbace_c2a_rules_security_manager_fn__1094000042_A_clinit) } }

func A_arbace_c2a_rules_security_manager_fn__1094000042_A_clinit() { A_arbace_c2a_rules_security_manager_fn__1094000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_security_manager_fn__1094000042_A_class }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_security_manager_fn__1094000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000042_A); return ok }

func A_arbace_c2a_rules_security_manager_fn__1094000042_A_Cast(x any) *A_arbace_c2a_rules_security_manager_fn__1094000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_security_manager_fn__1094000042_A_class)) }; return v }



type A_arbace_c2a_rules_security_manager_fn__1094000048_A struct{ jrt.Object; F_sb, F_s any }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_security_manager_fn__1094000048_A_fn_class *jrt.Class

var A_arbace_c2a_rules_security_manager_fn__1094000048_A_init jrt.ClassInit

func A_arbace_c2a_rules_security_manager_fn__1094000048_A_Init() { if !A_arbace_c2a_rules_security_manager_fn__1094000048_A_init.Done() { A_arbace_c2a_rules_security_manager_fn__1094000048_A_init.Run(A_arbace_c2a_rules_security_manager_fn__1094000048_A_clinit) } }

func A_arbace_c2a_rules_security_manager_fn__1094000048_A_clinit() { A_arbace_c2a_rules_security_manager_fn__1094000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_security_manager_fn__1094000048_A_class }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_security_manager_fn__1094000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_security_manager_fn__1094000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000048_A); return ok }

func A_arbace_c2a_rules_security_manager_fn__1094000048_A_Cast(x any) *A_arbace_c2a_rules_security_manager_fn__1094000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_security_manager_fn__1094000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_security_manager_fn__1094000048_A_class)) }; return v }



type A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A struct{ jrt.Object; F_import_spans any }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_fn_class *jrt.Class

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_init jrt.ClassInit

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_Init() { if !A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_init.Done() { A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_init.Run(A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_clinit) } }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_clinit() { A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A); return ok }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_Cast(x any) *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_A_class)) }; return v }



type A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A struct{ jrt.Object; F_i any }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_fn_class *jrt.Class

var A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_init jrt.ClassInit

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_Init() { if !A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_init.Done() { A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_init.Run(A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_clinit) } }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_clinit() { A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_class }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A); return ok }

func A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_Cast(x any) *A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_security_manager_in_import_QMARK___1094000021_fn__1094000023_A_class)) }; return v }



type A_arbace_c2a_rules_translate_A struct{ jrt.Object }

func (t *A_arbace_c2a_rules_translate_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_c2a_rules_translate_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_translate_A_fn_class *jrt.Class

var A_arbace_c2a_rules_translate_A_init jrt.ClassInit

func A_arbace_c2a_rules_translate_A_Init() { if !A_arbace_c2a_rules_translate_A_init.Done() { A_arbace_c2a_rules_translate_A_init.Run(A_arbace_c2a_rules_translate_A_clinit) } }

func A_arbace_c2a_rules_translate_A_clinit() { A_arbace_c2a_rules_translate_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_translate_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_translate_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_translate_A_class }

func (t *A_arbace_c2a_rules_translate_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_translate_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_translate_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_translate_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_translate_A); return ok }

func A_arbace_c2a_rules_translate_A_Cast(x any) *A_arbace_c2a_rules_translate_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_translate_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_translate_A_class)) }; return v }



type A_arbace_c2a_rules_translate_fn__1094000106_A struct{ jrt.Object; F_ctx any }

func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_rules_translate_fn__1094000106_A_fn_class *jrt.Class

var A_arbace_c2a_rules_translate_fn__1094000106_A_init jrt.ClassInit

func A_arbace_c2a_rules_translate_fn__1094000106_A_Init() { if !A_arbace_c2a_rules_translate_fn__1094000106_A_init.Done() { A_arbace_c2a_rules_translate_fn__1094000106_A_init.Run(A_arbace_c2a_rules_translate_fn__1094000106_A_clinit) } }

func A_arbace_c2a_rules_translate_fn__1094000106_A_clinit() { A_arbace_c2a_rules_translate_fn__1094000106_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_rules_translate_fn__1094000106_A_class }

func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_rules_translate_fn__1094000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_rules_translate_fn__1094000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_rules_translate_fn__1094000106_A); return ok }

func A_arbace_c2a_rules_translate_fn__1094000106_A_Cast(x any) *A_arbace_c2a_rules_translate_fn__1094000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_rules_translate_fn__1094000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_rules_translate_fn__1094000106_A_class)) }; return v }
