//line j2g_strings.ae:1
package aot_arbace_go_escape

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn19,arbace.go.check.envyn1,eyn21,arbace.go.check.typesyn1,tyn11,arbace.corekn3,dockn4,filekn4,namekn4,elseks3,goi11,unsupportedkn7,invalidkn9,interfacekn4,chankn7,pointerkn5,arraykn3,mapkn5,slicekn6,stringkn11,untyped-nilkn14,unsafe-pointerkn6,structkn4,typekn4,funckn5,tupleks2,go2,opkn6,spreadkn4,argskn15,untyped-complexkn12,untyped-boolkn13,untyped-floatkn5,targskn3,pkgkn9,local-pkgkn4,sendkn4,recvkn11,untyped-intkn14,untyped-stringkn12,untyped-runekn8,embeddedkn3,tagkn5,attrskn5,edgeskn6,derefskn7,walkgenkn10,queued-onekn9,param-esckn7,specialkn8,all-locskn8,closureskn4,heapkn7,mutatorkn6,calleekn5,blankkn1,bkn5,curfnkn10,loop-depthkn6,labelskn4,linekn3,dstkn9,addrtakenkn4,whatkn1,nkn4,exprkn12,result-indexkn12,dst-edge-idxkn10,queued-allkn8,capturedkn10,reassignedkn5,paramkn9,esc-classkn9,param-outkn6,resultkn6,loc-ofkn9,fn-of-objkn4,kindkn10,fn-of-nodekn6,parentkn7,startedkn7,plannedkn3,esckn5,constkn3,nilkn8,constantkn4,modekn2,opkn3,selkn5,derefkn1,xkn10,field-namekn8,variablekn4,pathkn6,methodkn8,ptr-recvkn11,recv-adjustkn4,addrkn8,implicitkn5,valuekn6,binarykn3,litkn4,formkn3,valkn4,runekn10,complex128kn7,float64kn3,intkn4,boolkn7,builtinkn13,convert-ifacekn6,assertyn3,anykn2,tokn11,place-indexkn5,indexkn11,place-fieldkn9,map-indexkn3,keykn9,place-mapkn5,elemskn6,fieldskn7,entrieskn5,fieldkn4,callkn3,objkn11,method-exprkn9,recv-typekn4,convyn4,convkn6,globalkn7,inl-pkgkn6,addstrkn4,listkn11,place-localkn12,place-globalkn5,unarykn1,ykn12,iface-methodkn7,indexeskn2,fnkn5,localkn5,ifacekn4,bytekn5,uint8kn9,bytes2strkn5,int32kn9,runes2strkn7,runestrkn9,str2byteskn9,str2runeskn9,slice2arrkn12,slice2arrptrkn7,uintptrkn19,unsafe-from-uintptrkn3,nopkn8,closure?kn12,closure-varskn7,inlcallkn2,okkn11,smallframeskn5,tempskn7,retvarskn3,varkn6,paramskn4,tagskn11,param-typeskn10,single-defks16,arbace.go.escape4,nonekn12,func-assignskn15,uintptr-pragmasks2,go3,endkn4,bodykn6,statickn7,closurekn3,sigkn8,compiledkn7,resultskn6,appendkn5,deferks16,arbace.go.escape4,recvkn4,autoks16,arbace.go.escape9,recv-nodekn4,nodeks16,arbace.go.escape7,wrapperkn7,wrapperkn5,ownerkn6,local?kn8,wrapkindkn2,gokn5,blockkn5,stmtskn4,declkn5,shortkn4,objskn4,initkn7,novaluekn11,place-derefkn8,comma-okkn9,zero-declkn4,defnkn5,rangekn6,returnkn2,ifkn4,condkn4,thenkn4,gotokn5,labelkn3,forkn6,placeskn4,overkn4,postkn7,clauseskn3,lhskn3,rhskn6,valueskn6,incdeckn5,placekn10,local-typekn2,chkn8,var-declkn6,assignkn3,letkn5,declskn6,switchkn9,directivekn9,op-assignkn11,type-switchkn11,fallthroughkn6,selectkn8,continuekn4,commkn5,breakkn4,stmtkn7,loopingkn10,nonloopingkn3,dclkn12,results-lostkn20,escapemutationscallskn6,externkn8,noescapekn14,uintptrescapeskn6,taggedkn8,zerocopyks16,arbace.go.escape4,typekn6,param?kn7,result?kn10,addressed?kn6,devirtkn8,indirectkn3,viaks16,arbace.go.escape3,maxkn7,foreignkn12,foreign-bodykn8,pkg-pathkn10,local-namekn20,inlfuncswithclosureskn12,implicit-ptrkn4,costkn3,inckn9,inl-statekn4,donekn3,inlkn8,visitingkn8,noinlinekn6,noracekn4,racekn10,inl-reasonkn8,lit-nameks16,arbace.go.escape4,copyks16,arbace.go.escape9,orig-linekn7,unknownkn10,inl-returnkn7,godeferkn12,inlined-bodyks16,arbace.go.escape5,triedkn9,kept-litskn10,inl-paramskn11,callee-namekn10,inl-statickn13,callee-is-litkn6,packedkn4,casekn4,refskn4,kidskn4,basekn7,defaultkn5,scopeys15,arbace.go.check7,sessionys15,arbace.go.check14,ensure-packageys20,arbace.go.check.load14,package-sourceys14,arbace.go.repl6,configys14,arbace.go.repl7,listed?ys14,arbace.go.repl14,digest-sessionkn3,dirkn8,delegatekn10,keep-treeskn6,errorskn3,msgkn7,nparamskn7,pragmaskn5,costskn4,optskn7,importskn5,fileskn10,decl-infoskn4,treekn7,genericks2,go8,noescapeks2,go8,noinlineks2,go6,noraceks2,go14,uintptrescapeskn7,escapesks2,go16,uintptrkeepalivekn9,keepalivekn9,extra-fnskn8,var-initkn5,partskn4,specv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,v11,arbace.core5,referR7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.go.escapem2,R8,s1940,gc's escape analysis over goi's checked trees (doc/go/GOI-SPEC.md, \"Since v1: gc's escape\n  analysis\"): a port, rule for rule, of Go 1.27.1's cmd/compile/internal/escape (escape.go,\n  graph.go, solve.go, expr.go, stmt.go, assign.go, call.go, utils.go, leaks.go; TamaGo's go1.27.1,\n  src/cmd/compile/internal/escape, its forms in tamago/cmd/go/cmd/compile/internal/escape), with\n  the parts of gc's front end it sees the tree through: ir.VisitFuncsBottomUp (ir/scc.go), the\n  ReassignOracle's StaticValue (ir/reassignment.go), loopvar.ForCapture's per-iteration loop\n  variables (loopvar/loopvar.go), typecheck's normalizeGoDeferCall (go/defer wrappers),\n  rewriteMultiValueCall and FixVariadicCall, and ir's expression format (ir/fmt.go) and types'\n  (types/fmt.go) for the messages.\n\n  It reports what gc's -m reports of it: \"moved to heap: x\", \"E escapes to heap\", \"E does not\n  escape\", \"leaking param: p\", \"leaking param content: p\", \"leaking param: p to result r\n  level=n\", \"p does not escape\", the self-assignments ignored; as lines FILE:LINE: MESSAGE, at\n  the forms' lines (the forms keep no columns). The checked tree stands for gc's IR after\n  typecheck: its implicit conversions are its OCONVIFACE nodes, its places and selections gc's\n  ODOT/ODOTPTR/OINDEX, a call's kind gc's OCALLFUNC/OCALLINTER (a method call as gc's fixed\n  OCALLFUNC of the method expression, the receiver its first argument).\n\n  Calls of functions of other packages use their parameter tags as gc does; goi has no export\n  data, so a package's functions are analyzed from their forms when the package's forms are at\n  hand (arbace.go.escape/*import-tags*), else such a call's arguments leak to the heap (gc's\n  unknown callee).\n\n  Without -l gc's inliner runs first (inline/inl.go's CanInline and hairyVisitor, the interleaved\n  inliner, devirtualize.StaticCall interleaved): can inline f, inlining call to f; the analysis then\n  sees the inlined bodies.v16,arbace.go.escape6,*msgs*v16,arbace.go.escape7,*wfile*l0,R9,v11,arbace.core7,string?v11,arbace.core4,map?R10,R11,v11,arbace.core7,ex-infoR12,v21,arbace.go.check.types5,underv16,arbace.go.escape5,underv11,arbace.core8,keyword?v11,arbace.core7,vector?R13,R14,v16,arbace.go.escape4,kindR15,R16,R17,R18,R19,S3,R20,R21,R22,R23,v11,arbace.core4,somev16,arbace.go.escape13,has-pointers?R24,R25,R26,v11,arbace.core4,restR22,v16,arbace.go.escape13,direct-iface?v11,arbace.core5,firstv21,arbace.go.check.types6,sizeofv21,arbace.go.check.types7,alignofv21,arbace.go.check.types8,untyped?v11,arbace.core3,strR27,v16,arbace.go.escape6,go-opsR28,v11,arbace.core4,peekv11,arbace.core3,vecR29,v13,arbace.string4,joinv11,arbace.core11,map-indexedv16,arbace.go.escape8,type-strv16,arbace.go.escape4,elemR21,R30,R31,R32,v11,arbace.core4,namev21,arbace.go.check.types6,named?v21,arbace.go.check.types4,infov11,arbace.core3,seqR33,v11,arbace.core3,mapR34,R35,v16,arbace.go.escape5,*ctx*v11,arbace.core4,lastv13,arbace.string5,splitp1,/R36,R37,v11,arbace.core6,empty?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv16,arbace.go.escape10,params-strv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consR38,R39,R40,R41,R42,v11,arbace.core6,pr-strv11,arbace.core5,assocv11,arbace.core3,notv16,arbace.go.escape4,lgetR43,v16,arbace.go.escape8,leak-getv11,arbace.core6,reducev11,arbace.core5,rangel1,l8,v16,arbace.go.escape8,no-leaksv11,arbace.core9,volatile!R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,v16,arbace.go.escape12,attr-escapesv16,arbace.go.escape13,attr-persistsv16,arbace.go.escape12,attr-mutatesv16,arbace.go.escape10,attr-callsR56,R57,R58,R59,R60,v16,arbace.go.escape6,fn-getR61,R62,v16,arbace.go.escape4,holev16,arbace.go.escape2,ebv16,arbace.go.escape5,shiftl-1,v16,arbace.go.escape6,iface?R63,v19,arbace.go.check.env4,obj?R64,R65,v16,arbace.go.escape5,curfnv16,arbace.go.escape5,depthR66,R67,R68,R69,R70,R71,v19,arbace.go.check.env1,oR72,R73,R74,R75,v16,arbace.go.escape12,unsupported!v16,arbace.go.escape9,has-attr?v11,arbace.core6,updatev11,arbace.core6,bit-orv16,arbace.go.escape5,lset!v16,arbace.go.escape12,discard-holev16,arbace.go.escape7,new-locv16,arbace.go.escape4,flowv11,arbace.core4,nextv16,arbace.go.escape6,k-addrR76,R77,v11,arbace.core4,not=v16,arbace.go.escape10,foreign-fnR78,R79,S2,R80,R81,R82,S2,R83,R84,R85,R86,R87,v21,arbace.go.check.types8,pointer?R88,R89,R90,R91,R92,v16,arbace.go.escape11,field-stepsv16,arbace.go.escape9,node-typeR93,v16,arbace.go.escape11,select-nodev11,arbace.core3,popR94,R95,R96,R97,R98,R99,R100,v16,arbace.go.escape8,bin-precv16,arbace.go.escape3,gopl5,R101,l7,v16,arbace.go.escape4,precR102,R103,R104,v11,arbace.core8,integer?v11,arbace.core2,<=l1114111,v16,arbace.go.escape8,untyped?S5,R105,R106,R107,R20,R108,v16,arbace.go.escape8,fmt-nodeR109,v16,arbace.go.escape8,args-strv16,arbace.go.escape12,spread-call?S3,R97,R89,R110,R110,v16,arbace.go.escape9,node-precv16,arbace.go.escape6,const?R83,R111,v11,arbace.core4,seq?R112,R113,R114,R115,R116,v16,arbace.go.escape12,expand-fieldR117,R118,R84,v16,arbace.go.escape9,const-strR119,R120,R121,R122,R123,R124,v16,arbace.go.escape11,builtin-strv16,arbace.go.escape13,variadic-argsR125,p1,/R126,R127,R128,R129,v11,arbace.core6,secondR112,R130,v13,arbace.string12,starts-with?R131,R132,R133,R134,R135,R136,R137,R138,R139,R140,R141,v16,arbace.go.escape4,exprv16,arbace.go.escape9,heap-holev16,arbace.go.escape12,mutator-holev16,arbace.go.escape7,discardR142,R20,S2,R143,R144,R145,S2,R146,R104,R147,v21,arbace.go.check.types13,integer-type?R148,S2,R143,R144,R149,S2,R146,R104,R150,R151,R152,R153,R154,R155,S2,s11,SliceHeaders12,StringHeaderv16,arbace.go.escape12,unsafe-valuev16,arbace.go.escape20,reflect-header-data?v16,arbace.go.escape7,k-derefv21,arbace.go.check.types15,unsafe-pointer?S3,s1,-s1,^s1,+S9,s1,*s1,%s1,|s1,/s1,-s1,&s2,&^s1,^s1,+S2,s2,>>s2,<<v21,arbace.go.check.types12,string-type?v11,arbace.core6,concatv16,arbace.go.escape15,add-string-listv16,arbace.go.escape10,fn-of-nodev16,arbace.go.escape5,spillR156,v16,arbace.go.escape10,walk-func!R157,v16,arbace.go.escape7,old-locv16,arbace.go.escape9,fn-of-objv11,arbace.core6,repeatv16,arbace.go.escape13,call-tag-holev16,arbace.go.escape8,tee-holev16,arbace.go.escape11,method-recvv16,arbace.go.escape12,method-valuev16,arbace.go.escape10,call-tempsv16,arbace.go.escape11,assign-heapv16,arbace.go.escape9,elt-valueR158,v16,arbace.go.escape4,callv16,arbace.go.escape8,discardsv16,arbace.go.escape12,closure-exprR159,v11,arbace.core6,removev11,arbace.core4,nil?v16,arbace.go.escape8,dot-typev16,arbace.go.escape9,conv-kindv16,arbace.go.escape17,heap-alloc-reasonv11,arbace.core9,contains?v16,arbace.go.escape10,with-line*v16,arbace.go.escape14,expr-skip-initR160,v16,arbace.go.escape7,*debug*v16,arbace.go.escape4,sizev16,arbace.go.escape9,max-stackv16,arbace.go.escape5,alignv16,arbace.go.escape12,max-implicitR161,v11,arbace.core4,mapvR162,v19,arbace.go.check.env3,objR163,v16,arbace.go.escape16,in-mutual-batch?R164,R165,l2,v16,arbace.go.escape11,callee-holev11,arbace.core4,intov16,arbace.go.escape15,num-esc-resultsv16,arbace.go.escape8,tag-holeR166,R167,R168,R169,v16,arbace.go.escape13,static-calleeR170,R171,v11,arbace.core6,subvecv16,arbace.go.escape9,call-linev11,arbace.core6,vectorv16,arbace.go.escape5,stmtsR172,R173,R174,v16,arbace.go.escape12,static-valueR175,R176,v16,arbace.go.escape24,resolve-assigned-calleesv16,arbace.go.escape16,func-assignmentsv11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsv16,arbace.go.escape8,argumentv16,arbace.go.escape15,merged-tag-holev11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*R177,v16,arbace.go.escape12,builtin-callv16,arbace.go.escape8,inl-callR178,S3,R25,R126,R84,v21,arbace.go.check.types8,uintptr?v16,arbace.go.escape13,wrapper-visitS3,R17,R19,R23,v11,arbace.core6,mapcatR179,v16,arbace.go.escape5,laterS3,R176,R173,R174,V2,R54,R180,V2,R54,R37,V1,R54,R181,v16,arbace.go.escape4,dcl!R180,v11,arbace.core8,assoc-inV2,R54,R182,R183,R184,R185,R81,R186,S3,R176,R173,R174,v16,arbace.go.escape16,normal-go-defer?V2,R54,R180,V2,R54,R37,V1,R54,R187,V2,R54,R37,V2,R54,R37,R188,R189,R190,R191,R192,R193,R194,R195,R196,S7,R142,R94,R127,R123,R24,R175,R113,S2,R189,R179,v16,arbace.go.escape13,wrap-go-deferv16,arbace.go.escape7,addr-ofv16,arbace.go.escape6,mutateR197,v16,arbace.go.escape10,outer-namev16,arbace.go.escape10,norm-placev16,arbace.go.escape15,same-safe-expr?S2,s3,lens3,capv16,arbace.go.escape18,may-affect-memory?v16,arbace.go.escape18,slice-self-assign?S1,R123,S2,R128,R110,R198,S2,R128,R110,S2,R128,R110,v16,arbace.go.escape14,comma-ok-tempsv16,arbace.go.escape11,reassigned!S2,R116,R123,v16,arbace.go.escape12,self-assign?v16,arbace.go.escape3,*m*v16,arbace.go.escape5,warn!v16,arbace.go.escape15,fmt-stmt-assignS2,R116,R123,R199,v16,arbace.go.escape9,name-loc?R200,R201,v11,arbace.core11,sequential?v16,arbace.go.escape11,terminates?R202,R203,v16,arbace.go.escape11,static-boolR204,R205,R206,R207,v16,arbace.go.escape4,stmtv16,arbace.go.escape10,live-stmtsv11,arbace.core3,setv16,arbace.go.escape11,assign-listv16,arbace.go.escape8,dcl-obj!S2,R208,R201,v16,arbace.go.escape11,loop-leakedv11,arbace.core3,incR209,v11,arbace.core4,takeV2,R55,R55,v11,arbace.core3,decS2,R107,R25,v16,arbace.go.escape5,blockR210,R211,R212,R213,R214,R215,v16,arbace.go.escape9,decl-stmtv16,arbace.go.escape8,go-deferR216,R217,V1,nv16,arbace.go.escape10,range-stmtR218,R219,R220,R221,v16,arbace.go.escape11,assign-stmtR222,R223,R224,R225,R226,R227,v16,arbace.go.escape16,type-switch-stmtR228,R229,R230,R231,R232,v16,arbace.go.escape11,return-stmtR233,R208,v16,arbace.go.escape8,for-stmtR234,R235,v16,arbace.go.escape7,with-fnv16,arbace.go.escape7,fn-set!R80,v16,arbace.go.escape12,label-statesR236,v16,arbace.go.escape17,contains-closure?R237,v16,arbace.go.escape8,leak-addv16,arbace.go.escape9,outlives?v16,arbace.go.escape8,leak-to!V3,R53,R54,R52,v16,arbace.go.escape9,walk-one!R238,v11,arbace.core7,vreset!R239,R240,R241,v16,arbace.go.escape13,leak-optimizev16,arbace.go.escape11,leak-encodev16,arbace.go.escape13,report-leaks!v16,arbace.go.escape9,param-tagR242,R243,R107,v16,arbace.go.escape10,literal-ofv16,arbace.go.escape9,new-batchv16,arbace.go.escape7,finish!v16,arbace.go.escape9,walk-all!v16,arbace.go.escape10,init-func!v16,arbace.go.escape12,flow-closurev16,arbace.go.escape22,rewrite-with-literals!S2,R71,R74,S2,R71,R74,v21,arbace.go.check.types9,exported?R244,S2,R134,R141,S2,R142,R155,S2,R71,R74,R245,R246,R247,v21,arbace.go.check.types5,same?v16,arbace.go.escape13,concrete-typev21,arbace.go.check.types14,missing-methodv21,arbace.go.check.types6,lookupR248,v21,arbace.go.check.types10,deref-typeR249,R250,v21,arbace.go.check.types12,*method-obj*v16,arbace.go.escape15,method-obj-datav16,arbace.go.escape17,iface-assignmentsS2,R189,R179,v11,arbace.core5,emptyv16,arbace.go.escape11,devirt-callv21,arbace.go.check.types9,unsigned?v16,arbace.go.escape15,small-int-constR251,v11,arbace.core6,every?S2,R115,R114,v16,arbace.go.escape8,bounded?v21,arbace.go.check.types22,identical-ignore-tags?v21,arbace.go.check.types11,float-type?S1,R71,V9,s6,Uint64s6,Uint32s6,Uint16s9,PutUint64s9,PutUint32s9,PutUint16s12,AppendUint64s12,AppendUint32s12,AppendUint16V2,s12,littleEndians9,bigEndianV9,s6,Uint64s6,Uint32s6,Uint16s9,PutUint64s9,PutUint32s9,PutUint16s12,AppendUint64s12,AppendUint32s12,AppendUint16V2,s2,LEs2,BER252,R253,R254,R255,v16,arbace.go.escape11,fn-pkg-namev16,arbace.go.escape11,cheap-callsv16,arbace.go.escape10,intrinsicsl-2,R256,l16,v16,arbace.go.escape9,conv-nop?R257,S2,R116,R123,S3,R134,R130,R141,v16,arbace.go.escape12,field-offsetv16,arbace.go.escape10,inl-calleev16,arbace.go.escape11,can-inline!v16,arbace.go.escape10,intrinsic?v16,arbace.go.escape11,cheap-call?R258,v16,arbace.go.escape8,max-costv16,arbace.go.escape12,param-local?v16,arbace.go.escape22,inline-param-call-costv16,arbace.go.escape22,inline-extra-call-costv11,arbace.core12,keep-indexedv21,arbace.go.check.types9,offsetsofv16,arbace.go.escape12,*big-caller*l20,v16,arbace.go.escape17,inline-max-budgetv16,arbace.go.escape31,inline-closure-called-once-costv13,arbace.string6,blank?v16,arbace.go.escape8,stmt-strv16,arbace.go.escape9,call-str2v16,arbace.go.escape9,stmts-strR259,S8,R142,R94,R127,R123,R24,R175,R102,R113,S8,R142,R94,R127,R123,R24,R175,R102,R113,R260,R261,R262,R263,R264,R265,R266,v16,arbace.go.escape10,hairy-costR267,S7,R142,R94,R127,R123,R24,R175,R113,R268,R269,R270,v11,arbace.core5,doallv11,arbace.core6,dissocR271,v16,arbace.go.escape13,closure-vars!v16,arbace.go.escape8,scan-fn!R272,S2,R29,R54,R273,S2,R29,R54,R274,R275,v16,arbace.go.escape10,try-inlineR276,v16,arbace.go.escape12,foreign-bodyv11,arbace.core4,disjp1,/v19,arbace.go.check.env5,oset!v11,arbace.core4,subsv16,arbace.go.escape7,all-fnsv16,arbace.go.escape9,copy-bodyv16,arbace.go.escape16,returns->assignsv16,arbace.go.escape16,register-copies!R277,v16,arbace.go.escape12,inline-callsR278,R279,v16,arbace.go.escape20,static-inlined-call?R280,v11,arbace.core5,swap!v16,arbace.go.escape10,bloop-tmpsv16,arbace.go.escape10,bloop-namev16,arbace.go.escape16,addressable-nameS2,R197,R89,v16,arbace.go.escape10,bloop-keptv16,arbace.go.escape16,keep-alive-callsv16,arbace.go.escape9,bloop-tmpv16,arbace.go.escape16,keep-alive-nodesR281,v16,arbace.go.escape13,preserve-stmtv16,arbace.go.escape7,b-loop?S8,R142,R94,R127,R123,R24,R175,R102,R113,v16,arbace.go.escape14,preserve-stmtsR282,R283,R284,R285,v11,arbace.core7,symbol?v16,arbace.go.escape12,static-init?S3,R17,R19,R23,v16,arbace.go.escape13,dynamic-partsv11,arbace.core7,number?S7,R142,R94,R127,R123,R24,R175,R113,m8,R87,R83,R103,TR86,R85,R24,R108,v11,arbace.core6,filterv16,arbace.go.escape9,const-eq?R286,v11,arbace.core8,tree-seqv11,arbace.core5,coll?v16,arbace.go.escape11,method-baseR287,v19,arbace.go.check.env9,scope-getv11,arbace.core17,requiring-resolveR288,R289,R290,R291,v11,arbace.core6,delay?v16,arbace.go.escape13,*import-root*R292,v11,arbace.core7,resolveR293,R294,R295,R296,m2,R297,V1,m2,R298,s10,no packageR297,v11,arbace.core10,constantlyv16,arbace.go.escape12,*pkg-bodies*v16,arbace.go.escape10,std-resultv16,arbace.go.escape15,analyze-packagev16,arbace.go.escape9,*phase-a*v11,arbace.core7,sort-byv11,arbace.core5,applyv11,arbace.core6,formatv16,arbace.go.escape11,*tag-cache*v13,arbace.string7,replacev16,arbace.go.escape12,forms-digestv16,arbace.go.escape12,*std-inline*v11,arbace.core11,read-stringv11,arbace.core5,slurpR299,R300,v16,arbace.go.escape8,*inline*v11,arbace.core4,atomR301,v16,arbace.go.escape11,tag-versionv11,arbace.core4,spitR290,R291,v11,arbace.core8,distinctS2,s6,unsafes1,CS2,s6,unsafes1,Cv11,arbace.core6,get-inV2,R302,R303,R304,v16,arbace.go.escape11,std-importsv16,arbace.go.escape17,load-package-tagsv16,arbace.go.escape8,pkg-tagsp1,/v11,arbace.core4,juxtv11,arbace.core11,select-keysV10,R183,R10,R9,R164,R166,R177,R175,R60,R262,R260,V10,R183,R10,R9,R164,R166,R177,R175,R60,R262,R260,v11,arbace.core7,reversev16,arbace.go.escape9,big-func?V3,R186,R167,R169,v16,arbace.go.escape15,static-inlined?R305,R306,v11,arbace.core4,compv16,arbace.go.escape10,bloop-walkv16,arbace.go.escape18,normalize-go-deferv16,arbace.go.escape14,prune-switchesv16,arbace.go.escape7,file-ofv11,arbace.core5,mergeR307,v16,arbace.go.escape7,fn-namev16,arbace.go.escape9,base-typeR308,R309,R310,R311,R312,R313,R314,R315,v16,arbace.go.escape15,inline-package!R316,v11,arbace.core1,=R317,m2,R87,R25,v16,arbace.go.escape12,devirtualizev16,arbace.go.escape9,bottom-upR318,v16,arbace.go.escape6,batch!v16,arbace.go.escape9,bce-walk!")

var Lit_1 *jrt.String = jrt.Intern("+")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.escape$addr_of$fn__1896000651")

var Lit_3 *jrt.String = jrt.Intern("an assignment to ")

var Lit_4 *jrt.String = jrt.Intern("_")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002039")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002041")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002043__1896002047")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002075__1896002079")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091")

var Lit_10 *jrt.String = jrt.Intern("init")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002120")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002122")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002140")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002164")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002192")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002198")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002200")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002140$fn__1896002141")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002140$iter__1896002143__1896002147")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002140$fn__1896002159")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002140$fn__1896002161")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002140$iter__1896002143__1896002147$fn__1896002148")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002140$iter__1896002143__1896002147$fn__1896002148$fn__1896002149")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002164$fn__1896002165")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002164$iter__1896002167__1896002171")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002164$fn__1896002183")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002164$fn__1896002185")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002164$iter__1896002167__1896002171$fn__1896002172")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$fn__1896002164$iter__1896002167__1896002171$fn__1896002172$fn__1896002173")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002043__1896002047$fn__1896002048")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002043__1896002047$fn__1896002048$fn__1896002049")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002043__1896002047$fn__1896002048$fn__1896002062")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002043__1896002047$fn__1896002048$fn__1896002049$fn__1896002050")

var Lit_34 *jrt.String = jrt.Intern("~r")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002075__1896002079$fn__1896002080")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002075__1896002079$fn__1896002080$fn__1896002081")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092$iter__1896002087__1896002096")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092$iter__1896002102__1896002106")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092$fn__1896002112")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092$iter__1896002087__1896002096$fn__1896002097")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092$iter__1896002087__1896002096$fn__1896002097$fn__1896002098")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092$iter__1896002102__1896002106$fn__1896002107")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package$iter__1896002085__1896002091$fn__1896002092$iter__1896002102__1896002106$fn__1896002107$fn__1896002108")

var Lit_45 *jrt.String = jrt.Intern(", ")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.escape$args_str$fn__1896000134")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.escape$assign_list$fn__1896000692")

var Lit_48 *jrt.String = jrt.Intern(" ignoring self-assignment in ")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.escape$assign_stmt$fn__1896000889")

var Lit_50 *jrt.String = jrt.Intern("Loop")

var Lit_51 *jrt.String = jrt.Intern("testing")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.escape$batch_BANG_$fn__1896001067")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.escape$batch_BANG_$fn__1896001069")

var Lit_54 *jrt.String = jrt.Intern(" escapes to heap in ")

var Lit_55 *jrt.String = jrt.Intern(":")

var Lit_56 *jrt.String = jrt.Intern("  flow: {heap} ← &{storage for ")

var Lit_57 *jrt.String = jrt.Intern("}:")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.escape$bce_walk_BANG_$walk__1896001177")

var Lit_59 *jrt.String = jrt.Intern("index bounds check elided")

var Lit_60 *jrt.String = jrt.Intern("UTF-8")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.escape$big_func_QMARK_$walk__1896001374")

var Lit_62 *jrt.String = jrt.Intern(" will be kept alive")

var Lit_63 *jrt.String = jrt.Intern("p.")

var Lit_64 *jrt.String = jrt.Intern(".")

var Lit_65 *jrt.String = jrt.Intern(".autotmp_")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk$ed__1896001592")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk$ed1__1896001596")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk$ed1__1896001596$fn__1896001598")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk$ed1__1896001596$fn__1896001604")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk$ed1__1896001596$fn__1896001606")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk$ed1__1896001596$fn__1896001608")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk$ed__1896001592$fn__1896001593")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.escape$bottom_up$callees__1896001755")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.escape$bottom_up$visit__1896001786")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.escape$bottom_up$callees__1896001755$walk__1896001756")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.escape$bottom_up$callees__1896001755$fn__1896001783")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.escape$bottom_up$visit__1896001786$fn__1896001791")

var Lit_78 *jrt.String = jrt.Intern("%")

var Lit_79 *jrt.String = jrt.Intern("&")

var Lit_80 *jrt.String = jrt.Intern("&^")

var Lit_81 *jrt.String = jrt.Intern("/")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.escape$bounded_QMARK_$fn__1896001174")

var Lit_83 *jrt.String = jrt.Intern(">>")

var Lit_84 *jrt.String = jrt.Intern("panic")

var Lit_85 *jrt.String = jrt.Intern("String")

var Lit_86 *jrt.String = jrt.Intern("Slice")

var Lit_87 *jrt.String = jrt.Intern("delete")

var Lit_88 *jrt.String = jrt.Intern("Alignof")

var Lit_89 *jrt.String = jrt.Intern("SliceData")

var Lit_90 *jrt.String = jrt.Intern("copy")

var Lit_91 *jrt.String = jrt.Intern("append")

var Lit_92 *jrt.String = jrt.Intern("keepalive")

var Lit_93 *jrt.String = jrt.Intern("Sizeof")

var Lit_94 *jrt.String = jrt.Intern("Offsetof")

var Lit_95 *jrt.String = jrt.Intern("Add")

var Lit_96 *jrt.String = jrt.Intern("make")

var Lit_97 *jrt.String = jrt.Intern("recover")

var Lit_98 *jrt.String = jrt.Intern("StringData")

var Lit_99 *jrt.String = jrt.Intern("real")

var Lit_100 *jrt.String = jrt.Intern("imag")

var Lit_101 *jrt.String = jrt.Intern("complex")

var Lit_102 *jrt.String = jrt.Intern("cap")

var Lit_103 *jrt.String = jrt.Intern("len")

var Lit_104 *jrt.String = jrt.Intern("max")

var Lit_105 *jrt.String = jrt.Intern("min")

var Lit_106 *jrt.String = jrt.Intern("new")

var Lit_107 *jrt.String = jrt.Intern("print")

var Lit_108 *jrt.String = jrt.Intern("clear")

var Lit_109 *jrt.String = jrt.Intern("println")

var Lit_110 *jrt.String = jrt.Intern("close")

var Lit_111 *jrt.String = jrt.Intern("the built-in ")

var Lit_112 *jrt.String = jrt.Intern("new(")

var Lit_113 *jrt.String = jrt.Intern(")")

var Lit_114 *jrt.String = jrt.Intern("make(")

var Lit_115 *jrt.String = jrt.Intern("(")

var Lit_116 *jrt.String = jrt.Intern("...")

var Lit_117 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273")

var Lit_118 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_119 *jrt.String = jrt.Intern("a call of a callee of no function type")

var Lit_120 *jrt.String = jrt.Intern("GOI_ESCAPE_TRACE")

var Lit_121 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000282")

var Lit_122 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000312")

var Lit_123 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000325")

var Lit_124 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000355")

var Lit_125 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000368")

var Lit_126 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000398")

var Lit_127 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000411")

var Lit_128 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000441")

var Lit_129 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000454")

var Lit_130 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000484")

var Lit_131 *jrt.String = jrt.Intern("a call of kind ")

var Lit_132 *jrt.String = jrt.Intern("escape: call")

var Lit_133 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000282$fn__1896000283")

var Lit_134 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000282$fn__1896000285")

var Lit_135 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000325$fn__1896000326")

var Lit_136 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000325$fn__1896000328")

var Lit_137 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000368$fn__1896000369")

var Lit_138 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000368$fn__1896000371")

var Lit_139 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000411$fn__1896000412")

var Lit_140 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000411$fn__1896000414")

var Lit_141 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000454$fn__1896000455")

var Lit_142 *jrt.String = jrt.Intern("arbace.go.escape$call$fn__1896000273$fn__1896000454$fn__1896000457")

var Lit_143 *jrt.String = jrt.Intern("arbace.go.escape$call_temps$fn__1896000208")

var Lit_144 *jrt.String = jrt.Intern("arbace.go.escape$call_temps$iter__1896000210__1896000214")

var Lit_145 *jrt.String = jrt.Intern("arbace.go.escape$call_temps$iter__1896000210__1896000214$fn__1896000215")

var Lit_146 *jrt.String = jrt.Intern("arbace.go.escape$call_temps$iter__1896000210__1896000214$fn__1896000215$fn__1896000216")

var Lit_147 *jrt.String = jrt.Intern("no function body")

var Lit_148 *jrt.String = jrt.Intern("marked go:noinline")

var Lit_149 *jrt.String = jrt.Intern("marked go:norace with -race compilation")

var Lit_150 *jrt.String = jrt.Intern("marked as having an escaping uintptr argument")

var Lit_151 *jrt.String = jrt.Intern("function too complex: cost ")

var Lit_152 *jrt.String = jrt.Intern(" exceeds budget ")

var Lit_153 *jrt.String = jrt.Intern("GOI_INLINE_COSTS")

var Lit_154 *jrt.String = jrt.Intern("arbace.go.escape$can_inline_BANG_$fn__1896001395")

var Lit_155 *jrt.String = jrt.Intern("arbace.go.escape$can_inline_BANG_$fn__1896001397")

var Lit_156 *jrt.String = jrt.Intern("inl-cost")

var Lit_157 *jrt.String = jrt.Intern("")

var Lit_158 *jrt.String = jrt.Intern("can inline ")

var Lit_159 *jrt.String = jrt.Intern("cannot inline ")

var Lit_160 *jrt.String = jrt.Intern(": ")

var Lit_161 *jrt.String = jrt.Intern("internal/abi")

var Lit_162 *jrt.String = jrt.Intern("EscapeNonString[")

var Lit_163 *jrt.String = jrt.Intern("arbace.go.escape$closure_vars_BANG_$inside_QMARK___1896001744")

var Lit_164 *jrt.String = jrt.Intern("arbace.go.escape$closure_vars_BANG_$fn__1896001746")

var Lit_165 *jrt.String = jrt.Intern("arbace.go.escape$closure_vars_BANG_$fn__1896001748")

var Lit_166 *jrt.String = jrt.Intern("arbace.go.escape$closure_vars_BANG_$fn__1896001748$fn__1896001749")

var Lit_167 *jrt.String = jrt.Intern("arbace.go.escape$comma_ok_temps$inner__1896000678")

var Lit_168 *jrt.String = jrt.Intern("arbace.go.escape$comma_ok_temps$iter__1896000680__1896000684")

var Lit_169 *jrt.String = jrt.Intern("arbace.go.escape$comma_ok_temps$iter__1896000680__1896000684$fn__1896000685")

var Lit_170 *jrt.String = jrt.Intern("arbace.go.escape$comma_ok_temps$iter__1896000680__1896000684$fn__1896000685$fn__1896000686")

var Lit_171 *jrt.String = jrt.Intern("arbace.go.escape$concrete_type$ct__1896001139")

var Lit_172 *jrt.String = jrt.Intern("arbace.go.escape$concrete_type$ct__1896001139$fn__1896001140")

var Lit_173 *jrt.String = jrt.Intern("nil")

var Lit_174 *jrt.String = jrt.Intern("arbace.go.escape$conv_kind$eb__1896000161")

var Lit_175 *jrt.String = jrt.Intern("arbace.go.escape$copy_body$fresh__1896001411")

var Lit_176 *jrt.String = jrt.Intern("arbace.go.escape$copy_body$cp__1896001413")

var Lit_177 *jrt.String = jrt.Intern("arbace.go.escape$copy_body$cp__1896001413$fn__1896001415")

var Lit_178 *jrt.String = jrt.Intern("arbace.go.escape$copy_body$cp__1896001413$fn__1896001415$fn__1896001419")

var Lit_179 *jrt.String = jrt.Intern("arbace.go.escape$copy_body$cp__1896001413$fn__1896001415$fn__1896001421")

var Lit_180 *jrt.String = jrt.Intern("arbace.go.escape$copy_body$cp__1896001413$fn__1896001415$fn__1896001423")

var Lit_181 *jrt.String = jrt.Intern("arbace.go.escape$decl_stmt$fn__1896000734")

var Lit_182 *jrt.String = jrt.Intern("arbace.go.escape$decl_stmt$fn__1896000736")

var Lit_183 *jrt.String = jrt.Intern("partially devirtualizing ")

var Lit_184 *jrt.String = jrt.Intern(" to ")

var Lit_185 *jrt.String = jrt.Intern("devirtualizing ")

var Lit_186 *jrt.String = jrt.Intern("arbace.go.escape$devirtualize$dv__1896001150")

var Lit_187 *jrt.String = jrt.Intern("arbace.go.escape$devirtualize$dv_call__1896001160")

var Lit_188 *jrt.String = jrt.Intern("arbace.go.escape$devirtualize$dv__1896001150$fn__1896001152")

var Lit_189 *jrt.String = jrt.Intern("arbace.go.escape$devirtualize$dv__1896001150$fn__1896001157")

var Lit_190 *jrt.String = jrt.Intern("arbace.go.escape$devirtualize$dv_call__1896001160$fn__1896001162")

var Lit_191 *jrt.String = jrt.Intern("arbace.go.escape$dynamic_parts$fn__1896001816")

var Lit_192 *jrt.String = jrt.Intern("arbace.go.escape$expr$fn__1896000197")

var Lit_193 *jrt.String = jrt.Intern("a composite literal of kind ")

var Lit_194 *jrt.String = jrt.Intern("new of a value")

var Lit_195 *jrt.String = jrt.Intern("the expression ")

var Lit_196 *jrt.String = jrt.Intern("arbace.go.escape$field_offset$fn__1896001348")

var Lit_197 *jrt.String = jrt.Intern("a selection through a type it cannot follow")

var Lit_198 *jrt.String = jrt.Intern("arbace.go.escape$finish_BANG_$fn__1896001012")

var Lit_199 *jrt.String = jrt.Intern("arbace.go.escape$finish_BANG_$fn__1896001021")

var Lit_200 *jrt.String = jrt.Intern("arbace.go.escape$finish_BANG_$fn__1896001034")

var Lit_201 *jrt.String = jrt.Intern("arbace.go.escape$finish_BANG_$fn__1896001036")

var Lit_202 *jrt.String = jrt.Intern("arbace.go.escape$finish_BANG_$fn__1896001012$fn__1896001015")

var Lit_203 *jrt.String = jrt.Intern("escape: tags")

var Lit_204 *jrt.String = jrt.Intern("arbace.go.escape$finish_BANG_$fn__1896001021$fn__1896001024")

var Lit_205 *jrt.String = jrt.Intern("zero-copy string->[]byte conversion")

var Lit_206 *jrt.String = jrt.Intern("moved to heap: ")

var Lit_207 *jrt.String = jrt.Intern("append escapes to heap")

var Lit_208 *jrt.String = jrt.Intern(" escapes to heap")

var Lit_209 *jrt.String = jrt.Intern("append does not escape")

var Lit_210 *jrt.String = jrt.Intern(" does not escape")

var Lit_211 *jrt.String = jrt.Intern("arbace.go.escape$flow_closure$fn__1896000940")

var Lit_212 *jrt.String = jrt.Intern("arbace.go.escape$flow_closure$fn__1896000942")

var Lit_213 *jrt.String = jrt.Intern("value")

var Lit_214 *jrt.String = jrt.Intern("ref")

var Lit_215 *jrt.String = jrt.Intern("arbace.go.escape$fmt_node$fn__1896000143")

var Lit_216 *jrt.String = jrt.Intern(".(")

var Lit_217 *jrt.String = jrt.Intern("any")

var Lit_218 *jrt.String = jrt.Intern("[")

var Lit_219 *jrt.String = jrt.Intern("]")

var Lit_220 *jrt.String = jrt.Intern("<-")

var Lit_221 *jrt.String = jrt.Intern("... argument")

var Lit_222 *jrt.String = jrt.Intern("{")

var Lit_223 *jrt.String = jrt.Intern("}")

var Lit_224 *jrt.String = jrt.Intern("~b")

var Lit_225 *jrt.String = jrt.Intern(" + ")

var Lit_226 *jrt.String = jrt.Intern("arbace.go.escape$fmt_node$fn__1896000147")

var Lit_227 *jrt.String = jrt.Intern(" ")

var Lit_228 *jrt.String = jrt.Intern("func literal")

var Lit_229 *jrt.String = jrt.Intern("*")

var Lit_230 *jrt.String = jrt.Intern(" = ")

var Lit_231 *jrt.String = jrt.Intern("arbace.go.escape$fmt_stmt_assign$fn__1896000670")

var Lit_232 *jrt.String = jrt.Intern("arbace.go.escape$fmt_stmt_assign$fn__1896000672")

var Lit_233 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001203$iter__1896001197__1896001204")

var Lit_234 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001203$iter__1896001197__1896001204$fn__1896001205")

var Lit_235 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001203$iter__1896001197__1896001204$fn__1896001205$iter__1896001199__1896001206")

var Lit_236 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001203$iter__1896001197__1896001204$fn__1896001205$iter__1896001199__1896001206$fn__1896001207")

var Lit_237 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001203$iter__1896001197__1896001204$fn__1896001205$iter__1896001199__1896001206$fn__1896001207$fn__1896001208")

var Lit_238 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001221$iter__1896001215__1896001222")

var Lit_239 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001221$iter__1896001215__1896001222$fn__1896001223")

var Lit_240 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001221$iter__1896001215__1896001222$fn__1896001223$iter__1896001217__1896001224")

var Lit_241 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001221$iter__1896001215__1896001222$fn__1896001223$iter__1896001217__1896001224$fn__1896001225")

var Lit_242 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001221$iter__1896001215__1896001222$fn__1896001223$iter__1896001217__1896001224$fn__1896001225$fn__1896001226")

var Lit_243 *jrt.String = jrt.Intern("(*")

var Lit_244 *jrt.String = jrt.Intern(").")

var Lit_245 *jrt.String = jrt.Intern("arbace.go.escape$for_stmt$iter__1896000832__1896000836")

var Lit_246 *jrt.String = jrt.Intern("arbace.go.escape$for_stmt$iter__1896000832__1896000836$fn__1896000837")

var Lit_247 *jrt.String = jrt.Intern("arbace.go.escape$for_stmt$iter__1896000832__1896000836$fn__1896000837$fn__1896000838")

var Lit_248 *jrt.String = jrt.Intern(".autotmp")

var Lit_249 *jrt.String = jrt.Intern("arbace.go.escape$foreign_body$fn__1896001850")

var Lit_250 *jrt.String = jrt.Intern("arbace.go.escape$foreign_body$fn__1896001850$fn__1896001851")

var Lit_251 *jrt.String = jrt.Intern("arbace.go.escape$foreign_body$fn__1896001850$iter__1896001853__1896001857")

var Lit_252 *jrt.String = jrt.Intern("arbace.go.escape$foreign_body$fn__1896001850$iter__1896001853__1896001857$fn__1896001858")

var Lit_253 *jrt.String = jrt.Intern("arbace.go.escape$foreign_body$fn__1896001850$iter__1896001853__1896001857$fn__1896001858$fn__1896001859")

var Lit_254 *jrt.String = jrt.Intern("arbace.go.escape$foreign_fn$fn__1896001946")

var Lit_255 *jrt.String = jrt.Intern("SHA-256")

var Lit_256 *jrt.String = jrt.Intern("arbace.go.escape$forms_digest$fn__1896001868")

var Lit_257 *jrt.String = jrt.Intern("arbace.go.escape$forms_digest$fn__1896001870")

var Lit_258 *jrt.String = jrt.Intern("arbace.go.escape$forms_digest$fn__1896001876")

var Lit_259 *jrt.String = jrt.Intern("%02x")

var Lit_260 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000518")

var Lit_261 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000520")

var Lit_262 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000522")

var Lit_263 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000524")

var Lit_264 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$iter__1896000526__1896000530")

var Lit_265 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000546")

var Lit_266 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000552")

var Lit_267 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000570")

var Lit_268 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$fn__1896000585")

var Lit_269 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$iter__1896000526__1896000530$fn__1896000531")

var Lit_270 *jrt.String = jrt.Intern("arbace.go.escape$go_defer$iter__1896000526__1896000530$fn__1896000531$fn__1896000532")

var Lit_271 *jrt.String = jrt.Intern("arbace.go.escape$hairy_cost$cost_BANG___1896001239")

var Lit_272 *jrt.String = jrt.Intern("arbace.go.escape$hairy_cost$visit__1896001241")

var Lit_273 *jrt.String = jrt.Intern("arbace.go.escape$hairy_cost$visit_place__1896001324")

var Lit_274 *jrt.String = jrt.Intern("arbace.go.escape$hairy_cost$visit_call__1896001326")

var Lit_275 *jrt.String = jrt.Intern("not inlining functions with closures")

var Lit_276 *jrt.String = jrt.Intern("unhandled op GO")

var Lit_277 *jrt.String = jrt.Intern("unhandled op DEFER")

var Lit_278 *jrt.String = jrt.Intern("arbace.go.escape$hairy_cost$visit__1896001241$fn__1896001274")

var Lit_279 *jrt.String = jrt.Intern("arbace.go.escape$hairy_cost$visit__1896001241$fn__1896001293")

var Lit_280 *jrt.String = jrt.Intern("call to recover")

var Lit_281 *jrt.String = jrt.Intern("arbace.go.escape$has_pointers_QMARK_$fn__1896000022")

var Lit_282 *jrt.String = jrt.Intern("too large for stack")

var Lit_283 *jrt.String = jrt.Intern("too aligned for stack")

var Lit_284 *jrt.String = jrt.Intern("zero-sized element")

var Lit_285 *jrt.String = jrt.Intern("arbace.go.escape$iface_assignments$add_BANG___1896001073")

var Lit_286 *jrt.String = jrt.Intern("arbace.go.escape$iface_assignments$place_obj__1896001075")

var Lit_287 *jrt.String = jrt.Intern("arbace.go.escape$iface_assignments$result_type__1896001077")

var Lit_288 *jrt.String = jrt.Intern("arbace.go.escape$iface_assignments$inl_val__1896001079")

var Lit_289 *jrt.String = jrt.Intern("arbace.go.escape$iface_assignments$assign_pairs__1896001081")

var Lit_290 *jrt.String = jrt.Intern("arbace.go.escape$iface_assignments$walk__1896001113")

var Lit_291 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$fn__1896001461")

var Lit_292 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il__1896001473")

var Lit_293 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il1__1896001479")

var Lit_294 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il1__1896001479$fn__1896001482")

var Lit_295 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il1__1896001479$fn__1896001488")

var Lit_296 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il1__1896001479$fn__1896001494")

var Lit_297 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il1__1896001479$fn__1896001500")

var Lit_298 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il__1896001473$fn__1896001474")

var Lit_299 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls$il__1896001473$fn__1896001476")

var Lit_300 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$fn__1896001967")

var Lit_301 *jrt.String = jrt.Intern("<autogenerated>")

var Lit_302 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$fn__1896001973")

var Lit_303 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$fn__1896001987")

var Lit_304 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$fn__1896001989")

var Lit_305 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$fn__1896001991")

var Lit_306 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$iter__1896001993__1896001997")

var Lit_307 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$fn__1896002011")

var Lit_308 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$fn__1896002013")

var Lit_309 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$iter__1896002015__1896002019")

var Lit_310 *jrt.String = jrt.Intern("inlining call to ")

var Lit_311 *jrt.String = jrt.Intern("function ")

var Lit_312 *jrt.String = jrt.Intern(" considered 'big'; reducing max cost of inlinees")

var Lit_313 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$iter__1896001993__1896001997$fn__1896001998")

var Lit_314 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$iter__1896001993__1896001997$fn__1896001998$fn__1896001999")

var Lit_315 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$iter__1896002015__1896002019$fn__1896002020")

var Lit_316 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_$iter__1896002015__1896002019$fn__1896002020$fn__1896002021")

var Lit_317 *jrt.String = jrt.Intern("arbace.go.escape$keep_alive_calls$iter__1896001553__1896001557")

var Lit_318 *jrt.String = jrt.Intern("arbace.go.escape$keep_alive_calls$iter__1896001553__1896001557$fn__1896001558")

var Lit_319 *jrt.String = jrt.Intern("arbace.go.escape$keep_alive_calls$iter__1896001553__1896001557$fn__1896001558$fn__1896001559")

var Lit_320 *jrt.String = jrt.Intern("dereference will be kept alive")

var Lit_321 *jrt.String = jrt.Intern("expr is unknown to bloop pass")

var Lit_322 *jrt.String = jrt.Intern("arbace.go.escape$label_states$walk__1896000917")

var Lit_323 *jrt.String = jrt.Intern("arbace.go.escape$leak_optimize$fn__1896000079")

var Lit_324 *jrt.String = jrt.Intern("arbace.go.escape$live_stmts$fn__1896000717")

var Lit_325 *jrt.String = jrt.Intern("go/")

var Lit_326 *jrt.String = jrt.Intern(".ae")

var Lit_327 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$cfile__1896001880")

var Lit_328 *jrt.String = jrt.Intern("-inline")

var Lit_329 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001882")

var Lit_330 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884")

var Lit_331 *jrt.String = jrt.Intern("getParentFile")

var Lit_332 *jrt.String = jrt.Intern("mkdirs")

var Lit_333 *jrt.String = jrt.Intern(".tmp")

var Lit_334 *jrt.String = jrt.Intern("-")

var Lit_335 *jrt.String = jrt.Intern(".edn")

var Lit_336 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$fn__1896001885")

var Lit_337 *jrt.String = jrt.Intern("1")

var Lit_338 *jrt.String = jrt.Intern("GOI_ESCAPE_STD_INLINE")

var Lit_339 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$fn__1896001887")

var Lit_340 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$iter__1896001899__1896001903")

var Lit_341 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$fn__1896001909")

var Lit_342 *jrt.String = jrt.Intern("escape: package")

var Lit_343 *jrt.String = jrt.Intern("not analyzed:")

var Lit_344 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$fn__1896001887$iter__1896001888__1896001892")

var Lit_345 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$fn__1896001887$iter__1896001888__1896001892$fn__1896001893")

var Lit_346 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$fn__1896001887$iter__1896001888__1896001892$fn__1896001893$fn__1896001894")

var Lit_347 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$iter__1896001899__1896001903$fn__1896001904")

var Lit_348 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags$fn__1896001884$iter__1896001899__1896001903$fn__1896001904$fn__1896001905")

var Lit_349 *jrt.String = jrt.Intern("arbace.go.escape$loop_leaked$walk__1896000739")

var Lit_350 *jrt.String = jrt.Intern("arbace.go.escape$merged_tag_hole$iter__1896000234__1896000238")

var Lit_351 *jrt.String = jrt.Intern("arbace.go.escape$merged_tag_hole$iter__1896000234__1896000238$fn__1896000239")

var Lit_352 *jrt.String = jrt.Intern("arbace.go.escape$merged_tag_hole$iter__1896000234__1896000238$fn__1896000239$fn__1896000240")

var Lit_353 *jrt.String = jrt.Intern("arbace.go.escape$new_batch$mk__1896000085")

var Lit_354 *jrt.String = jrt.Intern("arbace.go.escape$normalize_go_defer$nm__1896000639")

var Lit_355 *jrt.String = jrt.Intern("arbace.go.escape$normalize_go_defer$nm__1896000639$fn__1896000641")

var Lit_356 *jrt.String = jrt.Intern("assuming ")

var Lit_357 *jrt.String = jrt.Intern(" is unsafe uintptr")

var Lit_358 *jrt.String = jrt.Intern("leaking param: ")

var Lit_359 *jrt.String = jrt.Intern("marking ")

var Lit_360 *jrt.String = jrt.Intern(" as escaping uintptr")

var Lit_361 *jrt.String = jrt.Intern(" as escaping ...uintptr")

var Lit_362 *jrt.String = jrt.Intern("arbace.go.escape$param_tag$fn__1896001005")

var Lit_363 *jrt.String = jrt.Intern("arbace.go.escape$params_str$fn__1896000032")

var Lit_364 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$blk__1896001568")

var Lit_365 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$fn__1896001571")

var Lit_366 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$fn__1896001573")

var Lit_367 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$fn__1896001575")

var Lit_368 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$fn__1896001577")

var Lit_369 *jrt.String = jrt.Intern("function result")

var Lit_370 *jrt.String = jrt.Intern("s")

var Lit_371 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$tmp_of__1896001579")

var Lit_372 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$fn__1896001581")

var Lit_373 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt$fn__1896001581$fn__1896001582")

var Lit_374 *jrt.String = jrt.Intern("function arg will be kept alive")

var Lit_375 *jrt.String = jrt.Intern("arbace.go.escape$prune_switches$pr__1896001822")

var Lit_376 *jrt.String = jrt.Intern("arbace.go.escape$prune_switches$pr__1896001822$fn__1896001824")

var Lit_377 *jrt.String = jrt.Intern("arbace.go.escape$prune_switches$pr__1896001822$fn__1896001829")

var Lit_378 *jrt.String = jrt.Intern("arbace.go.escape$prune_switches$pr__1896001822$fn__1896001833")

var Lit_379 *jrt.String = jrt.Intern("arbace.go.escape$prune_switches$pr__1896001822$fn__1896001829$fn__1896001830")

var Lit_380 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt$fn__1896000797")

var Lit_381 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt$fn__1896000799")

var Lit_382 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt$fn__1896000801")

var Lit_383 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt$fn__1896000803")

var Lit_384 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt$iter__1896000805__1896000809")

var Lit_385 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt$iter__1896000805__1896000809$fn__1896000810")

var Lit_386 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt$iter__1896000805__1896000809$fn__1896000810$fn__1896000811")

var Lit_387 *jrt.String = jrt.Intern("Data")

var Lit_388 *jrt.String = jrt.Intern("reflect")

var Lit_389 *jrt.String = jrt.Intern("arbace.go.escape$register_copies_BANG_$walk__1896001428")

var Lit_390 *jrt.String = jrt.Intern("arbace.go.escape$register_copies_BANG_$walk__1896001428$fn__1896001429")

var Lit_391 *jrt.String = jrt.Intern("leaking param content: ")

var Lit_392 *jrt.String = jrt.Intern(" to result ")

var Lit_393 *jrt.String = jrt.Intern(" level=")

var Lit_394 *jrt.String = jrt.Intern("mutates param: ")

var Lit_395 *jrt.String = jrt.Intern(" derefs=")

var Lit_396 *jrt.String = jrt.Intern("calls param: ")

var Lit_397 *jrt.String = jrt.Intern(" does not escape, mutate, or call")

var Lit_398 *jrt.String = jrt.Intern("arbace.go.escape$resolve_assigned_callees$fn__1896000249")

var Lit_399 *jrt.String = jrt.Intern("arbace.go.escape$return_stmt$fn__1896000893")

var Lit_400 *jrt.String = jrt.Intern("arbace.go.escape$return_stmt$fn__1896000895")

var Lit_401 *jrt.String = jrt.Intern("arbace.go.escape$returns__GT_assigns$rw__1896001447")

var Lit_402 *jrt.String = jrt.Intern("arbace.go.escape$returns__GT_assigns$rw__1896001447$fn__1896001449")

var Lit_403 *jrt.String = jrt.Intern(".inlret")

var Lit_404 *jrt.String = jrt.Intern("arbace.go.escape$returns__GT_assigns$rw__1896001447$fn__1896001452")

var Lit_405 *jrt.String = jrt.Intern("arbace.go.escape$scan_fn_BANG_$declare_BANG___1896001612")

var Lit_406 *jrt.String = jrt.Intern("arbace.go.escape$scan_fn_BANG_$func_typed_QMARK___1896001614")

var Lit_407 *jrt.String = jrt.Intern("arbace.go.escape$scan_fn_BANG_$prune_BANG___1896001616")

var Lit_408 *jrt.String = jrt.Intern("arbace.go.escape$scan_fn_BANG_$walk__1896001626")

var Lit_409 *jrt.String = jrt.Intern(".func")

var Lit_410 *jrt.String = jrt.Intern("arbace.go.escape$scan_fn_BANG_$walk__1896001626$fn__1896001694")

var Lit_411 *jrt.String = jrt.Intern("arbace.go.escape$select_node$fn__1896000121")

var Lit_412 *jrt.String = jrt.Intern("arbace.go.escape$static_init_QMARK_$fn__1896001808")

var Lit_413 *jrt.String = jrt.Intern("arbace.go.escape$static_init_QMARK_$fn__1896001810")

var Lit_414 *jrt.String = jrt.Intern("arbace.go.escape$static_init_QMARK_$fn__1896001812")

var Lit_415 *jrt.String = jrt.Intern("arbace.go.escape$static_inlined_call_QMARK_$ok__1896001953")

var Lit_416 *jrt.String = jrt.Intern("arbace.go.escape$static_inlined_call_QMARK_$ok__1896001953$fn__1896001956")

var Lit_417 *jrt.String = jrt.Intern("arbace.go.escape$static_inlined_call_QMARK_$ok__1896001953$fn__1896001958")

var Lit_418 *jrt.String = jrt.Intern("arbace.go.escape$static_inlined_call_QMARK_$ok__1896001953$fn__1896001960")

var Lit_419 *jrt.String = jrt.Intern("arbace.go.escape$std_imports$fn__1896001913")

var Lit_420 *jrt.String = jrt.Intern("arbace.go.escape$std_imports$iter__1896001915__1896001921")

var Lit_421 *jrt.String = jrt.Intern("arbace.go.escape$std_imports$iter__1896001915__1896001921$fn__1896001922")

var Lit_422 *jrt.String = jrt.Intern("arbace.go.escape$std_imports$iter__1896001915__1896001921$fn__1896001922$iter__1896001917__1896001923")

var Lit_423 *jrt.String = jrt.Intern("arbace.go.escape$std_imports$iter__1896001915__1896001921$fn__1896001922$iter__1896001917__1896001923$fn__1896001924")

var Lit_424 *jrt.String = jrt.Intern("arbace.go.escape$std_imports$iter__1896001915__1896001921$fn__1896001922$iter__1896001917__1896001923$fn__1896001924$fn__1896001925")

var Lit_425 *jrt.String = jrt.Intern("arbace.go.escape$std_result$mk__1896001839")

var Lit_426 *jrt.String = jrt.Intern("arbace.go.escape$std_result$res__1896001845")

var Lit_427 *jrt.String = jrt.Intern("arbace.go.escape$std_result$fn__1896001847")

var Lit_428 *jrt.String = jrt.Intern("arbace.go.escape$std_result$mk__1896001839$fn__1896001840")

var Lit_429 *jrt.String = jrt.Intern("arbace.go.escape$std_result$mk__1896001839$fn__1896001842")

var Lit_430 *jrt.String = jrt.Intern("arbace.go.escape$stmt$fn__1896000898")

var Lit_431 *jrt.String = jrt.Intern("the statement ")

var Lit_432 *jrt.String = jrt.Intern(" at ")

var Lit_433 *jrt.String = jrt.Intern("arbace.go.escape$stmt_str$ex__1896001356")

var Lit_434 *jrt.String = jrt.Intern("arbace.go.escape$stmt_str$pl__1896001358")

var Lit_435 *jrt.String = jrt.Intern("= ")

var Lit_436 *jrt.String = jrt.Intern("switch statement")

var Lit_437 *jrt.String = jrt.Intern("for loop")

var Lit_438 *jrt.String = jrt.Intern("if ")

var Lit_439 *jrt.String = jrt.Intern(" { ")

var Lit_440 *jrt.String = jrt.Intern(" }")

var Lit_441 *jrt.String = jrt.Intern(" else { ")

var Lit_442 *jrt.String = jrt.Intern("select statement")

var Lit_443 *jrt.String = jrt.Intern("return ")

var Lit_444 *jrt.String = jrt.Intern("; ")

var Lit_445 *jrt.String = jrt.Intern("arbace.go.escape$stmt_str$iter__1896001361__1896001365")

var Lit_446 *jrt.String = jrt.Intern(" := ")

var Lit_447 *jrt.String = jrt.Intern("arbace.go.escape$stmt_str$fn__1896001371")

var Lit_448 *jrt.String = jrt.Intern(" <- ")

var Lit_449 *jrt.String = jrt.Intern("++")

var Lit_450 *jrt.String = jrt.Intern("--")

var Lit_451 *jrt.String = jrt.Intern("arbace.go.escape$stmt_str$iter__1896001361__1896001365$fn__1896001366")

var Lit_452 *jrt.String = jrt.Intern("arbace.go.escape$stmt_str$iter__1896001361__1896001365$fn__1896001366$fn__1896001367")

var Lit_453 *jrt.String = jrt.Intern("var ")

var Lit_454 *jrt.String = jrt.Intern("arbace.go.escape$tag_hole$iter__1896000222__1896000226")

var Lit_455 *jrt.String = jrt.Intern("arbace.go.escape$tag_hole$iter__1896000222__1896000226$fn__1896000227")

var Lit_456 *jrt.String = jrt.Intern("arbace.go.escape$tag_hole$iter__1896000222__1896000226$fn__1896000227$fn__1896000228")

var Lit_457 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$fn__1896001509")

var Lit_458 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$fresh__1896001514")

var Lit_459 *jrt.String = jrt.Intern("~p")

var Lit_460 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$fn__1896001517")

var Lit_461 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$fn__1896001519")

var Lit_462 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$fn__1896001521")

var Lit_463 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$fn__1896001527")

var Lit_464 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$iter__1896001535__1896001539")

var Lit_465 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$fn__1896001545")

var Lit_466 *jrt.String = jrt.Intern("~R")

var Lit_467 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$iter__1896001535__1896001539$fn__1896001540")

var Lit_468 *jrt.String = jrt.Intern("arbace.go.escape$try_inline$iter__1896001535__1896001539$fn__1896001540$fn__1896001541")

var Lit_469 *jrt.String = jrt.Intern("untyped complex")

var Lit_470 *jrt.String = jrt.Intern("untyped bool")

var Lit_471 *jrt.String = jrt.Intern("untyped float")

var Lit_472 *jrt.String = jrt.Intern("unsafe.Pointer")

var Lit_473 *jrt.String = jrt.Intern("untyped int")

var Lit_474 *jrt.String = jrt.Intern("untyped string")

var Lit_475 *jrt.String = jrt.Intern("untyped rune")

var Lit_476 *jrt.String = jrt.Intern(",")

var Lit_477 *jrt.String = jrt.Intern("error")

var Lit_478 *jrt.String = jrt.Intern("map[")

var Lit_479 *jrt.String = jrt.Intern("chan<- ")

var Lit_480 *jrt.String = jrt.Intern("<-chan ")

var Lit_481 *jrt.String = jrt.Intern("chan (")

var Lit_482 *jrt.String = jrt.Intern("chan ")

var Lit_483 *jrt.String = jrt.Intern("interface {}")

var Lit_484 *jrt.String = jrt.Intern("interface {")

var Lit_485 *jrt.String = jrt.Intern(";")

var Lit_486 *jrt.String = jrt.Intern("arbace.go.escape$type_str$iter__1896000041__1896000045")

var Lit_487 *jrt.String = jrt.Intern("[]")

var Lit_488 *jrt.String = jrt.Intern("func")

var Lit_489 *jrt.String = jrt.Intern("struct {")

var Lit_490 *jrt.String = jrt.Intern("arbace.go.escape$type_str$iter__1896000063__1896000067")

var Lit_491 *jrt.String = jrt.Intern("arbace.go.escape$type_str$iter__1896000041__1896000045$fn__1896000046")

var Lit_492 *jrt.String = jrt.Intern("arbace.go.escape$type_str$iter__1896000041__1896000045$fn__1896000046$fn__1896000047")

var Lit_493 *jrt.String = jrt.Intern("arbace.go.escape$type_str$iter__1896000063__1896000067$fn__1896000068")

var Lit_494 *jrt.String = jrt.Intern("arbace.go.escape$type_str$iter__1896000063__1896000067$fn__1896000068$fn__1896000069")

var Lit_495 *jrt.String = jrt.Intern("arbace.go.escape$type_switch_stmt$iter__1896000873__1896000877")

var Lit_496 *jrt.String = jrt.Intern("arbace.go.escape$type_switch_stmt$iter__1896000873__1896000877$fn__1896000878")

var Lit_497 *jrt.String = jrt.Intern("arbace.go.escape$type_switch_stmt$iter__1896000873__1896000877$fn__1896000878$fn__1896000879")

var Lit_498 *jrt.String = jrt.Intern("not supported by goi yet: escape analysis of ")

var Lit_499 *jrt.String = jrt.Intern("escape analysis of ")

var Lit_500 *jrt.String = jrt.Intern("arbace.go.escape$walk_all_BANG_$enqueue__1896000983")

var Lit_501 *jrt.String = jrt.Intern("arbace.go.escape$warm_order$visit__1896001932")

var Lit_502 *jrt.String = jrt.Intern("arbace.go.escape$warm_order$fn__1896001942")

var Lit_503 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$fn__1896000603")

var Lit_504 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$fn__1896000605")

var Lit_505 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$fn__1896000607")

var Lit_506 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$fn__1896000609")

var Lit_507 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$iter__1896000611__1896000615")

var Lit_508 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$ln__1896000627")

var Lit_509 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$fn__1896000630")

var Lit_510 *jrt.String = jrt.Intern("gowrap")

var Lit_511 *jrt.String = jrt.Intern("deferwrap")

var Lit_512 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$iter__1896000611__1896000615$fn__1896000616")

var Lit_513 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer$iter__1896000611__1896000615$fn__1896000616$fn__1896000617")

var Lit_514 *jrt.String = jrt.Intern("arbace.go.escape$wrapper_visit$fn__1896000511")

var Lit_515 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,zerocopykn7,privatekn8,arglistsyn4,lineyn3,msgyn1,dyn4,whatyn2,tykn3,tagyn4,longyn1,nkn8,declaredyn2,psyn8,variadicyn1,lyn1,kyn1,vyn1,ayn2,lkyn1,iyn6,derefsyn1,fyn1,byn1,eyn5,deltayn8,persistsyn1,oyn3,srcyn2,ksyn1,cyn3,xtyyn4,pathyn1,xyn5,stepsyn2,mnkn4,callkn3,litkn5,localkn6,globalkn4,funckn5,constkn3,nilkn4,convkn13,convert-ifacekn5,indexkn9,map-indexkn5,slicekn3,selkn5,fieldkn6,methodkn11,method-exprkn6,assertkn2,fnkn4,typekn6,resultkn11,place-localkn5,unarykn4,addrkn5,derefkn4,recvkn6,addstryn4,argsyn1,pv11,arbace.core5,in-nsMyn16,arbace.go.escapem2,R0,s1940,gc's escape analysis over goi's checked trees (doc/go/GOI-SPEC.md, \"Since v1: gc's escape\n  analysis\"): a port, rule for rule, of Go 1.27.1's cmd/compile/internal/escape (escape.go,\n  graph.go, solve.go, expr.go, stmt.go, assign.go, call.go, utils.go, leaks.go; TamaGo's go1.27.1,\n  src/cmd/compile/internal/escape, its forms in tamago/cmd/go/cmd/compile/internal/escape), with\n  the parts of gc's front end it sees the tree through: ir.VisitFuncsBottomUp (ir/scc.go), the\n  ReassignOracle's StaticValue (ir/reassignment.go), loopvar.ForCapture's per-iteration loop\n  variables (loopvar/loopvar.go), typecheck's normalizeGoDeferCall (go/defer wrappers),\n  rewriteMultiValueCall and FixVariadicCall, and ir's expression format (ir/fmt.go) and types'\n  (types/fmt.go) for the messages.\n\n  It reports what gc's -m reports of it: \"moved to heap: x\", \"E escapes to heap\", \"E does not\n  escape\", \"leaking param: p\", \"leaking param content: p\", \"leaking param: p to result r\n  level=n\", \"p does not escape\", the self-assignments ignored; as lines FILE:LINE: MESSAGE, at\n  the forms' lines (the forms keep no columns). The checked tree stands for gc's IR after\n  typecheck: its implicit conversions are its OCONVIFACE nodes, its places and selections gc's\n  ODOT/ODOTPTR/OINDEX, a call's kind gc's OCALLFUNC/OCALLINTER (a method call as gc's fixed\n  OCALLFUNC of the method expression, the receiver its first argument).\n\n  Calls of functions of other packages use their parameter tags as gc does; goi has no export\n  data, so a package's functions are analyzed from their forms when the package's forms are at\n  hand (arbace.go.escape/*import-tags*), else such a call's arguments leak to the heap (gc's\n  unknown callee).\n\n  Without -l gc's inliner runs first (inline/inl.go's CanInline and hairyVisitor, the interleaved\n  inliner, devirtualize.StaticCall interleaved): can inline f, inlining call to f; the analysis then\n  sees the inlined bodies.m2,R0,s1940,gc's escape analysis over goi's checked trees (doc/go/GOI-SPEC.md, \"Since v1: gc's escape\n  analysis\"): a port, rule for rule, of Go 1.27.1's cmd/compile/internal/escape (escape.go,\n  graph.go, solve.go, expr.go, stmt.go, assign.go, call.go, utils.go, leaks.go; TamaGo's go1.27.1,\n  src/cmd/compile/internal/escape, its forms in tamago/cmd/go/cmd/compile/internal/escape), with\n  the parts of gc's front end it sees the tree through: ir.VisitFuncsBottomUp (ir/scc.go), the\n  ReassignOracle's StaticValue (ir/reassignment.go), loopvar.ForCapture's per-iteration loop\n  variables (loopvar/loopvar.go), typecheck's normalizeGoDeferCall (go/defer wrappers),\n  rewriteMultiValueCall and FixVariadicCall, and ir's expression format (ir/fmt.go) and types'\n  (types/fmt.go) for the messages.\n\n  It reports what gc's -m reports of it: \"moved to heap: x\", \"E escapes to heap\", \"E does not\n  escape\", \"leaking param: p\", \"leaking param content: p\", \"leaking param: p to result r\n  level=n\", \"p does not escape\", the self-assignments ignored; as lines FILE:LINE: MESSAGE, at\n  the forms' lines (the forms keep no columns). The checked tree stands for gc's IR after\n  typecheck: its implicit conversions are its OCONVIFACE nodes, its places and selections gc's\n  ODOT/ODOTPTR/OINDEX, a call's kind gc's OCALLFUNC/OCALLINTER (a method call as gc's fixed\n  OCALLFUNC of the method expression, the receiver its first argument).\n\n  Calls of functions of other packages use their parameter tags as gc does; goi has no export\n  data, so a package's functions are analyzed from their forms when the package's forms are at\n  hand (arbace.go.escape/*import-tags*), else such a call's arguments leak to the heap (gc's\n  unknown callee).\n\n  Without -l gc's inliner runs first (inline/inl.go's CanInline and hairyVisitor, the interleaved\n  inliner, devirtualize.StaticCall interleaved): can inline f, inlining call to f; the analysis then\n  sees the inlined bodies.R1,v16,arbace.go.escape3,*m*l1,m10,R2,TR3,i40,R4,i1,R5,s19,arbace/go/escape.aeR0,s33,gc's -m level (base.Flag.LowerM).v16,arbace.go.escape7,*debug*m2,R6,l1,m10,R2,TR3,i44,R4,i1,R5,s19,arbace/go/escape.aeR0,s114,gc's -d flags the analysis reads: {:escapemutationscalls n :zerocopy n} (base.Debug; zerocopy\n  is on by default).v16,arbace.go.escape6,*msgs*m10,R2,TR3,i49,R4,i1,R5,s19,arbace/go/escape.aeR0,s47,A volatile vector of the messages: [line text].v16,arbace.go.escape7,*wfile*m10,R2,TR3,i53,R4,i1,R5,s19,arbace/go/escape.aeR0,s41,The file of the function a message is of.v16,arbace.go.escape5,warn!m10,R7,TR8,L1,V2,R9,R10,R3,i57,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,file-ofm10,R7,TR8,L1,V1,R11,R3,i60,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,unsupported!m10,R7,TR8,L1,V1,R12,R3,i64,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,*ctx*m10,R2,TR3,i67,R4,i1,R5,s19,arbace/go/escape.aeR0,s174,The run: {:local-pkg path, :fn-of-obj HashMap obj -> fn, :fn-of-node IdentityHashMap node -> fn,\n  :loc-of HashMap obj -> location (gc's Name.Opt), :owner HashMap obj -> fn}.v16,arbace.go.escape5,underm10,R7,TR8,L1,V1,R13,R3,i74,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,kindm10,R7,TR8,L1,V1,R13,R3,i76,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape6,iface?m10,R7,TR8,L1,V1,R13,R3,i82,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,elemm10,R7,TR8,L1,V1,R13,R3,i83,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape13,has-pointers?m10,R8,L1,V1,R13,R0,s23,types.Type.HasPointers.R3,i92,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape13,direct-iface?m12,R7,TR8,L1,V1,R13,R0,s88,types.IsDirectIface: a pointer-shaped type, stored in an interface's data word directly.R3,i106,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,sizem10,R7,TR8,L1,MV1,R13,m2,R14,R15,R3,i119,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,alignm10,R7,TR8,L1,MV1,R13,m2,R14,R15,R3,i120,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,untyped?m10,R7,TR8,L1,V1,R13,R3,i122,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape6,go-opsm24,s2,!=s2,!=s1,=s2,==s6,bit-ors1,|s3,nots1,!s7,bit-xors1,^s7,bit-ands1,&s11,bit-and-nots2,&^s4,not=s2,!=s2,ors2,||s7,bit-nots1,^s3,ands2,&&s2,==s2,==m8,R7,TR3,i124,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape3,gopm12,R7,TR8,L1,V1,R16,R0,s80,A unary or binary node's Go operator (the forms spell some: bit-and, not=, ...).R3,i128,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,spread-call?m10,R7,TR8,L1,V1,R16,R3,i133,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,type-strm8,R17,TR3,i137,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape10,params-strm10,R7,TR8,L1,V2,R18,R19,R3,i139,R4,i1,R5,s19,arbace/go/escape.aem10,R8,L1,V1,R13,R0,s150,A type as gc's %v of a types.Type prints it (types/fmt.go, fmtGo): the local package's names\n  unqualified, others' qualified by their package's name.R3,i146,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,attr-escapesm8,R7,TR3,i204,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape13,attr-persistsl2,m8,R7,TR3,i205,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,attr-mutatesl4,m8,R7,TR3,i206,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape10,attr-callsl8,m8,R7,TR3,i207,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,lgetm10,R7,TR8,L1,V2,R20,R21,R3,i209,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,lset!m10,R7,TR8,L1,V3,R20,R21,R22,R3,i210,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,has-attr?m10,R7,TR8,L1,V2,R20,R23,R3,i211,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,no-leaksV8,l0,l0,l0,l0,l0,l0,l0,l0,m8,R7,TR3,i214,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape15,num-esc-resultsl5,m8,R7,TR3,i215,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,leak-getm10,R7,TR8,L1,MV2,R24,R25,m2,R14,R15,R3,i216,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,leak-addm10,R7,TR8,L1,V3,R24,R25,R26,R3,i217,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape13,leak-optimizem10,R7,TR8,L1,V1,R24,R3,i222,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,leak-encodem12,R7,TR8,L1,V1,R24,R0,s82,Encode then parseLeaks: a tag whose heap leak is 0 keeps that alone (Encode's \"\").R3,i227,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape6,fn-getm10,R7,TR8,L1,V2,R27,R21,R3,i232,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,fn-set!m10,R7,TR8,L1,V3,R27,R21,R22,R3,i233,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,new-batchm10,R7,TR8,L1,V0,R3,i235,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,with-fnm10,R7,TR8,L1,V2,R28,R27,R3,i246,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape2,ebm10,R7,TR8,L1,V1,R29,R3,i247,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,curfnm10,R7,TR8,L1,V1,R29,R3,i248,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,depthm10,R7,TR8,L1,MV1,R29,m2,R14,R15,R3,i249,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,holem10,R7,TR8,L1,V1,R20,R3,i251,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,heap-holem10,R7,TR8,L1,V1,R29,R3,i252,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,mutator-holem10,R7,TR8,L1,V1,R29,R3,i253,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,callee-holem10,R7,TR8,L1,V1,R29,R3,i254,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,discard-holem10,R7,TR8,L1,V1,R29,R3,i255,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,shiftm10,R7,TR8,L1,V2,R21,R30,R3,i256,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,k-derefm10,R7,TR8,L1,V1,R21,R3,i259,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape6,k-addrm10,R7,TR8,L1,V1,R21,R3,i260,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,dot-typem10,R7,TR8,L1,V2,R21,R13,R3,i261,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,name-loc?m10,R7,TR8,L1,V1,R20,R3,i264,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,new-locm12,R7,TR8,L1,V3,R29,R16,R31,R0,s87,escape.newLoc: n an object (a variable: :what :name) or a node (an expression), or nil.R3,i266,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,old-locm10,R7,TR8,L1,V2,R29,R32,R3,i282,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,flowm12,R7,TR8,L1,V3,R29,R21,R33,R0,s11,batch.flow.R3,i286,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,tee-holem10,R7,TR8,L1,V2,R29,R34,R3,i300,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,laterm10,R7,TR8,L1,V2,R29,R21,R3,i308,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,spillm10,R7,TR8,L1,V3,R29,R21,R16,R3,i313,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape10,foreign-fnm8,R17,TR3,i320,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,fn-of-objm10,R7,TR8,L1,V1,R32,R3,i322,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape10,fn-of-nodem10,R7,TR8,L1,V1,R16,R3,i329,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape17,contains-closure?m12,R7,TR8,L1,V2,R27,R35,R0,s57,ir.ContainsClosure: closure c nested (at any depth) in f.R3,i331,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape16,in-mutual-batch?m10,R7,TR8,L1,V1,R27,R3,i340,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,node-typem10,R7,TR8,L1,V1,R16,R3,i345,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape6,const?m10,R7,TR8,L1,V1,R16,R3,i346,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,field-stepsm12,R7,TR8,L1,V3,R36,R37,R26,R0,s143,A selection's steps from x: [[deref? field-type] ...] for path's field indexes (the embedded\n  fields' and the selected field's) from x's type.R3,i348,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,select-nodem12,R7,TR8,L1,V3,R38,R39,R9,R0,s116,The nodes of x.f1.f2...: a selection node of one step each ({:op :sel :deref d :x ..}), from\n  steps of field-steps.R3,i363,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,expand-fieldm12,R7,TR8,L1,V1,R16,R0,s86,A :field or :place-field node as nested one-step selections (gc's ODOT/ODOTPTR chain).R3,i370,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,method-recvm12,R7,TR8,L1,V1,R40,R0,s161,A method call's or method value's receiver as gc's IR has it: the embedded fields selected\n  (:path less its last, the method's index), then the implicit & or *.R3,i377,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,fmt-nodem8,R17,TR3,i402,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape13,variadic-argsm8,R17,TR3,i402,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,precm52,R41,l8,R42,l8,R43,l8,R44,l8,R45,l8,R46,l8,R47,l8,R48,l8,R49,l8,R50,l8,R51,l8,R52,l8,R53,l8,R54,l8,R55,l8,R56,l8,R57,l8,R58,l8,R59,l8,R60,l8,R61,l8,R62,l7,R63,l7,R64,l7,R65,l7,R66,l5,m8,R7,TR3,i404,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,bin-precm38,s2,>>l6,s2,&&l2,s2,!=l4,s1,*l6,s1,%l6,s2,<=l4,s1,|l5,s1,/l6,s1,-l5,s2,>=l4,s1,&l6,s1,<l4,s2,<<l6,s2,&^l6,s2,||l1,s2,==l4,s1,^l5,s1,+l5,s1,>l4,m8,R7,TR3,i409,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,node-precm10,R7,TR8,L1,V1,R16,R3,i413,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,const-strm10,R7,TR8,L1,V1,R16,R3,i419,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape8,args-strm10,R7,TR8,L1,V1,R67,R3,i435,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,builtin-strm10,R7,TR8,L1,V1,R16,R3,i437,R4,i1,R5,s19,arbace/go/escape.aem10,R8,L1,V2,R16,R68,R0,s64,exprFmt: node n as gc's %v of its IR prints it, at precedence p.R3,i451,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,exprm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,discardm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape5,stmtsm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,stmtm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,callm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape10,walk-func!m8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,assign-listm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape7,addr-ofm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,reassigned!m8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape4,dcl!m8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape13,call-tag-holem8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape17,heap-alloc-reasonm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape10,call-tempsm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape9,elt-valuem8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape12,builtin-callm8,R17,TR3,i520,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape10,with-line*m10,R7,TR8,L1,V3,R29,R16,R27,R3,i522,R4,i1,R5,s19,arbace/go/escape.aev16,arbace.go.escape11,assign-heapm10,R7,TR8,L1,V2,R29,R33,R3,i530,R4,i1,R5,s19,arbace/go/escape.ae")

var Lit_516 *jrt.String = jrt.Intern("arbace.go.escape$eval1896000004$loading__1927001464__auto____1896000005")

var Lit_517 *jrt.String = jrt.Intern("arbace.go.escape$eval1896000008$fn__1896000009")

var Lit_518 *jrt.String = jrt.Intern("arbace.go.escape$warn_BANG_")

var Lit_519 *jrt.String = jrt.Intern("arbace.go.escape$file_of")

var Lit_520 *jrt.String = jrt.Intern("arbace.go.escape$unsupported_BANG_")

var Lit_521 *jrt.String = jrt.Intern("arbace.go.escape$under")

var Lit_522 *jrt.String = jrt.Intern("arbace.go.escape$kind")

var Lit_523 *jrt.String = jrt.Intern("arbace.go.escape$iface_QMARK_")

var Lit_524 *jrt.String = jrt.Intern("arbace.go.escape$elem")

var Lit_525 *jrt.String = jrt.Intern("arbace.go.escape$has_pointers_QMARK_")

var Lit_526 *jrt.String = jrt.Intern("arbace.go.escape$direct_iface_QMARK_")

var Lit_527 *jrt.String = jrt.Intern("arbace.go.escape$size")

var Lit_528 *jrt.String = jrt.Intern("arbace.go.escape$align")

var Lit_529 *jrt.String = jrt.Intern("arbace.go.escape$untyped_QMARK_")

var Lit_530 *jrt.String = jrt.Intern("arbace.go.escape$gop")

var Lit_531 *jrt.String = jrt.Intern("arbace.go.escape$spread_call_QMARK_")

var Lit_532 *jrt.String = jrt.Intern("arbace.go.escape$params_str")

var Lit_533 *jrt.String = jrt.Intern("arbace.go.escape$type_str")

var Lit_534 *jrt.String = jrt.Intern("arbace.go.escape$lget")

var Lit_535 *jrt.String = jrt.Intern("arbace.go.escape$lset_BANG_")

var Lit_536 *jrt.String = jrt.Intern("arbace.go.escape$has_attr_QMARK_")

var Lit_537 *jrt.String = jrt.Intern("arbace.go.escape$leak_get")

var Lit_538 *jrt.String = jrt.Intern("arbace.go.escape$leak_add")

var Lit_539 *jrt.String = jrt.Intern("arbace.go.escape$leak_optimize")

var Lit_540 *jrt.String = jrt.Intern("arbace.go.escape$leak_encode")

var Lit_541 *jrt.String = jrt.Intern("arbace.go.escape$fn_get")

var Lit_542 *jrt.String = jrt.Intern("arbace.go.escape$fn_set_BANG_")

var Lit_543 *jrt.String = jrt.Intern("arbace.go.escape$new_batch")

var Lit_544 *jrt.String = jrt.Intern("arbace.go.escape$with_fn")

var Lit_545 *jrt.String = jrt.Intern("arbace.go.escape$eb")

var Lit_546 *jrt.String = jrt.Intern("arbace.go.escape$curfn")

var Lit_547 *jrt.String = jrt.Intern("arbace.go.escape$depth")

var Lit_548 *jrt.String = jrt.Intern("arbace.go.escape$hole")

var Lit_549 *jrt.String = jrt.Intern("arbace.go.escape$heap_hole")

var Lit_550 *jrt.String = jrt.Intern("arbace.go.escape$mutator_hole")

var Lit_551 *jrt.String = jrt.Intern("arbace.go.escape$callee_hole")

var Lit_552 *jrt.String = jrt.Intern("arbace.go.escape$discard_hole")

var Lit_553 *jrt.String = jrt.Intern("arbace.go.escape$shift")

var Lit_554 *jrt.String = jrt.Intern("arbace.go.escape$k_deref")

var Lit_555 *jrt.String = jrt.Intern("arbace.go.escape$k_addr")

var Lit_556 *jrt.String = jrt.Intern("arbace.go.escape$dot_type")

var Lit_557 *jrt.String = jrt.Intern("arbace.go.escape$name_loc_QMARK_")

var Lit_558 *jrt.String = jrt.Intern("arbace.go.escape$new_loc")

var Lit_559 *jrt.String = jrt.Intern("arbace.go.escape$old_loc")

var Lit_560 *jrt.String = jrt.Intern("arbace.go.escape$flow")

var Lit_561 *jrt.String = jrt.Intern("arbace.go.escape$tee_hole")

var Lit_562 *jrt.String = jrt.Intern("arbace.go.escape$later")

var Lit_563 *jrt.String = jrt.Intern("arbace.go.escape$spill")

var Lit_564 *jrt.String = jrt.Intern("arbace.go.escape$fn_of_obj")

var Lit_565 *jrt.String = jrt.Intern("arbace.go.escape$fn_of_node")

var Lit_566 *jrt.String = jrt.Intern("arbace.go.escape$contains_closure_QMARK_")

var Lit_567 *jrt.String = jrt.Intern("arbace.go.escape$in_mutual_batch_QMARK_")

var Lit_568 *jrt.String = jrt.Intern("arbace.go.escape$node_type")

var Lit_569 *jrt.String = jrt.Intern("arbace.go.escape$const_QMARK_")

var Lit_570 *jrt.String = jrt.Intern("arbace.go.escape$field_steps")

var Lit_571 *jrt.String = jrt.Intern("arbace.go.escape$select_node")

var Lit_572 *jrt.String = jrt.Intern("arbace.go.escape$expand_field")

var Lit_573 *jrt.String = jrt.Intern("arbace.go.escape$method_recv")

var Lit_574 *jrt.String = jrt.Intern("arbace.go.escape$node_prec")

var Lit_575 *jrt.String = jrt.Intern("arbace.go.escape$const_str")

var Lit_576 *jrt.String = jrt.Intern("arbace.go.escape$args_str")

var Lit_577 *jrt.String = jrt.Intern("arbace.go.escape$builtin_str")

var Lit_578 *jrt.String = jrt.Intern("arbace.go.escape$fmt_node")

var Lit_579 *jrt.String = jrt.Intern("arbace.go.escape$with_line_STAR_")

var Lit_580 *jrt.String = jrt.Intern("arbace.go.escape$assign_heap")

var Lit_581 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,eyn1,nkn4,linekn6,columnkn4,fileyn2,nskn3,docyn1,kyn1,xkn3,tagyn4,longyn1,cyn2,ksyn1,fyn5,paramyn3,fnsyn9,param-idxyn7,nparamsyn1,vyn1,oyn4,valsyn4,dfltyn3,sigyn3,argyn4,pathyn4,treeyn1,lyn1,ryn3,dstyn3,srcyn4,dstsyn4,srcsyn3,rhsyn5,whereyn2,ssyn4,objsyn4,bodyyn1,byn3,cloyn5,otheryn4,sinkyn6,derefsyn4,rootyn7,walkgenyn7,enqueueyn4,lineyn2,nmyn3,escyn9,res-namesyn2,tyyn1,myn17,java.util.HashMapyn3,asgkn7,dynamickn8,declaredv16,arbace.go.escape6,mutatem10,R0,TR1,L1,V2,R2,R3,R4,i531,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,discardsm10,R0,TR1,L1,V2,R2,R7,R4,i532,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,conv-kindm12,R0,TR1,L1,V1,R3,R8,s169,The op gc's typecheck gives an explicit conversion (typecheck.tcConv): :str2bytes, :bytes2str\n  ... :iface (OCONVIFACE), :unsafe-from-uintptr, or :nop (OCONV, OCONVNOP).R4,i534,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape20,reflect-header-data?m12,R0,TR1,L1,V1,R3,R8,s125,ir.IsReflectHeaderDataField: n (a one-step selection) is the Data field of a\n  *reflect.SliceHeader or *reflect.StringHeader.R4,i555,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,unsafe-valuem12,R0,TR1,L1,V3,R2,R9,R3,R8,s84,escape.unsafeValue: k flows from a uintptr expression n converted to unsafe.Pointer.R4,i564,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape15,add-string-listm12,R0,TR1,L1,V1,R3,R8,s80,OADDSTR's operands: a string + chain flattened (typecheck's tcArith of strings).R4,i578,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,closure-exprm12,R0,TR1,L1,V3,R2,R9,R3,R8,s270,OCLOSURE: the literal's record spilled; a closure (a literal that captures a variable,\n  Func.IsClosure) walked here, in its enclosing function's batch, its captured variables marked;\n  a literal that captures none is a function of its own, analyzed in an earlier batch.R4,i585,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,method-valuem10,R0,TR1,L1,V3,R2,R9,R3,R4,i602,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape14,expr-skip-initm10,R0,TR1,L1,V3,R2,R9,R3,R4,i613,R5,i1,R6,s19,arbace/go/escape.aem12,R0,TR1,L1,V1,R10,R8,s61,A composite literal's element: its value (a keyed element's).R4,i687,R5,i1,R6,s19,arbace/go/escape.aem8,R1,L1,V3,R2,R9,R3,R4,i695,R5,i1,R6,s19,arbace/go/escape.aem8,R1,L1,V2,R2,R3,R4,i699,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,max-stackm10,R0,TR1,L1,MV0,m2,R11,R12,R4,i701,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,max-implicitm10,R0,TR1,L1,MV0,m2,R11,R12,R4,i702,R5,i1,R6,s19,arbace/go/escape.aem12,R0,TR1,L1,V1,R3,R8,s63,escape.HeapAllocReason: why node n must be on the heap, or nil.R4,i704,R5,i1,R6,s19,arbace/go/escape.aem12,R0,TR1,L1,V2,R2,R13,R8,s133,The temporaries of a multi-value call (OAS2FUNC into autotmps), made and the call walked\n  the first time one of its results is used.R4,i728,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,tag-holem12,R0,TR1,L1,V4,R2,R14,R15,R16,R8,s72,escape.tagHole: the hole for argument param (:recv or an index) of fn f.R4,i748,R5,i1,R6,s19,arbace/go/escape.aem10,R0,TR1,L1,V4,R2,R14,R15,R16,R4,i772,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape15,merged-tag-holem10,R0,TR1,L1,V5,R2,R14,R17,R18,R19,R4,i774,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,static-valuem12,R0,TR1,L1,V1,R3,R8,s156,ReassignOracle.StaticValue: n's value when n is a local variable defined once and never\n  reassigned (nor address taken), followed; OCONVNOP looked through.R4,i782,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape13,static-calleem12,R0,TR1,L1,V1,R20,R8,s140,ir.StaticCalleeName: the function a callee expression names: a package function, a method\n  expression's method, a function literal; or nil.R4,i796,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape16,func-assignmentsm12,R0,TR1,L1,V1,R21,R8,s124,ReassignOracle.FuncAssignments: the values of a func-typed local's assignments, or nil when one\n  is not a plain assignment.R4,i806,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape24,resolve-assigned-calleesm10,R0,TR1,L1,V1,R22,R4,i814,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,call-linem12,R0,TR1,L1,V2,R13,R23,R8,s108,A call's line as gc's (its Lparen's): after a function literal callee, the literal's closing\n  brace's line.R4,i828,R5,i1,R6,s19,arbace/go/escape.aem12,R0,TR1,L1,V2,R3,R24,R8,s142,typecheck.FixVariadicCall: a call's arguments with its variadic ones in an implicit slice\n  literal (\"... argument\"), nil when there are none.R4,i836,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,argumentm10,R0,TR1,L1,V3,R2,R9,R25,R4,i852,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,inl-callm12,R0,TR1,L1,V3,R2,R14,R3,R8,s85,OINLCALL: the inlined body's statements, then its result variables into the holes ks.R4,i854,R5,i1,R6,s19,arbace/go/escape.aem12,R0,TR1,L1,V3,R2,R14,R3,R8,s67,escape.call: ks the holes of the call's results (nil: a statement).R4,i862,R5,i1,R6,s19,arbace/go/escape.aem10,R0,TR1,L1,V3,R2,R14,R3,R4,i913,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape13,wrapper-visitm12,R0,TR1,L1,V2,R3,R26,R8,s135,normalizeGoDeferCall's visit: the arguments that need a temporary, as [path node] (paths into\n  the call node), the rest left in place.R4,i955,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,go-deferm10,R0,TR1,L1,V2,R2,R3,R4,i974,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape16,normal-go-defer?m10,R0,TR1,L1,V1,R13,R4,i1025,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape13,wrap-go-deferm12,R0,TR1,L1,V1,R3,R8,s89,Statement n (a go or defer) normalized: [temporaries' declaration or nil, the statement].R4,i1030,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape18,normalize-go-deferm12,R0,TR1,L1,V1,R27,R8,s65,The go and defer statements of a tree normalized (wrap-go-defer).R4,i1067,R5,i1,R6,s19,arbace/go/escape.aem12,R0,TR1,L1,V2,R2,R3,R8,s80,escape.addr: the hole for an assignment's destination (a place node, or :blank).R4,i1088,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,outer-namem12,R0,TR1,L1,V1,R3,R8,s111,ir.OuterValue then the name: the variable an expression's storage is of (x of x.f, x[i] of an\n  array), or nil.R4,i1113,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,norm-placem10,R0,TR1,L1,V1,R3,R4,i1124,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape15,same-safe-expr?m12,R0,TR1,L1,V2,R28,R29,R8,s16,ir.SameSafeExpr.R4,i1134,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape18,may-affect-memory?m10,R0,TR1,L1,V1,R3,R4,i1147,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape18,slice-self-assign?m10,R0,TR1,L1,V2,R30,R31,R4,i1163,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,self-assign?m10,R0,TR1,L1,V2,R30,R31,R4,i1180,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape15,fmt-stmt-assignm10,R0,TR1,L1,V2,R32,R33,R4,i1191,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape14,comma-ok-tempsm12,R0,TR1,L1,V2,R2,R34,R8,s282,typecheck's assignments of a comma-ok pair (v, ok = x.(T), m[k], <-c) to destinations of other\n  types: through an autotmp each (tmp, tmp2 = x.(T); v = tmp; ok = tmp2), the conversion of the\n  temporary in the value's place. The pair's values with the temporaries' assignments made.R4,i1194,R5,i1,R6,s19,arbace/go/escape.aem10,R1,L1,V4,R2,R32,R33,R35,R8,s143,escape.assignList: dsts (places, objects' holes given by addr-of) from srcs; where: the\n  statement, {:defn #{objs defined by it} :range bool}.R4,i1215,R5,i1,R6,s19,arbace/go/escape.aem10,R1,L1,V3,R2,R14,R35,R8,s18,escape.reassigned.R4,i1236,R5,i1,R6,s19,arbace/go/escape.aem8,R1,L1,V2,R2,R28,R4,i1247,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,dcl-obj!m10,R0,TR1,L1,V2,R2,R21,R4,i1251,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape5,blockm10,R0,TR1,L1,V2,R2,R36,R4,i1255,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape11,static-boolm12,R0,TR1,L1,V1,R13,R8,s60,noder's staticBool: +1, -1 for a constant condition, else 0.R4,i1260,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape11,terminates?m12,R0,TR1,L1,V1,R3,R8,s159,noder's terminates: a statement that ends normal control flow (return, goto, panic, an if\n  both of whose live branches do, a block whose last statement does).R4,i1267,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,live-stmtsm12,R0,TR1,L1,V1,R36,R8,s106,noder's stmts: the statements after a terminating one (and after the list's last label) are\n  not written.R4,i1281,R5,i1,R6,s19,arbace/go/escape.aem8,R1,L1,V2,R2,R36,R4,i1295,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,decl-stmtm12,R0,TR1,L1,V2,R2,R3,R8,s94,A :decl (x := v, var x T = v, var x T): gc's ODCLs, then its OAS or OAS2 (each object's Defn).R4,i1301,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape11,loop-leakedm12,R0,TR1,L1,V2,R37,R38,R8,s181,loopvar.ForCapture's possiblyLeaked: the loop variables objs captured by a function literal or\n  whose address is taken in body (outside a return statement of the loop's own depth).R4,i1318,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,range-stmtm10,R0,TR1,L1,V2,R2,R3,R4,i1347,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,for-stmtm10,R0,TR1,L1,V2,R2,R3,R4,i1381,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape16,type-switch-stmtm10,R0,TR1,L1,V2,R2,R3,R4,i1414,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape11,assign-stmtm10,R0,TR1,L1,V2,R2,R3,R4,i1431,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape11,return-stmtm10,R0,TR1,L1,V2,R2,R3,R4,i1442,R5,i1,R6,s19,arbace/go/escape.aem8,R1,L1,V2,R2,R3,R4,i1454,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,label-statesm12,R0,TR1,L1,V1,R38,R8,s86,walkFunc's labels: a label is :looping when a goto to it follows it, else :nonlooping.R4,i1505,R5,i1,R6,s19,arbace/go/escape.aem8,R1,L1,V2,R39,R15,R4,i1521,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,flow-closurem12,R0,TR1,L1,V3,R39,R9,R40,R8,s152,batch.flowClosure: closure clo's captured variables flow into its record, by value (<= 128\n  bytes, never reassigned nor address taken) or by reference.R4,i1528,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,init-func!m10,R0,TR1,L1,V2,R39,R15,R4,i1544,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,outlives?m12,R0,TR1,L1,V3,R39,R28,R41,R8,s50,batch.outlives: whether location l outlives other.R4,i1553,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,leak-to!m12,R0,TR1,L1,V3,R28,R42,R43,R8,s16,location.leakTo.R4,i1567,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,walk-one!m10,R0,TR1,L1,V4,R39,R44,R45,R46,R4,i1576,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,walk-all!m10,R0,TR1,L1,V1,R39,R4,i1628,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape13,report-leaks!m10,R0,TR1,L1,V4,R47,R48,R49,R50,R4,i1651,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,param-tagm12,R0,TR1,L1,V4,R39,R15,R21,R51,R8,s78,batch.paramTag: the tag of f's parameter o (its type ty), reporting its leaks.R4,i1675,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape7,finish!m10,R0,TR1,L1,V2,R39,R17,R4,i1703,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,literal-ofm12,R0,TR1,L1,V1,R3,R8,s73,A node's static value when it is a constant: the constant node, else nil.R4,i1732,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape22,rewrite-with-literals!m12,R0,TR1,L1,V1,R28,R8,s260,batch.rewriteWithLiterals: a make's non-constant size whose static value is a constant (or\n  the len of a slice literal), an interface conversion's operand whose static value is one,\n  replaced by the literal (in the location's node, which the messages print).R4,i1738,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape6,batch!m10,R0,TR1,L1,V1,R17,R4,i1767,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape15,method-obj-datam10,R0,TR1,L1,V1,R52,R4,i1799,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape17,iface-assignmentsm12,R0,TR1,L1,V1,R27,R8,s190,devirtualize.State.analyze over a function's tree: for each local variable of interface type,\n  its assignments: a node (its value), a type (a concrete value of that type), or nil (unknown).R4,i1804,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape13,concrete-typem12,R0,TR1,L1,V2,Myn3,asgm2,R11,R53,R3,R8,s76,devirtualize.concreteType: the one concrete type n's value can have, or nil.R4,i1872,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape11,devirt-callm12,R0,TR1,L1,V2,R54,R13,R8,s180,StaticCall of interface call c (its operands already devirtualized), asg the function's\n  interface assignments: c as a method call of its receiver's concrete type, reported, or c.R4,i1911,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,devirtualizem12,R0,TR1,L1,V1,R27,R8,s188,A function's tree with its devirtualizable interface calls made method calls (StaticCall),\n  each reported: devirtualizing x.M to T (partially, when T's method is an embedded interface's).R4,i1944,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape15,small-int-constm10,R0,TR1,L1,V1,R3,R4,i1975,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,bounded?m12,R0,TR1,L1,V2,R3,Myn2,mxm2,R11,R12,R8,s58,walk.bounded: whether integer expression n is in [0, max).R4,i1979,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,bce-walk!m12,R0,TR1,L1,V1,R38,R8,s83,The index expressions of a function's live code, each elided bounds check reported.R4,i2018,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,*inline*m10,R55,TR4,i2050,R5,i1,R6,s19,arbace/go/escape.aeR8,s42,Whether gc's inliner runs (gc without -l).v16,arbace.go.escape17,inline-max-budgetl80,m8,R0,TR4,i2054,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape22,inline-extra-call-costl57,m8,R0,TR4,i2055,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape22,inline-param-call-costl17,m8,R0,TR4,i2056,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape31,inline-closure-called-once-costl800,m8,R0,TR4,i2057,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape20,static-inlined-call?m8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,inl-calleem8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape11,can-inline!m8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,try-inlinem8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,field-offsetm8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,max-costm8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape7,all-fnsm8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape8,scan-fn!m8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape13,closure-vars!m8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,foreign-bodym8,R56,TR4,i2059,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape9,conv-nop?m12,R0,TR1,L1,V1,R3,R8,s86,typecheck's convertOp: whether a conversion is OCONVNOP (costs nothing in the budget).R4,i2061,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape12,param-local?m12,R0,TR1,L1,V1,R3,R8,s88,An ONAME of class PPARAM (or a closure variable of the enclosing function's: PAUTOHEAP).R4,i2078,R5,i1,R6,s19,arbace/go/escape.aev16,arbace.go.escape10,intrinsicsm20,s23,internal/runtime/atomicS47,s3,Or8s3,Ands10,Storeint64s5,Stores4,And8s5,Loadps4,Xadds5,Xchg8s3,Cass4,Xchgs10,StorepNoWBs14,LoadAcquintptrs4,Or32s11,Xchguintptrs10,StoreRel64s11,Xadduintptrs8,Casint64s10,Casuintptrs10,Storeint32s6,Xchg64s5,Casp1s7,Store64s9,Loadint32s6,Load64s7,LoadAcqs9,Xchgint32s2,Ors9,Xchgint64s8,Loaduints6,Xadd64s5,And64s12,Storeuintptrs4,Loads5,And32s11,Loaduintptrs5,Cas64s4,Or64s9,Xaddint64s6,Store8s15,StoreReluintptrs5,Load8s6,CasRels9,Xaddint32s8,StoreRels9,Loadint64s8,Casint32s9,LoadAcq64s20,internal/runtime/sysS13,s11,GetCallerPCs7,Bswap32s15,TrailingZeros64s11,OnesCount64s11,GetCallerSPs8,Prefetchs4,Len8s5,Len64s14,TrailingZeros8s7,Bswap64s15,TrailingZeros32s13,GetClosurePtrs16,PrefetchStreameds7,runtimeS2,s9,KeepAlives20,slicebytetostringtmps11,sync/atomicS36,s9,SwapInt64s9,SwapInt32s11,StoreUint32s8,AddInt64s19,CompareAndSwapInt32s9,AndUint32s11,StoreUint64s10,AndUintptrs12,StoreUintptrs9,AddUint64s21,CompareAndSwapUintptrs10,StoreInt64s8,AndInt64s11,LoadUintptrs8,AddInt32s8,OrUint32s10,LoadUint64s9,AddUint32s9,AndUint64s7,OrInt32s9,OrUintptrs8,OrUint64s11,SwapUintptrs20,CompareAndSwapUint64s11,LoadPointers9,LoadInt32s9,LoadInt64s10,StoreInt32s10,SwapUint64s8,AndInt32s10,SwapUint32s20,CompareAndSwapUint32s19,CompareAndSwapInt64s10,LoadUint32s7,OrInt64s10,AddUintptrs4,mathS6,s3,FMAs4,Ceils5,Truncs11,RoundToEvens4,sqrts5,Floors21,internal/runtime/mathS2,s5,Add64s10,MulUintptrs28,crypto/internal/constanttimeS2,s6,Selects11,boolToUint8s8,math/bigS1,s5,mulWWs21,internal/runtime/mapsS8,s19,ctrlGroupMatchEmptys17,bitsetRemoveBelows18,ctrlGroupMatchFulls28,ctrlGroupMatchEmptyOrDeleteds11,bitsetFirsts15,bitsetLowestSets20,bitsetShiftOutLowests16,ctrlGroupMatchH2s9,math/bitsS28,s3,Muls12,RotateLeft16s9,OnesCounts12,RotateLeft32s3,Divs5,Mul64s15,TrailingZeros64s3,Subs11,OnesCount64s3,Lens4,Len8s5,Sub64s11,OnesCount32s11,RotateLeft8s5,Len16s3,Adds5,Len64s14,TrailingZeros8s15,TrailingZeros16s11,OnesCount16s12,RotateLeft64s10,RotateLefts14,ReverseBytes32s5,Add64s5,Len32s15,TrailingZeros32s5,Div64s14,ReverseBytes64m10,R0,TR4,i2083,R5,i1,R6,s19,arbace/go/escape.aeR8,s250,ssagen's intrinsics for amd64 (ssagen/intrinsics.go's initIntrinsics, go1.27.1: its add, addF and\n  alias entries that apply to amd64): calls the back end replaces by instructions, which the\n  inliner's budget counts as one node (ir.IsIntrinsicCall).")

var Lit_582 *jrt.String = jrt.Intern("arbace.go.escape$mutate")

var Lit_583 *jrt.String = jrt.Intern("arbace.go.escape$discards")

var Lit_584 *jrt.String = jrt.Intern("arbace.go.escape$conv_kind")

var Lit_585 *jrt.String = jrt.Intern("arbace.go.escape$reflect_header_data_QMARK_")

var Lit_586 *jrt.String = jrt.Intern("arbace.go.escape$unsafe_value")

var Lit_587 *jrt.String = jrt.Intern("arbace.go.escape$add_string_list")

var Lit_588 *jrt.String = jrt.Intern("arbace.go.escape$closure_expr")

var Lit_589 *jrt.String = jrt.Intern("arbace.go.escape$method_value")

var Lit_590 *jrt.String = jrt.Intern("arbace.go.escape$expr_skip_init")

var Lit_591 *jrt.String = jrt.Intern("arbace.go.escape$elt_value")

var Lit_592 *jrt.String = jrt.Intern("arbace.go.escape$expr")

var Lit_593 *jrt.String = jrt.Intern("arbace.go.escape$discard")

var Lit_594 *jrt.String = jrt.Intern("arbace.go.escape$max_stack")

var Lit_595 *jrt.String = jrt.Intern("arbace.go.escape$max_implicit")

var Lit_596 *jrt.String = jrt.Intern("arbace.go.escape$heap_alloc_reason")

var Lit_597 *jrt.String = jrt.Intern("arbace.go.escape$call_temps")

var Lit_598 *jrt.String = jrt.Intern("arbace.go.escape$tag_hole")

var Lit_599 *jrt.String = jrt.Intern("arbace.go.escape$call_tag_hole")

var Lit_600 *jrt.String = jrt.Intern("arbace.go.escape$merged_tag_hole")

var Lit_601 *jrt.String = jrt.Intern("arbace.go.escape$static_value")

var Lit_602 *jrt.String = jrt.Intern("arbace.go.escape$static_callee")

var Lit_603 *jrt.String = jrt.Intern("arbace.go.escape$func_assignments")

var Lit_604 *jrt.String = jrt.Intern("arbace.go.escape$resolve_assigned_callees")

var Lit_605 *jrt.String = jrt.Intern("arbace.go.escape$call_line")

var Lit_606 *jrt.String = jrt.Intern("arbace.go.escape$variadic_args")

var Lit_607 *jrt.String = jrt.Intern("arbace.go.escape$argument")

var Lit_608 *jrt.String = jrt.Intern("arbace.go.escape$inl_call")

var Lit_609 *jrt.String = jrt.Intern("arbace.go.escape$call")

var Lit_610 *jrt.String = jrt.Intern("arbace.go.escape$builtin_call")

var Lit_611 *jrt.String = jrt.Intern("arbace.go.escape$wrapper_visit")

var Lit_612 *jrt.String = jrt.Intern("arbace.go.escape$go_defer")

var Lit_613 *jrt.String = jrt.Intern("arbace.go.escape$normal_go_defer_QMARK_")

var Lit_614 *jrt.String = jrt.Intern("arbace.go.escape$wrap_go_defer")

var Lit_615 *jrt.String = jrt.Intern("arbace.go.escape$normalize_go_defer")

var Lit_616 *jrt.String = jrt.Intern("arbace.go.escape$addr_of")

var Lit_617 *jrt.String = jrt.Intern("arbace.go.escape$outer_name")

var Lit_618 *jrt.String = jrt.Intern("arbace.go.escape$norm_place")

var Lit_619 *jrt.String = jrt.Intern("arbace.go.escape$same_safe_expr_QMARK_")

var Lit_620 *jrt.String = jrt.Intern("arbace.go.escape$may_affect_memory_QMARK_")

var Lit_621 *jrt.String = jrt.Intern("arbace.go.escape$slice_self_assign_QMARK_")

var Lit_622 *jrt.String = jrt.Intern("arbace.go.escape$self_assign_QMARK_")

var Lit_623 *jrt.String = jrt.Intern("arbace.go.escape$fmt_stmt_assign")

var Lit_624 *jrt.String = jrt.Intern("arbace.go.escape$comma_ok_temps")

var Lit_625 *jrt.String = jrt.Intern("arbace.go.escape$assign_list")

var Lit_626 *jrt.String = jrt.Intern("arbace.go.escape$reassigned_BANG_")

var Lit_627 *jrt.String = jrt.Intern("arbace.go.escape$dcl_BANG_")

var Lit_628 *jrt.String = jrt.Intern("arbace.go.escape$dcl_obj_BANG_")

var Lit_629 *jrt.String = jrt.Intern("arbace.go.escape$block")

var Lit_630 *jrt.String = jrt.Intern("arbace.go.escape$static_bool")

var Lit_631 *jrt.String = jrt.Intern("arbace.go.escape$terminates_QMARK_")

var Lit_632 *jrt.String = jrt.Intern("arbace.go.escape$live_stmts")

var Lit_633 *jrt.String = jrt.Intern("arbace.go.escape$stmts")

var Lit_634 *jrt.String = jrt.Intern("arbace.go.escape$decl_stmt")

var Lit_635 *jrt.String = jrt.Intern("arbace.go.escape$loop_leaked")

var Lit_636 *jrt.String = jrt.Intern("arbace.go.escape$range_stmt")

var Lit_637 *jrt.String = jrt.Intern("arbace.go.escape$for_stmt")

var Lit_638 *jrt.String = jrt.Intern("arbace.go.escape$type_switch_stmt")

var Lit_639 *jrt.String = jrt.Intern("arbace.go.escape$assign_stmt")

var Lit_640 *jrt.String = jrt.Intern("arbace.go.escape$return_stmt")

var Lit_641 *jrt.String = jrt.Intern("arbace.go.escape$stmt")

var Lit_642 *jrt.String = jrt.Intern("arbace.go.escape$label_states")

var Lit_643 *jrt.String = jrt.Intern("arbace.go.escape$walk_func_BANG_")

var Lit_644 *jrt.String = jrt.Intern("arbace.go.escape$flow_closure")

var Lit_645 *jrt.String = jrt.Intern("arbace.go.escape$init_func_BANG_")

var Lit_646 *jrt.String = jrt.Intern("arbace.go.escape$outlives_QMARK_")

var Lit_647 *jrt.String = jrt.Intern("arbace.go.escape$leak_to_BANG_")

var Lit_648 *jrt.String = jrt.Intern("arbace.go.escape$walk_one_BANG_")

var Lit_649 *jrt.String = jrt.Intern("arbace.go.escape$walk_all_BANG_")

var Lit_650 *jrt.String = jrt.Intern("arbace.go.escape$report_leaks_BANG_")

var Lit_651 *jrt.String = jrt.Intern("arbace.go.escape$param_tag")

var Lit_652 *jrt.String = jrt.Intern("arbace.go.escape$finish_BANG_")

var Lit_653 *jrt.String = jrt.Intern("arbace.go.escape$literal_of")

var Lit_654 *jrt.String = jrt.Intern("arbace.go.escape$rewrite_with_literals_BANG_")

var Lit_655 *jrt.String = jrt.Intern("arbace.go.escape$batch_BANG_")

var Lit_656 *jrt.String = jrt.Intern("arbace.go.escape$method_obj_data")

var Lit_657 *jrt.String = jrt.Intern("arbace.go.escape$iface_assignments")

var Lit_658 *jrt.String = jrt.Intern("arbace.go.escape$concrete_type")

var Lit_659 *jrt.String = jrt.Intern("arbace.go.escape$devirt_call")

var Lit_660 *jrt.String = jrt.Intern("arbace.go.escape$devirtualize")

var Lit_661 *jrt.String = jrt.Intern("arbace.go.escape$small_int_const")

var Lit_662 *jrt.String = jrt.Intern("arbace.go.escape$bounded_QMARK_")

var Lit_663 *jrt.String = jrt.Intern("arbace.go.escape$bce_walk_BANG_")

var Lit_664 *jrt.String = jrt.Intern("arbace.go.escape$conv_nop_QMARK_")

var Lit_665 *jrt.String = jrt.Intern("arbace.go.escape$param_local_QMARK_")

var Lit_666 *jrt.String = jrt.Intern("kn7,privatekn4,linekn6,columnkn4,filekn3,dockn8,arglistsyn1,fyn2,tyyn5,derefyn2,nmkn7,dynamicyn6,calleeyn11,called-onceyn1,ckn8,declaredyn2,ssyn1,nyn6,calleryn4,bodykn3,tagyn17,java.util.HashMapyn4,lineyn9,lit-namesyn5,declsyn4,qualyn1,xyn2,rvyn5,chainyn1,oyn4,objsyn2,styn4,treeyn3,fnsyn1,ayn1,byn1,dyn1,ryn4,pathyn12,java.io.Fileyn7,versionyn5,pathsyn1,mv16,arbace.go.escape11,cheap-callsv11,arbace.core3,setS1,s8,NoEscapem10,R0,TR1,i2098,R2,i1,R3,s19,arbace/go/escape.aeR4,s71,hairyVisitor's cheap calls (amd64: CanMergeLoads): counted as one node.v16,arbace.go.escape11,fn-pkg-namem12,R0,TR5,L1,V1,R6,R4,s52,A function record's package path and its name in it.R1,i2108,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape11,cheap-call?m10,R0,TR5,L1,V1,R6,R1,i2115,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,intrinsic?m10,R0,TR5,L1,V1,R6,R1,i2120,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,hairy-costm12,R0,TR5,L1,V1,R6,R4,s156,hairyVisitor over function f's body: [cost reason], gc's IR nodes counted as the unified IR\n  reader and typecheck build them from the checked tree's forms.R1,i2126,R2,i1,R3,s19,arbace/go/escape.aem12,R0,TR5,L1,V3,R7,R8,R9,R4,s72,The offset of field nm of struct type ty (through a pointer when deref).R1,i2255,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape12,*big-caller*m10,R10,TR1,i2266,R2,i1,R3,s19,arbace/go/escape.aeR4,s106,Whether the function whose calls are being inlined is big (IsBigFunc): its inlinees' maximum\n  cost is 20.m12,R0,TR5,L1,V2,R11,R12,R4,s62,inlineCostOK's maximum cost of a callee (a closure's doubled).R1,i2271,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,call-str2m12,R0,TR5,L1,V1,R13,R4,s124,A call as gc prints it after typecheck (-m=2's bodies): a method call as its method expression's\n  call, the receiver first.R1,i2278,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape8,stmt-strm8,R14,TR1,i2292,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,stmts-strm10,R0,TR5,L1,V1,R15,R1,i2294,R2,i1,R3,s19,arbace/go/escape.aem12,R0,TR5,L1,V1,R16,R4,s66,ir/fmt.go's stmtFmt (its short forms: for loop, switch statement).R1,i2297,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,big-func?m12,R0,TR5,L1,V1,R6,R4,s113,IsBigFunc: whether function f has more than 5,000 IR nodes (counted as the budget counts them,\n  every node one).R1,i2323,R2,i1,R3,s19,arbace/go/escape.aem12,R0,TR5,L1,V1,R6,R4,s89,CanInline: function f's inlining record {:cost n}, or nil (with its reason); its message.R1,i2336,R2,i1,R3,s19,arbace/go/escape.aem12,R0,TR5,L1,V2,R17,R13,R4,s168,inlCallee: the function call c of caller calls, when gc can inline it (a package function, a\n  method expression of the receiver's own type, a literal of the caller's).R1,i2374,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,copy-bodym12,R0,TR5,L1,V6,R18,Myn2,omm2,R19,R20,R21,R22,R23,R24,R4,s279,The callee's body copied for an inlined call at line: its variables (in om, extended with a\n  fresh copy of each the body declares) renamed, every node at the call's line (gc reports the\n  inlined code at its outermost position), its literals fresh nodes (named as the callee's).R1,i2395,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape16,register-copies!m12,R0,TR5,L1,V2,R17,R18,R4,s136,Records for the literals of an inlined body (copies of the callee's), scanned, so that their\n  calls in the copy can be inlined in turn.R1,i2430,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape16,returns->assignsm12,R0,TR5,L1,V2,R25,R26,R4,s150,The inlined body's return statements as assignments to the result variables rv (their goto to\n  the end left out: the analysis is not flow sensitive).R1,i2451,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape12,inline-callsm12,R0,TR5,L1,V3,R17,R25,R27,R4,s303,The interleaved inliner over a tree of function caller: each call gc inlines replaced by its\n  inlined body ({:op :inlcall}), reported (inlining call to f), the inlined bodies' own calls\n  inlined in turn (chain: the functions being inlined, gc's inlining tree: no function inlined\n  into its own copy).R1,i2473,R2,i1,R3,s19,arbace/go/escape.aem10,R0,TR5,L1,V3,R17,R13,R27,R1,i2522,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,bloop-tmpsv11,arbace.core4,atoml0,m8,R0,TR1,i2585,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,bloop-tmpm10,R0,TR5,L1,V2,R7,R21,R1,i2587,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,bloop-namem12,R0,TR5,L1,V1,R16,R4,s90,getNameFromNode: the variable at the root of n's selections, slices, conversions, indexes.R1,i2590,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape16,addressable-namem12,R0,TR5,L1,V1,R16,R4,s94,getAddressableNameFromNode: that variable when it is addressable (a local or global variable).R1,i2601,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,bloop-keptm10,R0,TR5,L1,V2,R21,R28,R1,i2607,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape16,keep-alive-callsm12,R0,TR5,L1,V2,R29,R21,R4,s98,keepAliveAt: runtime.KeepAlive(unsafe.Pointer(&v)) for each variable (the call IsCompilerVarLive).R1,i2611,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape16,keep-alive-nodesm12,R0,TR5,L1,V2,R21,R16,R4,s49,getKeepAliveNodes of an assignment's destination.R1,i2620,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape13,preserve-stmtm10,R0,TR5,L1,V1,R30,R1,i2629,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape14,preserve-stmtsm10,R0,TR5,L1,V1,R15,R1,i2680,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape7,b-loop?m10,R0,TR5,L1,V1,R16,R1,i2682,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,bloop-walkm10,R5,L1,V1,R31,R4,s34,bloop.Walk over a function's tree.R1,i2689,R2,i1,R3,s19,arbace/go/escape.aem10,R5,L1,V1,R6,R4,s266,Walks function f's body (not the bodies of its literals, which are scanned as functions of\n  their own): its declared variables (its Dcl), its function literals, the variables it refers\n  to (for the closure variables), the single definitions (the ReassignOracle's).R1,i2721,R2,i1,R3,s19,arbace/go/escape.aem10,R5,L1,V1,R6,R4,s162,A function literal's closure variables: the variables it (or a literal nested in it) refers to\n  that an enclosing function declares, in order of first reference.R1,i2807,R2,i1,R3,s19,arbace/go/escape.aem8,R5,L1,V1,R6,R1,i2825,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,bottom-upm12,R0,TR5,L1,V1,R32,R4,s159,ir.VisitFuncsBottomUp: the package functions in batches, each a strongly connected component\n  of the call graph (a function with its literals), callees first.R1,i2827,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape11,method-basem12,R0,TR5,L1,V1,R28,R4,s42,A method object's receiver base type name.R1,i2872,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape12,static-init?m12,R0,TR5,L1,V1,R16,R4,s121,staticinit's StaticAssign, approximately: an initializer gc makes static data (no code in the\n  package's init function).R1,i2882,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape13,dynamic-partsm12,R0,TR5,L1,V1,R16,R4,s226,staticinit.StaticAssign of an initializer: nil when the whole of it is code; else the parts\n  that are (a static composite literal's entries that are not static data), each assigned into\n  the static data by the init function.R1,i2901,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,const-eq?m10,R0,TR5,L1,V2,R33,R34,R1,i2916,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape14,prune-switchesm12,R0,TR5,L1,V1,R31,R4,s169,noder's writer: a switch whose tag (or true, without one) and cases are constants keeps only\n  the clause that matches (none when none does; not one that falls through).R1,i2922,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape7,fn-namem12,R0,TR5,L1,V2,R35,R28,R4,s59,ir.FuncName: a function's name, a method's (T).m or (*T).m.R1,i2950,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,base-typem12,R0,TR5,L1,V2,R36,R16,R4,s46,The type named n in checked package r's scope.R1,i2958,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape13,*import-root*m10,R10,TR1,i2965,R2,i1,R3,s19,arbace/go/escape.aeR4,s328,The forms root other packages' forms are read from for their parameter tags (gc reads them\n  from their export data, written when it compiled them): repr/go's forms of the standard\n  library for the configuration (bin/goi: the corpus linux-amd64), or nil: a call of another\n  package's function is a call of an unknown function.v16,arbace.go.escape11,*tag-cache*m10,R10,TR1,i2972,R2,i1,R3,s19,arbace/go/escape.aeR4,s150,A directory the packages' tags are kept in between runs ({name tags} per package, keyed by\n  the package's forms and this namespace's source), or nil.v16,arbace.go.escape11,tag-versionm10,R0,TR1,i2977,R2,i1,R3,s19,arbace/go/escape.aeR4,s82,The version of the tags' analysis, in the cache's keys: changed with the analysis.v16,arbace.go.escape8,pkg-tagsm10,R0,TR1,i2981,R2,i1,R3,s19,arbace/go/escape.aeR4,s89,The other packages' tags analyzed in this process: path -> {function name -> its record}.v16,arbace.go.escape15,analyze-packagem8,R14,TR1,i2985,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape8,std-sessm8,R0,TR1,i2987,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,std-resultm10,R5,L1,V1,R37,R4,s144,The checked result of standard package path, with its trees, from *import-root*'s forms (a\n  session of the process: each package checked once).R1,i2989,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape9,*phase-a*m10,R10,TR1,i3014,R2,i1,R3,s19,arbace/go/escape.aeR4,s135,When true, analyze-package returns the functions' records once scanned (their bodies for\n  inlining), before inlining and the analysis.v16,arbace.go.escape12,*pkg-bodies*m10,R10,TR1,i3019,R2,i1,R3,s19,arbace/go/escape.aeR4,s192,Other packages' functions' records with their bodies (for inlining their calls): an atom, path\n  -> {name f}; one for the analysis of each package (dropped when its tags are made, for memory).m10,R5,L1,V1,R6,R4,s70,Another package's function f (a foreign record) with its body, or nil.R1,i3024,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape12,*std-inline*m10,R10,TR1,i3043,R2,i1,R3,s19,arbace/go/escape.aeR4,s250,Whether another package's tags are made with gc's inliner on (as gc compiles the standard\n  library): the per-package warm-up's (one package a process: its imports' tags already kept),\n  else without it (a run that finds no tags made by the warm-up).v16,arbace.go.escape12,forms-digestm10,R0,TR5,L1,V3,Myn3,dirm2,R19,R38,Myn2,pfm2,R19,R38,R39,R1,i3049,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape17,load-package-tagsm12,R0,TR5,L1,V1,R37,R4,s165,Package path's functions' tags, from its forms under *import-root*: {name {:tags :sig ...}},\n  or {} when its forms are missing or goi's checker does not check them.R1,i3058,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape11,std-importsm10,R5,L1,V1,R37,R4,s84,The import paths of standard package path's forms (its files for the configuration).R1,i3112,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape10,warm-orderm10,R5,L1,V1,R40,R4,s132,The packages paths import, transitively, theirs first (each after its imports), whose tags\n  made with the inliner are not kept yet.R1,i3124,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape13,warm-package!m10,R5,L1,V1,R37,R4,s84,The tags of package path made with the inliner and kept (the warm-up's one package).R1,i3145,R2,i1,R3,s19,arbace/go/escape.aem12,R0,TR5,L1,V1,R28,R4,s72,The record of another package's function or method o (its tags), or nil.R1,i3151,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape7,analyzem10,R5,L1,V2,R36,R41,R4,s147,gc's escape analysis of a checked package (check-package's result r, with its trees): the\n  -m lines, [file line message] sorted. m: gc's -m level.R1,i3171,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape15,static-inlined?m10,R0,TR5,L1,V1,R25,R1,i3180,R2,i1,R3,s19,arbace/go/escape.aem12,R0,TR5,L1,V1,R30,R4,s215,staticinit over an inlined call in an initializer: its callee returns one expression static but\n  for its parameters, its arguments static (decided when it is inlined: the callee's nodes are not\n  kept in the tree).R1,i3182,R2,i1,R3,s19,arbace/go/escape.aev16,arbace.go.escape15,inline-package!m12,R0,TR5,L1,V1,R32,R4,s258,CanInline over the package's functions and literals, then their bodies with the calls gc\n  inlines inlined; the package scanned again over the new bodies (the literals inlined away\n  that capture nothing stay functions of their own): the top-level functions.R1,i3203,R2,i1,R3,s19,arbace/go/escape.aem10,R5,L1,V1,R36,R4,s103,The escape analysis of checked package r: its functions' records, their tags; the messages\n  in *msgs*.R1,i3257,R2,i1,R3,s19,arbace/go/escape.ae")

var Lit_667 *jrt.String = jrt.Intern("encoding/binary")

var Lit_668 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001203")

var Lit_669 *jrt.String = jrt.Intern("internal/byteorder")

var Lit_670 *jrt.String = jrt.Intern("arbace.go.escape$fn__1896001221")

var Lit_671 *jrt.String = jrt.Intern("arbace.go.escape$fn_pkg_name")

var Lit_672 *jrt.String = jrt.Intern("arbace.go.escape$cheap_call_QMARK_")

var Lit_673 *jrt.String = jrt.Intern("arbace.go.escape$intrinsic_QMARK_")

var Lit_674 *jrt.String = jrt.Intern("arbace.go.escape$hairy_cost")

var Lit_675 *jrt.String = jrt.Intern("arbace.go.escape$field_offset")

var Lit_676 *jrt.String = jrt.Intern("arbace.go.escape$max_cost")

var Lit_677 *jrt.String = jrt.Intern("arbace.go.escape$call_str2")

var Lit_678 *jrt.String = jrt.Intern("arbace.go.escape$stmts_str")

var Lit_679 *jrt.String = jrt.Intern("arbace.go.escape$stmt_str")

var Lit_680 *jrt.String = jrt.Intern("arbace.go.escape$big_func_QMARK_")

var Lit_681 *jrt.String = jrt.Intern("arbace.go.escape$can_inline_BANG_")

var Lit_682 *jrt.String = jrt.Intern("arbace.go.escape$inl_callee")

var Lit_683 *jrt.String = jrt.Intern("arbace.go.escape$copy_body")

var Lit_684 *jrt.String = jrt.Intern("arbace.go.escape$register_copies_BANG_")

var Lit_685 *jrt.String = jrt.Intern("arbace.go.escape$returns__GT_assigns")

var Lit_686 *jrt.String = jrt.Intern("arbace.go.escape$inline_calls")

var Lit_687 *jrt.String = jrt.Intern("arbace.go.escape$try_inline")

var Lit_688 *jrt.String = jrt.Intern("arbace.go.escape$bloop_tmp")

var Lit_689 *jrt.String = jrt.Intern("arbace.go.escape$bloop_name")

var Lit_690 *jrt.String = jrt.Intern("arbace.go.escape$addressable_name")

var Lit_691 *jrt.String = jrt.Intern("arbace.go.escape$bloop_kept")

var Lit_692 *jrt.String = jrt.Intern("arbace.go.escape$keep_alive_calls")

var Lit_693 *jrt.String = jrt.Intern("arbace.go.escape$keep_alive_nodes")

var Lit_694 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmt")

var Lit_695 *jrt.String = jrt.Intern("arbace.go.escape$preserve_stmts")

var Lit_696 *jrt.String = jrt.Intern("arbace.go.escape$b_loop_QMARK_")

var Lit_697 *jrt.String = jrt.Intern("arbace.go.escape$bloop_walk")

var Lit_698 *jrt.String = jrt.Intern("arbace.go.escape$scan_fn_BANG_")

var Lit_699 *jrt.String = jrt.Intern("arbace.go.escape$closure_vars_BANG_")

var Lit_700 *jrt.String = jrt.Intern("arbace.go.escape$all_fns")

var Lit_701 *jrt.String = jrt.Intern("arbace.go.escape$bottom_up")

var Lit_702 *jrt.String = jrt.Intern("arbace.go.escape$method_base")

var Lit_703 *jrt.String = jrt.Intern("arbace.go.escape$static_init_QMARK_")

var Lit_704 *jrt.String = jrt.Intern("arbace.go.escape$dynamic_parts")

var Lit_705 *jrt.String = jrt.Intern("arbace.go.escape$const_eq_QMARK_")

var Lit_706 *jrt.String = jrt.Intern("arbace.go.escape$prune_switches")

var Lit_707 *jrt.String = jrt.Intern("arbace.go.escape$fn_name")

var Lit_708 *jrt.String = jrt.Intern("arbace.go.escape$base_type")

var Lit_709 *jrt.String = jrt.Intern("escape-8")

var Lit_710 *jrt.String = jrt.Intern("arbace.go.escape$std_result")

var Lit_711 *jrt.String = jrt.Intern("arbace.go.escape$foreign_body")

var Lit_712 *jrt.String = jrt.Intern("arbace.go.escape$forms_digest")

var Lit_713 *jrt.String = jrt.Intern("arbace.go.escape$load_package_tags")

var Lit_714 *jrt.String = jrt.Intern("arbace.go.escape$std_imports")

var Lit_715 *jrt.String = jrt.Intern("arbace.go.escape$warm_order")

var Lit_716 *jrt.String = jrt.Intern("arbace.go.escape$warm_package_BANG_")

var Lit_717 *jrt.String = jrt.Intern("arbace.go.escape$foreign_fn")

var Lit_718 *jrt.String = jrt.Intern("arbace.go.escape$analyze")

var Lit_719 *jrt.String = jrt.Intern("arbace.go.escape$static_inlined_QMARK_")

var Lit_720 *jrt.String = jrt.Intern("arbace.go.escape$static_inlined_call_QMARK_")

var Lit_721 *jrt.String = jrt.Intern("arbace.go.escape$inline_package_BANG_")

var Lit_722 *jrt.String = jrt.Intern("arbace.go.escape$analyze_package")
