//line aot_arbace_go_escape__init.ae:1
package aot_arbace_go_escape

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_go_escape__init_A_Load__O() any { jrt.StartCheck(); A_arbace_go_escape__init_part0_A_Init__O(); A_arbace_go_escape__init_part1_A_Init__O(); A_arbace_go_escape__init_part2_A_Init__O(); A_arbace_go_escape__init_part0_A_Load__O(); A_arbace_go_escape__init_part1_A_Load__O(); A_arbace_go_escape__init_part2_A_Load__O(); return nil }

func A_arbace_go_escape__init_part0_A_Unit0__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(7, 1); return lang.IFn_Cast(A_arbace_go_escape__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_escape__init_part0_A_const_1) }
//line :7:1
func A_arbace_go_escape__init_part0_A_Unit1__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(7, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_escape__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_2)) }
//line :7:1
func A_arbace_go_escape__init_part0_A_Unit2__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(7, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_escape_eval1896000004_loading__1927001464__auto____1896000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_escape_eval1896000004_loading__1927001464__auto____1896000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_516, false, nil); A_arbace_go_escape_eval1896000004_loading__1927001464__auto____1896000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :7:1
func A_arbace_go_escape__init_part0_A_Unit3__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(7, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_escape__init_part0_A_const_1)).Equals_O__Z(A_arbace_go_escape__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_escape_eval1896000008_fn__1896000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_escape_eval1896000008_fn__1896000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_517, false, nil); A_arbace_go_escape_eval1896000008_fn__1896000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :7:1
func A_arbace_go_escape__init_part0_A_Init__O() any { A_arbace_go_escape__init_part0_A_Init(); return nil }
//line :7:1
func A_arbace_go_escape__init_part0_A_Load__O() any { A_arbace_go_escape__init_part0_A_Init(); A_arbace_go_escape__init_part0_A_Unit0__O(); A_arbace_go_escape__init_part0_A_Unit1__O(); A_arbace_go_escape__init_part0_A_Unit2__O(); A_arbace_go_escape__init_part0_A_Unit3__O(); A_arbace_go_escape__init_part0_A_Unit4__O(); A_arbace_go_escape__init_part0_A_Unit5__O(); A_arbace_go_escape__init_part0_A_Unit6__O(); A_arbace_go_escape__init_part0_A_Unit7__O(); A_arbace_go_escape__init_part0_A_Unit8__O(); A_arbace_go_escape__init_part0_A_Unit9__O(); A_arbace_go_escape__init_part0_A_Unit10__O(); A_arbace_go_escape__init_part0_A_Unit11__O(); A_arbace_go_escape__init_part0_A_Unit12__O(); A_arbace_go_escape__init_part0_A_Unit13__O(); A_arbace_go_escape__init_part0_A_Unit14__O(); A_arbace_go_escape__init_part0_A_Unit15__O(); A_arbace_go_escape__init_part0_A_Unit16__O(); A_arbace_go_escape__init_part0_A_Unit17__O(); A_arbace_go_escape__init_part0_A_Unit18__O(); A_arbace_go_escape__init_part0_A_Unit19__O(); A_arbace_go_escape__init_part0_A_Unit20__O(); A_arbace_go_escape__init_part0_A_Unit21__O(); A_arbace_go_escape__init_part0_A_Unit22__O(); A_arbace_go_escape__init_part0_A_Unit23__O(); A_arbace_go_escape__init_part0_A_Unit24__O(); A_arbace_go_escape__init_part0_A_Unit25__O(); A_arbace_go_escape__init_part0_A_Unit26__O(); A_arbace_go_escape__init_part0_A_Unit27__O(); A_arbace_go_escape__init_part0_A_Unit28__O(); A_arbace_go_escape__init_part0_A_Unit29__O(); A_arbace_go_escape__init_part0_A_Unit30__O(); A_arbace_go_escape__init_part0_A_Unit31__O(); A_arbace_go_escape__init_part0_A_Unit32__O(); A_arbace_go_escape__init_part0_A_Unit33__O(); A_arbace_go_escape__init_part0_A_Unit34__O(); A_arbace_go_escape__init_part0_A_Unit35__O(); A_arbace_go_escape__init_part0_A_Unit36__O(); A_arbace_go_escape__init_part0_A_Unit37__O(); A_arbace_go_escape__init_part0_A_Unit38__O(); A_arbace_go_escape__init_part0_A_Unit39__O(); A_arbace_go_escape__init_part0_A_Unit40__O(); A_arbace_go_escape__init_part0_A_Unit41__O(); A_arbace_go_escape__init_part0_A_Unit42__O(); A_arbace_go_escape__init_part0_A_Unit43__O(); A_arbace_go_escape__init_part0_A_Unit44__O(); A_arbace_go_escape__init_part0_A_Unit45__O(); A_arbace_go_escape__init_part0_A_Unit46__O(); A_arbace_go_escape__init_part0_A_Unit47__O(); A_arbace_go_escape__init_part0_A_Unit48__O(); A_arbace_go_escape__init_part0_A_Unit49__O(); A_arbace_go_escape__init_part0_A_Unit50__O(); A_arbace_go_escape__init_part0_A_Unit51__O(); A_arbace_go_escape__init_part0_A_Unit52__O(); A_arbace_go_escape__init_part0_A_Unit53__O(); A_arbace_go_escape__init_part0_A_Unit54__O(); A_arbace_go_escape__init_part0_A_Unit55__O(); A_arbace_go_escape__init_part0_A_Unit56__O(); A_arbace_go_escape__init_part0_A_Unit57__O(); A_arbace_go_escape__init_part0_A_Unit58__O(); A_arbace_go_escape__init_part0_A_Unit59__O(); A_arbace_go_escape__init_part0_A_Unit60__O(); A_arbace_go_escape__init_part0_A_Unit61__O(); A_arbace_go_escape__init_part0_A_Unit62__O(); A_arbace_go_escape__init_part0_A_Unit63__O(); A_arbace_go_escape__init_part0_A_Unit64__O(); A_arbace_go_escape__init_part0_A_Unit65__O(); A_arbace_go_escape__init_part0_A_Unit66__O(); A_arbace_go_escape__init_part0_A_Unit67__O(); A_arbace_go_escape__init_part0_A_Unit68__O(); A_arbace_go_escape__init_part0_A_Unit69__O(); A_arbace_go_escape__init_part0_A_Unit70__O(); A_arbace_go_escape__init_part0_A_Unit71__O(); A_arbace_go_escape__init_part0_A_Unit72__O(); A_arbace_go_escape__init_part0_A_Unit73__O(); A_arbace_go_escape__init_part0_A_Unit74__O(); A_arbace_go_escape__init_part0_A_Unit75__O(); A_arbace_go_escape__init_part0_A_Unit76__O(); A_arbace_go_escape__init_part0_A_Unit77__O(); A_arbace_go_escape__init_part0_A_Unit78__O(); A_arbace_go_escape__init_part0_A_Unit79__O(); A_arbace_go_escape__init_part0_A_Unit80__O(); A_arbace_go_escape__init_part0_A_Unit81__O(); A_arbace_go_escape__init_part0_A_Unit82__O(); A_arbace_go_escape__init_part0_A_Unit83__O(); A_arbace_go_escape__init_part0_A_Unit84__O(); A_arbace_go_escape__init_part0_A_Unit85__O(); A_arbace_go_escape__init_part0_A_Unit86__O(); A_arbace_go_escape__init_part0_A_Unit87__O(); A_arbace_go_escape__init_part0_A_Unit88__O(); A_arbace_go_escape__init_part0_A_Unit89__O(); A_arbace_go_escape__init_part0_A_Unit90__O(); A_arbace_go_escape__init_part0_A_Unit91__O(); A_arbace_go_escape__init_part0_A_Unit92__O(); A_arbace_go_escape__init_part0_A_Unit93__O(); A_arbace_go_escape__init_part0_A_Unit94__O(); A_arbace_go_escape__init_part0_A_Unit95__O(); A_arbace_go_escape__init_part0_A_Unit96__O(); A_arbace_go_escape__init_part0_A_Unit97__O(); A_arbace_go_escape__init_part0_A_Unit98__O(); A_arbace_go_escape__init_part0_A_Unit99__O(); return nil }
































func A_arbace_go_escape__init_part0_A_Unit4__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); A_arbace_go_escape__init_part0_A_const_4.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_5); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_6)); return A_arbace_go_escape__init_part0_A_const_4.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_escape__init_part0_A_Unit5__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_go_escape__init_part0_A_const_7.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_8); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_9)); return A_arbace_go_escape__init_part0_A_const_7.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_escape__init_part0_A_Unit6__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); A_arbace_go_escape__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_11)); return A_arbace_go_escape__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_escape__init_part0_A_Unit7__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); A_arbace_go_escape__init_part0_A_const_12.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_13)); return A_arbace_go_escape__init_part0_A_const_12.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_escape__init_part0_A_Unit8__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_escape_warn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_escape_warn_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_518, false, nil); A_arbace_go_escape_warn_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_15)); return A_arbace_go_escape__init_part0_A_const_14 }


func A_arbace_go_escape__init_part0_A_Unit9__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_escape_file_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_escape_file_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_519, false, nil); A_arbace_go_escape_file_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_17)); return A_arbace_go_escape__init_part0_A_const_16 }



func A_arbace_go_escape__init_part0_A_Unit10__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_escape_unsupported_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_escape_unsupported_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_520, false, nil); A_arbace_go_escape_unsupported_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_19)); return A_arbace_go_escape__init_part0_A_const_18 }


func A_arbace_go_escape__init_part0_A_Unit11__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); A_arbace_go_escape__init_part0_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_21)); return A_arbace_go_escape__init_part0_A_const_20.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_escape__init_part0_A_Unit12__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_escape_under_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_escape_under_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_521, false, nil); A_arbace_go_escape_under_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_23)); return A_arbace_go_escape__init_part0_A_const_22 }

func A_arbace_go_escape__init_part0_A_Unit13__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_escape_kind_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_escape_kind_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_522, false, nil); A_arbace_go_escape_kind_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_25)); return A_arbace_go_escape__init_part0_A_const_24 }





func A_arbace_go_escape__init_part0_A_Unit14__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_escape_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_escape_iface_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_523, false, nil); A_arbace_go_escape_iface_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_27)); return A_arbace_go_escape__init_part0_A_const_26 }
func A_arbace_go_escape__init_part0_A_Unit15__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_escape_elem_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_escape_elem_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_524, false, nil); A_arbace_go_escape_elem_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_29)); return A_arbace_go_escape__init_part0_A_const_28 }








func A_arbace_go_escape__init_part0_A_Unit16__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_escape_has_pointers_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_escape_has_pointers_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_525, false, nil); A_arbace_go_escape_has_pointers_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_31)); return A_arbace_go_escape__init_part0_A_const_30 }













func A_arbace_go_escape__init_part0_A_Unit17__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_escape_direct_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_escape_direct_iface_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_526, false, nil); A_arbace_go_escape_direct_iface_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_33)); return A_arbace_go_escape__init_part0_A_const_32 }












func A_arbace_go_escape__init_part0_A_Unit18__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_escape_size_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_escape_size_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_527, false, nil); A_arbace_go_escape_size_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_35)); return A_arbace_go_escape__init_part0_A_const_34 }
func A_arbace_go_escape__init_part0_A_Unit19__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_escape_align_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_escape_align_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_528, false, nil); A_arbace_go_escape_align_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_37)); return A_arbace_go_escape__init_part0_A_const_36 }

func A_arbace_go_escape__init_part0_A_Unit20__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_escape_untyped_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_escape_untyped_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_529, false, nil); A_arbace_go_escape_untyped_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_39)); return A_arbace_go_escape__init_part0_A_const_38 }

func A_arbace_go_escape__init_part0_A_Unit21__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); A_arbace_go_escape__init_part0_A_const_40.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_41); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_42)); return A_arbace_go_escape__init_part0_A_const_40 }



func A_arbace_go_escape__init_part0_A_Unit22__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_escape_gop_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_escape_gop_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_530, false, nil); A_arbace_go_escape_gop_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_44)); return A_arbace_go_escape__init_part0_A_const_43 }




func A_arbace_go_escape__init_part0_A_Unit23__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(133, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_escape_spread_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_escape_spread_call_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_531, false, nil); A_arbace_go_escape_spread_call_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_46)); return A_arbace_go_escape__init_part0_A_const_45 }



func A_arbace_go_escape__init_part0_A_Unit24__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_48)); return A_arbace_go_escape__init_part0_A_const_47 }

func A_arbace_go_escape__init_part0_A_Unit25__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_escape_params_str_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_escape_params_str_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_532, false, nil); A_arbace_go_escape_params_str_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_50)); return A_arbace_go_escape__init_part0_A_const_49 }






func A_arbace_go_escape__init_part0_A_Unit26__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_escape_type_str_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_escape_type_str_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_533, false, nil); A_arbace_go_escape_type_str_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_51)); return A_arbace_go_escape__init_part0_A_const_47 }

























































func A_arbace_go_escape__init_part0_A_Unit27__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(204, 1); A_arbace_go_escape__init_part0_A_const_52.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_5); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_53)); return A_arbace_go_escape__init_part0_A_const_52 }
func A_arbace_go_escape__init_part0_A_Unit28__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); A_arbace_go_escape__init_part0_A_const_54.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_55); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_56)); return A_arbace_go_escape__init_part0_A_const_54 }
func A_arbace_go_escape__init_part0_A_Unit29__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(206, 1); A_arbace_go_escape__init_part0_A_const_57.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_58); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_59)); return A_arbace_go_escape__init_part0_A_const_57 }
func A_arbace_go_escape__init_part0_A_Unit30__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); A_arbace_go_escape__init_part0_A_const_60.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_61); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_62)); return A_arbace_go_escape__init_part0_A_const_60 }

func A_arbace_go_escape__init_part0_A_Unit31__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_escape_lget_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_escape_lget_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_534, false, nil); A_arbace_go_escape_lget_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_64)); return A_arbace_go_escape__init_part0_A_const_63 }
func A_arbace_go_escape__init_part0_A_Unit32__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(210, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_escape_lset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_escape_lset_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_535, false, nil); A_arbace_go_escape_lset_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_66)); return A_arbace_go_escape__init_part0_A_const_65 }
func A_arbace_go_escape__init_part0_A_Unit33__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(211, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_escape_has_attr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_escape_has_attr_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_536, false, nil); A_arbace_go_escape_has_attr_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_68)); return A_arbace_go_escape__init_part0_A_const_67 }


func A_arbace_go_escape__init_part0_A_Unit34__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); A_arbace_go_escape__init_part0_A_const_69.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_70); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_69; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_71)); return A_arbace_go_escape__init_part0_A_const_69 }
func A_arbace_go_escape__init_part0_A_Unit35__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(215, 1); A_arbace_go_escape__init_part0_A_const_72.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_73); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_74)); return A_arbace_go_escape__init_part0_A_const_72 }
func A_arbace_go_escape__init_part0_A_Unit36__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_escape_leak_get_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_escape_leak_get_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_537, false, nil); A_arbace_go_escape_leak_get_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_76)); return A_arbace_go_escape__init_part0_A_const_75 }
func A_arbace_go_escape__init_part0_A_Unit37__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_escape_leak_add_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_escape_leak_add_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_538, false, nil); A_arbace_go_escape_leak_add_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_78)); return A_arbace_go_escape__init_part0_A_const_77 }




func A_arbace_go_escape__init_part0_A_Unit38__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_escape_leak_optimize_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_escape_leak_optimize_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_539, false, nil); A_arbace_go_escape_leak_optimize_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_80)); return A_arbace_go_escape__init_part0_A_const_79 }




func A_arbace_go_escape__init_part0_A_Unit39__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_escape_leak_encode_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_escape_leak_encode_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_540, false, nil); A_arbace_go_escape_leak_encode_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_82)); return A_arbace_go_escape__init_part0_A_const_81 }




func A_arbace_go_escape__init_part0_A_Unit40__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_escape_fn_get_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_escape_fn_get_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_541, false, nil); A_arbace_go_escape_fn_get_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_84)); return A_arbace_go_escape__init_part0_A_const_83 }
func A_arbace_go_escape__init_part0_A_Unit41__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_escape_fn_set_BANG__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_escape_fn_set_BANG__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_542, false, nil); A_arbace_go_escape_fn_set_BANG__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_86)); return A_arbace_go_escape__init_part0_A_const_85 }

func A_arbace_go_escape__init_part0_A_Unit42__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_escape_new_batch_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_escape_new_batch_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_543, false, nil); A_arbace_go_escape_new_batch_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_88)); return A_arbace_go_escape__init_part0_A_const_87 }










func A_arbace_go_escape__init_part0_A_Unit43__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(246, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_escape_with_fn_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_escape_with_fn_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_544, false, nil); A_arbace_go_escape_with_fn_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_90)); return A_arbace_go_escape__init_part0_A_const_89 }
func A_arbace_go_escape__init_part0_A_Unit44__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_escape_eb_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_escape_eb_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_545, false, nil); A_arbace_go_escape_eb_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_92)); return A_arbace_go_escape__init_part0_A_const_91 }
func A_arbace_go_escape__init_part0_A_Unit45__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_escape_curfn_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_escape_curfn_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_546, false, nil); A_arbace_go_escape_curfn_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_94)); return A_arbace_go_escape__init_part0_A_const_93 }
func A_arbace_go_escape__init_part0_A_Unit46__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(249, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_escape_depth_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_escape_depth_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_547, false, nil); A_arbace_go_escape_depth_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_96)); return A_arbace_go_escape__init_part0_A_const_95 }

func A_arbace_go_escape__init_part0_A_Unit47__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_escape_hole_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_escape_hole_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_548, false, nil); A_arbace_go_escape_hole_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_98)); return A_arbace_go_escape__init_part0_A_const_97 }
func A_arbace_go_escape__init_part0_A_Unit48__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(252, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_escape_heap_hole_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_escape_heap_hole_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_549, false, nil); A_arbace_go_escape_heap_hole_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_100)); return A_arbace_go_escape__init_part0_A_const_99 }
func A_arbace_go_escape__init_part0_A_Unit49__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_escape_mutator_hole_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_escape_mutator_hole_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_550, false, nil); A_arbace_go_escape_mutator_hole_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_102)); return A_arbace_go_escape__init_part0_A_const_101 }
func A_arbace_go_escape__init_part0_A_Unit50__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_escape_callee_hole_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_escape_callee_hole_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_551, false, nil); A_arbace_go_escape_callee_hole_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_104)); return A_arbace_go_escape__init_part0_A_const_103 }
func A_arbace_go_escape__init_part0_A_Unit51__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_go_escape_discard_hole_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_escape_discard_hole_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_552, false, nil); A_arbace_go_escape_discard_hole_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_106)); return A_arbace_go_escape__init_part0_A_const_105 }
func A_arbace_go_escape__init_part0_A_Unit52__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_go_escape_shift_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_escape_shift_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_553, false, nil); A_arbace_go_escape_shift_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_108)); return A_arbace_go_escape__init_part0_A_const_107 }


func A_arbace_go_escape__init_part0_A_Unit53__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(259, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_escape_k_deref_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_escape_k_deref_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_554, false, nil); A_arbace_go_escape_k_deref_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_110)); return A_arbace_go_escape__init_part0_A_const_109 }
func A_arbace_go_escape__init_part0_A_Unit54__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(260, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_escape_k_addr_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_escape_k_addr_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_555, false, nil); A_arbace_go_escape_k_addr_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_112)); return A_arbace_go_escape__init_part0_A_const_111 }
func A_arbace_go_escape__init_part0_A_Unit55__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(261, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_escape_dot_type_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_escape_dot_type_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_556, false, nil); A_arbace_go_escape_dot_type_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_114)); return A_arbace_go_escape__init_part0_A_const_113 }


func A_arbace_go_escape__init_part0_A_Unit56__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_go_escape_name_loc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_escape_name_loc_QMARK__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_557, false, nil); A_arbace_go_escape_name_loc_QMARK__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_116)); return A_arbace_go_escape__init_part0_A_const_115 }

func A_arbace_go_escape__init_part0_A_Unit57__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(266, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_go_escape_new_loc_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_escape_new_loc_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_558, false, nil); A_arbace_go_escape_new_loc_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_118)); return A_arbace_go_escape__init_part0_A_const_117 }















func A_arbace_go_escape__init_part0_A_Unit58__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_escape_old_loc_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_escape_old_loc_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_559, false, nil); A_arbace_go_escape_old_loc_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_120)); return A_arbace_go_escape__init_part0_A_const_119 }



func A_arbace_go_escape__init_part0_A_Unit59__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_escape_flow_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_escape_flow_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_560, false, nil); A_arbace_go_escape_flow_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_122)); return A_arbace_go_escape__init_part0_A_const_121 }













func A_arbace_go_escape__init_part0_A_Unit60__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_escape_tee_hole_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_escape_tee_hole_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_561, false, nil); A_arbace_go_escape_tee_hole_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_124)); return A_arbace_go_escape__init_part0_A_const_123 }







func A_arbace_go_escape__init_part0_A_Unit61__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(308, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_go_escape_later_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_go_escape_later_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_562, false, nil); A_arbace_go_escape_later_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_126)); return A_arbace_go_escape__init_part0_A_const_125 }




func A_arbace_go_escape__init_part0_A_Unit62__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_go_escape_spill_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_escape_spill_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_563, false, nil); A_arbace_go_escape_spill_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_128)); return A_arbace_go_escape__init_part0_A_const_127 }






func A_arbace_go_escape__init_part0_A_Unit63__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(320, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_129; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_130)); return A_arbace_go_escape__init_part0_A_const_129 }

func A_arbace_go_escape__init_part0_A_Unit64__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_go_escape_fn_of_obj_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_go_escape_fn_of_obj_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_564, false, nil); A_arbace_go_escape_fn_of_obj_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_132)); return A_arbace_go_escape__init_part0_A_const_131 }






func A_arbace_go_escape__init_part0_A_Unit65__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_go_escape_fn_of_node_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_go_escape_fn_of_node_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_565, false, nil); A_arbace_go_escape_fn_of_node_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_134)); return A_arbace_go_escape__init_part0_A_const_133 }

func A_arbace_go_escape__init_part0_A_Unit66__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(331, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_escape_contains_closure_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_escape_contains_closure_QMARK__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_566, false, nil); A_arbace_go_escape_contains_closure_QMARK__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_136)); return A_arbace_go_escape__init_part0_A_const_135 }








func A_arbace_go_escape__init_part0_A_Unit67__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(340, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_go_escape_in_mutual_batch_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_go_escape_in_mutual_batch_QMARK__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_567, false, nil); A_arbace_go_escape_in_mutual_batch_QMARK__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_138)); return A_arbace_go_escape__init_part0_A_const_137 }




func A_arbace_go_escape__init_part0_A_Unit68__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_go_escape_node_type_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_go_escape_node_type_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_568, false, nil); A_arbace_go_escape_node_type_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_140)); return A_arbace_go_escape__init_part0_A_const_139 }
func A_arbace_go_escape__init_part0_A_Unit69__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_go_escape_const_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_go_escape_const_QMARK__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_569, false, nil); A_arbace_go_escape_const_QMARK__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_142)); return A_arbace_go_escape__init_part0_A_const_141 }

func A_arbace_go_escape__init_part0_A_Unit70__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(348, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_go_escape_field_steps_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_go_escape_field_steps_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_570, false, nil); A_arbace_go_escape_field_steps_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_144)); return A_arbace_go_escape__init_part0_A_const_143 }














func A_arbace_go_escape__init_part0_A_Unit71__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_go_escape_select_node_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_escape_select_node_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_571, false, nil); A_arbace_go_escape_select_node_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_146)); return A_arbace_go_escape__init_part0_A_const_145 }






func A_arbace_go_escape__init_part0_A_Unit72__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_go_escape_expand_field_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_go_escape_expand_field_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_572, false, nil); A_arbace_go_escape_expand_field_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_148)); return A_arbace_go_escape__init_part0_A_const_147 }






func A_arbace_go_escape__init_part0_A_Unit73__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(377, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_go_escape_method_recv_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_go_escape_method_recv_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_573, false, nil); A_arbace_go_escape_method_recv_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_150)); return A_arbace_go_escape__init_part0_A_const_149 }
























func A_arbace_go_escape__init_part0_A_Unit74__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_152)); return A_arbace_go_escape__init_part0_A_const_151 }
//line :402:1
func A_arbace_go_escape__init_part0_A_Unit75__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_153; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_154)); return A_arbace_go_escape__init_part0_A_const_153 }

func A_arbace_go_escape__init_part0_A_Unit76__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(404, 1); A_arbace_go_escape__init_part0_A_const_155.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_156); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_157)); return A_arbace_go_escape__init_part0_A_const_155 }




func A_arbace_go_escape__init_part0_A_Unit77__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(409, 1); A_arbace_go_escape__init_part0_A_const_158.BindRoot_O__V(A_arbace_go_escape__init_part0_A_const_159); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_158; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_160)); return A_arbace_go_escape__init_part0_A_const_158 }



func A_arbace_go_escape__init_part0_A_Unit78__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_go_escape_node_prec_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_go_escape_node_prec_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_574, false, nil); A_arbace_go_escape_node_prec_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_162)); return A_arbace_go_escape__init_part0_A_const_161 }





func A_arbace_go_escape__init_part0_A_Unit79__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(419, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_go_escape_const_str_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_go_escape_const_str_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_575, false, nil); A_arbace_go_escape_const_str_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_164)); return A_arbace_go_escape__init_part0_A_const_163 }















func A_arbace_go_escape__init_part0_A_Unit80__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_go_escape_args_str_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_go_escape_args_str_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_576, false, nil); A_arbace_go_escape_args_str_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_166)); return A_arbace_go_escape__init_part0_A_const_165 }

func A_arbace_go_escape__init_part0_A_Unit81__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_go_escape_builtin_str_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_go_escape_builtin_str_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_577, false, nil); A_arbace_go_escape_builtin_str_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_168)); return A_arbace_go_escape__init_part0_A_const_167 }













func A_arbace_go_escape__init_part0_A_Unit82__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_151; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_go_escape_fmt_node_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_go_escape_fmt_node_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_578, false, nil); A_arbace_go_escape_fmt_node_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_169)); return A_arbace_go_escape__init_part0_A_const_151 }




































































func A_arbace_go_escape__init_part0_A_Unit83__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_170; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_171)); return A_arbace_go_escape__init_part0_A_const_170 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit84__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_172; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_173)); return A_arbace_go_escape__init_part0_A_const_172 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit85__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_174; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_175)); return A_arbace_go_escape__init_part0_A_const_174 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit86__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_176; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_177)); return A_arbace_go_escape__init_part0_A_const_176 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit87__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_178; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_179)); return A_arbace_go_escape__init_part0_A_const_178 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit88__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_180; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_181)); return A_arbace_go_escape__init_part0_A_const_180 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit89__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_182; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_183)); return A_arbace_go_escape__init_part0_A_const_182 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit90__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_184; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_185)); return A_arbace_go_escape__init_part0_A_const_184 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit91__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_186; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_187)); return A_arbace_go_escape__init_part0_A_const_186 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit92__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_188; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_189)); return A_arbace_go_escape__init_part0_A_const_188 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit93__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_190; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_191)); return A_arbace_go_escape__init_part0_A_const_190 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit94__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_192; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_193)); return A_arbace_go_escape__init_part0_A_const_192 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit95__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_194; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_195)); return A_arbace_go_escape__init_part0_A_const_194 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit96__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_196; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_197)); return A_arbace_go_escape__init_part0_A_const_196 }
//line :520:1
func A_arbace_go_escape__init_part0_A_Unit97__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_198; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_199)); return A_arbace_go_escape__init_part0_A_const_198 }

func A_arbace_go_escape__init_part0_A_Unit98__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(522, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_200; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_go_escape_with_line_STAR__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_go_escape_with_line_STAR__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_579, false, nil); A_arbace_go_escape_with_line_STAR__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_200; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_201)); return A_arbace_go_escape__init_part0_A_const_200 }







func A_arbace_go_escape__init_part0_A_Unit99__O() any { A_arbace_go_escape__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(530, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part0_A_const_202; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_go_escape_assign_heap_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_go_escape_assign_heap_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_580, false, nil); A_arbace_go_escape_assign_heap_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part0_A_const_202; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part0_A_const_203)); return A_arbace_go_escape__init_part0_A_const_202 }
func A_arbace_go_escape__init_part1_A_Unit100__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_escape_mutate_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_escape_mutate_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_582, false, nil); A_arbace_go_escape_mutate_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_1)); return A_arbace_go_escape__init_part1_A_const_0 }
//line :531:1
func A_arbace_go_escape__init_part1_A_Init__O() any { A_arbace_go_escape__init_part1_A_Init(); return nil }
//line :531:1
func A_arbace_go_escape__init_part1_A_Load__O() any { A_arbace_go_escape__init_part1_A_Init(); A_arbace_go_escape__init_part1_A_Unit100__O(); A_arbace_go_escape__init_part1_A_Unit101__O(); A_arbace_go_escape__init_part1_A_Unit102__O(); A_arbace_go_escape__init_part1_A_Unit103__O(); A_arbace_go_escape__init_part1_A_Unit104__O(); A_arbace_go_escape__init_part1_A_Unit105__O(); A_arbace_go_escape__init_part1_A_Unit106__O(); A_arbace_go_escape__init_part1_A_Unit107__O(); A_arbace_go_escape__init_part1_A_Unit108__O(); A_arbace_go_escape__init_part1_A_Unit109__O(); A_arbace_go_escape__init_part1_A_Unit110__O(); A_arbace_go_escape__init_part1_A_Unit111__O(); A_arbace_go_escape__init_part1_A_Unit112__O(); A_arbace_go_escape__init_part1_A_Unit113__O(); A_arbace_go_escape__init_part1_A_Unit114__O(); A_arbace_go_escape__init_part1_A_Unit115__O(); A_arbace_go_escape__init_part1_A_Unit116__O(); A_arbace_go_escape__init_part1_A_Unit117__O(); A_arbace_go_escape__init_part1_A_Unit118__O(); A_arbace_go_escape__init_part1_A_Unit119__O(); A_arbace_go_escape__init_part1_A_Unit120__O(); A_arbace_go_escape__init_part1_A_Unit121__O(); A_arbace_go_escape__init_part1_A_Unit122__O(); A_arbace_go_escape__init_part1_A_Unit123__O(); A_arbace_go_escape__init_part1_A_Unit124__O(); A_arbace_go_escape__init_part1_A_Unit125__O(); A_arbace_go_escape__init_part1_A_Unit126__O(); A_arbace_go_escape__init_part1_A_Unit127__O(); A_arbace_go_escape__init_part1_A_Unit128__O(); A_arbace_go_escape__init_part1_A_Unit129__O(); A_arbace_go_escape__init_part1_A_Unit130__O(); A_arbace_go_escape__init_part1_A_Unit131__O(); A_arbace_go_escape__init_part1_A_Unit132__O(); A_arbace_go_escape__init_part1_A_Unit133__O(); A_arbace_go_escape__init_part1_A_Unit134__O(); A_arbace_go_escape__init_part1_A_Unit135__O(); A_arbace_go_escape__init_part1_A_Unit136__O(); A_arbace_go_escape__init_part1_A_Unit137__O(); A_arbace_go_escape__init_part1_A_Unit138__O(); A_arbace_go_escape__init_part1_A_Unit139__O(); A_arbace_go_escape__init_part1_A_Unit140__O(); A_arbace_go_escape__init_part1_A_Unit141__O(); A_arbace_go_escape__init_part1_A_Unit142__O(); A_arbace_go_escape__init_part1_A_Unit143__O(); A_arbace_go_escape__init_part1_A_Unit144__O(); A_arbace_go_escape__init_part1_A_Unit145__O(); A_arbace_go_escape__init_part1_A_Unit146__O(); A_arbace_go_escape__init_part1_A_Unit147__O(); A_arbace_go_escape__init_part1_A_Unit148__O(); A_arbace_go_escape__init_part1_A_Unit149__O(); A_arbace_go_escape__init_part1_A_Unit150__O(); A_arbace_go_escape__init_part1_A_Unit151__O(); A_arbace_go_escape__init_part1_A_Unit152__O(); A_arbace_go_escape__init_part1_A_Unit153__O(); A_arbace_go_escape__init_part1_A_Unit154__O(); A_arbace_go_escape__init_part1_A_Unit155__O(); A_arbace_go_escape__init_part1_A_Unit156__O(); A_arbace_go_escape__init_part1_A_Unit157__O(); A_arbace_go_escape__init_part1_A_Unit158__O(); A_arbace_go_escape__init_part1_A_Unit159__O(); A_arbace_go_escape__init_part1_A_Unit160__O(); A_arbace_go_escape__init_part1_A_Unit161__O(); A_arbace_go_escape__init_part1_A_Unit162__O(); A_arbace_go_escape__init_part1_A_Unit163__O(); A_arbace_go_escape__init_part1_A_Unit164__O(); A_arbace_go_escape__init_part1_A_Unit165__O(); A_arbace_go_escape__init_part1_A_Unit166__O(); A_arbace_go_escape__init_part1_A_Unit167__O(); A_arbace_go_escape__init_part1_A_Unit168__O(); A_arbace_go_escape__init_part1_A_Unit169__O(); A_arbace_go_escape__init_part1_A_Unit170__O(); A_arbace_go_escape__init_part1_A_Unit171__O(); A_arbace_go_escape__init_part1_A_Unit172__O(); A_arbace_go_escape__init_part1_A_Unit173__O(); A_arbace_go_escape__init_part1_A_Unit174__O(); A_arbace_go_escape__init_part1_A_Unit175__O(); A_arbace_go_escape__init_part1_A_Unit176__O(); A_arbace_go_escape__init_part1_A_Unit177__O(); A_arbace_go_escape__init_part1_A_Unit178__O(); A_arbace_go_escape__init_part1_A_Unit179__O(); A_arbace_go_escape__init_part1_A_Unit180__O(); A_arbace_go_escape__init_part1_A_Unit181__O(); A_arbace_go_escape__init_part1_A_Unit182__O(); A_arbace_go_escape__init_part1_A_Unit183__O(); A_arbace_go_escape__init_part1_A_Unit184__O(); A_arbace_go_escape__init_part1_A_Unit185__O(); A_arbace_go_escape__init_part1_A_Unit186__O(); A_arbace_go_escape__init_part1_A_Unit187__O(); A_arbace_go_escape__init_part1_A_Unit188__O(); A_arbace_go_escape__init_part1_A_Unit189__O(); A_arbace_go_escape__init_part1_A_Unit190__O(); A_arbace_go_escape__init_part1_A_Unit191__O(); A_arbace_go_escape__init_part1_A_Unit192__O(); A_arbace_go_escape__init_part1_A_Unit193__O(); A_arbace_go_escape__init_part1_A_Unit194__O(); A_arbace_go_escape__init_part1_A_Unit195__O(); A_arbace_go_escape__init_part1_A_Unit196__O(); A_arbace_go_escape__init_part1_A_Unit197__O(); A_arbace_go_escape__init_part1_A_Unit198__O(); A_arbace_go_escape__init_part1_A_Unit199__O(); return nil }
func A_arbace_go_escape__init_part1_A_Unit101__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(532, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_escape_discards_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_escape_discards_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_583, false, nil); A_arbace_go_escape_discards_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_3)); return A_arbace_go_escape__init_part1_A_const_2 }

func A_arbace_go_escape__init_part1_A_Unit102__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(534, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_escape_conv_kind_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_escape_conv_kind_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_584, false, nil); A_arbace_go_escape_conv_kind_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_5)); return A_arbace_go_escape__init_part1_A_const_4 }




















func A_arbace_go_escape__init_part1_A_Unit103__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(555, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_escape_reflect_header_data_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_escape_reflect_header_data_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_585, false, nil); A_arbace_go_escape_reflect_header_data_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_7)); return A_arbace_go_escape__init_part1_A_const_6 }








func A_arbace_go_escape__init_part1_A_Unit104__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(564, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_escape_unsafe_value_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_escape_unsafe_value_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_586, false, nil); A_arbace_go_escape_unsafe_value_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_9)); return A_arbace_go_escape__init_part1_A_const_8 }













func A_arbace_go_escape__init_part1_A_Unit105__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(578, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_escape_add_string_list_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_escape_add_string_list_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_587, false, nil); A_arbace_go_escape_add_string_list_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_11)); return A_arbace_go_escape__init_part1_A_const_10 }






func A_arbace_go_escape__init_part1_A_Unit106__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(585, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_escape_closure_expr_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_escape_closure_expr_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_588, false, nil); A_arbace_go_escape_closure_expr_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_13)); return A_arbace_go_escape__init_part1_A_const_12 }
















func A_arbace_go_escape__init_part1_A_Unit107__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(602, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_escape_method_value_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_escape_method_value_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_589, false, nil); A_arbace_go_escape_method_value_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_15)); return A_arbace_go_escape__init_part1_A_const_14 }










func A_arbace_go_escape__init_part1_A_Unit108__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(613, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_escape_expr_skip_init_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_escape_expr_skip_init_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_590, false, nil); A_arbace_go_escape_expr_skip_init_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_17)); return A_arbace_go_escape__init_part1_A_const_16 }









































































func A_arbace_go_escape__init_part1_A_Unit109__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_escape_elt_value_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_escape_elt_value_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_591, false, nil); A_arbace_go_escape_elt_value_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_19)); return A_arbace_go_escape__init_part1_A_const_18 }







func A_arbace_go_escape__init_part1_A_Unit110__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(695, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_escape_expr_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_escape_expr_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_592, false, nil); A_arbace_go_escape_expr_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_21)); return A_arbace_go_escape__init_part1_A_const_20 }



func A_arbace_go_escape__init_part1_A_Unit111__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(699, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_escape_discard_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_escape_discard_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_593, false, nil); A_arbace_go_escape_discard_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_23)); return A_arbace_go_escape__init_part1_A_const_22 }

func A_arbace_go_escape__init_part1_A_Unit112__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(701, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_escape_max_stack_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_escape_max_stack_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_594, false, nil); A_arbace_go_escape_max_stack_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_25)); return A_arbace_go_escape__init_part1_A_const_24 }
func A_arbace_go_escape__init_part1_A_Unit113__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(702, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_escape_max_implicit_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_escape_max_implicit_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_595, false, nil); A_arbace_go_escape_max_implicit_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_27)); return A_arbace_go_escape__init_part1_A_const_26 }

func A_arbace_go_escape__init_part1_A_Unit114__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(704, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_escape_heap_alloc_reason_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_escape_heap_alloc_reason_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_596, false, nil); A_arbace_go_escape_heap_alloc_reason_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_29)); return A_arbace_go_escape__init_part1_A_const_28 }























func A_arbace_go_escape__init_part1_A_Unit115__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(728, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_escape_call_temps_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_escape_call_temps_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_597, false, nil); A_arbace_go_escape_call_temps_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_31)); return A_arbace_go_escape__init_part1_A_const_30 }



















func A_arbace_go_escape__init_part1_A_Unit116__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(748, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_escape_tag_hole_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_escape_tag_hole_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_598, false, nil); A_arbace_go_escape_tag_hole_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_33)); return A_arbace_go_escape__init_part1_A_const_32 }























func A_arbace_go_escape__init_part1_A_Unit117__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(772, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_escape_call_tag_hole_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_escape_call_tag_hole_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_599, false, nil); A_arbace_go_escape_call_tag_hole_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_35)); return A_arbace_go_escape__init_part1_A_const_34 }

func A_arbace_go_escape__init_part1_A_Unit118__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(774, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_escape_merged_tag_hole_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_escape_merged_tag_hole_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_600, false, nil); A_arbace_go_escape_merged_tag_hole_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_37)); return A_arbace_go_escape__init_part1_A_const_36 }







func A_arbace_go_escape__init_part1_A_Unit119__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(782, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_escape_static_value_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_escape_static_value_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_601, false, nil); A_arbace_go_escape_static_value_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_39)); return A_arbace_go_escape__init_part1_A_const_38 }













func A_arbace_go_escape__init_part1_A_Unit120__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(796, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_escape_static_callee_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_escape_static_callee_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_602, false, nil); A_arbace_go_escape_static_callee_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_41)); return A_arbace_go_escape__init_part1_A_const_40 }









func A_arbace_go_escape__init_part1_A_Unit121__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(806, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_escape_func_assignments_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_escape_func_assignments_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_603, false, nil); A_arbace_go_escape_func_assignments_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_43)); return A_arbace_go_escape__init_part1_A_const_42 }







func A_arbace_go_escape__init_part1_A_Unit122__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(814, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_escape_resolve_assigned_callees_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_escape_resolve_assigned_callees_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_604, false, nil); A_arbace_go_escape_resolve_assigned_callees_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_45)); return A_arbace_go_escape__init_part1_A_const_44 }













func A_arbace_go_escape__init_part1_A_Unit123__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(828, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_go_escape_call_line_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_go_escape_call_line_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_605, false, nil); A_arbace_go_escape_call_line_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_47)); return A_arbace_go_escape__init_part1_A_const_46 }







func A_arbace_go_escape__init_part1_A_Unit124__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(836, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_go_escape_variadic_args_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_go_escape_variadic_args_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_606, false, nil); A_arbace_go_escape_variadic_args_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_49)); return A_arbace_go_escape__init_part1_A_const_48 }















func A_arbace_go_escape__init_part1_A_Unit125__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(852, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_escape_argument_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_escape_argument_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_607, false, nil); A_arbace_go_escape_argument_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_51)); return A_arbace_go_escape__init_part1_A_const_50 }

func A_arbace_go_escape__init_part1_A_Unit126__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(854, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_escape_inl_call_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_escape_inl_call_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_608, false, nil); A_arbace_go_escape_inl_call_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_53)); return A_arbace_go_escape__init_part1_A_const_52 }







func A_arbace_go_escape__init_part1_A_Unit127__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(862, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_escape_call_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_escape_call_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_609, false, nil); A_arbace_go_escape_call_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_55)); return A_arbace_go_escape__init_part1_A_const_54 }


















































func A_arbace_go_escape__init_part1_A_Unit128__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(913, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_escape_builtin_call_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_escape_builtin_call_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_610, false, nil); A_arbace_go_escape_builtin_call_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_57)); return A_arbace_go_escape__init_part1_A_const_56 }









































func A_arbace_go_escape__init_part1_A_Unit129__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(955, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_escape_wrapper_visit_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_escape_wrapper_visit_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_611, false, nil); A_arbace_go_escape_wrapper_visit_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_59)); return A_arbace_go_escape__init_part1_A_const_58 }


















func A_arbace_go_escape__init_part1_A_Unit130__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(974, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_escape_go_defer_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_escape_go_defer_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_612, false, nil); A_arbace_go_escape_go_defer_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_61)); return A_arbace_go_escape__init_part1_A_const_60 }


















































func A_arbace_go_escape__init_part1_A_Unit131__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1025, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_escape_normal_go_defer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_escape_normal_go_defer_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_613, false, nil); A_arbace_go_escape_normal_go_defer_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_63)); return A_arbace_go_escape__init_part1_A_const_62 }




func A_arbace_go_escape__init_part1_A_Unit132__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1030, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_escape_wrap_go_defer_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_escape_wrap_go_defer_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_614, false, nil); A_arbace_go_escape_wrap_go_defer_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_65)); return A_arbace_go_escape__init_part1_A_const_64 }




































func A_arbace_go_escape__init_part1_A_Unit133__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1067, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_escape_normalize_go_defer_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_escape_normalize_go_defer_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_615, false, nil); A_arbace_go_escape_normalize_go_defer_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_67)); return A_arbace_go_escape__init_part1_A_const_66 }




















func A_arbace_go_escape__init_part1_A_Unit134__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1088, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_escape_addr_of_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_escape_addr_of_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_616, false, nil); A_arbace_go_escape_addr_of_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_69)); return A_arbace_go_escape__init_part1_A_const_68 }
























func A_arbace_go_escape__init_part1_A_Unit135__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1113, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_escape_outer_name_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_escape_outer_name_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_617, false, nil); A_arbace_go_escape_outer_name_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_71)); return A_arbace_go_escape__init_part1_A_const_70 }










func A_arbace_go_escape__init_part1_A_Unit136__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1124, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_go_escape_norm_place_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_escape_norm_place_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_618, false, nil); A_arbace_go_escape_norm_place_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_73)); return A_arbace_go_escape__init_part1_A_const_72 }









func A_arbace_go_escape__init_part1_A_Unit137__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1134, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_go_escape_same_safe_expr_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_escape_same_safe_expr_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_619, false, nil); A_arbace_go_escape_same_safe_expr_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_75)); return A_arbace_go_escape__init_part1_A_const_74 }












func A_arbace_go_escape__init_part1_A_Unit138__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1147, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_escape_may_affect_memory_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_escape_may_affect_memory_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_620, false, nil); A_arbace_go_escape_may_affect_memory_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_77)); return A_arbace_go_escape__init_part1_A_const_76 }















func A_arbace_go_escape__init_part1_A_Unit139__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1163, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_escape_slice_self_assign_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_escape_slice_self_assign_QMARK__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_621, false, nil); A_arbace_go_escape_slice_self_assign_QMARK__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_79)); return A_arbace_go_escape__init_part1_A_const_78 }
















func A_arbace_go_escape__init_part1_A_Unit140__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1180, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_escape_self_assign_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_escape_self_assign_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_622, false, nil); A_arbace_go_escape_self_assign_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_81)); return A_arbace_go_escape__init_part1_A_const_80 }










func A_arbace_go_escape__init_part1_A_Unit141__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1191, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_go_escape_fmt_stmt_assign_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_escape_fmt_stmt_assign_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_623, false, nil); A_arbace_go_escape_fmt_stmt_assign_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_83)); return A_arbace_go_escape__init_part1_A_const_82 }


func A_arbace_go_escape__init_part1_A_Unit142__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1194, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_go_escape_comma_ok_temps_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_escape_comma_ok_temps_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_624, false, nil); A_arbace_go_escape_comma_ok_temps_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_85)); return A_arbace_go_escape__init_part1_A_const_84 }




















func A_arbace_go_escape__init_part1_A_Unit143__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1215, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_escape_assign_list_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_escape_assign_list_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_625, false, nil); A_arbace_go_escape_assign_list_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_87)); return A_arbace_go_escape__init_part1_A_const_86 }




















func A_arbace_go_escape__init_part1_A_Unit144__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1236, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_escape_reassigned_BANG__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_escape_reassigned_BANG__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_626, false, nil); A_arbace_go_escape_reassigned_BANG__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_89)); return A_arbace_go_escape__init_part1_A_const_88 }










func A_arbace_go_escape__init_part1_A_Unit145__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1247, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_escape_dcl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_escape_dcl_BANG__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_627, false, nil); A_arbace_go_escape_dcl_BANG__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_91)); return A_arbace_go_escape__init_part1_A_const_90 }



func A_arbace_go_escape__init_part1_A_Unit146__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1251, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_go_escape_dcl_obj_BANG__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_go_escape_dcl_obj_BANG__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_628, false, nil); A_arbace_go_escape_dcl_obj_BANG__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_93)); return A_arbace_go_escape__init_part1_A_const_92 }



func A_arbace_go_escape__init_part1_A_Unit147__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1255, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_go_escape_block_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_go_escape_block_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_629, false, nil); A_arbace_go_escape_block_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_95)); return A_arbace_go_escape__init_part1_A_const_94 }




func A_arbace_go_escape__init_part1_A_Unit148__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1260, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_go_escape_static_bool_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_go_escape_static_bool_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_630, false, nil); A_arbace_go_escape_static_bool_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_97)); return A_arbace_go_escape__init_part1_A_const_96 }






func A_arbace_go_escape__init_part1_A_Unit149__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1267, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_go_escape_terminates_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_go_escape_terminates_QMARK__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_631, false, nil); A_arbace_go_escape_terminates_QMARK__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_99)); return A_arbace_go_escape__init_part1_A_const_98 }













func A_arbace_go_escape__init_part1_A_Unit150__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1281, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_escape_live_stmts_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_escape_live_stmts_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_632, false, nil); A_arbace_go_escape_live_stmts_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_101)); return A_arbace_go_escape__init_part1_A_const_100 }













func A_arbace_go_escape__init_part1_A_Unit151__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1295, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_go_escape_stmts_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_go_escape_stmts_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_633, false, nil); A_arbace_go_escape_stmts_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_103)); return A_arbace_go_escape__init_part1_A_const_102 }





func A_arbace_go_escape__init_part1_A_Unit152__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1301, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_go_escape_decl_stmt_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_go_escape_decl_stmt_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_634, false, nil); A_arbace_go_escape_decl_stmt_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_105)); return A_arbace_go_escape__init_part1_A_const_104 }
















func A_arbace_go_escape__init_part1_A_Unit153__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1318, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_go_escape_loop_leaked_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_go_escape_loop_leaked_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_635, false, nil); A_arbace_go_escape_loop_leaked_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_107)); return A_arbace_go_escape__init_part1_A_const_106 }




























func A_arbace_go_escape__init_part1_A_Unit154__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1347, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_go_escape_range_stmt_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_go_escape_range_stmt_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_636, false, nil); A_arbace_go_escape_range_stmt_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_109)); return A_arbace_go_escape__init_part1_A_const_108 }

































func A_arbace_go_escape__init_part1_A_Unit155__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1381, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_go_escape_for_stmt_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_escape_for_stmt_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_637, false, nil); A_arbace_go_escape_for_stmt_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_111)); return A_arbace_go_escape__init_part1_A_const_110 }
































func A_arbace_go_escape__init_part1_A_Unit156__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1414, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_go_escape_type_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_go_escape_type_switch_stmt_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_638, false, nil); A_arbace_go_escape_type_switch_stmt_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_113)); return A_arbace_go_escape__init_part1_A_const_112 }
















func A_arbace_go_escape__init_part1_A_Unit157__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1431, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_go_escape_assign_stmt_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_go_escape_assign_stmt_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_639, false, nil); A_arbace_go_escape_assign_stmt_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_115)); return A_arbace_go_escape__init_part1_A_const_114 }










func A_arbace_go_escape__init_part1_A_Unit158__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1442, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_go_escape_return_stmt_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_go_escape_return_stmt_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_640, false, nil); A_arbace_go_escape_return_stmt_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_117)); return A_arbace_go_escape__init_part1_A_const_116 }











func A_arbace_go_escape__init_part1_A_Unit159__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1454, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_go_escape_stmt_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_go_escape_stmt_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_641, false, nil); A_arbace_go_escape_stmt_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_119)); return A_arbace_go_escape__init_part1_A_const_118 }


















































func A_arbace_go_escape__init_part1_A_Unit160__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1505, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_go_escape_label_states_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_go_escape_label_states_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_642, false, nil); A_arbace_go_escape_label_states_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_121)); return A_arbace_go_escape__init_part1_A_const_120 }















func A_arbace_go_escape__init_part1_A_Unit161__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1521, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_go_escape_walk_func_BANG__A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_go_escape_walk_func_BANG__A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_643, false, nil); A_arbace_go_escape_walk_func_BANG__A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_123)); return A_arbace_go_escape__init_part1_A_const_122 }






func A_arbace_go_escape__init_part1_A_Unit162__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1528, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_go_escape_flow_closure_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_go_escape_flow_closure_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_644, false, nil); A_arbace_go_escape_flow_closure_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_125)); return A_arbace_go_escape__init_part1_A_const_124 }















func A_arbace_go_escape__init_part1_A_Unit163__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1544, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_go_escape_init_func_BANG__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_go_escape_init_func_BANG__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_645, false, nil); A_arbace_go_escape_init_func_BANG__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_127)); return A_arbace_go_escape__init_part1_A_const_126 }








func A_arbace_go_escape__init_part1_A_Unit164__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1553, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_go_escape_outlives_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_go_escape_outlives_QMARK__A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_646, false, nil); A_arbace_go_escape_outlives_QMARK__A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_129)); return A_arbace_go_escape__init_part1_A_const_128 }













func A_arbace_go_escape__init_part1_A_Unit165__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1567, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_go_escape_leak_to_BANG__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_go_escape_leak_to_BANG__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_647, false, nil); A_arbace_go_escape_leak_to_BANG__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_131)); return A_arbace_go_escape__init_part1_A_const_130 }








func A_arbace_go_escape__init_part1_A_Unit166__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1576, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_go_escape_walk_one_BANG__A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_go_escape_walk_one_BANG__A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_648, false, nil); A_arbace_go_escape_walk_one_BANG__A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_133)); return A_arbace_go_escape__init_part1_A_const_132 }



















































func A_arbace_go_escape__init_part1_A_Unit167__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1628, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_go_escape_walk_all_BANG__A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_go_escape_walk_all_BANG__A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_649, false, nil); A_arbace_go_escape_walk_all_BANG__A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_135)); return A_arbace_go_escape__init_part1_A_const_134 }






















func A_arbace_go_escape__init_part1_A_Unit168__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1651, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_go_escape_report_leaks_BANG__A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_go_escape_report_leaks_BANG__A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_650, false, nil); A_arbace_go_escape_report_leaks_BANG__A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_137)); return A_arbace_go_escape__init_part1_A_const_136 }























func A_arbace_go_escape__init_part1_A_Unit169__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1675, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_go_escape_param_tag_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_go_escape_param_tag_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_651, false, nil); A_arbace_go_escape_param_tag_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_139)); return A_arbace_go_escape__init_part1_A_const_138 }



























func A_arbace_go_escape__init_part1_A_Unit170__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1703, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_go_escape_finish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_escape_finish_BANG__A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_652, false, nil); A_arbace_go_escape_finish_BANG__A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_141)); return A_arbace_go_escape__init_part1_A_const_140 }




























func A_arbace_go_escape__init_part1_A_Unit171__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1732, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_go_escape_literal_of_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_go_escape_literal_of_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_653, false, nil); A_arbace_go_escape_literal_of_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_143)); return A_arbace_go_escape__init_part1_A_const_142 }





func A_arbace_go_escape__init_part1_A_Unit172__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1738, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_go_escape_rewrite_with_literals_BANG__A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_go_escape_rewrite_with_literals_BANG__A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_654, false, nil); A_arbace_go_escape_rewrite_with_literals_BANG__A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_145)); return A_arbace_go_escape__init_part1_A_const_144 }




























func A_arbace_go_escape__init_part1_A_Unit173__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1767, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_go_escape_batch_BANG__A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_go_escape_batch_BANG__A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_655, false, nil); A_arbace_go_escape_batch_BANG__A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_147)); return A_arbace_go_escape__init_part1_A_const_146 }































func A_arbace_go_escape__init_part1_A_Unit174__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1799, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_go_escape_method_obj_data_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_go_escape_method_obj_data_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_656, false, nil); A_arbace_go_escape_method_obj_data_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_149)); return A_arbace_go_escape__init_part1_A_const_148 }




func A_arbace_go_escape__init_part1_A_Unit175__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1804, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_go_escape_iface_assignments_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_go_escape_iface_assignments_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_657, false, nil); A_arbace_go_escape_iface_assignments_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_151)); return A_arbace_go_escape__init_part1_A_const_150 }



































































func A_arbace_go_escape__init_part1_A_Unit176__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1872, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_go_escape_concrete_type_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_go_escape_concrete_type_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_658, false, nil); A_arbace_go_escape_concrete_type_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_153)); return A_arbace_go_escape__init_part1_A_const_152 }






































func A_arbace_go_escape__init_part1_A_Unit177__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1911, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_go_escape_devirt_call_A_New(); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_go_escape_devirt_call_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_659, false, nil); A_arbace_go_escape_devirt_call_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_155)); return A_arbace_go_escape__init_part1_A_const_154 }
































func A_arbace_go_escape__init_part1_A_Unit178__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1944, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__158 any = A_arbace_go_escape_devirtualize_A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_go_escape_devirtualize_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_660, false, nil); A_arbace_go_escape_devirtualize_A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_157)); return A_arbace_go_escape__init_part1_A_const_156 }






























func A_arbace_go_escape__init_part1_A_Unit179__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1975, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_go_escape_small_int_const_A_New(); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_go_escape_small_int_const_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_661, false, nil); A_arbace_go_escape_small_int_const_A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_159)); return A_arbace_go_escape__init_part1_A_const_158 }



func A_arbace_go_escape__init_part1_A_Unit180__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1979, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_go_escape_bounded_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_go_escape_bounded_QMARK__A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_662, false, nil); A_arbace_go_escape_bounded_QMARK__A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_161)); return A_arbace_go_escape__init_part1_A_const_160 }






































func A_arbace_go_escape__init_part1_A_Unit181__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2018, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_go_escape_bce_walk_BANG__A_New(); var tmp3 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_go_escape_bce_walk_BANG__A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_663, false, nil); A_arbace_go_escape_bce_walk_BANG__A_fn_class = fncls__163d; tmp3 = fncls__163d } else { tmp3 = fncls__163 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_163)); return A_arbace_go_escape__init_part1_A_const_162 }































func A_arbace_go_escape__init_part1_A_Unit182__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2050, 1); A_arbace_go_escape__init_part1_A_const_164.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_164; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_165)); return A_arbace_go_escape__init_part1_A_const_164.SetDynamic_Z__Var(true).Ref() }



func A_arbace_go_escape__init_part1_A_Unit183__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2054, 1); A_arbace_go_escape__init_part1_A_const_166.BindRoot_O__V(A_arbace_go_escape__init_part1_A_const_167); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_166; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_168)); return A_arbace_go_escape__init_part1_A_const_166 }
func A_arbace_go_escape__init_part1_A_Unit184__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2055, 1); A_arbace_go_escape__init_part1_A_const_169.BindRoot_O__V(A_arbace_go_escape__init_part1_A_const_170); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_169; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_171)); return A_arbace_go_escape__init_part1_A_const_169 }
func A_arbace_go_escape__init_part1_A_Unit185__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2056, 1); A_arbace_go_escape__init_part1_A_const_172.BindRoot_O__V(A_arbace_go_escape__init_part1_A_const_173); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_172; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_174)); return A_arbace_go_escape__init_part1_A_const_172 }
func A_arbace_go_escape__init_part1_A_Unit186__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2057, 1); A_arbace_go_escape__init_part1_A_const_175.BindRoot_O__V(A_arbace_go_escape__init_part1_A_const_176); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_175; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_177)); return A_arbace_go_escape__init_part1_A_const_175 }

func A_arbace_go_escape__init_part1_A_Unit187__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_178; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_179)); return A_arbace_go_escape__init_part1_A_const_178 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit188__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_180; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_181)); return A_arbace_go_escape__init_part1_A_const_180 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit189__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_182; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_183)); return A_arbace_go_escape__init_part1_A_const_182 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit190__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_184; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_185)); return A_arbace_go_escape__init_part1_A_const_184 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit191__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_186; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_187)); return A_arbace_go_escape__init_part1_A_const_186 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit192__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_188; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_189)); return A_arbace_go_escape__init_part1_A_const_188 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit193__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_190; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_191)); return A_arbace_go_escape__init_part1_A_const_190 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit194__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_192; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_193)); return A_arbace_go_escape__init_part1_A_const_192 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit195__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_194; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_195)); return A_arbace_go_escape__init_part1_A_const_194 }
//line :2059:1
func A_arbace_go_escape__init_part1_A_Unit196__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2059, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_196; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_197)); return A_arbace_go_escape__init_part1_A_const_196 }

func A_arbace_go_escape__init_part1_A_Unit197__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2061, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_198; var tmp2 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_go_escape_conv_nop_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_go_escape_conv_nop_QMARK__A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_664, false, nil); A_arbace_go_escape_conv_nop_QMARK__A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_198; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_199)); return A_arbace_go_escape__init_part1_A_const_198 }
















func A_arbace_go_escape__init_part1_A_Unit198__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2078, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_200; var tmp2 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_go_escape_param_local_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_go_escape_param_local_QMARK__A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_665, false, nil); A_arbace_go_escape_param_local_QMARK__A_fn_class = fncls__167d; tmp3 = fncls__167d } else { tmp3 = fncls__167 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part1_A_const_200; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_201)); return A_arbace_go_escape__init_part1_A_const_200 }




func A_arbace_go_escape__init_part1_A_Unit199__O() any { A_arbace_go_escape__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2083, 1); A_arbace_go_escape__init_part1_A_const_202.BindRoot_O__V(A_arbace_go_escape__init_part1_A_const_203); var tmp1 *lang.Var = A_arbace_go_escape__init_part1_A_const_202; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part1_A_const_204)); return A_arbace_go_escape__init_part1_A_const_202 }














func A_arbace_go_escape__init_part2_A_Unit200__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2098, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_0; var tmp2 any; var root_1 any = A_arbace_go_escape__init_part2_A_const_1.GetRawRoot__O(); var linked_2 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_3 lang.IFn; if

	linked_2 == nil { ifn_3 = lang.IFn_Cast(root_1) } else { ifn_3 = nil }; var arg_4 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_escape_fn__1896001203_A_New(); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_escape_fn__1896001203_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_668, false, nil); A_arbace_go_escape_fn__1896001203_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp4, nil); arg_4 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); if linked_2 == nil { tmp2 = ifn_3.Invoke_O__O(arg_4) } else { tmp2 = linked_2.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1, arg_4) }; var tmp5 any = tmp2; var tmp6 any; var root_7 any = /*line :2098:1*/A_arbace_go_escape__init_part2_A_const_1.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_9 lang.IFn; if




	linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any; var tmp7 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_escape_fn__1896001221_A_New(); var tmp8 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_escape_fn__1896001221_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_670, false, nil); A_arbace_go_escape_fn__1896001221_A_fn_class = fncls__11d; tmp8 = fncls__11d } else { tmp8 = fncls__11 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp8, nil); arg_10 = Up_Compiler_AOTFn_IFn(tmp7).Invoke__O(); if linked_8 == nil { tmp6 = ifn_9.Invoke_O__O(arg_10) } else { tmp6 = linked_8.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_7, arg_10) }; /*line :2098:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_667, tmp5, Lit_669, tmp6, Lit_161, A_arbace_go_escape__init_part2_A_const_2))); var tmp9 *lang.Var = A_arbace_go_escape__init_part2_A_const_0; tmp9.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_3)); return A_arbace_go_escape__init_part2_A_const_0 }
//line :2098:1
func A_arbace_go_escape__init_part2_A_Init__O() any { A_arbace_go_escape__init_part2_A_Init(); return nil }
//line :2098:1
func A_arbace_go_escape__init_part2_A_Load__O() any { A_arbace_go_escape__init_part2_A_Init(); A_arbace_go_escape__init_part2_A_Unit200__O(); A_arbace_go_escape__init_part2_A_Unit201__O(); A_arbace_go_escape__init_part2_A_Unit202__O(); A_arbace_go_escape__init_part2_A_Unit203__O(); A_arbace_go_escape__init_part2_A_Unit204__O(); A_arbace_go_escape__init_part2_A_Unit205__O(); A_arbace_go_escape__init_part2_A_Unit206__O(); A_arbace_go_escape__init_part2_A_Unit207__O(); A_arbace_go_escape__init_part2_A_Unit208__O(); A_arbace_go_escape__init_part2_A_Unit209__O(); A_arbace_go_escape__init_part2_A_Unit210__O(); A_arbace_go_escape__init_part2_A_Unit211__O(); A_arbace_go_escape__init_part2_A_Unit212__O(); A_arbace_go_escape__init_part2_A_Unit213__O(); A_arbace_go_escape__init_part2_A_Unit214__O(); A_arbace_go_escape__init_part2_A_Unit215__O(); A_arbace_go_escape__init_part2_A_Unit216__O(); A_arbace_go_escape__init_part2_A_Unit217__O(); A_arbace_go_escape__init_part2_A_Unit218__O(); A_arbace_go_escape__init_part2_A_Unit219__O(); A_arbace_go_escape__init_part2_A_Unit220__O(); A_arbace_go_escape__init_part2_A_Unit221__O(); A_arbace_go_escape__init_part2_A_Unit222__O(); A_arbace_go_escape__init_part2_A_Unit223__O(); A_arbace_go_escape__init_part2_A_Unit224__O(); A_arbace_go_escape__init_part2_A_Unit225__O(); A_arbace_go_escape__init_part2_A_Unit226__O(); A_arbace_go_escape__init_part2_A_Unit227__O(); A_arbace_go_escape__init_part2_A_Unit228__O(); A_arbace_go_escape__init_part2_A_Unit229__O(); A_arbace_go_escape__init_part2_A_Unit230__O(); A_arbace_go_escape__init_part2_A_Unit231__O(); A_arbace_go_escape__init_part2_A_Unit232__O(); A_arbace_go_escape__init_part2_A_Unit233__O(); A_arbace_go_escape__init_part2_A_Unit234__O(); A_arbace_go_escape__init_part2_A_Unit235__O(); A_arbace_go_escape__init_part2_A_Unit236__O(); A_arbace_go_escape__init_part2_A_Unit237__O(); A_arbace_go_escape__init_part2_A_Unit238__O(); A_arbace_go_escape__init_part2_A_Unit239__O(); A_arbace_go_escape__init_part2_A_Unit240__O(); A_arbace_go_escape__init_part2_A_Unit241__O(); A_arbace_go_escape__init_part2_A_Unit242__O(); A_arbace_go_escape__init_part2_A_Unit243__O(); A_arbace_go_escape__init_part2_A_Unit244__O(); A_arbace_go_escape__init_part2_A_Unit245__O(); A_arbace_go_escape__init_part2_A_Unit246__O(); A_arbace_go_escape__init_part2_A_Unit247__O(); A_arbace_go_escape__init_part2_A_Unit248__O(); A_arbace_go_escape__init_part2_A_Unit249__O(); A_arbace_go_escape__init_part2_A_Unit250__O(); A_arbace_go_escape__init_part2_A_Unit251__O(); A_arbace_go_escape__init_part2_A_Unit252__O(); A_arbace_go_escape__init_part2_A_Unit253__O(); A_arbace_go_escape__init_part2_A_Unit254__O(); A_arbace_go_escape__init_part2_A_Unit255__O(); A_arbace_go_escape__init_part2_A_Unit256__O(); A_arbace_go_escape__init_part2_A_Unit257__O(); A_arbace_go_escape__init_part2_A_Unit258__O(); A_arbace_go_escape__init_part2_A_Unit259__O(); A_arbace_go_escape__init_part2_A_Unit260__O(); A_arbace_go_escape__init_part2_A_Unit261__O(); A_arbace_go_escape__init_part2_A_Unit262__O(); A_arbace_go_escape__init_part2_A_Unit263__O(); return nil }









func A_arbace_go_escape__init_part2_A_Unit201__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2108, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_escape_fn_pkg_name_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_escape_fn_pkg_name_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_671, false, nil); A_arbace_go_escape_fn_pkg_name_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_5)); return A_arbace_go_escape__init_part2_A_const_4 }






func A_arbace_go_escape__init_part2_A_Unit202__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2115, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_escape_cheap_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_escape_cheap_call_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_672, false, nil); A_arbace_go_escape_cheap_call_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_7)); return A_arbace_go_escape__init_part2_A_const_6 }




func A_arbace_go_escape__init_part2_A_Unit203__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2120, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_escape_intrinsic_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_escape_intrinsic_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_673, false, nil); A_arbace_go_escape_intrinsic_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_9)); return A_arbace_go_escape__init_part2_A_const_8 }





func A_arbace_go_escape__init_part2_A_Unit204__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2126, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_escape_hairy_cost_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_escape_hairy_cost_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_674, false, nil); A_arbace_go_escape_hairy_cost_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_11)); return A_arbace_go_escape__init_part2_A_const_10 }
































































































































func A_arbace_go_escape__init_part2_A_Unit205__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2255, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_escape_field_offset_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_escape_field_offset_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_675, false, nil); A_arbace_go_escape_field_offset_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_13)); return A_arbace_go_escape__init_part2_A_const_12 }










func A_arbace_go_escape__init_part2_A_Unit206__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2266, 1); A_arbace_go_escape__init_part2_A_const_14.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_15)); return A_arbace_go_escape__init_part2_A_const_14.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_escape__init_part2_A_Unit207__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2271, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_escape_max_cost_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_escape_max_cost_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_676, false, nil); A_arbace_go_escape_max_cost_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_17)); return A_arbace_go_escape__init_part2_A_const_16 }






func A_arbace_go_escape__init_part2_A_Unit208__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2278, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_escape_call_str2_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_escape_call_str2_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_677, false, nil); A_arbace_go_escape_call_str2_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_19)); return A_arbace_go_escape__init_part2_A_const_18 }













func A_arbace_go_escape__init_part2_A_Unit209__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2292, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_21)); return A_arbace_go_escape__init_part2_A_const_20 }

func A_arbace_go_escape__init_part2_A_Unit210__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2294, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_escape_stmts_str_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_escape_stmts_str_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_678, false, nil); A_arbace_go_escape_stmts_str_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_23)); return A_arbace_go_escape__init_part2_A_const_22 }


func A_arbace_go_escape__init_part2_A_Unit211__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2297, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_escape_stmt_str_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_escape_stmt_str_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_679, false, nil); A_arbace_go_escape_stmt_str_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_24)); return A_arbace_go_escape__init_part2_A_const_20 }

























func A_arbace_go_escape__init_part2_A_Unit212__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2323, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_escape_big_func_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_escape_big_func_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_680, false, nil); A_arbace_go_escape_big_func_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_26)); return A_arbace_go_escape__init_part2_A_const_25 }












func A_arbace_go_escape__init_part2_A_Unit213__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2336, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_go_escape_can_inline_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_go_escape_can_inline_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_681, false, nil); A_arbace_go_escape_can_inline_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_28)); return A_arbace_go_escape__init_part2_A_const_27 }





































func A_arbace_go_escape__init_part2_A_Unit214__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2374, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_go_escape_inl_callee_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_go_escape_inl_callee_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_682, false, nil); A_arbace_go_escape_inl_callee_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_30)); return A_arbace_go_escape__init_part2_A_const_29 }




















func A_arbace_go_escape__init_part2_A_Unit215__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2395, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_go_escape_copy_body_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_escape_copy_body_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_683, false, nil); A_arbace_go_escape_copy_body_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_32)); return A_arbace_go_escape__init_part2_A_const_31 }


































func A_arbace_go_escape__init_part2_A_Unit216__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2430, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_go_escape_register_copies_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_go_escape_register_copies_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_684, false, nil); A_arbace_go_escape_register_copies_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_34)); return A_arbace_go_escape__init_part2_A_const_33 }




















func A_arbace_go_escape__init_part2_A_Unit217__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2451, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_go_escape_returns__GT_assigns_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_go_escape_returns__GT_assigns_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_685, false, nil); A_arbace_go_escape_returns__GT_assigns_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_36)); return A_arbace_go_escape__init_part2_A_const_35 }





















func A_arbace_go_escape__init_part2_A_Unit218__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2473, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_go_escape_inline_calls_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_go_escape_inline_calls_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_686, false, nil); A_arbace_go_escape_inline_calls_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_38)); return A_arbace_go_escape__init_part2_A_const_37 }
















































func A_arbace_go_escape__init_part2_A_Unit219__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2522, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_go_escape_try_inline_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_go_escape_try_inline_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_687, false, nil); A_arbace_go_escape_try_inline_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_40)); return A_arbace_go_escape__init_part2_A_const_39 }






























































func A_arbace_go_escape__init_part2_A_Unit220__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2585, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_41; var tmp2 any; var root_47 any = A_arbace_go_escape__init_part2_A_const_42.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_go_escape__init_part2_A_const_43; if linked_48 == nil { tmp2 = ifn_49.Invoke_O__O(arg_50) } else { tmp2 = linked_48.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_47, arg_50) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_escape__init_part2_A_const_41; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_44)); return A_arbace_go_escape__init_part2_A_const_41 }

func A_arbace_go_escape__init_part2_A_Unit221__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2587, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_go_escape_bloop_tmp_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_go_escape_bloop_tmp_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_688, false, nil); A_arbace_go_escape_bloop_tmp_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_46)); return A_arbace_go_escape__init_part2_A_const_45 }


func A_arbace_go_escape__init_part2_A_Unit222__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2590, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_go_escape_bloop_name_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_go_escape_bloop_name_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_689, false, nil); A_arbace_go_escape_bloop_name_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_48)); return A_arbace_go_escape__init_part2_A_const_47 }










func A_arbace_go_escape__init_part2_A_Unit223__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2601, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_go_escape_addressable_name_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_go_escape_addressable_name_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_690, false, nil); A_arbace_go_escape_addressable_name_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_50)); return A_arbace_go_escape__init_part2_A_const_49 }





func A_arbace_go_escape__init_part2_A_Unit224__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2607, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_go_escape_bloop_kept_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_go_escape_bloop_kept_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_691, false, nil); A_arbace_go_escape_bloop_kept_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_52)); return A_arbace_go_escape__init_part2_A_const_51 }



func A_arbace_go_escape__init_part2_A_Unit225__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2611, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_go_escape_keep_alive_calls_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_go_escape_keep_alive_calls_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_692, false, nil); A_arbace_go_escape_keep_alive_calls_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_54)); return A_arbace_go_escape__init_part2_A_const_53 }








func A_arbace_go_escape__init_part2_A_Unit226__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2620, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_go_escape_keep_alive_nodes_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_go_escape_keep_alive_nodes_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_693, false, nil); A_arbace_go_escape_keep_alive_nodes_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_56)); return A_arbace_go_escape__init_part2_A_const_55 }








func A_arbace_go_escape__init_part2_A_Unit227__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2629, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_go_escape_preserve_stmt_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_go_escape_preserve_stmt_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_694, false, nil); A_arbace_go_escape_preserve_stmt_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_58)); return A_arbace_go_escape__init_part2_A_const_57 }


















































func A_arbace_go_escape__init_part2_A_Unit228__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2680, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_go_escape_preserve_stmts_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_go_escape_preserve_stmts_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_695, false, nil); A_arbace_go_escape_preserve_stmts_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_60)); return A_arbace_go_escape__init_part2_A_const_59 }

func A_arbace_go_escape__init_part2_A_Unit229__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2682, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_go_escape_b_loop_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_go_escape_b_loop_QMARK__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_696, false, nil); A_arbace_go_escape_b_loop_QMARK__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_62)); return A_arbace_go_escape__init_part2_A_const_61 }






func A_arbace_go_escape__init_part2_A_Unit230__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2689, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_go_escape_bloop_walk_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_go_escape_bloop_walk_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_697, false, nil); A_arbace_go_escape_bloop_walk_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_64)); return A_arbace_go_escape__init_part2_A_const_63 }































func A_arbace_go_escape__init_part2_A_Unit231__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2721, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_go_escape_scan_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_go_escape_scan_fn_BANG__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_698, false, nil); A_arbace_go_escape_scan_fn_BANG__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_66)); return A_arbace_go_escape__init_part2_A_const_65 }





















































































func A_arbace_go_escape__init_part2_A_Unit232__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2807, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_go_escape_closure_vars_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_go_escape_closure_vars_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_699, false, nil); A_arbace_go_escape_closure_vars_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_68)); return A_arbace_go_escape__init_part2_A_const_67 }

















func A_arbace_go_escape__init_part2_A_Unit233__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2825, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_go_escape_all_fns_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_go_escape_all_fns_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_700, false, nil); A_arbace_go_escape_all_fns_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_70)); return A_arbace_go_escape__init_part2_A_const_69 }

func A_arbace_go_escape__init_part2_A_Unit234__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2827, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_go_escape_bottom_up_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_go_escape_bottom_up_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_701, false, nil); A_arbace_go_escape_bottom_up_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_72)); return A_arbace_go_escape__init_part2_A_const_71 }












































func A_arbace_go_escape__init_part2_A_Unit235__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2872, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_go_escape_method_base_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_go_escape_method_base_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_702, false, nil); A_arbace_go_escape_method_base_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_74)); return A_arbace_go_escape__init_part2_A_const_73 }









func A_arbace_go_escape__init_part2_A_Unit236__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2882, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_go_escape_static_init_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_go_escape_static_init_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_703, false, nil); A_arbace_go_escape_static_init_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_76)); return A_arbace_go_escape__init_part2_A_const_75 }


















func A_arbace_go_escape__init_part2_A_Unit237__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2901, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_go_escape_dynamic_parts_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_go_escape_dynamic_parts_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_704, false, nil); A_arbace_go_escape_dynamic_parts_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_78)); return A_arbace_go_escape__init_part2_A_const_77 }














func A_arbace_go_escape__init_part2_A_Unit238__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2916, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_go_escape_const_eq_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_go_escape_const_eq_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_705, false, nil); A_arbace_go_escape_const_eq_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_80)); return A_arbace_go_escape__init_part2_A_const_79 }





func A_arbace_go_escape__init_part2_A_Unit239__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2922, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_go_escape_prune_switches_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_go_escape_prune_switches_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_706, false, nil); A_arbace_go_escape_prune_switches_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_82)); return A_arbace_go_escape__init_part2_A_const_81 }



























func A_arbace_go_escape__init_part2_A_Unit240__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2950, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_go_escape_fn_name_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_go_escape_fn_name_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_707, false, nil); A_arbace_go_escape_fn_name_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_84)); return A_arbace_go_escape__init_part2_A_const_83 }







func A_arbace_go_escape__init_part2_A_Unit241__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2958, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_go_escape_base_type_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_go_escape_base_type_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_708, false, nil); A_arbace_go_escape_base_type_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_86)); return A_arbace_go_escape__init_part2_A_const_85 }






func A_arbace_go_escape__init_part2_A_Unit242__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2965, 1); A_arbace_go_escape__init_part2_A_const_87.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_88)); return A_arbace_go_escape__init_part2_A_const_87.SetDynamic_Z__Var(true).Ref() }






func A_arbace_go_escape__init_part2_A_Unit243__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2972, 1); A_arbace_go_escape__init_part2_A_const_89.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_90)); return A_arbace_go_escape__init_part2_A_const_89.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_escape__init_part2_A_Unit244__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2977, 1); A_arbace_go_escape__init_part2_A_const_91.BindRoot_O__V(Lit_709); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_91; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_92)); return A_arbace_go_escape__init_part2_A_const_91 }



func A_arbace_go_escape__init_part2_A_Unit245__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2981, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_93; var tmp2 any; var root_93 any = A_arbace_go_escape__init_part2_A_const_42.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_95 lang.IFn; if

	linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_94 == nil { tmp2 = ifn_95.Invoke_O__O(arg_96) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_93, arg_96) }; /*line :2981:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_escape__init_part2_A_const_93; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_94)); return A_arbace_go_escape__init_part2_A_const_93 }



func A_arbace_go_escape__init_part2_A_Unit246__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2985, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_95; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_96)); return A_arbace_go_escape__init_part2_A_const_95 }

func A_arbace_go_escape__init_part2_A_Unit247__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2987, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_97; var tmp2 any; var root_97 any = A_arbace_go_escape__init_part2_A_const_42.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; if linked_98 == nil { tmp2 = ifn_99.Invoke_O__O(arg_100) } else { tmp2 = linked_98.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_97, arg_100) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_escape__init_part2_A_const_97; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_98)); return A_arbace_go_escape__init_part2_A_const_97 }

func A_arbace_go_escape__init_part2_A_Unit248__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2989, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_escape_std_result_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_escape_std_result_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_710, false, nil); A_arbace_go_escape_std_result_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_100)); return A_arbace_go_escape__init_part2_A_const_99 }
























func A_arbace_go_escape__init_part2_A_Unit249__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3014, 1); A_arbace_go_escape__init_part2_A_const_101.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_101; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_102)); return A_arbace_go_escape__init_part2_A_const_101.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_escape__init_part2_A_Unit250__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3019, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_103; var tmp2 any; var root_103 any = A_arbace_go_escape__init_part2_A_const_42.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_105 lang.IFn; if


	linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_104 == nil { tmp2 = ifn_105.Invoke_O__O(arg_106) } else { tmp2 = linked_104.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_103, arg_106) }; /*line :3019:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_go_escape__init_part2_A_const_103; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_104)); return A_arbace_go_escape__init_part2_A_const_103.SetDynamic_Z__Var(true).Ref() }




func A_arbace_go_escape__init_part2_A_Unit251__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3024, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_go_escape_foreign_body_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_go_escape_foreign_body_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_711, false, nil); A_arbace_go_escape_foreign_body_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_106)); return A_arbace_go_escape__init_part2_A_const_105 }


















func A_arbace_go_escape__init_part2_A_Unit252__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3043, 1); A_arbace_go_escape__init_part2_A_const_107.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_107; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_108)); return A_arbace_go_escape__init_part2_A_const_107.SetDynamic_Z__Var(true).Ref() }





func A_arbace_go_escape__init_part2_A_Unit253__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3049, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_go_escape_forms_digest_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_go_escape_forms_digest_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_712, false, nil); A_arbace_go_escape_forms_digest_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_110)); return A_arbace_go_escape__init_part2_A_const_109 }








func A_arbace_go_escape__init_part2_A_Unit254__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3058, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_go_escape_load_package_tags_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_go_escape_load_package_tags_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_713, false, nil); A_arbace_go_escape_load_package_tags_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_112)); return A_arbace_go_escape__init_part2_A_const_111 }





















































func A_arbace_go_escape__init_part2_A_Unit255__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3112, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_go_escape_std_imports_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_go_escape_std_imports_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_714, false, nil); A_arbace_go_escape_std_imports_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_114)); return A_arbace_go_escape__init_part2_A_const_113 }











func A_arbace_go_escape__init_part2_A_Unit256__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3124, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_go_escape_warm_order_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_go_escape_warm_order_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_715, false, nil); A_arbace_go_escape_warm_order_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_116)); return A_arbace_go_escape__init_part2_A_const_115 }




















func A_arbace_go_escape__init_part2_A_Unit257__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3145, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_go_escape_warm_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_go_escape_warm_package_BANG__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_716, false, nil); A_arbace_go_escape_warm_package_BANG__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_118)); return A_arbace_go_escape__init_part2_A_const_117 }





func A_arbace_go_escape__init_part2_A_Unit258__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3151, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_go_escape_foreign_fn_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_go_escape_foreign_fn_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_717, false, nil); A_arbace_go_escape_foreign_fn_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_120)); return A_arbace_go_escape__init_part2_A_const_119 }



















func A_arbace_go_escape__init_part2_A_Unit259__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3171, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_go_escape_analyze_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_go_escape_analyze_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_718, false, nil); A_arbace_go_escape_analyze_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_122)); return A_arbace_go_escape__init_part2_A_const_121 }








func A_arbace_go_escape__init_part2_A_Unit260__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3180, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_go_escape_static_inlined_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_go_escape_static_inlined_QMARK__A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_719, false, nil); A_arbace_go_escape_static_inlined_QMARK__A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_124)); return A_arbace_go_escape__init_part2_A_const_123 }

func A_arbace_go_escape__init_part2_A_Unit261__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3182, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_go_escape_static_inlined_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_go_escape_static_inlined_call_QMARK__A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_720, false, nil); A_arbace_go_escape_static_inlined_call_QMARK__A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_126)); return A_arbace_go_escape__init_part2_A_const_125 }




















func A_arbace_go_escape__init_part2_A_Unit262__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3203, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_go_escape_inline_package_BANG__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_go_escape_inline_package_BANG__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_721, false, nil); A_arbace_go_escape_inline_package_BANG__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_128)); return A_arbace_go_escape__init_part2_A_const_127 }





















































func A_arbace_go_escape__init_part2_A_Unit263__O() any { A_arbace_go_escape__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3257, 1); var tmp1 *lang.Var = A_arbace_go_escape__init_part2_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_go_escape_analyze_package_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_go_escape_analyze_package_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_722, false, nil); A_arbace_go_escape_analyze_package_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_escape__init_part2_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_escape__init_part2_A_const_129)); return A_arbace_go_escape__init_part2_A_const_95 }



type A_arbace_go_escape__init_A struct{ jrt.Object }

func A_arbace_go_escape__init_A_New() *A_arbace_go_escape__init_A { t := &A_arbace_go_escape__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_escape__init_A) Ctor() {}

func (t *A_arbace_go_escape__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_escape__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_escape__init_A_class }

func (t *A_arbace_go_escape__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_escape__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_escape__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_escape__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_escape__init_A); return ok }

func A_arbace_go_escape__init_A_Cast(x any) *A_arbace_go_escape__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_escape__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_escape__init_A_class)) }; return v }



type A_arbace_go_escape__init_part0_A struct{ jrt.Object }

var A_arbace_go_escape__init_part0_A_const_pool *jrt.RefArray

var A_arbace_go_escape__init_part0_A_const_0 *lang.Var

var A_arbace_go_escape__init_part0_A_const_1 any

var A_arbace_go_escape__init_part0_A_const_2 any

var A_arbace_go_escape__init_part0_A_const_3 any

var A_arbace_go_escape__init_part0_A_const_4 *lang.Var

var A_arbace_go_escape__init_part0_A_const_5 any

var A_arbace_go_escape__init_part0_A_const_6 any

var A_arbace_go_escape__init_part0_A_const_7 *lang.Var

var A_arbace_go_escape__init_part0_A_const_8 any

var A_arbace_go_escape__init_part0_A_const_9 any

var A_arbace_go_escape__init_part0_A_const_10 *lang.Var

var A_arbace_go_escape__init_part0_A_const_11 any

var A_arbace_go_escape__init_part0_A_const_12 *lang.Var

var A_arbace_go_escape__init_part0_A_const_13 any

var A_arbace_go_escape__init_part0_A_const_14 *lang.Var

var A_arbace_go_escape__init_part0_A_const_15 any

var A_arbace_go_escape__init_part0_A_const_16 *lang.Var

var A_arbace_go_escape__init_part0_A_const_17 any

var A_arbace_go_escape__init_part0_A_const_18 *lang.Var

var A_arbace_go_escape__init_part0_A_const_19 any

var A_arbace_go_escape__init_part0_A_const_20 *lang.Var

var A_arbace_go_escape__init_part0_A_const_21 any

var A_arbace_go_escape__init_part0_A_const_22 *lang.Var

var A_arbace_go_escape__init_part0_A_const_23 any

var A_arbace_go_escape__init_part0_A_const_24 *lang.Var

var A_arbace_go_escape__init_part0_A_const_25 any

var A_arbace_go_escape__init_part0_A_const_26 *lang.Var

var A_arbace_go_escape__init_part0_A_const_27 any

var A_arbace_go_escape__init_part0_A_const_28 *lang.Var

var A_arbace_go_escape__init_part0_A_const_29 any

var A_arbace_go_escape__init_part0_A_const_30 *lang.Var

var A_arbace_go_escape__init_part0_A_const_31 any

var A_arbace_go_escape__init_part0_A_const_32 *lang.Var

var A_arbace_go_escape__init_part0_A_const_33 any

var A_arbace_go_escape__init_part0_A_const_34 *lang.Var

var A_arbace_go_escape__init_part0_A_const_35 any

var A_arbace_go_escape__init_part0_A_const_36 *lang.Var

var A_arbace_go_escape__init_part0_A_const_37 any

var A_arbace_go_escape__init_part0_A_const_38 *lang.Var

var A_arbace_go_escape__init_part0_A_const_39 any

var A_arbace_go_escape__init_part0_A_const_40 *lang.Var

var A_arbace_go_escape__init_part0_A_const_41 any

var A_arbace_go_escape__init_part0_A_const_42 any

var A_arbace_go_escape__init_part0_A_const_43 *lang.Var

var A_arbace_go_escape__init_part0_A_const_44 any

var A_arbace_go_escape__init_part0_A_const_45 *lang.Var

var A_arbace_go_escape__init_part0_A_const_46 any

var A_arbace_go_escape__init_part0_A_const_47 *lang.Var

var A_arbace_go_escape__init_part0_A_const_48 any

var A_arbace_go_escape__init_part0_A_const_49 *lang.Var

var A_arbace_go_escape__init_part0_A_const_50 any

var A_arbace_go_escape__init_part0_A_const_51 any

var A_arbace_go_escape__init_part0_A_const_52 *lang.Var

var A_arbace_go_escape__init_part0_A_const_53 any

var A_arbace_go_escape__init_part0_A_const_54 *lang.Var

var A_arbace_go_escape__init_part0_A_const_55 any

var A_arbace_go_escape__init_part0_A_const_56 any

var A_arbace_go_escape__init_part0_A_const_57 *lang.Var

var A_arbace_go_escape__init_part0_A_const_58 any

var A_arbace_go_escape__init_part0_A_const_59 any

var A_arbace_go_escape__init_part0_A_const_60 *lang.Var

var A_arbace_go_escape__init_part0_A_const_61 any

var A_arbace_go_escape__init_part0_A_const_62 any

var A_arbace_go_escape__init_part0_A_const_63 *lang.Var

var A_arbace_go_escape__init_part0_A_const_64 any

var A_arbace_go_escape__init_part0_A_const_65 *lang.Var

var A_arbace_go_escape__init_part0_A_const_66 any

var A_arbace_go_escape__init_part0_A_const_67 *lang.Var

var A_arbace_go_escape__init_part0_A_const_68 any

var A_arbace_go_escape__init_part0_A_const_69 *lang.Var

var A_arbace_go_escape__init_part0_A_const_70 any

var A_arbace_go_escape__init_part0_A_const_71 any

var A_arbace_go_escape__init_part0_A_const_72 *lang.Var

var A_arbace_go_escape__init_part0_A_const_73 any

var A_arbace_go_escape__init_part0_A_const_74 any

var A_arbace_go_escape__init_part0_A_const_75 *lang.Var

var A_arbace_go_escape__init_part0_A_const_76 any

var A_arbace_go_escape__init_part0_A_const_77 *lang.Var

var A_arbace_go_escape__init_part0_A_const_78 any

var A_arbace_go_escape__init_part0_A_const_79 *lang.Var

var A_arbace_go_escape__init_part0_A_const_80 any

var A_arbace_go_escape__init_part0_A_const_81 *lang.Var

var A_arbace_go_escape__init_part0_A_const_82 any

var A_arbace_go_escape__init_part0_A_const_83 *lang.Var

var A_arbace_go_escape__init_part0_A_const_84 any

var A_arbace_go_escape__init_part0_A_const_85 *lang.Var

var A_arbace_go_escape__init_part0_A_const_86 any

var A_arbace_go_escape__init_part0_A_const_87 *lang.Var

var A_arbace_go_escape__init_part0_A_const_88 any

var A_arbace_go_escape__init_part0_A_const_89 *lang.Var

var A_arbace_go_escape__init_part0_A_const_90 any

var A_arbace_go_escape__init_part0_A_const_91 *lang.Var

var A_arbace_go_escape__init_part0_A_const_92 any

var A_arbace_go_escape__init_part0_A_const_93 *lang.Var

var A_arbace_go_escape__init_part0_A_const_94 any

var A_arbace_go_escape__init_part0_A_const_95 *lang.Var

var A_arbace_go_escape__init_part0_A_const_96 any

var A_arbace_go_escape__init_part0_A_const_97 *lang.Var

var A_arbace_go_escape__init_part0_A_const_98 any

var A_arbace_go_escape__init_part0_A_const_99 *lang.Var

var A_arbace_go_escape__init_part0_A_const_100 any

var A_arbace_go_escape__init_part0_A_const_101 *lang.Var

var A_arbace_go_escape__init_part0_A_const_102 any

var A_arbace_go_escape__init_part0_A_const_103 *lang.Var

var A_arbace_go_escape__init_part0_A_const_104 any

var A_arbace_go_escape__init_part0_A_const_105 *lang.Var

var A_arbace_go_escape__init_part0_A_const_106 any

var A_arbace_go_escape__init_part0_A_const_107 *lang.Var

var A_arbace_go_escape__init_part0_A_const_108 any

var A_arbace_go_escape__init_part0_A_const_109 *lang.Var

var A_arbace_go_escape__init_part0_A_const_110 any

var A_arbace_go_escape__init_part0_A_const_111 *lang.Var

var A_arbace_go_escape__init_part0_A_const_112 any

var A_arbace_go_escape__init_part0_A_const_113 *lang.Var

var A_arbace_go_escape__init_part0_A_const_114 any

var A_arbace_go_escape__init_part0_A_const_115 *lang.Var

var A_arbace_go_escape__init_part0_A_const_116 any

var A_arbace_go_escape__init_part0_A_const_117 *lang.Var

var A_arbace_go_escape__init_part0_A_const_118 any

var A_arbace_go_escape__init_part0_A_const_119 *lang.Var

var A_arbace_go_escape__init_part0_A_const_120 any

var A_arbace_go_escape__init_part0_A_const_121 *lang.Var

var A_arbace_go_escape__init_part0_A_const_122 any

var A_arbace_go_escape__init_part0_A_const_123 *lang.Var

var A_arbace_go_escape__init_part0_A_const_124 any

var A_arbace_go_escape__init_part0_A_const_125 *lang.Var

var A_arbace_go_escape__init_part0_A_const_126 any

var A_arbace_go_escape__init_part0_A_const_127 *lang.Var

var A_arbace_go_escape__init_part0_A_const_128 any

var A_arbace_go_escape__init_part0_A_const_129 *lang.Var

var A_arbace_go_escape__init_part0_A_const_130 any

var A_arbace_go_escape__init_part0_A_const_131 *lang.Var

var A_arbace_go_escape__init_part0_A_const_132 any

var A_arbace_go_escape__init_part0_A_const_133 *lang.Var

var A_arbace_go_escape__init_part0_A_const_134 any

var A_arbace_go_escape__init_part0_A_const_135 *lang.Var

var A_arbace_go_escape__init_part0_A_const_136 any

var A_arbace_go_escape__init_part0_A_const_137 *lang.Var

var A_arbace_go_escape__init_part0_A_const_138 any

var A_arbace_go_escape__init_part0_A_const_139 *lang.Var

var A_arbace_go_escape__init_part0_A_const_140 any

var A_arbace_go_escape__init_part0_A_const_141 *lang.Var

var A_arbace_go_escape__init_part0_A_const_142 any

var A_arbace_go_escape__init_part0_A_const_143 *lang.Var

var A_arbace_go_escape__init_part0_A_const_144 any

var A_arbace_go_escape__init_part0_A_const_145 *lang.Var

var A_arbace_go_escape__init_part0_A_const_146 any

var A_arbace_go_escape__init_part0_A_const_147 *lang.Var

var A_arbace_go_escape__init_part0_A_const_148 any

var A_arbace_go_escape__init_part0_A_const_149 *lang.Var

var A_arbace_go_escape__init_part0_A_const_150 any

var A_arbace_go_escape__init_part0_A_const_151 *lang.Var

var A_arbace_go_escape__init_part0_A_const_152 any

var A_arbace_go_escape__init_part0_A_const_153 *lang.Var

var A_arbace_go_escape__init_part0_A_const_154 any

var A_arbace_go_escape__init_part0_A_const_155 *lang.Var

var A_arbace_go_escape__init_part0_A_const_156 any

var A_arbace_go_escape__init_part0_A_const_157 any

var A_arbace_go_escape__init_part0_A_const_158 *lang.Var

var A_arbace_go_escape__init_part0_A_const_159 any

var A_arbace_go_escape__init_part0_A_const_160 any

var A_arbace_go_escape__init_part0_A_const_161 *lang.Var

var A_arbace_go_escape__init_part0_A_const_162 any

var A_arbace_go_escape__init_part0_A_const_163 *lang.Var

var A_arbace_go_escape__init_part0_A_const_164 any

var A_arbace_go_escape__init_part0_A_const_165 *lang.Var

var A_arbace_go_escape__init_part0_A_const_166 any

var A_arbace_go_escape__init_part0_A_const_167 *lang.Var

var A_arbace_go_escape__init_part0_A_const_168 any

var A_arbace_go_escape__init_part0_A_const_169 any

var A_arbace_go_escape__init_part0_A_const_170 *lang.Var

var A_arbace_go_escape__init_part0_A_const_171 any

var A_arbace_go_escape__init_part0_A_const_172 *lang.Var

var A_arbace_go_escape__init_part0_A_const_173 any

var A_arbace_go_escape__init_part0_A_const_174 *lang.Var

var A_arbace_go_escape__init_part0_A_const_175 any

var A_arbace_go_escape__init_part0_A_const_176 *lang.Var

var A_arbace_go_escape__init_part0_A_const_177 any

var A_arbace_go_escape__init_part0_A_const_178 *lang.Var

var A_arbace_go_escape__init_part0_A_const_179 any

var A_arbace_go_escape__init_part0_A_const_180 *lang.Var

var A_arbace_go_escape__init_part0_A_const_181 any

var A_arbace_go_escape__init_part0_A_const_182 *lang.Var

var A_arbace_go_escape__init_part0_A_const_183 any

var A_arbace_go_escape__init_part0_A_const_184 *lang.Var

var A_arbace_go_escape__init_part0_A_const_185 any

var A_arbace_go_escape__init_part0_A_const_186 *lang.Var

var A_arbace_go_escape__init_part0_A_const_187 any

var A_arbace_go_escape__init_part0_A_const_188 *lang.Var

var A_arbace_go_escape__init_part0_A_const_189 any

var A_arbace_go_escape__init_part0_A_const_190 *lang.Var

var A_arbace_go_escape__init_part0_A_const_191 any

var A_arbace_go_escape__init_part0_A_const_192 *lang.Var

var A_arbace_go_escape__init_part0_A_const_193 any

var A_arbace_go_escape__init_part0_A_const_194 *lang.Var

var A_arbace_go_escape__init_part0_A_const_195 any

var A_arbace_go_escape__init_part0_A_const_196 *lang.Var

var A_arbace_go_escape__init_part0_A_const_197 any

var A_arbace_go_escape__init_part0_A_const_198 *lang.Var

var A_arbace_go_escape__init_part0_A_const_199 any

var A_arbace_go_escape__init_part0_A_const_200 *lang.Var

var A_arbace_go_escape__init_part0_A_const_201 any

var A_arbace_go_escape__init_part0_A_const_202 *lang.Var

var A_arbace_go_escape__init_part0_A_const_203 any

var A_arbace_go_escape__init_part0_A_init jrt.ClassInit

func A_arbace_go_escape__init_part0_A_Init() { if !A_arbace_go_escape__init_part0_A_init.Done() { A_arbace_go_escape__init_part0_A_init.Run(A_arbace_go_escape__init_part0_A_clinit) } }

func A_arbace_go_escape__init_part0_A_clinit() { A_arbace_go_escape__init_part0_A_clinit_p0(); A_arbace_go_escape__init_part0_A_clinit_p1(); A_arbace_go_escape__init_part0_A_clinit_p2(); A_arbace_go_escape__init_part0_A_clinit_p3(); A_arbace_go_escape__init_part0_A_clinit_p4(); A_arbace_go_escape__init_part0_A_clinit_p5(); A_arbace_go_escape__init_part0_A_clinit_p6(); A_arbace_go_escape__init_part0_A_clinit_p7(); A_arbace_go_escape__init_part0_A_clinit_p8(); A_arbace_go_escape__init_part0_A_clinit_p9(); A_arbace_go_escape__init_part0_A_clinit_p10(); A_arbace_go_escape__init_part0_A_clinit_p11(); A_arbace_go_escape__init_part0_A_clinit_p12(); A_arbace_go_escape__init_part0_A_clinit_p13(); A_arbace_go_escape__init_part0_A_clinit_p14(); A_arbace_go_escape__init_part0_A_clinit_p15() }

func A_arbace_go_escape__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_escape__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_515, 273); A_arbace_go_escape__init_part0_A_const_0 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[69]); A_arbace_go_escape__init_part0_A_const_1 = A_arbace_go_escape__init_part0_A_const_pool.A[70]; A_arbace_go_escape__init_part0_A_const_2 = A_arbace_go_escape__init_part0_A_const_pool.A[71]; A_arbace_go_escape__init_part0_A_const_3 = A_arbace_go_escape__init_part0_A_const_pool.A[72]; A_arbace_go_escape__init_part0_A_const_4 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[73]); A_arbace_go_escape__init_part0_A_const_5 = A_arbace_go_escape__init_part0_A_const_pool.A[74]; A_arbace_go_escape__init_part0_A_const_6 = A_arbace_go_escape__init_part0_A_const_pool.A[75]; A_arbace_go_escape__init_part0_A_const_7 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[76]); A_arbace_go_escape__init_part0_A_const_8 = A_arbace_go_escape__init_part0_A_const_pool.A[77]; A_arbace_go_escape__init_part0_A_const_9 = A_arbace_go_escape__init_part0_A_const_pool.A[78]; A_arbace_go_escape__init_part0_A_const_10 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[79]); A_arbace_go_escape__init_part0_A_const_11 = A_arbace_go_escape__init_part0_A_const_pool.A[80]; A_arbace_go_escape__init_part0_A_const_12 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[81]) }

func A_arbace_go_escape__init_part0_A_clinit_p1() { A_arbace_go_escape__init_part0_A_const_13 = A_arbace_go_escape__init_part0_A_const_pool.A[82]; A_arbace_go_escape__init_part0_A_const_14 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[83]); A_arbace_go_escape__init_part0_A_const_15 = A_arbace_go_escape__init_part0_A_const_pool.A[84]; A_arbace_go_escape__init_part0_A_const_16 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[85]); A_arbace_go_escape__init_part0_A_const_17 = A_arbace_go_escape__init_part0_A_const_pool.A[86]; A_arbace_go_escape__init_part0_A_const_18 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[87]); A_arbace_go_escape__init_part0_A_const_19 = A_arbace_go_escape__init_part0_A_const_pool.A[88]; A_arbace_go_escape__init_part0_A_const_20 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[89]); A_arbace_go_escape__init_part0_A_const_21 = A_arbace_go_escape__init_part0_A_const_pool.A[90]; A_arbace_go_escape__init_part0_A_const_22 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[91]); A_arbace_go_escape__init_part0_A_const_23 = A_arbace_go_escape__init_part0_A_const_pool.A[92]; A_arbace_go_escape__init_part0_A_const_24 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[93]); A_arbace_go_escape__init_part0_A_const_25 = A_arbace_go_escape__init_part0_A_const_pool.A[94] }

func A_arbace_go_escape__init_part0_A_clinit_p2() { A_arbace_go_escape__init_part0_A_const_26 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[95]); A_arbace_go_escape__init_part0_A_const_27 = A_arbace_go_escape__init_part0_A_const_pool.A[96]; A_arbace_go_escape__init_part0_A_const_28 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[97]); A_arbace_go_escape__init_part0_A_const_29 = A_arbace_go_escape__init_part0_A_const_pool.A[98]; A_arbace_go_escape__init_part0_A_const_30 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[99]); A_arbace_go_escape__init_part0_A_const_31 = A_arbace_go_escape__init_part0_A_const_pool.A[100]; A_arbace_go_escape__init_part0_A_const_32 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[101]); A_arbace_go_escape__init_part0_A_const_33 = A_arbace_go_escape__init_part0_A_const_pool.A[102]; A_arbace_go_escape__init_part0_A_const_34 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[103]); A_arbace_go_escape__init_part0_A_const_35 = A_arbace_go_escape__init_part0_A_const_pool.A[104]; A_arbace_go_escape__init_part0_A_const_36 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[105]); A_arbace_go_escape__init_part0_A_const_37 = A_arbace_go_escape__init_part0_A_const_pool.A[106]; A_arbace_go_escape__init_part0_A_const_38 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[107]) }

func A_arbace_go_escape__init_part0_A_clinit_p3() { A_arbace_go_escape__init_part0_A_const_39 = A_arbace_go_escape__init_part0_A_const_pool.A[108]; A_arbace_go_escape__init_part0_A_const_40 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[109]); A_arbace_go_escape__init_part0_A_const_41 = A_arbace_go_escape__init_part0_A_const_pool.A[110]; A_arbace_go_escape__init_part0_A_const_42 = A_arbace_go_escape__init_part0_A_const_pool.A[111]; A_arbace_go_escape__init_part0_A_const_43 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[112]); A_arbace_go_escape__init_part0_A_const_44 = A_arbace_go_escape__init_part0_A_const_pool.A[113]; A_arbace_go_escape__init_part0_A_const_45 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[114]); A_arbace_go_escape__init_part0_A_const_46 = A_arbace_go_escape__init_part0_A_const_pool.A[115]; A_arbace_go_escape__init_part0_A_const_47 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[116]); A_arbace_go_escape__init_part0_A_const_48 = A_arbace_go_escape__init_part0_A_const_pool.A[117]; A_arbace_go_escape__init_part0_A_const_49 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[118]); A_arbace_go_escape__init_part0_A_const_50 = A_arbace_go_escape__init_part0_A_const_pool.A[119]; A_arbace_go_escape__init_part0_A_const_51 = A_arbace_go_escape__init_part0_A_const_pool.A[120]; A_arbace_go_escape__init_part0_A_const_52 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[121]) }

func A_arbace_go_escape__init_part0_A_clinit_p4() { A_arbace_go_escape__init_part0_A_const_53 = A_arbace_go_escape__init_part0_A_const_pool.A[122]; A_arbace_go_escape__init_part0_A_const_54 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[123]); A_arbace_go_escape__init_part0_A_const_55 = A_arbace_go_escape__init_part0_A_const_pool.A[124]; A_arbace_go_escape__init_part0_A_const_56 = A_arbace_go_escape__init_part0_A_const_pool.A[125]; A_arbace_go_escape__init_part0_A_const_57 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[126]); A_arbace_go_escape__init_part0_A_const_58 = A_arbace_go_escape__init_part0_A_const_pool.A[127]; A_arbace_go_escape__init_part0_A_const_59 = A_arbace_go_escape__init_part0_A_const_pool.A[128]; A_arbace_go_escape__init_part0_A_const_60 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[129]); A_arbace_go_escape__init_part0_A_const_61 = A_arbace_go_escape__init_part0_A_const_pool.A[130]; A_arbace_go_escape__init_part0_A_const_62 = A_arbace_go_escape__init_part0_A_const_pool.A[131]; A_arbace_go_escape__init_part0_A_const_63 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[132]); A_arbace_go_escape__init_part0_A_const_64 = A_arbace_go_escape__init_part0_A_const_pool.A[133]; A_arbace_go_escape__init_part0_A_const_65 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[134]); A_arbace_go_escape__init_part0_A_const_66 = A_arbace_go_escape__init_part0_A_const_pool.A[135] }

func A_arbace_go_escape__init_part0_A_clinit_p5() { A_arbace_go_escape__init_part0_A_const_67 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[136]); A_arbace_go_escape__init_part0_A_const_68 = A_arbace_go_escape__init_part0_A_const_pool.A[137]; A_arbace_go_escape__init_part0_A_const_69 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[138]); A_arbace_go_escape__init_part0_A_const_70 = A_arbace_go_escape__init_part0_A_const_pool.A[139]; A_arbace_go_escape__init_part0_A_const_71 = A_arbace_go_escape__init_part0_A_const_pool.A[140]; A_arbace_go_escape__init_part0_A_const_72 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[141]); A_arbace_go_escape__init_part0_A_const_73 = A_arbace_go_escape__init_part0_A_const_pool.A[142]; A_arbace_go_escape__init_part0_A_const_74 = A_arbace_go_escape__init_part0_A_const_pool.A[143]; A_arbace_go_escape__init_part0_A_const_75 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[144]); A_arbace_go_escape__init_part0_A_const_76 = A_arbace_go_escape__init_part0_A_const_pool.A[145]; A_arbace_go_escape__init_part0_A_const_77 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[146]); A_arbace_go_escape__init_part0_A_const_78 = A_arbace_go_escape__init_part0_A_const_pool.A[147]; A_arbace_go_escape__init_part0_A_const_79 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[148]); A_arbace_go_escape__init_part0_A_const_80 = A_arbace_go_escape__init_part0_A_const_pool.A[149] }

func A_arbace_go_escape__init_part0_A_clinit_p6() { A_arbace_go_escape__init_part0_A_const_81 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[150]); A_arbace_go_escape__init_part0_A_const_82 = A_arbace_go_escape__init_part0_A_const_pool.A[151]; A_arbace_go_escape__init_part0_A_const_83 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[152]); A_arbace_go_escape__init_part0_A_const_84 = A_arbace_go_escape__init_part0_A_const_pool.A[153]; A_arbace_go_escape__init_part0_A_const_85 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[154]); A_arbace_go_escape__init_part0_A_const_86 = A_arbace_go_escape__init_part0_A_const_pool.A[155]; A_arbace_go_escape__init_part0_A_const_87 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[156]); A_arbace_go_escape__init_part0_A_const_88 = A_arbace_go_escape__init_part0_A_const_pool.A[157]; A_arbace_go_escape__init_part0_A_const_89 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[158]); A_arbace_go_escape__init_part0_A_const_90 = A_arbace_go_escape__init_part0_A_const_pool.A[159]; A_arbace_go_escape__init_part0_A_const_91 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[160]); A_arbace_go_escape__init_part0_A_const_92 = A_arbace_go_escape__init_part0_A_const_pool.A[161]; A_arbace_go_escape__init_part0_A_const_93 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[162]) }

func A_arbace_go_escape__init_part0_A_clinit_p7() { A_arbace_go_escape__init_part0_A_const_94 = A_arbace_go_escape__init_part0_A_const_pool.A[163]; A_arbace_go_escape__init_part0_A_const_95 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[164]); A_arbace_go_escape__init_part0_A_const_96 = A_arbace_go_escape__init_part0_A_const_pool.A[165]; A_arbace_go_escape__init_part0_A_const_97 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[166]); A_arbace_go_escape__init_part0_A_const_98 = A_arbace_go_escape__init_part0_A_const_pool.A[167]; A_arbace_go_escape__init_part0_A_const_99 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[168]); A_arbace_go_escape__init_part0_A_const_100 = A_arbace_go_escape__init_part0_A_const_pool.A[169]; A_arbace_go_escape__init_part0_A_const_101 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[170]); A_arbace_go_escape__init_part0_A_const_102 = A_arbace_go_escape__init_part0_A_const_pool.A[171]; A_arbace_go_escape__init_part0_A_const_103 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[172]); A_arbace_go_escape__init_part0_A_const_104 = A_arbace_go_escape__init_part0_A_const_pool.A[173]; A_arbace_go_escape__init_part0_A_const_105 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[174]); A_arbace_go_escape__init_part0_A_const_106 = A_arbace_go_escape__init_part0_A_const_pool.A[175] }

func A_arbace_go_escape__init_part0_A_clinit_p8() { A_arbace_go_escape__init_part0_A_const_107 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[176]); A_arbace_go_escape__init_part0_A_const_108 = A_arbace_go_escape__init_part0_A_const_pool.A[177]; A_arbace_go_escape__init_part0_A_const_109 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[178]); A_arbace_go_escape__init_part0_A_const_110 = A_arbace_go_escape__init_part0_A_const_pool.A[179]; A_arbace_go_escape__init_part0_A_const_111 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[180]); A_arbace_go_escape__init_part0_A_const_112 = A_arbace_go_escape__init_part0_A_const_pool.A[181]; A_arbace_go_escape__init_part0_A_const_113 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[182]); A_arbace_go_escape__init_part0_A_const_114 = A_arbace_go_escape__init_part0_A_const_pool.A[183]; A_arbace_go_escape__init_part0_A_const_115 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[184]); A_arbace_go_escape__init_part0_A_const_116 = A_arbace_go_escape__init_part0_A_const_pool.A[185]; A_arbace_go_escape__init_part0_A_const_117 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[186]); A_arbace_go_escape__init_part0_A_const_118 = A_arbace_go_escape__init_part0_A_const_pool.A[187]; A_arbace_go_escape__init_part0_A_const_119 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[188]) }

func A_arbace_go_escape__init_part0_A_clinit_p9() { A_arbace_go_escape__init_part0_A_const_120 = A_arbace_go_escape__init_part0_A_const_pool.A[189]; A_arbace_go_escape__init_part0_A_const_121 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[190]); A_arbace_go_escape__init_part0_A_const_122 = A_arbace_go_escape__init_part0_A_const_pool.A[191]; A_arbace_go_escape__init_part0_A_const_123 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[192]); A_arbace_go_escape__init_part0_A_const_124 = A_arbace_go_escape__init_part0_A_const_pool.A[193]; A_arbace_go_escape__init_part0_A_const_125 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[194]); A_arbace_go_escape__init_part0_A_const_126 = A_arbace_go_escape__init_part0_A_const_pool.A[195]; A_arbace_go_escape__init_part0_A_const_127 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[196]); A_arbace_go_escape__init_part0_A_const_128 = A_arbace_go_escape__init_part0_A_const_pool.A[197]; A_arbace_go_escape__init_part0_A_const_129 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[198]); A_arbace_go_escape__init_part0_A_const_130 = A_arbace_go_escape__init_part0_A_const_pool.A[199]; A_arbace_go_escape__init_part0_A_const_131 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[200]); A_arbace_go_escape__init_part0_A_const_132 = A_arbace_go_escape__init_part0_A_const_pool.A[201] }

func A_arbace_go_escape__init_part0_A_clinit_p10() { A_arbace_go_escape__init_part0_A_const_133 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[202]); A_arbace_go_escape__init_part0_A_const_134 = A_arbace_go_escape__init_part0_A_const_pool.A[203]; A_arbace_go_escape__init_part0_A_const_135 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[204]); A_arbace_go_escape__init_part0_A_const_136 = A_arbace_go_escape__init_part0_A_const_pool.A[205]; A_arbace_go_escape__init_part0_A_const_137 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[206]); A_arbace_go_escape__init_part0_A_const_138 = A_arbace_go_escape__init_part0_A_const_pool.A[207]; A_arbace_go_escape__init_part0_A_const_139 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[208]); A_arbace_go_escape__init_part0_A_const_140 = A_arbace_go_escape__init_part0_A_const_pool.A[209]; A_arbace_go_escape__init_part0_A_const_141 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[210]); A_arbace_go_escape__init_part0_A_const_142 = A_arbace_go_escape__init_part0_A_const_pool.A[211]; A_arbace_go_escape__init_part0_A_const_143 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[212]); A_arbace_go_escape__init_part0_A_const_144 = A_arbace_go_escape__init_part0_A_const_pool.A[213]; A_arbace_go_escape__init_part0_A_const_145 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[214]) }

func A_arbace_go_escape__init_part0_A_clinit_p11() { A_arbace_go_escape__init_part0_A_const_146 = A_arbace_go_escape__init_part0_A_const_pool.A[215]; A_arbace_go_escape__init_part0_A_const_147 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[216]); A_arbace_go_escape__init_part0_A_const_148 = A_arbace_go_escape__init_part0_A_const_pool.A[217]; A_arbace_go_escape__init_part0_A_const_149 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[218]); A_arbace_go_escape__init_part0_A_const_150 = A_arbace_go_escape__init_part0_A_const_pool.A[219]; A_arbace_go_escape__init_part0_A_const_151 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[220]); A_arbace_go_escape__init_part0_A_const_152 = A_arbace_go_escape__init_part0_A_const_pool.A[221]; A_arbace_go_escape__init_part0_A_const_153 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[222]); A_arbace_go_escape__init_part0_A_const_154 = A_arbace_go_escape__init_part0_A_const_pool.A[223]; A_arbace_go_escape__init_part0_A_const_155 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[224]); A_arbace_go_escape__init_part0_A_const_156 = A_arbace_go_escape__init_part0_A_const_pool.A[225]; A_arbace_go_escape__init_part0_A_const_157 = A_arbace_go_escape__init_part0_A_const_pool.A[226]; A_arbace_go_escape__init_part0_A_const_158 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[227]); A_arbace_go_escape__init_part0_A_const_159 = A_arbace_go_escape__init_part0_A_const_pool.A[228] }

func A_arbace_go_escape__init_part0_A_clinit_p12() { A_arbace_go_escape__init_part0_A_const_160 = A_arbace_go_escape__init_part0_A_const_pool.A[229]; A_arbace_go_escape__init_part0_A_const_161 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[230]); A_arbace_go_escape__init_part0_A_const_162 = A_arbace_go_escape__init_part0_A_const_pool.A[231]; A_arbace_go_escape__init_part0_A_const_163 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[232]); A_arbace_go_escape__init_part0_A_const_164 = A_arbace_go_escape__init_part0_A_const_pool.A[233]; A_arbace_go_escape__init_part0_A_const_165 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[234]); A_arbace_go_escape__init_part0_A_const_166 = A_arbace_go_escape__init_part0_A_const_pool.A[235]; A_arbace_go_escape__init_part0_A_const_167 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[236]); A_arbace_go_escape__init_part0_A_const_168 = A_arbace_go_escape__init_part0_A_const_pool.A[237]; A_arbace_go_escape__init_part0_A_const_169 = A_arbace_go_escape__init_part0_A_const_pool.A[238]; A_arbace_go_escape__init_part0_A_const_170 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[239]); A_arbace_go_escape__init_part0_A_const_171 = A_arbace_go_escape__init_part0_A_const_pool.A[240]; A_arbace_go_escape__init_part0_A_const_172 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[241]); A_arbace_go_escape__init_part0_A_const_173 = A_arbace_go_escape__init_part0_A_const_pool.A[242] }

func A_arbace_go_escape__init_part0_A_clinit_p13() { A_arbace_go_escape__init_part0_A_const_174 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[243]); A_arbace_go_escape__init_part0_A_const_175 = A_arbace_go_escape__init_part0_A_const_pool.A[244]; A_arbace_go_escape__init_part0_A_const_176 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[245]); A_arbace_go_escape__init_part0_A_const_177 = A_arbace_go_escape__init_part0_A_const_pool.A[246]; A_arbace_go_escape__init_part0_A_const_178 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[247]); A_arbace_go_escape__init_part0_A_const_179 = A_arbace_go_escape__init_part0_A_const_pool.A[248]; A_arbace_go_escape__init_part0_A_const_180 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[249]); A_arbace_go_escape__init_part0_A_const_181 = A_arbace_go_escape__init_part0_A_const_pool.A[250]; A_arbace_go_escape__init_part0_A_const_182 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[251]); A_arbace_go_escape__init_part0_A_const_183 = A_arbace_go_escape__init_part0_A_const_pool.A[252]; A_arbace_go_escape__init_part0_A_const_184 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[253]); A_arbace_go_escape__init_part0_A_const_185 = A_arbace_go_escape__init_part0_A_const_pool.A[254]; A_arbace_go_escape__init_part0_A_const_186 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[255]) }

func A_arbace_go_escape__init_part0_A_clinit_p14() { A_arbace_go_escape__init_part0_A_const_187 = A_arbace_go_escape__init_part0_A_const_pool.A[256]; A_arbace_go_escape__init_part0_A_const_188 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[257]); A_arbace_go_escape__init_part0_A_const_189 = A_arbace_go_escape__init_part0_A_const_pool.A[258]; A_arbace_go_escape__init_part0_A_const_190 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[259]); A_arbace_go_escape__init_part0_A_const_191 = A_arbace_go_escape__init_part0_A_const_pool.A[260]; A_arbace_go_escape__init_part0_A_const_192 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[261]); A_arbace_go_escape__init_part0_A_const_193 = A_arbace_go_escape__init_part0_A_const_pool.A[262]; A_arbace_go_escape__init_part0_A_const_194 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[263]); A_arbace_go_escape__init_part0_A_const_195 = A_arbace_go_escape__init_part0_A_const_pool.A[264]; A_arbace_go_escape__init_part0_A_const_196 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[265]); A_arbace_go_escape__init_part0_A_const_197 = A_arbace_go_escape__init_part0_A_const_pool.A[266]; A_arbace_go_escape__init_part0_A_const_198 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[267]); A_arbace_go_escape__init_part0_A_const_199 = A_arbace_go_escape__init_part0_A_const_pool.A[268] }

func A_arbace_go_escape__init_part0_A_clinit_p15() { A_arbace_go_escape__init_part0_A_const_200 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[269]); A_arbace_go_escape__init_part0_A_const_201 = A_arbace_go_escape__init_part0_A_const_pool.A[270]; A_arbace_go_escape__init_part0_A_const_202 = lang.Var_Cast(A_arbace_go_escape__init_part0_A_const_pool.A[271]); A_arbace_go_escape__init_part0_A_const_203 = A_arbace_go_escape__init_part0_A_const_pool.A[272] }

func A_arbace_go_escape__init_part0_A_New() *A_arbace_go_escape__init_part0_A { A_arbace_go_escape__init_part0_A_Init(); t := &A_arbace_go_escape__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_go_escape__init_part0_A) Ctor() {}

func (t *A_arbace_go_escape__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_escape__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_go_escape__init_part0_A_class }

func (t *A_arbace_go_escape__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_escape__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_escape__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_escape__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_escape__init_part0_A); return ok }

func A_arbace_go_escape__init_part0_A_Cast(x any) *A_arbace_go_escape__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_escape__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_escape__init_part0_A_class)) }; return v }



type A_arbace_go_escape__init_part1_A struct{ jrt.Object }

var A_arbace_go_escape__init_part1_A_const_pool *jrt.RefArray

var A_arbace_go_escape__init_part1_A_const_0 *lang.Var

var A_arbace_go_escape__init_part1_A_const_1 any

var A_arbace_go_escape__init_part1_A_const_2 *lang.Var

var A_arbace_go_escape__init_part1_A_const_3 any

var A_arbace_go_escape__init_part1_A_const_4 *lang.Var

var A_arbace_go_escape__init_part1_A_const_5 any

var A_arbace_go_escape__init_part1_A_const_6 *lang.Var

var A_arbace_go_escape__init_part1_A_const_7 any

var A_arbace_go_escape__init_part1_A_const_8 *lang.Var

var A_arbace_go_escape__init_part1_A_const_9 any

var A_arbace_go_escape__init_part1_A_const_10 *lang.Var

var A_arbace_go_escape__init_part1_A_const_11 any

var A_arbace_go_escape__init_part1_A_const_12 *lang.Var

var A_arbace_go_escape__init_part1_A_const_13 any

var A_arbace_go_escape__init_part1_A_const_14 *lang.Var

var A_arbace_go_escape__init_part1_A_const_15 any

var A_arbace_go_escape__init_part1_A_const_16 *lang.Var

var A_arbace_go_escape__init_part1_A_const_17 any

var A_arbace_go_escape__init_part1_A_const_18 *lang.Var

var A_arbace_go_escape__init_part1_A_const_19 any

var A_arbace_go_escape__init_part1_A_const_20 *lang.Var

var A_arbace_go_escape__init_part1_A_const_21 any

var A_arbace_go_escape__init_part1_A_const_22 *lang.Var

var A_arbace_go_escape__init_part1_A_const_23 any

var A_arbace_go_escape__init_part1_A_const_24 *lang.Var

var A_arbace_go_escape__init_part1_A_const_25 any

var A_arbace_go_escape__init_part1_A_const_26 *lang.Var

var A_arbace_go_escape__init_part1_A_const_27 any

var A_arbace_go_escape__init_part1_A_const_28 *lang.Var

var A_arbace_go_escape__init_part1_A_const_29 any

var A_arbace_go_escape__init_part1_A_const_30 *lang.Var

var A_arbace_go_escape__init_part1_A_const_31 any

var A_arbace_go_escape__init_part1_A_const_32 *lang.Var

var A_arbace_go_escape__init_part1_A_const_33 any

var A_arbace_go_escape__init_part1_A_const_34 *lang.Var

var A_arbace_go_escape__init_part1_A_const_35 any

var A_arbace_go_escape__init_part1_A_const_36 *lang.Var

var A_arbace_go_escape__init_part1_A_const_37 any

var A_arbace_go_escape__init_part1_A_const_38 *lang.Var

var A_arbace_go_escape__init_part1_A_const_39 any

var A_arbace_go_escape__init_part1_A_const_40 *lang.Var

var A_arbace_go_escape__init_part1_A_const_41 any

var A_arbace_go_escape__init_part1_A_const_42 *lang.Var

var A_arbace_go_escape__init_part1_A_const_43 any

var A_arbace_go_escape__init_part1_A_const_44 *lang.Var

var A_arbace_go_escape__init_part1_A_const_45 any

var A_arbace_go_escape__init_part1_A_const_46 *lang.Var

var A_arbace_go_escape__init_part1_A_const_47 any

var A_arbace_go_escape__init_part1_A_const_48 *lang.Var

var A_arbace_go_escape__init_part1_A_const_49 any

var A_arbace_go_escape__init_part1_A_const_50 *lang.Var

var A_arbace_go_escape__init_part1_A_const_51 any

var A_arbace_go_escape__init_part1_A_const_52 *lang.Var

var A_arbace_go_escape__init_part1_A_const_53 any

var A_arbace_go_escape__init_part1_A_const_54 *lang.Var

var A_arbace_go_escape__init_part1_A_const_55 any

var A_arbace_go_escape__init_part1_A_const_56 *lang.Var

var A_arbace_go_escape__init_part1_A_const_57 any

var A_arbace_go_escape__init_part1_A_const_58 *lang.Var

var A_arbace_go_escape__init_part1_A_const_59 any

var A_arbace_go_escape__init_part1_A_const_60 *lang.Var

var A_arbace_go_escape__init_part1_A_const_61 any

var A_arbace_go_escape__init_part1_A_const_62 *lang.Var

var A_arbace_go_escape__init_part1_A_const_63 any

var A_arbace_go_escape__init_part1_A_const_64 *lang.Var

var A_arbace_go_escape__init_part1_A_const_65 any

var A_arbace_go_escape__init_part1_A_const_66 *lang.Var

var A_arbace_go_escape__init_part1_A_const_67 any

var A_arbace_go_escape__init_part1_A_const_68 *lang.Var

var A_arbace_go_escape__init_part1_A_const_69 any

var A_arbace_go_escape__init_part1_A_const_70 *lang.Var

var A_arbace_go_escape__init_part1_A_const_71 any

var A_arbace_go_escape__init_part1_A_const_72 *lang.Var

var A_arbace_go_escape__init_part1_A_const_73 any

var A_arbace_go_escape__init_part1_A_const_74 *lang.Var

var A_arbace_go_escape__init_part1_A_const_75 any

var A_arbace_go_escape__init_part1_A_const_76 *lang.Var

var A_arbace_go_escape__init_part1_A_const_77 any

var A_arbace_go_escape__init_part1_A_const_78 *lang.Var

var A_arbace_go_escape__init_part1_A_const_79 any

var A_arbace_go_escape__init_part1_A_const_80 *lang.Var

var A_arbace_go_escape__init_part1_A_const_81 any

var A_arbace_go_escape__init_part1_A_const_82 *lang.Var

var A_arbace_go_escape__init_part1_A_const_83 any

var A_arbace_go_escape__init_part1_A_const_84 *lang.Var

var A_arbace_go_escape__init_part1_A_const_85 any

var A_arbace_go_escape__init_part1_A_const_86 *lang.Var

var A_arbace_go_escape__init_part1_A_const_87 any

var A_arbace_go_escape__init_part1_A_const_88 *lang.Var

var A_arbace_go_escape__init_part1_A_const_89 any

var A_arbace_go_escape__init_part1_A_const_90 *lang.Var

var A_arbace_go_escape__init_part1_A_const_91 any

var A_arbace_go_escape__init_part1_A_const_92 *lang.Var

var A_arbace_go_escape__init_part1_A_const_93 any

var A_arbace_go_escape__init_part1_A_const_94 *lang.Var

var A_arbace_go_escape__init_part1_A_const_95 any

var A_arbace_go_escape__init_part1_A_const_96 *lang.Var

var A_arbace_go_escape__init_part1_A_const_97 any

var A_arbace_go_escape__init_part1_A_const_98 *lang.Var

var A_arbace_go_escape__init_part1_A_const_99 any

var A_arbace_go_escape__init_part1_A_const_100 *lang.Var

var A_arbace_go_escape__init_part1_A_const_101 any

var A_arbace_go_escape__init_part1_A_const_102 *lang.Var

var A_arbace_go_escape__init_part1_A_const_103 any

var A_arbace_go_escape__init_part1_A_const_104 *lang.Var

var A_arbace_go_escape__init_part1_A_const_105 any

var A_arbace_go_escape__init_part1_A_const_106 *lang.Var

var A_arbace_go_escape__init_part1_A_const_107 any

var A_arbace_go_escape__init_part1_A_const_108 *lang.Var

var A_arbace_go_escape__init_part1_A_const_109 any

var A_arbace_go_escape__init_part1_A_const_110 *lang.Var

var A_arbace_go_escape__init_part1_A_const_111 any

var A_arbace_go_escape__init_part1_A_const_112 *lang.Var

var A_arbace_go_escape__init_part1_A_const_113 any

var A_arbace_go_escape__init_part1_A_const_114 *lang.Var

var A_arbace_go_escape__init_part1_A_const_115 any

var A_arbace_go_escape__init_part1_A_const_116 *lang.Var

var A_arbace_go_escape__init_part1_A_const_117 any

var A_arbace_go_escape__init_part1_A_const_118 *lang.Var

var A_arbace_go_escape__init_part1_A_const_119 any

var A_arbace_go_escape__init_part1_A_const_120 *lang.Var

var A_arbace_go_escape__init_part1_A_const_121 any

var A_arbace_go_escape__init_part1_A_const_122 *lang.Var

var A_arbace_go_escape__init_part1_A_const_123 any

var A_arbace_go_escape__init_part1_A_const_124 *lang.Var

var A_arbace_go_escape__init_part1_A_const_125 any

var A_arbace_go_escape__init_part1_A_const_126 *lang.Var

var A_arbace_go_escape__init_part1_A_const_127 any

var A_arbace_go_escape__init_part1_A_const_128 *lang.Var

var A_arbace_go_escape__init_part1_A_const_129 any

var A_arbace_go_escape__init_part1_A_const_130 *lang.Var

var A_arbace_go_escape__init_part1_A_const_131 any

var A_arbace_go_escape__init_part1_A_const_132 *lang.Var

var A_arbace_go_escape__init_part1_A_const_133 any

var A_arbace_go_escape__init_part1_A_const_134 *lang.Var

var A_arbace_go_escape__init_part1_A_const_135 any

var A_arbace_go_escape__init_part1_A_const_136 *lang.Var

var A_arbace_go_escape__init_part1_A_const_137 any

var A_arbace_go_escape__init_part1_A_const_138 *lang.Var

var A_arbace_go_escape__init_part1_A_const_139 any

var A_arbace_go_escape__init_part1_A_const_140 *lang.Var

var A_arbace_go_escape__init_part1_A_const_141 any

var A_arbace_go_escape__init_part1_A_const_142 *lang.Var

var A_arbace_go_escape__init_part1_A_const_143 any

var A_arbace_go_escape__init_part1_A_const_144 *lang.Var

var A_arbace_go_escape__init_part1_A_const_145 any

var A_arbace_go_escape__init_part1_A_const_146 *lang.Var

var A_arbace_go_escape__init_part1_A_const_147 any

var A_arbace_go_escape__init_part1_A_const_148 *lang.Var

var A_arbace_go_escape__init_part1_A_const_149 any

var A_arbace_go_escape__init_part1_A_const_150 *lang.Var

var A_arbace_go_escape__init_part1_A_const_151 any

var A_arbace_go_escape__init_part1_A_const_152 *lang.Var

var A_arbace_go_escape__init_part1_A_const_153 any

var A_arbace_go_escape__init_part1_A_const_154 *lang.Var

var A_arbace_go_escape__init_part1_A_const_155 any

var A_arbace_go_escape__init_part1_A_const_156 *lang.Var

var A_arbace_go_escape__init_part1_A_const_157 any

var A_arbace_go_escape__init_part1_A_const_158 *lang.Var

var A_arbace_go_escape__init_part1_A_const_159 any

var A_arbace_go_escape__init_part1_A_const_160 *lang.Var

var A_arbace_go_escape__init_part1_A_const_161 any

var A_arbace_go_escape__init_part1_A_const_162 *lang.Var

var A_arbace_go_escape__init_part1_A_const_163 any

var A_arbace_go_escape__init_part1_A_const_164 *lang.Var

var A_arbace_go_escape__init_part1_A_const_165 any

var A_arbace_go_escape__init_part1_A_const_166 *lang.Var

var A_arbace_go_escape__init_part1_A_const_167 any

var A_arbace_go_escape__init_part1_A_const_168 any

var A_arbace_go_escape__init_part1_A_const_169 *lang.Var

var A_arbace_go_escape__init_part1_A_const_170 any

var A_arbace_go_escape__init_part1_A_const_171 any

var A_arbace_go_escape__init_part1_A_const_172 *lang.Var

var A_arbace_go_escape__init_part1_A_const_173 any

var A_arbace_go_escape__init_part1_A_const_174 any

var A_arbace_go_escape__init_part1_A_const_175 *lang.Var

var A_arbace_go_escape__init_part1_A_const_176 any

var A_arbace_go_escape__init_part1_A_const_177 any

var A_arbace_go_escape__init_part1_A_const_178 *lang.Var

var A_arbace_go_escape__init_part1_A_const_179 any

var A_arbace_go_escape__init_part1_A_const_180 *lang.Var

var A_arbace_go_escape__init_part1_A_const_181 any

var A_arbace_go_escape__init_part1_A_const_182 *lang.Var

var A_arbace_go_escape__init_part1_A_const_183 any

var A_arbace_go_escape__init_part1_A_const_184 *lang.Var

var A_arbace_go_escape__init_part1_A_const_185 any

var A_arbace_go_escape__init_part1_A_const_186 *lang.Var

var A_arbace_go_escape__init_part1_A_const_187 any

var A_arbace_go_escape__init_part1_A_const_188 *lang.Var

var A_arbace_go_escape__init_part1_A_const_189 any

var A_arbace_go_escape__init_part1_A_const_190 *lang.Var

var A_arbace_go_escape__init_part1_A_const_191 any

var A_arbace_go_escape__init_part1_A_const_192 *lang.Var

var A_arbace_go_escape__init_part1_A_const_193 any

var A_arbace_go_escape__init_part1_A_const_194 *lang.Var

var A_arbace_go_escape__init_part1_A_const_195 any

var A_arbace_go_escape__init_part1_A_const_196 *lang.Var

var A_arbace_go_escape__init_part1_A_const_197 any

var A_arbace_go_escape__init_part1_A_const_198 *lang.Var

var A_arbace_go_escape__init_part1_A_const_199 any

var A_arbace_go_escape__init_part1_A_const_200 *lang.Var

var A_arbace_go_escape__init_part1_A_const_201 any

var A_arbace_go_escape__init_part1_A_const_202 *lang.Var

var A_arbace_go_escape__init_part1_A_const_203 any

var A_arbace_go_escape__init_part1_A_const_204 any

var A_arbace_go_escape__init_part1_A_init jrt.ClassInit

func A_arbace_go_escape__init_part1_A_Init() { if !A_arbace_go_escape__init_part1_A_init.Done() { A_arbace_go_escape__init_part1_A_init.Run(A_arbace_go_escape__init_part1_A_clinit) } }

func A_arbace_go_escape__init_part1_A_clinit() { A_arbace_go_escape__init_part1_A_clinit_p0(); A_arbace_go_escape__init_part1_A_clinit_p1(); A_arbace_go_escape__init_part1_A_clinit_p2() }

func A_arbace_go_escape__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_escape__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_581, 246); A_arbace_go_escape__init_part1_A_const_0 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[57]); A_arbace_go_escape__init_part1_A_const_1 = A_arbace_go_escape__init_part1_A_const_pool.A[58]; A_arbace_go_escape__init_part1_A_const_2 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[59]); A_arbace_go_escape__init_part1_A_const_3 = A_arbace_go_escape__init_part1_A_const_pool.A[60]; A_arbace_go_escape__init_part1_A_const_4 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[61]); A_arbace_go_escape__init_part1_A_const_5 = A_arbace_go_escape__init_part1_A_const_pool.A[62]; A_arbace_go_escape__init_part1_A_const_6 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[63]); A_arbace_go_escape__init_part1_A_const_7 = A_arbace_go_escape__init_part1_A_const_pool.A[64]; A_arbace_go_escape__init_part1_A_const_8 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[65]); A_arbace_go_escape__init_part1_A_const_9 = A_arbace_go_escape__init_part1_A_const_pool.A[66]; A_arbace_go_escape__init_part1_A_const_10 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[67]); A_arbace_go_escape__init_part1_A_const_11 = A_arbace_go_escape__init_part1_A_const_pool.A[68] }

func A_arbace_go_escape__init_part1_A_clinit_p1() { A_arbace_go_escape__init_part1_A_const_12 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[69]); A_arbace_go_escape__init_part1_A_const_13 = A_arbace_go_escape__init_part1_A_const_pool.A[70]; A_arbace_go_escape__init_part1_A_const_14 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[71]); A_arbace_go_escape__init_part1_A_const_15 = A_arbace_go_escape__init_part1_A_const_pool.A[72]; A_arbace_go_escape__init_part1_A_const_16 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[73]); A_arbace_go_escape__init_part1_A_const_17 = A_arbace_go_escape__init_part1_A_const_pool.A[74] }

func A_arbace_go_escape__init_part1_A_clinit_p2() { var tmp1 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp1 = A_arbace_go_escape__init_part0_A_const_196; A_arbace_go_escape__init_part1_A_const_18 = tmp1; A_arbace_go_escape__init_part1_A_const_19 = A_arbace_go_escape__init_part1_A_const_pool.A[75]; var tmp2 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp2 = A_arbace_go_escape__init_part0_A_const_170; A_arbace_go_escape__init_part1_A_const_20 = tmp2; A_arbace_go_escape__init_part1_A_const_21 = A_arbace_go_escape__init_part1_A_const_pool.A[76]; var tmp3 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp3 = A_arbace_go_escape__init_part0_A_const_172; A_arbace_go_escape__init_part1_A_const_22 = tmp3; A_arbace_go_escape__init_part1_A_const_23 = A_arbace_go_escape__init_part1_A_const_pool.A[77]; A_arbace_go_escape__init_part1_A_const_24 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[78]); A_arbace_go_escape__init_part1_A_const_25 = A_arbace_go_escape__init_part1_A_const_pool.A[79]; A_arbace_go_escape__init_part1_A_const_26 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[80]); A_arbace_go_escape__init_part1_A_const_27 = A_arbace_go_escape__init_part1_A_const_pool.A[81]; var tmp4 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp4 = A_arbace_go_escape__init_part0_A_const_192; A_arbace_go_escape__init_part1_A_const_28 = tmp4; A_arbace_go_escape__init_part1_A_const_29 = A_arbace_go_escape__init_part1_A_const_pool.A[82]; var tmp5 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp5 = A_arbace_go_escape__init_part0_A_const_194; A_arbace_go_escape__init_part1_A_const_30 = tmp5; A_arbace_go_escape__init_part1_A_const_31 = A_arbace_go_escape__init_part1_A_const_pool.A[83]; A_arbace_go_escape__init_part1_A_const_32 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[84]); A_arbace_go_escape__init_part1_A_const_33 = A_arbace_go_escape__init_part1_A_const_pool.A[85]; var tmp6 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp6 = A_arbace_go_escape__init_part0_A_const_190; A_arbace_go_escape__init_part1_A_const_34 = tmp6; A_arbace_go_escape__init_part1_A_const_35 = A_arbace_go_escape__init_part1_A_const_pool.A[86]; A_arbace_go_escape__init_part1_A_const_36 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[87]); A_arbace_go_escape__init_part1_A_const_37 = A_arbace_go_escape__init_part1_A_const_pool.A[88]; A_arbace_go_escape__init_part1_A_const_38 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[89]); A_arbace_go_escape__init_part1_A_const_39 = A_arbace_go_escape__init_part1_A_const_pool.A[90]; A_arbace_go_escape__init_part1_A_const_40 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[91]); A_arbace_go_escape__init_part1_A_const_41 = A_arbace_go_escape__init_part1_A_const_pool.A[92]; A_arbace_go_escape__init_part1_A_const_42 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[93]); A_arbace_go_escape__init_part1_A_const_43 = A_arbace_go_escape__init_part1_A_const_pool.A[94]; A_arbace_go_escape__init_part1_A_const_44 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[95]); A_arbace_go_escape__init_part1_A_const_45 = A_arbace_go_escape__init_part1_A_const_pool.A[96]; A_arbace_go_escape__init_part1_A_const_46 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[97]); A_arbace_go_escape__init_part1_A_const_47 = A_arbace_go_escape__init_part1_A_const_pool.A[98]; var tmp7 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp7 = A_arbace_go_escape__init_part0_A_const_153; A_arbace_go_escape__init_part1_A_const_48 = tmp7; A_arbace_go_escape__init_part1_A_const_49 = A_arbace_go_escape__init_part1_A_const_pool.A[99]; A_arbace_go_escape__init_part1_A_const_50 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[100]); A_arbace_go_escape__init_part1_A_const_51 = A_arbace_go_escape__init_part1_A_const_pool.A[101]; A_arbace_go_escape__init_part1_A_const_52 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[102]); A_arbace_go_escape__init_part1_A_const_53 = A_arbace_go_escape__init_part1_A_const_pool.A[103]; var tmp8 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp8 = A_arbace_go_escape__init_part0_A_const_178; A_arbace_go_escape__init_part1_A_const_54 = tmp8; A_arbace_go_escape__init_part1_A_const_55 = A_arbace_go_escape__init_part1_A_const_pool.A[104]; var tmp9 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp9 = A_arbace_go_escape__init_part0_A_const_198; A_arbace_go_escape__init_part1_A_const_56 = tmp9; A_arbace_go_escape__init_part1_A_const_57 = A_arbace_go_escape__init_part1_A_const_pool.A[105]; A_arbace_go_escape__init_part1_A_const_58 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[106]); A_arbace_go_escape__init_part1_A_const_59 = A_arbace_go_escape__init_part1_A_const_pool.A[107]; A_arbace_go_escape__init_part1_A_const_60 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[108]); A_arbace_go_escape__init_part1_A_const_61 = A_arbace_go_escape__init_part1_A_const_pool.A[109]; A_arbace_go_escape__init_part1_A_const_62 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[110]); A_arbace_go_escape__init_part1_A_const_63 = A_arbace_go_escape__init_part1_A_const_pool.A[111]; A_arbace_go_escape__init_part1_A_const_64 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[112]); A_arbace_go_escape__init_part1_A_const_65 = A_arbace_go_escape__init_part1_A_const_pool.A[113]; A_arbace_go_escape__init_part1_A_const_66 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[114]); A_arbace_go_escape__init_part1_A_const_67 = A_arbace_go_escape__init_part1_A_const_pool.A[115]; var tmp10 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp10 = A_arbace_go_escape__init_part0_A_const_184; A_arbace_go_escape__init_part1_A_const_68 = tmp10; A_arbace_go_escape__init_part1_A_const_69 = A_arbace_go_escape__init_part1_A_const_pool.A[116]; A_arbace_go_escape__init_part1_A_const_70 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[117]); A_arbace_go_escape__init_part1_A_const_71 = A_arbace_go_escape__init_part1_A_const_pool.A[118]; A_arbace_go_escape__init_part1_A_const_72 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[119]); A_arbace_go_escape__init_part1_A_const_73 = A_arbace_go_escape__init_part1_A_const_pool.A[120]; A_arbace_go_escape__init_part1_A_const_74 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[121]); A_arbace_go_escape__init_part1_A_const_75 = A_arbace_go_escape__init_part1_A_const_pool.A[122]; A_arbace_go_escape__init_part1_A_const_76 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[123]); A_arbace_go_escape__init_part1_A_const_77 = A_arbace_go_escape__init_part1_A_const_pool.A[124]; A_arbace_go_escape__init_part1_A_const_78 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[125]); A_arbace_go_escape__init_part1_A_const_79 = A_arbace_go_escape__init_part1_A_const_pool.A[126]; A_arbace_go_escape__init_part1_A_const_80 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[127]); A_arbace_go_escape__init_part1_A_const_81 = A_arbace_go_escape__init_part1_A_const_pool.A[128]; A_arbace_go_escape__init_part1_A_const_82 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[129]); A_arbace_go_escape__init_part1_A_const_83 = A_arbace_go_escape__init_part1_A_const_pool.A[130]; A_arbace_go_escape__init_part1_A_const_84 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[131]); A_arbace_go_escape__init_part1_A_const_85 = A_arbace_go_escape__init_part1_A_const_pool.A[132]; var tmp11 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp11 = A_arbace_go_escape__init_part0_A_const_182; A_arbace_go_escape__init_part1_A_const_86 = tmp11; A_arbace_go_escape__init_part1_A_const_87 = A_arbace_go_escape__init_part1_A_const_pool.A[133]; var tmp12 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp12 = A_arbace_go_escape__init_part0_A_const_186; A_arbace_go_escape__init_part1_A_const_88 = tmp12; A_arbace_go_escape__init_part1_A_const_89 = A_arbace_go_escape__init_part1_A_const_pool.A[134]; var tmp13 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp13 = A_arbace_go_escape__init_part0_A_const_188; A_arbace_go_escape__init_part1_A_const_90 = tmp13; A_arbace_go_escape__init_part1_A_const_91 = A_arbace_go_escape__init_part1_A_const_pool.A[135]; A_arbace_go_escape__init_part1_A_const_92 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[136]); A_arbace_go_escape__init_part1_A_const_93 = A_arbace_go_escape__init_part1_A_const_pool.A[137]; A_arbace_go_escape__init_part1_A_const_94 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[138]); A_arbace_go_escape__init_part1_A_const_95 = A_arbace_go_escape__init_part1_A_const_pool.A[139]; A_arbace_go_escape__init_part1_A_const_96 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[140]); A_arbace_go_escape__init_part1_A_const_97 = A_arbace_go_escape__init_part1_A_const_pool.A[141]; A_arbace_go_escape__init_part1_A_const_98 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[142]); A_arbace_go_escape__init_part1_A_const_99 = A_arbace_go_escape__init_part1_A_const_pool.A[143]; A_arbace_go_escape__init_part1_A_const_100 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[144]); A_arbace_go_escape__init_part1_A_const_101 = A_arbace_go_escape__init_part1_A_const_pool.A[145]; var tmp14 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp14 = A_arbace_go_escape__init_part0_A_const_174; A_arbace_go_escape__init_part1_A_const_102 = tmp14; A_arbace_go_escape__init_part1_A_const_103 = A_arbace_go_escape__init_part1_A_const_pool.A[146]; A_arbace_go_escape__init_part1_A_const_104 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[147]); A_arbace_go_escape__init_part1_A_const_105 = A_arbace_go_escape__init_part1_A_const_pool.A[148]; A_arbace_go_escape__init_part1_A_const_106 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[149]); A_arbace_go_escape__init_part1_A_const_107 = A_arbace_go_escape__init_part1_A_const_pool.A[150]; A_arbace_go_escape__init_part1_A_const_108 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[151]); A_arbace_go_escape__init_part1_A_const_109 = A_arbace_go_escape__init_part1_A_const_pool.A[152]; A_arbace_go_escape__init_part1_A_const_110 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[153]); A_arbace_go_escape__init_part1_A_const_111 = A_arbace_go_escape__init_part1_A_const_pool.A[154]; A_arbace_go_escape__init_part1_A_const_112 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[155]); A_arbace_go_escape__init_part1_A_const_113 = A_arbace_go_escape__init_part1_A_const_pool.A[156]; A_arbace_go_escape__init_part1_A_const_114 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[157]); A_arbace_go_escape__init_part1_A_const_115 = A_arbace_go_escape__init_part1_A_const_pool.A[158]; A_arbace_go_escape__init_part1_A_const_116 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[159]); A_arbace_go_escape__init_part1_A_const_117 = A_arbace_go_escape__init_part1_A_const_pool.A[160]; var tmp15 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp15 = A_arbace_go_escape__init_part0_A_const_176; A_arbace_go_escape__init_part1_A_const_118 = tmp15; A_arbace_go_escape__init_part1_A_const_119 = A_arbace_go_escape__init_part1_A_const_pool.A[161]; A_arbace_go_escape__init_part1_A_const_120 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[162]); A_arbace_go_escape__init_part1_A_const_121 = A_arbace_go_escape__init_part1_A_const_pool.A[163]; var tmp16 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp16 = A_arbace_go_escape__init_part0_A_const_180; A_arbace_go_escape__init_part1_A_const_122 = tmp16; A_arbace_go_escape__init_part1_A_const_123 = A_arbace_go_escape__init_part1_A_const_pool.A[164]; A_arbace_go_escape__init_part1_A_const_124 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[165]); A_arbace_go_escape__init_part1_A_const_125 = A_arbace_go_escape__init_part1_A_const_pool.A[166]; A_arbace_go_escape__init_part1_A_const_126 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[167]); A_arbace_go_escape__init_part1_A_const_127 = A_arbace_go_escape__init_part1_A_const_pool.A[168]; A_arbace_go_escape__init_part1_A_const_128 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[169]); A_arbace_go_escape__init_part1_A_const_129 = A_arbace_go_escape__init_part1_A_const_pool.A[170]; A_arbace_go_escape__init_part1_A_const_130 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[171]); A_arbace_go_escape__init_part1_A_const_131 = A_arbace_go_escape__init_part1_A_const_pool.A[172]; A_arbace_go_escape__init_part1_A_const_132 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[173]); A_arbace_go_escape__init_part1_A_const_133 = A_arbace_go_escape__init_part1_A_const_pool.A[174]; A_arbace_go_escape__init_part1_A_const_134 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[175]); A_arbace_go_escape__init_part1_A_const_135 = A_arbace_go_escape__init_part1_A_const_pool.A[176]; A_arbace_go_escape__init_part1_A_const_136 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[177]); A_arbace_go_escape__init_part1_A_const_137 = A_arbace_go_escape__init_part1_A_const_pool.A[178]; A_arbace_go_escape__init_part1_A_const_138 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[179]); A_arbace_go_escape__init_part1_A_const_139 = A_arbace_go_escape__init_part1_A_const_pool.A[180]; A_arbace_go_escape__init_part1_A_const_140 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[181]); A_arbace_go_escape__init_part1_A_const_141 = A_arbace_go_escape__init_part1_A_const_pool.A[182]; A_arbace_go_escape__init_part1_A_const_142 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[183]); A_arbace_go_escape__init_part1_A_const_143 = A_arbace_go_escape__init_part1_A_const_pool.A[184]; A_arbace_go_escape__init_part1_A_const_144 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[185]); A_arbace_go_escape__init_part1_A_const_145 = A_arbace_go_escape__init_part1_A_const_pool.A[186]; A_arbace_go_escape__init_part1_A_const_146 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[187]); A_arbace_go_escape__init_part1_A_const_147 = A_arbace_go_escape__init_part1_A_const_pool.A[188]; A_arbace_go_escape__init_part1_A_const_148 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[189]); A_arbace_go_escape__init_part1_A_const_149 = A_arbace_go_escape__init_part1_A_const_pool.A[190]; A_arbace_go_escape__init_part1_A_const_150 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[191]); A_arbace_go_escape__init_part1_A_const_151 = A_arbace_go_escape__init_part1_A_const_pool.A[192]; A_arbace_go_escape__init_part1_A_const_152 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[193]); A_arbace_go_escape__init_part1_A_const_153 = A_arbace_go_escape__init_part1_A_const_pool.A[194]; A_arbace_go_escape__init_part1_A_const_154 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[195]); A_arbace_go_escape__init_part1_A_const_155 = A_arbace_go_escape__init_part1_A_const_pool.A[196]; A_arbace_go_escape__init_part1_A_const_156 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[197]); A_arbace_go_escape__init_part1_A_const_157 = A_arbace_go_escape__init_part1_A_const_pool.A[198]; A_arbace_go_escape__init_part1_A_const_158 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[199]); A_arbace_go_escape__init_part1_A_const_159 = A_arbace_go_escape__init_part1_A_const_pool.A[200]; A_arbace_go_escape__init_part1_A_const_160 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[201]); A_arbace_go_escape__init_part1_A_const_161 = A_arbace_go_escape__init_part1_A_const_pool.A[202]; A_arbace_go_escape__init_part1_A_const_162 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[203]); A_arbace_go_escape__init_part1_A_const_163 = A_arbace_go_escape__init_part1_A_const_pool.A[204]; A_arbace_go_escape__init_part1_A_const_164 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[205]); A_arbace_go_escape__init_part1_A_const_165 = A_arbace_go_escape__init_part1_A_const_pool.A[206]; A_arbace_go_escape__init_part1_A_const_166 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[207]); A_arbace_go_escape__init_part1_A_const_167 = A_arbace_go_escape__init_part1_A_const_pool.A[208]; A_arbace_go_escape__init_part1_A_const_168 = A_arbace_go_escape__init_part1_A_const_pool.A[209]; A_arbace_go_escape__init_part1_A_const_169 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[210]); A_arbace_go_escape__init_part1_A_const_170 = A_arbace_go_escape__init_part1_A_const_pool.A[211]; A_arbace_go_escape__init_part1_A_const_171 = A_arbace_go_escape__init_part1_A_const_pool.A[212]; A_arbace_go_escape__init_part1_A_const_172 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[213]); A_arbace_go_escape__init_part1_A_const_173 = A_arbace_go_escape__init_part1_A_const_pool.A[214]; A_arbace_go_escape__init_part1_A_const_174 = A_arbace_go_escape__init_part1_A_const_pool.A[215]; A_arbace_go_escape__init_part1_A_const_175 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[216]); A_arbace_go_escape__init_part1_A_const_176 = A_arbace_go_escape__init_part1_A_const_pool.A[217]; A_arbace_go_escape__init_part1_A_const_177 = A_arbace_go_escape__init_part1_A_const_pool.A[218]; A_arbace_go_escape__init_part1_A_const_178 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[219]); A_arbace_go_escape__init_part1_A_const_179 = A_arbace_go_escape__init_part1_A_const_pool.A[220]; A_arbace_go_escape__init_part1_A_const_180 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[221]); A_arbace_go_escape__init_part1_A_const_181 = A_arbace_go_escape__init_part1_A_const_pool.A[222]; A_arbace_go_escape__init_part1_A_const_182 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[223]); A_arbace_go_escape__init_part1_A_const_183 = A_arbace_go_escape__init_part1_A_const_pool.A[224]; A_arbace_go_escape__init_part1_A_const_184 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[225]); A_arbace_go_escape__init_part1_A_const_185 = A_arbace_go_escape__init_part1_A_const_pool.A[226]; A_arbace_go_escape__init_part1_A_const_186 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[227]); A_arbace_go_escape__init_part1_A_const_187 = A_arbace_go_escape__init_part1_A_const_pool.A[228]; A_arbace_go_escape__init_part1_A_const_188 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[229]); A_arbace_go_escape__init_part1_A_const_189 = A_arbace_go_escape__init_part1_A_const_pool.A[230]; A_arbace_go_escape__init_part1_A_const_190 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[231]); A_arbace_go_escape__init_part1_A_const_191 = A_arbace_go_escape__init_part1_A_const_pool.A[232]; A_arbace_go_escape__init_part1_A_const_192 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[233]); A_arbace_go_escape__init_part1_A_const_193 = A_arbace_go_escape__init_part1_A_const_pool.A[234]; A_arbace_go_escape__init_part1_A_const_194 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[235]); A_arbace_go_escape__init_part1_A_const_195 = A_arbace_go_escape__init_part1_A_const_pool.A[236]; A_arbace_go_escape__init_part1_A_const_196 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[237]); A_arbace_go_escape__init_part1_A_const_197 = A_arbace_go_escape__init_part1_A_const_pool.A[238]; A_arbace_go_escape__init_part1_A_const_198 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[239]); A_arbace_go_escape__init_part1_A_const_199 = A_arbace_go_escape__init_part1_A_const_pool.A[240]; A_arbace_go_escape__init_part1_A_const_200 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[241]); A_arbace_go_escape__init_part1_A_const_201 = A_arbace_go_escape__init_part1_A_const_pool.A[242]; A_arbace_go_escape__init_part1_A_const_202 = lang.Var_Cast(A_arbace_go_escape__init_part1_A_const_pool.A[243]); A_arbace_go_escape__init_part1_A_const_203 = A_arbace_go_escape__init_part1_A_const_pool.A[244]; A_arbace_go_escape__init_part1_A_const_204 = A_arbace_go_escape__init_part1_A_const_pool.A[245] }

func A_arbace_go_escape__init_part1_A_New() *A_arbace_go_escape__init_part1_A { A_arbace_go_escape__init_part1_A_Init(); t := &A_arbace_go_escape__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_go_escape__init_part1_A) Ctor() {}

func (t *A_arbace_go_escape__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_escape__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_go_escape__init_part1_A_class }

func (t *A_arbace_go_escape__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_escape__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_escape__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_escape__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_escape__init_part1_A); return ok }

func A_arbace_go_escape__init_part1_A_Cast(x any) *A_arbace_go_escape__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_escape__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_escape__init_part1_A_class)) }; return v }



type A_arbace_go_escape__init_part2_A struct{ jrt.Object }

var A_arbace_go_escape__init_part2_A_const_pool *jrt.RefArray

var A_arbace_go_escape__init_part2_A_const_0 *lang.Var

var A_arbace_go_escape__init_part2_A_const_1 *lang.Var

var A_arbace_go_escape__init_part2_A_const_2 any

var A_arbace_go_escape__init_part2_A_const_3 any

var A_arbace_go_escape__init_part2_A_const_4 *lang.Var

var A_arbace_go_escape__init_part2_A_const_5 any

var A_arbace_go_escape__init_part2_A_const_6 *lang.Var

var A_arbace_go_escape__init_part2_A_const_7 any

var A_arbace_go_escape__init_part2_A_const_8 *lang.Var

var A_arbace_go_escape__init_part2_A_const_9 any

var A_arbace_go_escape__init_part2_A_const_10 *lang.Var

var A_arbace_go_escape__init_part2_A_const_11 any

var A_arbace_go_escape__init_part2_A_const_12 *lang.Var

var A_arbace_go_escape__init_part2_A_const_13 any

var A_arbace_go_escape__init_part2_A_const_14 *lang.Var

var A_arbace_go_escape__init_part2_A_const_15 any

var A_arbace_go_escape__init_part2_A_const_16 *lang.Var

var A_arbace_go_escape__init_part2_A_const_17 any

var A_arbace_go_escape__init_part2_A_const_18 *lang.Var

var A_arbace_go_escape__init_part2_A_const_19 any

var A_arbace_go_escape__init_part2_A_const_20 *lang.Var

var A_arbace_go_escape__init_part2_A_const_21 any

var A_arbace_go_escape__init_part2_A_const_22 *lang.Var

var A_arbace_go_escape__init_part2_A_const_23 any

var A_arbace_go_escape__init_part2_A_const_24 any

var A_arbace_go_escape__init_part2_A_const_25 *lang.Var

var A_arbace_go_escape__init_part2_A_const_26 any

var A_arbace_go_escape__init_part2_A_const_27 *lang.Var

var A_arbace_go_escape__init_part2_A_const_28 any

var A_arbace_go_escape__init_part2_A_const_29 *lang.Var

var A_arbace_go_escape__init_part2_A_const_30 any

var A_arbace_go_escape__init_part2_A_const_31 *lang.Var

var A_arbace_go_escape__init_part2_A_const_32 any

var A_arbace_go_escape__init_part2_A_const_33 *lang.Var

var A_arbace_go_escape__init_part2_A_const_34 any

var A_arbace_go_escape__init_part2_A_const_35 *lang.Var

var A_arbace_go_escape__init_part2_A_const_36 any

var A_arbace_go_escape__init_part2_A_const_37 *lang.Var

var A_arbace_go_escape__init_part2_A_const_38 any

var A_arbace_go_escape__init_part2_A_const_39 *lang.Var

var A_arbace_go_escape__init_part2_A_const_40 any

var A_arbace_go_escape__init_part2_A_const_41 *lang.Var

var A_arbace_go_escape__init_part2_A_const_42 *lang.Var

var A_arbace_go_escape__init_part2_A_const_43 any

var A_arbace_go_escape__init_part2_A_const_44 any

var A_arbace_go_escape__init_part2_A_const_45 *lang.Var

var A_arbace_go_escape__init_part2_A_const_46 any

var A_arbace_go_escape__init_part2_A_const_47 *lang.Var

var A_arbace_go_escape__init_part2_A_const_48 any

var A_arbace_go_escape__init_part2_A_const_49 *lang.Var

var A_arbace_go_escape__init_part2_A_const_50 any

var A_arbace_go_escape__init_part2_A_const_51 *lang.Var

var A_arbace_go_escape__init_part2_A_const_52 any

var A_arbace_go_escape__init_part2_A_const_53 *lang.Var

var A_arbace_go_escape__init_part2_A_const_54 any

var A_arbace_go_escape__init_part2_A_const_55 *lang.Var

var A_arbace_go_escape__init_part2_A_const_56 any

var A_arbace_go_escape__init_part2_A_const_57 *lang.Var

var A_arbace_go_escape__init_part2_A_const_58 any

var A_arbace_go_escape__init_part2_A_const_59 *lang.Var

var A_arbace_go_escape__init_part2_A_const_60 any

var A_arbace_go_escape__init_part2_A_const_61 *lang.Var

var A_arbace_go_escape__init_part2_A_const_62 any

var A_arbace_go_escape__init_part2_A_const_63 *lang.Var

var A_arbace_go_escape__init_part2_A_const_64 any

var A_arbace_go_escape__init_part2_A_const_65 *lang.Var

var A_arbace_go_escape__init_part2_A_const_66 any

var A_arbace_go_escape__init_part2_A_const_67 *lang.Var

var A_arbace_go_escape__init_part2_A_const_68 any

var A_arbace_go_escape__init_part2_A_const_69 *lang.Var

var A_arbace_go_escape__init_part2_A_const_70 any

var A_arbace_go_escape__init_part2_A_const_71 *lang.Var

var A_arbace_go_escape__init_part2_A_const_72 any

var A_arbace_go_escape__init_part2_A_const_73 *lang.Var

var A_arbace_go_escape__init_part2_A_const_74 any

var A_arbace_go_escape__init_part2_A_const_75 *lang.Var

var A_arbace_go_escape__init_part2_A_const_76 any

var A_arbace_go_escape__init_part2_A_const_77 *lang.Var

var A_arbace_go_escape__init_part2_A_const_78 any

var A_arbace_go_escape__init_part2_A_const_79 *lang.Var

var A_arbace_go_escape__init_part2_A_const_80 any

var A_arbace_go_escape__init_part2_A_const_81 *lang.Var

var A_arbace_go_escape__init_part2_A_const_82 any

var A_arbace_go_escape__init_part2_A_const_83 *lang.Var

var A_arbace_go_escape__init_part2_A_const_84 any

var A_arbace_go_escape__init_part2_A_const_85 *lang.Var

var A_arbace_go_escape__init_part2_A_const_86 any

var A_arbace_go_escape__init_part2_A_const_87 *lang.Var

var A_arbace_go_escape__init_part2_A_const_88 any

var A_arbace_go_escape__init_part2_A_const_89 *lang.Var

var A_arbace_go_escape__init_part2_A_const_90 any

var A_arbace_go_escape__init_part2_A_const_91 *lang.Var

var A_arbace_go_escape__init_part2_A_const_92 any

var A_arbace_go_escape__init_part2_A_const_93 *lang.Var

var A_arbace_go_escape__init_part2_A_const_94 any

var A_arbace_go_escape__init_part2_A_const_95 *lang.Var

var A_arbace_go_escape__init_part2_A_const_96 any

var A_arbace_go_escape__init_part2_A_const_97 *lang.Var

var A_arbace_go_escape__init_part2_A_const_98 any

var A_arbace_go_escape__init_part2_A_const_99 *lang.Var

var A_arbace_go_escape__init_part2_A_const_100 any

var A_arbace_go_escape__init_part2_A_const_101 *lang.Var

var A_arbace_go_escape__init_part2_A_const_102 any

var A_arbace_go_escape__init_part2_A_const_103 *lang.Var

var A_arbace_go_escape__init_part2_A_const_104 any

var A_arbace_go_escape__init_part2_A_const_105 *lang.Var

var A_arbace_go_escape__init_part2_A_const_106 any

var A_arbace_go_escape__init_part2_A_const_107 *lang.Var

var A_arbace_go_escape__init_part2_A_const_108 any

var A_arbace_go_escape__init_part2_A_const_109 *lang.Var

var A_arbace_go_escape__init_part2_A_const_110 any

var A_arbace_go_escape__init_part2_A_const_111 *lang.Var

var A_arbace_go_escape__init_part2_A_const_112 any

var A_arbace_go_escape__init_part2_A_const_113 *lang.Var

var A_arbace_go_escape__init_part2_A_const_114 any

var A_arbace_go_escape__init_part2_A_const_115 *lang.Var

var A_arbace_go_escape__init_part2_A_const_116 any

var A_arbace_go_escape__init_part2_A_const_117 *lang.Var

var A_arbace_go_escape__init_part2_A_const_118 any

var A_arbace_go_escape__init_part2_A_const_119 *lang.Var

var A_arbace_go_escape__init_part2_A_const_120 any

var A_arbace_go_escape__init_part2_A_const_121 *lang.Var

var A_arbace_go_escape__init_part2_A_const_122 any

var A_arbace_go_escape__init_part2_A_const_123 *lang.Var

var A_arbace_go_escape__init_part2_A_const_124 any

var A_arbace_go_escape__init_part2_A_const_125 *lang.Var

var A_arbace_go_escape__init_part2_A_const_126 any

var A_arbace_go_escape__init_part2_A_const_127 *lang.Var

var A_arbace_go_escape__init_part2_A_const_128 any

var A_arbace_go_escape__init_part2_A_const_129 any

var A_arbace_go_escape__init_part2_A_init jrt.ClassInit

func A_arbace_go_escape__init_part2_A_Init() { if !A_arbace_go_escape__init_part2_A_init.Done() { A_arbace_go_escape__init_part2_A_init.Run(A_arbace_go_escape__init_part2_A_clinit) } }

func A_arbace_go_escape__init_part2_A_clinit() { A_arbace_go_escape__init_part2_A_clinit_p0(); A_arbace_go_escape__init_part2_A_clinit_p1() }

func A_arbace_go_escape__init_part2_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_escape__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_666, 161); A_arbace_go_escape__init_part2_A_const_0 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[42]); A_arbace_go_escape__init_part2_A_const_1 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[43]); A_arbace_go_escape__init_part2_A_const_2 = A_arbace_go_escape__init_part2_A_const_pool.A[44]; A_arbace_go_escape__init_part2_A_const_3 = A_arbace_go_escape__init_part2_A_const_pool.A[45]; A_arbace_go_escape__init_part2_A_const_4 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[46]); A_arbace_go_escape__init_part2_A_const_5 = A_arbace_go_escape__init_part2_A_const_pool.A[47]; A_arbace_go_escape__init_part2_A_const_6 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[48]); A_arbace_go_escape__init_part2_A_const_7 = A_arbace_go_escape__init_part2_A_const_pool.A[49]; A_arbace_go_escape__init_part2_A_const_8 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[50]); A_arbace_go_escape__init_part2_A_const_9 = A_arbace_go_escape__init_part2_A_const_pool.A[51]; A_arbace_go_escape__init_part2_A_const_10 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[52]); A_arbace_go_escape__init_part2_A_const_11 = A_arbace_go_escape__init_part2_A_const_pool.A[53] }

func A_arbace_go_escape__init_part2_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp1 = A_arbace_go_escape__init_part1_A_const_186; A_arbace_go_escape__init_part2_A_const_12 = tmp1; A_arbace_go_escape__init_part2_A_const_13 = A_arbace_go_escape__init_part2_A_const_pool.A[54]; A_arbace_go_escape__init_part2_A_const_14 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[55]); A_arbace_go_escape__init_part2_A_const_15 = A_arbace_go_escape__init_part2_A_const_pool.A[56]; var tmp2 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp2 = A_arbace_go_escape__init_part1_A_const_188; A_arbace_go_escape__init_part2_A_const_16 = tmp2; A_arbace_go_escape__init_part2_A_const_17 = A_arbace_go_escape__init_part2_A_const_pool.A[57]; A_arbace_go_escape__init_part2_A_const_18 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[58]); A_arbace_go_escape__init_part2_A_const_19 = A_arbace_go_escape__init_part2_A_const_pool.A[59]; A_arbace_go_escape__init_part2_A_const_20 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[60]); A_arbace_go_escape__init_part2_A_const_21 = A_arbace_go_escape__init_part2_A_const_pool.A[61]; A_arbace_go_escape__init_part2_A_const_22 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[62]); A_arbace_go_escape__init_part2_A_const_23 = A_arbace_go_escape__init_part2_A_const_pool.A[63]; A_arbace_go_escape__init_part2_A_const_24 = A_arbace_go_escape__init_part2_A_const_pool.A[64]; A_arbace_go_escape__init_part2_A_const_25 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[65]); A_arbace_go_escape__init_part2_A_const_26 = A_arbace_go_escape__init_part2_A_const_pool.A[66]; var tmp3 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp3 = A_arbace_go_escape__init_part1_A_const_182; A_arbace_go_escape__init_part2_A_const_27 = tmp3; A_arbace_go_escape__init_part2_A_const_28 = A_arbace_go_escape__init_part2_A_const_pool.A[67]; var tmp4 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp4 = A_arbace_go_escape__init_part1_A_const_180; A_arbace_go_escape__init_part2_A_const_29 = tmp4; A_arbace_go_escape__init_part2_A_const_30 = A_arbace_go_escape__init_part2_A_const_pool.A[68]; A_arbace_go_escape__init_part2_A_const_31 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[69]); A_arbace_go_escape__init_part2_A_const_32 = A_arbace_go_escape__init_part2_A_const_pool.A[70]; A_arbace_go_escape__init_part2_A_const_33 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[71]); A_arbace_go_escape__init_part2_A_const_34 = A_arbace_go_escape__init_part2_A_const_pool.A[72]; A_arbace_go_escape__init_part2_A_const_35 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[73]); A_arbace_go_escape__init_part2_A_const_36 = A_arbace_go_escape__init_part2_A_const_pool.A[74]; A_arbace_go_escape__init_part2_A_const_37 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[75]); A_arbace_go_escape__init_part2_A_const_38 = A_arbace_go_escape__init_part2_A_const_pool.A[76]; var tmp5 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp5 = A_arbace_go_escape__init_part1_A_const_184; A_arbace_go_escape__init_part2_A_const_39 = tmp5; A_arbace_go_escape__init_part2_A_const_40 = A_arbace_go_escape__init_part2_A_const_pool.A[77]; A_arbace_go_escape__init_part2_A_const_41 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[78]); A_arbace_go_escape__init_part2_A_const_42 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[79]); A_arbace_go_escape__init_part2_A_const_43 = A_arbace_go_escape__init_part2_A_const_pool.A[80]; A_arbace_go_escape__init_part2_A_const_44 = A_arbace_go_escape__init_part2_A_const_pool.A[81]; A_arbace_go_escape__init_part2_A_const_45 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[82]); A_arbace_go_escape__init_part2_A_const_46 = A_arbace_go_escape__init_part2_A_const_pool.A[83]; A_arbace_go_escape__init_part2_A_const_47 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[84]); A_arbace_go_escape__init_part2_A_const_48 = A_arbace_go_escape__init_part2_A_const_pool.A[85]; A_arbace_go_escape__init_part2_A_const_49 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[86]); A_arbace_go_escape__init_part2_A_const_50 = A_arbace_go_escape__init_part2_A_const_pool.A[87]; A_arbace_go_escape__init_part2_A_const_51 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[88]); A_arbace_go_escape__init_part2_A_const_52 = A_arbace_go_escape__init_part2_A_const_pool.A[89]; A_arbace_go_escape__init_part2_A_const_53 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[90]); A_arbace_go_escape__init_part2_A_const_54 = A_arbace_go_escape__init_part2_A_const_pool.A[91]; A_arbace_go_escape__init_part2_A_const_55 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[92]); A_arbace_go_escape__init_part2_A_const_56 = A_arbace_go_escape__init_part2_A_const_pool.A[93]; A_arbace_go_escape__init_part2_A_const_57 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[94]); A_arbace_go_escape__init_part2_A_const_58 = A_arbace_go_escape__init_part2_A_const_pool.A[95]; A_arbace_go_escape__init_part2_A_const_59 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[96]); A_arbace_go_escape__init_part2_A_const_60 = A_arbace_go_escape__init_part2_A_const_pool.A[97]; A_arbace_go_escape__init_part2_A_const_61 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[98]); A_arbace_go_escape__init_part2_A_const_62 = A_arbace_go_escape__init_part2_A_const_pool.A[99]; A_arbace_go_escape__init_part2_A_const_63 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[100]); A_arbace_go_escape__init_part2_A_const_64 = A_arbace_go_escape__init_part2_A_const_pool.A[101]; var tmp6 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp6 = A_arbace_go_escape__init_part1_A_const_192; A_arbace_go_escape__init_part2_A_const_65 = tmp6; A_arbace_go_escape__init_part2_A_const_66 = A_arbace_go_escape__init_part2_A_const_pool.A[102]; var tmp7 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp7 = A_arbace_go_escape__init_part1_A_const_194; A_arbace_go_escape__init_part2_A_const_67 = tmp7; A_arbace_go_escape__init_part2_A_const_68 = A_arbace_go_escape__init_part2_A_const_pool.A[103]; var tmp8 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp8 = A_arbace_go_escape__init_part1_A_const_190; A_arbace_go_escape__init_part2_A_const_69 = tmp8; A_arbace_go_escape__init_part2_A_const_70 = A_arbace_go_escape__init_part2_A_const_pool.A[104]; A_arbace_go_escape__init_part2_A_const_71 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[105]); A_arbace_go_escape__init_part2_A_const_72 = A_arbace_go_escape__init_part2_A_const_pool.A[106]; A_arbace_go_escape__init_part2_A_const_73 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[107]); A_arbace_go_escape__init_part2_A_const_74 = A_arbace_go_escape__init_part2_A_const_pool.A[108]; A_arbace_go_escape__init_part2_A_const_75 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[109]); A_arbace_go_escape__init_part2_A_const_76 = A_arbace_go_escape__init_part2_A_const_pool.A[110]; A_arbace_go_escape__init_part2_A_const_77 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[111]); A_arbace_go_escape__init_part2_A_const_78 = A_arbace_go_escape__init_part2_A_const_pool.A[112]; A_arbace_go_escape__init_part2_A_const_79 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[113]); A_arbace_go_escape__init_part2_A_const_80 = A_arbace_go_escape__init_part2_A_const_pool.A[114]; A_arbace_go_escape__init_part2_A_const_81 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[115]); A_arbace_go_escape__init_part2_A_const_82 = A_arbace_go_escape__init_part2_A_const_pool.A[116]; A_arbace_go_escape__init_part2_A_const_83 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[117]); A_arbace_go_escape__init_part2_A_const_84 = A_arbace_go_escape__init_part2_A_const_pool.A[118]; A_arbace_go_escape__init_part2_A_const_85 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[119]); A_arbace_go_escape__init_part2_A_const_86 = A_arbace_go_escape__init_part2_A_const_pool.A[120]; A_arbace_go_escape__init_part2_A_const_87 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[121]); A_arbace_go_escape__init_part2_A_const_88 = A_arbace_go_escape__init_part2_A_const_pool.A[122]; A_arbace_go_escape__init_part2_A_const_89 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[123]); A_arbace_go_escape__init_part2_A_const_90 = A_arbace_go_escape__init_part2_A_const_pool.A[124]; A_arbace_go_escape__init_part2_A_const_91 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[125]); A_arbace_go_escape__init_part2_A_const_92 = A_arbace_go_escape__init_part2_A_const_pool.A[126]; A_arbace_go_escape__init_part2_A_const_93 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[127]); A_arbace_go_escape__init_part2_A_const_94 = A_arbace_go_escape__init_part2_A_const_pool.A[128]; A_arbace_go_escape__init_part2_A_const_95 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[129]); A_arbace_go_escape__init_part2_A_const_96 = A_arbace_go_escape__init_part2_A_const_pool.A[130]; A_arbace_go_escape__init_part2_A_const_97 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[131]); A_arbace_go_escape__init_part2_A_const_98 = A_arbace_go_escape__init_part2_A_const_pool.A[132]; A_arbace_go_escape__init_part2_A_const_99 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[133]); A_arbace_go_escape__init_part2_A_const_100 = A_arbace_go_escape__init_part2_A_const_pool.A[134]; A_arbace_go_escape__init_part2_A_const_101 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[135]); A_arbace_go_escape__init_part2_A_const_102 = A_arbace_go_escape__init_part2_A_const_pool.A[136]; A_arbace_go_escape__init_part2_A_const_103 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[137]); A_arbace_go_escape__init_part2_A_const_104 = A_arbace_go_escape__init_part2_A_const_pool.A[138]; var tmp9 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp9 = A_arbace_go_escape__init_part1_A_const_196; A_arbace_go_escape__init_part2_A_const_105 = tmp9; A_arbace_go_escape__init_part2_A_const_106 = A_arbace_go_escape__init_part2_A_const_pool.A[139]; A_arbace_go_escape__init_part2_A_const_107 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[140]); A_arbace_go_escape__init_part2_A_const_108 = A_arbace_go_escape__init_part2_A_const_pool.A[141]; A_arbace_go_escape__init_part2_A_const_109 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[142]); A_arbace_go_escape__init_part2_A_const_110 = A_arbace_go_escape__init_part2_A_const_pool.A[143]; A_arbace_go_escape__init_part2_A_const_111 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[144]); A_arbace_go_escape__init_part2_A_const_112 = A_arbace_go_escape__init_part2_A_const_pool.A[145]; A_arbace_go_escape__init_part2_A_const_113 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[146]); A_arbace_go_escape__init_part2_A_const_114 = A_arbace_go_escape__init_part2_A_const_pool.A[147]; A_arbace_go_escape__init_part2_A_const_115 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[148]); A_arbace_go_escape__init_part2_A_const_116 = A_arbace_go_escape__init_part2_A_const_pool.A[149]; A_arbace_go_escape__init_part2_A_const_117 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[150]); A_arbace_go_escape__init_part2_A_const_118 = A_arbace_go_escape__init_part2_A_const_pool.A[151]; var tmp10 *lang.Var; A_arbace_go_escape__init_part0_A_Init(); tmp10 = A_arbace_go_escape__init_part0_A_const_129; A_arbace_go_escape__init_part2_A_const_119 = tmp10; A_arbace_go_escape__init_part2_A_const_120 = A_arbace_go_escape__init_part2_A_const_pool.A[152]; A_arbace_go_escape__init_part2_A_const_121 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[153]); A_arbace_go_escape__init_part2_A_const_122 = A_arbace_go_escape__init_part2_A_const_pool.A[154]; A_arbace_go_escape__init_part2_A_const_123 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[155]); A_arbace_go_escape__init_part2_A_const_124 = A_arbace_go_escape__init_part2_A_const_pool.A[156]; var tmp11 *lang.Var; A_arbace_go_escape__init_part1_A_Init(); tmp11 = A_arbace_go_escape__init_part1_A_const_178; A_arbace_go_escape__init_part2_A_const_125 = tmp11; A_arbace_go_escape__init_part2_A_const_126 = A_arbace_go_escape__init_part2_A_const_pool.A[157]; A_arbace_go_escape__init_part2_A_const_127 = lang.Var_Cast(A_arbace_go_escape__init_part2_A_const_pool.A[158]); A_arbace_go_escape__init_part2_A_const_128 = A_arbace_go_escape__init_part2_A_const_pool.A[159]; A_arbace_go_escape__init_part2_A_const_129 = A_arbace_go_escape__init_part2_A_const_pool.A[160] }

func A_arbace_go_escape__init_part2_A_New() *A_arbace_go_escape__init_part2_A { A_arbace_go_escape__init_part2_A_Init(); t := &A_arbace_go_escape__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_go_escape__init_part2_A) Ctor() {}

func (t *A_arbace_go_escape__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_escape__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_go_escape__init_part2_A_class }

func (t *A_arbace_go_escape__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_escape__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_escape__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_escape__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_escape__init_part2_A); return ok }

func A_arbace_go_escape__init_part2_A_Cast(x any) *A_arbace_go_escape__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_escape__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_escape__init_part2_A_class)) }; return v }
