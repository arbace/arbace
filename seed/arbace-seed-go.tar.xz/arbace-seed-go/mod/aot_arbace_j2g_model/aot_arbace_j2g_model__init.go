//line aot_arbace_j2g_model__init.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model__init_part0_A_Unit0__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_model__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model__init_part0_A_const_1) }
//line :1:1
func A_arbace_j2g_model__init_part0_A_Unit1__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_model__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_2)) }
//line :1:1
func A_arbace_j2g_model__init_part0_A_Unit2__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_model__init_part0_A_Unit3__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_model__init_part0_A_const_1)).Equals_O__Z(A_arbace_j2g_model__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, nil); A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_j2g_model__init_part0_A_Init__O() any { A_arbace_j2g_model__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_j2g_model__init_part0_A_Load__O() any { A_arbace_j2g_model__init_part0_A_Init(); A_arbace_j2g_model__init_part0_A_Unit0__O(); A_arbace_j2g_model__init_part0_A_Unit1__O(); A_arbace_j2g_model__init_part0_A_Unit2__O(); A_arbace_j2g_model__init_part0_A_Unit3__O(); A_arbace_j2g_model__init_part0_A_Unit4__O(); A_arbace_j2g_model__init_part0_A_Unit5__O(); A_arbace_j2g_model__init_part0_A_Unit6__O(); A_arbace_j2g_model__init_part0_A_Unit7__O(); A_arbace_j2g_model__init_part0_A_Unit8__O(); A_arbace_j2g_model__init_part0_A_Unit9__O(); A_arbace_j2g_model__init_part0_A_Unit10__O(); A_arbace_j2g_model__init_part0_A_Unit11__O(); A_arbace_j2g_model__init_part0_A_Unit12__O(); A_arbace_j2g_model__init_part0_A_Unit13__O(); A_arbace_j2g_model__init_part0_A_Unit14__O(); A_arbace_j2g_model__init_part0_A_Unit15__O(); A_arbace_j2g_model__init_part0_A_Unit16__O(); A_arbace_j2g_model__init_part0_A_Unit17__O(); A_arbace_j2g_model__init_part0_A_Unit18__O(); A_arbace_j2g_model__init_part0_A_Unit19__O(); A_arbace_j2g_model__init_part0_A_Unit20__O(); A_arbace_j2g_model__init_part0_A_Unit21__O(); A_arbace_j2g_model__init_part0_A_Unit22__O(); A_arbace_j2g_model__init_part0_A_Unit23__O(); A_arbace_j2g_model__init_part0_A_Unit24__O(); A_arbace_j2g_model__init_part0_A_Unit25__O(); A_arbace_j2g_model__init_part0_A_Unit26__O(); A_arbace_j2g_model__init_part0_A_Unit27__O(); A_arbace_j2g_model__init_part0_A_Unit28__O(); A_arbace_j2g_model__init_part0_A_Unit29__O(); A_arbace_j2g_model__init_part0_A_Unit30__O(); A_arbace_j2g_model__init_part0_A_Unit31__O(); A_arbace_j2g_model__init_part0_A_Unit32__O(); A_arbace_j2g_model__init_part0_A_Unit33__O(); A_arbace_j2g_model__init_part0_A_Unit34__O(); A_arbace_j2g_model__init_part0_A_Unit35__O(); A_arbace_j2g_model__init_part0_A_Unit36__O(); A_arbace_j2g_model__init_part0_A_Unit37__O(); A_arbace_j2g_model__init_part0_A_Unit38__O(); A_arbace_j2g_model__init_part0_A_Unit39__O(); A_arbace_j2g_model__init_part0_A_Unit40__O(); A_arbace_j2g_model__init_part0_A_Unit41__O(); A_arbace_j2g_model__init_part0_A_Unit42__O(); A_arbace_j2g_model__init_part0_A_Unit43__O(); A_arbace_j2g_model__init_part0_A_Unit44__O(); A_arbace_j2g_model__init_part0_A_Unit45__O(); A_arbace_j2g_model__init_part0_A_Unit46__O(); A_arbace_j2g_model__init_part0_A_Unit47__O(); A_arbace_j2g_model__init_part0_A_Unit48__O(); A_arbace_j2g_model__init_part0_A_Unit49__O(); A_arbace_j2g_model__init_part0_A_Unit50__O(); A_arbace_j2g_model__init_part0_A_Unit51__O(); A_arbace_j2g_model__init_part0_A_Unit52__O(); A_arbace_j2g_model__init_part0_A_Unit53__O(); A_arbace_j2g_model__init_part0_A_Unit54__O(); A_arbace_j2g_model__init_part0_A_Unit55__O(); A_arbace_j2g_model__init_part0_A_Unit56__O(); A_arbace_j2g_model__init_part0_A_Unit57__O(); A_arbace_j2g_model__init_part0_A_Unit58__O(); A_arbace_j2g_model__init_part0_A_Unit59__O(); A_arbace_j2g_model__init_part0_A_Unit60__O(); A_arbace_j2g_model__init_part0_A_Unit61__O(); A_arbace_j2g_model__init_part0_A_Unit62__O(); A_arbace_j2g_model__init_part0_A_Unit63__O(); A_arbace_j2g_model__init_part0_A_Unit64__O(); A_arbace_j2g_model__init_part0_A_Unit65__O(); A_arbace_j2g_model__init_part0_A_Unit66__O(); A_arbace_j2g_model__init_part0_A_Unit67__O(); A_arbace_j2g_model__init_part0_A_Unit68__O(); A_arbace_j2g_model__init_part0_A_Unit69__O(); A_arbace_j2g_model__init_part0_A_Unit70__O(); A_arbace_j2g_model__init_part0_A_Unit71__O(); A_arbace_j2g_model__init_part0_A_Unit72__O(); A_arbace_j2g_model__init_part0_A_Unit73__O(); A_arbace_j2g_model__init_part0_A_Unit74__O(); A_arbace_j2g_model__init_part0_A_Unit75__O(); A_arbace_j2g_model__init_part0_A_Unit76__O(); A_arbace_j2g_model__init_part0_A_Unit77__O(); A_arbace_j2g_model__init_part0_A_Unit78__O(); A_arbace_j2g_model__init_part0_A_Unit79__O(); A_arbace_j2g_model__init_part0_A_Unit80__O(); A_arbace_j2g_model__init_part0_A_Unit81__O(); A_arbace_j2g_model__init_part0_A_Unit82__O(); A_arbace_j2g_model__init_part0_A_Unit83__O(); A_arbace_j2g_model__init_part0_A_Unit84__O(); A_arbace_j2g_model__init_part0_A_Unit85__O(); A_arbace_j2g_model__init_part0_A_Unit86__O(); A_arbace_j2g_model__init_part0_A_Unit87__O(); A_arbace_j2g_model__init_part0_A_Unit88__O(); A_arbace_j2g_model__init_part0_A_Unit89__O(); A_arbace_j2g_model__init_part0_A_Unit90__O(); A_arbace_j2g_model__init_part0_A_Unit91__O(); A_arbace_j2g_model__init_part0_A_Unit92__O(); A_arbace_j2g_model__init_part0_A_Unit93__O(); A_arbace_j2g_model__init_part0_A_Unit94__O(); A_arbace_j2g_model__init_part0_A_Unit95__O(); A_arbace_j2g_model__init_part0_A_Unit96__O(); A_arbace_j2g_model__init_part0_A_Unit97__O(); A_arbace_j2g_model__init_part0_A_Unit98__O(); A_arbace_j2g_model__init_part0_A_Unit99__O(); return nil }



func A_arbace_j2g_model__init_A_Load__O() any { jrt.StartCheck(); A_arbace_j2g_model__init_part0_A_Init__O(); A_arbace_j2g_model__init_part1_A_Init__O(); A_arbace_j2g_model__init_part0_A_Load__O(); A_arbace_j2g_model__init_part1_A_Load__O(); return nil }









func A_arbace_j2g_model__init_part0_A_Unit4__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); A_arbace_j2g_model__init_part0_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_5)); return A_arbace_j2g_model__init_part0_A_const_4.SetDynamic_Z__Var(true).Ref() }










func A_arbace_j2g_model__init_part0_A_Unit5__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); A_arbace_j2g_model__init_part0_A_const_6.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_7)); return A_arbace_j2g_model__init_part0_A_const_6.SetDynamic_Z__Var(true).Ref() }



func A_arbace_j2g_model__init_part0_A_Unit6__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_model_on_run_thread_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_model_on_run_thread_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_j2g_model_on_run_thread_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_9)); return A_arbace_j2g_model__init_part0_A_const_8 }




func A_arbace_j2g_model__init_part0_A_Unit7__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_model_run_fn_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_model_run_fn_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_j2g_model_run_fn_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_11)); return A_arbace_j2g_model__init_part0_A_const_10 }







func A_arbace_j2g_model__init_part0_A_Unit8__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); A_arbace_j2g_model__init_part0_A_const_12.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_13); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_14)); return A_arbace_j2g_model__init_part0_A_const_12 }




func A_arbace_j2g_model__init_part0_A_Unit9__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_model_jobs_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_model_jobs_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_j2g_model_jobs_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_16)); return A_arbace_j2g_model__init_part0_A_const_15 }








func A_arbace_j2g_model__init_part0_A_Unit10__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_17; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__12 any = A_arbace_j2g_model_par_mapv_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_model_par_mapv_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, true, nil); A_arbace_j2g_model_par_mapv_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__12, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_18)); return A_arbace_j2g_model__init_part0_A_const_17 }































func A_arbace_j2g_model__init_part0_A_Unit11__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_model_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_model_has_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_j2g_model_has_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_20)); return A_arbace_j2g_model__init_part0_A_const_19 }

func A_arbace_j2g_model__init_part0_A_Unit12__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_model_T_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_model_T_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_j2g_model_T_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_22)); return A_arbace_j2g_model__init_part0_A_const_21 }

func A_arbace_j2g_model__init_part0_A_Unit13__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_model_translated_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_model_translated_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_j2g_model_translated_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_24)); return A_arbace_j2g_model__init_part0_A_const_23 }

func A_arbace_j2g_model__init_part0_A_Unit14__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); A_arbace_j2g_model__init_part0_A_const_25.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_26); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_27)); return A_arbace_j2g_model__init_part0_A_const_25 }















func A_arbace_j2g_model__init_part0_A_Unit15__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_model_serial_accessor_bases_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_model_serial_accessor_bases_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, nil); A_arbace_j2g_model_serial_accessor_bases_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_29)); return A_arbace_j2g_model__init_part0_A_const_28 }





func A_arbace_j2g_model__init_part0_A_Unit16__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_model_j2g_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_model_j2g_static_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, nil); A_arbace_j2g_model_j2g_static_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_31)); return A_arbace_j2g_model__init_part0_A_const_30 }














func A_arbace_j2g_model__init_part0_A_Unit17__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_model_jrt_class_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_model_jrt_class_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, nil); A_arbace_j2g_model_jrt_class_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_33)); return A_arbace_j2g_model__init_part0_A_const_32 }




func A_arbace_j2g_model__init_part0_A_Unit18__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_model_hand_written_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_model_hand_written_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, nil); A_arbace_j2g_model_hand_written_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_35)); return A_arbace_j2g_model__init_part0_A_const_34 }




func A_arbace_j2g_model__init_part0_A_Unit19__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_model_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_model_in_world_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, nil); A_arbace_j2g_model_in_world_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_37)); return A_arbace_j2g_model__init_part0_A_const_36 }


func A_arbace_j2g_model__init_part0_A_Unit20__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_model_translatable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_model_translatable_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, nil); A_arbace_j2g_model_translatable_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_39)); return A_arbace_j2g_model__init_part0_A_const_38 }




func A_arbace_j2g_model__init_part0_A_Unit21__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(150, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_model_reflectable_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, nil); A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_41)); return A_arbace_j2g_model__init_part0_A_const_40 }

















func A_arbace_j2g_model__init_part0_A_Unit22__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_model_reflected_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_model_reflected_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_j2g_model_reflected_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_43)); return A_arbace_j2g_model__init_part0_A_const_42 }




func A_arbace_j2g_model__init_part0_A_Unit23__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_model_info_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_model_info_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, nil); A_arbace_j2g_model_info_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_45)); return A_arbace_j2g_model__init_part0_A_const_44 }
func A_arbace_j2g_model__init_part0_A_Unit24__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_model_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_model_interface_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, nil); A_arbace_j2g_model_interface_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_47)); return A_arbace_j2g_model__init_part0_A_const_46 }

func A_arbace_j2g_model__init_part0_A_Unit25__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_model_desc_classes_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_model_desc_classes_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, nil); A_arbace_j2g_model_desc_classes_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_49)); return A_arbace_j2g_model__init_part0_A_const_48 }








func A_arbace_j2g_model__init_part0_A_Unit26__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_50; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_j2g_model__init_part0_A_const_50; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_51)); return A_arbace_j2g_model__init_part0_A_const_50 }



func A_arbace_j2g_model__init_part0_A_Unit27__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(189, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_model_method_desc_classes_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_model_method_desc_classes_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, nil); A_arbace_j2g_model_method_desc_classes_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_53)); return A_arbace_j2g_model__init_part0_A_const_52 }






func A_arbace_j2g_model__init_part0_A_Unit28__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(196, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_model_erased_desc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_j2g_model_erased_desc_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_55)); return A_arbace_j2g_model__init_part0_A_const_54 }











func A_arbace_j2g_model__init_part0_A_Unit29__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(208, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_model_desc_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, nil); A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_57)); return A_arbace_j2g_model__init_part0_A_const_56 }
func A_arbace_j2g_model__init_part0_A_Unit30__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_model_mdesc_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, nil); A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_59)); return A_arbace_j2g_model__init_part0_A_const_58 }




func A_arbace_j2g_model__init_part0_A_Unit31__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_model_go_name_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_model_go_name_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_j2g_model_go_name_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_61)); return A_arbace_j2g_model__init_part0_A_const_60 }








func A_arbace_j2g_model__init_part0_A_Unit32__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_model_pkg_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_model_pkg_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, nil); A_arbace_j2g_model_pkg_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_63)); return A_arbace_j2g_model__init_part0_A_const_62 }

func A_arbace_j2g_model__init_part0_A_Unit33__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_j2g_model_abstract_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_model_abstract_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, nil); A_arbace_j2g_model_abstract_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_65)); return A_arbace_j2g_model__init_part0_A_const_64 }
func A_arbace_j2g_model__init_part0_A_Unit34__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_model_final_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_model_final_QMARK__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_j2g_model_final_QMARK__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_67)); return A_arbace_j2g_model__init_part0_A_const_66 }

func A_arbace_j2g_model__init_part0_A_Unit35__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(228, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_model_subclasses_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_model_subclasses_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_j2g_model_subclasses_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_69)); return A_arbace_j2g_model__init_part0_A_const_68 }




func A_arbace_j2g_model__init_part0_A_Unit36__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_j2g_model_make_subclass_index_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_model_make_subclass_index_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, nil); A_arbace_j2g_model_make_subclass_index_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_71)); return A_arbace_j2g_model__init_part0_A_const_70 }










func A_arbace_j2g_model__init_part0_A_Unit37__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); A_arbace_j2g_model__init_part0_A_const_72.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_73); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_74)); return A_arbace_j2g_model__init_part0_A_const_72 }












func A_arbace_j2g_model__init_part0_A_Unit38__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(257, 1); A_arbace_j2g_model__init_part0_A_const_75.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_76); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_75; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_77)); return A_arbace_j2g_model__init_part0_A_const_75 }


























































































func A_arbace_j2g_model__init_part0_A_Unit39__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(348, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_78; var tmp2 any; var root_61 any = A_arbace_j2g_model__init_part0_A_const_79.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var root_65 any = A_arbace_j2g_model__init_part0_A_const_80.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_j2g_model__init_part0_A_const_72.GetRawRoot__O(); var arg_69 any = A_arbace_j2g_model__init_part0_A_const_75.GetRawRoot__O(); if linked_66 == nil { arg_64 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { arg_64 = linked_66.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; if linked_62 == nil { tmp2 = ifn_63.Invoke_O__O(arg_64) } else { tmp2 = linked_62.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_61, arg_64) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_model__init_part0_A_const_78; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_81)); return A_arbace_j2g_model__init_part0_A_const_78 }

func A_arbace_j2g_model__init_part0_A_Unit40__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__71 any = A_arbace_j2g_model_leaf_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_j2g_model_leaf_QMARK__A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, nil); A_arbace_j2g_model_leaf_QMARK__A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_83)); return A_arbace_j2g_model__init_part0_A_const_82 }














func A_arbace_j2g_model__init_part0_A_Unit41__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__73 any = A_arbace_j2g_model_qualify_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_model_qualify_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, nil); A_arbace_j2g_model_qualify_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_85)); return A_arbace_j2g_model__init_part0_A_const_84 }




func A_arbace_j2g_model__init_part0_A_Unit42__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__75 any = A_arbace_j2g_model_class_sym_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_j2g_model_class_sym_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, nil); A_arbace_j2g_model_class_sym_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_87)); return A_arbace_j2g_model__init_part0_A_const_86 }




func A_arbace_j2g_model__init_part0_A_Unit43__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__77 any = A_arbace_j2g_model_jrt_sym_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_j2g_model_jrt_sym_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, nil); A_arbace_j2g_model_jrt_sym_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__77, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_89)); return A_arbace_j2g_model__init_part0_A_const_88 }

func A_arbace_j2g_model__init_part0_A_Unit44__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(377, 1); A_arbace_j2g_model__init_part0_A_const_90.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_91); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_92)); return A_arbace_j2g_model__init_part0_A_const_90 }

func A_arbace_j2g_model__init_part0_A_Unit45__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); A_arbace_j2g_model__init_part0_A_const_93.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_94); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_93; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_95)); return A_arbace_j2g_model__init_part0_A_const_93 }


func A_arbace_j2g_model__init_part0_A_Unit46__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(382, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__79 any = A_arbace_j2g_model_array_test_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_j2g_model_array_test_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, nil); A_arbace_j2g_model_array_test_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_97)); return A_arbace_j2g_model__init_part0_A_const_96 }













func A_arbace_j2g_model__init_part0_A_Unit47__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(396, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__81 any = A_arbace_j2g_model_go_type_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_j2g_model_go_type_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, nil); A_arbace_j2g_model_go_type_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_99)); return A_arbace_j2g_model__init_part0_A_const_98 }




















func A_arbace_j2g_model__init_part0_A_Unit48__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__83 any = A_arbace_j2g_model_pointer_desc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, nil); A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__83, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_101)); return A_arbace_j2g_model__init_part0_A_const_100 }








func A_arbace_j2g_model__init_part0_A_Unit49__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(426, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__85 any = A_arbace_j2g_model_iface_desc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_j2g_model_iface_desc_QMARK__A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, nil); A_arbace_j2g_model_iface_desc_QMARK__A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_103)); return A_arbace_j2g_model__init_part0_A_const_102 }







func A_arbace_j2g_model__init_part0_A_Unit50__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__87 any = A_arbace_j2g_model_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_j2g_model_static_QMARK__A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, nil); A_arbace_j2g_model_static_QMARK__A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__87, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_105)); return A_arbace_j2g_model__init_part0_A_const_104 }
func A_arbace_j2g_model__init_part0_A_Unit51__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__89 any = A_arbace_j2g_model_private_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_j2g_model_private_QMARK__A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, nil); A_arbace_j2g_model_private_QMARK__A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__89, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_107)); return A_arbace_j2g_model__init_part0_A_const_106 }
func A_arbace_j2g_model__init_part0_A_Unit52__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(436, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__91 any = A_arbace_j2g_model_abstract_m_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_j2g_model_abstract_m_QMARK__A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, nil); A_arbace_j2g_model_abstract_m_QMARK__A_fn_class = fncls__90d; tmp3 = fncls__90d } else { tmp3 = fncls__90 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__91, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_109)); return A_arbace_j2g_model__init_part0_A_const_108 }

func A_arbace_j2g_model__init_part0_A_Unit53__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(438, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__93 any = A_arbace_j2g_model_methods_of_A_New(); var tmp3 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_j2g_model_methods_of_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, nil); A_arbace_j2g_model_methods_of_A_fn_class = fncls__92d; tmp3 = fncls__92d } else { tmp3 = fncls__92 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__93, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_111)); return A_arbace_j2g_model__init_part0_A_const_110 }
func A_arbace_j2g_model__init_part0_A_Unit54__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(439, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__95 any = A_arbace_j2g_model_fields_of_A_New(); var tmp3 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_j2g_model_fields_of_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, nil); A_arbace_j2g_model_fields_of_A_fn_class = fncls__94d; tmp3 = fncls__94d } else { tmp3 = fncls__94 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_113)); return A_arbace_j2g_model__init_part0_A_const_112 }

func A_arbace_j2g_model__init_part0_A_Unit55__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(441, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__97 any = A_arbace_j2g_model_find_method_A_New(); var tmp3 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_j2g_model_find_method_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, nil); A_arbace_j2g_model_find_method_A_fn_class = fncls__96d; tmp3 = fncls__96d } else { tmp3 = fncls__96 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_115)); return A_arbace_j2g_model__init_part0_A_const_114 }


func A_arbace_j2g_model__init_part0_A_Unit56__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__99 any = A_arbace_j2g_model_virtual_member_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_j2g_model_virtual_member_QMARK__A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_168, false, nil); A_arbace_j2g_model_virtual_member_QMARK__A_fn_class = fncls__98d; tmp3 = fncls__98d } else { tmp3 = fncls__98 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__99, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_117)); return A_arbace_j2g_model__init_part0_A_const_116 }




func A_arbace_j2g_model__init_part0_A_Unit57__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(449, 1); A_arbace_j2g_model__init_part0_A_const_118.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_119); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_118; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_120)); return A_arbace_j2g_model__init_part0_A_const_118 }




func A_arbace_j2g_model__init_part0_A_Unit58__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(454, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__101 any = A_arbace_j2g_model_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_j2g_model_supertypes_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, false, nil); A_arbace_j2g_model_supertypes_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__101, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_122)); return A_arbace_j2g_model__init_part0_A_const_121 }


func A_arbace_j2g_model__init_part0_A_Unit59__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(457, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__103 any = A_arbace_j2g_model_world_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_j2g_model_world_supertypes_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_j2g_model_world_supertypes_A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_124)); return A_arbace_j2g_model__init_part0_A_const_123 }




func A_arbace_j2g_model__init_part0_A_Unit60__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(462, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__105 any = A_arbace_j2g_model_all_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_j2g_model_all_supertypes_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, nil); A_arbace_j2g_model_all_supertypes_A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__105, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_126)); return A_arbace_j2g_model__init_part0_A_const_125 }






func A_arbace_j2g_model__init_part0_A_Unit61__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(469, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_127; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_128)); return A_arbace_j2g_model__init_part0_A_const_127 }

func A_arbace_j2g_model__init_part0_A_Unit62__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__107 any = A_arbace_j2g_model_hw_method_exists_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_172, false, nil); A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__107, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_130)); return A_arbace_j2g_model__init_part0_A_const_129 }














func A_arbace_j2g_model__init_part0_A_Unit63__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(486, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__109 any = A_arbace_j2g_model_j2g_method_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_j2g_model_j2g_method_QMARK__A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, nil); A_arbace_j2g_model_j2g_method_QMARK__A_fn_class = fncls__108d; tmp3 = fncls__108d } else { tmp3 = fncls__108 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__109, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_131)); return A_arbace_j2g_model__init_part0_A_const_127 }









func A_arbace_j2g_model__init_part0_A_Unit64__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__111 any = A_arbace_j2g_model_member_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_j2g_model_member_in_world_QMARK__A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, nil); A_arbace_j2g_model_member_in_world_QMARK__A_fn_class = fncls__110d; tmp3 = fncls__110d } else { tmp3 = fncls__110 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__111, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_133)); return A_arbace_j2g_model__init_part0_A_const_132 }






func A_arbace_j2g_model__init_part0_A_Unit65__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(503, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__113 any = A_arbace_j2g_model_declared_vmethods_A_New(); var tmp3 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_j2g_model_declared_vmethods_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, nil); A_arbace_j2g_model_declared_vmethods_A_fn_class = fncls__112d; tmp3 = fncls__112d } else { tmp3 = fncls__112 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__113, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_135)); return A_arbace_j2g_model__init_part0_A_const_134 }







func A_arbace_j2g_model__init_part0_A_Unit66__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(511, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__115 any = A_arbace_j2g_model_vmethods_A_New(); var tmp3 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_j2g_model_vmethods_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, nil); A_arbace_j2g_model_vmethods_A_fn_class = fncls__114d; tmp3 = fncls__114d } else { tmp3 = fncls__114 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__115, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_137)); return A_arbace_j2g_model__init_part0_A_const_136 }
















func A_arbace_j2g_model__init_part0_A_Unit67__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(528, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__117 any = A_arbace_j2g_model_java_type_name_A_New(); var tmp3 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_j2g_model_java_type_name_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, nil); A_arbace_j2g_model_java_type_name_A_fn_class = fncls__116d; tmp3 = fncls__116d } else { tmp3 = fncls__116 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__117, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_139)); return A_arbace_j2g_model__init_part0_A_const_138 }







func A_arbace_j2g_model__init_part0_A_Unit68__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(536, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__119 any = A_arbace_j2g_model_abstract_method_error_text_A_New(); var tmp3 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_j2g_model_abstract_method_error_text_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, nil); A_arbace_j2g_model_abstract_method_error_text_A_fn_class = fncls__118d; tmp3 = fncls__118d } else { tmp3 = fncls__118 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__119, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_141)); return A_arbace_j2g_model__init_part0_A_const_140 }








func A_arbace_j2g_model__init_part0_A_Unit69__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(545, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__121 any = A_arbace_j2g_model_superclass_chain_A_New(); var tmp3 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_j2g_model_superclass_chain_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, nil); A_arbace_j2g_model_superclass_chain_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__121, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_143)); return A_arbace_j2g_model__init_part0_A_const_142 }


func A_arbace_j2g_model__init_part0_A_Unit70__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(548, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__123 any = A_arbace_j2g_model_impl_of_A_New(); var tmp3 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_j2g_model_impl_of_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_180, false, nil); A_arbace_j2g_model_impl_of_A_fn_class = fncls__122d; tmp3 = fncls__122d } else { tmp3 = fncls__122 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__123, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_145)); return A_arbace_j2g_model__init_part0_A_const_144 }






























func A_arbace_j2g_model__init_part0_A_Unit71__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(579, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__125 any = A_arbace_j2g_model_serialization_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_j2g_model_serialization_QMARK__A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_181, false, nil); A_arbace_j2g_model_serialization_QMARK__A_fn_class = fncls__124d; tmp3 = fncls__124d } else { tmp3 = fncls__124 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__125, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_147)); return A_arbace_j2g_model__init_part0_A_const_146 }






func A_arbace_j2g_model__init_part0_A_Unit72__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(586, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__127 any = A_arbace_j2g_model_serializable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_j2g_model_serializable_QMARK__A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_182, false, nil); A_arbace_j2g_model_serializable_QMARK__A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__127, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_149)); return A_arbace_j2g_model__init_part0_A_const_148 }




func A_arbace_j2g_model__init_part0_A_Unit73__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(591, 1); A_arbace_j2g_model__init_part0_A_const_150.BindRoot_O__V(A_arbace_j2g_model__init_part0_A_const_151); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_150; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_152)); return A_arbace_j2g_model__init_part0_A_const_150 }









func A_arbace_j2g_model__init_part0_A_Unit74__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_153; var tmp2 *lang.Compiler_AOTFn; var fnbody__129 any = A_arbace_j2g_model_serial_hook_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_j2g_model_serial_hook_QMARK__A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_183, false, nil); A_arbace_j2g_model_serial_hook_QMARK__A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__129, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_154)); return A_arbace_j2g_model__init_part0_A_const_153 }





func A_arbace_j2g_model__init_part0_A_Unit75__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(607, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__131 any = A_arbace_j2g_model_serial_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_j2g_model_serial_field_QMARK__A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_184, false, nil); A_arbace_j2g_model_serial_field_QMARK__A_fn_class = fncls__130d; tmp3 = fncls__130d } else { tmp3 = fncls__130 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__131, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_156)); return A_arbace_j2g_model__init_part0_A_const_155 }






func A_arbace_j2g_model__init_part0_A_Unit76__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(614, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__133 any = A_arbace_j2g_model_java_pkg_A_New(); var tmp3 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_j2g_model_java_pkg_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_185, false, nil); A_arbace_j2g_model_java_pkg_A_fn_class = fncls__132d; tmp3 = fncls__132d } else { tmp3 = fncls__132 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__133, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_158)); return A_arbace_j2g_model__init_part0_A_const_157 }

func A_arbace_j2g_model__init_part0_A_Unit77__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(616, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__135 any = A_arbace_j2g_model_class_access_A_New(); var tmp3 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_j2g_model_class_access_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_186, false, nil); A_arbace_j2g_model_class_access_A_fn_class = fncls__134d; tmp3 = fncls__134d } else { tmp3 = fncls__134 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_160)); return A_arbace_j2g_model__init_part0_A_const_159 }





func A_arbace_j2g_model__init_part0_A_Unit78__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(622, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__137 any = A_arbace_j2g_model_ctors_of_A_New(); var tmp3 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_j2g_model_ctors_of_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_187, false, nil); A_arbace_j2g_model_ctors_of_A_fn_class = fncls__136d; tmp3 = fncls__136d } else { tmp3 = fncls__136 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__137, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_162)); return A_arbace_j2g_model__init_part0_A_const_161 }

func A_arbace_j2g_model__init_part0_A_Unit79__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__139 any = A_arbace_j2g_model_super_ctor_accessible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_j2g_model_super_ctor_accessible_QMARK__A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_188, false, nil); A_arbace_j2g_model_super_ctor_accessible_QMARK__A_fn_class = fncls__138d; tmp3 = fncls__138d } else { tmp3 = fncls__138 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__139, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_164)); return A_arbace_j2g_model__init_part0_A_const_163 }















func A_arbace_j2g_model__init_part0_A_Unit80__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(640, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__141 any = A_arbace_j2g_model_serial_chain_super_A_New(); var tmp3 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_j2g_model_serial_chain_super_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_189, false, nil); A_arbace_j2g_model_serial_chain_super_A_fn_class = fncls__140d; tmp3 = fncls__140d } else { tmp3 = fncls__140 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_166)); return A_arbace_j2g_model__init_part0_A_const_165 }




















func A_arbace_j2g_model__init_part0_A_Unit81__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(661, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__143 any = A_arbace_j2g_model_serial_super_A_New(); var tmp3 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_j2g_model_serial_super_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_190, false, nil); A_arbace_j2g_model_serial_super_A_fn_class = fncls__142d; tmp3 = fncls__142d } else { tmp3 = fncls__142 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__143, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_168)); return A_arbace_j2g_model__init_part0_A_const_167 }





















func A_arbace_j2g_model__init_part0_A_Unit82__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(683, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_169; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_170)); return A_arbace_j2g_model__init_part0_A_const_169 }

func A_arbace_j2g_model__init_part0_A_Unit83__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(685, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__145 any = A_arbace_j2g_model_default_suid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_j2g_model_default_suid_QMARK__A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_191, false, nil); A_arbace_j2g_model_default_suid_QMARK__A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_172)); return A_arbace_j2g_model__init_part0_A_const_171 }






func A_arbace_j2g_model__init_part0_A_Unit84__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(692, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__147 any = A_arbace_j2g_model_serial_uid_A_New(); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_j2g_model_serial_uid_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_192, false, nil); A_arbace_j2g_model_serial_uid_A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__147, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_174)); return A_arbace_j2g_model__init_part0_A_const_173 }

















func A_arbace_j2g_model__init_part0_A_Unit85__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(710, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__149 any = A_arbace_j2g_model_foreign_super_accessible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_j2g_model_foreign_super_accessible_QMARK__A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_193, false, nil); A_arbace_j2g_model_foreign_super_accessible_QMARK__A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__149, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_176)); return A_arbace_j2g_model__init_part0_A_const_175 }







func A_arbace_j2g_model__init_part0_A_Unit86__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(718, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__151 any = A_arbace_j2g_model_code_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_j2g_model_code_class_QMARK__A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_194, false, nil); A_arbace_j2g_model_code_class_QMARK__A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__151, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_177)); return A_arbace_j2g_model__init_part0_A_const_169 }









func A_arbace_j2g_model__init_part0_A_Unit87__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(728, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__153 any = A_arbace_j2g_model_code_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_j2g_model_code_iface_QMARK__A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_195, false, nil); A_arbace_j2g_model_code_iface_QMARK__A_fn_class = fncls__152d; tmp3 = fncls__152d } else { tmp3 = fncls__152 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__153, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_179)); return A_arbace_j2g_model__init_part0_A_const_178 }





func A_arbace_j2g_model__init_part0_A_Unit88__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(734, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__155 any = A_arbace_j2g_model_nest_top_A_New(); var tmp3 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_j2g_model_nest_top_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_196, false, nil); A_arbace_j2g_model_nest_top_A_fn_class = fncls__154d; tmp3 = fncls__154d } else { tmp3 = fncls__154 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__155, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_181)); return A_arbace_j2g_model__init_part0_A_const_180 }




func A_arbace_j2g_model__init_part0_A_Unit89__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(739, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_182; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_183)); return A_arbace_j2g_model__init_part0_A_const_182 }

func A_arbace_j2g_model__init_part0_A_Unit90__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(741, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__157 any = A_arbace_j2g_model_init_superinterfaces_A_New(); var tmp3 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_197, false, nil); A_arbace_j2g_model_init_superinterfaces_A_fn_class = fncls__156d; tmp3 = fncls__156d } else { tmp3 = fncls__156 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__157, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_185)); return A_arbace_j2g_model__init_part0_A_const_184 }


















func A_arbace_j2g_model__init_part0_A_Unit91__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(760, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__159 any = A_arbace_j2g_model_trivial_init_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_j2g_model_trivial_init_QMARK__A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_198, false, nil); A_arbace_j2g_model_trivial_init_QMARK__A_fn_class = fncls__158d; tmp3 = fncls__158d } else { tmp3 = fncls__158 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__159, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_186)); return A_arbace_j2g_model__init_part0_A_const_182 }
























func A_arbace_j2g_model__init_part0_A_Unit92__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(785, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__161 any = A_arbace_j2g_model_go_qualified_name_A_New(); var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_j2g_model_go_qualified_name_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_199, false, nil); A_arbace_j2g_model_go_qualified_name_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__161, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_188)); return A_arbace_j2g_model__init_part0_A_const_187 }





func A_arbace_j2g_model__init_part0_A_Unit93__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(791, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_189; var tmp2 any; var root_162 any = A_arbace_j2g_model__init_part0_A_const_79.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_164 lang.IFn; if

	linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_j2g_model__init_part0_A_const_190.GetRawRoot__O(); if linked_163 == nil { tmp2 = ifn_164.Invoke_O__O(arg_165) } else { tmp2 = linked_163.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_162, arg_165) }; /*line :791:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_model__init_part0_A_const_189; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_191)); return A_arbace_j2g_model__init_part0_A_const_189 }



func A_arbace_j2g_model__init_part0_A_Unit94__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(795, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_192; var tmp2 *lang.Compiler_AOTFn; var fnbody__167 any = A_arbace_j2g_model_start_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_j2g_model_start_class_QMARK__A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_200, false, nil); A_arbace_j2g_model_start_class_QMARK__A_fn_class = fncls__166d; tmp3 = fncls__166d } else { tmp3 = fncls__166 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__167, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_192; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_193)); return A_arbace_j2g_model__init_part0_A_const_192 }






func A_arbace_j2g_model__init_part0_A_Unit95__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(802, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_194; var tmp2 *lang.Compiler_AOTFn; var fnbody__169 any = A_arbace_j2g_model_start_classes_A_New(); var tmp3 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_j2g_model_start_classes_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_201, false, nil); A_arbace_j2g_model_start_classes_A_fn_class = fncls__168d; tmp3 = fncls__168d } else { tmp3 = fncls__168 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__169, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_194; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_195)); return A_arbace_j2g_model__init_part0_A_const_194 }








func A_arbace_j2g_model__init_part0_A_Unit96__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(811, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_196; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_197)); return A_arbace_j2g_model__init_part0_A_const_196 }

func A_arbace_j2g_model__init_part0_A_Unit97__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(813, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_198; var tmp2 *lang.Compiler_AOTFn; var fnbody__171 any = A_arbace_j2g_model_top_class_A_New(); var tmp3 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_j2g_model_top_class_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_202, false, nil); A_arbace_j2g_model_top_class_A_fn_class = fncls__170d; tmp3 = fncls__170d } else { tmp3 = fncls__170 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__171, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_198; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_199)); return A_arbace_j2g_model__init_part0_A_const_198 }

func A_arbace_j2g_model__init_part0_A_Unit98__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(815, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_200; var tmp2 *lang.Compiler_AOTFn; var fnbody__173 any = A_arbace_j2g_model_pure_ctor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_203, false, nil); A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class = fncls__172d; tmp3 = fncls__172d } else { tmp3 = fncls__172 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__173, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_200; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_201)); return A_arbace_j2g_model__init_part0_A_const_200 }






















func A_arbace_j2g_model__init_part0_A_Unit99__O() any { A_arbace_j2g_model__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(838, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part0_A_const_196; var tmp2 *lang.Compiler_AOTFn; var fnbody__175 any = A_arbace_j2g_model_pure_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__174 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__A_fn_class; if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_204, false, nil); A_arbace_j2g_model_pure_node_QMARK__A_fn_class = fncls__174d; tmp3 = fncls__174d } else { tmp3 = fncls__174 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__175, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part0_A_const_196; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part0_A_const_202)); return A_arbace_j2g_model__init_part0_A_const_196 }


























func A_arbace_j2g_model__init_part1_A_Unit100__O() any { A_arbace_j2g_model__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(865, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_model_benign_init_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_206, false, nil); A_arbace_j2g_model_benign_init_QMARK__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part1_A_const_1)); return A_arbace_j2g_model__init_part1_A_const_0 }
//line :865:1
func A_arbace_j2g_model__init_part1_A_Init__O() any { A_arbace_j2g_model__init_part1_A_Init(); return nil }
//line :865:1
func A_arbace_j2g_model__init_part1_A_Load__O() any { A_arbace_j2g_model__init_part1_A_Init(); A_arbace_j2g_model__init_part1_A_Unit100__O(); A_arbace_j2g_model__init_part1_A_Unit101__O(); A_arbace_j2g_model__init_part1_A_Unit102__O(); A_arbace_j2g_model__init_part1_A_Unit103__O(); A_arbace_j2g_model__init_part1_A_Unit104__O(); A_arbace_j2g_model__init_part1_A_Unit105__O(); A_arbace_j2g_model__init_part1_A_Unit106__O(); return nil }























func A_arbace_j2g_model__init_part1_A_Unit101__O() any { A_arbace_j2g_model__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(889, 1); A_arbace_j2g_model__init_part1_A_const_2.BindRoot_O__V(A_arbace_j2g_model__init_part1_A_const_3); var tmp1 *lang.Var = A_arbace_j2g_model__init_part1_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part1_A_const_4)); return A_arbace_j2g_model__init_part1_A_const_2 }









func A_arbace_j2g_model__init_part1_A_Unit102__O() any { A_arbace_j2g_model__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(899, 1); A_arbace_j2g_model__init_part1_A_const_5.BindRoot_O__V(A_arbace_j2g_model__init_part1_A_const_6); var tmp1 *lang.Var = A_arbace_j2g_model__init_part1_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part1_A_const_7)); return A_arbace_j2g_model__init_part1_A_const_5 }










func A_arbace_j2g_model__init_part1_A_Unit103__O() any { A_arbace_j2g_model__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(910, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_model_class_loader_resource_target_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_model_class_loader_resource_target_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_207, false, nil); A_arbace_j2g_model_class_loader_resource_target_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part1_A_const_9)); return A_arbace_j2g_model__init_part1_A_const_8 }








func A_arbace_j2g_model__init_part1_A_Unit104__O() any { A_arbace_j2g_model__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(919, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_model_class_loader_resource_ready_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_model_class_loader_resource_ready_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_208, false, nil); A_arbace_j2g_model_class_loader_resource_ready_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part1_A_const_11)); return A_arbace_j2g_model__init_part1_A_const_10 }






func A_arbace_j2g_model__init_part1_A_Unit105__O() any { A_arbace_j2g_model__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(926, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part1_A_const_12; var tmp2 any; var root_7 any = A_arbace_j2g_model__init_part1_A_const_13.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_9 lang.IFn; if









	linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = A_arbace_j2g_model__init_part1_A_const_14; var arg_11 any; var root_12 any = A_arbace_j2g_model__init_part1_A_const_15.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_14 lang.IFn; if









	linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_model_fn__1479000270_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_model_fn__1479000270_A_fn_class; if
	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_209, false, nil); A_arbace_j2g_model_fn__1479000270_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp4, nil); arg_15 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O(); var arg_16 any; var tmp5 /*line :946:1*/*lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_model_fn__1479000288_A_New(); var tmp6 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_model_fn__1479000288_A_fn_class; if


	fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_210, false, nil); A_arbace_j2g_model_fn__1479000288_A_fn_class = fncls__19d; tmp6 = fncls__19d } else { tmp6 = fncls__19 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp6, nil); arg_16 = Up_Compiler_AOTFn_IFn(tmp5).Invoke__O(); if /*line :946:1*/ linked_13 == nil { arg_11 = ifn_14.Invoke_O_O__O(arg_15, arg_16) } else { arg_11 = linked_13.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_12, arg_15, arg_16) }; if /*line :936:1*/ linked_8 == nil { tmp2 = ifn_9.Invoke_O_O__O(arg_10, arg_11) } else { tmp2 = linked_8.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_7, arg_10, arg_11) }; /*line :926:1*/tmp1.BindRoot_O__V(tmp2); var tmp7 *lang.Var = A_arbace_j2g_model__init_part1_A_const_12; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part1_A_const_16)); return A_arbace_j2g_model__init_part1_A_const_12 }

























func A_arbace_j2g_model__init_part1_A_Unit106__O() any { A_arbace_j2g_model__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(952, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_part1_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_model_throwable_print_helper_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_model_throwable_print_helper_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_211, false, nil); A_arbace_j2g_model_throwable_print_helper_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_model__init_part1_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_part1_A_const_18)); return A_arbace_j2g_model__init_part1_A_const_17 }



type A_arbace_j2g_model__init_A struct{ jrt.Object }

func A_arbace_j2g_model__init_A_New() *A_arbace_j2g_model__init_A { t := &A_arbace_j2g_model__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model__init_A) Ctor() {}

func (t *A_arbace_j2g_model__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model__init_A_class }

func (t *A_arbace_j2g_model__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model__init_A); return ok }

func A_arbace_j2g_model__init_A_Cast(x any) *A_arbace_j2g_model__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model__init_A_class)) }; return v }



type A_arbace_j2g_model__init_part0_A struct{ jrt.Object }

var A_arbace_j2g_model__init_part0_A_const_pool *jrt.RefArray

var A_arbace_j2g_model__init_part0_A_const_0 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_1 any

var A_arbace_j2g_model__init_part0_A_const_2 any

var A_arbace_j2g_model__init_part0_A_const_3 any

var A_arbace_j2g_model__init_part0_A_const_4 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_5 any

var A_arbace_j2g_model__init_part0_A_const_6 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_7 any

var A_arbace_j2g_model__init_part0_A_const_8 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_9 any

var A_arbace_j2g_model__init_part0_A_const_10 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_11 any

var A_arbace_j2g_model__init_part0_A_const_12 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_13 any

var A_arbace_j2g_model__init_part0_A_const_14 any

var A_arbace_j2g_model__init_part0_A_const_15 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_16 any

var A_arbace_j2g_model__init_part0_A_const_17 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_18 any

var A_arbace_j2g_model__init_part0_A_const_19 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_20 any

var A_arbace_j2g_model__init_part0_A_const_21 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_22 any

var A_arbace_j2g_model__init_part0_A_const_23 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_24 any

var A_arbace_j2g_model__init_part0_A_const_25 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_26 any

var A_arbace_j2g_model__init_part0_A_const_27 any

var A_arbace_j2g_model__init_part0_A_const_28 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_29 any

var A_arbace_j2g_model__init_part0_A_const_30 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_31 any

var A_arbace_j2g_model__init_part0_A_const_32 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_33 any

var A_arbace_j2g_model__init_part0_A_const_34 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_35 any

var A_arbace_j2g_model__init_part0_A_const_36 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_37 any

var A_arbace_j2g_model__init_part0_A_const_38 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_39 any

var A_arbace_j2g_model__init_part0_A_const_40 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_41 any

var A_arbace_j2g_model__init_part0_A_const_42 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_43 any

var A_arbace_j2g_model__init_part0_A_const_44 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_45 any

var A_arbace_j2g_model__init_part0_A_const_46 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_47 any

var A_arbace_j2g_model__init_part0_A_const_48 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_49 any

var A_arbace_j2g_model__init_part0_A_const_50 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_51 any

var A_arbace_j2g_model__init_part0_A_const_52 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_53 any

var A_arbace_j2g_model__init_part0_A_const_54 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_55 any

var A_arbace_j2g_model__init_part0_A_const_56 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_57 any

var A_arbace_j2g_model__init_part0_A_const_58 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_59 any

var A_arbace_j2g_model__init_part0_A_const_60 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_61 any

var A_arbace_j2g_model__init_part0_A_const_62 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_63 any

var A_arbace_j2g_model__init_part0_A_const_64 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_65 any

var A_arbace_j2g_model__init_part0_A_const_66 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_67 any

var A_arbace_j2g_model__init_part0_A_const_68 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_69 any

var A_arbace_j2g_model__init_part0_A_const_70 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_71 any

var A_arbace_j2g_model__init_part0_A_const_72 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_73 any

var A_arbace_j2g_model__init_part0_A_const_74 any

var A_arbace_j2g_model__init_part0_A_const_75 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_76 any

var A_arbace_j2g_model__init_part0_A_const_77 any

var A_arbace_j2g_model__init_part0_A_const_78 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_79 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_80 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_81 any

var A_arbace_j2g_model__init_part0_A_const_82 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_83 any

var A_arbace_j2g_model__init_part0_A_const_84 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_85 any

var A_arbace_j2g_model__init_part0_A_const_86 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_87 any

var A_arbace_j2g_model__init_part0_A_const_88 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_89 any

var A_arbace_j2g_model__init_part0_A_const_90 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_91 any

var A_arbace_j2g_model__init_part0_A_const_92 any

var A_arbace_j2g_model__init_part0_A_const_93 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_94 any

var A_arbace_j2g_model__init_part0_A_const_95 any

var A_arbace_j2g_model__init_part0_A_const_96 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_97 any

var A_arbace_j2g_model__init_part0_A_const_98 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_99 any

var A_arbace_j2g_model__init_part0_A_const_100 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_101 any

var A_arbace_j2g_model__init_part0_A_const_102 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_103 any

var A_arbace_j2g_model__init_part0_A_const_104 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_105 any

var A_arbace_j2g_model__init_part0_A_const_106 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_107 any

var A_arbace_j2g_model__init_part0_A_const_108 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_109 any

var A_arbace_j2g_model__init_part0_A_const_110 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_111 any

var A_arbace_j2g_model__init_part0_A_const_112 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_113 any

var A_arbace_j2g_model__init_part0_A_const_114 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_115 any

var A_arbace_j2g_model__init_part0_A_const_116 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_117 any

var A_arbace_j2g_model__init_part0_A_const_118 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_119 any

var A_arbace_j2g_model__init_part0_A_const_120 any

var A_arbace_j2g_model__init_part0_A_const_121 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_122 any

var A_arbace_j2g_model__init_part0_A_const_123 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_124 any

var A_arbace_j2g_model__init_part0_A_const_125 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_126 any

var A_arbace_j2g_model__init_part0_A_const_127 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_128 any

var A_arbace_j2g_model__init_part0_A_const_129 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_130 any

var A_arbace_j2g_model__init_part0_A_const_131 any

var A_arbace_j2g_model__init_part0_A_const_132 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_133 any

var A_arbace_j2g_model__init_part0_A_const_134 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_135 any

var A_arbace_j2g_model__init_part0_A_const_136 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_137 any

var A_arbace_j2g_model__init_part0_A_const_138 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_139 any

var A_arbace_j2g_model__init_part0_A_const_140 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_141 any

var A_arbace_j2g_model__init_part0_A_const_142 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_143 any

var A_arbace_j2g_model__init_part0_A_const_144 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_145 any

var A_arbace_j2g_model__init_part0_A_const_146 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_147 any

var A_arbace_j2g_model__init_part0_A_const_148 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_149 any

var A_arbace_j2g_model__init_part0_A_const_150 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_151 any

var A_arbace_j2g_model__init_part0_A_const_152 any

var A_arbace_j2g_model__init_part0_A_const_153 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_154 any

var A_arbace_j2g_model__init_part0_A_const_155 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_156 any

var A_arbace_j2g_model__init_part0_A_const_157 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_158 any

var A_arbace_j2g_model__init_part0_A_const_159 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_160 any

var A_arbace_j2g_model__init_part0_A_const_161 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_162 any

var A_arbace_j2g_model__init_part0_A_const_163 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_164 any

var A_arbace_j2g_model__init_part0_A_const_165 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_166 any

var A_arbace_j2g_model__init_part0_A_const_167 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_168 any

var A_arbace_j2g_model__init_part0_A_const_169 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_170 any

var A_arbace_j2g_model__init_part0_A_const_171 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_172 any

var A_arbace_j2g_model__init_part0_A_const_173 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_174 any

var A_arbace_j2g_model__init_part0_A_const_175 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_176 any

var A_arbace_j2g_model__init_part0_A_const_177 any

var A_arbace_j2g_model__init_part0_A_const_178 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_179 any

var A_arbace_j2g_model__init_part0_A_const_180 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_181 any

var A_arbace_j2g_model__init_part0_A_const_182 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_183 any

var A_arbace_j2g_model__init_part0_A_const_184 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_185 any

var A_arbace_j2g_model__init_part0_A_const_186 any

var A_arbace_j2g_model__init_part0_A_const_187 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_188 any

var A_arbace_j2g_model__init_part0_A_const_189 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_190 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_191 any

var A_arbace_j2g_model__init_part0_A_const_192 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_193 any

var A_arbace_j2g_model__init_part0_A_const_194 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_195 any

var A_arbace_j2g_model__init_part0_A_const_196 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_197 any

var A_arbace_j2g_model__init_part0_A_const_198 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_199 any

var A_arbace_j2g_model__init_part0_A_const_200 *lang.Var

var A_arbace_j2g_model__init_part0_A_const_201 any

var A_arbace_j2g_model__init_part0_A_const_202 any

var A_arbace_j2g_model__init_part0_A_init jrt.ClassInit

func A_arbace_j2g_model__init_part0_A_Init() { if !A_arbace_j2g_model__init_part0_A_init.Done() { A_arbace_j2g_model__init_part0_A_init.Run(A_arbace_j2g_model__init_part0_A_clinit) } }

func A_arbace_j2g_model__init_part0_A_clinit() { A_arbace_j2g_model__init_part0_A_clinit_p0(); A_arbace_j2g_model__init_part0_A_clinit_p1(); A_arbace_j2g_model__init_part0_A_clinit_p2(); A_arbace_j2g_model__init_part0_A_clinit_p3(); A_arbace_j2g_model__init_part0_A_clinit_p4(); A_arbace_j2g_model__init_part0_A_clinit_p5(); A_arbace_j2g_model__init_part0_A_clinit_p6(); A_arbace_j2g_model__init_part0_A_clinit_p7(); A_arbace_j2g_model__init_part0_A_clinit_p8(); A_arbace_j2g_model__init_part0_A_clinit_p9(); A_arbace_j2g_model__init_part0_A_clinit_p10(); A_arbace_j2g_model__init_part0_A_clinit_p11(); A_arbace_j2g_model__init_part0_A_clinit_p12(); A_arbace_j2g_model__init_part0_A_clinit_p13(); A_arbace_j2g_model__init_part0_A_clinit_p14(); A_arbace_j2g_model__init_part0_A_clinit_p15() }

func A_arbace_j2g_model__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_123, 252); A_arbace_j2g_model__init_part0_A_const_0 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[49]); A_arbace_j2g_model__init_part0_A_const_1 = A_arbace_j2g_model__init_part0_A_const_pool.A[50]; A_arbace_j2g_model__init_part0_A_const_2 = A_arbace_j2g_model__init_part0_A_const_pool.A[51]; A_arbace_j2g_model__init_part0_A_const_3 = A_arbace_j2g_model__init_part0_A_const_pool.A[52]; A_arbace_j2g_model__init_part0_A_const_4 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[53]); A_arbace_j2g_model__init_part0_A_const_5 = A_arbace_j2g_model__init_part0_A_const_pool.A[54]; A_arbace_j2g_model__init_part0_A_const_6 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[55]); A_arbace_j2g_model__init_part0_A_const_7 = A_arbace_j2g_model__init_part0_A_const_pool.A[56]; A_arbace_j2g_model__init_part0_A_const_8 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[57]); A_arbace_j2g_model__init_part0_A_const_9 = A_arbace_j2g_model__init_part0_A_const_pool.A[58]; A_arbace_j2g_model__init_part0_A_const_10 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[59]); A_arbace_j2g_model__init_part0_A_const_11 = A_arbace_j2g_model__init_part0_A_const_pool.A[60]; A_arbace_j2g_model__init_part0_A_const_12 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[61]) }

func A_arbace_j2g_model__init_part0_A_clinit_p1() { A_arbace_j2g_model__init_part0_A_const_13 = A_arbace_j2g_model__init_part0_A_const_pool.A[62]; A_arbace_j2g_model__init_part0_A_const_14 = A_arbace_j2g_model__init_part0_A_const_pool.A[63]; A_arbace_j2g_model__init_part0_A_const_15 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[64]); A_arbace_j2g_model__init_part0_A_const_16 = A_arbace_j2g_model__init_part0_A_const_pool.A[65]; A_arbace_j2g_model__init_part0_A_const_17 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[66]); A_arbace_j2g_model__init_part0_A_const_18 = A_arbace_j2g_model__init_part0_A_const_pool.A[67]; A_arbace_j2g_model__init_part0_A_const_19 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[68]); A_arbace_j2g_model__init_part0_A_const_20 = A_arbace_j2g_model__init_part0_A_const_pool.A[69]; A_arbace_j2g_model__init_part0_A_const_21 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[70]); A_arbace_j2g_model__init_part0_A_const_22 = A_arbace_j2g_model__init_part0_A_const_pool.A[71]; A_arbace_j2g_model__init_part0_A_const_23 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[72]); A_arbace_j2g_model__init_part0_A_const_24 = A_arbace_j2g_model__init_part0_A_const_pool.A[73]; A_arbace_j2g_model__init_part0_A_const_25 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[74]); A_arbace_j2g_model__init_part0_A_const_26 = A_arbace_j2g_model__init_part0_A_const_pool.A[75] }

func A_arbace_j2g_model__init_part0_A_clinit_p2() { A_arbace_j2g_model__init_part0_A_const_27 = A_arbace_j2g_model__init_part0_A_const_pool.A[76]; A_arbace_j2g_model__init_part0_A_const_28 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[77]); A_arbace_j2g_model__init_part0_A_const_29 = A_arbace_j2g_model__init_part0_A_const_pool.A[78]; A_arbace_j2g_model__init_part0_A_const_30 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[79]); A_arbace_j2g_model__init_part0_A_const_31 = A_arbace_j2g_model__init_part0_A_const_pool.A[80]; A_arbace_j2g_model__init_part0_A_const_32 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[81]); A_arbace_j2g_model__init_part0_A_const_33 = A_arbace_j2g_model__init_part0_A_const_pool.A[82]; A_arbace_j2g_model__init_part0_A_const_34 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[83]); A_arbace_j2g_model__init_part0_A_const_35 = A_arbace_j2g_model__init_part0_A_const_pool.A[84]; A_arbace_j2g_model__init_part0_A_const_36 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[85]); A_arbace_j2g_model__init_part0_A_const_37 = A_arbace_j2g_model__init_part0_A_const_pool.A[86]; A_arbace_j2g_model__init_part0_A_const_38 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[87]); A_arbace_j2g_model__init_part0_A_const_39 = A_arbace_j2g_model__init_part0_A_const_pool.A[88] }

func A_arbace_j2g_model__init_part0_A_clinit_p3() { A_arbace_j2g_model__init_part0_A_const_40 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[89]); A_arbace_j2g_model__init_part0_A_const_41 = A_arbace_j2g_model__init_part0_A_const_pool.A[90]; A_arbace_j2g_model__init_part0_A_const_42 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[91]); A_arbace_j2g_model__init_part0_A_const_43 = A_arbace_j2g_model__init_part0_A_const_pool.A[92]; A_arbace_j2g_model__init_part0_A_const_44 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[93]); A_arbace_j2g_model__init_part0_A_const_45 = A_arbace_j2g_model__init_part0_A_const_pool.A[94]; A_arbace_j2g_model__init_part0_A_const_46 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[95]); A_arbace_j2g_model__init_part0_A_const_47 = A_arbace_j2g_model__init_part0_A_const_pool.A[96]; A_arbace_j2g_model__init_part0_A_const_48 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[97]); A_arbace_j2g_model__init_part0_A_const_49 = A_arbace_j2g_model__init_part0_A_const_pool.A[98]; A_arbace_j2g_model__init_part0_A_const_50 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[99]); A_arbace_j2g_model__init_part0_A_const_51 = A_arbace_j2g_model__init_part0_A_const_pool.A[100]; A_arbace_j2g_model__init_part0_A_const_52 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[101]) }

func A_arbace_j2g_model__init_part0_A_clinit_p4() { A_arbace_j2g_model__init_part0_A_const_53 = A_arbace_j2g_model__init_part0_A_const_pool.A[102]; A_arbace_j2g_model__init_part0_A_const_54 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[103]); A_arbace_j2g_model__init_part0_A_const_55 = A_arbace_j2g_model__init_part0_A_const_pool.A[104]; A_arbace_j2g_model__init_part0_A_const_56 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[105]); A_arbace_j2g_model__init_part0_A_const_57 = A_arbace_j2g_model__init_part0_A_const_pool.A[106]; A_arbace_j2g_model__init_part0_A_const_58 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[107]); A_arbace_j2g_model__init_part0_A_const_59 = A_arbace_j2g_model__init_part0_A_const_pool.A[108]; A_arbace_j2g_model__init_part0_A_const_60 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[109]); A_arbace_j2g_model__init_part0_A_const_61 = A_arbace_j2g_model__init_part0_A_const_pool.A[110]; A_arbace_j2g_model__init_part0_A_const_62 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[111]); A_arbace_j2g_model__init_part0_A_const_63 = A_arbace_j2g_model__init_part0_A_const_pool.A[112]; A_arbace_j2g_model__init_part0_A_const_64 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[113]); A_arbace_j2g_model__init_part0_A_const_65 = A_arbace_j2g_model__init_part0_A_const_pool.A[114] }

func A_arbace_j2g_model__init_part0_A_clinit_p5() { A_arbace_j2g_model__init_part0_A_const_66 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[115]); A_arbace_j2g_model__init_part0_A_const_67 = A_arbace_j2g_model__init_part0_A_const_pool.A[116]; A_arbace_j2g_model__init_part0_A_const_68 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[117]); A_arbace_j2g_model__init_part0_A_const_69 = A_arbace_j2g_model__init_part0_A_const_pool.A[118]; A_arbace_j2g_model__init_part0_A_const_70 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[119]); A_arbace_j2g_model__init_part0_A_const_71 = A_arbace_j2g_model__init_part0_A_const_pool.A[120]; A_arbace_j2g_model__init_part0_A_const_72 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[121]); A_arbace_j2g_model__init_part0_A_const_73 = A_arbace_j2g_model__init_part0_A_const_pool.A[122]; A_arbace_j2g_model__init_part0_A_const_74 = A_arbace_j2g_model__init_part0_A_const_pool.A[123]; A_arbace_j2g_model__init_part0_A_const_75 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[124]); A_arbace_j2g_model__init_part0_A_const_76 = A_arbace_j2g_model__init_part0_A_const_pool.A[125]; A_arbace_j2g_model__init_part0_A_const_77 = A_arbace_j2g_model__init_part0_A_const_pool.A[126]; A_arbace_j2g_model__init_part0_A_const_78 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[127]) }

func A_arbace_j2g_model__init_part0_A_clinit_p6() { A_arbace_j2g_model__init_part0_A_const_79 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[128]); A_arbace_j2g_model__init_part0_A_const_80 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[129]); A_arbace_j2g_model__init_part0_A_const_81 = A_arbace_j2g_model__init_part0_A_const_pool.A[130]; A_arbace_j2g_model__init_part0_A_const_82 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[131]); A_arbace_j2g_model__init_part0_A_const_83 = A_arbace_j2g_model__init_part0_A_const_pool.A[132]; A_arbace_j2g_model__init_part0_A_const_84 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[133]); A_arbace_j2g_model__init_part0_A_const_85 = A_arbace_j2g_model__init_part0_A_const_pool.A[134]; A_arbace_j2g_model__init_part0_A_const_86 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[135]); A_arbace_j2g_model__init_part0_A_const_87 = A_arbace_j2g_model__init_part0_A_const_pool.A[136]; A_arbace_j2g_model__init_part0_A_const_88 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[137]); A_arbace_j2g_model__init_part0_A_const_89 = A_arbace_j2g_model__init_part0_A_const_pool.A[138]; A_arbace_j2g_model__init_part0_A_const_90 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[139]); A_arbace_j2g_model__init_part0_A_const_91 = A_arbace_j2g_model__init_part0_A_const_pool.A[140] }

func A_arbace_j2g_model__init_part0_A_clinit_p7() { A_arbace_j2g_model__init_part0_A_const_92 = A_arbace_j2g_model__init_part0_A_const_pool.A[141]; A_arbace_j2g_model__init_part0_A_const_93 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[142]); A_arbace_j2g_model__init_part0_A_const_94 = A_arbace_j2g_model__init_part0_A_const_pool.A[143]; A_arbace_j2g_model__init_part0_A_const_95 = A_arbace_j2g_model__init_part0_A_const_pool.A[144]; A_arbace_j2g_model__init_part0_A_const_96 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[145]); A_arbace_j2g_model__init_part0_A_const_97 = A_arbace_j2g_model__init_part0_A_const_pool.A[146]; A_arbace_j2g_model__init_part0_A_const_98 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[147]); A_arbace_j2g_model__init_part0_A_const_99 = A_arbace_j2g_model__init_part0_A_const_pool.A[148]; A_arbace_j2g_model__init_part0_A_const_100 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[149]); A_arbace_j2g_model__init_part0_A_const_101 = A_arbace_j2g_model__init_part0_A_const_pool.A[150]; A_arbace_j2g_model__init_part0_A_const_102 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[151]); A_arbace_j2g_model__init_part0_A_const_103 = A_arbace_j2g_model__init_part0_A_const_pool.A[152]; A_arbace_j2g_model__init_part0_A_const_104 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[153]); A_arbace_j2g_model__init_part0_A_const_105 = A_arbace_j2g_model__init_part0_A_const_pool.A[154] }

func A_arbace_j2g_model__init_part0_A_clinit_p8() { A_arbace_j2g_model__init_part0_A_const_106 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[155]); A_arbace_j2g_model__init_part0_A_const_107 = A_arbace_j2g_model__init_part0_A_const_pool.A[156]; A_arbace_j2g_model__init_part0_A_const_108 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[157]); A_arbace_j2g_model__init_part0_A_const_109 = A_arbace_j2g_model__init_part0_A_const_pool.A[158]; A_arbace_j2g_model__init_part0_A_const_110 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[159]); A_arbace_j2g_model__init_part0_A_const_111 = A_arbace_j2g_model__init_part0_A_const_pool.A[160]; A_arbace_j2g_model__init_part0_A_const_112 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[161]); A_arbace_j2g_model__init_part0_A_const_113 = A_arbace_j2g_model__init_part0_A_const_pool.A[162]; A_arbace_j2g_model__init_part0_A_const_114 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[163]); A_arbace_j2g_model__init_part0_A_const_115 = A_arbace_j2g_model__init_part0_A_const_pool.A[164]; A_arbace_j2g_model__init_part0_A_const_116 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[165]); A_arbace_j2g_model__init_part0_A_const_117 = A_arbace_j2g_model__init_part0_A_const_pool.A[166]; A_arbace_j2g_model__init_part0_A_const_118 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[167]) }

func A_arbace_j2g_model__init_part0_A_clinit_p9() { A_arbace_j2g_model__init_part0_A_const_119 = A_arbace_j2g_model__init_part0_A_const_pool.A[168]; A_arbace_j2g_model__init_part0_A_const_120 = A_arbace_j2g_model__init_part0_A_const_pool.A[169]; A_arbace_j2g_model__init_part0_A_const_121 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[170]); A_arbace_j2g_model__init_part0_A_const_122 = A_arbace_j2g_model__init_part0_A_const_pool.A[171]; A_arbace_j2g_model__init_part0_A_const_123 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[172]); A_arbace_j2g_model__init_part0_A_const_124 = A_arbace_j2g_model__init_part0_A_const_pool.A[173]; A_arbace_j2g_model__init_part0_A_const_125 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[174]); A_arbace_j2g_model__init_part0_A_const_126 = A_arbace_j2g_model__init_part0_A_const_pool.A[175]; A_arbace_j2g_model__init_part0_A_const_127 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[176]); A_arbace_j2g_model__init_part0_A_const_128 = A_arbace_j2g_model__init_part0_A_const_pool.A[177]; A_arbace_j2g_model__init_part0_A_const_129 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[178]); A_arbace_j2g_model__init_part0_A_const_130 = A_arbace_j2g_model__init_part0_A_const_pool.A[179]; A_arbace_j2g_model__init_part0_A_const_131 = A_arbace_j2g_model__init_part0_A_const_pool.A[180]; A_arbace_j2g_model__init_part0_A_const_132 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[181]) }

func A_arbace_j2g_model__init_part0_A_clinit_p10() { A_arbace_j2g_model__init_part0_A_const_133 = A_arbace_j2g_model__init_part0_A_const_pool.A[182]; A_arbace_j2g_model__init_part0_A_const_134 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[183]); A_arbace_j2g_model__init_part0_A_const_135 = A_arbace_j2g_model__init_part0_A_const_pool.A[184]; A_arbace_j2g_model__init_part0_A_const_136 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[185]); A_arbace_j2g_model__init_part0_A_const_137 = A_arbace_j2g_model__init_part0_A_const_pool.A[186]; A_arbace_j2g_model__init_part0_A_const_138 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[187]); A_arbace_j2g_model__init_part0_A_const_139 = A_arbace_j2g_model__init_part0_A_const_pool.A[188]; A_arbace_j2g_model__init_part0_A_const_140 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[189]); A_arbace_j2g_model__init_part0_A_const_141 = A_arbace_j2g_model__init_part0_A_const_pool.A[190]; A_arbace_j2g_model__init_part0_A_const_142 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[191]); A_arbace_j2g_model__init_part0_A_const_143 = A_arbace_j2g_model__init_part0_A_const_pool.A[192]; A_arbace_j2g_model__init_part0_A_const_144 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[193]); A_arbace_j2g_model__init_part0_A_const_145 = A_arbace_j2g_model__init_part0_A_const_pool.A[194] }

func A_arbace_j2g_model__init_part0_A_clinit_p11() { A_arbace_j2g_model__init_part0_A_const_146 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[195]); A_arbace_j2g_model__init_part0_A_const_147 = A_arbace_j2g_model__init_part0_A_const_pool.A[196]; A_arbace_j2g_model__init_part0_A_const_148 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[197]); A_arbace_j2g_model__init_part0_A_const_149 = A_arbace_j2g_model__init_part0_A_const_pool.A[198]; A_arbace_j2g_model__init_part0_A_const_150 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[199]); A_arbace_j2g_model__init_part0_A_const_151 = A_arbace_j2g_model__init_part0_A_const_pool.A[200]; A_arbace_j2g_model__init_part0_A_const_152 = A_arbace_j2g_model__init_part0_A_const_pool.A[201]; A_arbace_j2g_model__init_part0_A_const_153 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[202]); A_arbace_j2g_model__init_part0_A_const_154 = A_arbace_j2g_model__init_part0_A_const_pool.A[203]; A_arbace_j2g_model__init_part0_A_const_155 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[204]); A_arbace_j2g_model__init_part0_A_const_156 = A_arbace_j2g_model__init_part0_A_const_pool.A[205]; A_arbace_j2g_model__init_part0_A_const_157 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[206]); A_arbace_j2g_model__init_part0_A_const_158 = A_arbace_j2g_model__init_part0_A_const_pool.A[207] }

func A_arbace_j2g_model__init_part0_A_clinit_p12() { A_arbace_j2g_model__init_part0_A_const_159 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[208]); A_arbace_j2g_model__init_part0_A_const_160 = A_arbace_j2g_model__init_part0_A_const_pool.A[209]; A_arbace_j2g_model__init_part0_A_const_161 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[210]); A_arbace_j2g_model__init_part0_A_const_162 = A_arbace_j2g_model__init_part0_A_const_pool.A[211]; A_arbace_j2g_model__init_part0_A_const_163 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[212]); A_arbace_j2g_model__init_part0_A_const_164 = A_arbace_j2g_model__init_part0_A_const_pool.A[213]; A_arbace_j2g_model__init_part0_A_const_165 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[214]); A_arbace_j2g_model__init_part0_A_const_166 = A_arbace_j2g_model__init_part0_A_const_pool.A[215]; A_arbace_j2g_model__init_part0_A_const_167 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[216]); A_arbace_j2g_model__init_part0_A_const_168 = A_arbace_j2g_model__init_part0_A_const_pool.A[217]; A_arbace_j2g_model__init_part0_A_const_169 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[218]); A_arbace_j2g_model__init_part0_A_const_170 = A_arbace_j2g_model__init_part0_A_const_pool.A[219]; A_arbace_j2g_model__init_part0_A_const_171 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[220]) }

func A_arbace_j2g_model__init_part0_A_clinit_p13() { A_arbace_j2g_model__init_part0_A_const_172 = A_arbace_j2g_model__init_part0_A_const_pool.A[221]; A_arbace_j2g_model__init_part0_A_const_173 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[222]); A_arbace_j2g_model__init_part0_A_const_174 = A_arbace_j2g_model__init_part0_A_const_pool.A[223]; A_arbace_j2g_model__init_part0_A_const_175 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[224]); A_arbace_j2g_model__init_part0_A_const_176 = A_arbace_j2g_model__init_part0_A_const_pool.A[225]; A_arbace_j2g_model__init_part0_A_const_177 = A_arbace_j2g_model__init_part0_A_const_pool.A[226]; A_arbace_j2g_model__init_part0_A_const_178 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[227]); A_arbace_j2g_model__init_part0_A_const_179 = A_arbace_j2g_model__init_part0_A_const_pool.A[228]; A_arbace_j2g_model__init_part0_A_const_180 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[229]); A_arbace_j2g_model__init_part0_A_const_181 = A_arbace_j2g_model__init_part0_A_const_pool.A[230]; A_arbace_j2g_model__init_part0_A_const_182 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[231]); A_arbace_j2g_model__init_part0_A_const_183 = A_arbace_j2g_model__init_part0_A_const_pool.A[232]; A_arbace_j2g_model__init_part0_A_const_184 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[233]); A_arbace_j2g_model__init_part0_A_const_185 = A_arbace_j2g_model__init_part0_A_const_pool.A[234] }

func A_arbace_j2g_model__init_part0_A_clinit_p14() { A_arbace_j2g_model__init_part0_A_const_186 = A_arbace_j2g_model__init_part0_A_const_pool.A[235]; A_arbace_j2g_model__init_part0_A_const_187 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[236]); A_arbace_j2g_model__init_part0_A_const_188 = A_arbace_j2g_model__init_part0_A_const_pool.A[237]; A_arbace_j2g_model__init_part0_A_const_189 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[238]); A_arbace_j2g_model__init_part0_A_const_190 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[239]); A_arbace_j2g_model__init_part0_A_const_191 = A_arbace_j2g_model__init_part0_A_const_pool.A[240]; A_arbace_j2g_model__init_part0_A_const_192 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[241]); A_arbace_j2g_model__init_part0_A_const_193 = A_arbace_j2g_model__init_part0_A_const_pool.A[242]; A_arbace_j2g_model__init_part0_A_const_194 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[243]); A_arbace_j2g_model__init_part0_A_const_195 = A_arbace_j2g_model__init_part0_A_const_pool.A[244]; A_arbace_j2g_model__init_part0_A_const_196 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[245]); A_arbace_j2g_model__init_part0_A_const_197 = A_arbace_j2g_model__init_part0_A_const_pool.A[246]; A_arbace_j2g_model__init_part0_A_const_198 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[247]) }

func A_arbace_j2g_model__init_part0_A_clinit_p15() { A_arbace_j2g_model__init_part0_A_const_199 = A_arbace_j2g_model__init_part0_A_const_pool.A[248]; A_arbace_j2g_model__init_part0_A_const_200 = lang.Var_Cast(A_arbace_j2g_model__init_part0_A_const_pool.A[249]); A_arbace_j2g_model__init_part0_A_const_201 = A_arbace_j2g_model__init_part0_A_const_pool.A[250]; A_arbace_j2g_model__init_part0_A_const_202 = A_arbace_j2g_model__init_part0_A_const_pool.A[251] }

func A_arbace_j2g_model__init_part0_A_New() *A_arbace_j2g_model__init_part0_A { A_arbace_j2g_model__init_part0_A_Init(); t := &A_arbace_j2g_model__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model__init_part0_A) Ctor() {}

func (t *A_arbace_j2g_model__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model__init_part0_A_class }

func (t *A_arbace_j2g_model__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model__init_part0_A); return ok }

func A_arbace_j2g_model__init_part0_A_Cast(x any) *A_arbace_j2g_model__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model__init_part0_A_class)) }; return v }



type A_arbace_j2g_model__init_part1_A struct{ jrt.Object }

var A_arbace_j2g_model__init_part1_A_const_pool *jrt.RefArray

var A_arbace_j2g_model__init_part1_A_const_0 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_1 any

var A_arbace_j2g_model__init_part1_A_const_2 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_3 any

var A_arbace_j2g_model__init_part1_A_const_4 any

var A_arbace_j2g_model__init_part1_A_const_5 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_6 any

var A_arbace_j2g_model__init_part1_A_const_7 any

var A_arbace_j2g_model__init_part1_A_const_8 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_9 any

var A_arbace_j2g_model__init_part1_A_const_10 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_11 any

var A_arbace_j2g_model__init_part1_A_const_12 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_13 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_14 any

var A_arbace_j2g_model__init_part1_A_const_15 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_16 any

var A_arbace_j2g_model__init_part1_A_const_17 *lang.Var

var A_arbace_j2g_model__init_part1_A_const_18 any

var A_arbace_j2g_model__init_part1_A_init jrt.ClassInit

func A_arbace_j2g_model__init_part1_A_Init() { if !A_arbace_j2g_model__init_part1_A_init.Done() { A_arbace_j2g_model__init_part1_A_init.Run(A_arbace_j2g_model__init_part1_A_clinit) } }

func A_arbace_j2g_model__init_part1_A_clinit() { jrt.StartCheck(); A_arbace_j2g_model__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_205, 28); A_arbace_j2g_model__init_part1_A_const_0 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[10]); A_arbace_j2g_model__init_part1_A_const_1 = A_arbace_j2g_model__init_part1_A_const_pool.A[11]; A_arbace_j2g_model__init_part1_A_const_2 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[12]); A_arbace_j2g_model__init_part1_A_const_3 = A_arbace_j2g_model__init_part1_A_const_pool.A[13]; A_arbace_j2g_model__init_part1_A_const_4 = A_arbace_j2g_model__init_part1_A_const_pool.A[14]; A_arbace_j2g_model__init_part1_A_const_5 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[15]); A_arbace_j2g_model__init_part1_A_const_6 = A_arbace_j2g_model__init_part1_A_const_pool.A[16]; A_arbace_j2g_model__init_part1_A_const_7 = A_arbace_j2g_model__init_part1_A_const_pool.A[17]; A_arbace_j2g_model__init_part1_A_const_8 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[18]); A_arbace_j2g_model__init_part1_A_const_9 = A_arbace_j2g_model__init_part1_A_const_pool.A[19]; A_arbace_j2g_model__init_part1_A_const_10 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[20]); A_arbace_j2g_model__init_part1_A_const_11 = A_arbace_j2g_model__init_part1_A_const_pool.A[21]; A_arbace_j2g_model__init_part1_A_const_12 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[22]); A_arbace_j2g_model__init_part1_A_const_13 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[23]); A_arbace_j2g_model__init_part1_A_const_14 = A_arbace_j2g_model__init_part1_A_const_pool.A[24]; var tmp1 *lang.Var; A_arbace_j2g_model__init_part0_A_Init(); tmp1 = A_arbace_j2g_model__init_part0_A_const_80; A_arbace_j2g_model__init_part1_A_const_15 = tmp1; A_arbace_j2g_model__init_part1_A_const_16 = A_arbace_j2g_model__init_part1_A_const_pool.A[25]; A_arbace_j2g_model__init_part1_A_const_17 = lang.Var_Cast(A_arbace_j2g_model__init_part1_A_const_pool.A[26]); A_arbace_j2g_model__init_part1_A_const_18 = A_arbace_j2g_model__init_part1_A_const_pool.A[27] }

func A_arbace_j2g_model__init_part1_A_New() *A_arbace_j2g_model__init_part1_A { A_arbace_j2g_model__init_part1_A_Init(); t := &A_arbace_j2g_model__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model__init_part1_A) Ctor() {}

func (t *A_arbace_j2g_model__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model__init_part1_A_class }

func (t *A_arbace_j2g_model__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model__init_part1_A); return ok }

func A_arbace_j2g_model__init_part1_A_Cast(x any) *A_arbace_j2g_model__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model__init_part1_A_class)) }; return v }
