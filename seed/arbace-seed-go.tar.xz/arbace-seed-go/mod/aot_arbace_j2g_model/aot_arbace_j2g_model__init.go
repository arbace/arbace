//line aot_arbace_j2g_model__init.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model__init_A_Unit0__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_model__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model__init_A_const_1) }
//line :1:1
func A_arbace_j2g_model__init_A_Unit1__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_model__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_model__init_A_Unit2__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_j2g_model__init_A_Unit3__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_model__init_A_const_1)).Equals_O__Z(A_arbace_j2g_model__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_j2g_model__init_A_Load__O() any { A_arbace_j2g_model__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_model__init_A_Unit0__O(); A_arbace_j2g_model__init_A_Unit1__O(); A_arbace_j2g_model__init_A_Unit2__O(); A_arbace_j2g_model__init_A_Unit3__O(); A_arbace_j2g_model__init_A_Unit4__O(); A_arbace_j2g_model__init_A_Unit5__O(); A_arbace_j2g_model__init_A_Unit6__O(); A_arbace_j2g_model__init_A_Unit7__O(); A_arbace_j2g_model__init_A_Unit8__O(); A_arbace_j2g_model__init_A_Unit9__O(); A_arbace_j2g_model__init_A_Unit10__O(); A_arbace_j2g_model__init_A_Unit11__O(); A_arbace_j2g_model__init_A_Unit12__O(); A_arbace_j2g_model__init_A_Unit13__O(); A_arbace_j2g_model__init_A_Unit14__O(); A_arbace_j2g_model__init_A_Unit15__O(); A_arbace_j2g_model__init_A_Unit16__O(); A_arbace_j2g_model__init_A_Unit17__O(); A_arbace_j2g_model__init_A_Unit18__O(); A_arbace_j2g_model__init_A_Unit19__O(); A_arbace_j2g_model__init_A_Unit20__O(); A_arbace_j2g_model__init_A_Unit21__O(); A_arbace_j2g_model__init_A_Unit22__O(); A_arbace_j2g_model__init_A_Unit23__O(); A_arbace_j2g_model__init_A_Unit24__O(); A_arbace_j2g_model__init_A_Unit25__O(); A_arbace_j2g_model__init_A_Unit26__O(); A_arbace_j2g_model__init_A_Unit27__O(); A_arbace_j2g_model__init_A_Unit28__O(); A_arbace_j2g_model__init_A_Unit29__O(); A_arbace_j2g_model__init_A_Unit30__O(); A_arbace_j2g_model__init_A_Unit31__O(); A_arbace_j2g_model__init_A_Unit32__O(); A_arbace_j2g_model__init_A_Unit33__O(); A_arbace_j2g_model__init_A_Unit34__O(); A_arbace_j2g_model__init_A_Unit35__O(); A_arbace_j2g_model__init_A_Unit36__O(); A_arbace_j2g_model__init_A_Unit37__O(); A_arbace_j2g_model__init_A_Unit38__O(); A_arbace_j2g_model__init_A_Unit39__O(); A_arbace_j2g_model__init_A_Unit40__O(); A_arbace_j2g_model__init_A_Unit41__O(); A_arbace_j2g_model__init_A_Unit42__O(); A_arbace_j2g_model__init_A_Unit43__O(); A_arbace_j2g_model__init_A_Unit44__O(); A_arbace_j2g_model__init_A_Unit45__O(); A_arbace_j2g_model__init_A_Unit46__O(); A_arbace_j2g_model__init_A_Unit47__O(); A_arbace_j2g_model__init_A_Unit48__O(); A_arbace_j2g_model__init_A_Unit49__O(); A_arbace_j2g_model__init_A_Unit50__O(); A_arbace_j2g_model__init_A_Unit51__O(); A_arbace_j2g_model__init_A_Unit52__O(); A_arbace_j2g_model__init_A_Unit53__O(); A_arbace_j2g_model__init_A_Unit54__O(); A_arbace_j2g_model__init_A_Unit55__O(); A_arbace_j2g_model__init_A_Unit56__O(); A_arbace_j2g_model__init_A_Unit57__O(); A_arbace_j2g_model__init_A_Unit58__O(); A_arbace_j2g_model__init_A_Unit59__O(); A_arbace_j2g_model__init_A_Unit60__O(); A_arbace_j2g_model__init_A_Unit61__O(); A_arbace_j2g_model__init_A_Unit62__O(); A_arbace_j2g_model__init_A_Unit63__O(); A_arbace_j2g_model__init_A_Unit64__O(); A_arbace_j2g_model__init_A_Unit65__O(); A_arbace_j2g_model__init_A_Unit66__O(); A_arbace_j2g_model__init_A_Unit67__O(); A_arbace_j2g_model__init_A_Unit68__O(); A_arbace_j2g_model__init_A_Unit69__O(); A_arbace_j2g_model__init_A_Unit70__O(); A_arbace_j2g_model__init_A_Unit71__O(); A_arbace_j2g_model__init_A_Unit72__O(); A_arbace_j2g_model__init_A_Unit73__O(); A_arbace_j2g_model__init_A_Unit74__O(); A_arbace_j2g_model__init_A_Unit75__O(); A_arbace_j2g_model__init_A_Unit76__O(); A_arbace_j2g_model__init_A_Unit77__O(); A_arbace_j2g_model__init_A_Unit78__O(); A_arbace_j2g_model__init_A_Unit79__O(); A_arbace_j2g_model__init_A_Unit80__O(); return nil }








func A_arbace_j2g_model__init_A_Unit4__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); A_arbace_j2g_model__init_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_5)); return A_arbace_j2g_model__init_A_const_4.SetDynamic_Z__Var(true).Ref() }






func A_arbace_j2g_model__init_A_Unit5__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); A_arbace_j2g_model__init_A_const_6.BindRoot_O__V(A_arbace_j2g_model__init_A_const_7); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_8)); return A_arbace_j2g_model__init_A_const_6 }




func A_arbace_j2g_model__init_A_Unit6__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_9; var tmp2 any = A_arbace_j2g_model_jobs_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_model_jobs_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_j2g_model_jobs_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_10)); return A_arbace_j2g_model__init_A_const_9 }








func A_arbace_j2g_model__init_A_Unit7__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_11; var tmp2 any = A_arbace_j2g_model_par_mapv_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_model_par_mapv_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, true); A_arbace_j2g_model_par_mapv_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_12)); return A_arbace_j2g_model__init_A_const_11 }































func A_arbace_j2g_model__init_A_Unit8__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_13; var tmp2 any = A_arbace_j2g_model_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_model_has_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_model_has_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_14)); return A_arbace_j2g_model__init_A_const_13 }

func A_arbace_j2g_model__init_A_Unit9__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_15; var tmp2 any = A_arbace_j2g_model_T_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_model_T_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_model_T_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_16)); return A_arbace_j2g_model__init_A_const_15 }

func A_arbace_j2g_model__init_A_Unit10__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_17; var tmp2 any = A_arbace_j2g_model_translated_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_model_translated_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_model_translated_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_18)); return A_arbace_j2g_model__init_A_const_17 }

func A_arbace_j2g_model__init_A_Unit11__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_19; var tmp2 any = A_arbace_j2g_model_j2g_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_model_j2g_static_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_model_j2g_static_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_20)); return A_arbace_j2g_model__init_A_const_19 }








func A_arbace_j2g_model__init_A_Unit12__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_21; var tmp2 any = A_arbace_j2g_model_jrt_class_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_model_jrt_class_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_j2g_model_jrt_class_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_22)); return A_arbace_j2g_model__init_A_const_21 }




func A_arbace_j2g_model__init_A_Unit13__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_23; var tmp2 any = A_arbace_j2g_model_hand_written_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_model_hand_written_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_model_hand_written_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_24)); return A_arbace_j2g_model__init_A_const_23 }




func A_arbace_j2g_model__init_A_Unit14__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_25; var tmp2 any = A_arbace_j2g_model_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_model_in_world_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_model_in_world_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_26)); return A_arbace_j2g_model__init_A_const_25 }


func A_arbace_j2g_model__init_A_Unit15__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_27; var tmp2 any = A_arbace_j2g_model_translatable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_model_translatable_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_j2g_model_translatable_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_28)); return A_arbace_j2g_model__init_A_const_27 }




func A_arbace_j2g_model__init_A_Unit16__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_29; var tmp2 any = A_arbace_j2g_model_reflectable_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_30)); return A_arbace_j2g_model__init_A_const_29 }

















func A_arbace_j2g_model__init_A_Unit17__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_31; var tmp2 any = A_arbace_j2g_model_reflected_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_model_reflected_QMARK__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_model_reflected_QMARK__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_32)); return A_arbace_j2g_model__init_A_const_31 }




func A_arbace_j2g_model__init_A_Unit18__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_33; var tmp2 any = A_arbace_j2g_model_info_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_model_info_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_model_info_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_34)); return A_arbace_j2g_model__init_A_const_33 }
func A_arbace_j2g_model__init_A_Unit19__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_35; var tmp2 any = A_arbace_j2g_model_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_model_interface_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_j2g_model_interface_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_36)); return A_arbace_j2g_model__init_A_const_35 }

func A_arbace_j2g_model__init_A_Unit20__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_37; var tmp2 any = A_arbace_j2g_model_desc_classes_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_model_desc_classes_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_j2g_model_desc_classes_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_38)); return A_arbace_j2g_model__init_A_const_37 }








func A_arbace_j2g_model__init_A_Unit21__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_39; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_j2g_model__init_A_const_39; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_40)); return A_arbace_j2g_model__init_A_const_39 }



func A_arbace_j2g_model__init_A_Unit22__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_41; var tmp2 any = A_arbace_j2g_model_method_desc_classes_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_model_method_desc_classes_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_model_method_desc_classes_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_42)); return A_arbace_j2g_model__init_A_const_41 }






func A_arbace_j2g_model__init_A_Unit23__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_43; var tmp2 any = A_arbace_j2g_model_erased_desc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_j2g_model_erased_desc_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_44)); return A_arbace_j2g_model__init_A_const_43 }











func A_arbace_j2g_model__init_A_Unit24__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_45; var tmp2 any = A_arbace_j2g_model_desc_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_46)); return A_arbace_j2g_model__init_A_const_45 }
func A_arbace_j2g_model__init_A_Unit25__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_47; var tmp2 any = A_arbace_j2g_model_mdesc_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_48)); return A_arbace_j2g_model__init_A_const_47 }




func A_arbace_j2g_model__init_A_Unit26__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_49; var tmp2 any = A_arbace_j2g_model_go_name_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_j2g_model_go_name_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_j2g_model_go_name_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_50)); return A_arbace_j2g_model__init_A_const_49 }








func A_arbace_j2g_model__init_A_Unit27__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_51; var tmp2 any = A_arbace_j2g_model_pkg_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_model_pkg_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_model_pkg_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_52)); return A_arbace_j2g_model__init_A_const_51 }

func A_arbace_j2g_model__init_A_Unit28__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_53; var tmp2 any = A_arbace_j2g_model_abstract_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_model_abstract_QMARK__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_j2g_model_abstract_QMARK__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_54)); return A_arbace_j2g_model__init_A_const_53 }
func A_arbace_j2g_model__init_A_Unit29__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_55; var tmp2 any = A_arbace_j2g_model_final_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_model_final_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_j2g_model_final_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_56)); return A_arbace_j2g_model__init_A_const_55 }

func A_arbace_j2g_model__init_A_Unit30__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_57; var tmp2 any = A_arbace_j2g_model_subclasses_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_model_subclasses_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_j2g_model_subclasses_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_58)); return A_arbace_j2g_model__init_A_const_57 }




func A_arbace_j2g_model__init_A_Unit31__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(183, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_59; var tmp2 any = A_arbace_j2g_model_make_subclass_index_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_model_make_subclass_index_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_j2g_model_make_subclass_index_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_60)); return A_arbace_j2g_model__init_A_const_59 }










func A_arbace_j2g_model__init_A_Unit32__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(194, 1); A_arbace_j2g_model__init_A_const_61.BindRoot_O__V(A_arbace_j2g_model__init_A_const_62); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_63)); return A_arbace_j2g_model__init_A_const_61 }












func A_arbace_j2g_model__init_A_Unit33__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_64; var tmp2 any; var root_28 any = A_arbace_j2g_model__init_A_const_65.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_j2g_model__init_A_const_61.GetRawRoot__O(); if linked_29 == nil { tmp2 = ifn_30.Invoke_O__O(arg_31) } else { tmp2 = linked_29.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_28, arg_31) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_model__init_A_const_64; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_66)); return A_arbace_j2g_model__init_A_const_64 }

func A_arbace_j2g_model__init_A_Unit34__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_67; var tmp2 any = A_arbace_j2g_model_leaf_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_model_leaf_QMARK__A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_j2g_model_leaf_QMARK__A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_68)); return A_arbace_j2g_model__init_A_const_67 }














func A_arbace_j2g_model__init_A_Unit35__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_69; var tmp2 any = A_arbace_j2g_model_qualify_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_model_qualify_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_j2g_model_qualify_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_70)); return A_arbace_j2g_model__init_A_const_69 }




func A_arbace_j2g_model__init_A_Unit36__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_71; var tmp2 any = A_arbace_j2g_model_class_sym_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_j2g_model_class_sym_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_j2g_model_class_sym_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_72)); return A_arbace_j2g_model__init_A_const_71 }




func A_arbace_j2g_model__init_A_Unit37__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_73; var tmp2 any = A_arbace_j2g_model_jrt_sym_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_model_jrt_sym_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_j2g_model_jrt_sym_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_74)); return A_arbace_j2g_model__init_A_const_73 }

func A_arbace_j2g_model__init_A_Unit38__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); A_arbace_j2g_model__init_A_const_75.BindRoot_O__V(A_arbace_j2g_model__init_A_const_76); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_75; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_77)); return A_arbace_j2g_model__init_A_const_75 }

func A_arbace_j2g_model__init_A_Unit39__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(238, 1); A_arbace_j2g_model__init_A_const_78.BindRoot_O__V(A_arbace_j2g_model__init_A_const_79); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_80)); return A_arbace_j2g_model__init_A_const_78 }


func A_arbace_j2g_model__init_A_Unit40__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_81; var tmp2 any = A_arbace_j2g_model_array_test_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_model_array_test_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_j2g_model_array_test_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_82)); return A_arbace_j2g_model__init_A_const_81 }













func A_arbace_j2g_model__init_A_Unit41__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_83; var tmp2 any = A_arbace_j2g_model_go_type_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_model_go_type_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_j2g_model_go_type_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_84)); return A_arbace_j2g_model__init_A_const_83 }




















func A_arbace_j2g_model__init_A_Unit42__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(276, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_85; var tmp2 any = A_arbace_j2g_model_pointer_desc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_86)); return A_arbace_j2g_model__init_A_const_85 }








func A_arbace_j2g_model__init_A_Unit43__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(285, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_87; var tmp2 any = A_arbace_j2g_model_iface_desc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_model_iface_desc_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_j2g_model_iface_desc_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_88)); return A_arbace_j2g_model__init_A_const_87 }







func A_arbace_j2g_model__init_A_Unit44__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(293, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_89; var tmp2 any = A_arbace_j2g_model_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_j2g_model_static_QMARK__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_j2g_model_static_QMARK__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_90)); return A_arbace_j2g_model__init_A_const_89 }
func A_arbace_j2g_model__init_A_Unit45__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(294, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_91; var tmp2 any = A_arbace_j2g_model_private_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_model_private_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_j2g_model_private_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_92)); return A_arbace_j2g_model__init_A_const_91 }
func A_arbace_j2g_model__init_A_Unit46__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_93; var tmp2 any = A_arbace_j2g_model_abstract_m_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_j2g_model_abstract_m_QMARK__A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_j2g_model_abstract_m_QMARK__A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_94)); return A_arbace_j2g_model__init_A_const_93 }

func A_arbace_j2g_model__init_A_Unit47__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_95; var tmp2 any = A_arbace_j2g_model_methods_of_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_model_methods_of_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_j2g_model_methods_of_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_96)); return A_arbace_j2g_model__init_A_const_95 }
func A_arbace_j2g_model__init_A_Unit48__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_97; var tmp2 any = A_arbace_j2g_model_fields_of_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_model_fields_of_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_j2g_model_fields_of_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_98)); return A_arbace_j2g_model__init_A_const_97 }

func A_arbace_j2g_model__init_A_Unit49__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_99; var tmp2 any = A_arbace_j2g_model_find_method_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_model_find_method_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_j2g_model_find_method_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_100)); return A_arbace_j2g_model__init_A_const_99 }


func A_arbace_j2g_model__init_A_Unit50__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(303, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_101; var tmp2 any = A_arbace_j2g_model_virtual_member_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_j2g_model_virtual_member_QMARK__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_j2g_model_virtual_member_QMARK__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_102)); return A_arbace_j2g_model__init_A_const_101 }




func A_arbace_j2g_model__init_A_Unit51__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(308, 1); A_arbace_j2g_model__init_A_const_103.BindRoot_O__V(A_arbace_j2g_model__init_A_const_104); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_103; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_105)); return A_arbace_j2g_model__init_A_const_103 }




func A_arbace_j2g_model__init_A_Unit52__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_106; var tmp2 any = A_arbace_j2g_model_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_model_supertypes_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_j2g_model_supertypes_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_107)); return A_arbace_j2g_model__init_A_const_106 }


func A_arbace_j2g_model__init_A_Unit53__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(316, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_108; var tmp2 any = A_arbace_j2g_model_world_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_j2g_model_world_supertypes_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_j2g_model_world_supertypes_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_109)); return A_arbace_j2g_model__init_A_const_108 }




func A_arbace_j2g_model__init_A_Unit54__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_110; var tmp2 any = A_arbace_j2g_model_all_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_model_all_supertypes_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_j2g_model_all_supertypes_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_111)); return A_arbace_j2g_model__init_A_const_110 }






func A_arbace_j2g_model__init_A_Unit55__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_113)); return A_arbace_j2g_model__init_A_const_112 }

func A_arbace_j2g_model__init_A_Unit56__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_114; var tmp2 any = A_arbace_j2g_model_hw_method_exists_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_115)); return A_arbace_j2g_model__init_A_const_114 }














func A_arbace_j2g_model__init_A_Unit57__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_112; var tmp2 any = A_arbace_j2g_model_j2g_method_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_model_j2g_method_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_j2g_model_j2g_method_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_116)); return A_arbace_j2g_model__init_A_const_112 }









func A_arbace_j2g_model__init_A_Unit58__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(355, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_117; var tmp2 any = A_arbace_j2g_model_member_in_world_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_model_member_in_world_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_j2g_model_member_in_world_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_118)); return A_arbace_j2g_model__init_A_const_117 }






func A_arbace_j2g_model__init_A_Unit59__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(362, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_119; var tmp2 any = A_arbace_j2g_model_declared_vmethods_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_model_declared_vmethods_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_j2g_model_declared_vmethods_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_120)); return A_arbace_j2g_model__init_A_const_119 }







func A_arbace_j2g_model__init_A_Unit60__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_121; var tmp2 any = A_arbace_j2g_model_vmethods_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_model_vmethods_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_j2g_model_vmethods_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_122)); return A_arbace_j2g_model__init_A_const_121 }
















func A_arbace_j2g_model__init_A_Unit61__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_123; var tmp2 any = A_arbace_j2g_model_java_type_name_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_model_java_type_name_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_j2g_model_java_type_name_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_124)); return A_arbace_j2g_model__init_A_const_123 }







func A_arbace_j2g_model__init_A_Unit62__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_125; var tmp2 any = A_arbace_j2g_model_abstract_method_error_text_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_model_abstract_method_error_text_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_j2g_model_abstract_method_error_text_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_126)); return A_arbace_j2g_model__init_A_const_125 }








func A_arbace_j2g_model__init_A_Unit63__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(404, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_127; var tmp2 any = A_arbace_j2g_model_superclass_chain_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_model_superclass_chain_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_j2g_model_superclass_chain_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_128)); return A_arbace_j2g_model__init_A_const_127 }


func A_arbace_j2g_model__init_A_Unit64__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_129; var tmp2 any = A_arbace_j2g_model_impl_of_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_j2g_model_impl_of_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_j2g_model_impl_of_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_130)); return A_arbace_j2g_model__init_A_const_129 }






























func A_arbace_j2g_model__init_A_Unit65__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(438, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_131; var tmp2 any = A_arbace_j2g_model_code_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_model_code_class_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_j2g_model_code_class_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_132)); return A_arbace_j2g_model__init_A_const_131 }









func A_arbace_j2g_model__init_A_Unit66__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(448, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_133; var tmp2 any = A_arbace_j2g_model_code_iface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_j2g_model_code_iface_QMARK__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_j2g_model_code_iface_QMARK__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_134)); return A_arbace_j2g_model__init_A_const_133 }





func A_arbace_j2g_model__init_A_Unit67__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(454, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_135; var tmp2 any = A_arbace_j2g_model_nest_top_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_model_nest_top_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_j2g_model_nest_top_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_136)); return A_arbace_j2g_model__init_A_const_135 }




func A_arbace_j2g_model__init_A_Unit68__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(459, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_137; var tmp2 any = A_arbace_j2g_model_trivial_init_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_model_trivial_init_QMARK__A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_j2g_model_trivial_init_QMARK__A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_138)); return A_arbace_j2g_model__init_A_const_137 }























func A_arbace_j2g_model__init_A_Unit69__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(483, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_139; var tmp2 any = A_arbace_j2g_model_go_qualified_name_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_model_go_qualified_name_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_j2g_model_go_qualified_name_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_140)); return A_arbace_j2g_model__init_A_const_139 }





func A_arbace_j2g_model__init_A_Unit70__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(489, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_141; var tmp2 any; var root_64 any = A_arbace_j2g_model__init_A_const_65.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_66 lang.IFn; if

	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_j2g_model__init_A_const_142.GetRawRoot__O(); if linked_65 == nil { tmp2 = ifn_66.Invoke_O__O(arg_67) } else { tmp2 = linked_65.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_64, arg_67) }; /*line :489:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_model__init_A_const_141; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_143)); return A_arbace_j2g_model__init_A_const_141 }



func A_arbace_j2g_model__init_A_Unit71__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(493, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_144; var tmp2 any = A_arbace_j2g_model_start_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_model_start_class_QMARK__A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_j2g_model_start_class_QMARK__A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_145)); return A_arbace_j2g_model__init_A_const_144 }






func A_arbace_j2g_model__init_A_Unit72__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(500, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_146; var tmp2 any = A_arbace_j2g_model_start_classes_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_model_start_classes_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_j2g_model_start_classes_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_147)); return A_arbace_j2g_model__init_A_const_146 }








func A_arbace_j2g_model__init_A_Unit73__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(509, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_148; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_149)); return A_arbace_j2g_model__init_A_const_148 }

func A_arbace_j2g_model__init_A_Unit74__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(511, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_150; var tmp2 any = A_arbace_j2g_model_top_class_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_j2g_model_top_class_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_j2g_model_top_class_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_151)); return A_arbace_j2g_model__init_A_const_150 }

func A_arbace_j2g_model__init_A_Unit75__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_152; var tmp2 any = A_arbace_j2g_model_pure_ctor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_153)); return A_arbace_j2g_model__init_A_const_152 }






















func A_arbace_j2g_model__init_A_Unit76__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(536, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_148; var tmp2 any = A_arbace_j2g_model_pure_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_j2g_model_pure_node_QMARK__A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_154)); return A_arbace_j2g_model__init_A_const_148 }


























func A_arbace_j2g_model__init_A_Unit77__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(563, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_155; var tmp2 any = A_arbace_j2g_model_benign_init_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_j2g_model_benign_init_QMARK__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_156)); return A_arbace_j2g_model__init_A_const_155 }























func A_arbace_j2g_model__init_A_Unit78__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(587, 1); A_arbace_j2g_model__init_A_const_157.BindRoot_O__V(A_arbace_j2g_model__init_A_const_158); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_157; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_159)); return A_arbace_j2g_model__init_A_const_157 }









func A_arbace_j2g_model__init_A_Unit79__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(597, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_160; var tmp2 any; var root_74 any = A_arbace_j2g_model__init_A_const_161.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_76 lang.IFn; if








	linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = A_arbace_j2g_model__init_A_const_162; var arg_78 any; var tmp3 any = A_arbace_j2g_model_fn__1479000200_A_New(); var tmp4 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_model_fn__1479000200_A_fn_class; if




	fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_j2g_model_fn__1479000200_A_fn_class = fncls__79d; tmp4 = fncls__79d } else { tmp4 = fncls__79 }; arg_78 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); if /*line :606:1*/ linked_75 == nil { tmp2 = ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { tmp2 = linked_75.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_74, arg_77, arg_78) }; /*line :597:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_j2g_model__init_A_const_160; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_163)); return A_arbace_j2g_model__init_A_const_160 }
















func A_arbace_j2g_model__init_A_Unit80__O() any { A_arbace_j2g_model__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(614, 1); var tmp1 *lang.Var = A_arbace_j2g_model__init_A_const_164; var tmp2 any = A_arbace_j2g_model_throwable_print_helper_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_j2g_model_throwable_print_helper_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_j2g_model_throwable_print_helper_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_model__init_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_model__init_A_const_165)); return A_arbace_j2g_model__init_A_const_164 }



type A_arbace_j2g_model__init_A struct{ jrt.Object }

var A_arbace_j2g_model__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_model__init_A_const_0 *lang.Var

var A_arbace_j2g_model__init_A_const_1 any

var A_arbace_j2g_model__init_A_const_2 any

var A_arbace_j2g_model__init_A_const_3 any

var A_arbace_j2g_model__init_A_const_4 *lang.Var

var A_arbace_j2g_model__init_A_const_5 any

var A_arbace_j2g_model__init_A_const_6 *lang.Var

var A_arbace_j2g_model__init_A_const_7 any

var A_arbace_j2g_model__init_A_const_8 any

var A_arbace_j2g_model__init_A_const_9 *lang.Var

var A_arbace_j2g_model__init_A_const_10 any

var A_arbace_j2g_model__init_A_const_11 *lang.Var

var A_arbace_j2g_model__init_A_const_12 any

var A_arbace_j2g_model__init_A_const_13 *lang.Var

var A_arbace_j2g_model__init_A_const_14 any

var A_arbace_j2g_model__init_A_const_15 *lang.Var

var A_arbace_j2g_model__init_A_const_16 any

var A_arbace_j2g_model__init_A_const_17 *lang.Var

var A_arbace_j2g_model__init_A_const_18 any

var A_arbace_j2g_model__init_A_const_19 *lang.Var

var A_arbace_j2g_model__init_A_const_20 any

var A_arbace_j2g_model__init_A_const_21 *lang.Var

var A_arbace_j2g_model__init_A_const_22 any

var A_arbace_j2g_model__init_A_const_23 *lang.Var

var A_arbace_j2g_model__init_A_const_24 any

var A_arbace_j2g_model__init_A_const_25 *lang.Var

var A_arbace_j2g_model__init_A_const_26 any

var A_arbace_j2g_model__init_A_const_27 *lang.Var

var A_arbace_j2g_model__init_A_const_28 any

var A_arbace_j2g_model__init_A_const_29 *lang.Var

var A_arbace_j2g_model__init_A_const_30 any

var A_arbace_j2g_model__init_A_const_31 *lang.Var

var A_arbace_j2g_model__init_A_const_32 any

var A_arbace_j2g_model__init_A_const_33 *lang.Var

var A_arbace_j2g_model__init_A_const_34 any

var A_arbace_j2g_model__init_A_const_35 *lang.Var

var A_arbace_j2g_model__init_A_const_36 any

var A_arbace_j2g_model__init_A_const_37 *lang.Var

var A_arbace_j2g_model__init_A_const_38 any

var A_arbace_j2g_model__init_A_const_39 *lang.Var

var A_arbace_j2g_model__init_A_const_40 any

var A_arbace_j2g_model__init_A_const_41 *lang.Var

var A_arbace_j2g_model__init_A_const_42 any

var A_arbace_j2g_model__init_A_const_43 *lang.Var

var A_arbace_j2g_model__init_A_const_44 any

var A_arbace_j2g_model__init_A_const_45 *lang.Var

var A_arbace_j2g_model__init_A_const_46 any

var A_arbace_j2g_model__init_A_const_47 *lang.Var

var A_arbace_j2g_model__init_A_const_48 any

var A_arbace_j2g_model__init_A_const_49 *lang.Var

var A_arbace_j2g_model__init_A_const_50 any

var A_arbace_j2g_model__init_A_const_51 *lang.Var

var A_arbace_j2g_model__init_A_const_52 any

var A_arbace_j2g_model__init_A_const_53 *lang.Var

var A_arbace_j2g_model__init_A_const_54 any

var A_arbace_j2g_model__init_A_const_55 *lang.Var

var A_arbace_j2g_model__init_A_const_56 any

var A_arbace_j2g_model__init_A_const_57 *lang.Var

var A_arbace_j2g_model__init_A_const_58 any

var A_arbace_j2g_model__init_A_const_59 *lang.Var

var A_arbace_j2g_model__init_A_const_60 any

var A_arbace_j2g_model__init_A_const_61 *lang.Var

var A_arbace_j2g_model__init_A_const_62 any

var A_arbace_j2g_model__init_A_const_63 any

var A_arbace_j2g_model__init_A_const_64 *lang.Var

var A_arbace_j2g_model__init_A_const_65 *lang.Var

var A_arbace_j2g_model__init_A_const_66 any

var A_arbace_j2g_model__init_A_const_67 *lang.Var

var A_arbace_j2g_model__init_A_const_68 any

var A_arbace_j2g_model__init_A_const_69 *lang.Var

var A_arbace_j2g_model__init_A_const_70 any

var A_arbace_j2g_model__init_A_const_71 *lang.Var

var A_arbace_j2g_model__init_A_const_72 any

var A_arbace_j2g_model__init_A_const_73 *lang.Var

var A_arbace_j2g_model__init_A_const_74 any

var A_arbace_j2g_model__init_A_const_75 *lang.Var

var A_arbace_j2g_model__init_A_const_76 any

var A_arbace_j2g_model__init_A_const_77 any

var A_arbace_j2g_model__init_A_const_78 *lang.Var

var A_arbace_j2g_model__init_A_const_79 any

var A_arbace_j2g_model__init_A_const_80 any

var A_arbace_j2g_model__init_A_const_81 *lang.Var

var A_arbace_j2g_model__init_A_const_82 any

var A_arbace_j2g_model__init_A_const_83 *lang.Var

var A_arbace_j2g_model__init_A_const_84 any

var A_arbace_j2g_model__init_A_const_85 *lang.Var

var A_arbace_j2g_model__init_A_const_86 any

var A_arbace_j2g_model__init_A_const_87 *lang.Var

var A_arbace_j2g_model__init_A_const_88 any

var A_arbace_j2g_model__init_A_const_89 *lang.Var

var A_arbace_j2g_model__init_A_const_90 any

var A_arbace_j2g_model__init_A_const_91 *lang.Var

var A_arbace_j2g_model__init_A_const_92 any

var A_arbace_j2g_model__init_A_const_93 *lang.Var

var A_arbace_j2g_model__init_A_const_94 any

var A_arbace_j2g_model__init_A_const_95 *lang.Var

var A_arbace_j2g_model__init_A_const_96 any

var A_arbace_j2g_model__init_A_const_97 *lang.Var

var A_arbace_j2g_model__init_A_const_98 any

var A_arbace_j2g_model__init_A_const_99 *lang.Var

var A_arbace_j2g_model__init_A_const_100 any

var A_arbace_j2g_model__init_A_const_101 *lang.Var

var A_arbace_j2g_model__init_A_const_102 any

var A_arbace_j2g_model__init_A_const_103 *lang.Var

var A_arbace_j2g_model__init_A_const_104 any

var A_arbace_j2g_model__init_A_const_105 any

var A_arbace_j2g_model__init_A_const_106 *lang.Var

var A_arbace_j2g_model__init_A_const_107 any

var A_arbace_j2g_model__init_A_const_108 *lang.Var

var A_arbace_j2g_model__init_A_const_109 any

var A_arbace_j2g_model__init_A_const_110 *lang.Var

var A_arbace_j2g_model__init_A_const_111 any

var A_arbace_j2g_model__init_A_const_112 *lang.Var

var A_arbace_j2g_model__init_A_const_113 any

var A_arbace_j2g_model__init_A_const_114 *lang.Var

var A_arbace_j2g_model__init_A_const_115 any

var A_arbace_j2g_model__init_A_const_116 any

var A_arbace_j2g_model__init_A_const_117 *lang.Var

var A_arbace_j2g_model__init_A_const_118 any

var A_arbace_j2g_model__init_A_const_119 *lang.Var

var A_arbace_j2g_model__init_A_const_120 any

var A_arbace_j2g_model__init_A_const_121 *lang.Var

var A_arbace_j2g_model__init_A_const_122 any

var A_arbace_j2g_model__init_A_const_123 *lang.Var

var A_arbace_j2g_model__init_A_const_124 any

var A_arbace_j2g_model__init_A_const_125 *lang.Var

var A_arbace_j2g_model__init_A_const_126 any

var A_arbace_j2g_model__init_A_const_127 *lang.Var

var A_arbace_j2g_model__init_A_const_128 any

var A_arbace_j2g_model__init_A_const_129 *lang.Var

var A_arbace_j2g_model__init_A_const_130 any

var A_arbace_j2g_model__init_A_const_131 *lang.Var

var A_arbace_j2g_model__init_A_const_132 any

var A_arbace_j2g_model__init_A_const_133 *lang.Var

var A_arbace_j2g_model__init_A_const_134 any

var A_arbace_j2g_model__init_A_const_135 *lang.Var

var A_arbace_j2g_model__init_A_const_136 any

var A_arbace_j2g_model__init_A_const_137 *lang.Var

var A_arbace_j2g_model__init_A_const_138 any

var A_arbace_j2g_model__init_A_const_139 *lang.Var

var A_arbace_j2g_model__init_A_const_140 any

var A_arbace_j2g_model__init_A_const_141 *lang.Var

var A_arbace_j2g_model__init_A_const_142 *lang.Var

var A_arbace_j2g_model__init_A_const_143 any

var A_arbace_j2g_model__init_A_const_144 *lang.Var

var A_arbace_j2g_model__init_A_const_145 any

var A_arbace_j2g_model__init_A_const_146 *lang.Var

var A_arbace_j2g_model__init_A_const_147 any

var A_arbace_j2g_model__init_A_const_148 *lang.Var

var A_arbace_j2g_model__init_A_const_149 any

var A_arbace_j2g_model__init_A_const_150 *lang.Var

var A_arbace_j2g_model__init_A_const_151 any

var A_arbace_j2g_model__init_A_const_152 *lang.Var

var A_arbace_j2g_model__init_A_const_153 any

var A_arbace_j2g_model__init_A_const_154 any

var A_arbace_j2g_model__init_A_const_155 *lang.Var

var A_arbace_j2g_model__init_A_const_156 any

var A_arbace_j2g_model__init_A_const_157 *lang.Var

var A_arbace_j2g_model__init_A_const_158 any

var A_arbace_j2g_model__init_A_const_159 any

var A_arbace_j2g_model__init_A_const_160 *lang.Var

var A_arbace_j2g_model__init_A_const_161 *lang.Var

var A_arbace_j2g_model__init_A_const_162 any

var A_arbace_j2g_model__init_A_const_163 any

var A_arbace_j2g_model__init_A_const_164 *lang.Var

var A_arbace_j2g_model__init_A_const_165 any

var A_arbace_j2g_model__init_A_init jrt.ClassInit

func A_arbace_j2g_model__init_A_Init() { if !A_arbace_j2g_model__init_A_init.Done() { A_arbace_j2g_model__init_A_init.Run(A_arbace_j2g_model__init_A_clinit) } }

func A_arbace_j2g_model__init_A_clinit() { A_arbace_j2g_model__init_A_clinit_p0(); A_arbace_j2g_model__init_A_clinit_p1(); A_arbace_j2g_model__init_A_clinit_p2(); A_arbace_j2g_model__init_A_clinit_p3(); A_arbace_j2g_model__init_A_clinit_p4(); A_arbace_j2g_model__init_A_clinit_p5(); A_arbace_j2g_model__init_A_clinit_p6(); A_arbace_j2g_model__init_A_clinit_p7(); A_arbace_j2g_model__init_A_clinit_p8(); A_arbace_j2g_model__init_A_clinit_p9(); A_arbace_j2g_model__init_A_clinit_p10(); A_arbace_j2g_model__init_A_clinit_p11(); A_arbace_j2g_model__init_A_clinit_p12() }

func A_arbace_j2g_model__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_81, 211); A_arbace_j2g_model__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[45]); A_arbace_j2g_model__init_A_const_1 = A_arbace_j2g_model__init_A_const_pool.A[46]; A_arbace_j2g_model__init_A_const_2 = A_arbace_j2g_model__init_A_const_pool.A[47]; A_arbace_j2g_model__init_A_const_3 = A_arbace_j2g_model__init_A_const_pool.A[48]; A_arbace_j2g_model__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[49]); A_arbace_j2g_model__init_A_const_5 = A_arbace_j2g_model__init_A_const_pool.A[50]; A_arbace_j2g_model__init_A_const_6 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[51]); A_arbace_j2g_model__init_A_const_7 = A_arbace_j2g_model__init_A_const_pool.A[52]; A_arbace_j2g_model__init_A_const_8 = A_arbace_j2g_model__init_A_const_pool.A[53]; A_arbace_j2g_model__init_A_const_9 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[54]); A_arbace_j2g_model__init_A_const_10 = A_arbace_j2g_model__init_A_const_pool.A[55]; A_arbace_j2g_model__init_A_const_11 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[56]); A_arbace_j2g_model__init_A_const_12 = A_arbace_j2g_model__init_A_const_pool.A[57] }

func A_arbace_j2g_model__init_A_clinit_p1() { A_arbace_j2g_model__init_A_const_13 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[58]); A_arbace_j2g_model__init_A_const_14 = A_arbace_j2g_model__init_A_const_pool.A[59]; A_arbace_j2g_model__init_A_const_15 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[60]); A_arbace_j2g_model__init_A_const_16 = A_arbace_j2g_model__init_A_const_pool.A[61]; A_arbace_j2g_model__init_A_const_17 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[62]); A_arbace_j2g_model__init_A_const_18 = A_arbace_j2g_model__init_A_const_pool.A[63]; A_arbace_j2g_model__init_A_const_19 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[64]); A_arbace_j2g_model__init_A_const_20 = A_arbace_j2g_model__init_A_const_pool.A[65]; A_arbace_j2g_model__init_A_const_21 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[66]); A_arbace_j2g_model__init_A_const_22 = A_arbace_j2g_model__init_A_const_pool.A[67]; A_arbace_j2g_model__init_A_const_23 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[68]); A_arbace_j2g_model__init_A_const_24 = A_arbace_j2g_model__init_A_const_pool.A[69]; A_arbace_j2g_model__init_A_const_25 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[70]) }

func A_arbace_j2g_model__init_A_clinit_p2() { A_arbace_j2g_model__init_A_const_26 = A_arbace_j2g_model__init_A_const_pool.A[71]; A_arbace_j2g_model__init_A_const_27 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[72]); A_arbace_j2g_model__init_A_const_28 = A_arbace_j2g_model__init_A_const_pool.A[73]; A_arbace_j2g_model__init_A_const_29 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[74]); A_arbace_j2g_model__init_A_const_30 = A_arbace_j2g_model__init_A_const_pool.A[75]; A_arbace_j2g_model__init_A_const_31 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[76]); A_arbace_j2g_model__init_A_const_32 = A_arbace_j2g_model__init_A_const_pool.A[77]; A_arbace_j2g_model__init_A_const_33 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[78]); A_arbace_j2g_model__init_A_const_34 = A_arbace_j2g_model__init_A_const_pool.A[79]; A_arbace_j2g_model__init_A_const_35 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[80]); A_arbace_j2g_model__init_A_const_36 = A_arbace_j2g_model__init_A_const_pool.A[81]; A_arbace_j2g_model__init_A_const_37 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[82]); A_arbace_j2g_model__init_A_const_38 = A_arbace_j2g_model__init_A_const_pool.A[83] }

func A_arbace_j2g_model__init_A_clinit_p3() { A_arbace_j2g_model__init_A_const_39 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[84]); A_arbace_j2g_model__init_A_const_40 = A_arbace_j2g_model__init_A_const_pool.A[85]; A_arbace_j2g_model__init_A_const_41 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[86]); A_arbace_j2g_model__init_A_const_42 = A_arbace_j2g_model__init_A_const_pool.A[87]; A_arbace_j2g_model__init_A_const_43 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[88]); A_arbace_j2g_model__init_A_const_44 = A_arbace_j2g_model__init_A_const_pool.A[89]; A_arbace_j2g_model__init_A_const_45 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[90]); A_arbace_j2g_model__init_A_const_46 = A_arbace_j2g_model__init_A_const_pool.A[91]; A_arbace_j2g_model__init_A_const_47 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[92]); A_arbace_j2g_model__init_A_const_48 = A_arbace_j2g_model__init_A_const_pool.A[93]; A_arbace_j2g_model__init_A_const_49 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[94]); A_arbace_j2g_model__init_A_const_50 = A_arbace_j2g_model__init_A_const_pool.A[95]; A_arbace_j2g_model__init_A_const_51 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[96]) }

func A_arbace_j2g_model__init_A_clinit_p4() { A_arbace_j2g_model__init_A_const_52 = A_arbace_j2g_model__init_A_const_pool.A[97]; A_arbace_j2g_model__init_A_const_53 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[98]); A_arbace_j2g_model__init_A_const_54 = A_arbace_j2g_model__init_A_const_pool.A[99]; A_arbace_j2g_model__init_A_const_55 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[100]); A_arbace_j2g_model__init_A_const_56 = A_arbace_j2g_model__init_A_const_pool.A[101]; A_arbace_j2g_model__init_A_const_57 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[102]); A_arbace_j2g_model__init_A_const_58 = A_arbace_j2g_model__init_A_const_pool.A[103]; A_arbace_j2g_model__init_A_const_59 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[104]); A_arbace_j2g_model__init_A_const_60 = A_arbace_j2g_model__init_A_const_pool.A[105]; A_arbace_j2g_model__init_A_const_61 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[106]); A_arbace_j2g_model__init_A_const_62 = A_arbace_j2g_model__init_A_const_pool.A[107]; A_arbace_j2g_model__init_A_const_63 = A_arbace_j2g_model__init_A_const_pool.A[108]; A_arbace_j2g_model__init_A_const_64 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[109]) }

func A_arbace_j2g_model__init_A_clinit_p5() { A_arbace_j2g_model__init_A_const_65 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[110]); A_arbace_j2g_model__init_A_const_66 = A_arbace_j2g_model__init_A_const_pool.A[111]; A_arbace_j2g_model__init_A_const_67 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[112]); A_arbace_j2g_model__init_A_const_68 = A_arbace_j2g_model__init_A_const_pool.A[113]; A_arbace_j2g_model__init_A_const_69 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[114]); A_arbace_j2g_model__init_A_const_70 = A_arbace_j2g_model__init_A_const_pool.A[115]; A_arbace_j2g_model__init_A_const_71 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[116]); A_arbace_j2g_model__init_A_const_72 = A_arbace_j2g_model__init_A_const_pool.A[117]; A_arbace_j2g_model__init_A_const_73 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[118]); A_arbace_j2g_model__init_A_const_74 = A_arbace_j2g_model__init_A_const_pool.A[119]; A_arbace_j2g_model__init_A_const_75 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[120]); A_arbace_j2g_model__init_A_const_76 = A_arbace_j2g_model__init_A_const_pool.A[121]; A_arbace_j2g_model__init_A_const_77 = A_arbace_j2g_model__init_A_const_pool.A[122] }

func A_arbace_j2g_model__init_A_clinit_p6() { A_arbace_j2g_model__init_A_const_78 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[123]); A_arbace_j2g_model__init_A_const_79 = A_arbace_j2g_model__init_A_const_pool.A[124]; A_arbace_j2g_model__init_A_const_80 = A_arbace_j2g_model__init_A_const_pool.A[125]; A_arbace_j2g_model__init_A_const_81 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[126]); A_arbace_j2g_model__init_A_const_82 = A_arbace_j2g_model__init_A_const_pool.A[127]; A_arbace_j2g_model__init_A_const_83 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[128]); A_arbace_j2g_model__init_A_const_84 = A_arbace_j2g_model__init_A_const_pool.A[129]; A_arbace_j2g_model__init_A_const_85 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[130]); A_arbace_j2g_model__init_A_const_86 = A_arbace_j2g_model__init_A_const_pool.A[131]; A_arbace_j2g_model__init_A_const_87 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[132]); A_arbace_j2g_model__init_A_const_88 = A_arbace_j2g_model__init_A_const_pool.A[133]; A_arbace_j2g_model__init_A_const_89 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[134]); A_arbace_j2g_model__init_A_const_90 = A_arbace_j2g_model__init_A_const_pool.A[135] }

func A_arbace_j2g_model__init_A_clinit_p7() { A_arbace_j2g_model__init_A_const_91 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[136]); A_arbace_j2g_model__init_A_const_92 = A_arbace_j2g_model__init_A_const_pool.A[137]; A_arbace_j2g_model__init_A_const_93 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[138]); A_arbace_j2g_model__init_A_const_94 = A_arbace_j2g_model__init_A_const_pool.A[139]; A_arbace_j2g_model__init_A_const_95 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[140]); A_arbace_j2g_model__init_A_const_96 = A_arbace_j2g_model__init_A_const_pool.A[141]; A_arbace_j2g_model__init_A_const_97 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[142]); A_arbace_j2g_model__init_A_const_98 = A_arbace_j2g_model__init_A_const_pool.A[143]; A_arbace_j2g_model__init_A_const_99 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[144]); A_arbace_j2g_model__init_A_const_100 = A_arbace_j2g_model__init_A_const_pool.A[145]; A_arbace_j2g_model__init_A_const_101 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[146]); A_arbace_j2g_model__init_A_const_102 = A_arbace_j2g_model__init_A_const_pool.A[147]; A_arbace_j2g_model__init_A_const_103 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[148]) }

func A_arbace_j2g_model__init_A_clinit_p8() { A_arbace_j2g_model__init_A_const_104 = A_arbace_j2g_model__init_A_const_pool.A[149]; A_arbace_j2g_model__init_A_const_105 = A_arbace_j2g_model__init_A_const_pool.A[150]; A_arbace_j2g_model__init_A_const_106 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[151]); A_arbace_j2g_model__init_A_const_107 = A_arbace_j2g_model__init_A_const_pool.A[152]; A_arbace_j2g_model__init_A_const_108 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[153]); A_arbace_j2g_model__init_A_const_109 = A_arbace_j2g_model__init_A_const_pool.A[154]; A_arbace_j2g_model__init_A_const_110 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[155]); A_arbace_j2g_model__init_A_const_111 = A_arbace_j2g_model__init_A_const_pool.A[156]; A_arbace_j2g_model__init_A_const_112 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[157]); A_arbace_j2g_model__init_A_const_113 = A_arbace_j2g_model__init_A_const_pool.A[158]; A_arbace_j2g_model__init_A_const_114 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[159]); A_arbace_j2g_model__init_A_const_115 = A_arbace_j2g_model__init_A_const_pool.A[160]; A_arbace_j2g_model__init_A_const_116 = A_arbace_j2g_model__init_A_const_pool.A[161]; A_arbace_j2g_model__init_A_const_117 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[162]) }

func A_arbace_j2g_model__init_A_clinit_p9() { A_arbace_j2g_model__init_A_const_118 = A_arbace_j2g_model__init_A_const_pool.A[163]; A_arbace_j2g_model__init_A_const_119 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[164]); A_arbace_j2g_model__init_A_const_120 = A_arbace_j2g_model__init_A_const_pool.A[165]; A_arbace_j2g_model__init_A_const_121 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[166]); A_arbace_j2g_model__init_A_const_122 = A_arbace_j2g_model__init_A_const_pool.A[167]; A_arbace_j2g_model__init_A_const_123 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[168]); A_arbace_j2g_model__init_A_const_124 = A_arbace_j2g_model__init_A_const_pool.A[169]; A_arbace_j2g_model__init_A_const_125 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[170]); A_arbace_j2g_model__init_A_const_126 = A_arbace_j2g_model__init_A_const_pool.A[171]; A_arbace_j2g_model__init_A_const_127 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[172]); A_arbace_j2g_model__init_A_const_128 = A_arbace_j2g_model__init_A_const_pool.A[173]; A_arbace_j2g_model__init_A_const_129 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[174]); A_arbace_j2g_model__init_A_const_130 = A_arbace_j2g_model__init_A_const_pool.A[175] }

func A_arbace_j2g_model__init_A_clinit_p10() { A_arbace_j2g_model__init_A_const_131 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[176]); A_arbace_j2g_model__init_A_const_132 = A_arbace_j2g_model__init_A_const_pool.A[177]; A_arbace_j2g_model__init_A_const_133 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[178]); A_arbace_j2g_model__init_A_const_134 = A_arbace_j2g_model__init_A_const_pool.A[179]; A_arbace_j2g_model__init_A_const_135 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[180]); A_arbace_j2g_model__init_A_const_136 = A_arbace_j2g_model__init_A_const_pool.A[181]; A_arbace_j2g_model__init_A_const_137 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[182]); A_arbace_j2g_model__init_A_const_138 = A_arbace_j2g_model__init_A_const_pool.A[183]; A_arbace_j2g_model__init_A_const_139 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[184]); A_arbace_j2g_model__init_A_const_140 = A_arbace_j2g_model__init_A_const_pool.A[185]; A_arbace_j2g_model__init_A_const_141 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[186]); A_arbace_j2g_model__init_A_const_142 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[187]); A_arbace_j2g_model__init_A_const_143 = A_arbace_j2g_model__init_A_const_pool.A[188] }

func A_arbace_j2g_model__init_A_clinit_p11() { A_arbace_j2g_model__init_A_const_144 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[189]); A_arbace_j2g_model__init_A_const_145 = A_arbace_j2g_model__init_A_const_pool.A[190]; A_arbace_j2g_model__init_A_const_146 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[191]); A_arbace_j2g_model__init_A_const_147 = A_arbace_j2g_model__init_A_const_pool.A[192]; A_arbace_j2g_model__init_A_const_148 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[193]); A_arbace_j2g_model__init_A_const_149 = A_arbace_j2g_model__init_A_const_pool.A[194]; A_arbace_j2g_model__init_A_const_150 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[195]); A_arbace_j2g_model__init_A_const_151 = A_arbace_j2g_model__init_A_const_pool.A[196]; A_arbace_j2g_model__init_A_const_152 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[197]); A_arbace_j2g_model__init_A_const_153 = A_arbace_j2g_model__init_A_const_pool.A[198]; A_arbace_j2g_model__init_A_const_154 = A_arbace_j2g_model__init_A_const_pool.A[199]; A_arbace_j2g_model__init_A_const_155 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[200]); A_arbace_j2g_model__init_A_const_156 = A_arbace_j2g_model__init_A_const_pool.A[201] }

func A_arbace_j2g_model__init_A_clinit_p12() { A_arbace_j2g_model__init_A_const_157 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[202]); A_arbace_j2g_model__init_A_const_158 = A_arbace_j2g_model__init_A_const_pool.A[203]; A_arbace_j2g_model__init_A_const_159 = A_arbace_j2g_model__init_A_const_pool.A[204]; A_arbace_j2g_model__init_A_const_160 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[205]); A_arbace_j2g_model__init_A_const_161 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[206]); A_arbace_j2g_model__init_A_const_162 = A_arbace_j2g_model__init_A_const_pool.A[207]; A_arbace_j2g_model__init_A_const_163 = A_arbace_j2g_model__init_A_const_pool.A[208]; A_arbace_j2g_model__init_A_const_164 = lang.Var_Cast(A_arbace_j2g_model__init_A_const_pool.A[209]); A_arbace_j2g_model__init_A_const_165 = A_arbace_j2g_model__init_A_const_pool.A[210] }

func A_arbace_j2g_model__init_A_New() *A_arbace_j2g_model__init_A { A_arbace_j2g_model__init_A_Init(); t := &A_arbace_j2g_model__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model__init_A) Ctor() {}

func (t *A_arbace_j2g_model__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model__init_A_class }

func (t *A_arbace_j2g_model__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model__init_A); return ok }

func A_arbace_j2g_model__init_A_Cast(x any) *A_arbace_j2g_model__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model__init_A_class)) }; return v }
