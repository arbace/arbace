//line j2g_strings.ae:1
package aot_arbace_j2g_model

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.namesyn2,nmyn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.startyn5,startyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn1,Tkn11,jrt-classeskn5,flagskn7,methodskn10,interfaceskn4,elsekn6,erasedkn2,gokn14,subclass-indexkn5,superkn5,typeskn3,jrtkn4,castkn4,nullyn3,anykn4,descyn1,*kn6,fieldskn4,namekn5,funcskn5,ownerkn14,vmethods-cachekn4,kindkn6,objectkn6,methodkn8,jrt-implkn8,promotedkn5,classkn7,defaultks3,c2j4,codekn4,metakn13,trivial-cachekn5,statekn6,clinitkn10,clj-constskn11,uses-assertkn16,interface-assertkn6,bodieskn4,callkn8,prologuekn11,nested-callkn4,argskn4,ctorkn4,initkn4,bodykn2,opkn7,convertkn4,fromkn2,tokn4,exprkn9,set-fieldkn9,this-pathkn6,targetkn4,pathkn3,valkn6,invokekn6,statickn10,set-statickn8,declarerkn5,fieldkn3,letkn8,bindingskn10,get-statickn2,dokn10,statementskn3,retkn5,constkn5,localkn9,new-arraykn4,dimskn3,newkn5,outerkn5,arithkn3,remkn3,divkn1,okn5,exactkn6,familykn9,class-litkn10,array-initkn5,elemskn6,benignv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,v11,arbace.core5,referR17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.modelm2,R18,s252,The closed world of one j2g run (J2G-SPEC §4.1, §5): which classes exist in Go (translated\n  ones, T, and jrt's hand-written ones, H), leaf classes (§5.3), the Go type of a Java type\n  (§5.1), virtual method sets and their implementations (§5.4, §5.5).v11,arbace.core3,seqv16,arbace.j2g.model12,default-jobsv11,arbace.core3,vecv11,arbace.core5,rangev11,arbace.core4,mapvv11,arbace.core4,peekv11,arbace.core11,future-callv11,arbace.core4,atoml-1,v11,arbace.core5,swap!v11,arbace.core3,incv11,arbace.core5,doallv11,arbace.core10,repeatedlyv11,arbace.core4,run!v11,arbace.core3,notl0,R19,v16,arbace.j2g.model3,*w*v11,arbace.core9,contains?v16,arbace.j2g.model1,Tv16,arbace.j2g.model11,translated?R20,v16,arbace.j2g.model9,jrt-classv22,arbace.classes.analyze4,declv13,arbace.string12,starts-with?v13,arbace.string9,includes?v11,arbace.core5,some?v18,arbace.classes.env4,infov18,arbace.classes.env10,interface?v16,arbace.j2g.model4,has?R21,l8192,v11,arbace.core6,empty?R22,v11,arbace.core6,every?v16,arbace.j2g.model9,in-world?v16,arbace.j2g.model22,reflectable-interface?R23,v11,arbace.core8,keyword?v20,arbace.classes.types6,array?v16,arbace.j2g.model12,desc-classesv11,arbace.core4,subsv20,arbace.classes.types10,array-dimsv20,arbace.classes.types11,class-desc?R24,v20,arbace.classes.types14,desc->internalv11,arbace.core7,string?v16,arbace.j2g.model13,mdesc-classesv20,arbace.classes.types17,parse-method-descv11,arbace.core6,mapcatv11,arbace.core4,consv20,arbace.classes.types9,elem-typev11,arbace.core4,someR25,v16,arbace.j2g.model19,method-desc-classesR26,v16,arbace.j2g.names13,go-class-namev16,arbace.j2g.names6,pkg-ofv16,arbace.j2g.model4,infoi1024,i16,R27,v11,arbace.core6,reset!v11,arbace.core6,reduceR28,v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core6,concatv11,arbace.core4,keysv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv16,arbace.j2g.model10,interface?v16,arbace.j2g.model13,hand-written?R29,R30,v16,arbace.j2g.model7,go-namev16,arbace.j2g.model9,abstract?v16,arbace.j2g.model10,subclassesv16,arbace.j2g.model12,proxy-super?v16,arbace.j2g.model6,final?v11,arbace.core6,symbolv16,arbace.j2g.names8,pkg-namev16,arbace.j2g.model7,qualifyv16,arbace.j2g.model3,pkgv16,arbace.j2g.model9,class-symR31,v20,arbace.classes.types5,prim?v11,arbace.core4,listv16,arbace.j2g.model7,jrt-symv16,arbace.j2g.model13,prim-array-goR32,R33,v16,arbace.j2g.model7,prim-goR33,R33,v16,arbace.j2g.model5,leaf?v11,arbace.core7,ex-infov11,arbace.core6,pr-strR34,R35,R35,R35,v11,arbace.core4,not=v20,arbace.classes.types4,ref?v16,arbace.j2g.model13,pointer-desc?i8,i2,R36,R37,v16,arbace.j2g.model10,methods-ofv16,arbace.j2g.model7,static?v16,arbace.j2g.model8,private?v11,arbace.core6,removev11,arbace.core4,nil?v11,arbace.core6,filterv16,arbace.j2g.model10,supertypesv18,arbace.classes.env14,all-supertypesv16,arbace.j2g.names11,method-basev16,arbace.j2g.model11,object-keysv14,arbace.j2g.jrt13,iface-methodsR38,v14,arbace.j2g.jrt14,struct-methodsv16,arbace.j2g.names9,impl-namev16,arbace.j2g.model11,j2g-method?S2,s16,Chars__IntStreams21,CodePoints__IntStreamv16,arbace.j2g.model15,mdesc-in-world?v16,arbace.j2g.model17,hw-method-exists?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv16,arbace.j2g.model15,virtual-member?v16,arbace.j2g.model16,member-in-world?v11,arbace.core12,chunk-appendv11,arbace.core5,assocR39,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,restR40,v16,arbace.j2g.model17,declared-vmethodsv11,arbace.core9,array-mapv16,arbace.j2g.model14,all-supertypesv16,arbace.j2g.model14,java-type-namem18,s1,Js4,longs1,Ss5,shorts1,Zs7,booleans1,Cs4,chars1,Fs5,floats1,Bs4,bytes1,Vs4,voids1,Is3,ints1,Ds6,doublev13,arbace.string7,replacev13,arbace.string4,joinv11,arbace.core3,mapv11,arbace.core10,take-whilev11,arbace.core7,iteratev16,arbace.j2g.model11,find-methodv16,arbace.j2g.model11,abstract-m?R41,R42,R43,R44,R45,R46,v16,arbace.j2g.model16,superclass-chainR47,v18,arbace.classes.env9,subclass?R48,R49,v11,arbace.core10,re-matchesp32,arbace/lang/Compiler\\$AOT[FR]\\d+i512,v11,arbace.core8,distinctv16,arbace.j2g.model13,trivial-init?R50,R51,R52,R53,R54,R55,v16,arbace.j2g.model20,init-superinterfacesv16,arbace.j2g.names8,pkg-pathv16,arbace.j2g.model11,start-namesv16,arbace.j2g.model17,go-qualified-namev11,arbace.core4,intov16,arbace.j2g.model12,start-class?v11,arbace.core4,keepv16,arbace.j2g.start7,classesR56,v16,arbace.j2g.model9,top-classR57,R58,R59,v16,arbace.j2g.model10,pure-node?R60,S3,s16,java/lang/Records14,java/lang/Enums16,java/lang/Objectv16,arbace.j2g.model10,pure-ctor?R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,R86,R87,v11,arbace.core7,number?R88,R89,R90,R91,S2,R92,R93,R94,R95,R96,R97,R98,R99,v16,arbace.j2g.model12,benign-init?R100,v16,arbace.j2g.model18,runtime-exec-descsv16,arbace.j2g.model20,support-call-helpersv16,arbace.j2g.model13,translatable?")

var Lit_1 *jrt.String = jrt.Intern("/")

var Lit_2 *jrt.String = jrt.Intern(".")

var Lit_3 *jrt.String = jrt.Intern(", ")

var Lit_4 *jrt.String = jrt.Intern(" of ")

var Lit_5 *jrt.String = jrt.Intern("interface ")

var Lit_6 *jrt.String = jrt.Intern("abstract class ")

var Lit_7 *jrt.String = jrt.Intern("_Cast")

var Lit_8 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_9 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_10 *jrt.String = jrt.Intern("ObjectArray")

var Lit_11 *jrt.String = jrt.Intern("RefArray")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.model$benign_init_QMARK_$fn__1479000211")

var Lit_13 *jrt.String = jrt.Intern("")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods$iter__1479000090__1479000094")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods$iter__1479000090__1479000094$fn__1479000095")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods$iter__1479000090__1479000094$fn__1479000095$fn__1479000096")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.model$erased_desc_QMARK_$fn__1479000047")

var Lit_18 *jrt.String = jrt.Intern("arbace.j2g.model$erased_desc_QMARK_$fn__1479000049")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.model$find_method$fn__1479000080")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000218$iter__1479000214__1479000219")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000218$iter__1479000214__1479000219$fn__1479000220")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000218$iter__1479000214__1479000219$fn__1479000220$fn__1479000221")

var Lit_23 *jrt.String = jrt.Intern("java/lang/Runtime")

var Lit_24 *jrt.String = jrt.Intern("exec")

var Lit_25 *jrt.String = jrt.Intern("J2g_Runtime")

var Lit_26 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_27 *jrt.String = jrt.Intern("V")

var Lit_28 *jrt.String = jrt.Intern("_I")

var Lit_29 *jrt.String = jrt.Intern("j2g: no Go type for ")

var Lit_30 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_31 *jrt.String = jrt.Intern("_")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$fn__1479000124")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$iter__1479000126__1479000130")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$fn__1479000136")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$fn__1479000136$fn__1479000137")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$iter__1479000126__1479000130$fn__1479000131")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$iter__1479000126__1479000130$fn__1479000131$fn__1479000132")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$declares_default_QMARK___1479000145")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$walk__1479000149")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$iter__1479000151__1479000155")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$declares_default_QMARK___1479000145$fn__1479000146")

var Lit_42 *jrt.String = jrt.Intern("<clinit>")

var Lit_43 *jrt.String = jrt.Intern("<init>")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$iter__1479000151__1479000155$fn__1479000156")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$iter__1479000151__1479000155$fn__1479000156$fn__1479000157")

var Lit_46 *jrt.String = jrt.Intern("java/lang/String")

var Lit_47 *jrt.String = jrt.Intern("java/lang/CharSequence")

var Lit_48 *jrt.String = jrt.Intern("java/util/stream/IntStream")

var Lit_49 *jrt.String = jrt.Intern("java/lang/System")

var Lit_50 *jrt.String = jrt.Intern("GetProperties__Properties")

var Lit_51 *jrt.String = jrt.Intern("java/util/Properties")

var Lit_52 *jrt.String = jrt.Intern("[]")

var Lit_53 *jrt.String = jrt.Intern("J2G_JOBS")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index$fn__1479000059")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index$fn__1479000059$fn__1479000060")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index$fn__1479000059$fn__1479000060$fn__1479000061")

var Lit_57 *jrt.String = jrt.Intern("$")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$fn__1479000017")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$work__1479000019")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$fn__1479000021")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$fn__1479000021$fn__1479000022")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.model$pure_ctor_QMARK_$fn__1479000179")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.model$pure_ctor_QMARK_$fn__1479000181")

var Lit_64 *jrt.String = jrt.Intern("java/lang/Class")

var Lit_65 *jrt.String = jrt.Intern("getPrimitiveClass")

var Lit_66 *jrt.String = jrt.Intern("$values")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000191")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000194")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000199")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000201")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000203")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000205")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000207")

var Lit_74 *jrt.String = jrt.Intern("java/")

var Lit_75 *jrt.String = jrt.Intern("javax/")

var Lit_76 *jrt.String = jrt.Intern("jdk/")

var Lit_77 *jrt.String = jrt.Intern("sun/")

var Lit_78 *jrt.String = jrt.Intern("com/sun/")

var Lit_79 *jrt.String = jrt.Intern("$$")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.model$reflectable_interface_QMARK_$fn__1479000035")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes$iter__1479000165__1479000169")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes$iter__1479000165__1479000169$fn__1479000170")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes$iter__1479000165__1479000169$fn__1479000170$fn__1479000171")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.model$superclass_chain$fn__1479000116")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.model$vmethods$fn__1479000101")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.model$vmethods$fn__1479000101$fn__1479000102")

var Lit_87 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,nyn1,fyn2,xsyn1,&yn5,orderyn5,flagsyn3,clsyn4,baseyn1,dkn3,tagkn7,privateyn4,descyn1,wyn4,fromyn2,ofyn5,identyn6,suffixyn4,boolyn4,int8yn6,uint16yn5,int16yn5,int32yn5,int64yn7,float32yn7,float64yn4,kindyn1,xyn4,compyn1,myn4,namekn8,declaredyn5,ownerkn2,asyn1,kyn6,Stringyn1,cyn4,seenyn4,nodev11,arbace.core5,in-nsMyn16,arbace.j2g.modelm2,R0,s252,The closed world of one j2g run (J2G-SPEC §4.1, §5): which classes exist in Go (translated\n  ones, T, and jrt's hand-written ones, H), leaf classes (§5.3), the Go type of a Java type\n  (§5.1), virtual method sets and their implementations (§5.4, §5.5).m2,R0,s252,The closed world of one j2g run (J2G-SPEC §4.1, §5): which classes exist in Go (translated\n  ones, T, and jrt's hand-written ones, H), leaf classes (§5.3), the Go type of a Java type\n  (§5.1), virtual method sets and their implementations (§5.4, §5.5).R1,v16,arbace.j2g.model3,*w*m10,R2,TR3,i14,R4,i1,R5,s19,arbace/j2g/model.aeR0,s88,The world: {:jrt scan :T atom-or-set :jrt-classes {internal {:go :var :standin :file}}}.v16,arbace.j2g.model12,default-jobsl16,m8,R3,i21,R4,i1,R5,s19,arbace/j2g/model.aeR0,s182,At most this many threads by default: on Go, 16 take 10 GB at most for the program, 64 take\n  12 GB (GOMEMLIMIT 12GiB) for 5% less time (doc/STANDALONE-NOTES.md, S4, amendment SA51).v16,arbace.j2g.model4,jobsm10,R6,L1,V0,R0,s102,How many threads translate and write: J2G_JOBS, else the number of processors, at most\n  default-jobs.R3,i26,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,par-mapvm10,R6,L1,V5,R7,R8,R9,R10,V1,R11,R0,s703,(mapv f xs), f applied on up to n threads, each taking the next element (in xs' order, or\n  in the order of the indices `order`: the longest first); the results in xs' order. f's\n  dynamic bindings are the caller's (future's conveyance). The last element in that order (the\n  shortest) first, alone, then the others: on a host whose evaluator compiles an evaluated fn's\n  method on its first call without a lock (a stage 0 older than 2026-10-18,\n  Compiler$CodeRun.cmethod), threads first calling one at once could read its analyzed tree's\n  lazy state torn (a NullPointerException in HashMap$EntrySet.iterator); that element compiles\n  the fns of its path alone (on a thread of its own, as the others).R3,i35,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model4,has?m8,R6,L1,V2,R12,R8,R3,i67,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model1,Tm8,R6,L1,V0,R3,i69,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,translated?m8,R6,L1,V1,R7,R3,i71,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,j2g-static?m10,R6,L1,V2,R13,R14,R0,s290,A static method of jrt's hand-written class cls (Go base name base) that j2g writes itself,\n  in the program's support code, because its type is a translated class jrt cannot name:\n  System.getProperties(), a Properties (out.ae; JRT-NOTES.md, \"Text and locales\":\n  StaticProperty reads it).R3,i73,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,jrt-classm10,R6,L1,V1,R7,R0,s89,jrt's hand-written (or stand-in) class n, when jrt defines it: {:go :var :standin :file}.R3,i82,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,hand-written?m10,R6,L1,V1,R7,R0,s67,Is n a class jrt provides and j2g does not translate in this world?R3,i87,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,in-world?m8,R6,L1,V1,R7,R3,i92,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,translatable?m10,R6,L1,V1,R7,R0,s67,Is n in the class environment as Java forms (j2g can translate it)?R3,i95,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model22,reflectable-interface?m10,R6,L1,V1,R7,R0,s184,Is n a JDK interface j2g knows only by reflection (no Java forms: outside the converted\n  closure), which it may declare: its methods, no code (J2G-NOTES.md, \"Reflected\n  interfaces\")?R3,i100,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,reflected?m10,R6,L1,V1,R7,R0,s65,Is n a translated class declared from reflection (no Java forms)?R3,i118,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model4,infom8,R6,L1,V1,R7,R3,i123,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,interface?m8,R6,L1,V1,R7,R3,i124,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,desc-classesm10,R6,L1,V1,R15,R0,s67,The classes a descriptor mentions (array element classes included).R3,i126,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,mdesc-classesm12,R16,C38,java.util.concurrent.ConcurrentHashMapR17,TR3,i135,R4,i1,R5,s19,arbace/j2g/model.aeR0,s89,Method descriptor -> method-desc-classes' answer (asked for every call, by every thread).v16,arbace.j2g.model19,method-desc-classesm8,R6,L1,V1,R18,R3,i139,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,erased-desc?m10,R6,L1,V1,R15,R0,s255,Is d a class outside the world in a package a variant erases (j2g/erase), or an array of\n  one? Values of such types exist only to feed what the Go build cuts (the bytecode back end):\n  an operation producing one is the zero value (proposed amendment B2).R3,i146,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model14,desc-in-world?m8,R6,L1,V1,R15,R3,i158,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model15,mdesc-in-world?m8,R6,L1,V1,R18,R3,i159,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,go-namem10,R6,L1,V1,R7,R0,s263,The Go type name of class n: jrt's own name for a class jrt provides and j2g does not\n  translate (a jrt class may register a JDK name under another Go name: ReentrantLock's\n  condition is AbstractQueuedSynchronizer$ConditionObject), else the name derived from n.R3,i164,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model3,pkgm8,R6,L1,V1,R7,R3,i173,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,abstract?m8,R6,L1,V1,R7,R3,i175,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model6,final?m8,R6,L1,V1,R7,R3,i176,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,subclassesm10,R6,L1,V1,R7,R0,s63,Direct subclasses of class n in the world (memoized per world).R3,i178,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model19,make-subclass-indexm8,R6,L1,V1,R19,R3,i183,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,proxy-supersV9,s14,java/io/Writers14,java/io/Readers22,java/io/PushbackReaders19,java/io/InputStreams20,java/io/OutputStreams26,arbace/lang/APersistentMaps22,java/io/BufferedWriters21,java/lang/ThreadLocals16,java/util/BitSetm8,R3,i194,R4,i1,R5,s19,arbace/j2g/model.aeR0,s211,The classes besides Object that a proxy may extend in the Go build (§5.12, arbace.j2g.dyn):\n  each gets a Go type DynSub_C, a subclass of C in the world, so a translated class of the list\n  is not a leaf (§5.3).v16,arbace.j2g.model12,class-supersV62,s19,java/lang/Throwables19,java/lang/Exceptions26,java/lang/RuntimeExceptions15,java/lang/Errors34,java/lang/IllegalArgumentExceptions31,java/lang/IllegalStateExceptions14,java/lang/Enums16,java/lang/Records15,arbace/lang/AFns16,java/lang/Threads26,java/io/FilterOutputStreams23,java/io/FileInputStreams17,java/util/HashMaps16,java/util/Vectors20,java/util/LinkedLists18,java/util/TimeZones25,java/net/URLStreamHandlers17,java/lang/Processs19,java/net/SocketImpls25,java/io/FilterInputStreams28,java/util/AbstractCollections22,java/util/AbstractLists21,java/util/AbstractMaps32,java/util/AbstractSequentialLists21,java/util/AbstractSets53,java/util/concurrent/locks/AbstractQueuedSynchronizers18,java/util/Calendars19,java/util/ArrayLists23,java/util/LinkedHashMaps23,java/util/LinkedHashSets25,java/util/IdentityHashMaps23,java/util/PriorityQueues28,java/io/ByteArrayInputStreams20,java/io/StringWriters12,java/io/Files24,java/lang/AssertionErrors20,java/math/BigIntegers27,java/text/DateFormatSymbolss27,java/util/concurrent/Phasers48,java/util/concurrent/ScheduledThreadPoolExecutors22,java/util/zip/Deflaters22,java/util/zip/Inflaters19,java/io/PrintStreams19,java/io/PrintWriters24,java/io/DataOutputStreams20,java/util/Observables27,java/util/GregorianCalendars42,java/util/concurrent/ConcurrentSkipListMaps17,java/util/TreeMaps17,java/util/TreeSets29,java/io/ByteArrayOutputStreams57,java/util/concurrent/locks/AbstractQueuedLongSynchronizers42,java/util/concurrent/ConcurrentSkipListSets30,java/util/zip/GZIPOutputStreams27,java/lang/ref/WeakReferences27,java/lang/ref/SoftReferences32,java/lang/InheritableThreadLocals43,java/util/concurrent/atomic/AtomicReferences40,java/util/concurrent/CopyOnWriteArraySets41,java/util/concurrent/CopyOnWriteArrayLists36,java/util/concurrent/RecursiveActions34,java/util/concurrent/RecursiveTaskm8,R3,i207,R4,i1,R5,s19,arbace/j2g/model.aeR0,s390,The classes besides proxy-supers that the classes of Java forms made at the REPL may extend\n  (doc/go/CLASSFORMS-REPL.md; arbace.j2g.dyn/class-supers): each gets its DynSub_C as the\n  proxies' superclasses do, so a translated one is not a leaf either (§5.3). Since JC4b the\n  superclasses jdk26u's tests extend (doc/classes/JAVA-CONFORMANCE-SURVEY.md, \"As built: JC4b\",\n  \"As built: JC4c\").v16,arbace.j2g.model12,proxy-super?v11,arbace.core3,setv11,arbace.core6,concatm8,R17,TR3,i240,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model5,leaf?m10,R6,L1,V1,R7,R0,s231,Is class n a leaf (§5.3): its values are *C pointers. Interfaces are not; jrt's classes are\n  leaves when jrt gives them no class interface C_I; a translated class of proxy-supers or\n  class-supers is not (its DynSub_C extends it).R3,i242,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,qualifym10,R6,L1,V3,R20,R21,R22,R0,s83,A Go identifier of package `of` (:jrt or :lang) as referred to from package `from`.R3,i257,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,class-symm10,R6,L2,V2,R20,R7,V3,R20,R7,R23,R0,s91,The Go identifier `suffix` of class n (\"\" for the type itself), as referred to from `from`.R3,i262,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,jrt-symm8,R6,L1,V2,R20,R22,R3,i267,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,prim-gom16,s1,ZR24,s1,BR25,s1,CR26,s1,SR27,s1,IR28,s1,JR29,s1,FR30,s1,DR31,m6,R3,i269,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,prim-array-gom16,s1,Zs12,BooleanArrays1,Bs9,ByteArrays1,Cs9,CharArrays1,Ss10,ShortArrays1,Is8,IntArrays1,Js9,LongArrays1,Fs10,FloatArrays1,Ds11,DoubleArraym6,R3,i271,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,array-testm10,R6,L1,V5,R20,R32,R33,R15,R34,R0,s402,checkcast (kind :cast) or instanceof (:instance) of array type d on x, an any, in package\n  `from` (J2G-SPEC §5.7, §5.9): jrt's type switch on the array's Go type, a primitive array's\n  `jrt.IntArray_Cast` and kin, Object[]'s `jrt.ObjectArray_Cast`, another reference array's\n  `jrt.RefArray_Cast` with comp, the form of the component class (Class.isInstance only where the\n  component classes differ).R3,i274,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,go-typem10,R6,L1,V2,R20,R15,R0,s58,The Go type form of descriptor d in package `from` (§5.1).R3,i288,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,pointer-desc?m10,R6,L1,V1,R15,R0,s58,Is the Go type of d a pointer (leaf class, String, array)?R3,i309,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,iface-desc?m10,R6,L1,V1,R15,R0,s47,Is the Go type of d an interface (any, C_I, J)?R3,i318,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,static?m8,R6,L1,V1,R35,R3,i326,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,private?m8,R6,L1,V1,R35,R3,i327,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,abstract-m?m8,R6,L1,V1,R35,R3,i328,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,methods-ofm8,R6,L1,V1,R7,R3,i330,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,fields-ofm8,R6,L1,V1,R7,R3,i331,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,find-methodm8,R6,L1,V3,R7,R36,R18,R3,i333,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model15,virtual-member?m10,R6,L1,V1,R35,R0,s89,A method that takes part in dispatch: an instance method, not private, not a constructor.R3,i336,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,object-keysS5,V2,s8,getClasss19,()Ljava/lang/Class;V2,s8,toStrings20,()Ljava/lang/String;V2,s5,clones20,()Ljava/lang/Object;V2,s6,equalss21,(Ljava/lang/Object;)ZV2,s8,hashCodes3,()Im8,R3,i341,R4,i1,R5,s19,arbace/j2g/model.aeR0,s61,Object's methods every class has through jrt.Object_I (§5.8).v16,arbace.j2g.model10,supertypesm8,R6,L1,V1,R7,R3,i346,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model16,world-supertypesm10,R6,L1,V1,R7,R0,s83,n's supertypes that exist in the world (interfaces that do not are left out, §4.1).R3,i349,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model14,all-supertypesm10,R6,L1,V1,R7,R0,s196,n and its supertypes that exist in the world, superclass chain first then interfaces\n  (Java's supertypes: an interface in the world counts also when it is reached only through\n  one that is not).R3,i354,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,j2g-method?m8,R37,TR3,i361,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model17,hw-method-exists?m10,R6,L1,V2,R7,R35,R0,s77,Does jrt's hand-written class or interface n have method m (name desc) in Go?R3,i363,R4,i1,R5,s19,arbace/j2g/model.aem10,R6,L1,V2,R7,R14,R0,s385,An instance method of jrt's hand-written class n (Go base name base) that the program's\n  support code has, though jrt does not: String's chars() and codePoints(), the default methods\n  of CharSequence (translated), which j2g forwards to on the classes jrt writes that implement\n  it (JRT-NOTES.md, \"Text and locales\": CompactNumberFormat and java.time's text call them on\n  a String).R3,i378,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model16,member-in-world?m10,R6,L1,V2,R7,R35,R0,s103,Does method m of class n exist in Go: its descriptor's classes exist, and for a jrt class\n  jrt has it.R3,i388,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model17,declared-vmethodsm10,R6,L1,V1,R7,R0,s64,The virtual methods n declares that exist in Go, by [name desc].R3,i395,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,vmethodsm10,R6,L1,V1,R7,R0,s188,Every virtual method of n (declared and inherited, abstract or not), in the world, Object's\n  excluded: an ordered map [name desc] -> method (the most specific declaration: classes first).R3,i403,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model14,java-type-namem10,R6,L1,V1,R15,R0,s62,The Java name of descriptor d (int, java.lang.Object, byte[]).R3,i420,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model26,abstract-method-error-textm10,R6,L1,V3,R7,R38,V2,R36,R18,R0,s188,HotSpot's message of the AbstractMethodError of method k = [name desc] (declared in owner, an\n  interface or an abstract class) called on an object of class n, which does not implement it.R3,i428,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model16,superclass-chainm8,R6,L1,V1,R7,R3,i437,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,impl-ofm10,R6,L1,V2,R7,V4,R36,R18,R39,R40,R0,s339,The implementation of virtual method k = [name desc] for class n: {:kind :class :owner c\n  :method m} for a method with a body in n or a superclass (a jrt class's: :jrt-impl when jrt\n  has Impl_, :promoted when the method itself is on its struct), {:kind :default :owner j\n  :method m} for an interface's default method, or nil (abstract).R3,i440,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,code-class?m10,R6,L1,V1,R7,R0,s488,Is class n a compiled fn's code (standalone S6, :c2j/code; SA156)? Not a Java object in Go:\n  it implements its arities' interfaces (code-iface?) and nothing of Object's protocol, which\n  its fn (Compiler$AOTFn) answers; its struct starts with a header word that stays zero (so\n  that jrt.IsDynamic reads it as any object's). Its allocation initializes its nest's\n  top-level class (its namespace's holder, whose constants its code reads), so that its code\n  reads them unguarded (SA158).R3,i471,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,code-iface?m10,R6,L1,V1,Myn1,nm2,R16,R41,R0,s163,Is interface n a compiled fn's arity, Compiler$AOTF<n> or $AOTR<n> (SA156): its Go interface\n  does not embed jrt.Object_I, so that code-class? types implement it.R3,i481,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,nest-topm10,R6,L1,V1,Myn1,nm2,R16,R41,R0,s75,The top-level class of class n's nest (internal names: before the first $).R3,i487,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,trivial-init?m8,R37,TR3,i492,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model20,init-superinterfacesm10,R6,L1,V1,R7,R0,s283,The superinterfaces of class n initialized with it (JLS 12.4.2 step 7: those that declare a\n  default method, each direct superinterface's superinterfaces before it, in the order of the\n  declaration's lists), translated with non-trivial initialization; none for an interface (JC4b).R3,i494,R4,i1,R5,s19,arbace/j2g/model.aem10,R6,L1,V1,R7,R0,s226,Does class n have trivial initialization (§6.2): no static initializer code, no\n  non-constant static field initializer, a superclass with trivial initialization? jrt's\n  classes count as trivial (jrt initializes them itself).R3,i513,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model17,go-qualified-namem10,R6,L1,V1,R7,R0,s133,Class n's Go name with its package's path (arbace/lang.Util), as jrt's trace of class\n  initialization prints it (ARBACE_TRACE_INIT).R3,i538,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,start-namesv16,arbace.j2g.start7,classesm10,R17,TR3,i544,R4,i1,R5,s19,arbace/j2g/model.aeR0,s51,The Go names of arbace.j2g.start/classes, as a set.v16,arbace.j2g.model12,start-class?m10,R6,L1,V1,R7,R0,s133,Is n one of the classes initialized at start (arbace.j2g.start/classes) in this world:\n  translated, with non-trivial initialization?R3,i548,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,start-classesm10,R6,L1,V0,R0,s91,The classes initialized at start in this world (start-class?), in arbace.j2g.start's order.R3,i555,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,pure-node?m8,R37,TR3,i564,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,top-classm10,R17,TR6,L1,V1,Myn1,nm2,R16,R41,R3,i566,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,pure-ctor?m12,R17,TR6,L1,V4,R7,R42,R35,R43,R0,s210,Is constructor m of class c (in the file of class n) free of effects beyond its object's\n  fields: field stores of pure values on this, a super or this constructor call that is pure\n  too (Object's at the end)?R3,i568,R4,i1,R5,s19,arbace/j2g/model.aem12,R17,TR6,L1,V3,R7,R44,R43,R0,s152,Can node, run inside the static initializer of class n, neither be observed outside n's\n  statics and new objects nor throw (bar running out of memory)?R3,i591,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,benign-init?m10,R6,L1,V1,R7,R0,s392,Is class n's initialization unobservable but through n's own static fields: trivial, or a\n  static initializer that only stores pure values (constants, arrays, n's own objects built by\n  pure constructors) into n's statics, over a superclass whose initialization is benign too?\n  Then a static method of n that reads no static field of n needs no initialization guard\n  (J2G-NOTES, phase 2D).R3,i618,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model18,runtime-exec-descsV6,s39,(Ljava/lang/String;)Ljava/lang/Process;s58,(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s72,(Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;s40,([Ljava/lang/String;)Ljava/lang/Process;s59,([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s73,([Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;m8,R3,i642,R4,i1,R5,s19,arbace/j2g/model.aeR0,s104,Runtime.exec's six overloads (jrt's own Java jdk.internal.jrt.RuntimeExec: JRT-NOTES.md,\n  \"Processes\").v16,arbace.j2g.model20,support-call-helpersv11,arbace.core4,intom8,V3,s19,java/lang/Throwables15,printStackTraces24,(Ljava/io/PrintWriter;)VV2,s25,J2g_PrintStackTraceWriters19,java/io/PrintWriterV3,s19,java/lang/Throwables15,printStackTraces24,(Ljava/io/PrintStream;)VV2,s25,J2g_PrintStackTraceStreams19,java/io/PrintStreamV3,s14,java/util/Dates9,toInstants21,()Ljava/time/Instant;V2,s17,J2g_DateToInstants17,java/time/InstantV3,s14,java/util/Dates4,froms37,(Ljava/time/Instant;)Ljava/util/Date;V2,s12,J2g_DateFroms17,java/time/Instantm8,R3,i652,R4,i1,R5,s19,arbace/j2g/model.aeR0,s701,The instance methods of jrt's hand-written classes that jrt cannot write itself, as they name\n  translated classes, by [owner name desc]: [support function, the translated class it needs].\n  Calls of them are translated to j2g's support function (out/support-forms), the receiver\n  first, as the REPL's reflection reaches them (out's init entries). Throwable's printStackTrace\n  to a PrintWriter or a PrintStream (javac's crash reports; doc/classes/JAVA-FRONTEND-SURVEY.md,\n  \"As built: JN2\"); since JC6 Runtime.exec's overloads and Date.toInstant\n  (doc/classes/JAVA-CONFORMANCE-SURVEY.md, JCS77 (a), \"As built: JC6\"), which the interpreter\n  reached by reflection and the compiled program found cut.v16,arbace.j2g.model22,throwable-print-helperm10,R6,L1,V3,R38,R36,R18,R0,s231,The support function of a call of a member of support-call-helpers declared by its owner\n  (owner, the method's declaring class), when the class it needs has Java forms (main.ae then\n  roots what the function calls); nil otherwise.R3,i669,R4,i1,R5,s19,arbace/j2g/model.ae")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.model$eval1479000004$loading__1927001464__auto____1479000005")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.model$eval1479000008$fn__1479000009")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.model$jobs")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.model$has_QMARK_")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.model$T")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.model$translated_QMARK_")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.model$j2g_static_QMARK_")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.model$jrt_class")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.model$hand_written_QMARK_")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.model$in_world_QMARK_")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.model$translatable_QMARK_")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.model$reflectable_interface_QMARK_")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.model$reflected_QMARK_")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.model$info")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.model$interface_QMARK_")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.model$desc_classes")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.model$method_desc_classes")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.model$erased_desc_QMARK_")

var Lit_107 *jrt.String = jrt.Intern("arbace.j2g.model$desc_in_world_QMARK_")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.model$mdesc_in_world_QMARK_")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.model$go_name")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.model$pkg")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.model$abstract_QMARK_")

var Lit_112 *jrt.String = jrt.Intern("arbace.j2g.model$final_QMARK_")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.model$subclasses")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.model$leaf_QMARK_")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.model$qualify")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.model$class_sym")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.model$jrt_sym")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.model$array_test")

var Lit_120 *jrt.String = jrt.Intern("arbace.j2g.model$go_type")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.model$pointer_desc_QMARK_")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.model$iface_desc_QMARK_")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.model$static_QMARK_")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.model$private_QMARK_")

var Lit_125 *jrt.String = jrt.Intern("arbace.j2g.model$abstract_m_QMARK_")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.model$methods_of")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.model$fields_of")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.model$find_method")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.model$virtual_member_QMARK_")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.model$supertypes")

var Lit_131 *jrt.String = jrt.Intern("arbace.j2g.model$world_supertypes")

var Lit_132 *jrt.String = jrt.Intern("arbace.j2g.model$all_supertypes")

var Lit_133 *jrt.String = jrt.Intern("arbace.j2g.model$hw_method_exists_QMARK_")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.model$j2g_method_QMARK_")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.model$member_in_world_QMARK_")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.model$vmethods")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.model$java_type_name")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.model$abstract_method_error_text")

var Lit_140 *jrt.String = jrt.Intern("arbace.j2g.model$superclass_chain")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.model$code_class_QMARK_")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.model$code_iface_QMARK_")

var Lit_144 *jrt.String = jrt.Intern("arbace.j2g.model$nest_top")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.model$trivial_init_QMARK_")

var Lit_147 *jrt.String = jrt.Intern("arbace.j2g.model$go_qualified_name")

var Lit_148 *jrt.String = jrt.Intern("arbace.j2g.model$start_class_QMARK_")

var Lit_149 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes")

var Lit_150 *jrt.String = jrt.Intern("arbace.j2g.model$top_class")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.model$pure_ctor_QMARK_")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.model$benign_init_QMARK_")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000218")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.model$throwable_print_helper")
