//line j2g_strings.ae:1
package aot_arbace_j2g_model

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn19,arbace.classes.suidyn4,suidyn16,arbace.j2g.namesyn2,nmyn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.startyn5,startyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn1,Tkn11,jrt-classeskn5,flagskn7,methodskn10,interfaceskn4,elsekn6,erasedkn2,gokn14,subclass-indexkn5,superkn5,typeskn3,jrtkn4,castkn4,nullyn3,anykn4,descyn1,*kn6,fieldskn4,namekn5,funcskn5,ownerkn14,vmethods-cachekn4,kindkn6,objectkn6,methodkn8,jrt-implkn8,promotedkn5,classkn7,defaultkn3,anykn3,topkn7,nestingkn11,inner-flagskn15,outer-instance?kn4,instkn4,enumkn6,recordkn9,enum-bodykn4,anonkn5,localkn6,appendks3,c2j4,codekn4,metakn13,trivial-cachekn5,statekn6,clinitkn10,clj-constskn11,uses-assertkn16,interface-assertkn6,bodieskn4,callkn8,prologuekn11,nested-callkn4,argskn4,ctorkn4,initkn4,bodykn2,opkn7,convertkn4,fromkn2,tokn4,exprkn9,set-fieldkn9,this-pathkn6,targetkn4,pathkn3,valkn6,invokekn6,statickn10,set-statickn8,declarerkn5,fieldkn3,letkn8,bindingskn10,get-statickn2,dokn10,statementskn3,retkn5,constkn9,new-arraykn4,dimskn3,newkn5,outerkn5,arithkn3,remkn3,divkn1,okn5,exactkn6,familykn9,class-litkn10,array-initkn5,elemskn6,benignv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,v11,arbace.core5,referR19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.modelm2,R20,s252,The closed world of one j2g run (J2G-SPEC §4.1, §5): which classes exist in Go (translated\n  ones, T, and jrt's hand-written ones, H), leaf classes (§5.3), the Go type of a Java type\n  (§5.1), virtual method sets and their implementations (§5.4, §5.5).v16,arbace.j2g.model5,*run*v16,arbace.j2g.model13,on-run-threadv11,arbace.core3,seqv16,arbace.j2g.model12,default-jobsv11,arbace.core3,vecv11,arbace.core5,rangev11,arbace.core4,mapvv11,arbace.core4,peekv11,arbace.core11,future-callv16,arbace.j2g.model6,run-fnv11,arbace.core4,atoml-1,v11,arbace.core5,swap!v11,arbace.core3,incv11,arbace.core5,doallv11,arbace.core10,repeatedlyv11,arbace.core4,run!v11,arbace.core3,notl0,R21,v16,arbace.j2g.model3,*w*v11,arbace.core9,contains?v16,arbace.j2g.model1,Tv11,arbace.core4,subsv16,arbace.j2g.model11,translated?v11,arbace.core4,somev16,arbace.j2g.model21,serial-accessor-basesv11,arbace.core4,keysv16,arbace.j2g.model16,serial-accessorsR22,v16,arbace.j2g.model9,jrt-classv22,arbace.classes.analyze4,declv13,arbace.string12,starts-with?v13,arbace.string9,includes?v11,arbace.core5,some?v18,arbace.classes.env4,infov18,arbace.classes.env10,interface?v16,arbace.j2g.model4,has?R23,l8192,v11,arbace.core6,empty?R24,v11,arbace.core6,every?v16,arbace.j2g.model9,in-world?v16,arbace.j2g.model22,reflectable-interface?R25,v11,arbace.core8,keyword?v20,arbace.classes.types6,array?v16,arbace.j2g.model12,desc-classesv20,arbace.classes.types10,array-dimsv20,arbace.classes.types11,class-desc?R26,v20,arbace.classes.types14,desc->internalv11,arbace.core7,string?v16,arbace.j2g.model13,mdesc-classesv20,arbace.classes.types17,parse-method-descv11,arbace.core6,mapcatv11,arbace.core4,consv20,arbace.classes.types9,elem-typeR27,v16,arbace.j2g.model19,method-desc-classesR28,v16,arbace.j2g.names13,go-class-namev16,arbace.j2g.names6,pkg-ofv16,arbace.j2g.model4,infoi1024,i16,R29,v11,arbace.core6,reset!v11,arbace.core6,reduceR30,v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core6,concatv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv16,arbace.j2g.model10,interface?v16,arbace.j2g.model13,hand-written?R31,R32,v16,arbace.j2g.model7,go-namev16,arbace.j2g.model9,abstract?v16,arbace.j2g.model10,subclassesv16,arbace.j2g.model12,proxy-super?v16,arbace.j2g.model6,final?v11,arbace.core6,symbolv16,arbace.j2g.names8,pkg-namev16,arbace.j2g.model7,qualifyv16,arbace.j2g.model3,pkgv16,arbace.j2g.model9,class-symR33,v20,arbace.classes.types5,prim?v11,arbace.core4,listv16,arbace.j2g.model7,jrt-symv16,arbace.j2g.model13,prim-array-goR34,R35,v16,arbace.j2g.model7,prim-goR35,R35,v16,arbace.j2g.model5,leaf?v11,arbace.core7,ex-infov11,arbace.core6,pr-strR36,R37,R37,R37,v11,arbace.core4,not=v20,arbace.classes.types4,ref?v16,arbace.j2g.model13,pointer-desc?i8,i2,R38,R39,v16,arbace.j2g.model10,methods-ofv16,arbace.j2g.model7,static?v16,arbace.j2g.model8,private?v11,arbace.core6,removev11,arbace.core4,nil?v11,arbace.core6,filterv16,arbace.j2g.model10,supertypesv18,arbace.classes.env14,all-supertypesv16,arbace.j2g.names11,method-basev16,arbace.j2g.model11,object-keysv14,arbace.j2g.jrt13,iface-methodsR40,v14,arbace.j2g.jrt14,struct-methodsv16,arbace.j2g.names9,impl-namev16,arbace.j2g.model11,j2g-method?S2,s16,Chars__IntStreams21,CodePoints__IntStreamv16,arbace.j2g.model15,mdesc-in-world?v16,arbace.j2g.model17,hw-method-exists?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv16,arbace.j2g.model15,virtual-member?v16,arbace.j2g.model16,member-in-world?v11,arbace.core12,chunk-appendv11,arbace.core5,assocR41,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,restR42,v16,arbace.j2g.model17,declared-vmethodsv11,arbace.core9,array-mapv16,arbace.j2g.model14,all-supertypesv16,arbace.j2g.model14,java-type-namem18,s1,Js4,longs1,Ss5,shorts1,Zs7,booleans1,Cs4,chars1,Fs5,floats1,Bs4,bytes1,Vs4,voids1,Is3,ints1,Ds6,doublev13,arbace.string7,replacev13,arbace.string4,joinv11,arbace.core3,mapv11,arbace.core10,take-whilev11,arbace.core7,iteratev16,arbace.j2g.model11,find-methodv16,arbace.j2g.model11,abstract-m?R43,R44,R45,R46,R47,R48,v16,arbace.j2g.model16,superclass-chainR49,v18,arbace.classes.env9,subclass?S1,s20,java/io/Serializablev16,arbace.j2g.model12,serial-hooksR50,S2,s16,serialVersionUIDs22,serialPersistentFieldsR51,R52,R53,v13,arbace.string5,splitp2,\\$v16,arbace.j2g.model8,java-pkgv16,arbace.j2g.model8,ctors-ofv16,arbace.j2g.model12,class-accessv16,arbace.j2g.model13,serializable?v11,arbace.core10,drop-whilev16,arbace.j2g.model22,super-ctor-accessible?V2,nni1,i4,R54,v16,arbace.j2g.model14,serialization?R55,S2,R56,R57,R58,S2,R59,R60,v16,arbace.j2g.model18,serial-chain-superv16,arbace.j2g.model13,default-suid?S2,R56,R57,v16,arbace.j2g.model11,code-class?v19,arbace.classes.suid12,default-suidv16,arbace.j2g.model10,serial-uidv11,arbace.core4,spitR61,R62,R63,v11,arbace.core10,re-matchesp32,arbace/lang/Compiler\\$AOT[FR]\\d+i512,v11,arbace.core8,distinctv16,arbace.j2g.model13,trivial-init?R64,R65,R66,R67,R68,R69,v16,arbace.j2g.model20,init-superinterfacesv16,arbace.j2g.names8,pkg-pathv16,arbace.j2g.model11,start-namesv16,arbace.j2g.model17,go-qualified-namev11,arbace.core4,intov16,arbace.j2g.model12,start-class?v11,arbace.core4,keepv16,arbace.j2g.start7,classesR70,v16,arbace.j2g.model9,top-classR71,R72,R73,v16,arbace.j2g.model10,pure-node?R74,S3,s16,java/lang/Records14,java/lang/Enums16,java/lang/Objectv16,arbace.j2g.model10,pure-ctor?R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,R86,R87,R88,R89,R90,R91,R92,R93,R94,R95,R96,R97,R98,R99,R60,R100,v11,arbace.core7,number?R101,R102,R103,R104,S2,R105,R106,R107,R108,R109,R110,R111,R112,v16,arbace.j2g.model12,benign-init?R113,l1,v16,arbace.j2g.model28,class-loader-resource-targetv16,arbace.j2g.model29,class-loader-resource-helpersv16,arbace.j2g.model18,runtime-exec-descsv16,arbace.j2g.model20,support-call-helpersv16,arbace.j2g.model13,translatable?v16,arbace.j2g.model28,class-loader-resource-ready?")

var Lit_1 *jrt.String = jrt.Intern("/")

var Lit_2 *jrt.String = jrt.Intern(".")

var Lit_3 *jrt.String = jrt.Intern(", ")

var Lit_4 *jrt.String = jrt.Intern(" of ")

var Lit_5 *jrt.String = jrt.Intern("interface ")

var Lit_6 *jrt.String = jrt.Intern("abstract class ")

var Lit_7 *jrt.String = jrt.Intern("_Cast")

var Lit_8 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_9 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_10 *jrt.String = jrt.Intern("ObjectArray")

var Lit_11 *jrt.String = jrt.Intern("RefArray")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.model$benign_init_QMARK_$fn__1479000255")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.model$class_loader_resource_ready_QMARK_$fn__1479000263")

var Lit_14 *jrt.String = jrt.Intern("jdk/internal/jrt/ClassPathResources")

var Lit_15 *jrt.String = jrt.Intern("getSystem")

var Lit_16 *jrt.String = jrt.Intern("system")

var Lit_17 *jrt.String = jrt.Intern("(Ljava/lang/ClassLoader;")

var Lit_18 *jrt.String = jrt.Intern("")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.model$ctors_of$fn__1479000157")

var Lit_20 *jrt.String = jrt.Intern("<init>")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods$iter__1479000099__1479000103")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods$iter__1479000099__1479000103$fn__1479000104")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods$iter__1479000099__1479000103$fn__1479000104$fn__1479000105")

var Lit_24 *jrt.String = jrt.Intern("1")

var Lit_25 *jrt.String = jrt.Intern("J2G_DEFAULT_SUID")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.model$erased_desc_QMARK_$fn__1479000056")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.model$erased_desc_QMARK_$fn__1479000058")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.model$find_method$fn__1479000089")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000270$iter__1479000266__1479000271")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000270$iter__1479000266__1479000271$fn__1479000272")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000270$iter__1479000266__1479000271$fn__1479000272$fn__1479000273")

var Lit_32 *jrt.String = jrt.Intern("java/lang/ClassLoader")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000288$iter__1479000284__1479000289")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000288$iter__1479000284__1479000289$fn__1479000290")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000288$iter__1479000284__1479000289$fn__1479000290$fn__1479000291")

var Lit_36 *jrt.String = jrt.Intern("java/lang/Runtime")

var Lit_37 *jrt.String = jrt.Intern("exec")

var Lit_38 *jrt.String = jrt.Intern("J2g_Runtime")

var Lit_39 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.model$foreign_super_accessible_QMARK_$fn__1479000182")

var Lit_41 *jrt.String = jrt.Intern("V")

var Lit_42 *jrt.String = jrt.Intern("_I")

var Lit_43 *jrt.String = jrt.Intern("j2g: no Go type for ")

var Lit_44 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_45 *jrt.String = jrt.Intern("_")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$fn__1479000133")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$iter__1479000135__1479000139")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$fn__1479000145")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$fn__1479000145$fn__1479000146")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$iter__1479000135__1479000139$fn__1479000140")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of$iter__1479000135__1479000139$fn__1479000140$fn__1479000141")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$declares_default_QMARK___1479000189")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$walk__1479000193")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$iter__1479000195__1479000199")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$declares_default_QMARK___1479000189$fn__1479000190")

var Lit_56 *jrt.String = jrt.Intern("<clinit>")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$iter__1479000195__1479000199$fn__1479000200")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces$iter__1479000195__1479000199$fn__1479000200$fn__1479000201")

var Lit_59 *jrt.String = jrt.Intern("java/lang/String")

var Lit_60 *jrt.String = jrt.Intern("java/lang/CharSequence")

var Lit_61 *jrt.String = jrt.Intern("java/util/stream/IntStream")

var Lit_62 *jrt.String = jrt.Intern("java/lang/System")

var Lit_63 *jrt.String = jrt.Intern("GetProperties__Properties")

var Lit_64 *jrt.String = jrt.Intern("java/util/Properties")

var Lit_65 *jrt.String = jrt.Intern("java/lang/Thread")

var Lit_66 *jrt.String = jrt.Intern("GetAllStackTraces__Map")

var Lit_67 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_68 *jrt.String = jrt.Intern("jdk/internal/access/SharedSecrets")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.model$j2g_static_QMARK_$fn__1479000036")

var Lit_70 *jrt.String = jrt.Intern("[]")

var Lit_71 *jrt.String = jrt.Intern("J2G_JOBS")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index$fn__1479000068")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index$fn__1479000068$fn__1479000069")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index$fn__1479000068$fn__1479000069$fn__1479000070")

var Lit_75 *jrt.String = jrt.Intern("$")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$fn__1479000021")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$work__1479000025")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$fn__1479000027")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$fn__1479000021$fn__1479000022")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv$fn__1479000027$fn__1479000028")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.model$pure_ctor_QMARK_$fn__1479000223")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.model$pure_ctor_QMARK_$fn__1479000225")

var Lit_83 *jrt.String = jrt.Intern("java/lang/Class")

var Lit_84 *jrt.String = jrt.Intern("getPrimitiveClass")

var Lit_85 *jrt.String = jrt.Intern("$values")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000235")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000238")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000243")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000245")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000247")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000249")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_$fn__1479000251")

var Lit_93 *jrt.String = jrt.Intern("java/")

var Lit_94 *jrt.String = jrt.Intern("javax/")

var Lit_95 *jrt.String = jrt.Intern("jdk/")

var Lit_96 *jrt.String = jrt.Intern("sun/")

var Lit_97 *jrt.String = jrt.Intern("com/sun/")

var Lit_98 *jrt.String = jrt.Intern("$$")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.model$reflectable_interface_QMARK_$fn__1479000044")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.model$run_fn$fn__1479000013")

var Lit_101 *jrt.String = jrt.Intern("Get")

var Lit_102 *jrt.String = jrt.Intern("__")

var Lit_103 *jrt.String = jrt.Intern("Set")

var Lit_104 *jrt.String = jrt.Intern("__V")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.model$serial_chain_super$fn__1479000170")

var Lit_106 *jrt.String = jrt.Intern("()V")

var Lit_107 *jrt.String = jrt.Intern("java/io/ObjectStreamClass")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.model$serial_uid$fn__1479000176")

var Lit_109 *jrt.String = jrt.Intern("J2G_DEFAULT_SUID_OUT")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.model$serial_uid$fn__1479000178")

var Lit_111 *jrt.String = jrt.Intern("serialVersionUID")

var Lit_112 *jrt.String = jrt.Intern(" ")

var Lit_113 *jrt.String = jrt.Intern("\n")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes$iter__1479000209__1479000213")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes$iter__1479000209__1479000213$fn__1479000214")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes$iter__1479000209__1479000213$fn__1479000214$fn__1479000215")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.model$super_ctor_accessible_QMARK_$top__1479000162")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.model$super_ctor_accessible_QMARK_$fn__1479000164")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.model$super_ctor_accessible_QMARK_$fn__1479000166")

var Lit_120 *jrt.String = jrt.Intern("arbace.j2g.model$superclass_chain$fn__1479000125")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.model$vmethods$fn__1479000110")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.model$vmethods$fn__1479000110$fn__1479000111")

var Lit_123 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,fyn1,nyn2,xsyn1,&yn5,orderyn5,flagsyn1,iyn3,clsyn4,baseyn1,dkn3,tagkn7,privateyn4,descyn1,wyn4,fromyn2,ofyn5,identyn6,suffixyn4,boolyn4,int8yn6,uint16yn5,int16yn5,int32yn5,int64yn7,float32yn7,float64yn4,kindyn1,xyn4,compyn1,myn4,namekn8,declaredyn5,ownerkn2,asyn1,kkn3,anyyn2,mmyn2,clyn6,Stringyn1,cyn4,seenyn4,nodev11,arbace.core5,in-nsMyn16,arbace.j2g.modelm2,R0,s252,The closed world of one j2g run (J2G-SPEC §4.1, §5): which classes exist in Go (translated\n  ones, T, and jrt's hand-written ones, H), leaf classes (§5.3), the Go type of a Java type\n  (§5.1), virtual method sets and their implementations (§5.4, §5.5).m2,R0,s252,The closed world of one j2g run (J2G-SPEC §4.1, §5): which classes exist in Go (translated\n  ones, T, and jrt's hand-written ones, H), leaf classes (§5.3), the Go type of a Java type\n  (§5.1), virtual method sets and their implementations (§5.4, §5.5).R1,v16,arbace.j2g.model3,*w*m10,R2,TR3,i15,R4,i1,R5,s19,arbace/j2g/model.aeR0,s88,The world: {:jrt scan :T atom-or-set :jrt-classes {internal {:go :var :standin :file}}}.v16,arbace.j2g.model5,*run*m10,R2,TR3,i26,R4,i1,R5,s19,arbace/j2g/model.aeR0,s63,True on j2g's run and on the threads of its futures (conveyed).v16,arbace.j2g.model13,on-run-threadm10,R6,L1,V1,R7,R0,s38,The marker frame: calls f. See run-fn.R3,i30,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model6,run-fnm10,R6,L1,V1,R7,R0,s75,f, or when this thread carries *run*, a fn calling f through on-run-thread.R3,i35,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,default-jobsl16,m8,R3,i43,R4,i1,R5,s19,arbace/j2g/model.aeR0,s182,At most this many threads by default: on Go, 16 take 10 GB at most for the program, 64 take\n  12 GB (GOMEMLIMIT 12GiB) for 5% less time (doc/STANDALONE-NOTES.md, S4, amendment SA51).v16,arbace.j2g.model4,jobsm10,R6,L1,V0,R0,s102,How many threads translate and write: J2G_JOBS, else the number of processors, at most\n  default-jobs.R3,i48,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,par-mapvm10,R6,L1,V5,R8,R7,R9,R10,V1,R11,R0,s703,(mapv f xs), f applied on up to n threads, each taking the next element (in xs' order, or\n  in the order of the indices `order`: the longest first); the results in xs' order. f's\n  dynamic bindings are the caller's (future's conveyance). The last element in that order (the\n  shortest) first, alone, then the others: on a host whose evaluator compiles an evaluated fn's\n  method on its first call without a lock (a stage 0 older than 2026-10-18,\n  Compiler$CodeRun.cmethod), threads first calling one at once could read its analyzed tree's\n  lazy state torn (a NullPointerException in HashMap$EntrySet.iterator); that element compiles\n  the fns of its path alone (on a thread of its own, as the others).R3,i57,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model4,has?m8,R6,L1,V2,R12,R7,R3,i89,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model1,Tm8,R6,L1,V0,R3,i91,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,translated?m8,R6,L1,V1,R8,R3,i93,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model16,serial-accessorsm10,s47,jdk/internal/access/JavaObjectInputStreamAccesss25,java/io/ObjectInputStreams51,jdk/internal/access/JavaObjectInputStreamReadStrings25,java/io/ObjectInputStreams47,jdk/internal/access/JavaObjectInputFilterAccesss32,java/io/ObjectInputFilter$Configs49,jdk/internal/access/JavaxCryptoSealedObjectAccesss25,javax/crypto/SealedObjects44,jdk/internal/access/JavaUtilCollectionAccesss37,java/util/ImmutableCollections$Accessm8,R3,i95,R4,i1,R5,s19,arbace/j2g/model.aeR0,s308,JCS167: SharedSecrets' serialization accessors (jdk26u's jdk.internal.access.SharedSecrets): the\n  access interface -> the class whose initialization sets it (the getter's ensureClassInitialized).\n  Since slice 4 also SealedObject's (doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As built: serialization\n  slice 4\").v16,arbace.j2g.model21,serial-accessor-basesm10,R6,L1,V1,R13,R0,s87,The Go base names of SharedSecrets' getter and setter of access interface i: [get set].R3,i111,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,j2g-static?m10,R6,L1,V2,R14,R15,R0,s449,A static method of jrt's hand-written class cls (Go base name base) that j2g writes itself,\n  in the program's support code, because its type is a translated class jrt cannot name:\n  System.getProperties(), a Properties (out.ae; JRT-NOTES.md, \"Text and locales\":\n  StaticProperty reads it); SharedSecrets' serialization accessors (JCS167: serial-accessors), when\n  their interfaces are translated; Thread.getAllStackTraces(), a HashMap (JCS320 (a)).R3,i117,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,jrt-classm10,R6,L1,V1,R8,R0,s89,jrt's hand-written (or stand-in) class n, when jrt defines it: {:go :var :standin :file}.R3,i132,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,hand-written?m10,R6,L1,V1,R8,R0,s67,Is n a class jrt provides and j2g does not translate in this world?R3,i137,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,in-world?m8,R6,L1,V1,R8,R3,i142,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,translatable?m10,R6,L1,V1,R8,R0,s67,Is n in the class environment as Java forms (j2g can translate it)?R3,i145,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model22,reflectable-interface?m10,R6,L1,V1,R8,R0,s184,Is n a JDK interface j2g knows only by reflection (no Java forms: outside the converted\n  closure), which it may declare: its methods, no code (J2G-NOTES.md, \"Reflected\n  interfaces\")?R3,i150,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,reflected?m10,R6,L1,V1,R8,R0,s65,Is n a translated class declared from reflection (no Java forms)?R3,i168,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model4,infom8,R6,L1,V1,R8,R3,i173,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,interface?m8,R6,L1,V1,R8,R3,i174,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,desc-classesm10,R6,L1,V1,R16,R0,s67,The classes a descriptor mentions (array element classes included).R3,i176,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,mdesc-classesm12,R17,C38,java.util.concurrent.ConcurrentHashMapR18,TR3,i185,R4,i1,R5,s19,arbace/j2g/model.aeR0,s89,Method descriptor -> method-desc-classes' answer (asked for every call, by every thread).v16,arbace.j2g.model19,method-desc-classesm8,R6,L1,V1,R19,R3,i189,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,erased-desc?m10,R6,L1,V1,R16,R0,s255,Is d a class outside the world in a package a variant erases (j2g/erase), or an array of\n  one? Values of such types exist only to feed what the Go build cuts (the bytecode back end):\n  an operation producing one is the zero value (proposed amendment B2).R3,i196,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model14,desc-in-world?m8,R6,L1,V1,R16,R3,i208,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model15,mdesc-in-world?m8,R6,L1,V1,R19,R3,i209,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,go-namem10,R6,L1,V1,R8,R0,s263,The Go type name of class n: jrt's own name for a class jrt provides and j2g does not\n  translate (a jrt class may register a JDK name under another Go name: ReentrantLock's\n  condition is AbstractQueuedSynchronizer$ConditionObject), else the name derived from n.R3,i214,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model3,pkgm8,R6,L1,V1,R8,R3,i223,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,abstract?m8,R6,L1,V1,R8,R3,i225,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model6,final?m8,R6,L1,V1,R8,R3,i226,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,subclassesm10,R6,L1,V1,R8,R0,s63,Direct subclasses of class n in the world (memoized per world).R3,i228,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model19,make-subclass-indexm8,R6,L1,V1,R20,R3,i233,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,proxy-supersV9,s14,java/io/Writers14,java/io/Readers22,java/io/PushbackReaders19,java/io/InputStreams20,java/io/OutputStreams26,arbace/lang/APersistentMaps22,java/io/BufferedWriters21,java/lang/ThreadLocals16,java/util/BitSetm8,R3,i244,R4,i1,R5,s19,arbace/j2g/model.aeR0,s211,The classes besides Object that a proxy may extend in the Go build (§5.12, arbace.j2g.dyn):\n  each gets a Go type DynSub_C, a subclass of C in the world, so a translated class of the list\n  is not a leaf (§5.3).v16,arbace.j2g.model12,class-supersV131,s19,java/lang/Throwables19,java/lang/Exceptions26,java/lang/RuntimeExceptions15,java/lang/Errors34,java/lang/IllegalArgumentExceptions31,java/lang/IllegalStateExceptions14,java/lang/Enums16,java/lang/Records15,arbace/lang/AFns29,java/security/BasicPermissions22,java/security/Identitys27,java/security/IdentityScopes30,java/security/cert/Certificates34,java/security/cert/X509Certificates22,java/security/cert/CRLs25,java/security/KeyStoreSpis38,javax/net/ssl/X509ExtendedTrustManagers36,javax/net/ssl/X509ExtendedKeyManagers30,javax/net/ssl/SSLSocketFactorys36,javax/net/ssl/SSLServerSocketFactorys23,javax/net/ssl/SSLSockets23,javax/net/ssl/SSLEngines27,javax/net/ssl/SSLContextSpis27,javax/net/ssl/SNIServerNames24,javax/net/ssl/SNIMatchers34,javax/net/ssl/KeyManagerFactorySpis32,javax/tools/SimpleJavaFileObjects31,com/sun/source/util/TreeScanners35,com/sun/source/util/TreePathScanners22,java/net/Authenticators22,java/net/ProxySelectors15,java/net/Sockets21,java/net/ServerSockets22,java/net/URLConnections28,java/net/SecureCacheResponses22,java/io/BufferedReaders27,javax/naming/InitialContexts41,com/sun/net/httpserver/BasicAuthenticators26,java/net/HttpURLConnections16,java/lang/Threads26,java/io/FilterOutputStreams23,java/io/FileInputStreams17,java/util/HashMaps16,java/util/Vectors20,java/util/LinkedLists18,java/util/TimeZones25,java/net/URLStreamHandlers17,java/lang/Processs19,java/net/SocketImpls25,java/io/FilterInputStreams28,java/util/AbstractCollections22,java/util/AbstractLists21,java/util/AbstractMaps32,java/util/AbstractSequentialLists21,java/util/AbstractSets53,java/util/concurrent/locks/AbstractQueuedSynchronizers18,java/util/Calendars25,java/util/logging/Handlers31,java/util/logging/StreamHandlers32,java/util/logging/ConsoleHandlers31,java/util/logging/MemoryHandlers27,java/util/logging/Formatters30,java/util/logging/XMLFormatters30,java/util/logging/ErrorManagers23,java/util/logging/Levels24,java/util/logging/Loggers28,java/util/logging/LogManagers19,java/util/ArrayLists23,java/util/LinkedHashMaps23,java/util/LinkedHashSets25,java/util/IdentityHashMaps23,java/util/PriorityQueues28,java/io/ByteArrayInputStreams20,java/io/StringWriters12,java/io/Files24,java/lang/AssertionErrors20,java/math/BigIntegers27,java/text/DateFormatSymbolss27,java/util/concurrent/Phasers48,java/util/concurrent/ScheduledThreadPoolExecutors22,java/util/zip/Deflaters22,java/util/zip/Inflaters19,java/io/PrintStreams19,java/io/PrintWriters24,java/io/DataOutputStreams20,java/util/Observables27,java/util/GregorianCalendars42,java/util/concurrent/ConcurrentSkipListMaps17,java/util/TreeMaps17,java/util/TreeSets29,java/io/ByteArrayOutputStreams57,java/util/concurrent/locks/AbstractQueuedLongSynchronizers42,java/util/concurrent/ConcurrentSkipListSets30,java/util/zip/GZIPOutputStreams19,java/util/TimerTasks31,java/util/concurrent/FutureTasks35,java/util/spi/LocaleServiceProviders24,java/nio/charset/Charsets31,java/nio/charset/CharsetDecoders31,java/nio/charset/CharsetEncoders27,java/lang/ref/WeakReferences27,java/lang/ref/SoftReferences32,java/lang/InheritableThreadLocals43,java/util/concurrent/atomic/AtomicReferences40,java/util/concurrent/CopyOnWriteArraySets41,java/util/concurrent/CopyOnWriteArrayLists36,java/util/concurrent/RecursiveActions34,java/util/concurrent/RecursiveTasks21,java/lang/ClassLoaders22,java/security/Providers30,java/security/Provider$Services26,java/security/SecureRandoms29,java/security/SecureRandomSpis30,java/security/MessageDigestSpis23,java/security/Signatures26,java/security/SignatureSpis27,java/security/KeyFactorySpis33,java/security/KeyPairGeneratorSpis36,java/security/AlgorithmParametersSpis33,java/security/spec/EncodedKeySpecs22,javax/crypto/CipherSpis19,javax/crypto/MacSpis16,javax/crypto/Macs19,javax/crypto/KDFSpis32,javax/crypto/SecretKeyFactorySpis30,javax/crypto/CipherInputStreams31,javax/crypto/CipherOutputStreams17,java/util/HashSets37,java/security/spec/X509EncodedKeySpecs38,java/security/spec/PKCS8EncodedKeySpecs30,java/lang/ref/PhantomReferencem8,R3,i257,R4,i1,R5,s19,arbace/j2g/model.aeR0,s390,The classes besides proxy-supers that the classes of Java forms made at the REPL may extend\n  (doc/go/CLASSFORMS-REPL.md; arbace.j2g.dyn/class-supers): each gets its DynSub_C as the\n  proxies' superclasses do, so a translated one is not a leaf either (§5.3). Since JC4b the\n  superclasses jdk26u's tests extend (doc/classes/JAVA-CONFORMANCE-SURVEY.md, \"As built: JC4b\",\n  \"As built: JC4c\").v16,arbace.j2g.model12,proxy-super?v11,arbace.core3,setv11,arbace.core6,concatm8,R18,TR3,i348,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model5,leaf?m10,R6,L1,V1,R8,R0,s231,Is class n a leaf (§5.3): its values are *C pointers. Interfaces are not; jrt's classes are\n  leaves when jrt gives them no class interface C_I; a translated class of proxy-supers or\n  class-supers is not (its DynSub_C extends it).R3,i350,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,qualifym10,R6,L1,V3,R21,R22,R23,R0,s83,A Go identifier of package `of` (:jrt or :lang) as referred to from package `from`.R3,i365,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,class-symm10,R6,L2,V2,R21,R8,V3,R21,R8,R24,R0,s91,The Go identifier `suffix` of class n (\"\" for the type itself), as referred to from `from`.R3,i370,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,jrt-symm8,R6,L1,V2,R21,R23,R3,i375,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,prim-gom16,s1,ZR25,s1,BR26,s1,CR27,s1,SR28,s1,IR29,s1,JR30,s1,FR31,s1,DR32,m6,R3,i377,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,prim-array-gom16,s1,Zs12,BooleanArrays1,Bs9,ByteArrays1,Cs9,CharArrays1,Ss10,ShortArrays1,Is8,IntArrays1,Js9,LongArrays1,Fs10,FloatArrays1,Ds11,DoubleArraym6,R3,i379,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,array-testm10,R6,L1,V5,R21,R33,R34,R16,R35,R0,s402,checkcast (kind :cast) or instanceof (:instance) of array type d on x, an any, in package\n  `from` (J2G-SPEC §5.7, §5.9): jrt's type switch on the array's Go type, a primitive array's\n  `jrt.IntArray_Cast` and kin, Object[]'s `jrt.ObjectArray_Cast`, another reference array's\n  `jrt.RefArray_Cast` with comp, the form of the component class (Class.isInstance only where the\n  component classes differ).R3,i382,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,go-typem10,R6,L1,V2,R21,R16,R0,s58,The Go type form of descriptor d in package `from` (§5.1).R3,i396,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,pointer-desc?m10,R6,L1,V1,R16,R0,s58,Is the Go type of d a pointer (leaf class, String, array)?R3,i417,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,iface-desc?m10,R6,L1,V1,R16,R0,s47,Is the Go type of d an interface (any, C_I, J)?R3,i426,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,static?m8,R6,L1,V1,R36,R3,i434,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,private?m8,R6,L1,V1,R36,R3,i435,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,abstract-m?m8,R6,L1,V1,R36,R3,i436,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,methods-ofm8,R6,L1,V1,R8,R3,i438,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,fields-ofm8,R6,L1,V1,R8,R3,i439,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,find-methodm8,R6,L1,V3,R8,R37,R19,R3,i441,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model15,virtual-member?m10,R6,L1,V1,R36,R0,s89,A method that takes part in dispatch: an instance method, not private, not a constructor.R3,i444,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,object-keysS5,V2,s8,getClasss19,()Ljava/lang/Class;V2,s8,toStrings20,()Ljava/lang/String;V2,s5,clones20,()Ljava/lang/Object;V2,s6,equalss21,(Ljava/lang/Object;)ZV2,s8,hashCodes3,()Im8,R3,i449,R4,i1,R5,s19,arbace/j2g/model.aeR0,s61,Object's methods every class has through jrt.Object_I (§5.8).v16,arbace.j2g.model10,supertypesm8,R6,L1,V1,R8,R3,i454,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model16,world-supertypesm10,R6,L1,V1,R8,R0,s83,n's supertypes that exist in the world (interfaces that do not are left out, §4.1).R3,i457,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model14,all-supertypesm10,R6,L1,V1,R8,R0,s196,n and its supertypes that exist in the world, superclass chain first then interfaces\n  (Java's supertypes: an interface in the world counts also when it is reached only through\n  one that is not).R3,i462,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,j2g-method?m8,R38,TR3,i469,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model17,hw-method-exists?m10,R6,L1,V2,R8,R36,R0,s77,Does jrt's hand-written class or interface n have method m (name desc) in Go?R3,i471,R4,i1,R5,s19,arbace/j2g/model.aem10,R6,L1,V2,R8,R15,R0,s385,An instance method of jrt's hand-written class n (Go base name base) that the program's\n  support code has, though jrt does not: String's chars() and codePoints(), the default methods\n  of CharSequence (translated), which j2g forwards to on the classes jrt writes that implement\n  it (JRT-NOTES.md, \"Text and locales\": CompactNumberFormat and java.time's text call them on\n  a String).R3,i486,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model16,member-in-world?m10,R6,L1,V2,R8,R36,R0,s103,Does method m of class n exist in Go: its descriptor's classes exist, and for a jrt class\n  jrt has it.R3,i496,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model17,declared-vmethodsm10,R6,L1,V1,R8,R0,s64,The virtual methods n declares that exist in Go, by [name desc].R3,i503,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,vmethodsm10,R6,L1,V1,R8,R0,s188,Every virtual method of n (declared and inherited, abstract or not), in the world, Object's\n  excluded: an ordered map [name desc] -> method (the most specific declaration: classes first).R3,i511,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model14,java-type-namem10,R6,L1,V1,R16,R0,s62,The Java name of descriptor d (int, java.lang.Object, byte[]).R3,i528,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model26,abstract-method-error-textm10,R6,L1,V3,R8,R39,V2,R37,R19,R0,s188,HotSpot's message of the AbstractMethodError of method k = [name desc] (declared in owner, an\n  interface or an abstract class) called on an object of class n, which does not implement it.R3,i536,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model16,superclass-chainm8,R6,L1,V1,R8,R3,i545,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model7,impl-ofm10,R6,L1,V2,R8,V4,R37,R19,R40,R41,R0,s339,The implementation of virtual method k = [name desc] for class n: {:kind :class :owner c\n  :method m} for a method with a body in n or a superclass (a jrt class's: :jrt-impl when jrt\n  has Impl_, :promoted when the method itself is on its struct), {:kind :default :owner j\n  :method m} for an interface's default method, or nil (abstract).R3,i548,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model14,serialization?m10,R6,L1,V0,R0,s278,JCS167: is Java serialization in the world (java.io.ObjectStreamClass has Java forms)? Then the\n  Serializable classes' serialization members are in their member tables (out/member-tables), their\n  hooks reached (reach/serial-reach!) and their allocation written (serial-super).R3,i579,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,serializable?m10,R6,L1,V1,R8,R0,s68,Is class n Serializable (java.io.Serializable among its supertypes)?R3,i586,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,serial-hooksm10,V2,s11,writeObjects31,(Ljava/io/ObjectOutputStream;)VR18,V2,s10,readObjects30,(Ljava/io/ObjectInputStream;)VR18,V2,s16,readObjectNoDatas3,()VR18,V2,s12,writeReplaces20,()Ljava/lang/Object;R42,V2,s11,readResolves20,()Ljava/lang/Object;R42,m8,R3,i591,R4,i1,R5,s19,arbace/j2g/model.aeR0,s283,JCS167: the members ObjectStreamClass finds by reflection on a Serializable class: [name desc]\n  -> :private (writeObject, readObject, readObjectNoData: getPrivateMethod's, private and not\n  static) or :any (writeReplace, readResolve: getInheritableMethod's, any access, not static).v16,arbace.j2g.model12,serial-hook?m10,R6,L1,V1,R43,R0,s83,Is method mm of a Serializable class one of its serialization hooks (serial-hooks)?R3,i601,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,serial-field?m10,R6,L1,V1,R7,R0,s244,Is field f of a Serializable class one serialization reads by reflection: an instance field\n  (getDefaultSerialFields, the reflector, records' components), serialVersionUID or\n  serialPersistentFields (getDeclaredSUID, getDeclaredSerialFields)?R3,i607,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,java-pkgm10,R18,TR6,L1,V1,R8,R3,i614,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,class-accessm12,R18,TR6,L1,V1,R8,R0,s89,Class n's access flags as Class.getModifiers reports them (a member class's inner flags).R3,i616,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,ctors-ofm10,R18,TR6,L1,V1,R8,R3,i622,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model22,super-ctor-accessible?m12,R18,TR6,L1,V1,R44,R0,s253,jdk.internal.reflect.ReflectionFactory.superHasAccessibleConstructor(cl) (jdk26u): in cl's\n  package, any non-private constructor of its superclass (or the two nestmates); else the\n  superclass public or protected with a public or protected constructor.R3,i624,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model18,serial-chain-superm10,R6,L1,V1,R8,R0,s191,ReflectionFactory.newConstructorForSerialization's rule on Serializable class n's superclass\n  chain (serial-super's, without its conditions on n itself): [S ctor] (S nil for Object), or nil.R3,i640,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model12,serial-superm10,R6,L1,V1,R8,R0,s1044,CDR10, JCS167 (doc/go/JRT-NOTES.md, \"Serialization\"; doc/classes/JAVA-DEFERRED-TRIAGE.md,\n  \"As built: JCS167 (write-ahead)\"): when class n's objects are made for deserialization by\n  jrt's allocation (jdk.internal.jrt.SerialAlloc), [S ctor] for its first superclass S that is\n  not Serializable and S's no-argument constructor (nil for Object's, which does nothing); else\n  nil. ReflectionFactory.newConstructorForSerialization's rule (jdk26u): each serializable class\n  up the chain has a superclass with a constructor accessible to it (super-ctor-accessible?), and\n  S's no-argument constructor is not private and, unless public or protected, in n's package.\n  Only when serialization is in the world (serialization?), for a concrete translated class that\n  is Serializable, neither an enum nor a record (they are made by name and by their canonical\n  constructor), instantiated by the program (reach's :inst, when the world has it: RTA's,\n  serial-reach! reaches S's constructor), S's constructor taking nothing in Go (no outer\n  instance).R3,i661,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,code-class?m8,R38,TR3,i683,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,default-suid?m10,R6,L1,V0,R0,s298,JCS168's switch (doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As built: JCS167 slices 2-3 (write-ahead)\";\n  the user's decision pending): J2G_DEFAULT_SUID=1 has j2g write the default serialVersionUID of each\n  translated Serializable class without a declared one into its ClassInfo.SerialUID (serial-uid).R3,i685,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,serial-uidm10,R6,L1,V1,R8,R0,s564,JCS168: the default serialVersionUID of translated class n (arbace.classes.suid, computeDefaultSUID's\n  rule over the class as javac compiles it), when the switch is on (default-suid?), serialization in the\n  world, n Serializable without a static serialVersionUID field, neither an enum nor a record\n  (ObjectStreamClass gives those 0), nor a compiled fn's code; else nil. Each value is also appended to\n  the file J2G_DEFAULT_SUID_OUT names (\"binary-name value\" lines, for the night's comparison with the\n  JDK's, test/jrt/serialization/default-suids-jdk26.txt).R3,i692,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model25,foreign-super-accessible?m10,R6,L1,V1,R8,R0,s202,superHasAccessibleConstructor's answer for a subclass of n in another package (an interpreted\n  class extending n, JCS167's cfSerialFor): n public or protected, with a public or protected\n  constructor.R3,i710,R4,i1,R5,s19,arbace/j2g/model.aem10,R6,L1,V1,R8,R0,s488,Is class n a compiled fn's code (standalone S6, :c2j/code; SA156)? Not a Java object in Go:\n  it implements its arities' interfaces (code-iface?) and nothing of Object's protocol, which\n  its fn (Compiler$AOTFn) answers; its struct starts with a header word that stays zero (so\n  that jrt.IsDynamic reads it as any object's). Its allocation initializes its nest's\n  top-level class (its namespace's holder, whose constants its code reads), so that its code\n  reads them unguarded (SA158).R3,i718,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,code-iface?m10,R6,L1,V1,Myn1,nm2,R17,R45,R0,s163,Is interface n a compiled fn's arity, Compiler$AOTF<n> or $AOTR<n> (SA156): its Go interface\n  does not embed jrt.Object_I, so that code-class? types implement it.R3,i728,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model8,nest-topm10,R6,L1,V1,Myn1,nm2,R17,R45,R0,s75,The top-level class of class n's nest (internal names: before the first $).R3,i734,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,trivial-init?m8,R38,TR3,i739,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model20,init-superinterfacesm10,R6,L1,V1,R8,R0,s283,The superinterfaces of class n initialized with it (JLS 12.4.2 step 7: those that declare a\n  default method, each direct superinterface's superinterfaces before it, in the order of the\n  declaration's lists), translated with non-trivial initialization; none for an interface (JC4b).R3,i741,R4,i1,R5,s19,arbace/j2g/model.aem10,R6,L1,V1,R8,R0,s226,Does class n have trivial initialization (§6.2): no static initializer code, no\n  non-constant static field initializer, a superclass with trivial initialization? jrt's\n  classes count as trivial (jrt initializes them itself).R3,i760,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model17,go-qualified-namem10,R6,L1,V1,R8,R0,s133,Class n's Go name with its package's path (arbace/lang.Util), as jrt's trace of class\n  initialization prints it (ARBACE_TRACE_INIT).R3,i785,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model11,start-namesv16,arbace.j2g.start7,classesm10,R18,TR3,i791,R4,i1,R5,s19,arbace/j2g/model.aeR0,s51,The Go names of arbace.j2g.start/classes, as a set.v16,arbace.j2g.model12,start-class?m10,R6,L1,V1,R8,R0,s133,Is n one of the classes initialized at start (arbace.j2g.start/classes) in this world:\n  translated, with non-trivial initialization?R3,i795,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model13,start-classesm10,R6,L1,V0,R0,s91,The classes initialized at start in this world (start-class?), in arbace.j2g.start's order.R3,i802,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,pure-node?m8,R38,TR3,i811,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model9,top-classm10,R18,TR6,L1,V1,Myn1,nm2,R17,R45,R3,i813,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model10,pure-ctor?m12,R18,TR6,L1,V4,R8,R46,R36,R47,R0,s210,Is constructor m of class c (in the file of class n) free of effects beyond its object's\n  fields: field stores of pure values on this, a super or this constructor call that is pure\n  too (Object's at the end)?R3,i815,R4,i1,R5,s19,arbace/j2g/model.aem12,R18,TR6,L1,V3,R8,R48,R47,R0,s152,Can node, run inside the static initializer of class n, neither be observed outside n's\n  statics and new objects nor throw (bar running out of memory)?R3,i838,R4,i1,R5,s19,arbace/j2g/model.ae")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.model$eval1479000004$loading__1927001464__auto____1479000005")

var Lit_125 *jrt.String = jrt.Intern("arbace.j2g.model$eval1479000008$fn__1479000009")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.model$on_run_thread")

var Lit_127 *jrt.String = jrt.Intern("arbace.j2g.model$run_fn")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.model$jobs")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.model$par_mapv")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.model$has_QMARK_")

var Lit_131 *jrt.String = jrt.Intern("arbace.j2g.model$T")

var Lit_132 *jrt.String = jrt.Intern("arbace.j2g.model$translated_QMARK_")

var Lit_133 *jrt.String = jrt.Intern("arbace.j2g.model$serial_accessor_bases")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.model$j2g_static_QMARK_")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.model$jrt_class")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.model$hand_written_QMARK_")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.model$in_world_QMARK_")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.model$translatable_QMARK_")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.model$reflectable_interface_QMARK_")

var Lit_140 *jrt.String = jrt.Intern("arbace.j2g.model$reflected_QMARK_")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.model$info")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.model$interface_QMARK_")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.model$desc_classes")

var Lit_144 *jrt.String = jrt.Intern("arbace.j2g.model$method_desc_classes")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.model$erased_desc_QMARK_")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.model$desc_in_world_QMARK_")

var Lit_147 *jrt.String = jrt.Intern("arbace.j2g.model$mdesc_in_world_QMARK_")

var Lit_148 *jrt.String = jrt.Intern("arbace.j2g.model$go_name")

var Lit_149 *jrt.String = jrt.Intern("arbace.j2g.model$pkg")

var Lit_150 *jrt.String = jrt.Intern("arbace.j2g.model$abstract_QMARK_")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.model$final_QMARK_")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.model$subclasses")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.model$make_subclass_index")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.model$leaf_QMARK_")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.model$qualify")

var Lit_156 *jrt.String = jrt.Intern("arbace.j2g.model$class_sym")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.model$jrt_sym")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.model$array_test")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.model$go_type")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.model$pointer_desc_QMARK_")

var Lit_161 *jrt.String = jrt.Intern("arbace.j2g.model$iface_desc_QMARK_")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.model$static_QMARK_")

var Lit_163 *jrt.String = jrt.Intern("arbace.j2g.model$private_QMARK_")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.model$abstract_m_QMARK_")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.model$methods_of")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.model$fields_of")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.model$find_method")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.model$virtual_member_QMARK_")

var Lit_169 *jrt.String = jrt.Intern("arbace.j2g.model$supertypes")

var Lit_170 *jrt.String = jrt.Intern("arbace.j2g.model$world_supertypes")

var Lit_171 *jrt.String = jrt.Intern("arbace.j2g.model$all_supertypes")

var Lit_172 *jrt.String = jrt.Intern("arbace.j2g.model$hw_method_exists_QMARK_")

var Lit_173 *jrt.String = jrt.Intern("arbace.j2g.model$j2g_method_QMARK_")

var Lit_174 *jrt.String = jrt.Intern("arbace.j2g.model$member_in_world_QMARK_")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.model$declared_vmethods")

var Lit_176 *jrt.String = jrt.Intern("arbace.j2g.model$vmethods")

var Lit_177 *jrt.String = jrt.Intern("arbace.j2g.model$java_type_name")

var Lit_178 *jrt.String = jrt.Intern("arbace.j2g.model$abstract_method_error_text")

var Lit_179 *jrt.String = jrt.Intern("arbace.j2g.model$superclass_chain")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.model$impl_of")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.model$serialization_QMARK_")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.model$serializable_QMARK_")

var Lit_183 *jrt.String = jrt.Intern("arbace.j2g.model$serial_hook_QMARK_")

var Lit_184 *jrt.String = jrt.Intern("arbace.j2g.model$serial_field_QMARK_")

var Lit_185 *jrt.String = jrt.Intern("arbace.j2g.model$java_pkg")

var Lit_186 *jrt.String = jrt.Intern("arbace.j2g.model$class_access")

var Lit_187 *jrt.String = jrt.Intern("arbace.j2g.model$ctors_of")

var Lit_188 *jrt.String = jrt.Intern("arbace.j2g.model$super_ctor_accessible_QMARK_")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.model$serial_chain_super")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.model$serial_super")

var Lit_191 *jrt.String = jrt.Intern("arbace.j2g.model$default_suid_QMARK_")

var Lit_192 *jrt.String = jrt.Intern("arbace.j2g.model$serial_uid")

var Lit_193 *jrt.String = jrt.Intern("arbace.j2g.model$foreign_super_accessible_QMARK_")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.model$code_class_QMARK_")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.model$code_iface_QMARK_")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.model$nest_top")

var Lit_197 *jrt.String = jrt.Intern("arbace.j2g.model$init_superinterfaces")

var Lit_198 *jrt.String = jrt.Intern("arbace.j2g.model$trivial_init_QMARK_")

var Lit_199 *jrt.String = jrt.Intern("arbace.j2g.model$go_qualified_name")

var Lit_200 *jrt.String = jrt.Intern("arbace.j2g.model$start_class_QMARK_")

var Lit_201 *jrt.String = jrt.Intern("arbace.j2g.model$start_classes")

var Lit_202 *jrt.String = jrt.Intern("arbace.j2g.model$top_class")

var Lit_203 *jrt.String = jrt.Intern("arbace.j2g.model$pure_ctor_QMARK_")

var Lit_204 *jrt.String = jrt.Intern("arbace.j2g.model$pure_node_QMARK_")

var Lit_205 *jrt.String = jrt.Intern("kn8,arglistsyn1,nkn3,dockn4,linekn6,columnkn4,fileyn3,nmeyn4,descyn5,owneryn4,namev16,arbace.j2g.model12,benign-init?m10,R0,L1,V1,R1,R2,s392,Is class n's initialization unobservable but through n's own static fields: trivial, or a\n  static initializer that only stores pure values (constants, arrays, n's own objects built by\n  pure constructors) into n's statics, over a superclass whose initialization is benign too?\n  Then a static method of n that reads no static field of n needs no initialization guard\n  (J2G-NOTES, phase 2D).R3,i865,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model18,runtime-exec-descsV6,s39,(Ljava/lang/String;)Ljava/lang/Process;s58,(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s72,(Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;s40,([Ljava/lang/String;)Ljava/lang/Process;s59,([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s73,([Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;m8,R3,i889,R4,i1,R5,s19,arbace/j2g/model.aeR2,s104,Runtime.exec's six overloads (jrt's own Java jdk.internal.jrt.RuntimeExec: JRT-NOTES.md,\n  \"Processes\").v16,arbace.j2g.model29,class-loader-resource-helpersV6,V3,s11,getResources34,(Ljava/lang/String;)Ljava/net/URL;s26,J2g_ClassLoaderGetResourceV3,s12,getResourcess43,(Ljava/lang/String;)Ljava/util/Enumeration;s27,J2g_ClassLoaderGetResourcesV3,s19,getResourceAsStreams41,(Ljava/lang/String;)Ljava/io/InputStream;s34,J2g_ClassLoaderGetResourceAsStreamV3,s17,getSystemResources34,(Ljava/lang/String;)Ljava/net/URL;s32,J2g_ClassLoaderGetSystemResourceV3,s18,getSystemResourcess43,(Ljava/lang/String;)Ljava/util/Enumeration;s33,J2g_ClassLoaderGetSystemResourcesV3,s25,getSystemResourceAsStreams41,(Ljava/lang/String;)Ljava/io/InputStream;s40,J2g_ClassLoaderGetSystemResourceAsStreamm8,R3,i899,R4,i1,R5,s19,arbace/j2g/model.aeR2,s219,ClassLoader's resource methods translated code calls, [name desc support-function]: the instance\n  ones a loader's own override first, else ClassPathResources' (out/support-forms); the static ones\n  the system loader's.v16,arbace.j2g.model28,class-loader-resource-targetm10,R0,L1,V2,R6,R7,R2,s232,The static method of jdk.internal.jrt.ClassPathResources a ClassLoader resource helper calls (name\n  desc): getResource(ClassLoader, String) for getResource(String), systemResource(String) for\n  getSystemResource(String), and so on.R3,i910,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model28,class-loader-resource-ready?m10,R0,L1,V2,R6,R7,R2,s140,Has the world's ClassPathResources the static a ClassLoader resource helper calls (jrt's own Java as\n  converted: the helpers came with A5)?R3,i919,R4,i1,R5,s19,arbace/j2g/model.aev16,arbace.j2g.model20,support-call-helpersv11,arbace.core4,intom10,V3,s19,java/lang/Throwables15,printStackTraces24,(Ljava/io/PrintWriter;)VV2,s25,J2g_PrintStackTraceWriters19,java/io/PrintWriterV3,s19,java/lang/Throwables15,printStackTraces24,(Ljava/io/PrintStream;)VV2,s25,J2g_PrintStackTraceStreams19,java/io/PrintStreamV3,s14,java/util/Dates9,toInstants21,()Ljava/time/Instant;V2,s17,J2g_DateToInstants17,java/time/InstantV3,s14,java/util/Dates4,froms37,(Ljava/time/Instant;)Ljava/util/Date;V2,s12,J2g_DateFroms17,java/time/InstantV3,s16,java/lang/Systems16,inheritedChannels29,()Ljava/nio/channels/Channel;V2,s26,J2g_SystemInheritedChannels38,java/nio/channels/spi/SelectorProviderm8,R3,i926,R4,i1,R5,s19,arbace/j2g/model.aeR2,s803,The instance methods of jrt's hand-written classes that jrt cannot write itself, as they name\n  translated classes, by [owner name desc]: [support function, the translated class it needs].\n  Calls of them are translated to j2g's support function (out/support-forms), the receiver\n  first, as the REPL's reflection reaches them (out's init entries). Throwable's printStackTrace\n  to a PrintWriter or a PrintStream (javac's crash reports; doc/classes/JAVA-FRONTEND-SURVEY.md,\n  \"As built: JN2\"); since JC6 Runtime.exec's overloads and Date.toInstant\n  (doc/classes/JAVA-CONFORMANCE-SURVEY.md, JCS77 (a), \"As built: JC6\"), which the interpreter\n  reached by reflection and the compiled program found cut; since JCS201 (a) System.inheritedChannel\n  (doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As built: JCS201\").v16,arbace.j2g.model22,throwable-print-helperm10,R0,L1,V3,R8,R9,R7,R2,s231,The support function of a call of a member of support-call-helpers declared by its owner\n  (owner, the method's declaring class), when the class it needs has Java forms (main.ae then\n  roots what the function calls); nil otherwise.R3,i952,R4,i1,R5,s19,arbace/j2g/model.ae")

var Lit_206 *jrt.String = jrt.Intern("arbace.j2g.model$benign_init_QMARK_")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.model$class_loader_resource_target")

var Lit_208 *jrt.String = jrt.Intern("arbace.j2g.model$class_loader_resource_ready_QMARK_")

var Lit_209 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000270")

var Lit_210 *jrt.String = jrt.Intern("arbace.j2g.model$fn__1479000288")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.model$throwable_print_helper")
