//line aot_arbace_j2g_model.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New() *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_model_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_model_A_const_1, A_arbace_j2g_model_A_const_2, A_arbace_j2g_model_A_const_3, A_arbace_j2g_model_A_const_4, A_arbace_j2g_model_A_const_5, A_arbace_j2g_model_A_const_6, A_arbace_j2g_model_A_const_7, A_arbace_j2g_model_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New() *A_arbace_j2g_model_eval1479000008_fn__1479000009_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000008_fn__1479000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_model_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_model_A_const_14.GetRawRoot__O(), A_arbace_j2g_model_A_const_15) }
























func A_arbace_j2g_model_jobs_A_New() *A_arbace_j2g_model_jobs_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jobs_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_53).Ref(); var tmp1 any; var tmp2 any; var root_26 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_28 lang.IFn; if




	linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = e__1; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_26, arg_29) }; if jrt.J2g_Truth(tmp2) {
		tmp1 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(e__1))).Ref() } else {
			tmp1 = lang.Numbers_Min_O_J__O_NoInit(A_arbace_j2g_model_A_const_17.GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :31:1*/ lang.Numbers_Max_J_O__O_NoInit(1, tmp1) }



func A_arbace_j2g_model_par_mapv_A_New() *A_arbace_j2g_model_par_mapv_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) Ctor() {}
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1479000013__3 any) any { var vec__1479000014__5 any = p__1479000013__3; var order__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000014__5, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__7 any; var root_30 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_32 lang.IFn; if









	linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = xs__2; if linked_31 == nil { xs__7 = ifn_32.Invoke_O__O(arg_33) } else { xs__7 = linked_31.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_30, arg_33) }; var cnt__8 int32 = /*line :35:1*/lang.RT_Count_O__I_NoInit(xs__7); var n__9 any = lang.Numbers_Min_O_J__O_NoInit(n__0, int64(cnt__8)); var order__10 any; if












	jrt.J2g_Truth(order__6) { var root_34 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = order__6; if linked_35 == nil { order__10 = ifn_36.Invoke_O__O(arg_37) } else { order__10 = linked_35.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_34, arg_37) } } else { var root_38 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var root_42 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref(); if linked_43 == nil { arg_41 = ifn_44.Invoke_O__O(arg_45) } else { arg_41 = linked_43.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_42, arg_45) }; if linked_39 == nil { order__10 = ifn_40.Invoke_O__O(arg_41) } else { order__10 = linked_39.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_38, arg_41) } }; var tmp1 bool; var na_46 any = n__9; var na_47 int64 = 1; if
	jrt.Long_InstanceOf(na_46) { var n0_48 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_49 int64 = na_47; tmp1 = n0_48 <= n1_49 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_46, na_47) }; if tmp1 {
		var root_51 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = f__1; var arg_55 any = xs__7; if linked_52 == nil { return ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { return linked_52.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) } } else {
//line :49:1
			var res__11 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref()).Ref(); var last_i__12 any; var root_56 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_58 lang.IFn


			if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = order__10; if linked_57 == nil { last_i__12 = ifn_58.Invoke_O__O(arg_59) } else { last_i__12 = linked_57.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_56, arg_59) }
//line :49:1
			var ___13 any; var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(res__11); var tmp3 int32 = lang.RT_IntCast_O__I_NoInit(last_i__12); var tmp4 any; var root_60 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_62 lang.IFn; _ = ___13



			if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_64 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var fnbody__69 any = A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(f__1, last_i__12, xs__7); var tmp5 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__69); A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class = fncls__68d; tmp5 = fncls__68d } else { tmp5 = fncls__68 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp5, nil); if linked_65 == nil { arg_63 = ifn_66.Invoke_O__O(arg_67) } else { arg_63 = linked_65.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_64, arg_67) }; if linked_61 == nil { tmp4 = ifn_62.Invoke_O__O(arg_63) } else { tmp4 = linked_61.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_60, arg_63) }; ___13 = lang.RT_Aset_O1_I_O__O_NoInit(tmp2, tmp3, tmp4)
//line :49:1
			var next_i__14 any; var root_70 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_72 lang.IFn




			if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = A_arbace_j2g_model_A_const_24; if linked_71 == nil { next_i__14 = ifn_72.Invoke_O__O(arg_73) } else { next_i__14 = linked_71.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_70, arg_73) }
//line :49:1
			var work__15 any; var fnbody__85 any = A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__14, xs__7, res__11); var tmp6 *jrt.Class
			var fncls__84 /*line :49:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class





			if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__85); A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class = fncls__84d; tmp6 = fncls__84d } else { tmp6 = fncls__84 }; work__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp6, nil)
//line :49:1
			var ws__16 any; var root_86 any = A_arbace_j2g_model_A_const_27.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_88 lang.IFn











			if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_90 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = n__9; var arg_94 any; var fnbody__102 any = A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(work__15); var tmp7 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__102); A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class = fncls__101d; tmp7 = fncls__101d } else { tmp7 = fncls__101 }; arg_94 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp7, nil); if linked_91 == nil { arg_89 = ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { arg_89 = linked_91.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_90, arg_93, arg_94) }; if linked_87 == nil { ws__16 = ifn_88.Invoke_O__O(arg_89) } else { ws__16 = linked_87.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_86, arg_89) }
			var root_107 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var arg_111 any = ws__16; if linked_108 == nil { ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { linked_108.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }
			var root_103 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = res__11; if linked_104 == nil { return ifn_105.Invoke_O__O(arg_106) } else { return linked_104.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_103, arg_106) } } }
//line :53:1
func A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000017_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000017_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_f; t.F_f = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var t__2 any = t.F_xs; t.F_xs = nil; tmp3 = t__2; var tmp4 any = tmp3; var tmp5 any; var t__3 any = t.F_last_i; t.F_last_i = nil; tmp5 = t__3; return tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_O__I_NoInit(tmp5))) }

func A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_j2g_model_par_mapv_work__1479000019_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_work__1479000019_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Invoke_O__O(self any) any { for { L2: for { var k__1 any; var root_74 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_76 lang.IFn
											if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = t.F_next_i; var arg_78 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); if linked_75 == nil { k__1 = ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { k__1 = linked_75.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_74, arg_77, arg_78) }
											var tmp1 bool; var na_79 any = k__1; var na_80 int64 = lang.Numbers_Dec_J__J_NoInit(int64(t.F_cnt)); if jrt.Long_InstanceOf(na_79) { var n0_81 int64 = jrt.NN(jrt.Long_Cast(na_79)).LongValue__J(); var n1_82 int64 = na_80; tmp1 = n0_81 < n1_82 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_79, na_80) }; if tmp1 { var tmp2 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(k__1)); var tmp3 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_res); var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any = t.F_xs

		lang.RT_Aset_O1_I_O__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(i__2), tmp4.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(i__2))))
		continue L2 } else {
//line :57:1
			return nil } } }; /*line :55:1*/panic("j2g: unreachable") }





func A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Invoke_O__O(self any) any { var root_95 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var fnbody__100 any = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(t.F_work); var tmp1 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__100); A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class = fncls__99d; tmp1 = fncls__99d } else { tmp1 = fncls__99 }; arg_98 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp1, nil); if linked_96 == nil { return ifn_97.Invoke_O__O(arg_98) } else { return linked_96.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_95, arg_98) } }
//line :61:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_work; t.F_work = nil; tmp1 = t_; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_j2g_model_has_QMARK__A_New() *A_arbace_j2g_model_has_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Ctor() {}
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_112 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any; var tmp1 int64; var na_116 any; var or__1927000174__auto____3 any = flags__0; if jrt.J2g_Truth(or__1927000174__auto____3) { na_116 = or__1927000174__auto____3 } else { na_116 = A_arbace_j2g_model_A_const_31 }; var na_117 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_116); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_117) }; tmp2 = tmp3; if tmp2 { var n0_118 int64 = jrt.NN(jrt.Long_Cast(na_116)).LongValue__J(); var n1_119 int64 = jrt.NN(jrt.Long_Cast(na_117)).LongValue__J(); tmp1 = n0_118 & n1_119 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_116, na_117) }; arg_115 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_113 == nil { return ifn_114.Invoke_O__O(arg_115) } else { return linked_113.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_112, arg_115) } }

func A_arbace_j2g_model_T_A_New() *A_arbace_j2g_model_T_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_T_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_j2g_model_T_A) Ctor() {}
//line :69:1
func (t *A_arbace_j2g_model_T_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_32; var x__1 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if lang.IDeref_InstanceOf(x__1) { var root_121 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = x__1; if linked_122 == nil { return ifn_123.Invoke_O__O(arg_124) } else { return linked_122.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_121, arg_124) } } else { return x__1 } }

func A_arbace_j2g_model_translated_QMARK__A_New() *A_arbace_j2g_model_translated_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_125 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any; var root_130 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_j2g_model_T_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; if linked_131 == nil { arg_128 = ifn_132.Invoke__O() } else { arg_128 = linked_131.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_130) }; var arg_129 any = n__0; if linked_126 == nil { return ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { return linked_126.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_125, arg_128, arg_129) } }

func A_arbace_j2g_model_j2g_static_QMARK__A_New() *A_arbace_j2g_model_j2g_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_49); if and__1927000168__auto____3 {





	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(base__1, Lit_50); if and__1927000168__auto____4 {
		var root_133 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = Lit_51; if linked_134 == nil { return ifn_135.Invoke_O__O(arg_136) } else { return linked_134.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_133, arg_136) } } else {
//line :79:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_jrt_class_A_New() *A_arbace_j2g_model_jrt_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Ctor() {}
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
}
func A_arbace_j2g_model_hand_written_QMARK__A_New() *A_arbace_j2g_model_hand_written_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_137 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_139 lang.IFn; if


	linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = n__0; if linked_138 == nil { and__1927000168__auto____2 = ifn_139.Invoke_O__O(arg_140) } else { and__1927000168__auto____2 = linked_138.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_137, arg_140) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_141 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var root_145 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = n__0; if linked_146 == nil { arg_144 = ifn_147.Invoke_O__O(arg_148) } else { arg_144 = linked_146.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_145, arg_148) }; if linked_142 == nil { return ifn_143.Invoke_O__O(arg_144) } else { return linked_142.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_141, arg_144) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_in_world_QMARK__A_New() *A_arbace_j2g_model_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var root_149 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = n__0; if linked_150 == nil { or__1927000174__auto____3 = ifn_151.Invoke_O__O(arg_152) } else { or__1927000174__auto____3 = linked_150.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_149, arg_152) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_153 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = n__0; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_153, arg_156) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }

func A_arbace_j2g_model_translatable_QMARK__A_New() *A_arbace_j2g_model_translatable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var root_157 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = n__0; if linked_158 == nil { tmp1 = ifn_159.Invoke_O__O(arg_160) } else { tmp1 = linked_158.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_157, arg_160) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_reflectable_interface_QMARK__A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_161 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_163 lang.IFn; if




	linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any; var root_165 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = n__0; if linked_166 == nil { arg_164 = ifn_167.Invoke_O__O(arg_168) } else { arg_164 = linked_166.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_165, arg_168) }; if linked_162 == nil { and__1927000168__auto____2 = ifn_163.Invoke_O__O(arg_164) } else { and__1927000168__auto____2 = linked_162.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_161, arg_164) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_169 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_171 lang.IFn
		if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = n__0; var arg_173 any = Lit_74; if linked_170 == nil { or__1927000174__auto____3 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { or__1927000174__auto____3 = linked_170.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_174 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = n__0; var arg_178 any = Lit_75; if linked_175 == nil { or__1927000174__auto____4 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { or__1927000174__auto____4 = linked_175.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; if jrt.J2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_179 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = n__0; var arg_183 any = Lit_76; if linked_180 == nil { or__1927000174__auto____5 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { or__1927000174__auto____5 = linked_180.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_184 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = n__0; var arg_188 any = Lit_77; if linked_185 == nil { or__1927000174__auto____6 = ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { or__1927000174__auto____6 = linked_185.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_184, arg_187, arg_188) }; if jrt.J2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			var root_189 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = n__0; var arg_193 any = Lit_78; if linked_190 == nil { and__1927000168__auto____3 = ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { and__1927000168__auto____3 = linked_190.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_189, arg_192, arg_193) } } } } }
//line :105:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_194 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_196 lang.IFn


			if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any; var root_198 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = n__0; var arg_202 any = Lit_79; if linked_199 == nil { arg_197 = ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { arg_197 = linked_199.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }; if linked_195 == nil { and__1927000168__auto____4 = ifn_196.Invoke_O__O(arg_197) } else { and__1927000168__auto____4 = linked_195.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_194, arg_197) }
//line :105:1
			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_203 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_205 lang.IFn



				if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var root_207 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = n__0; if linked_208 == nil { arg_206 = ifn_209.Invoke_O__O(arg_210) } else { arg_206 = linked_208.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_207, arg_210) }; if linked_204 == nil { and__1927000168__auto____5 = ifn_205.Invoke_O__O(arg_206) } else { and__1927000168__auto____5 = linked_204.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_203, arg_206) }
//line :105:1
				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_211 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_213 lang.IFn




					if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = n__0; if linked_212 == nil { and__1927000168__auto____6 = ifn_213.Invoke_O__O(arg_214) } else { and__1927000168__auto____6 = linked_212.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_211, arg_214) }
//line :105:1
					if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_215 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_217 lang.IFn






						if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var root_219 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_224 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = n__0; if linked_225 == nil { tmp2 = ifn_226.Invoke_O__O(arg_227) } else { tmp2 = linked_225.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_224, arg_227) }; arg_222 = tmp1.Invoke_O__O(tmp2); var arg_223 any = A_arbace_j2g_model_A_const_47; if linked_220 == nil { arg_218 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { arg_218 = linked_220.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; if linked_216 == nil { and__1927000168__auto____7 = ifn_217.Invoke_O__O(arg_218) } else { and__1927000168__auto____7 = linked_216.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_215, arg_218) }
//line :105:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_228 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_230 lang.IFn









							if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp4 any; var root_232 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = n__0; if linked_233 == nil { tmp4 = ifn_234.Invoke_O__O(arg_235) } else { tmp4 = linked_233.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_232, arg_235) }; arg_231 = tmp3.Invoke_O__O(tmp4); if linked_229 == nil { and__1927000168__auto____8 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____8 = linked_229.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_228, arg_231) }
//line :105:1
							if jrt.J2g_Truth(and__1927000168__auto____8) {










								var root_236 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any; var fnbody__250 any = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New(); var tmp5 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class = fncls__249d; tmp5 = fncls__249d } else { tmp5 = fncls__249 }; arg_239 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__250, tmp5, nil); var arg_240 any; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_53; var tmp7 any; var root_251 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = n__0; if linked_252 == nil { tmp7 = ifn_253.Invoke_O__O(arg_254) } else { tmp7 = linked_252.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_251, arg_254) }; arg_240 = tmp6.Invoke_O__O(tmp7); if linked_237 == nil { return ifn_238.Invoke_O_O__O(arg_239, arg_240) } else { return linked_237.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_236, arg_239, arg_240) } } else {
//line :105:1
									return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Invoke_O_O__O(self, p1__1479000034_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_241 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = p1__1479000034_SHARP___1; if linked_242 == nil { or__1927000174__auto____2 = ifn_243.Invoke_O__O(arg_244) } else { or__1927000174__auto____2 = linked_242.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_241, arg_244) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_245 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = p1__1479000034_SHARP___1; if linked_246 == nil { return ifn_247.Invoke_O__O(arg_248) } else { return linked_246.(*A_arbace_j2g_model_reflectable_interface_QMARK__A).Invoke_O_O__O(root_245, arg_248) } } }

func A_arbace_j2g_model_reflected_QMARK__A_New() *A_arbace_j2g_model_reflected_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_255 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_257 lang.IFn; if


	linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = n__0; if linked_256 == nil { and__1927000168__auto____2 = ifn_257.Invoke_O__O(arg_258) } else { and__1927000168__auto____2 = linked_256.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_255, arg_258) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_259 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any; var root_263 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = n__0; if linked_264 == nil { arg_262 = ifn_265.Invoke_O__O(arg_266) } else { arg_262 = linked_264.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_263, arg_266) }; if linked_260 == nil { return ifn_261.Invoke_O__O(arg_262) } else { return linked_260.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_259, arg_262) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_info_A_New() *A_arbace_j2g_model_info_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_info_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_j2g_model_info_A) Ctor() {}
//line :123:1
func (t *A_arbace_j2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { var root_267 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = n__0; if linked_268 == nil { return ifn_269.Invoke_O__O(arg_270) } else { return linked_268.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_267, arg_270) } }
func A_arbace_j2g_model_interface_QMARK__A_New() *A_arbace_j2g_model_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Ctor() {}
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_271 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = n__0; if linked_272 == nil { return ifn_273.Invoke_O__O(arg_274) } else { return linked_272.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_271, arg_274) } }

func A_arbace_j2g_model_desc_classes_A_New() *A_arbace_j2g_model_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(d__0, nil) { return nil } else { var tmp1 any; var root_275 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_277 lang.IFn
		if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = d__0; if linked_276 == nil { tmp1 = ifn_277.Invoke_O__O(arg_278) } else { tmp1 = linked_276.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_275, arg_278) }
//line :129:1
		if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var root_279 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_281 lang.IFn

			if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = d__0; if linked_280 == nil { tmp2 = ifn_281.Invoke_O__O(arg_282) } else { tmp2 = linked_280.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_279, arg_282) }
//line :129:1
			if jrt.J2g_Truth(tmp2) {

				var root_283 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var root_287 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = d__0; var arg_291 any; var root_292 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = d__0; if linked_293 == nil { arg_291 = ifn_294.Invoke_O__O(arg_295) } else { arg_291 = linked_293.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_292, arg_295) }; if linked_288 == nil { arg_286 = ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { arg_286 = linked_288.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) }; if linked_284 == nil { return ifn_285.Invoke_O__O(arg_286) } else { return linked_284.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_283, arg_286) } } else {
//line :129:1
					var tmp3 any; var root_296 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_298 lang.IFn


					if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = d__0; if linked_297 == nil { tmp3 = ifn_298.Invoke_O__O(arg_299) } else { tmp3 = linked_297.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_296, arg_299) }
//line :129:1
					if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_300 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_302 lang.IFn


						if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = d__0; if linked_301 == nil { tmp4 = ifn_302.Invoke_O__O(arg_303) } else { tmp4 = linked_301.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_300, arg_303) }
//line :129:1
						return lang.Tuple_Create_O__IPersistentVector(tmp4) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil
						}
						}
				}
		}
	}
}



func A_arbace_j2g_model_method_desc_classes_A_New() *A_arbace_j2g_model_method_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_304 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_306 lang.IFn; if
											linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = desc__0; if linked_305 == nil { tmp1 = ifn_306.Invoke_O__O(arg_307) } else { tmp1 = linked_305.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_304, arg_307) }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Get_O__O(desc__0) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var vec__1479000042__3 any; var root_308 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_310 lang.IFn
												if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = desc__0; if linked_309 == nil { vec__1479000042__3 = ifn_310.Invoke_O__O(arg_311) } else { vec__1479000042__3 = linked_309.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_308, arg_311) }
//line :140:1
		var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(1), nil); var v__6 any; var root_312 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_314 lang.IFn

		if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var tmp4 any; var root_321 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = r__5; var arg_325 any = ps__4; if linked_322 == nil { tmp4 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { tmp4 = linked_322.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }; arg_315 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_313 == nil { v__6 = ifn_314.Invoke_O__O(arg_315) } else { v__6 = linked_313.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_312, arg_315) }
		var tmp5 any; var root_326 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = desc__0; if linked_327 == nil { tmp5 = ifn_328.Invoke_O__O(arg_329) } else { tmp5 = linked_327.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_326, arg_329) }; if jrt.J2g_Truth(tmp5) { jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Put_O_O__O(desc__0, v__6) }
//line :140:1
		return v__6 } }





func A_arbace_j2g_model_erased_desc_QMARK__A_New() *A_arbace_j2g_model_erased_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_330 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_332 lang.IFn; if




	linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = d__0; if linked_331 == nil { and__1927000168__auto____2 = ifn_332.Invoke_O__O(arg_333) } else { and__1927000168__auto____2 = linked_331.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_330, arg_333) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__343 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class
		if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__343); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class = fncls__342d; tmp2 = fncls__342d } else { tmp2 = fncls__342 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__343, tmp2, nil); e__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :151:1
		var and__1927000168__auto____4 any; var root_344 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_346 lang.IFn

		if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = e__3; if linked_345 == nil { and__1927000168__auto____4 = ifn_346.Invoke_O__O(arg_347) } else { and__1927000168__auto____4 = linked_345.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_344, arg_347) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var n__5 any; var root_348 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_350 lang.IFn
			if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = e__3; if linked_349 == nil { n__5 = ifn_350.Invoke_O__O(arg_351) } else { n__5 = linked_349.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_348, arg_351) }
//line :153:1
			var and__1927000168__auto____6 any; var root_352 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_354 lang.IFn

			if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any; var root_356 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = n__5; if linked_357 == nil { arg_355 = ifn_358.Invoke_O__O(arg_359) } else { arg_355 = linked_357.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_356, arg_359) }; if linked_353 == nil { and__1927000168__auto____6 = ifn_354.Invoke_O__O(arg_355) } else { and__1927000168__auto____6 = linked_353.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_352, arg_355) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
				var root_360 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any; var fnbody__371 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(n__5); var tmp3 *jrt.Class; var fncls__370 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class; if fncls__370 == nil { var fncls__370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__371); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class = fncls__370d; tmp3 = fncls__370d } else { tmp3 = fncls__370 }; arg_363 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__371, tmp3, nil); var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_69; var arg_364 any = tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if linked_361 == nil { return ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { return linked_361.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) } } else {
//line :155:1
					return and__1927000168__auto____6 } } else {
//line :153:1
						return and__1927000168__auto____4 } } else {
//line :151:1
							return and__1927000168__auto____2 } }
func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { var tmp1 any; var root_334 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = d__1; if linked_335 == nil { tmp1 = ifn_336.Invoke_O__O(arg_337) } else { tmp1 = linked_335.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_334, arg_337) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_338 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = d__1; if linked_339 == nil { tmp2 = ifn_340.Invoke_O__O(arg_341) } else { tmp2 = linked_339.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_338, arg_341) }; d__1 = tmp2; continue L1 } else { return d__1 } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A{}; t.Ctor_O(p0); return t }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Invoke_O_O__O(self, p1__1479000046_SHARP___1 any) any { var root_365 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = t.F_n; var arg_369 any = p1__1479000046_SHARP___1; if linked_366 == nil { return ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { return linked_366.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_365, arg_368, arg_369) } }

func A_arbace_j2g_model_desc_in_world_QMARK__A_New() *A_arbace_j2g_model_desc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var root_372 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_376 any; var root_377 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = d__0; if linked_378 == nil { arg_376 = ifn_379.Invoke_O__O(arg_380) } else { arg_376 = linked_378.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_377, arg_380) }; if linked_373 == nil { return ifn_374.Invoke_O_O__O(arg_375, arg_376) } else { return linked_373.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_372, arg_375, arg_376) } }
func A_arbace_j2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_j2g_model_mdesc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { var root_381 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_385 any; var root_386 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, A_arbace_j2g_model_method_desc_classes_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = desc__0; if linked_387 == nil { arg_385 = ifn_388.Invoke_O__O(arg_389) } else { arg_385 = linked_387.(*A_arbace_j2g_model_method_desc_classes_A).Invoke_O_O__O(root_386, arg_389) }; if linked_382 == nil { return ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { return linked_382.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_381, arg_384, arg_385) } }




func A_arbace_j2g_model_go_name_A_New() *A_arbace_j2g_model_go_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_name_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; if




	jrt.J2g_Truth(A_arbace_j2g_model_A_const_33.Get__O()) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2; var tmp2 any; var root_390 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_392 lang.IFn
			if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = n__0; if linked_391 == nil { tmp2 = ifn_392.Invoke_O__O(arg_393) } else { tmp2 = linked_391.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_390, arg_393) }; if jrt.J2g_Truth(tmp2) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = A_arbace_j2g_model_A_const_71.Invoke_O__O(jc__3) } } else {
//line :170:1
				or__1927000174__auto____2 = nil } } else {
//line :169:1
					or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						var root_394 any = A_arbace_j2g_model_A_const_72.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = n__0; if linked_395 == nil { return ifn_396.Invoke_O__O(arg_397) } else { return linked_395.(*aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_394, arg_397) } } }
func A_arbace_j2g_model_pkg_A_New() *A_arbace_j2g_model_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pkg_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { var root_398 any = A_arbace_j2g_model_A_const_73.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = n__0; if linked_399 == nil { return ifn_400.Invoke_O__O(arg_401) } else { return linked_399.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_398, arg_401) } }

func A_arbace_j2g_model_abstract_QMARK__A_New() *A_arbace_j2g_model_abstract_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Ctor() {}
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_402 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_407 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_j2g_model_info_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = n__0; if linked_408 == nil { tmp2 = ifn_409.Invoke_O__O(arg_410) } else { tmp2 = linked_408.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_407, arg_410) }; arg_405 = tmp1.Invoke_O__O(tmp2); var arg_406 any = A_arbace_j2g_model_A_const_75; if linked_403 == nil { return ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { return linked_403.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_402, arg_405, arg_406) } }
func A_arbace_j2g_model_final_QMARK__A_New() *A_arbace_j2g_model_final_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_411 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_416 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_j2g_model_info_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = n__0; if linked_417 == nil { tmp2 = ifn_418.Invoke_O__O(arg_419) } else { tmp2 = linked_417.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_416, arg_419) }; arg_414 = tmp1.Invoke_O__O(tmp2); var arg_415 any = A_arbace_j2g_model_A_const_76; if linked_412 == nil { return ifn_413.Invoke_O_O__O(arg_414, arg_415) } else { return linked_412.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_411, arg_414, arg_415) } }

func A_arbace_j2g_model_subclasses_A_New() *A_arbace_j2g_model_subclasses_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_subclasses_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Ctor() {}
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_77; return lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())).Invoke__O(), n__0)
}
func A_arbace_j2g_model_make_subclass_index_A_New() *A_arbace_j2g_model_make_subclass_index_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Ctor() {}
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any; var root_420 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_422 lang.IFn; if
											linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any; if linked_421 == nil { cache__2 = ifn_422.Invoke_O__O(arg_423) } else { cache__2 = linked_421.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_420, arg_423) }; var fnbody__484 any =
											A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(cache__2, w__0); var tmp1 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__484); A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class = fncls__483d; tmp1 = fncls__483d } else { tmp1 = fncls__483 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__484, tmp1, nil) }
//line :185:1
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_424 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_426 lang.IFn; if
												linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = t.F_cache; if linked_425 == nil { or__1927000174__auto____1 = ifn_426.Invoke_O__O(arg_427) } else { or__1927000174__auto____1 = linked_425.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_424, arg_427) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var root_428 any = A_arbace_j2g_model_A_const_78.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = t.F_cache; var arg_432 any; var root_474 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_476 lang.IFn
													if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_33, t.F_w); if linked_475 == nil { ifn_476.Invoke_O__O(arg_477) } else { linked_475.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_474, arg_477) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__473 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(t.F_w); var tmp2 *jrt.Class; var fncls__472 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class; if fncls__472 == nil { var fncls__472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__473); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class = fncls__472d; tmp2 = fncls__472d } else { tmp2 = fncls__472 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__473, tmp2, nil); arg_432 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
//line :187:1
		if linked_429 == nil { return ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { return linked_429.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_428, arg_431, arg_432) } } }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(p0 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var root_433 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any; var fnbody__456 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New(); var tmp2 *jrt.Class; var fncls__455 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class; if fncls__455 == nil { var fncls__455d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class = fncls__455d; tmp2 = fncls__455d } else { tmp2 = fncls__455 }; arg_436 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__456, tmp2, nil); var arg_437 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_438 any; var root_457 any = A_arbace_j2g_model_A_const_83.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_459 lang.IFn


		if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var root_462 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, A_arbace_j2g_model_T_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; if linked_463 == nil { arg_460 = ifn_464.Invoke__O() } else { arg_460 = linked_463.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_462) }; var arg_461 any; var root_465 any = A_arbace_j2g_model_A_const_84.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_37; var tmp4 any; var t_ any = t.F_w; t.F_w = nil; tmp4 = t_; arg_468 = tmp3.Invoke_O__O(tmp4); if linked_466 == nil { arg_461 = ifn_467.Invoke_O__O(arg_468) } else { arg_461 = linked_466.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_465, arg_468) }; if linked_458 == nil { arg_438 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { arg_438 = linked_458.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }
//line :189:1
		if linked_434 == nil { tmp1 = ifn_435.Invoke_O_O_O__O(arg_436, arg_437, arg_438) } else { tmp1 = linked_434.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_433, arg_436, arg_437, arg_438) } }
//line :188:1
	return nil }(); var root_469 any = A_arbace_j2g_model_A_const_85.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; if linked_470 == nil { ifn_471.Invoke__O() } else { linked_470.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_469) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New() *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var s__3 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_439 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, A_arbace_j2g_model_info_A_fn_class); var ifn_441 lang.IFn; if
																		linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = c__2; if linked_440 == nil { tmp2 = ifn_441.Invoke_O__O(arg_442) } else { tmp2 = linked_440.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_439, arg_442) }; s__3 = tmp1.Invoke_O__O(tmp2); if
																		jrt.J2g_Truth(s__3) { var root_443 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = m__1; var arg_447 any = s__3; var arg_448 any; var root_450 any = A_arbace_j2g_model_A_const_82.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var arg_454 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_451 == nil { arg_448 = ifn_452.Invoke_O_O__O(arg_453, arg_454) } else { arg_448 = linked_451.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_450, arg_453, arg_454) }; var arg_449 any = c__2; if linked_444 == nil { return ifn_445.Invoke_O_O_O_O__O(arg_446, arg_447, arg_448, arg_449) } else { return linked_444.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_443, arg_446, arg_447, arg_448, arg_449) } } else { return m__1 } }


















































func A_arbace_j2g_model_leaf_QMARK__A_New() *A_arbace_j2g_model_leaf_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Ctor() {}
//line :242:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_485 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_487 lang.IFn

		if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = n__0; if linked_486 == nil { tmp1 = ifn_487.Invoke_O__O(arg_488) } else { tmp1 = linked_486.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_485, arg_488) }
//line :247:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var root_489 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_491 lang.IFn


			if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = n__0; if linked_490 == nil { tmp2 = ifn_491.Invoke_O__O(arg_492) } else { tmp2 = linked_490.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_489, arg_492) }
//line :247:1
			if jrt.J2g_Truth(tmp2) {


				var root_493 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any; var root_497 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_90; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_500 any = tmp3.Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_501 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28); var tmp6 any; var root_502 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, A_arbace_j2g_model_go_name_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = n__0; if linked_503 == nil { tmp6 = ifn_504.Invoke_O__O(arg_505) } else { tmp6 = linked_503.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_502, arg_505) }; arg_501 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_498 == nil { arg_496 = ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { arg_496 = linked_498.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_497, arg_500, arg_501) }; if linked_494 == nil { return ifn_495.Invoke_O__O(arg_496) } else { return linked_494.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_493, arg_496) } } else {
//line :247:1
					if A_arbace_j2g_model_A_const_60 != nil { var and__1927000168__auto____2 any; var root_506 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_508 lang.IFn



						if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any; var root_510 any = A_arbace_j2g_model_A_const_93.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_j2g_model_abstract_QMARK__A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = n__0; if linked_511 == nil { arg_509 = ifn_512.Invoke_O__O(arg_513) } else { arg_509 = linked_511.(*A_arbace_j2g_model_abstract_QMARK__A).Invoke_O_O__O(root_510, arg_513) }; if linked_507 == nil { and__1927000168__auto____2 = ifn_508.Invoke_O__O(arg_509) } else { and__1927000168__auto____2 = linked_507.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_506, arg_509) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_514 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any; var root_518 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, A_arbace_j2g_model_subclasses_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = n__0; if linked_519 == nil { arg_517 = ifn_520.Invoke_O__O(arg_521) } else { arg_517 = linked_519.(*A_arbace_j2g_model_subclasses_A).Invoke_O_O__O(root_518, arg_521) }; if linked_515 == nil { and__1927000168__auto____3 = ifn_516.Invoke_O__O(arg_517) } else { and__1927000168__auto____3 = linked_515.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_514, arg_517) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
							var root_522 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_95.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_526 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any; var root_530 any = A_arbace_j2g_model_A_const_96.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = n__0; if linked_531 == nil { arg_529 = ifn_532.Invoke_O__O(arg_533) } else { arg_529 = linked_531.(*A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_530, arg_533) }; if linked_527 == nil { arg_525 = ifn_528.Invoke_O__O(arg_529) } else { arg_525 = linked_527.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_526, arg_529) } } else { arg_525 = and__1927000168__auto____4 }; if linked_523 == nil { return ifn_524.Invoke_O__O(arg_525) } else { return linked_523.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_522, arg_525) } } else {
//line :251:1
								return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :247:1
									return nil
								}
				}
		}
	}
}




func A_arbace_j2g_model_qualify_A_New() *A_arbace_j2g_model_qualify_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_qualify_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_j2g_model_qualify_A) Ctor() {}
//line :257:1
func (t *A_arbace_j2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z_NoInit(from__0, nil) }; if tmp1 { var root_534 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = ident__2; if linked_535 == nil { return ifn_536.Invoke_O__O(arg_537) } else { return linked_535.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_534, arg_537) } } else { var root_538 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var root_543 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = of__1; if linked_544 == nil { arg_541 = ifn_545.Invoke_O__O(arg_546) } else { arg_541 = linked_544.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A).Invoke_O_O__O(root_543, arg_546) }; var arg_542 any = ident__2; if linked_539 == nil { return ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { return linked_539.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_538, arg_541, arg_542)
	} } }
func A_arbace_j2g_model_class_sym_A_New() *A_arbace_j2g_model_class_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_sym_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_j2g_model_class_sym_A) Ctor() {}
//line :262:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	var root_547 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_j2g_model_qualify_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = from__0; var arg_551 any; var root_553 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, A_arbace_j2g_model_pkg_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = n__1; if linked_554 == nil { arg_551 = ifn_555.Invoke_O__O(arg_556) } else { arg_551 = linked_554.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_553, arg_556) }; var arg_552 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_557 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_j2g_model_go_name_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = n__1; if linked_558 == nil { tmp2 = ifn_559.Invoke_O__O(arg_560) } else { tmp2 = linked_558.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_557, arg_560) }; arg_552 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, suffix__2)).Ref(); if linked_548 == nil { return ifn_549.Invoke_O_O_O__O(arg_550, arg_551, arg_552) } else { return linked_548.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_547, arg_550, arg_551, arg_552) } }
//line :262:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	var root_561 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = from__0; var arg_565 any = n__1; var arg_566 any = Lit_13; if linked_562 == nil { return ifn_563.Invoke_O_O_O__O(arg_564, arg_565, arg_566) } else { return linked_562.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_561, arg_564, arg_565, arg_566)
	}
}
func A_arbace_j2g_model_jrt_sym_A_New() *A_arbace_j2g_model_jrt_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_j2g_model_jrt_sym_A) Ctor() {}
//line :267:1
func (t *A_arbace_j2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { var root_567 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, A_arbace_j2g_model_qualify_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = from__0; var arg_571 any = A_arbace_j2g_model_A_const_91; var arg_572 any = ident__1; if linked_568 == nil { return ifn_569.Invoke_O_O_O__O(arg_570, arg_571, arg_572) } else { return linked_568.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_567, arg_570, arg_571, arg_572) } }






func A_arbace_j2g_model_array_test_A_New() *A_arbace_j2g_model_array_test_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_array_test_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_j2g_model_array_test_A) Ctor() {}
//line :274:1
func (t *A_arbace_j2g_model_array_test_A) Invoke_O_O_O_O_O_O__O(self, from__0, kind__1, x__2, d__3, comp__4 any) any { var e__6 any; var root_573 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_575 lang.IFn; if






	linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = d__3; if linked_574 == nil { e__6 = ifn_575.Invoke_O__O(arg_576) } else { e__6 = linked_574.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_573, arg_576) }; var suffix__7 any; if
	lang.Util_Equiv_O_O__Z_NoInit(kind__1, A_arbace_j2g_model_A_const_102) { suffix__7 = Lit_7 } else { suffix__7 = Lit_8 }; var tmp1 any; var root_577 any =
	A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_579 lang.IFn; if
	linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = e__6; if linked_578 == nil { tmp1 = ifn_579.Invoke_O__O(arg_580) } else { tmp1 = linked_578.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_577, arg_580) }; if /*line :283:1*/ jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp3 any; var root_581 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = from__0; var arg_585 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_106.GetRawRoot__O()).Invoke_O__O(e__6), suffix__7)).Ref(); if linked_582 == nil { tmp3 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { tmp3 = linked_582.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }; return tmp2.Invoke_O_O__O(tmp3, x__2) } else {
//line :283:1
			if lang.Util_Equiv_O_O__Z_NoInit(e__6, Lit_9) {

				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp5 any; var root_586 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = from__0; var arg_590 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_587 == nil { tmp5 = ifn_588.Invoke_O_O__O(arg_589, arg_590) } else { tmp5 = linked_587.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_586, arg_589, arg_590) }; return tmp4.Invoke_O_O__O(tmp5, x__2) } else {
//line :283:1
					if A_arbace_j2g_model_A_const_60 != nil {


						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp7 any; var root_591 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = from__0; var arg_595 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_592 == nil { tmp7 = ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { tmp7 = linked_592.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_591, arg_594, arg_595) }; return tmp6.Invoke_O_O_O__O(tmp7, x__2, comp__4) } else {
//line :283:1
							return nil } } } }




func A_arbace_j2g_model_go_type_A_New() *A_arbace_j2g_model_go_type_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_type_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_j2g_model_go_type_A) Ctor() {}
//line :288:1
func (t *A_arbace_j2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, A_arbace_j2g_model_A_const_107) { return A_arbace_j2g_model_A_const_108 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_109.GetRawRoot__O()).Invoke_O__O(d__1)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_109.GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :291:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_27) { return nil } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_9) { return A_arbace_j2g_model_A_const_110 } else { var tmp1 any; var root_596 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_598 lang.IFn




				if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = d__1; if linked_597 == nil { tmp1 = ifn_598.Invoke_O__O(arg_599) } else { tmp1 = linked_597.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_596, arg_599) }
//line :291:1
				if jrt.J2g_Truth(tmp1) { var e__3 any; var root_600 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_602 lang.IFn




					if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = d__1; if linked_601 == nil { e__3 = ifn_602.Invoke_O__O(arg_603) } else { e__3 = linked_601.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_600, arg_603) }
					var tmp2 any; var root_604 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = e__3; if linked_605 == nil { tmp2 = ifn_606.Invoke_O__O(arg_607) } else { tmp2 = linked_605.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_604, arg_607) }; if jrt.J2g_Truth(tmp2) {
						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_116; var tmp5 any; var root_652 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = from__0; var arg_656 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_106.GetRawRoot__O()).Invoke_O__O(e__3); if linked_653 == nil { tmp5 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { tmp5 = linked_653.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_A_const_117; var tmp8 any; var root_657 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = from__0; var arg_661 any = Lit_11; if linked_658 == nil { tmp8 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { tmp8 = linked_658.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } } else {
//line :291:1
								var tmp9 any; var root_608 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_610 lang.IFn








								if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = d__1; if linked_609 == nil { tmp9 = ifn_610.Invoke_O__O(arg_611) } else { tmp9 = linked_609.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_608, arg_611) }
//line :291:1
								if jrt.J2g_Truth(tmp9) { var n__3 any; var root_612 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_614 lang.IFn









									if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = d__1; if linked_613 == nil { n__3 = ifn_614.Invoke_O__O(arg_615) } else { n__3 = linked_613.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_612, arg_615) }
									var tmp10 any; var root_616 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_618 lang.IFn
									if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var root_620 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = n__3; if linked_621 == nil { arg_619 = ifn_622.Invoke_O__O(arg_623) } else { arg_619 = linked_621.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_620, arg_623) }; if linked_617 == nil { tmp10 = ifn_618.Invoke_O__O(arg_619) } else { tmp10 = linked_617.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_616, arg_619) }
//line :302:1
									if jrt.J2g_Truth(tmp10) { return A_arbace_j2g_model_A_const_111 } else { var tmp11 any; var root_624 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_626 lang.IFn

										if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = n__3; if linked_625 == nil { tmp11 = ifn_626.Invoke_O__O(arg_627) } else { tmp11 = linked_625.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_624, arg_627) }
//line :302:1
										if jrt.J2g_Truth(tmp11) {

											var root_628 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = from__0; var arg_632 any = n__3; if linked_629 == nil { return ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { return linked_629.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_628, arg_631, arg_632) } } else {
//line :302:1
												var tmp12 any; var root_633 any = A_arbace_j2g_model_A_const_112.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_635 lang.IFn


												if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = n__3; if linked_634 == nil { tmp12 = ifn_635.Invoke_O__O(arg_636) } else { tmp12 = linked_634.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_633, arg_636) }
//line :302:1
												if jrt.J2g_Truth(tmp12) {


													var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_model_A_const_118; var tmp15 any; var root_662 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = from__0; var arg_666 any = n__3; if linked_663 == nil { tmp15 = ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { tmp15 = linked_663.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }; return tmp13.Invoke_O_O__O(tmp14, tmp15) } else {
//line :302:1
														if A_arbace_j2g_model_A_const_60 != nil {



															var root_637 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = from__0; var arg_641 any = n__3; var arg_642 any = Lit_28; if linked_638 == nil { return ifn_639.Invoke_O_O_O__O(arg_640, arg_641, arg_642) } else { return linked_638.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_637, arg_640, arg_641, arg_642) } } else {
//line :302:1
																return nil } } } } } else {
//line :291:1
																	if A_arbace_j2g_model_A_const_60 != nil { var tmp16 any; var root_643 any = A_arbace_j2g_model_A_const_113.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_645 lang.IFn















																		if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_114.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); var arg_647 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_115, d__1)); if linked_644 == nil { tmp16 = ifn_645.Invoke_O_O__O(arg_646, arg_647) } else { tmp16 = linked_644.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_643, arg_646, arg_647) }
//line :291:1
																		panic(jrt.Thrown(jrt.Throwable_Cast(tmp16))) } else { return nil
																		}
																}
							}
			}
			}
		}
	}
}









func A_arbace_j2g_model_pointer_desc_QMARK__A_New() *A_arbace_j2g_model_pointer_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_667 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = d__0; if linked_668 == nil { tmp1 = ifn_669.Invoke_O__O(arg_670) } else { tmp1 = linked_668.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_671 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_673 lang.IFn
		if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = d__0; if linked_672 == nil { tmp2 = ifn_673.Invoke_O__O(arg_674) } else { tmp2 = linked_672.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_671, arg_674) }
//line :312:1
		if jrt.J2g_Truth(tmp2) { var n__2 any; var root_675 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_677 lang.IFn
			if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = d__0; if linked_676 == nil { n__2 = ifn_677.Invoke_O__O(arg_678) } else { n__2 = linked_676.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_675, arg_678) }
//line :312:1
			var and__1927000168__auto____3 any; var root_679 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_681 lang.IFn

			if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = n__2; if linked_680 == nil { and__1927000168__auto____3 = ifn_681.Invoke_O__O(arg_682) } else { and__1927000168__auto____3 = linked_680.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_679, arg_682) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_683 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var root_687 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = n__2; if linked_688 == nil { arg_686 = ifn_689.Invoke_O__O(arg_690) } else { arg_686 = linked_688.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_687, arg_690) }; if linked_684 == nil { and__1927000168__auto____4 = ifn_685.Invoke_O__O(arg_686) } else { and__1927000168__auto____4 = linked_684.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_683, arg_686) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_691 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_693 lang.IFn; if linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = n__2; var arg_695 any = Lit_30; if linked_692 == nil { and__1927000168__auto____5 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { and__1927000168__auto____5 = linked_692.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_696 any = A_arbace_j2g_model_A_const_112.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = n__2; if linked_697 == nil { return ifn_698.Invoke_O__O(arg_699) } else { return linked_697.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_696, arg_699) } } else {
//line :314:1
					return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :312:1
						if A_arbace_j2g_model_A_const_60 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
						}
					}
	}
}

func A_arbace_j2g_model_iface_desc_QMARK__A_New() *A_arbace_j2g_model_iface_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Ctor() {}
//line :318:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_700 any = A_arbace_j2g_model_A_const_120.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_702 lang.IFn; if


	linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = d__0; if linked_701 == nil { and__1927000168__auto____2 = ifn_702.Invoke_O__O(arg_703) } else { and__1927000168__auto____2 = linked_701.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_700, arg_703) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_704 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = d__0; var arg_708 any = A_arbace_j2g_model_A_const_107; if linked_705 == nil { and__1927000168__auto____3 = ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { and__1927000168__auto____3 = linked_705.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_704, arg_707, arg_708) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_709 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any; var root_713 any = A_arbace_j2g_model_A_const_121.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = d__0; if linked_714 == nil { arg_712 = ifn_715.Invoke_O__O(arg_716) } else { arg_712 = linked_714.(*A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_713, arg_716) }; if linked_710 == nil { return ifn_711.Invoke_O__O(arg_712) } else { return linked_710.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_709, arg_712) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_model_static_QMARK__A_New() *A_arbace_j2g_model_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_j2g_model_static_QMARK__A) Ctor() {}
//line :326:1
func (t *A_arbace_j2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_717 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_721 any = A_arbace_j2g_model_A_const_122; if linked_718 == nil { return ifn_719.Invoke_O_O__O(arg_720, arg_721) } else { return linked_718.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_717, arg_720, arg_721) } }
func A_arbace_j2g_model_private_QMARK__A_New() *A_arbace_j2g_model_private_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_j2g_model_private_QMARK__A) Ctor() {}
//line :327:1
func (t *A_arbace_j2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_722 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_726 any = A_arbace_j2g_model_A_const_123; if linked_723 == nil { return ifn_724.Invoke_O_O__O(arg_725, arg_726) } else { return linked_723.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_722, arg_725, arg_726) } }
func A_arbace_j2g_model_abstract_m_QMARK__A_New() *A_arbace_j2g_model_abstract_m_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Ctor() {}
//line :328:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_727 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_731 any = A_arbace_j2g_model_A_const_75; if linked_728 == nil { return ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { return linked_728.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_727, arg_730, arg_731) } }

func A_arbace_j2g_model_methods_of_A_New() *A_arbace_j2g_model_methods_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_methods_of_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_j2g_model_methods_of_A) Ctor() {}
//line :330:1
func (t *A_arbace_j2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp2 any; var root_732 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, A_arbace_j2g_model_info_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = n__0; if linked_733 == nil { tmp2 = ifn_734.Invoke_O__O(arg_735) } else { tmp2 = linked_733.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_732, arg_735) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_j2g_model_fields_of_A_New() *A_arbace_j2g_model_fields_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fields_of_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_j2g_model_fields_of_A) Ctor() {}
//line :331:1
func (t *A_arbace_j2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_124; var tmp2 any; var root_736 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, A_arbace_j2g_model_info_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = n__0; if linked_737 == nil { tmp2 = ifn_738.Invoke_O__O(arg_739) } else { tmp2 = linked_737.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_736, arg_739) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_find_method_A_New() *A_arbace_j2g_model_find_method_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_A{}; t.Ctor(); return t }
//line :333:1
func (t *A_arbace_j2g_model_find_method_A) Ctor() {}
//line :333:1
func (t *A_arbace_j2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var root_740 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var fnbody__746 any = A_arbace_j2g_model_find_method_fn__1479000080_A_New_O_O(name__1, desc__2); var tmp1 *jrt.Class; var fncls__745 *jrt.Class = A_arbace_j2g_model_find_method_fn__1479000080_A_fn_class; if fncls__745 == nil { var fncls__745d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__746); A_arbace_j2g_model_find_method_fn__1479000080_A_fn_class = fncls__745d; tmp1 = fncls__745d } else { tmp1 = fncls__745 }; arg_743 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__746, tmp1, nil); var arg_744 any; var root_747 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = n__0; if linked_748 == nil { arg_744 = ifn_749.Invoke_O__O(arg_750) } else { arg_744 = linked_748.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_747, arg_750) }; if linked_741 == nil { return ifn_742.Invoke_O_O__O(arg_743, arg_744) } else { return linked_741.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_740, arg_743, arg_744) } }
//line :334:1
func A_arbace_j2g_model_find_method_fn__1479000080_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_find_method_fn__1479000080_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_fn__1479000080_A{}; t.Ctor_O_O(p0, p1); return t }
//line :334:1
func (t *A_arbace_j2g_model_find_method_fn__1479000080_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :334:1
func (t *A_arbace_j2g_model_find_method_fn__1479000080_A) Invoke_O_O__O(self, p1__1479000079_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_model_A_const_125.Invoke_O__O(p1__1479000079_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_model_A_const_115.Invoke_O__O(p1__1479000079_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1479000079_SHARP___1 } else { return nil } }

func A_arbace_j2g_model_virtual_member_QMARK__A_New() *A_arbace_j2g_model_virtual_member_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :336:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Ctor() {}
//line :336:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any; var root_751 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_753 lang.IFn; if


	linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any; var root_755 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = m__0; if linked_756 == nil { arg_754 = ifn_757.Invoke_O__O(arg_758) } else { arg_754 = linked_756.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_755, arg_758) }; if linked_752 == nil { and__1927000168__auto____2 = ifn_753.Invoke_O__O(arg_754) } else { and__1927000168__auto____2 = linked_752.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_751, arg_754) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_759 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var root_763 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = m__0; if linked_764 == nil { arg_762 = ifn_765.Invoke_O__O(arg_766) } else { arg_762 = linked_764.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_763, arg_766) }; if linked_760 == nil { and__1927000168__auto____3 = ifn_761.Invoke_O__O(arg_762) } else { and__1927000168__auto____3 = linked_760.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_759, arg_762) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_767 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = Lit_43; var arg_771 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(m__0); if linked_768 == nil { and__1927000168__auto____4 = ifn_769.Invoke_O_O__O(arg_770, arg_771) } else { and__1927000168__auto____4 = linked_768.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_767, arg_770, arg_771) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_772 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = Lit_42; var arg_776 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(m__0); if linked_773 == nil { return ifn_774.Invoke_O_O__O(arg_775, arg_776) } else { return linked_773.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_772, arg_775, arg_776) } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_model_supertypes_A_New() *A_arbace_j2g_model_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_supertypes_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_j2g_model_supertypes_A) Ctor() {}
//line :346:1
func (t *A_arbace_j2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_777 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, A_arbace_j2g_model_info_A_fn_class); var ifn_779 lang.IFn; if
										linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = n__0; if linked_778 == nil { i__2 = ifn_779.Invoke_O__O(arg_780) } else { i__2 = linked_778.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_777, arg_780) }; var root_781 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var arg_785 any; var root_786 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(i__2); var arg_790 any = A_arbace_j2g_model_A_const_53.Invoke_O__O(i__2); if linked_787 == nil { arg_785 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { arg_785 = linked_787.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; if linked_782 == nil { return ifn_783.Invoke_O_O__O(arg_784, arg_785) } else { return linked_782.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_781, arg_784, arg_785) } }

func A_arbace_j2g_model_world_supertypes_A_New() *A_arbace_j2g_model_world_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_j2g_model_world_supertypes_A) Ctor() {}
//line :349:1
func (t *A_arbace_j2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	var root_791 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_795 any; var root_796 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, A_arbace_j2g_model_supertypes_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = n__0; if linked_797 == nil { arg_795 = ifn_798.Invoke_O__O(arg_799) } else { arg_795 = linked_797.(*A_arbace_j2g_model_supertypes_A).Invoke_O_O__O(root_796, arg_799) }; if linked_792 == nil { return ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { return linked_792.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_791, arg_794, arg_795)
	} }
func A_arbace_j2g_model_all_supertypes_A_New() *A_arbace_j2g_model_all_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_j2g_model_all_supertypes_A) Ctor() {}
//line :354:1
func (t *A_arbace_j2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	var root_800 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any; var root_804 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_808 any; var root_809 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = n__0; if linked_810 == nil { arg_808 = ifn_811.Invoke_O__O(arg_812) } else { arg_808 = linked_810.(*aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_809, arg_812) }; if linked_805 == nil { arg_803 = ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { arg_803 = linked_805.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_804, arg_807, arg_808) }; if linked_801 == nil { return ifn_802.Invoke_O__O(arg_803) } else { return linked_801.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_800, arg_803)
	}
}

func A_arbace_j2g_model_hw_method_exists_QMARK__A_New() *A_arbace_j2g_model_hw_method_exists_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :363:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_91; var scan__3 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var g__4 any; var root_813 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, A_arbace_j2g_model_go_name_A_fn_class); var ifn_815 lang.IFn; if



	linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = n__0; if linked_814 == nil { g__4 = ifn_815.Invoke_O__O(arg_816) } else { g__4 = linked_814.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_813, arg_816) }; var base__5 any; var root_817 any = /*line :363:1*/A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_819 lang.IFn; if




	linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(m__1); var arg_821 any = A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1); if linked_818 == nil { base__5 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { base__5 = linked_818.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }; if
	lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30) {
		var root_822 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var arg_826 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_125.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1)); if linked_823 == nil { return ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { return linked_823.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_822, arg_825, arg_826) } } else {
//line :369:1
			var tmp2 any; var root_827 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_829 lang.IFn

			if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = n__0; if linked_828 == nil { tmp2 = ifn_829.Invoke_O__O(arg_830) } else { tmp2 = linked_828.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_827, arg_830) }
//line :369:1
			if jrt.J2g_Truth(tmp2) { var or__1927000174__auto____6 any; var root_831 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_833 lang.IFn

				if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var root_836 any = A_arbace_j2g_model_A_const_136.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = scan__3; var arg_840 any = g__4; if linked_837 == nil { arg_834 = ifn_838.Invoke_O_O__O(arg_839, arg_840) } else { arg_834 = linked_837.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_836, arg_839, arg_840) }; var arg_835 any = base__5; if linked_832 == nil { or__1927000174__auto____6 = ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { or__1927000174__auto____6 = linked_832.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_831, arg_834, arg_835) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					var root_841 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = A_arbace_j2g_model_A_const_137.Invoke_O__O(scan__3); var arg_845 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref(); if linked_842 == nil { return ifn_843.Invoke_O_O__O(arg_844, arg_845) } else { return linked_842.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_841, arg_844, arg_845) } } } else {
//line :369:1
						if A_arbace_j2g_model_A_const_60 != nil { var ms__6 any; var root_846 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_848 lang.IFn




							if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = scan__3; var arg_850 any = g__4; if linked_847 == nil { ms__6 = ifn_848.Invoke_O_O__O(arg_849, arg_850) } else { ms__6 = linked_847.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_846, arg_849, arg_850) }
//line :369:1
							var or__1927000174__auto____7 any; var root_851 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_853 lang.IFn





							if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = ms__6; var arg_855 any = base__5; if linked_852 == nil { or__1927000174__auto____7 = ifn_853.Invoke_O_O__O(arg_854, arg_855) } else { or__1927000174__auto____7 = linked_852.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_851, arg_854, arg_855) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_856 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = ms__6; var arg_860 any; var root_861 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = base__5; if linked_862 == nil { arg_860 = ifn_863.Invoke_O__O(arg_864) } else { arg_860 = linked_862.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_861, arg_864) }; if linked_857 == nil { or__1927000174__auto____8 = ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { or__1927000174__auto____8 = linked_857.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_856, arg_859, arg_860) }; if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								var root_865 any = A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, A_arbace_j2g_model_j2g_method_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = n__0; var arg_869 any = base__5; if linked_866 == nil { return ifn_867.Invoke_O_O__O(arg_868, arg_869) } else { return linked_866.(*A_arbace_j2g_model_j2g_method_QMARK__A).Invoke_O_O_O__O(root_865, arg_868, arg_869) } } } } else {
//line :369:1
									return nil } } } }








func A_arbace_j2g_model_j2g_method_QMARK__A_New() *A_arbace_j2g_model_j2g_method_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_method_QMARK__A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Ctor() {}
//line :378:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_46); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_141).Invoke_O__O(base__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_870 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_872 lang.IFn
		if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = Lit_47; if linked_871 == nil { and__1927000168__auto____5 = ifn_872.Invoke_O__O(arg_873) } else { and__1927000168__auto____5 = linked_871.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_870, arg_873) }
//line :385:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_874 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = Lit_48; if linked_875 == nil { return ifn_876.Invoke_O__O(arg_877) } else { return linked_875.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_874, arg_877) } } else {
//line :385:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_member_in_world_QMARK__A_New() *A_arbace_j2g_model_member_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Ctor() {}
//line :388:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any; var root_878 any = A_arbace_j2g_model_A_const_142.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_880 lang.IFn; if



	linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1); if linked_879 == nil { and__1927000168__auto____3 = ifn_880.Invoke_O__O(arg_881) } else { and__1927000168__auto____3 = linked_879.(*A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_878, arg_881) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_882 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_884 lang.IFn
		if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any; var root_886 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = n__0; if linked_887 == nil { arg_885 = ifn_888.Invoke_O__O(arg_889) } else { arg_885 = linked_887.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_886, arg_889) }; if linked_883 == nil { or__1927000174__auto____4 = ifn_884.Invoke_O__O(arg_885) } else { or__1927000174__auto____4 = linked_883.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_882, arg_885) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_890 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = n__0; var arg_894 any = m__1; if linked_891 == nil { return ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { return linked_891.(*A_arbace_j2g_model_hw_method_exists_QMARK__A).Invoke_O_O_O__O(root_890, arg_893, arg_894) } } } else {
//line :392:1
			return and__1927000168__auto____3 } }


func A_arbace_j2g_model_declared_vmethods_A_New() *A_arbace_j2g_model_declared_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Ctor() {}
//line :395:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var fnbody__994 any = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_New_O(n__0); var tmp1 *jrt.Class; var fncls__993 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_fn_class; if


	fncls__993 == nil { var fncls__993d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__994); A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_fn_class = fncls__993d; tmp1 = fncls__993d } else { tmp1 = fncls__993 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__994, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_995 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = n__0; if linked_996 == nil { tmp3 = ifn_997.Invoke_O__O(arg_998) } else { tmp3 = linked_996.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_995, arg_998) }; return tmp2.Invoke_O__O(tmp3) }
//line :398:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_New_O(p0 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A{}; t.Ctor_O(p0); return t }
//line :398:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :398:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A) Invoke_O_O__O(self, s__1479000091__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__992 any = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_New_O_O_O(t.F_n, s__1479000091__1, self); var tmp2 *jrt.Class; var fncls__991 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_fn_class; if fncls__991 == nil { var fncls__991d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__992); A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_fn_class = fncls__991d; tmp2 = fncls__991d } else { tmp2 = fncls__991 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__992, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :398:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :398:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A) Ctor_O_O_O(c__n, c__s__1479000091, c__iter__1479000090 any) { t.F_n = c__n; t.F_s__1479000091 = c__s__1479000091; t.F_iter__1479000090 = c__iter__1479000090 }
//line :398:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A) Invoke_O__O(self any) any { { var s__1479000091__1 any; var t_ any = t.F_s__1479000091; t.F_s__1479000091 = nil; s__1479000091__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_895 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = s__1479000091__1; if linked_896 == nil { temp__1927000414__auto____2 = ifn_897.Invoke_O__O(arg_898) } else { temp__1927000414__auto____2 = linked_896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_895, arg_898) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000091__3 any = temp__1927000414__auto____2; var tmp1 any; var root_899 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = s__1479000091__3; if linked_900 == nil { tmp1 = ifn_901.Invoke_O__O(arg_902) } else { tmp1 = linked_900.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_899, arg_902) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_903 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = s__1479000091__3; if linked_904 == nil { c__1927001037__auto____4 = ifn_905.Invoke_O__O(arg_906) } else { c__1927001037__auto____4 = linked_904.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_903, arg_906) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000093__6 any; var root_907 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_908 == nil { b__1479000093__6 = ifn_909.Invoke_O__O(arg_910) } else { b__1479000093__6 = linked_908.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_907, arg_910) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__932 any = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_New_O_O_I_O(t.F_n, b__1479000093__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__931 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_fn_class; if fncls__931 == nil { var fncls__931d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__932); A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_fn_class = fncls__931d; tmp3 = fncls__931d } else { tmp3 = fncls__931 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__932, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_933 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any; var root_938 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = b__1479000093__6; if linked_939 == nil { arg_936 = ifn_940.Invoke_O__O(arg_941) } else { arg_936 = linked_939.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_938, arg_941) }; var arg_937 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000090); var tmp5 any; var root_942 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = s__1479000091__3; if linked_943 == nil { tmp5 = ifn_944.Invoke_O__O(arg_945) } else { tmp5 = linked_943.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_942, arg_945) }; arg_937 = tmp4.Invoke_O__O(tmp5); if linked_934 == nil { return ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { return linked_934.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) } } else { var root_946 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any; var root_951 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = b__1479000093__6; if linked_952 == nil { arg_949 = ifn_953.Invoke_O__O(arg_954) } else { arg_949 = linked_952.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_951, arg_954) }; var arg_950 any; if linked_947 == nil { return ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { return linked_947.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_946, arg_949, arg_950) } } } else { var m__4 any; var root_955 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = s__1479000091__3; if linked_956 == nil { m__4 = ifn_957.Invoke_O__O(arg_958) } else { m__4 = linked_956.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_955, arg_958) }; var tmp6 any; var root_959 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_961 lang.IFn
															if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = m__4; if linked_960 == nil { tmp6 = ifn_961.Invoke_O__O(arg_962) } else { tmp6 = linked_960.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_959, arg_962) }
//line :398:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_963 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_965 lang.IFn

		if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = t.F_n; var arg_967 any = m__4; if linked_964 == nil { tmp7 = ifn_965.Invoke_O_O__O(arg_966, arg_967) } else { tmp7 = linked_964.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_963, arg_966, arg_967) }
//line :398:1
		if jrt.J2g_Truth(tmp7) { var root_968 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any; var root_973 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_975 lang.IFn


			if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = m__4; var arg_977 any = A_arbace_j2g_model_A_const_151; var arg_978 any = t.F_n; if linked_974 == nil { arg_971 = ifn_975.Invoke_O_O_O__O(arg_976, arg_977, arg_978) } else { arg_971 = linked_974.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_973, arg_976, arg_977, arg_978) }
//line :398:1
			var arg_972 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000090); var tmp9 any; var root_979 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = s__1479000091__3; if linked_980 == nil { tmp9 = ifn_981.Invoke_O__O(arg_982) } else { tmp9 = linked_980.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_979, arg_982) }; arg_972 = tmp8.Invoke_O__O(tmp9); if linked_969 == nil { return ifn_970.Invoke_O_O__O(arg_971, arg_972) } else { return linked_969.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_968, arg_971, arg_972) } } else { var tmp10 any; var root_983 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = s__1479000091__3; if linked_984 == nil { tmp10 = ifn_985.Invoke_O__O(arg_986) } else { tmp10 = linked_984.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_983, arg_986) }; s__1479000091__1 = tmp10; continue L1 } } else { var tmp11 any; var root_987 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = s__1479000091__3; if linked_988 == nil { tmp11 = ifn_989.Invoke_O__O(arg_990) } else { tmp11 = linked_988.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_987, arg_990) }; s__1479000091__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :398:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :398:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A) Ctor_O_O_I_O(c__n, c__b__1479000093 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1479000093 = c__b__1479000093; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :398:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A) Invoke_O__O(self any) any { { var i__1479000092__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000092__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000092__1)); var tmp2 any; var root_911 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_913 lang.IFn
																	if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = m__2; if linked_912 == nil { tmp2 = ifn_913.Invoke_O__O(arg_914) } else { tmp2 = linked_912.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_911, arg_914) }
//line :398:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_915 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_917 lang.IFn

		if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = t.F_n; var arg_919 any = m__2; if linked_916 == nil { tmp3 = ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { tmp3 = linked_916.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_915, arg_918, arg_919) }
//line :398:1
		if jrt.J2g_Truth(tmp3) { var root_920 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = t.F_b__1479000093; var arg_924 any; var root_925 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_927 lang.IFn


			if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = m__2; var arg_929 any = A_arbace_j2g_model_A_const_151; var arg_930 any = t.F_n; if linked_926 == nil { arg_924 = ifn_927.Invoke_O_O_O__O(arg_928, arg_929, arg_930) } else { arg_924 = linked_926.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_925, arg_928, arg_929, arg_930) }
//line :398:1
			if linked_921 == nil { ifn_922.Invoke_O_O__O(arg_923, arg_924) } else { linked_921.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_920, arg_923, arg_924) }; i__1479000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000092__1); continue L1 } else { i__1479000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000092__1); continue L1 } } else { i__1479000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000092__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_model_vmethods_A_New() *A_arbace_j2g_model_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_A{}; t.Ctor(); return t }
//line :403:1
func (t *A_arbace_j2g_model_vmethods_A) Ctor() {}
//line :403:1
func (t *A_arbace_j2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_157; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var or__1927000174__auto____3 any; var tmp2 any; var root_999 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1001 lang.IFn; if




	linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = cache__2; if linked_1000 == nil { tmp2 = ifn_1001.Invoke_O__O(arg_1002) } else { tmp2 = linked_1000.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_999, arg_1002) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var root_1003 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1005 lang.IFn
		if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any; var fnbody__1038 any = A_arbace_j2g_model_vmethods_fn__1479000101_A_New(); var tmp3 *jrt.Class; var fncls__1037 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000101_A_fn_class; if fncls__1037 == nil { var fncls__1037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); A_arbace_j2g_model_vmethods_fn__1479000101_A_fn_class = fncls__1037d; tmp3 = fncls__1037d } else { tmp3 = fncls__1037 }; arg_1006 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1038, tmp3, nil); var arg_1007 any; var root_1039 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_1041 lang.IFn






		if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; if linked_1040 == nil { arg_1007 = ifn_1041.Invoke__O() } else { arg_1007 = linked_1040.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_1039) }
//line :409:1
		var arg_1008 any; var root_1042 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1044 lang.IFn






		if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = n__0; if linked_1043 == nil { arg_1008 = ifn_1044.Invoke_O__O(arg_1045) } else { arg_1008 = linked_1043.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1042, arg_1045) }
//line :409:1
		if linked_1004 == nil { r__4 = ifn_1005.Invoke_O_O_O__O(arg_1006, arg_1007, arg_1008) } else { r__4 = linked_1004.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1003, arg_1006, arg_1007, arg_1008)
		}






		var root_1046 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = cache__2; var arg_1050 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var arg_1051 any = n__0; var arg_1052 any = r__4; if linked_1047 == nil { ifn_1048.Invoke_O_O_O_O__O(arg_1049, arg_1050, arg_1051, arg_1052) } else { linked_1047.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1046, arg_1049, arg_1050, arg_1051, arg_1052) }
//line :408:1
		return r__4 } }
func A_arbace_j2g_model_vmethods_fn__1479000101_A_New() *A_arbace_j2g_model_vmethods_fn__1479000101_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000101_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_A) Ctor() {}
//line :409:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(c__2, Lit_30) { return acc__1 } else {

		var root_1009 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any; var fnbody__1032 any = A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_New(); var tmp1 *jrt.Class; var fncls__1031 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_fn_class; if fncls__1031 == nil { var fncls__1031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, nil); A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_fn_class = fncls__1031d; tmp1 = fncls__1031d } else { tmp1 = fncls__1031 }; arg_1012 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1032, tmp1, nil); var arg_1013 any = acc__1; var arg_1014 any; var root_1033 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, A_arbace_j2g_model_declared_vmethods_A_fn_class); var ifn_1035 lang.IFn


		if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = c__2; if linked_1034 == nil { arg_1014 = ifn_1035.Invoke_O__O(arg_1036) } else { arg_1014 = linked_1034.(*A_arbace_j2g_model_declared_vmethods_A).Invoke_O_O__O(root_1033, arg_1036) }
//line :412:1
		if linked_1010 == nil { return ifn_1011.Invoke_O_O_O__O(arg_1012, arg_1013, arg_1014) } else { return linked_1010.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1009, arg_1012, arg_1013, arg_1014) } } }
//line :412:1
func A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_New() *A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A{}; t.Ctor(); return t }
//line :412:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A) Ctor() {}
//line :412:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_125.Invoke_O__O(m__2), A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)); var tmp1 any; var or__1927000174__auto____4 any; var root_1015 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1017 lang.IFn; if

	linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = acc__1; var arg_1019 any = k__3; if linked_1016 == nil { or__1927000174__auto____4 = ifn_1017.Invoke_O_O__O(arg_1018, arg_1019) } else { or__1927000174__auto____4 = linked_1016.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1015, arg_1018, arg_1019) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_1020 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var arg_1024 any = k__3; if linked_1021 == nil { tmp1 = ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { tmp1 = linked_1021.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) } }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_1025 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = acc__1; var arg_1029 any = k__3; var arg_1030 any = m__2; if linked_1026 == nil { return ifn_1027.Invoke_O_O_O__O(arg_1028, arg_1029, arg_1030) } else { return linked_1026.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1025, arg_1028, arg_1029, arg_1030) } } }





func A_arbace_j2g_model_java_type_name_A_New() *A_arbace_j2g_model_java_type_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_java_type_name_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_j2g_model_java_type_name_A) Ctor() {}
//line :420:1
func (t *A_arbace_j2g_model_java_type_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_1053 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = d__0; if linked_1054 == nil { tmp1 = ifn_1055.Invoke_O__O(arg_1056) } else { tmp1 = linked_1054.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1053, arg_1056) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_52); var tmp3 any; var root_1057 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any; var root_1061 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = d__0; if linked_1062 == nil { arg_1060 = ifn_1063.Invoke_O__O(arg_1064) } else { arg_1060 = linked_1062.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1061, arg_1064) }; if linked_1058 == nil { tmp3 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp3 = linked_1058.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1057, arg_1060) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref() } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(d__0))) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_162).Invoke_O__O(d__0) } else {
//line :423:1
			if A_arbace_j2g_model_A_const_60 != nil {


				var root_1065 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any; var root_1071 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = d__0; if linked_1072 == nil { arg_1068 = ifn_1073.Invoke_O__O(arg_1074) } else { arg_1068 = linked_1072.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1071, arg_1074) }; var arg_1069 any = Lit_1; var arg_1070 any = Lit_2; if linked_1066 == nil { return ifn_1067.Invoke_O_O_O__O(arg_1068, arg_1069, arg_1070) } else { return linked_1066.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1065, arg_1068, arg_1069, arg_1070) } } else {
//line :423:1
					return nil
				}
		}
	}
}
func A_arbace_j2g_model_abstract_method_error_text_A_New() *A_arbace_j2g_model_abstract_method_error_text_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_method_error_text_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Ctor() {}
//line :428:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Invoke_O_O_O_O__O(self, n__0, owner__1, p__1479000107__2 any) any { var vec__1479000108__4 any = p__1479000107__2; var name__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000108__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000108__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1479000111__7 any; var root_1075 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1077 lang.IFn; if



	linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = desc__6; if linked_1076 == nil { vec__1479000111__7 = ifn_1077.Invoke_O__O(arg_1078) } else { vec__1479000111__7 = linked_1076.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1075, arg_1078) }; var ps__8 any = /*line :428:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1479000111__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000111__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,12,s15:Receiver class ns69: does not define or inherit an implementation of the resolved method s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1079 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1081 lang.IFn; if




	linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = n__0; var arg_1083 any = Lit_1; var arg_1084 any = Lit_2; if linked_1080 == nil { tmp2 = ifn_1081.Invoke_O_O_O__O(arg_1082, arg_1083, arg_1084) } else { tmp2 = linked_1080.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1079, arg_1082, arg_1083, arg_1084) }; var tmp3 any = tmp2; var tmp4 any; var root_1085 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1087 lang.IFn; if
	linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = r__9; if linked_1086 == nil { tmp4 = ifn_1087.Invoke_O__O(arg_1088) } else { tmp4 = linked_1086.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1085, arg_1088) }; var tmp5 any = tmp4; var tmp6 any; var root_1089 any = /*line :433:1*/A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1091 lang.IFn; if
	linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = Lit_3; var arg_1093 any; var root_1094 any = A_arbace_j2g_model_A_const_165.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var arg_1098 any = ps__8; if linked_1095 == nil { arg_1093 = ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { arg_1093 = linked_1095.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }; if linked_1090 == nil { tmp6 = ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { tmp6 = linked_1090.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) }; var tmp7 any = tmp6; var tmp8 /*line :433:1*/*jrt.String; if

	jrt.J2g_Truth(owner__1) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil, nil); var tmp10 *jrt.String; var tmp11 any; var root_1099 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = owner__1; if linked_1100 == nil { tmp11 = ifn_1101.Invoke_O__O(arg_1102) } else { tmp11 = linked_1100.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1099, arg_1102) }; if jrt.J2g_Truth(tmp11) { tmp10 = Lit_5 } else { tmp10 = Lit_6 }; var tmp12 any = tmp10.Ref(); var tmp13 any; var root_1103 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = owner__1; var arg_1107 any = Lit_1; var arg_1108 any = Lit_2; if linked_1104 == nil { tmp13 = ifn_1105.Invoke_O_O_O__O(arg_1106, arg_1107, arg_1108) } else { tmp13 = linked_1104.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1103, arg_1106, arg_1107, arg_1108) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13)) } else { tmp8 = nil }; return /*line :433:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, nil, tmp5, nil, name__5, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }



func A_arbace_j2g_model_superclass_chain_A_New() *A_arbace_j2g_model_superclass_chain_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_j2g_model_superclass_chain_A) Ctor() {}
//line :437:1
func (t *A_arbace_j2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1109 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var arg_1113 any; var root_1114 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any; var fnbody__1124 any = A_arbace_j2g_model_superclass_chain_fn__1479000116_A_New(); var tmp1 *jrt.Class; var fncls__1123 *jrt.Class = A_arbace_j2g_model_superclass_chain_fn__1479000116_A_fn_class; if fncls__1123 == nil { var fncls__1123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_j2g_model_superclass_chain_fn__1479000116_A_fn_class = fncls__1123d; tmp1 = fncls__1123d } else { tmp1 = fncls__1123 }; arg_1117 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1124, tmp1, nil); var arg_1118 any = n__0; if linked_1115 == nil { arg_1113 = ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { arg_1113 = linked_1115.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) }; if linked_1110 == nil { return ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { return linked_1110.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) } }
//line :438:1
func A_arbace_j2g_model_superclass_chain_fn__1479000116_A_New() *A_arbace_j2g_model_superclass_chain_fn__1479000116_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_fn__1479000116_A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000116_A) Ctor() {}
//line :438:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000116_A) Invoke_O_O__O(self, p1__1479000115_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_1119 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, A_arbace_j2g_model_info_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = p1__1479000115_SHARP___1; if linked_1120 == nil { tmp2 = ifn_1121.Invoke_O__O(arg_1122) } else { tmp2 = linked_1120.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1119, arg_1122) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_impl_of_A_New() *A_arbace_j2g_model_impl_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_A{}; t.Ctor(); return t }
//line :440:1
func (t *A_arbace_j2g_model_impl_of_A) Ctor() {}
//line :440:1
func (t *A_arbace_j2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1479000120__1 any) any { var vec__1479000121__3 any = p__1479000120__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000121__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000121__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__1479000121__3; var or__1927000174__auto____7 any; var root_1125 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1127 lang.IFn; _ = k__6; if





	linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any; var fnbody__1201 any = A_arbace_j2g_model_impl_of_fn__1479000124_A_New_O_O_O(name__4, desc__5, n__0); var tmp1 *jrt.Class; var fncls__1200 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class; if fncls__1200 == nil { var fncls__1200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__1201); A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class = fncls__1200d; tmp1 = fncls__1200d } else { tmp1 = fncls__1200 }; arg_1128 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1201, tmp1, nil); var arg_1129 any; var root_1202 any = A_arbace_j2g_model_A_const_176.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1204 lang.IFn; if












	linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = n__0; if linked_1203 == nil { arg_1129 = ifn_1204.Invoke_O__O(arg_1205) } else { arg_1129 = linked_1203.(*A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1202, arg_1205) }; if /*line :446:1*/ linked_1126 == nil { or__1927000174__auto____7 = ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { or__1927000174__auto____7 = linked_1126.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var fnbody__1391 any = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_New_O_O(name__4, desc__5); var tmp2 *jrt.Class
		var fncls__1390 /*line :446:1*/*jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_fn_class














		if fncls__1390 == nil { var fncls__1390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__1391); A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_fn_class = fncls__1390d; tmp2 = fncls__1390d } else { tmp2 = fncls__1390 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1391, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp4 any; var root_1420 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = n__0; if linked_1421 == nil { tmp4 = ifn_1422.Invoke_O__O(arg_1423) } else { tmp4 = linked_1421.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1420, arg_1423) }; cands__8 = tmp3.Invoke_O__O(tmp4)
//line :446:1
		var cands__9 any; var root_1392 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1394 lang.IFn





















		if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any; var fnbody__1415 any = A_arbace_j2g_model_impl_of_fn__1479000136_A_New_O(cands__8); var tmp5 *jrt.Class; var fncls__1414 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000136_A_fn_class; if fncls__1414 == nil { var fncls__1414d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__1415); A_arbace_j2g_model_impl_of_fn__1479000136_A_fn_class = fncls__1414d; tmp5 = fncls__1414d } else { tmp5 = fncls__1414 }; arg_1395 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1415, tmp5, nil); var arg_1396 any = cands__8; if linked_1393 == nil { cands__9 = ifn_1394.Invoke_O_O__O(arg_1395, arg_1396) } else { cands__9 = linked_1393.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1392, arg_1395, arg_1396) }
		var root_1416 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = cands__9; if linked_1417 == nil { return ifn_1418.Invoke_O__O(arg_1419) } else { return linked_1417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1416, arg_1419) } } }
//line :446:1
func A_arbace_j2g_model_impl_of_fn__1479000124_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_impl_of_fn__1479000124_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000124_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :446:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :446:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var root_1130 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1132 lang.IFn; if
											linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any; var root_1134 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = c__1; if linked_1135 == nil { arg_1133 = ifn_1136.Invoke_O__O(arg_1137) } else { arg_1133 = linked_1135.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1134, arg_1137) }; if linked_1131 == nil { and__1927000168__auto____2 = ifn_1132.Invoke_O__O(arg_1133) } else { and__1927000168__auto____2 = linked_1131.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1130, arg_1133) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1138 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = c__1; var arg_1142 any = t.F_name; var arg_1143 any = t.F_desc; if linked_1139 == nil { temp__1927000414__auto____2 = ifn_1140.Invoke_O_O_O__O(arg_1141, arg_1142, arg_1143) } else { temp__1927000414__auto____2 = linked_1139.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1138, arg_1141, arg_1142, arg_1143) } } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any; var root_1144 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1146 lang.IFn
												if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any; var root_1148 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = m__3; if linked_1149 == nil { arg_1147 = ifn_1150.Invoke_O__O(arg_1151) } else { arg_1147 = linked_1149.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1148, arg_1151) }; if linked_1145 == nil { and__1927000168__auto____4 = ifn_1146.Invoke_O__O(arg_1147) } else { and__1927000168__auto____4 = linked_1145.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1144, arg_1147) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1152 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any; var root_1156 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = m__3; if linked_1157 == nil { arg_1155 = ifn_1158.Invoke_O__O(arg_1159) } else { arg_1155 = linked_1157.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1156, arg_1159) }; if linked_1153 == nil { and__1927000168__auto____5 = ifn_1154.Invoke_O__O(arg_1155) } else { and__1927000168__auto____5 = linked_1153.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1152, arg_1155) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1160 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1162 lang.IFn
													if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any; var root_1164 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = m__3; if linked_1165 == nil { arg_1163 = ifn_1166.Invoke_O__O(arg_1167) } else { arg_1163 = linked_1165.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1164, arg_1167) }; if linked_1161 == nil { or__1927000174__auto____6 = ifn_1162.Invoke_O__O(arg_1163) } else { or__1927000174__auto____6 = linked_1161.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1160, arg_1163) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__1, t.F_n)).Ref() } } else {
//line :448:1
				tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

					if lang.Util_Equiv_O_O__Z_NoInit(c__1, Lit_30) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_171, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { var tmp2 any; var root_1168 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1170 lang.IFn

						if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = c__1; if linked_1169 == nil { tmp2 = ifn_1170.Invoke_O__O(arg_1171) } else { tmp2 = linked_1169.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1168, arg_1171) }
//line :450:1
						if jrt.J2g_Truth(tmp2) { var base__4 any; var root_1172 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1174 lang.IFn


							if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = t.F_name; var arg_1176 any = t.F_desc; if linked_1173 == nil { base__4 = ifn_1174.Invoke_O_O__O(arg_1175, arg_1176) } else { base__4 = linked_1173.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1172, arg_1175, arg_1176) }
//line :450:1
							var ms__5 any; var root_1177 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1179 lang.IFn



							if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1180 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var arg_1181 any; var root_1182 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = c__1; if linked_1183 == nil { arg_1181 = ifn_1184.Invoke_O__O(arg_1185) } else { arg_1181 = linked_1183.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1182, arg_1185) }; if linked_1178 == nil { ms__5 = ifn_1179.Invoke_O_O__O(arg_1180, arg_1181) } else { ms__5 = linked_1178.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1177, arg_1180, arg_1181) }
							var tmp4 any; var root_1186 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = ms__5; var arg_1190 any; var root_1191 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = base__4; if linked_1192 == nil { arg_1190 = ifn_1193.Invoke_O__O(arg_1194) } else { arg_1190 = linked_1192.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_1191, arg_1194) }; if linked_1187 == nil { tmp4 = ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { tmp4 = linked_1187.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) }; if jrt.J2g_Truth(tmp4) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { var tmp5 any; var root_1195 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1197 lang.IFn
								if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = ms__5; var arg_1199 any = base__4; if linked_1196 == nil { tmp5 = ifn_1197.Invoke_O_O__O(arg_1198, arg_1199) } else { tmp5 = linked_1196.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1195, arg_1198, arg_1199) }
//line :455:1
								if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_174, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil } } } } else {
//line :450:1
									if A_arbace_j2g_model_A_const_60 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_175, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { return nil } } } } else {
//line :448:1
										return nil } } else {
//line :447:1
											return nil } }













func A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A{}; t.Ctor_O_O(p0, p1); return t }
//line :461:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :461:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A) Invoke_O_O__O(self, s__1479000127__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1389 any = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_New_O_O_O_O(self, t.F_name, t.F_desc, s__1479000127__1); var tmp2 *jrt.Class; var fncls__1388 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_fn_class; if fncls__1388 == nil { var fncls__1388d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__1389); A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_fn_class = fncls__1388d; tmp2 = fncls__1388d } else { tmp2 = fncls__1388 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1389, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :461:1
func A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :461:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A) Ctor_O_O_O_O(c__iter__1479000126, c__name, c__desc, c__s__1479000127 any) { t.F_iter__1479000126 = c__iter__1479000126; t.F_name = c__name; t.F_desc = c__desc; t.F_s__1479000127 = c__s__1479000127 }
//line :461:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A) Invoke_O__O(self any) any { { var s__1479000127__1 any; var t_ any = t.F_s__1479000127; t.F_s__1479000127 = nil; s__1479000127__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1206 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = s__1479000127__1; if linked_1207 == nil { temp__1927000414__auto____2 = ifn_1208.Invoke_O__O(arg_1209) } else { temp__1927000414__auto____2 = linked_1207.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1206, arg_1209) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000127__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1210 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = s__1479000127__3; if linked_1211 == nil { tmp1 = ifn_1212.Invoke_O__O(arg_1213) } else { tmp1 = linked_1211.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1210, arg_1213) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1214 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = s__1479000127__3; if linked_1215 == nil { c__1927001037__auto____4 = ifn_1216.Invoke_O__O(arg_1217) } else { c__1927001037__auto____4 = linked_1215.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1214, arg_1217) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000129__6 any; var root_1218 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1219 == nil { b__1479000129__6 = ifn_1220.Invoke_O__O(arg_1221) } else { b__1479000129__6 = linked_1219.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1218, arg_1221) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1284 any = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_New_O_O_O_I_O(t.F_name, b__1479000129__6, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1283 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_fn_class; if fncls__1283 == nil { var fncls__1283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__1284); A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_fn_class = fncls__1283d; tmp3 = fncls__1283d } else { tmp3 = fncls__1283 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1284, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1285 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any; var root_1290 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = b__1479000129__6; if linked_1291 == nil { arg_1288 = ifn_1292.Invoke_O__O(arg_1293) } else { arg_1288 = linked_1291.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1290, arg_1293) }; var arg_1289 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000126); var tmp5 any; var root_1294 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = s__1479000127__3; if linked_1295 == nil { tmp5 = ifn_1296.Invoke_O__O(arg_1297) } else { tmp5 = linked_1295.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1294, arg_1297) }; arg_1289 = tmp4.Invoke_O__O(tmp5); if linked_1286 == nil { return ifn_1287.Invoke_O_O__O(arg_1288, arg_1289) } else { return linked_1286.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1285, arg_1288, arg_1289) } } else { var root_1298 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any; var root_1303 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = b__1479000129__6; if linked_1304 == nil { arg_1301 = ifn_1305.Invoke_O__O(arg_1306) } else { arg_1301 = linked_1304.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1303, arg_1306) }; var arg_1302 any; if linked_1299 == nil { return ifn_1300.Invoke_O_O__O(arg_1301, arg_1302) } else { return linked_1299.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1298, arg_1301, arg_1302) } } } else { var c__4 any; var root_1307 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = s__1479000127__3; if linked_1308 == nil { c__4 = ifn_1309.Invoke_O__O(arg_1310) } else { c__4 = linked_1308.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1307, arg_1310) }; var tmp6 any; var root_1311 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1313 lang.IFn
														if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = c__4; if linked_1312 == nil { tmp6 = ifn_1313.Invoke_O__O(arg_1314) } else { tmp6 = linked_1312.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1311, arg_1314) }
//line :461:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_1315 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1317 lang.IFn

		if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = c__4; var arg_1319 any = t.F_name; var arg_1320 any = t.F_desc; if linked_1316 == nil { m__5 = ifn_1317.Invoke_O_O_O__O(arg_1318, arg_1319, arg_1320) } else { m__5 = linked_1316.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1315, arg_1318, arg_1319, arg_1320) }
//line :461:1
		var tmp7 any
		var and__1927000168__auto____6 any = m__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1321 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any; var root_1325 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = m__5; if linked_1326 == nil { arg_1324 = ifn_1327.Invoke_O__O(arg_1328) } else { arg_1324 = linked_1326.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1325, arg_1328) }; if linked_1322 == nil { and__1927000168__auto____7 = ifn_1323.Invoke_O__O(arg_1324) } else { and__1927000168__auto____7 = linked_1322.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1321, arg_1324) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1329 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any; var root_1333 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = m__5; if linked_1334 == nil { arg_1332 = ifn_1335.Invoke_O__O(arg_1336) } else { arg_1332 = linked_1334.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1333, arg_1336) }; if linked_1330 == nil { and__1927000168__auto____8 = ifn_1331.Invoke_O__O(arg_1332) } else { and__1927000168__auto____8 = linked_1330.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1329, arg_1332) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1337 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1339 lang.IFn; if linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any; var root_1341 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = m__5; if linked_1342 == nil { arg_1340 = ifn_1343.Invoke_O__O(arg_1344) } else { arg_1340 = linked_1342.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1341, arg_1344) }; if linked_1338 == nil { tmp7 = ifn_1339.Invoke_O__O(arg_1340) } else { tmp7 = linked_1338.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1337, arg_1340) } } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 }
//line :461:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____6 any; var root_1345 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1347 lang.IFn



			if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any; var root_1349 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = c__4; if linked_1350 == nil { arg_1348 = ifn_1351.Invoke_O__O(arg_1352) } else { arg_1348 = linked_1350.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1349, arg_1352) }; if linked_1346 == nil { or__1927000174__auto____6 = ifn_1347.Invoke_O__O(arg_1348) } else { or__1927000174__auto____6 = linked_1346.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1345, arg_1348) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp8 = or__1927000174__auto____6 } else {
				var root_1353 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_137; var tmp10 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1356 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1357 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil); var tmp12 any; var root_1358 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = c__4; if linked_1359 == nil { tmp12 = ifn_1360.Invoke_O__O(arg_1361) } else { tmp12 = linked_1359.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1358, arg_1361) }; var tmp13 any = tmp12; var tmp14 any; var root_1362 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = t.F_name; var arg_1366 any = t.F_desc; if linked_1363 == nil { tmp14 = ifn_1364.Invoke_O_O__O(arg_1365, arg_1366) } else { tmp14 = linked_1363.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1362, arg_1365, arg_1366) }; arg_1357 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, tmp14)).Ref(); if linked_1354 == nil { tmp8 = ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { tmp8 = linked_1354.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) } }
//line :461:1
			if jrt.J2g_Truth(tmp8) { var root_1367 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1369 lang.IFn; if linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_177, A_arbace_j2g_model_A_const_151, c__4, A_arbace_j2g_model_A_const_172, m__5)); var arg_1371 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1479000126); var tmp16 any; var root_1372 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = s__1479000127__3; if linked_1373 == nil { tmp16 = ifn_1374.Invoke_O__O(arg_1375) } else { tmp16 = linked_1373.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1372, arg_1375) }; arg_1371 = tmp15.Invoke_O__O(tmp16); if linked_1368 == nil { return ifn_1369.Invoke_O_O__O(arg_1370, arg_1371) } else { return linked_1368.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1367, arg_1370, arg_1371) } } else { var tmp17 any; var root_1376 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = s__1479000127__3; if linked_1377 == nil { tmp17 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp17 = linked_1377.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1376, arg_1379) }; s__1479000127__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1380 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = s__1479000127__3; if linked_1381 == nil { tmp18 = ifn_1382.Invoke_O__O(arg_1383) } else { tmp18 = linked_1381.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1380, arg_1383) }; s__1479000127__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1384 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = s__1479000127__3; if linked_1385 == nil { tmp19 = ifn_1386.Invoke_O__O(arg_1387) } else { tmp19 = linked_1385.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1384, arg_1387) }; s__1479000127__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :461:1
func A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :461:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A) Ctor_O_O_O_I_O(c__name, c__b__1479000129, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__1479000129 = c__b__1479000129; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :461:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A) Invoke_O__O(self any) any { { var i__1479000128__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000128__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000128__1)); var tmp2 any; var root_1222 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1224 lang.IFn
																if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = c__2; if linked_1223 == nil { tmp2 = ifn_1224.Invoke_O__O(arg_1225) } else { tmp2 = linked_1223.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1222, arg_1225) }
//line :461:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_1226 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1228 lang.IFn

		if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = c__2; var arg_1230 any = t.F_name; var arg_1231 any = t.F_desc; if linked_1227 == nil { m__3 = ifn_1228.Invoke_O_O_O__O(arg_1229, arg_1230, arg_1231) } else { m__3 = linked_1227.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1226, arg_1229, arg_1230, arg_1231) }
//line :461:1
		var tmp3 any
		var and__1927000168__auto____4 any = m__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1232 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var root_1236 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = m__3; if linked_1237 == nil { arg_1235 = ifn_1238.Invoke_O__O(arg_1239) } else { arg_1235 = linked_1237.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1236, arg_1239) }; if linked_1233 == nil { and__1927000168__auto____5 = ifn_1234.Invoke_O__O(arg_1235) } else { and__1927000168__auto____5 = linked_1233.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1232, arg_1235) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1240 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var root_1244 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = m__3; if linked_1245 == nil { arg_1243 = ifn_1246.Invoke_O__O(arg_1247) } else { arg_1243 = linked_1245.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1244, arg_1247) }; if linked_1241 == nil { and__1927000168__auto____6 = ifn_1242.Invoke_O__O(arg_1243) } else { and__1927000168__auto____6 = linked_1241.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1240, arg_1243) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1248 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any; var root_1252 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1254 lang.IFn; if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = m__3; if linked_1253 == nil { arg_1251 = ifn_1254.Invoke_O__O(arg_1255) } else { arg_1251 = linked_1253.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1252, arg_1255) }; if linked_1249 == nil { tmp3 = ifn_1250.Invoke_O__O(arg_1251) } else { tmp3 = linked_1249.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1248, arg_1251) } } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :461:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____4 any; var root_1256 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1258 lang.IFn



			if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any; var root_1260 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = c__2; if linked_1261 == nil { arg_1259 = ifn_1262.Invoke_O__O(arg_1263) } else { arg_1259 = linked_1261.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1260, arg_1263) }; if linked_1257 == nil { or__1927000174__auto____4 = ifn_1258.Invoke_O__O(arg_1259) } else { or__1927000174__auto____4 = linked_1257.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1256, arg_1259) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else {
				var root_1264 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_137; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1267 any = tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1268 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil); var tmp8 any; var root_1269 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = c__2; if linked_1270 == nil { tmp8 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp8 = linked_1270.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1269, arg_1272) }; var tmp9 any = tmp8; var tmp10 any; var root_1273 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = t.F_name; var arg_1277 any = t.F_desc; if linked_1274 == nil { tmp10 = ifn_1275.Invoke_O_O__O(arg_1276, arg_1277) } else { tmp10 = linked_1274.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1273, arg_1276, arg_1277) }; arg_1268 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref(); if linked_1265 == nil { tmp4 = ifn_1266.Invoke_O_O__O(arg_1267, arg_1268) } else { tmp4 = linked_1265.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1264, arg_1267, arg_1268) } }
//line :461:1
			if jrt.J2g_Truth(tmp4) { var root_1278 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = t.F_b__1479000129; var arg_1282 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_177, A_arbace_j2g_model_A_const_151, c__2, A_arbace_j2g_model_A_const_172, m__3)); if linked_1279 == nil { ifn_1280.Invoke_O_O__O(arg_1281, arg_1282) } else { linked_1279.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1278, arg_1281, arg_1282) }; i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } else { i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } } else { i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } } else { i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_model_impl_of_fn__1479000136_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000136_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000136_A{}; t.Ctor_O(p0); return t }
//line :468:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :468:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_A) Invoke_O_O__O(self, x__1 any) any { var root_1397 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any; var fnbody__1413 any = A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_New_O(x__1); var tmp1 *jrt.Class; var fncls__1412 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_fn_class; if fncls__1412 == nil { var fncls__1412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__1413); A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_fn_class = fncls__1412d; tmp1 = fncls__1412d } else { tmp1 = fncls__1412 }; arg_1400 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1413, tmp1, nil); var arg_1401 any = t.F_cands; if linked_1398 == nil { return ifn_1399.Invoke_O_O__O(arg_1400, arg_1401) } else { return linked_1398.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1397, arg_1400, arg_1401) } }
//line :468:1
func A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A{}; t.Ctor_O(p0); return t }
//line :468:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :468:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A) Invoke_O_O__O(self, p1__1479000119_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1402 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(p1__1479000119_SHARP___1); var arg_1406 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(t.F_x); if linked_1403 == nil { and__1927000168__auto____2 = ifn_1404.Invoke_O_O__O(arg_1405, arg_1406) } else { and__1927000168__auto____2 = linked_1403.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1402, arg_1405, arg_1406) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1407 any = A_arbace_j2g_model_A_const_178.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(p1__1479000119_SHARP___1); var arg_1411 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(t.F_x); if linked_1408 == nil { return ifn_1409.Invoke_O_O__O(arg_1410, arg_1411) } else { return linked_1408.(*aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1407, arg_1410, arg_1411) } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_code_class_QMARK__A_New() *A_arbace_j2g_model_code_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_class_QMARK__A{}; t.Ctor(); return t }
//line :471:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Ctor() {}
//line :471:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_179; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_180; var tmp3 any; var root_1424 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = n__0; if linked_1425 == nil { tmp3 = ifn_1426.Invoke_O__O(arg_1427) } else { tmp3 = linked_1425.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1424, arg_1427) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)))).Ref()
}
func A_arbace_j2g_model_code_iface_QMARK__A_New() *A_arbace_j2g_model_code_iface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_iface_QMARK__A{}; t.Ctor(); return t }
//line :481:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Ctor() {}
//line :481:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1428 any = A_arbace_j2g_model_A_const_181.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = A_arbace_j2g_model_A_const_182; var arg_1432 any = n__0; if linked_1429 == nil { tmp1 = ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { tmp1 = linked_1429.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_nest_top_A_New() *A_arbace_j2g_model_nest_top_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_nest_top_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_j2g_model_nest_top_A) Ctor() {}
//line :487:1
func (t *A_arbace_j2g_model_nest_top_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_57); if


	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1433 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = n__0; var arg_1437 any = A_arbace_j2g_model_A_const_31; var arg_1438 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1434 == nil { return ifn_1435.Invoke_O_O_O__O(arg_1436, arg_1437, arg_1438) } else { return linked_1434.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1433, arg_1436, arg_1437, arg_1438) } } }



func A_arbace_j2g_model_init_superinterfaces_A_New() *A_arbace_j2g_model_init_superinterfaces_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_j2g_model_init_superinterfaces_A) Ctor() {}
//line :494:1
func (t *A_arbace_j2g_model_init_superinterfaces_A) Invoke_O_O__O(self, n__0 any) any { var d__2 any; var root_1439 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1441 lang.IFn; if




	linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = n__0; if linked_1440 == nil { d__2 = ifn_1441.Invoke_O__O(arg_1442) } else { d__2 = linked_1440.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1439, arg_1442) }; var tmp1 any; var and__1927000168__auto____3 any = d__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1443 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any; var root_1447 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(d__2); var arg_1451 any = A_arbace_j2g_model_A_const_183; if linked_1448 == nil { arg_1446 = ifn_1449.Invoke_O_O__O(arg_1450, arg_1451) } else { arg_1446 = linked_1448.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1447, arg_1450, arg_1451) }; if linked_1444 == nil { tmp1 = ifn_1445.Invoke_O__O(arg_1446) } else { tmp1 = linked_1444.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1443, arg_1446) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var declares_default_QMARK___3 any; var fnbody__1483 any = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A_New(); var tmp2 *jrt.Class; var fncls__1482 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A_fn_class
		if fncls__1482 == nil { var fncls__1482d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A_fn_class = fncls__1482d; tmp2 = fncls__1482d } else { tmp2 = fncls__1482 }; declares_default_QMARK___3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1483, tmp2, nil)
//line :500:1
		var walk__4 any; var fnbody__1507 any = A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A_New_O(declares_default_QMARK___3); var tmp3 *jrt.Class
		var fncls__1506 /*line :500:1*/*jrt.Class = A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A_fn_class




		if fncls__1506 == nil { var fncls__1506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__1507); A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A_fn_class = fncls__1506d; tmp3 = fncls__1506d } else { tmp3 = fncls__1506 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1507, tmp3, nil)



		var root_1508 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any; var root_1512 any = A_arbace_j2g_model_A_const_184.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any; var iter__1927001039__auto____5 any; var fnbody__1597 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A_New(); var tmp4 *jrt.Class; var fncls__1596 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A_fn_class; if fncls__1596 == nil { var fncls__1596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A_fn_class = fncls__1596d; tmp4 = fncls__1596d } else { tmp4 = fncls__1596 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1597, tmp4, nil); arg_1515 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()).Invoke_O_O__O(walk__4, A_arbace_j2g_model_A_const_53.Invoke_O__O(d__2))); if linked_1513 == nil { arg_1511 = ifn_1514.Invoke_O__O(arg_1515) } else { arg_1511 = linked_1513.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1512, arg_1515) }; if linked_1509 == nil { return ifn_1510.Invoke_O__O(arg_1511) } else { return linked_1509.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1508, arg_1511) } } else {
//line :500:1
			return nil } }
func A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A_New() *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A{}; t.Ctor(); return t }
//line :501:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A) Ctor() {}
//line :501:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A) Invoke_O_O__O(self, j__1 any) any {
	var root_1452 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any; var fnbody__1477 any = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A_New(); var tmp1 *jrt.Class; var fncls__1476 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A_fn_class; if fncls__1476 == nil { var fncls__1476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A_fn_class = fncls__1476d; tmp1 = fncls__1476d } else { tmp1 = fncls__1476 }; arg_1455 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1477, tmp1, nil); var arg_1456 any; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp3 any; var root_1478 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1480 lang.IFn

	if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = j__1; if linked_1479 == nil { tmp3 = ifn_1480.Invoke_O__O(arg_1481) } else { tmp3 = linked_1479.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1478, arg_1481) }; arg_1456 = tmp2.Invoke_O__O(tmp3)
//line :502:1
	if linked_1453 == nil { return ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { return linked_1453.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) } }
//line :502:1
func A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A_New() *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A{}; t.Ctor(); return t }
//line :502:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A) Ctor() {}
//line :502:1
func (t *A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A) Invoke_O_O__O(self, p1__1479000144_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1457 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = Lit_42; var arg_1461 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(p1__1479000144_SHARP___1); if linked_1458 == nil { and__1927000168__auto____2 = ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { and__1927000168__auto____2 = linked_1458.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1462 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = Lit_43; var arg_1466 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(p1__1479000144_SHARP___1); if linked_1463 == nil { and__1927000168__auto____3 = ifn_1464.Invoke_O_O__O(arg_1465, arg_1466) } else { and__1927000168__auto____3 = linked_1463.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1462, arg_1465, arg_1466) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
																				var root_1467 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any; var root_1471 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(p1__1479000144_SHARP___1); var arg_1475 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_Or_J_J__J_NoInit(8, 1024), 2)).Ref(); if linked_1472 == nil { arg_1470 = ifn_1473.Invoke_O_O__O(arg_1474, arg_1475) } else { arg_1470 = linked_1472.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_1471, arg_1474, arg_1475) }; if linked_1468 == nil { return ifn_1469.Invoke_O__O(arg_1470) } else { return linked_1468.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1467, arg_1470) } } else {
//line :502:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A_New_O(p0 any) *A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A{}; t.Ctor_O(p0); return t }
//line :505:1
func (t *A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A) Ctor_O(c__declares_default_QMARK_ any) { t.F_declares_default_QMARK_ = c__declares_default_QMARK_ }
//line :505:1
func (t *A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A) Invoke_O_O__O(self, j__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_1484 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = j__1; if linked_1485 == nil { and__1927000168__auto____2 = ifn_1486.Invoke_O__O(arg_1487) } else { and__1927000168__auto____2 = linked_1485.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1484, arg_1487) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1488 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = j__1; if linked_1489 == nil { tmp1 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp1 = linked_1489.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1488, arg_1491) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_1492 any = A_arbace_j2g_model_A_const_83.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_53; var tmp4 any; var root_1502 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = j__1; if linked_1503 == nil { tmp4 = ifn_1504.Invoke_O__O(arg_1505) } else { tmp4 = linked_1503.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1502, arg_1505) }; arg_1495 = tmp2.Invoke_O_O__O(self, tmp3.Invoke_O__O(tmp4)); var arg_1496 any
		if jrt.J2g_Truth(lang.IFn_Cast(t.F_declares_default_QMARK_).Invoke_O__O(j__1)) { arg_1496 = lang.Tuple_Create_O__IPersistentVector(j__1) } else { arg_1496 = nil }
//line :507:1
		if linked_1493 == nil { return ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { return linked_1493.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) } } else {
//line :506:1
			return nil
		}
}
func A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A_New() *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A{}; t.Ctor(); return t }
//line :509:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A) Ctor() {}
//line :509:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A) Invoke_O_O__O(self, s__1479000152__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1595 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A_New_O_O(s__1479000152__1, self); var tmp2 *jrt.Class; var fncls__1594 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A_fn_class; if fncls__1594 == nil { var fncls__1594d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__1595); A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A_fn_class = fncls__1594d; tmp2 = fncls__1594d } else { tmp2 = fncls__1594 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1595, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :509:1
func A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A{}; t.Ctor_O_O(p0, p1); return t }
//line :509:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A) Ctor_O_O(c__s__1479000152, c__iter__1479000151 any) { t.F_s__1479000152 = c__s__1479000152; t.F_iter__1479000151 = c__iter__1479000151 }
//line :509:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A) Invoke_O__O(self any) any { { var s__1479000152__1 any; var t_ any = t.F_s__1479000152; t.F_s__1479000152 = nil; s__1479000152__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1516 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = s__1479000152__1; if linked_1517 == nil { temp__1927000414__auto____2 = ifn_1518.Invoke_O__O(arg_1519) } else { temp__1927000414__auto____2 = linked_1517.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1516, arg_1519) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000152__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1520 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = s__1479000152__3; if linked_1521 == nil { tmp1 = ifn_1522.Invoke_O__O(arg_1523) } else { tmp1 = linked_1521.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1520, arg_1523) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1524 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = s__1479000152__3; if linked_1525 == nil { c__1927001037__auto____4 = ifn_1526.Invoke_O__O(arg_1527) } else { c__1927001037__auto____4 = linked_1525.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1524, arg_1527) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000154__6 any; var root_1528 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1529 == nil { b__1479000154__6 = ifn_1530.Invoke_O__O(arg_1531) } else { b__1479000154__6 = linked_1529.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1528, arg_1531) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1546 any = A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A_New_O_I_O(b__1479000154__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1545 *jrt.Class = A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A_fn_class; if fncls__1545 == nil { var fncls__1545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__1546); A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A_fn_class = fncls__1545d; tmp3 = fncls__1545d } else { tmp3 = fncls__1545 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1546, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1547 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any; var root_1552 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = b__1479000154__6; if linked_1553 == nil { arg_1550 = ifn_1554.Invoke_O__O(arg_1555) } else { arg_1550 = linked_1553.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1552, arg_1555) }; var arg_1551 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000151); var tmp5 any; var root_1556 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = s__1479000152__3; if linked_1557 == nil { tmp5 = ifn_1558.Invoke_O__O(arg_1559) } else { tmp5 = linked_1557.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1556, arg_1559) }; arg_1551 = tmp4.Invoke_O__O(tmp5); if linked_1548 == nil { return ifn_1549.Invoke_O_O__O(arg_1550, arg_1551) } else { return linked_1548.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1547, arg_1550, arg_1551) } } else { var root_1560 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any; var root_1565 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = b__1479000154__6; if linked_1566 == nil { arg_1563 = ifn_1567.Invoke_O__O(arg_1568) } else { arg_1563 = linked_1566.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1565, arg_1568) }; var arg_1564 any; if linked_1561 == nil { return ifn_1562.Invoke_O_O__O(arg_1563, arg_1564) } else { return linked_1561.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1560, arg_1563, arg_1564) } } } else { var j__4 any; var root_1569 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = s__1479000152__3; if linked_1570 == nil { j__4 = ifn_1571.Invoke_O__O(arg_1572) } else { j__4 = linked_1570.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1569, arg_1572) }; var tmp6 any; var root_1573 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1575 lang.IFn
																if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any; var root_1577 any = A_arbace_j2g_model_A_const_185.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = j__4; if linked_1578 == nil { arg_1576 = ifn_1579.Invoke_O__O(arg_1580) } else { arg_1576 = linked_1578.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1577, arg_1580) }; if linked_1574 == nil { tmp6 = ifn_1575.Invoke_O__O(arg_1576) } else { tmp6 = linked_1574.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1573, arg_1576) }
//line :509:1
	if jrt.J2g_Truth(tmp6) { var root_1581 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = j__4; var arg_1585 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1479000151); var tmp8 any; var root_1586 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1588 lang.IFn; if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = s__1479000152__3; if linked_1587 == nil { tmp8 = ifn_1588.Invoke_O__O(arg_1589) } else { tmp8 = linked_1587.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1586, arg_1589) }; arg_1585 = tmp7.Invoke_O__O(tmp8); if linked_1582 == nil { return ifn_1583.Invoke_O_O__O(arg_1584, arg_1585) } else { return linked_1582.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1581, arg_1584, arg_1585) } } else { var tmp9 any; var root_1590 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1592 lang.IFn; if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = s__1479000152__3; if linked_1591 == nil { tmp9 = ifn_1592.Invoke_O__O(arg_1593) } else { tmp9 = linked_1591.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1590, arg_1593) }; s__1479000152__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :509:1
func A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :509:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A) Ctor_O_I_O(c__b__1479000154 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000154 = c__b__1479000154; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :509:1
func (t *A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A) Invoke_O__O(self any) any { { var i__1479000153__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000153__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000153__1)); var tmp2 any; var root_1532 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1534 lang.IFn
																		if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var root_1536 any = A_arbace_j2g_model_A_const_185.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = j__2; if linked_1537 == nil { arg_1535 = ifn_1538.Invoke_O__O(arg_1539) } else { arg_1535 = linked_1537.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1536, arg_1539) }; if linked_1533 == nil { tmp2 = ifn_1534.Invoke_O__O(arg_1535) } else { tmp2 = linked_1533.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1532, arg_1535) }
//line :509:1
	if jrt.J2g_Truth(tmp2) { var root_1540 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = t.F_b__1479000154; var arg_1544 any = j__2; if linked_1541 == nil { ifn_1542.Invoke_O_O__O(arg_1543, arg_1544) } else { linked_1541.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1540, arg_1543, arg_1544) }; i__1479000153__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000153__1); continue L1 } else { i__1479000153__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000153__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_trivial_init_QMARK__A_New() *A_arbace_j2g_model_trivial_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Ctor() {}
//line :513:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_186; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var tmp2 any; var root_1603 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1605 lang.IFn; if





	linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any; var root_1608 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = cache__2; if linked_1609 == nil { arg_1606 = ifn_1610.Invoke_O__O(arg_1611) } else { arg_1606 = linked_1609.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1608, arg_1611) }; var arg_1607 any = n__0; if linked_1604 == nil { tmp2 = ifn_1605.Invoke_O_O__O(arg_1606, arg_1607) } else { tmp2 = linked_1604.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1603, arg_1606, arg_1607) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1612 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = cache__2; if linked_1613 == nil { tmp3 = ifn_1614.Invoke_O__O(arg_1615) } else { tmp3 = linked_1613.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1612, arg_1615) }; return lang.RT_Get_O_O__O_NoInit(tmp3, n__0) } else {
//line :519:1
			var r__3 any; var tmp4 any; var root_1616 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1618 lang.IFn


			if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any; var root_1620 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = n__0; if linked_1621 == nil { arg_1619 = ifn_1622.Invoke_O__O(arg_1623) } else { arg_1619 = linked_1621.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1620, arg_1623) }; if linked_1617 == nil { tmp4 = ifn_1618.Invoke_O__O(arg_1619) } else { tmp4 = linked_1617.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1616, arg_1619) }
//line :521:1
			if jrt.J2g_Truth(tmp4) { r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1624 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1626 lang.IFn

				if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = n__0; if linked_1625 == nil { tmp5 = ifn_1626.Invoke_O__O(arg_1627) } else { tmp5 = linked_1625.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1624, arg_1627) }
//line :521:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__3 = jrt.Boolean_TRUE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__3 any; var root_1628 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1630 lang.IFn


					if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = n__0; if linked_1629 == nil { d__3 = ifn_1630.Invoke_O__O(arg_1631) } else { d__3 = linked_1629.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1628, arg_1631) }
//line :521:1
					var st__4 any; var root_1632 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1634 lang.IFn


					if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(d__3); if linked_1633 == nil { st__4 = ifn_1634.Invoke_O__O(arg_1635) } else { st__4 = linked_1633.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1632, arg_1635) }
//line :521:1
					var and__1927000168__auto____5 any; var root_1636 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1638 lang.IFn




					if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = A_arbace_j2g_model_A_const_188.Invoke_O__O(st__4); if linked_1637 == nil { and__1927000168__auto____5 = ifn_1638.Invoke_O__O(arg_1639) } else { and__1927000168__auto____5 = linked_1637.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1636, arg_1639) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1640 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1642 lang.IFn
						if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = A_arbace_j2g_model_A_const_189.Invoke_O__O(st__4); if linked_1641 == nil { and__1927000168__auto____6 = ifn_1642.Invoke_O__O(arg_1643) } else { and__1927000168__auto____6 = linked_1641.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1640, arg_1643) }
//line :526:1
						if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1644 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1646 lang.IFn

							if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = A_arbace_j2g_model_A_const_190.Invoke_O__O(st__4); if linked_1645 == nil { and__1927000168__auto____7 = ifn_1646.Invoke_O__O(arg_1647) } else { and__1927000168__auto____7 = linked_1645.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1644, arg_1647) }
//line :526:1
							if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1648 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1650 lang.IFn


								if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = A_arbace_j2g_model_A_const_191.Invoke_O__O(st__4); if linked_1649 == nil { and__1927000168__auto____8 = ifn_1650.Invoke_O__O(arg_1651) } else { and__1927000168__auto____8 = linked_1649.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1648, arg_1651) }
//line :526:1
								if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3), nil)



									if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1652 any = A_arbace_j2g_model_A_const_185.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3); if linked_1653 == nil { and__1927000168__auto____9 = ifn_1654.Invoke_O__O(arg_1655) } else { and__1927000168__auto____9 = linked_1653.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1652, arg_1655) } }
//line :526:1
									if jrt.J2g_Truth(and__1927000168__auto____9) {




										var root_1656 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any; var root_1660 any = A_arbace_j2g_model_A_const_192.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, A_arbace_j2g_model_init_superinterfaces_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = n__0; if linked_1661 == nil { arg_1659 = ifn_1662.Invoke_O__O(arg_1663) } else { arg_1659 = linked_1661.(*A_arbace_j2g_model_init_superinterfaces_A).Invoke_O_O__O(root_1660, arg_1663) }; if linked_1657 == nil { r__3 = ifn_1658.Invoke_O__O(arg_1659) } else { r__3 = linked_1657.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1656, arg_1659) } } else {
//line :526:1
											r__3 = and__1927000168__auto____9 } } else { r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :521:1
												r__3 = nil
											}
				}
			}







			var root_1664 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = cache__2; var arg_1668 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var arg_1669 any = n__0; var arg_1670 any = r__3; if linked_1665 == nil { ifn_1666.Invoke_O_O_O_O__O(arg_1667, arg_1668, arg_1669, arg_1670) } else { linked_1665.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1664, arg_1667, arg_1668, arg_1669, arg_1670) }
//line :519:1
			return r__3 } }


















func A_arbace_j2g_model_go_qualified_name_A_New() *A_arbace_j2g_model_go_qualified_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_qualified_name_A{}; t.Ctor(); return t }
//line :538:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Ctor() {}
//line :538:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_1671 any = A_arbace_j2g_model_A_const_193.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any; var root_1675 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, A_arbace_j2g_model_pkg_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = n__0; if linked_1676 == nil { arg_1674 = ifn_1677.Invoke_O__O(arg_1678) } else { arg_1674 = linked_1676.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_1675, arg_1678) }; if linked_1672 == nil { tmp2 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp2 = linked_1672.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A).Invoke_O_O__O(root_1671, arg_1674) }; var tmp3 any = tmp2; var tmp4 any; var root_1679 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1681 lang.IFn; if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = n__0; if linked_1680 == nil { tmp4 = ifn_1681.Invoke_O__O(arg_1682) } else { tmp4 = linked_1680.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1679, arg_1682) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
}




func A_arbace_j2g_model_start_class_QMARK__A_New() *A_arbace_j2g_model_start_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_class_QMARK__A{}; t.Ctor(); return t }
//line :548:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Ctor() {}
//line :548:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_1683 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1685 lang.IFn; if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); if linked_1684 == nil { and__1927000168__auto____2 = ifn_1685.Invoke_O__O(arg_1686) } else { and__1927000168__auto____2 = linked_1684.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1683, arg_1686) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1687 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any = n__0; if linked_1688 == nil { and__1927000168__auto____3 = ifn_1689.Invoke_O__O(arg_1690) } else { and__1927000168__auto____3 = linked_1688.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1687, arg_1690) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1691 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var arg_1695 any; var root_1696 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = n__0; if linked_1697 == nil { arg_1695 = ifn_1698.Invoke_O__O(arg_1699) } else { arg_1695 = linked_1697.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1696, arg_1699) }; if linked_1692 == nil { and__1927000168__auto____4 = ifn_1693.Invoke_O_O__O(arg_1694, arg_1695) } else { and__1927000168__auto____4 = linked_1692.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1691, arg_1694, arg_1695) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1700 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any; var root_1704 any = A_arbace_j2g_model_A_const_185.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = n__0; if linked_1705 == nil { arg_1703 = ifn_1706.Invoke_O__O(arg_1707) } else { arg_1703 = linked_1705.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1704, arg_1707) }; if linked_1701 == nil { tmp1 = ifn_1702.Invoke_O__O(arg_1703) } else { tmp1 = linked_1701.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1700, arg_1703) } } else {
//line :552:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_j2g_model_start_classes_A_New() *A_arbace_j2g_model_start_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_j2g_model_start_classes_A) Ctor() {}
//line :555:1
func (t *A_arbace_j2g_model_start_classes_A) Invoke_O__O(self any) any { var by_go__1 any; var root_1708 any = A_arbace_j2g_model_A_const_196.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1710 lang.IFn; if


	linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1712 any; var iter__1927001039__auto____1 any; var fnbody__1794 any = A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A_New(); var tmp1 *jrt.Class; var fncls__1793 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A_fn_class; if fncls__1793 == nil { var fncls__1793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A_fn_class = fncls__1793d; tmp1 = fncls__1793d } else { tmp1 = fncls__1793 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1794, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp3 any; var root_1795 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, A_arbace_j2g_model_T_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; if linked_1796 == nil { tmp3 = ifn_1797.Invoke__O() } else { tmp3 = linked_1796.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_1795) }; arg_1712 = tmp2.Invoke_O__O(tmp3); if linked_1709 == nil { by_go__1 = ifn_1710.Invoke_O_O__O(arg_1711, arg_1712) } else { by_go__1 = linked_1709.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1708, arg_1711, arg_1712) }; var root_1798 any =
	A_arbace_j2g_model_A_const_198.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = by_go__1; var arg_1802 any = A_arbace_j2g_model_A_const_199.GetRawRoot__O(); if linked_1799 == nil { return ifn_1800.Invoke_O_O__O(arg_1801, arg_1802) } else { return linked_1799.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1798, arg_1801, arg_1802) } }
//line :558:1
func A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A_New() *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A{}; t.Ctor(); return t }
//line :558:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A) Ctor() {}
//line :558:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A) Invoke_O_O__O(self, s__1479000166__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1792 any = A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A_New_O_O(s__1479000166__1, self); var tmp2 *jrt.Class; var fncls__1791 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A_fn_class; if fncls__1791 == nil { var fncls__1791d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1792); A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A_fn_class = fncls__1791d; tmp2 = fncls__1791d } else { tmp2 = fncls__1791 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1792, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :558:1
func A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A{}; t.Ctor_O_O(p0, p1); return t }
//line :558:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A) Ctor_O_O(c__s__1479000166, c__iter__1479000165 any) { t.F_s__1479000166 = c__s__1479000166; t.F_iter__1479000165 = c__iter__1479000165 }
//line :558:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A) Invoke_O__O(self any) any { { var s__1479000166__1 any; var t_ any = t.F_s__1479000166; t.F_s__1479000166 = nil; s__1479000166__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1713 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = s__1479000166__1; if linked_1714 == nil { temp__1927000414__auto____2 = ifn_1715.Invoke_O__O(arg_1716) } else { temp__1927000414__auto____2 = linked_1714.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1713, arg_1716) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000166__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1717 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = s__1479000166__3; if linked_1718 == nil { tmp1 = ifn_1719.Invoke_O__O(arg_1720) } else { tmp1 = linked_1718.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1717, arg_1720) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1721 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = s__1479000166__3; if linked_1722 == nil { c__1927001037__auto____4 = ifn_1723.Invoke_O__O(arg_1724) } else { c__1927001037__auto____4 = linked_1722.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1721, arg_1724) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000168__6 any; var root_1725 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1726 == nil { b__1479000168__6 = ifn_1727.Invoke_O__O(arg_1728) } else { b__1479000168__6 = linked_1726.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1725, arg_1728) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1743 any = A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A_New_O_I_O(b__1479000168__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1742 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A_fn_class; if fncls__1742 == nil { var fncls__1742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1743); A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A_fn_class = fncls__1742d; tmp3 = fncls__1742d } else { tmp3 = fncls__1742 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1743, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1744 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any; var root_1749 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = b__1479000168__6; if linked_1750 == nil { arg_1747 = ifn_1751.Invoke_O__O(arg_1752) } else { arg_1747 = linked_1750.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1749, arg_1752) }; var arg_1748 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000165); var tmp5 any; var root_1753 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = s__1479000166__3; if linked_1754 == nil { tmp5 = ifn_1755.Invoke_O__O(arg_1756) } else { tmp5 = linked_1754.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1753, arg_1756) }; arg_1748 = tmp4.Invoke_O__O(tmp5); if linked_1745 == nil { return ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { return linked_1745.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) } } else { var root_1757 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any; var root_1762 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = b__1479000168__6; if linked_1763 == nil { arg_1760 = ifn_1764.Invoke_O__O(arg_1765) } else { arg_1760 = linked_1763.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1762, arg_1765) }; var arg_1761 any; if linked_1758 == nil { return ifn_1759.Invoke_O_O__O(arg_1760, arg_1761) } else { return linked_1758.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1757, arg_1760, arg_1761) } } } else { var n__4 any; var root_1766 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = s__1479000166__3; if linked_1767 == nil { n__4 = ifn_1768.Invoke_O__O(arg_1769) } else { n__4 = linked_1767.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1766, arg_1769) }; var tmp6 any; var root_1770 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = n__4; if linked_1771 == nil { tmp6 = ifn_1772.Invoke_O__O(arg_1773) } else { tmp6 = linked_1771.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1770, arg_1773) }; if jrt.J2g_Truth(tmp6) { var root_1774 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any; var tmp7 any; var root_1779 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = n__4; if linked_1780 == nil { tmp7 = ifn_1781.Invoke_O__O(arg_1782) } else { tmp7 = linked_1780.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1779, arg_1782) }; arg_1777 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, n__4); var arg_1778 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000165); var tmp9 any; var root_1783 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = s__1479000166__3; if linked_1784 == nil { tmp9 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp9 = linked_1784.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1783, arg_1786) }; arg_1778 = tmp8.Invoke_O__O(tmp9); if linked_1775 == nil { return ifn_1776.Invoke_O_O__O(arg_1777, arg_1778) } else { return linked_1775.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1774, arg_1777, arg_1778) } } else { var tmp10 any; var root_1787 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = s__1479000166__3; if linked_1788 == nil { tmp10 = ifn_1789.Invoke_O__O(arg_1790) } else { tmp10 = linked_1788.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1787, arg_1790) }; s__1479000166__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :558:1
func A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :558:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A) Ctor_O_I_O(c__b__1479000168 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000168 = c__b__1479000168; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :558:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A) Invoke_O__O(self any) any { { var i__1479000167__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000167__1)); var tmp2 any; var root_1729 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1731 lang.IFn; if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = n__2; if linked_1730 == nil { tmp2 = ifn_1731.Invoke_O__O(arg_1732) } else { tmp2 = linked_1730.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1729, arg_1732) }; if jrt.J2g_Truth(tmp2) { var root_1733 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1735 lang.IFn; if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = t.F_b__1479000168; var arg_1737 any; var tmp3 any; var root_1738 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = n__2; if linked_1739 == nil { tmp3 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp3 = linked_1739.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1738, arg_1741) }; arg_1737 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, n__2); if linked_1734 == nil { ifn_1735.Invoke_O_O__O(arg_1736, arg_1737) } else { linked_1734.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1733, arg_1736, arg_1737) }; i__1479000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000167__1); continue L1 } else { i__1479000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000167__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_model_top_class_A_New() *A_arbace_j2g_model_top_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_top_class_A{}; t.Ctor(); return t }
//line :566:1
func (t *A_arbace_j2g_model_top_class_A) Ctor() {}
//line :566:1
func (t *A_arbace_j2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_57); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1803 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = n__0; var arg_1807 any = A_arbace_j2g_model_A_const_31; var arg_1808 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1804 == nil { return ifn_1805.Invoke_O_O_O__O(arg_1806, arg_1807, arg_1808) } else { return linked_1804.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1803, arg_1806, arg_1807, arg_1808) } } }

func A_arbace_j2g_model_pure_ctor_QMARK__A_New() *A_arbace_j2g_model_pure_ctor_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :568:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :568:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any; var root_1809 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1811 lang.IFn; if




	linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = c__1; if linked_1810 == nil { d__5 = ifn_1811.Invoke_O__O(arg_1812) } else { d__5 = linked_1810.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1809, arg_1812) }; var ab__6 any; if
	jrt.J2g_Truth(d__5) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_200; var tmp2 any; var root_1813 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(d__5); if linked_1814 == nil { tmp2 = ifn_1815.Invoke_O__O(arg_1816) } else { tmp2 = linked_1814.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1813, arg_1816) }; ab__6 = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), lang.Tuple_Create_O_O__IPersistentVector(Lit_43, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_1817 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = c__1; if linked_1818 == nil { and__1927000168__auto____9 = ifn_1819.Invoke_O__O(arg_1820) } else { and__1927000168__auto____9 = linked_1818.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1817, arg_1820) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp3 any; var root_1821 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1823 lang.IFn
		if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = c__1; if linked_1822 == nil { tmp3 = ifn_1823.Invoke_O__O(arg_1824) } else { tmp3 = linked_1822.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1821, arg_1824) }; var tmp4 any = tmp3; var tmp5 any; var root_1825 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = n__0; if linked_1826 == nil { tmp5 = ifn_1827.Invoke_O__O(arg_1828) } else { tmp5 = linked_1826.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1825, arg_1828) }; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)
//line :575:1
		if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_1829 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1831 lang.IFn

			if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any; var root_1833 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = seen__3; var arg_1837 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)); if linked_1834 == nil { arg_1832 = ifn_1835.Invoke_O_O__O(arg_1836, arg_1837) } else { arg_1832 = linked_1834.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1833, arg_1836, arg_1837) }; if linked_1830 == nil { and__1927000168__auto____11 = ifn_1831.Invoke_O__O(arg_1832) } else { and__1927000168__auto____11 = linked_1830.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1829, arg_1832) }
//line :575:1
			if jrt.J2g_Truth(and__1927000168__auto____11) { var seen__12 any; var root_1838 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1840 lang.IFn


				if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = seen__3; var arg_1842 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)); if linked_1839 == nil { seen__12 = ifn_1840.Invoke_O_O__O(arg_1841, arg_1842) } else { seen__12 = linked_1839.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1838, arg_1841, arg_1842) }
//line :575:1
				var call__13 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(ab__6); var sup__14 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__5); var and__1927000168__auto____15 any; var root_1843 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1843, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1845 lang.IFn





				if linked_1844 == nil { ifn_1845 = lang.IFn_Cast(root_1843) } else { ifn_1845 = nil }; var arg_1846 any = A_arbace_j2g_model_A_const_203.Invoke_O__O(ab__6); if linked_1844 == nil { and__1927000168__auto____15 = ifn_1845.Invoke_O__O(arg_1846) } else { and__1927000168__auto____15 = linked_1844.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1843, arg_1846) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1847 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1849 lang.IFn
					if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = A_arbace_j2g_model_A_const_204.Invoke_O__O(ab__6); if linked_1848 == nil { and__1927000168__auto____16 = ifn_1849.Invoke_O__O(arg_1850) } else { and__1927000168__auto____16 = linked_1848.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1847, arg_1850) }
//line :581:1
					if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z_NoInit(call__13, nil)

						if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var root_1851 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1853 lang.IFn
							if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any; var fnbody__1863 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A_New_O_O(n__0, seen__12); var tmp6 *jrt.Class; var fncls__1862 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A_fn_class; if fncls__1862 == nil { var fncls__1862d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__1863); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A_fn_class = fncls__1862d; tmp6 = fncls__1862d } else { tmp6 = fncls__1862 }; arg_1854 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1863, tmp6, nil); var arg_1855 any = A_arbace_j2g_model_A_const_206.Invoke_O__O(call__13); if linked_1852 == nil { and__1927000168__auto____18 = ifn_1853.Invoke_O_O__O(arg_1854, arg_1855) } else { and__1927000168__auto____18 = linked_1852.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1851, arg_1854, arg_1855) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_175.Invoke_O__O(call__13), nil)
								if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19).Ref() } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_207); var or__1927000174__auto____20 any = tmp7.Invoke_O__O(A_arbace_j2g_model_A_const_175.Invoke_O__O(call__13)); if jrt.J2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
									var root_1864 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = n__0; var arg_1868 any = A_arbace_j2g_model_A_const_175.Invoke_O__O(call__13); var arg_1869 any = A_arbace_j2g_model_A_const_209.Invoke_O__O(call__13); var arg_1870 any = seen__12; if linked_1865 == nil { and__1927000168__auto____17 = ifn_1866.Invoke_O_O_O_O__O(arg_1867, arg_1868, arg_1869, arg_1870) } else { and__1927000168__auto____17 = linked_1865.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1864, arg_1867, arg_1868, arg_1869, arg_1870) } } } } else {
//line :584:1
										and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :581:1
						if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any; var root_1871 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1873 lang.IFn





							if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = call__13; if linked_1872 == nil { or__1927000174__auto____18 = ifn_1873.Invoke_O__O(arg_1874) } else { or__1927000174__auto____18 = linked_1872.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1871, arg_1874) }; if jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z_NoInit(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sup__14, Lit_30)).Ref() } }
//line :581:1
							if jrt.J2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var root_1875 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1877 lang.IFn






								if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any; var fnbody__1887 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A_New_O_O(n__0, seen__12); var tmp8 *jrt.Class; var fncls__1886 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A_fn_class; if fncls__1886 == nil { var fncls__1886d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__1887); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A_fn_class = fncls__1886d; tmp8 = fncls__1886d } else { tmp8 = fncls__1886 }; arg_1878 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1887, tmp8, nil); var arg_1879 any; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_210; var tmp10 any; var root_1888 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(d__5); if linked_1889 == nil { tmp10 = ifn_1890.Invoke_O__O(arg_1891) } else { tmp10 = linked_1889.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1888, arg_1891) }; arg_1879 = tmp9.Invoke_O__O(tmp10); if linked_1876 == nil { and__1927000168__auto____19 = ifn_1877.Invoke_O_O__O(arg_1878, arg_1879) } else { and__1927000168__auto____19 = linked_1876.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1875, arg_1878, arg_1879) }
//line :581:1
								if jrt.J2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_211.Invoke_O__O(ab__6), nil)







									if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20_2).Ref() } else { var root_1892 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = n__0; var arg_1896 any = A_arbace_j2g_model_A_const_211.Invoke_O__O(ab__6); var arg_1897 any = seen__12; if linked_1893 == nil { return ifn_1894.Invoke_O_O_O__O(arg_1895, arg_1896, arg_1897) } else { return linked_1893.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1892, arg_1895, arg_1896, arg_1897) } } } else {
//line :581:1
										return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :575:1
											return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A{}; t.Ctor_O_O(p0, p1); return t }
//line :584:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :584:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A) Invoke_O_O__O(self, p1__1479000177_SHARP___1 any) any { var root_1856 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = t.F_n; var arg_1860 any = p1__1479000177_SHARP___1; var arg_1861 any = t.F_seen; if linked_1857 == nil { return ifn_1858.Invoke_O_O_O__O(arg_1859, arg_1860, arg_1861) } else { return linked_1857.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1856, arg_1859, arg_1860, arg_1861) } }



func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A{}; t.Ctor_O_O(p0, p1); return t }
//line :588:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :588:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A) Invoke_O_O__O(self, p1__1479000178_SHARP___1 any) any { var root_1880 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = t.F_n; var arg_1884 any = p1__1479000178_SHARP___1; var arg_1885 any = t.F_seen; if linked_1881 == nil { return ifn_1882.Invoke_O_O_O__O(arg_1883, arg_1884, arg_1885) } else { return linked_1881.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1880, arg_1883, arg_1884, arg_1885) } }


func A_arbace_j2g_model_pure_node_QMARK__A_New() *A_arbace_j2g_model_pure_node_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :591:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Ctor() {}
//line :591:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1479000190__4_ any = A_arbace_j2g_model_A_const_212.Invoke_O__O(node__1); switch



	lang.Util_Hash_O__I_NoInit(G__1479000190__4_) >> 3 & 63 { case 1: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_213) { var and__1927000168__auto____5 any; var root_1899 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1901 lang.IFn


















		if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = A_arbace_j2g_model_A_const_214.Invoke_O__O(node__1); if linked_1900 == nil { and__1927000168__auto____5 = ifn_1901.Invoke_O__O(arg_1902) } else { and__1927000168__auto____5 = linked_1900.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1899, arg_1902) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1903 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = A_arbace_j2g_model_A_const_215.Invoke_O__O(node__1); if linked_1904 == nil { and__1927000168__auto____6 = ifn_1905.Invoke_O__O(arg_1906) } else { and__1927000168__auto____6 = linked_1904.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1903, arg_1906) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1907 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = n__0; var arg_1911 any = A_arbace_j2g_model_A_const_216.Invoke_O__O(node__1); var arg_1912 any = seen__2; if linked_1908 == nil { return ifn_1909.Invoke_O_O_O__O(arg_1910, arg_1911, arg_1912) } else { return linked_1908.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1907, arg_1910, arg_1911, arg_1912) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :595:1
	case 11: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_217) { var tmp1 any = A_arbace_j2g_model_A_const_218; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_212; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_219.Invoke_O__O(node__1)))







		if and__1927000168__auto____5_2 { var and__1927000168__auto____6_2 any; var root_1913 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_220; var arg_1916 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_219.Invoke_O__O(node__1)); if linked_1914 == nil { and__1927000168__auto____6_2 = ifn_1915.Invoke_O__O(arg_1916) } else { and__1927000168__auto____6_2 = linked_1914.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1913, arg_1916) }; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var root_1917 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = n__0; var arg_1921 any = A_arbace_j2g_model_A_const_221.Invoke_O__O(node__1); var arg_1922 any = seen__2; if linked_1918 == nil { return ifn_1919.Invoke_O_O_O__O(arg_1920, arg_1921, arg_1922) } else { return linked_1918.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1917, arg_1920, arg_1921, arg_1922) } } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() } }
//line :595:1
	case 13: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_222) { var tmp4 any = A_arbace_j2g_model_A_const_223; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_j2g_model_A_const_170.Invoke_O__O(node__1))













		if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_64, A_arbace_j2g_model_A_const_151.Invoke_O__O(node__1))
			if and__1927000168__auto____6_4 { or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_65, A_arbace_j2g_model_A_const_125.Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, A_arbace_j2g_model_A_const_151.Invoke_O__O(node__1))

				if and__1927000168__auto____7 { and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_66, A_arbace_j2g_model_A_const_125.Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :609:1
			if and__1927000168__auto____6_3 {



				var root_1923 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any; var fnbody__1935 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A_New_O_O(n__0, seen__2); var tmp5 *jrt.Class; var fncls__1934 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A_fn_class; if fncls__1934 == nil { var fncls__1934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__1935); A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A_fn_class = fncls__1934d; tmp5 = fncls__1934d } else { tmp5 = fncls__1934 }; arg_1926 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1935, tmp5, nil); var arg_1927 any = A_arbace_j2g_model_A_const_206.Invoke_O__O(node__1); if linked_1924 == nil { return ifn_1925.Invoke_O_O__O(arg_1926, arg_1927) } else { return linked_1924.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1923, arg_1926, arg_1927) } } else {
//line :609:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_3).Ref() } }
//line :595:1
	case 14: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_224) { var and__1927000168__auto____5_4 bool; var tmp6 any; var tmp7 *lang.Keyword = A_arbace_j2g_model_A_const_225; var or__1927000174__auto____5 any = tmp7.Invoke_O__O(A_arbace_j2g_model_A_const_226.Invoke_O__O(node__1))






		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp6 = or__1927000174__auto____5 } else { var tmp8 *lang.Keyword = A_arbace_j2g_model_A_const_151; tmp6 = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_226.Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp6); if and__1927000168__auto____5_4 { var root_1936 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1938 lang.IFn; if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = n__0; var arg_1940 any = A_arbace_j2g_model_A_const_221.Invoke_O__O(node__1); var arg_1941 any = seen__2; if linked_1937 == nil { return ifn_1938.Invoke_O_O_O__O(arg_1939, arg_1940, arg_1941) } else { return linked_1937.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1936, arg_1939, arg_1940, arg_1941) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_4).Ref() } }
//line :595:1
	case 15: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_218) { return jrt.Boolean_TRUE.Ref() }; case 19: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_227) { var and__1927000168__auto____5_5 any; var root_1942 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1944 lang.IFn


		if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any; var fnbody__1954 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A_New_O_O(n__0, seen__2); var tmp9 *jrt.Class; var fncls__1953 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A_fn_class; if fncls__1953 == nil { var fncls__1953d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__1954); A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A_fn_class = fncls__1953d; tmp9 = fncls__1953d } else { tmp9 = fncls__1953 }; arg_1945 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1954, tmp9, nil); var arg_1946 any = A_arbace_j2g_model_A_const_228.Invoke_O__O(node__1); if linked_1943 == nil { and__1927000168__auto____5_5 = ifn_1944.Invoke_O_O__O(arg_1945, arg_1946) } else { and__1927000168__auto____5_5 = linked_1943.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1942, arg_1945, arg_1946) }; if jrt.J2g_Truth(and__1927000168__auto____5_5) { var root_1955 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = n__0; var arg_1959 any = A_arbace_j2g_model_A_const_211.Invoke_O__O(node__1); var arg_1960 any = seen__2; if linked_1956 == nil { return ifn_1957.Invoke_O_O_O__O(arg_1958, arg_1959, arg_1960) } else { return linked_1956.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1955, arg_1958, arg_1959, arg_1960) } } else { return and__1927000168__auto____5_5 } }
//line :595:1
	case 21: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_229) {





		var tmp10 any; var tmp11 *lang.Keyword = A_arbace_j2g_model_A_const_225; var or__1927000174__auto____5_2 any = tmp11.Invoke_O__O(A_arbace_j2g_model_A_const_226.Invoke_O__O(node__1)); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp10 = or__1927000174__auto____5_2 } else { var tmp12 *lang.Keyword = A_arbace_j2g_model_A_const_151; tmp10 = tmp12.Invoke_O__O(A_arbace_j2g_model_A_const_226.Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp10)).Ref() }
//line :595:1
	case 25: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_230) { var and__1927000168__auto____5_6 any; var root_1961 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1961, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1963 lang.IFn

		if linked_1962 == nil { ifn_1963 = lang.IFn_Cast(root_1961) } else { ifn_1963 = nil }; var arg_1964 any; var fnbody__1973 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A_New_O_O(n__0, seen__2); var tmp13 *jrt.Class; var fncls__1972 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A_fn_class; if fncls__1972 == nil { var fncls__1972d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__1973); A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A_fn_class = fncls__1972d; tmp13 = fncls__1972d } else { tmp13 = fncls__1972 }; arg_1964 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1973, tmp13, nil); var arg_1965 any = A_arbace_j2g_model_A_const_231.Invoke_O__O(node__1); if linked_1962 == nil { and__1927000168__auto____5_6 = ifn_1963.Invoke_O_O__O(arg_1964, arg_1965) } else { and__1927000168__auto____5_6 = linked_1962.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1961, arg_1964, arg_1965) }; if jrt.J2g_Truth(and__1927000168__auto____5_6) { var root_1974 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = n__0; var arg_1978 any = A_arbace_j2g_model_A_const_232.Invoke_O__O(node__1); var arg_1979 any = seen__2; if linked_1975 == nil { return ifn_1976.Invoke_O_O_O__O(arg_1977, arg_1978, arg_1979) } else { return linked_1975.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1974, arg_1977, arg_1978, arg_1979) } } else { return and__1927000168__auto____5_6 } }
//line :595:1
	case 29: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_233) { return jrt.Boolean_TRUE.Ref() }; case 30: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_234) { return jrt.Boolean_TRUE.Ref() }; case 34: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_235) {




		var root_1980 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any; var fnbody__1994 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A_New(); var tmp14 *jrt.Class; var fncls__1993 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A_fn_class; if fncls__1993 == nil { var fncls__1993d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A_fn_class = fncls__1993d; tmp14 = fncls__1993d } else { tmp14 = fncls__1993 }; arg_1983 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1994, tmp14, nil); var arg_1984 any = A_arbace_j2g_model_A_const_237.Invoke_O__O(node__1); if linked_1981 == nil { return ifn_1982.Invoke_O_O__O(arg_1983, arg_1984) } else { return linked_1981.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1980, arg_1983, arg_1984) } }
//line :595:1
	case 39: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_238) { var and__1927000168__auto____5_7 any; var root_1995 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1997 lang.IFn








		if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any; var fnbody__2007 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A_New_O_O(n__0, seen__2); var tmp15 *jrt.Class; var fncls__2006 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A_fn_class; if fncls__2006 == nil { var fncls__2006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__2007); A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A_fn_class = fncls__2006d; tmp15 = fncls__2006d } else { tmp15 = fncls__2006 }; arg_1998 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2007, tmp15, nil); var arg_1999 any = A_arbace_j2g_model_A_const_206.Invoke_O__O(node__1); if linked_1996 == nil { and__1927000168__auto____5_7 = ifn_1997.Invoke_O_O__O(arg_1998, arg_1999) } else { and__1927000168__auto____5_7 = linked_1996.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1995, arg_1998, arg_1999) }; if jrt.J2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_239.Invoke_O__O(node__1), nil); if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_30, A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1))

			if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1), n__0)
				if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_2008 any = A_arbace_j2g_model_A_const_185.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1); if linked_2009 == nil { and__1927000168__auto____8 = ifn_2010.Invoke_O__O(arg_2011) } else { and__1927000168__auto____8 = linked_2009.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2008, arg_2011) } }; if jrt.J2g_Truth(and__1927000168__auto____8) {
					var root_2012 any = A_arbace_j2g_model_A_const_208.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = n__0; var arg_2016 any = A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1); var arg_2017 any = A_arbace_j2g_model_A_const_209.Invoke_O__O(node__1); var arg_2018 any = seen__2; if linked_2013 == nil { return ifn_2014.Invoke_O_O_O_O__O(arg_2015, arg_2016, arg_2017, arg_2018) } else { return linked_2013.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_2012, arg_2015, arg_2016, arg_2017, arg_2018) } } else {
//line :607:1
						return and__1927000168__auto____8 } } } else {
//line :604:1
							return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :595:1
	case 43: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_240) { var and__1927000168__auto____5_8 any; var root_2019 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_2020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2019, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2021 lang.IFn



















		if linked_2020 == nil { ifn_2021 = lang.IFn_Cast(root_2019) } else { ifn_2021 = nil }; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_241); var arg_2022 any = tmp16.Invoke_O__O(A_arbace_j2g_model_A_const_242.Invoke_O__O(node__1)); if linked_2020 == nil { and__1927000168__auto____5_8 = ifn_2021.Invoke_O__O(arg_2022) } else { and__1927000168__auto____5_8 = linked_2020.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2019, arg_2022) }; if jrt.J2g_Truth(and__1927000168__auto____5_8) { var and__1927000168__auto____6_6 any; var root_2023 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2023, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2025 lang.IFn; if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2026 any = A_arbace_j2g_model_A_const_243; var arg_2027 any = A_arbace_j2g_model_A_const_244.Invoke_O__O(node__1); if linked_2024 == nil { and__1927000168__auto____6_6 = ifn_2025.Invoke_O_O__O(arg_2026, arg_2027) } else { and__1927000168__auto____6_6 = linked_2024.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2023, arg_2026, arg_2027) }; if jrt.J2g_Truth(and__1927000168__auto____6_6) { var root_2028 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any; var fnbody__2040 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_New_O_O(n__0, seen__2); var tmp17 *jrt.Class; var fncls__2039 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_fn_class; if fncls__2039 == nil { var fncls__2039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__2040); A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_fn_class = fncls__2039d; tmp17 = fncls__2039d } else { tmp17 = fncls__2039 }; arg_2031 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2040, tmp17, nil); var arg_2032 any = A_arbace_j2g_model_A_const_206.Invoke_O__O(node__1); if linked_2029 == nil { return ifn_2030.Invoke_O_O__O(arg_2031, arg_2032) } else { return linked_2029.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2028, arg_2031, arg_2032) } } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :595:1
	case 44: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_245) { return jrt.Boolean_TRUE.Ref() }; case 46: if any(G__1479000190__4_) == any(A_arbace_j2g_model_A_const_246) {



		var root_2041 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any; var fnbody__2053 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_New_O_O(n__0, seen__2); var tmp18 *jrt.Class; var fncls__2052 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_fn_class; if fncls__2052 == nil { var fncls__2052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__2053); A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_fn_class = fncls__2052d; tmp18 = fncls__2052d } else { tmp18 = fncls__2052 }; arg_2044 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2053, tmp18, nil); var arg_2045 any = A_arbace_j2g_model_A_const_247.Invoke_O__O(node__1); if linked_2042 == nil { return ifn_2043.Invoke_O_O__O(arg_2044, arg_2045) } else { return linked_2042.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2041, arg_2044, arg_2045) } }
//line :595:1
	default:}; return jrt.Boolean_FALSE.Ref() }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A{}; t.Ctor_O_O(p0, p1); return t }
//line :597:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :597:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A) Invoke_O_O__O(self, p1__1479000184_SHARP___1 any) any { var root_1966 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = t.F_n; var arg_1970 any = p1__1479000184_SHARP___1; var arg_1971 any = t.F_seen; if linked_1967 == nil { return ifn_1968.Invoke_O_O_O__O(arg_1969, arg_1970, arg_1971) } else { return linked_1967.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1966, arg_1969, arg_1970, arg_1971) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A{}; t.Ctor_O_O(p0, p1); return t }
//line :598:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :598:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A) Invoke_O_O__O(self, p__1479000193__1 any) any { var vec__1479000195__2 any = p__1479000193__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000195__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000195__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1947 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1949 lang.IFn; _ = ___3; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = t.F_n; var arg_1951 any = init__4; var arg_1952 any = t.F_seen; if linked_1948 == nil { return ifn_1949.Invoke_O_O_O__O(arg_1950, arg_1951, arg_1952) } else { return linked_1948.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1947, arg_1950, arg_1951, arg_1952) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :599:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :599:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A) Invoke_O_O__O(self, p1__1479000185_SHARP___1 any) any { var root_2046 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2048 lang.IFn; if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = t.F_n; var arg_2050 any = p1__1479000185_SHARP___1; var arg_2051 any = t.F_seen; if linked_2047 == nil { return ifn_2048.Invoke_O_O_O__O(arg_2049, arg_2050, arg_2051) } else { return linked_2047.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2046, arg_2049, arg_2050, arg_2051) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A_New() *A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A{}; t.Ctor(); return t }
//line :600:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A) Ctor() {}
//line :600:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A) Invoke_O_O__O(self, p1__1479000186_SHARP___1 any) any { var tmp1 any = A_arbace_j2g_model_A_const_233; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_model_A_const_212.Invoke_O__O(p1__1479000186_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_1985 any = A_arbace_j2g_model_A_const_236.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = A_arbace_j2g_model_A_const_221.Invoke_O__O(p1__1479000186_SHARP___1); if linked_1986 == nil { and__1927000168__auto____3 = ifn_1987.Invoke_O__O(arg_1988) } else { and__1927000168__auto____3 = linked_1986.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_1985, arg_1988) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1989 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_j2g_model_A_const_221.Invoke_O__O(p1__1479000186_SHARP___1)))).Ref(); if linked_1990 == nil { return ifn_1991.Invoke_O__O(arg_1992) } else { return linked_1990.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1989, arg_1992) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A{}; t.Ctor_O_O(p0, p1); return t }
//line :604:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :604:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A) Invoke_O_O__O(self, p1__1479000187_SHARP___1 any) any { var root_2000 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = t.F_n; var arg_2004 any = p1__1479000187_SHARP___1; var arg_2005 any = t.F_seen; if linked_2001 == nil { return ifn_2002.Invoke_O_O_O__O(arg_2003, arg_2004, arg_2005) } else { return linked_2001.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2000, arg_2003, arg_2004, arg_2005) } }








func A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :613:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :613:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A) Invoke_O_O__O(self, p1__1479000188_SHARP___1 any) any { var root_1928 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1930 lang.IFn; if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = t.F_n; var arg_1932 any = p1__1479000188_SHARP___1; var arg_1933 any = t.F_seen; if linked_1929 == nil { return ifn_1930.Invoke_O_O_O__O(arg_1931, arg_1932, arg_1933) } else { return linked_1929.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1928, arg_1931, arg_1932, arg_1933) } }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A{}; t.Ctor_O_O(p0, p1); return t }
//line :615:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :615:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A) Invoke_O_O__O(self, p1__1479000189_SHARP___1 any) any { var root_2033 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = t.F_n; var arg_2037 any = p1__1479000189_SHARP___1; var arg_2038 any = t.F_seen; if linked_2034 == nil { return ifn_2035.Invoke_O_O_O__O(arg_2036, arg_2037, arg_2038) } else { return linked_2034.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2033, arg_2036, arg_2037, arg_2038) } }


func A_arbace_j2g_model_benign_init_QMARK__A_New() *A_arbace_j2g_model_benign_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :618:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Ctor() {}
//line :618:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_186; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_249, n__0); var tmp2 any; var root_2054 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2056 lang.IFn; if








	linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any; var root_2059 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = cache__2; if linked_2060 == nil { arg_2057 = ifn_2061.Invoke_O__O(arg_2062) } else { arg_2057 = linked_2060.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2059, arg_2062) }; var arg_2058 any = k__3; if linked_2055 == nil { tmp2 = ifn_2056.Invoke_O_O__O(arg_2057, arg_2058) } else { tmp2 = linked_2055.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2054, arg_2057, arg_2058) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_2063 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = cache__2; if linked_2064 == nil { tmp3 = ifn_2065.Invoke_O__O(arg_2066) } else { tmp3 = linked_2064.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2063, arg_2066) }; return lang.RT_Get_O_O__O_NoInit(tmp3, k__3) } else {
//line :627:1
			var r__4 any; var tmp4 any; var root_2067 any = A_arbace_j2g_model_A_const_185.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2069 lang.IFn


			if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = n__0; if linked_2068 == nil { tmp4 = ifn_2069.Invoke_O__O(arg_2070) } else { tmp4 = linked_2068.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2067, arg_2070) }
//line :629:1
			if jrt.J2g_Truth(tmp4) { r__4 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_2071 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2073 lang.IFn

				if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = n__0; if linked_2072 == nil { tmp5 = ifn_2073.Invoke_O__O(arg_2074) } else { tmp5 = linked_2072.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2071, arg_2074) }
//line :629:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__4 = jrt.Boolean_FALSE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__4 any; var root_2075 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2077 lang.IFn


					if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = n__0; if linked_2076 == nil { d__4 = ifn_2077.Invoke_O__O(arg_2078) } else { d__4 = linked_2076.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2075, arg_2078) }
//line :629:1
					var st__5 any; var root_2079 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2081 lang.IFn


					if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(d__4); if linked_2080 == nil { st__5 = ifn_2081.Invoke_O__O(arg_2082) } else { st__5 = linked_2080.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2079, arg_2082) }
//line :629:1
					var and__1927000168__auto____6 any; var root_2083 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2085 lang.IFn




					if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = A_arbace_j2g_model_A_const_189.Invoke_O__O(st__5); if linked_2084 == nil { and__1927000168__auto____6 = ifn_2085.Invoke_O__O(arg_2086) } else { and__1927000168__auto____6 = linked_2084.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2083, arg_2086) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_2087 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2089 lang.IFn
						if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = A_arbace_j2g_model_A_const_190.Invoke_O__O(st__5); if linked_2088 == nil { and__1927000168__auto____7 = ifn_2089.Invoke_O__O(arg_2090) } else { and__1927000168__auto____7 = linked_2088.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2087, arg_2090) }
//line :634:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_2091 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2093 lang.IFn

							if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any = A_arbace_j2g_model_A_const_191.Invoke_O__O(st__5); if linked_2092 == nil { and__1927000168__auto____8 = ifn_2093.Invoke_O__O(arg_2094) } else { and__1927000168__auto____8 = linked_2092.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2091, arg_2094) }
//line :634:1
							if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4), nil)


								if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_2095 any = A_arbace_j2g_model_A_const_248.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, A_arbace_j2g_model_benign_init_QMARK__A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4); if linked_2096 == nil { and__1927000168__auto____9 = ifn_2097.Invoke_O__O(arg_2098) } else { and__1927000168__auto____9 = linked_2096.(*A_arbace_j2g_model_benign_init_QMARK__A).Invoke_O_O__O(root_2095, arg_2098) } }
//line :634:1
								if jrt.J2g_Truth(and__1927000168__auto____9) {



									var root_2099 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any; var fnbody__2111 any = A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A_New_O(n__0); var tmp6 *jrt.Class; var fncls__2110 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A_fn_class; if fncls__2110 == nil { var fncls__2110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__2111); A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A_fn_class = fncls__2110d; tmp6 = fncls__2110d } else { tmp6 = fncls__2110 }; arg_2102 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2111, tmp6, nil); var arg_2103 any = A_arbace_j2g_model_A_const_188.Invoke_O__O(st__5); if linked_2100 == nil { r__4 = ifn_2101.Invoke_O_O__O(arg_2102, arg_2103) } else { r__4 = linked_2100.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_2099, arg_2102, arg_2103) } } else {
//line :634:1
										r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :629:1
											r__4 = nil
										}
				}
			}






			var root_2112 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2112, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = cache__2; var arg_2116 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var arg_2117 any = k__3; var arg_2118 any = r__4; if linked_2113 == nil { ifn_2114.Invoke_O_O_O_O__O(arg_2115, arg_2116, arg_2117, arg_2118) } else { linked_2113.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2112, arg_2115, arg_2116, arg_2117, arg_2118) }
//line :627:1
			return r__4 } }










func A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A_New_O(p0 any) *A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A{}; t.Ctor_O(p0); return t }
//line :638:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :638:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A) Invoke_O_O__O(self, p1__1479000210_SHARP___1 any) any { var root_2104 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = t.F_n; var arg_2108 any = p1__1479000210_SHARP___1; var arg_2109 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_2105 == nil { return ifn_2106.Invoke_O_O_O__O(arg_2107, arg_2108, arg_2109) } else { return linked_2105.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_2104, arg_2107, arg_2108, arg_2109) } }



























func A_arbace_j2g_model_fn__1479000218_A_New() *A_arbace_j2g_model_fn__1479000218_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000218_A{}; t.Ctor(); return t }
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_A) Ctor() {}
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__2190 any = A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A_New(); var tmp1 *jrt.Class; var fncls__2189 *jrt.Class = A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A_fn_class; if fncls__2189 == nil { var fncls__2189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A_fn_class = fncls__2189d; tmp1 = fncls__2189d } else { tmp1 = fncls__2189 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2190, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_model_A_const_250.GetRawRoot__O()) }
//line :666:1
func A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A_New() *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A{}; t.Ctor(); return t }
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A) Ctor() {}
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A) Invoke_O_O__O(self, s__1479000215__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2188 any = A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A_New_O_O(self, s__1479000215__1); var tmp2 *jrt.Class; var fncls__2187 *jrt.Class = A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A_fn_class; if fncls__2187 == nil { var fncls__2187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__2188); A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A_fn_class = fncls__2187d; tmp2 = fncls__2187d } else { tmp2 = fncls__2187 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2188, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :666:1
func A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A{}; t.Ctor_O_O(p0, p1); return t }
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A) Ctor_O_O(c__iter__1479000214, c__s__1479000215 any) { t.F_iter__1479000214 = c__iter__1479000214; t.F_s__1479000215 = c__s__1479000215 }
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A) Invoke_O__O(self any) any { { var s__1479000215__1 any; var t_ any = t.F_s__1479000215; t.F_s__1479000215 = nil; s__1479000215__1 = t_; for { var temp__1927000414__auto____2 any; var root_2119 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2121 lang.IFn; if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any = s__1479000215__1; if linked_2120 == nil { temp__1927000414__auto____2 = ifn_2121.Invoke_O__O(arg_2122) } else { temp__1927000414__auto____2 = linked_2120.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2119, arg_2122) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000215__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2123 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2125 lang.IFn; if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = s__1479000215__3; if linked_2124 == nil { tmp1 = ifn_2125.Invoke_O__O(arg_2126) } else { tmp1 = linked_2124.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2123, arg_2126) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2127 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_2128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2127, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2129 lang.IFn; if linked_2128 == nil { ifn_2129 = lang.IFn_Cast(root_2127) } else { ifn_2129 = nil }; var arg_2130 any = s__1479000215__3; if linked_2128 == nil { c__1927001037__auto____4 = ifn_2129.Invoke_O__O(arg_2130) } else { c__1927001037__auto____4 = linked_2128.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2127, arg_2130) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000217__6 any; var root_2131 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_2132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2131, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2133 lang.IFn; if linked_2132 == nil { ifn_2133 = lang.IFn_Cast(root_2131) } else { ifn_2133 = nil }; var arg_2134 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2132 == nil { b__1479000217__6 = ifn_2133.Invoke_O__O(arg_2134) } else { b__1479000217__6 = linked_2132.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2131, arg_2134) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2146 any = A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A_New_O_I_O(b__1479000217__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2145 *jrt.Class = A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A_fn_class; if fncls__2145 == nil { var fncls__2145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2146); A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A_fn_class = fncls__2145d; tmp3 = fncls__2145d } else { tmp3 = fncls__2145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2146, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2147 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var root_2152 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = b__1479000217__6; if linked_2153 == nil { arg_2150 = ifn_2154.Invoke_O__O(arg_2155) } else { arg_2150 = linked_2153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2152, arg_2155) }; var arg_2151 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000214); var tmp5 any; var root_2156 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = s__1479000215__3; if linked_2157 == nil { tmp5 = ifn_2158.Invoke_O__O(arg_2159) } else { tmp5 = linked_2157.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2156, arg_2159) }; arg_2151 = tmp4.Invoke_O__O(tmp5); if linked_2148 == nil { return ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { return linked_2148.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) } } else { var root_2160 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any; var root_2165 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_2166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2165, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2167 lang.IFn; if linked_2166 == nil { ifn_2167 = lang.IFn_Cast(root_2165) } else { ifn_2167 = nil }; var arg_2168 any = b__1479000217__6; if linked_2166 == nil { arg_2163 = ifn_2167.Invoke_O__O(arg_2168) } else { arg_2163 = linked_2166.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2165, arg_2168) }; var arg_2164 any; if linked_2161 == nil { return ifn_2162.Invoke_O_O__O(arg_2163, arg_2164) } else { return linked_2161.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2160, arg_2163, arg_2164) } } } else { var d__4 any; var root_2169 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2171 lang.IFn; if linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any = s__1479000215__3; if linked_2170 == nil { d__4 = ifn_2171.Invoke_O__O(arg_2172) } else { d__4 = linked_2170.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2169, arg_2172) }; var root_2173 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any; var tmp6 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_23, Lit_24, d__4); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp8 any; var root_2178 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2180 lang.IFn
															if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = Lit_24; var arg_2182 any = d__4; if linked_2179 == nil { tmp8 = ifn_2180.Invoke_O_O__O(arg_2181, arg_2182) } else { tmp8 = linked_2179.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2178, arg_2181, arg_2182) }
//line :666:1
	arg_2176 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(), Lit_26)); var arg_2177 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1479000214); var tmp10 any; var root_2183 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = s__1479000215__3; if linked_2184 == nil { tmp10 = ifn_2185.Invoke_O__O(arg_2186) } else { tmp10 = linked_2184.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2183, arg_2186) }; arg_2177 = tmp9.Invoke_O__O(tmp10); if linked_2174 == nil { return ifn_2175.Invoke_O_O__O(arg_2176, arg_2177) } else { return linked_2174.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2173, arg_2176, arg_2177) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :666:1
func A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A) Ctor_O_I_O(c__b__1479000217 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000217 = c__b__1479000217; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :666:1
func (t *A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A) Invoke_O__O(self any) any { { var i__1479000216__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000216__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000216__1)); var root_2135 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any = t.F_b__1479000217; var arg_2139 any; var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_23, Lit_24, d__2); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp4 any; var root_2140 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2142 lang.IFn
																	if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = Lit_24; var arg_2144 any = d__2; if linked_2141 == nil { tmp4 = ifn_2142.Invoke_O_O__O(arg_2143, arg_2144) } else { tmp4 = linked_2141.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2140, arg_2143, arg_2144) }
//line :666:1
	arg_2139 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(), Lit_26)); if linked_2136 == nil { ifn_2137.Invoke_O_O__O(arg_2138, arg_2139) } else { linked_2136.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2135, arg_2138, arg_2139) }; i__1479000216__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000216__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_model_throwable_print_helper_A_New() *A_arbace_j2g_model_throwable_print_helper_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_throwable_print_helper_A{}; t.Ctor(); return t }
//line :669:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Ctor() {}
//line :669:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Invoke_O_O_O_O__O(self, owner__0, name__1, desc__2 any) any { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_model_A_const_251.GetRawRoot__O(), lang.Tuple_Create_O_O_O__IPersistentVector(owner__0, name__1, desc__2)); if




	jrt.J2g_Truth(temp__1927000414__auto____4) { var vec__1479000226__5 any = temp__1927000414__auto____4; var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000226__5, lang.RT_IntCast_J__I_NoInit(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000226__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____8 any; var root_2191 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2193 lang.IFn
		if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = owner__0; if linked_2192 == nil { and__1927000168__auto____8 = ifn_2193.Invoke_O__O(arg_2194) } else { and__1927000168__auto____8 = linked_2192.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2191, arg_2194) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_2195 any = A_arbace_j2g_model_A_const_252.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, A_arbace_j2g_model_translatable_QMARK__A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = c__7; if linked_2196 == nil { tmp1 = ifn_2197.Invoke_O__O(arg_2198) } else { tmp1 = linked_2196.(*A_arbace_j2g_model_translatable_QMARK__A).Invoke_O_O__O(root_2195, arg_2198) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return f__6 } else { return nil } } else {
//line :674:1
			return nil } }





























































type A_arbace_j2g_model_A struct{ jrt.Object }

var A_arbace_j2g_model_A_const_pool *jrt.RefArray

var A_arbace_j2g_model_A_const_0 *lang.Var

var A_arbace_j2g_model_A_const_1 any

var A_arbace_j2g_model_A_const_2 any

var A_arbace_j2g_model_A_const_3 any

var A_arbace_j2g_model_A_const_4 any

var A_arbace_j2g_model_A_const_5 any

var A_arbace_j2g_model_A_const_6 any

var A_arbace_j2g_model_A_const_7 any

var A_arbace_j2g_model_A_const_8 any

var A_arbace_j2g_model_A_const_9 *lang.Var

var A_arbace_j2g_model_A_const_10 any

var A_arbace_j2g_model_A_const_11 *lang.Var

var A_arbace_j2g_model_A_const_12 *lang.Var

var A_arbace_j2g_model_A_const_13 *lang.Var

var A_arbace_j2g_model_A_const_14 *lang.Var

var A_arbace_j2g_model_A_const_15 any

var A_arbace_j2g_model_A_const_16 *lang.Var

var A_arbace_j2g_model_A_const_17 *lang.Var

var A_arbace_j2g_model_A_const_18 *lang.Var

var A_arbace_j2g_model_A_const_19 *lang.Var

var A_arbace_j2g_model_A_const_20 *lang.Var

var A_arbace_j2g_model_A_const_21 *lang.Var

var A_arbace_j2g_model_A_const_22 *lang.Var

var A_arbace_j2g_model_A_const_23 *lang.Var

var A_arbace_j2g_model_A_const_24 any

var A_arbace_j2g_model_A_const_25 *lang.Var

var A_arbace_j2g_model_A_const_26 *lang.Var

var A_arbace_j2g_model_A_const_27 *lang.Var

var A_arbace_j2g_model_A_const_28 *lang.Var

var A_arbace_j2g_model_A_const_29 *lang.Var

var A_arbace_j2g_model_A_const_30 *lang.Var

var A_arbace_j2g_model_A_const_31 any

var A_arbace_j2g_model_A_const_32 *lang.Keyword

var A_arbace_j2g_model_A_const_33 *lang.Var

var A_arbace_j2g_model_A_const_34 *lang.Var

var A_arbace_j2g_model_A_const_35 *lang.Var

var A_arbace_j2g_model_A_const_36 *lang.Var

var A_arbace_j2g_model_A_const_37 *lang.Keyword

var A_arbace_j2g_model_A_const_38 *lang.Var

var A_arbace_j2g_model_A_const_39 *lang.Var

var A_arbace_j2g_model_A_const_40 *lang.Var

var A_arbace_j2g_model_A_const_41 *lang.Var

var A_arbace_j2g_model_A_const_42 *lang.Var

var A_arbace_j2g_model_A_const_43 *lang.Var

var A_arbace_j2g_model_A_const_44 *lang.Var

var A_arbace_j2g_model_A_const_45 *lang.Var

var A_arbace_j2g_model_A_const_46 *lang.Keyword

var A_arbace_j2g_model_A_const_47 any

var A_arbace_j2g_model_A_const_48 *lang.Var

var A_arbace_j2g_model_A_const_49 *lang.Keyword

var A_arbace_j2g_model_A_const_50 *lang.Var

var A_arbace_j2g_model_A_const_51 *lang.Var

var A_arbace_j2g_model_A_const_52 *lang.Var

var A_arbace_j2g_model_A_const_53 *lang.Keyword

var A_arbace_j2g_model_A_const_54 *lang.Var

var A_arbace_j2g_model_A_const_55 *lang.Var

var A_arbace_j2g_model_A_const_56 *lang.Var

var A_arbace_j2g_model_A_const_57 *lang.Var

var A_arbace_j2g_model_A_const_58 *lang.Var

var A_arbace_j2g_model_A_const_59 *lang.Var

var A_arbace_j2g_model_A_const_60 *lang.Keyword

var A_arbace_j2g_model_A_const_61 *lang.Var

var A_arbace_j2g_model_A_const_62 *lang.Var

var A_arbace_j2g_model_A_const_63 *lang.Var

var A_arbace_j2g_model_A_const_64 *lang.Var

var A_arbace_j2g_model_A_const_65 *lang.Var

var A_arbace_j2g_model_A_const_66 *lang.Var

var A_arbace_j2g_model_A_const_67 *lang.Var

var A_arbace_j2g_model_A_const_68 *lang.Var

var A_arbace_j2g_model_A_const_69 *lang.Keyword

var A_arbace_j2g_model_A_const_70 *lang.Var

var A_arbace_j2g_model_A_const_71 *lang.Keyword

var A_arbace_j2g_model_A_const_72 *lang.Var

var A_arbace_j2g_model_A_const_73 *lang.Var

var A_arbace_j2g_model_A_const_74 *lang.Var

var A_arbace_j2g_model_A_const_75 any

var A_arbace_j2g_model_A_const_76 any

var A_arbace_j2g_model_A_const_77 *lang.Keyword

var A_arbace_j2g_model_A_const_78 *lang.Var

var A_arbace_j2g_model_A_const_79 *lang.Var

var A_arbace_j2g_model_A_const_80 *lang.Keyword

var A_arbace_j2g_model_A_const_81 *lang.Var

var A_arbace_j2g_model_A_const_82 *lang.Var

var A_arbace_j2g_model_A_const_83 *lang.Var

var A_arbace_j2g_model_A_const_84 *lang.Var

var A_arbace_j2g_model_A_const_85 *lang.Var

var A_arbace_j2g_model_A_const_86 *lang.Var

var A_arbace_j2g_model_A_const_87 *lang.Var

var A_arbace_j2g_model_A_const_88 *lang.Var

var A_arbace_j2g_model_A_const_89 *lang.Var

var A_arbace_j2g_model_A_const_90 *lang.Keyword

var A_arbace_j2g_model_A_const_91 *lang.Keyword

var A_arbace_j2g_model_A_const_92 *lang.Var

var A_arbace_j2g_model_A_const_93 *lang.Var

var A_arbace_j2g_model_A_const_94 *lang.Var

var A_arbace_j2g_model_A_const_95 *lang.Var

var A_arbace_j2g_model_A_const_96 *lang.Var

var A_arbace_j2g_model_A_const_97 *lang.Var

var A_arbace_j2g_model_A_const_98 *lang.Var

var A_arbace_j2g_model_A_const_99 *lang.Var

var A_arbace_j2g_model_A_const_100 *lang.Var

var A_arbace_j2g_model_A_const_101 *lang.Var

var A_arbace_j2g_model_A_const_102 *lang.Keyword

var A_arbace_j2g_model_A_const_103 *lang.Var

var A_arbace_j2g_model_A_const_104 *lang.Var

var A_arbace_j2g_model_A_const_105 *lang.Var

var A_arbace_j2g_model_A_const_106 *lang.Var

var A_arbace_j2g_model_A_const_107 *lang.Keyword

var A_arbace_j2g_model_A_const_108 any

var A_arbace_j2g_model_A_const_109 *lang.Var

var A_arbace_j2g_model_A_const_110 any

var A_arbace_j2g_model_A_const_111 any

var A_arbace_j2g_model_A_const_112 *lang.Var

var A_arbace_j2g_model_A_const_113 *lang.Var

var A_arbace_j2g_model_A_const_114 *lang.Var

var A_arbace_j2g_model_A_const_115 *lang.Keyword

var A_arbace_j2g_model_A_const_116 any

var A_arbace_j2g_model_A_const_117 any

var A_arbace_j2g_model_A_const_118 any

var A_arbace_j2g_model_A_const_119 *lang.Var

var A_arbace_j2g_model_A_const_120 *lang.Var

var A_arbace_j2g_model_A_const_121 *lang.Var

var A_arbace_j2g_model_A_const_122 any

var A_arbace_j2g_model_A_const_123 any

var A_arbace_j2g_model_A_const_124 *lang.Keyword

var A_arbace_j2g_model_A_const_125 *lang.Keyword

var A_arbace_j2g_model_A_const_126 *lang.Var

var A_arbace_j2g_model_A_const_127 *lang.Var

var A_arbace_j2g_model_A_const_128 *lang.Var

var A_arbace_j2g_model_A_const_129 *lang.Var

var A_arbace_j2g_model_A_const_130 *lang.Var

var A_arbace_j2g_model_A_const_131 *lang.Var

var A_arbace_j2g_model_A_const_132 *lang.Var

var A_arbace_j2g_model_A_const_133 *lang.Var

var A_arbace_j2g_model_A_const_134 *lang.Var

var A_arbace_j2g_model_A_const_135 *lang.Var

var A_arbace_j2g_model_A_const_136 *lang.Var

var A_arbace_j2g_model_A_const_137 *lang.Keyword

var A_arbace_j2g_model_A_const_138 *lang.Var

var A_arbace_j2g_model_A_const_139 *lang.Var

var A_arbace_j2g_model_A_const_140 *lang.Var

var A_arbace_j2g_model_A_const_141 any

var A_arbace_j2g_model_A_const_142 *lang.Var

var A_arbace_j2g_model_A_const_143 *lang.Var

var A_arbace_j2g_model_A_const_144 *lang.Var

var A_arbace_j2g_model_A_const_145 *lang.Var

var A_arbace_j2g_model_A_const_146 *lang.Var

var A_arbace_j2g_model_A_const_147 *lang.Var

var A_arbace_j2g_model_A_const_148 *lang.Var

var A_arbace_j2g_model_A_const_149 *lang.Var

var A_arbace_j2g_model_A_const_150 *lang.Var

var A_arbace_j2g_model_A_const_151 *lang.Keyword

var A_arbace_j2g_model_A_const_152 *lang.Var

var A_arbace_j2g_model_A_const_153 *lang.Var

var A_arbace_j2g_model_A_const_154 *lang.Var

var A_arbace_j2g_model_A_const_155 *lang.Var

var A_arbace_j2g_model_A_const_156 *lang.Var

var A_arbace_j2g_model_A_const_157 *lang.Keyword

var A_arbace_j2g_model_A_const_158 *lang.Var

var A_arbace_j2g_model_A_const_159 *lang.Var

var A_arbace_j2g_model_A_const_160 *lang.Var

var A_arbace_j2g_model_A_const_161 *lang.Var

var A_arbace_j2g_model_A_const_162 any

var A_arbace_j2g_model_A_const_163 *lang.Var

var A_arbace_j2g_model_A_const_164 *lang.Var

var A_arbace_j2g_model_A_const_165 *lang.Var

var A_arbace_j2g_model_A_const_166 *lang.Var

var A_arbace_j2g_model_A_const_167 *lang.Var

var A_arbace_j2g_model_A_const_168 *lang.Var

var A_arbace_j2g_model_A_const_169 *lang.Var

var A_arbace_j2g_model_A_const_170 *lang.Keyword

var A_arbace_j2g_model_A_const_171 *lang.Keyword

var A_arbace_j2g_model_A_const_172 *lang.Keyword

var A_arbace_j2g_model_A_const_173 *lang.Keyword

var A_arbace_j2g_model_A_const_174 *lang.Keyword

var A_arbace_j2g_model_A_const_175 *lang.Keyword

var A_arbace_j2g_model_A_const_176 *lang.Var

var A_arbace_j2g_model_A_const_177 *lang.Keyword

var A_arbace_j2g_model_A_const_178 *lang.Var

var A_arbace_j2g_model_A_const_179 *lang.Keyword

var A_arbace_j2g_model_A_const_180 *lang.Keyword

var A_arbace_j2g_model_A_const_181 *lang.Var

var A_arbace_j2g_model_A_const_182 any

var A_arbace_j2g_model_A_const_183 any

var A_arbace_j2g_model_A_const_184 *lang.Var

var A_arbace_j2g_model_A_const_185 *lang.Var

var A_arbace_j2g_model_A_const_186 *lang.Keyword

var A_arbace_j2g_model_A_const_187 *lang.Keyword

var A_arbace_j2g_model_A_const_188 *lang.Keyword

var A_arbace_j2g_model_A_const_189 *lang.Keyword

var A_arbace_j2g_model_A_const_190 *lang.Keyword

var A_arbace_j2g_model_A_const_191 *lang.Keyword

var A_arbace_j2g_model_A_const_192 *lang.Var

var A_arbace_j2g_model_A_const_193 *lang.Var

var A_arbace_j2g_model_A_const_194 *lang.Var

var A_arbace_j2g_model_A_const_195 *lang.Var

var A_arbace_j2g_model_A_const_196 *lang.Var

var A_arbace_j2g_model_A_const_197 *lang.Var

var A_arbace_j2g_model_A_const_198 *lang.Var

var A_arbace_j2g_model_A_const_199 *lang.Var

var A_arbace_j2g_model_A_const_200 *lang.Keyword

var A_arbace_j2g_model_A_const_201 *lang.Var

var A_arbace_j2g_model_A_const_202 *lang.Keyword

var A_arbace_j2g_model_A_const_203 *lang.Keyword

var A_arbace_j2g_model_A_const_204 *lang.Keyword

var A_arbace_j2g_model_A_const_205 *lang.Var

var A_arbace_j2g_model_A_const_206 *lang.Keyword

var A_arbace_j2g_model_A_const_207 any

var A_arbace_j2g_model_A_const_208 *lang.Var

var A_arbace_j2g_model_A_const_209 *lang.Keyword

var A_arbace_j2g_model_A_const_210 *lang.Keyword

var A_arbace_j2g_model_A_const_211 *lang.Keyword

var A_arbace_j2g_model_A_const_212 *lang.Keyword

var A_arbace_j2g_model_A_const_213 *lang.Keyword

var A_arbace_j2g_model_A_const_214 *lang.Keyword

var A_arbace_j2g_model_A_const_215 *lang.Keyword

var A_arbace_j2g_model_A_const_216 *lang.Keyword

var A_arbace_j2g_model_A_const_217 *lang.Keyword

var A_arbace_j2g_model_A_const_218 *lang.Keyword

var A_arbace_j2g_model_A_const_219 *lang.Keyword

var A_arbace_j2g_model_A_const_220 *lang.Keyword

var A_arbace_j2g_model_A_const_221 *lang.Keyword

var A_arbace_j2g_model_A_const_222 *lang.Keyword

var A_arbace_j2g_model_A_const_223 *lang.Keyword

var A_arbace_j2g_model_A_const_224 *lang.Keyword

var A_arbace_j2g_model_A_const_225 *lang.Keyword

var A_arbace_j2g_model_A_const_226 *lang.Keyword

var A_arbace_j2g_model_A_const_227 *lang.Keyword

var A_arbace_j2g_model_A_const_228 *lang.Keyword

var A_arbace_j2g_model_A_const_229 *lang.Keyword

var A_arbace_j2g_model_A_const_230 *lang.Keyword

var A_arbace_j2g_model_A_const_231 *lang.Keyword

var A_arbace_j2g_model_A_const_232 *lang.Keyword

var A_arbace_j2g_model_A_const_233 *lang.Keyword

var A_arbace_j2g_model_A_const_234 *lang.Keyword

var A_arbace_j2g_model_A_const_235 *lang.Keyword

var A_arbace_j2g_model_A_const_236 *lang.Var

var A_arbace_j2g_model_A_const_237 *lang.Keyword

var A_arbace_j2g_model_A_const_238 *lang.Keyword

var A_arbace_j2g_model_A_const_239 *lang.Keyword

var A_arbace_j2g_model_A_const_240 *lang.Keyword

var A_arbace_j2g_model_A_const_241 any

var A_arbace_j2g_model_A_const_242 *lang.Keyword

var A_arbace_j2g_model_A_const_243 *lang.Keyword

var A_arbace_j2g_model_A_const_244 *lang.Keyword

var A_arbace_j2g_model_A_const_245 *lang.Keyword

var A_arbace_j2g_model_A_const_246 *lang.Keyword

var A_arbace_j2g_model_A_const_247 *lang.Keyword

var A_arbace_j2g_model_A_const_248 *lang.Var

var A_arbace_j2g_model_A_const_249 *lang.Keyword

var A_arbace_j2g_model_A_const_250 *lang.Var

var A_arbace_j2g_model_A_const_251 *lang.Var

var A_arbace_j2g_model_A_const_252 *lang.Var

var A_arbace_j2g_model_A_init jrt.ClassInit

func A_arbace_j2g_model_A_Init() { if !A_arbace_j2g_model_A_init.Done() { A_arbace_j2g_model_A_init.Run(A_arbace_j2g_model_A_clinit) } }

func A_arbace_j2g_model_A_clinit() { A_arbace_j2g_model_A_clinit_p0(); A_arbace_j2g_model_A_clinit_p1(); A_arbace_j2g_model_A_clinit_p2(); A_arbace_j2g_model_A_clinit_p3(); A_arbace_j2g_model_A_clinit_p4(); A_arbace_j2g_model_A_clinit_p5(); A_arbace_j2g_model_A_clinit_p6(); A_arbace_j2g_model_A_clinit_p7(); A_arbace_j2g_model_A_clinit_p8(); A_arbace_j2g_model_A_clinit_p9(); A_arbace_j2g_model_A_clinit_p10(); A_arbace_j2g_model_A_clinit_p11(); A_arbace_j2g_model_A_clinit_p12(); A_arbace_j2g_model_A_clinit_p13(); A_arbace_j2g_model_A_clinit_p14(); A_arbace_j2g_model_A_clinit_p15(); A_arbace_j2g_model_A_clinit_p16(); A_arbace_j2g_model_A_clinit_p17(); A_arbace_j2g_model_A_clinit_p18(); A_arbace_j2g_model_A_clinit_p19(); A_arbace_j2g_model_A_clinit_p20() }

func A_arbace_j2g_model_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 354); A_arbace_j2g_model_A_const_0 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[101]); A_arbace_j2g_model_A_const_1 = A_arbace_j2g_model_A_const_pool.A[102]; A_arbace_j2g_model_A_const_2 = A_arbace_j2g_model_A_const_pool.A[103]; A_arbace_j2g_model_A_const_3 = A_arbace_j2g_model_A_const_pool.A[104]; A_arbace_j2g_model_A_const_4 = A_arbace_j2g_model_A_const_pool.A[105]; A_arbace_j2g_model_A_const_5 = A_arbace_j2g_model_A_const_pool.A[106]; A_arbace_j2g_model_A_const_6 = A_arbace_j2g_model_A_const_pool.A[107]; A_arbace_j2g_model_A_const_7 = A_arbace_j2g_model_A_const_pool.A[108]; A_arbace_j2g_model_A_const_8 = A_arbace_j2g_model_A_const_pool.A[109]; A_arbace_j2g_model_A_const_9 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[110]); A_arbace_j2g_model_A_const_10 = A_arbace_j2g_model_A_const_pool.A[111]; A_arbace_j2g_model_A_const_11 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[112]); A_arbace_j2g_model_A_const_12 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[113]) }

func A_arbace_j2g_model_A_clinit_p1() { A_arbace_j2g_model_A_const_13 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[114]); A_arbace_j2g_model_A_const_14 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[115]); A_arbace_j2g_model_A_const_15 = A_arbace_j2g_model_A_const_pool.A[116]; A_arbace_j2g_model_A_const_16 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[117]); A_arbace_j2g_model_A_const_17 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[118]); A_arbace_j2g_model_A_const_18 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[119]); A_arbace_j2g_model_A_const_19 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[120]); A_arbace_j2g_model_A_const_20 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[121]); A_arbace_j2g_model_A_const_21 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[122]); A_arbace_j2g_model_A_const_22 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[123]); A_arbace_j2g_model_A_const_23 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[124]); A_arbace_j2g_model_A_const_24 = A_arbace_j2g_model_A_const_pool.A[125] }

func A_arbace_j2g_model_A_clinit_p2() { A_arbace_j2g_model_A_const_25 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[126]); A_arbace_j2g_model_A_const_26 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[127]); A_arbace_j2g_model_A_const_27 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[128]); A_arbace_j2g_model_A_const_28 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[129]); A_arbace_j2g_model_A_const_29 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[130]); A_arbace_j2g_model_A_const_30 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[131]); A_arbace_j2g_model_A_const_31 = A_arbace_j2g_model_A_const_pool.A[132]; A_arbace_j2g_model_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[133]); A_arbace_j2g_model_A_const_33 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[134]); A_arbace_j2g_model_A_const_34 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[135]); A_arbace_j2g_model_A_const_35 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[136]); A_arbace_j2g_model_A_const_36 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[137]) }

func A_arbace_j2g_model_A_clinit_p3() { A_arbace_j2g_model_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[138]); A_arbace_j2g_model_A_const_38 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[139]); A_arbace_j2g_model_A_const_39 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[140]); A_arbace_j2g_model_A_const_40 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[141]); A_arbace_j2g_model_A_const_41 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[142]); A_arbace_j2g_model_A_const_42 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[143]); A_arbace_j2g_model_A_const_43 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[144]); A_arbace_j2g_model_A_const_44 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[145]); A_arbace_j2g_model_A_const_45 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[146]); A_arbace_j2g_model_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[147]); A_arbace_j2g_model_A_const_47 = A_arbace_j2g_model_A_const_pool.A[148]; A_arbace_j2g_model_A_const_48 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[149]) }

func A_arbace_j2g_model_A_clinit_p4() { A_arbace_j2g_model_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[150]); A_arbace_j2g_model_A_const_50 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[151]); A_arbace_j2g_model_A_const_51 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[152]); A_arbace_j2g_model_A_const_52 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[153]); A_arbace_j2g_model_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[154]); A_arbace_j2g_model_A_const_54 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[155]); A_arbace_j2g_model_A_const_55 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[156]); A_arbace_j2g_model_A_const_56 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[157]); A_arbace_j2g_model_A_const_57 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[158]); A_arbace_j2g_model_A_const_58 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[159]); A_arbace_j2g_model_A_const_59 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[160]); A_arbace_j2g_model_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[161]) }

func A_arbace_j2g_model_A_clinit_p5() { A_arbace_j2g_model_A_const_61 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[162]); A_arbace_j2g_model_A_const_62 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[163]); A_arbace_j2g_model_A_const_63 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[164]); A_arbace_j2g_model_A_const_64 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[165]); A_arbace_j2g_model_A_const_65 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[166]); A_arbace_j2g_model_A_const_66 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[167]); A_arbace_j2g_model_A_const_67 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[168]); A_arbace_j2g_model_A_const_68 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[169]); A_arbace_j2g_model_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[170]); A_arbace_j2g_model_A_const_70 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[171]); A_arbace_j2g_model_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[172]); A_arbace_j2g_model_A_const_72 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[173]) }

func A_arbace_j2g_model_A_clinit_p6() { A_arbace_j2g_model_A_const_73 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[174]); A_arbace_j2g_model_A_const_74 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[175]); A_arbace_j2g_model_A_const_75 = A_arbace_j2g_model_A_const_pool.A[176]; A_arbace_j2g_model_A_const_76 = A_arbace_j2g_model_A_const_pool.A[177]; A_arbace_j2g_model_A_const_77 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[178]); A_arbace_j2g_model_A_const_78 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[179]); A_arbace_j2g_model_A_const_79 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[180]); A_arbace_j2g_model_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[181]); A_arbace_j2g_model_A_const_81 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[182]); A_arbace_j2g_model_A_const_82 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[183]); A_arbace_j2g_model_A_const_83 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[184]); A_arbace_j2g_model_A_const_84 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[185]) }

func A_arbace_j2g_model_A_clinit_p7() { A_arbace_j2g_model_A_const_85 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[186]); A_arbace_j2g_model_A_const_86 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[187]); A_arbace_j2g_model_A_const_87 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[188]); A_arbace_j2g_model_A_const_88 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[189]); A_arbace_j2g_model_A_const_89 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[190]); A_arbace_j2g_model_A_const_90 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[191]); A_arbace_j2g_model_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[192]); A_arbace_j2g_model_A_const_92 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[193]); A_arbace_j2g_model_A_const_93 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[194]); A_arbace_j2g_model_A_const_94 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[195]); A_arbace_j2g_model_A_const_95 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[196]); A_arbace_j2g_model_A_const_96 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[197]) }

func A_arbace_j2g_model_A_clinit_p8() { A_arbace_j2g_model_A_const_97 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[198]); A_arbace_j2g_model_A_const_98 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[199]); A_arbace_j2g_model_A_const_99 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[200]); A_arbace_j2g_model_A_const_100 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[201]); A_arbace_j2g_model_A_const_101 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[202]); A_arbace_j2g_model_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[203]); A_arbace_j2g_model_A_const_103 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[204]); A_arbace_j2g_model_A_const_104 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[205]); A_arbace_j2g_model_A_const_105 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[206]); A_arbace_j2g_model_A_const_106 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[207]); A_arbace_j2g_model_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[208]); A_arbace_j2g_model_A_const_108 = A_arbace_j2g_model_A_const_pool.A[209] }

func A_arbace_j2g_model_A_clinit_p9() { A_arbace_j2g_model_A_const_109 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[210]); A_arbace_j2g_model_A_const_110 = A_arbace_j2g_model_A_const_pool.A[211]; A_arbace_j2g_model_A_const_111 = A_arbace_j2g_model_A_const_pool.A[212]; A_arbace_j2g_model_A_const_112 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[213]); A_arbace_j2g_model_A_const_113 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[214]); A_arbace_j2g_model_A_const_114 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[215]); A_arbace_j2g_model_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[216]); A_arbace_j2g_model_A_const_116 = A_arbace_j2g_model_A_const_pool.A[217]; A_arbace_j2g_model_A_const_117 = A_arbace_j2g_model_A_const_pool.A[218]; A_arbace_j2g_model_A_const_118 = A_arbace_j2g_model_A_const_pool.A[219]; A_arbace_j2g_model_A_const_119 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[220]); A_arbace_j2g_model_A_const_120 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[221]); A_arbace_j2g_model_A_const_121 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[222]) }

func A_arbace_j2g_model_A_clinit_p10() { A_arbace_j2g_model_A_const_122 = A_arbace_j2g_model_A_const_pool.A[223]; A_arbace_j2g_model_A_const_123 = A_arbace_j2g_model_A_const_pool.A[224]; A_arbace_j2g_model_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[225]); A_arbace_j2g_model_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[226]); A_arbace_j2g_model_A_const_126 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[227]); A_arbace_j2g_model_A_const_127 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[228]); A_arbace_j2g_model_A_const_128 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[229]); A_arbace_j2g_model_A_const_129 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[230]); A_arbace_j2g_model_A_const_130 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[231]); A_arbace_j2g_model_A_const_131 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[232]); A_arbace_j2g_model_A_const_132 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[233]); A_arbace_j2g_model_A_const_133 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[234]) }

func A_arbace_j2g_model_A_clinit_p11() { A_arbace_j2g_model_A_const_134 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[235]); A_arbace_j2g_model_A_const_135 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[236]); A_arbace_j2g_model_A_const_136 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[237]); A_arbace_j2g_model_A_const_137 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[238]); A_arbace_j2g_model_A_const_138 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[239]); A_arbace_j2g_model_A_const_139 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[240]); A_arbace_j2g_model_A_const_140 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[241]); A_arbace_j2g_model_A_const_141 = A_arbace_j2g_model_A_const_pool.A[242]; A_arbace_j2g_model_A_const_142 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[243]); A_arbace_j2g_model_A_const_143 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[244]); A_arbace_j2g_model_A_const_144 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[245]); A_arbace_j2g_model_A_const_145 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[246]) }

func A_arbace_j2g_model_A_clinit_p12() { A_arbace_j2g_model_A_const_146 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[247]); A_arbace_j2g_model_A_const_147 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[248]); A_arbace_j2g_model_A_const_148 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[249]); A_arbace_j2g_model_A_const_149 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[250]); A_arbace_j2g_model_A_const_150 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[251]); A_arbace_j2g_model_A_const_151 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[252]); A_arbace_j2g_model_A_const_152 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[253]); A_arbace_j2g_model_A_const_153 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[254]); A_arbace_j2g_model_A_const_154 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[255]); A_arbace_j2g_model_A_const_155 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[256]); A_arbace_j2g_model_A_const_156 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[257]); A_arbace_j2g_model_A_const_157 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[258]) }

func A_arbace_j2g_model_A_clinit_p13() { A_arbace_j2g_model_A_const_158 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[259]); A_arbace_j2g_model_A_const_159 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[260]); A_arbace_j2g_model_A_const_160 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[261]); A_arbace_j2g_model_A_const_161 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[262]); A_arbace_j2g_model_A_const_162 = A_arbace_j2g_model_A_const_pool.A[263]; A_arbace_j2g_model_A_const_163 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[264]); A_arbace_j2g_model_A_const_164 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[265]); A_arbace_j2g_model_A_const_165 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[266]); A_arbace_j2g_model_A_const_166 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[267]); A_arbace_j2g_model_A_const_167 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[268]); A_arbace_j2g_model_A_const_168 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[269]); A_arbace_j2g_model_A_const_169 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[270]) }

func A_arbace_j2g_model_A_clinit_p14() { A_arbace_j2g_model_A_const_170 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[271]); A_arbace_j2g_model_A_const_171 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[272]); A_arbace_j2g_model_A_const_172 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[273]); A_arbace_j2g_model_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[274]); A_arbace_j2g_model_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[275]); A_arbace_j2g_model_A_const_175 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[276]); A_arbace_j2g_model_A_const_176 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[277]); A_arbace_j2g_model_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[278]); A_arbace_j2g_model_A_const_178 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[279]); A_arbace_j2g_model_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[280]); A_arbace_j2g_model_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[281]); A_arbace_j2g_model_A_const_181 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[282]) }

func A_arbace_j2g_model_A_clinit_p15() { A_arbace_j2g_model_A_const_182 = A_arbace_j2g_model_A_const_pool.A[283]; A_arbace_j2g_model_A_const_183 = A_arbace_j2g_model_A_const_pool.A[284]; A_arbace_j2g_model_A_const_184 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[285]); A_arbace_j2g_model_A_const_185 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[286]); A_arbace_j2g_model_A_const_186 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[287]); A_arbace_j2g_model_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[288]); A_arbace_j2g_model_A_const_188 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[289]); A_arbace_j2g_model_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[290]); A_arbace_j2g_model_A_const_190 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[291]); A_arbace_j2g_model_A_const_191 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[292]); A_arbace_j2g_model_A_const_192 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[293]); A_arbace_j2g_model_A_const_193 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[294]) }

func A_arbace_j2g_model_A_clinit_p16() { A_arbace_j2g_model_A_const_194 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[295]); A_arbace_j2g_model_A_const_195 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[296]); A_arbace_j2g_model_A_const_196 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[297]); A_arbace_j2g_model_A_const_197 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[298]); A_arbace_j2g_model_A_const_198 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[299]); A_arbace_j2g_model_A_const_199 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[300]); A_arbace_j2g_model_A_const_200 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[301]); A_arbace_j2g_model_A_const_201 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[302]); A_arbace_j2g_model_A_const_202 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[303]); A_arbace_j2g_model_A_const_203 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[304]); A_arbace_j2g_model_A_const_204 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[305]); A_arbace_j2g_model_A_const_205 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[306]) }

func A_arbace_j2g_model_A_clinit_p17() { A_arbace_j2g_model_A_const_206 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[307]); A_arbace_j2g_model_A_const_207 = A_arbace_j2g_model_A_const_pool.A[308]; A_arbace_j2g_model_A_const_208 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[309]); A_arbace_j2g_model_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[310]); A_arbace_j2g_model_A_const_210 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[311]); A_arbace_j2g_model_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[312]); A_arbace_j2g_model_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[313]); A_arbace_j2g_model_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[314]); A_arbace_j2g_model_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[315]); A_arbace_j2g_model_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[316]); A_arbace_j2g_model_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[317]); A_arbace_j2g_model_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[318]) }

func A_arbace_j2g_model_A_clinit_p18() { A_arbace_j2g_model_A_const_218 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[319]); A_arbace_j2g_model_A_const_219 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[320]); A_arbace_j2g_model_A_const_220 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[321]); A_arbace_j2g_model_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[322]); A_arbace_j2g_model_A_const_222 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[323]); A_arbace_j2g_model_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[324]); A_arbace_j2g_model_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[325]); A_arbace_j2g_model_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[326]); A_arbace_j2g_model_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[327]); A_arbace_j2g_model_A_const_227 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[328]); A_arbace_j2g_model_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[329]); A_arbace_j2g_model_A_const_229 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[330]) }

func A_arbace_j2g_model_A_clinit_p19() { A_arbace_j2g_model_A_const_230 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[331]); A_arbace_j2g_model_A_const_231 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[332]); A_arbace_j2g_model_A_const_232 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[333]); A_arbace_j2g_model_A_const_233 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[334]); A_arbace_j2g_model_A_const_234 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[335]); A_arbace_j2g_model_A_const_235 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[336]); A_arbace_j2g_model_A_const_236 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[337]); A_arbace_j2g_model_A_const_237 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[338]); A_arbace_j2g_model_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[339]); A_arbace_j2g_model_A_const_239 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[340]); A_arbace_j2g_model_A_const_240 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[341]); A_arbace_j2g_model_A_const_241 = A_arbace_j2g_model_A_const_pool.A[342] }

func A_arbace_j2g_model_A_clinit_p20() { A_arbace_j2g_model_A_const_242 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[343]); A_arbace_j2g_model_A_const_243 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[344]); A_arbace_j2g_model_A_const_244 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[345]); A_arbace_j2g_model_A_const_245 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[346]); A_arbace_j2g_model_A_const_246 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[347]); A_arbace_j2g_model_A_const_247 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[348]); A_arbace_j2g_model_A_const_248 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[349]); A_arbace_j2g_model_A_const_249 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[350]); A_arbace_j2g_model_A_const_250 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[351]); A_arbace_j2g_model_A_const_251 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[352]); A_arbace_j2g_model_A_const_252 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[353]) }

func A_arbace_j2g_model_A_New() *A_arbace_j2g_model_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_A) Ctor() {}

func (t *A_arbace_j2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_A_class }

func (t *A_arbace_j2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_A); return ok }

func A_arbace_j2g_model_A_Cast(x any) *A_arbace_j2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_A_class)) }; return v }



type A_arbace_j2g_model_T_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_T_A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_m_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_m_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_method_error_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_method_error_text_A_fn_class *jrt.Class



type A_arbace_j2g_model_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_all_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_array_test_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_array_test_A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_benign_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000211_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_code_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_code_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_declared_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A struct{ j2g_header uint64; F_n, F_s__1479000091, F_iter__1479000090 any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A struct{ j2g_header uint64; F_n, F_b__1479000093 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_erased_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000004_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000004_A_New() *A_arbace_j2g_model_eval1479000004_A { t := &A_arbace_j2g_model_eval1479000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000004_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000004_A_class }

func (t *A_arbace_j2g_model_eval1479000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000004_A); return ok }

func A_arbace_j2g_model_eval1479000004_A_Cast(x any) *A_arbace_j2g_model_eval1479000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000004_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000008_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000008_A_New() *A_arbace_j2g_model_eval1479000008_A { t := &A_arbace_j2g_model_eval1479000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000008_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000008_A_class }

func (t *A_arbace_j2g_model_eval1479000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000008_A); return ok }

func A_arbace_j2g_model_eval1479000008_A_Cast(x any) *A_arbace_j2g_model_eval1479000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000008_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000008_fn__1479000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class *jrt.Class



type A_arbace_j2g_model_fields_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fields_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_final_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_final_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_find_method_A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_fn__1479000080_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_find_method_fn__1479000080_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000218_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000218_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A struct{ j2g_header uint64; F_iter__1479000214, F_s__1479000215 any }

var A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A struct{ j2g_header uint64; F_b__1479000217 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_fn__1479000218_iter__1479000214__1479000219_fn__1479000220_fn__1479000221_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_qualified_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_qualified_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_model_hand_written_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hand_written_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_hw_method_exists_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_iface_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_iface_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_impl_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000124_A struct{ j2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000136_A struct{ j2g_header uint64; F_cands any }

var A_arbace_j2g_model_impl_of_fn__1479000136_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A struct{ j2g_header uint64; F_iter__1479000126, F_name, F_desc, F_s__1479000127 any }

var A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A struct{ j2g_header uint64; F_name, F_b__1479000129, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_fn_class *jrt.Class



type A_arbace_j2g_model_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_info_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_info_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_declares_default_QMARK___1479000145_fn__1479000146_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A struct{ j2g_header uint64; F_s__1479000152, F_iter__1479000151 any }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A struct{ j2g_header uint64; F_b__1479000154 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_init_superinterfaces_iter__1479000151__1479000155_fn__1479000156_fn__1479000157_A_fn_class *jrt.Class



type A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A struct{ j2g_header uint64; F_declares_default_QMARK_ any }

var A_arbace_j2g_model_init_superinterfaces_walk__1479000149_A_fn_class *jrt.Class



type A_arbace_j2g_model_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_method_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_java_type_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_java_type_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_jobs_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jobs_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_leaf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_leaf_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_A struct{ j2g_header uint64; F_cache, F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A struct{ j2g_header uint64; F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class *jrt.Class



type A_arbace_j2g_model_mdesc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_member_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_member_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_method_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_method_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_methods_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_methods_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_nest_top_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_nest_top_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_par_mapv_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000017_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_work__1479000019_A struct{ j2g_header uint64; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

var A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class *jrt.Class



type A_arbace_j2g_model_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_pointer_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_private_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000179_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000181_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000191_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000194_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000199_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000201_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000203_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000205_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000207_A_fn_class *jrt.Class



type A_arbace_j2g_model_qualify_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_qualify_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflected_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflected_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A struct{ j2g_header uint64; F_s__1479000166, F_iter__1479000165 any }

var A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A struct{ j2g_header uint64; F_b__1479000168 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_start_classes_iter__1479000165__1479000169_fn__1479000170_fn__1479000171_A_fn_class *jrt.Class



type A_arbace_j2g_model_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_subclasses_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_subclasses_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_fn__1479000116_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_fn__1479000116_A_fn_class *jrt.Class



type A_arbace_j2g_model_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_throwable_print_helper_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_throwable_print_helper_A_fn_class *jrt.Class



type A_arbace_j2g_model_top_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_top_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_translatable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translatable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_translated_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translated_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_trivial_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_trivial_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_virtual_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_virtual_member_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000101_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000101_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_fn_class *jrt.Class



type A_arbace_j2g_model_world_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_world_supertypes_A_fn_class *jrt.Class
