//line aot_arbace_j2g_model.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New() *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_model_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_model_A_const_1, A_arbace_j2g_model_A_const_2, A_arbace_j2g_model_A_const_3, A_arbace_j2g_model_A_const_4, A_arbace_j2g_model_A_const_5, A_arbace_j2g_model_A_const_6, A_arbace_j2g_model_A_const_7, A_arbace_j2g_model_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New() *A_arbace_j2g_model_eval1479000008_fn__1479000009_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000008_fn__1479000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_model_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_model_A_const_14.GetRawRoot__O(), A_arbace_j2g_model_A_const_15) }
























func A_arbace_j2g_model_jobs_A_New() *A_arbace_j2g_model_jobs_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jobs_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_45).Ref(); var tmp1 any; var tmp2 any; var root_26 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_28 lang.IFn; if




	linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = e__1; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_26, arg_29) }; if jrt.J2g_Truth(tmp2) {
		tmp1 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(e__1))).Ref() } else {
			tmp1 = lang.Numbers_Min_O_J__O_NoInit(A_arbace_j2g_model_A_const_17.GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :31:1*/ lang.Numbers_Max_J_O__O_NoInit(1, tmp1) }



func A_arbace_j2g_model_par_mapv_A_New() *A_arbace_j2g_model_par_mapv_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) Ctor() {}
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1479000013__3 any) any { var vec__1479000014__5 any = p__1479000013__3; var order__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000014__5, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__7 any; var root_30 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_32 lang.IFn; if









	linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = xs__2; if linked_31 == nil { xs__7 = ifn_32.Invoke_O__O(arg_33) } else { xs__7 = linked_31.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_30, arg_33) }; var cnt__8 int32 = /*line :35:1*/lang.RT_Count_O__I_NoInit(xs__7); var n__9 any = lang.Numbers_Min_O_J__O_NoInit(n__0, int64(cnt__8)); var order__10 any; if












	jrt.J2g_Truth(order__6) { var root_34 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = order__6; if linked_35 == nil { order__10 = ifn_36.Invoke_O__O(arg_37) } else { order__10 = linked_35.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_34, arg_37) } } else { var root_38 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var root_42 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref(); if linked_43 == nil { arg_41 = ifn_44.Invoke_O__O(arg_45) } else { arg_41 = linked_43.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_42, arg_45) }; if linked_39 == nil { order__10 = ifn_40.Invoke_O__O(arg_41) } else { order__10 = linked_39.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_38, arg_41) } }; var tmp1 bool; var na_46 any = n__9; var na_47 int64 = 1; if
	jrt.Long_InstanceOf(na_46) { var n0_48 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_49 int64 = na_47; tmp1 = n0_48 <= n1_49 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_46, na_47) }; if tmp1 {
		var root_51 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = f__1; var arg_55 any = xs__7; if linked_52 == nil { return ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { return linked_52.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) } } else {
//line :49:1
			var res__11 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref()).Ref(); var last_i__12 any; var root_56 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_58 lang.IFn


			if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = order__10; if linked_57 == nil { last_i__12 = ifn_58.Invoke_O__O(arg_59) } else { last_i__12 = linked_57.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_56, arg_59) }
//line :49:1
			var ___13 any; var tmp2 *jrt.RefArray = jrt.ObjectArray_Cast(res__11); var tmp3 int32 = lang.RT_IntCast_O__I_NoInit(last_i__12); var tmp4 any; var root_60 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_62 lang.IFn; _ = ___13



			if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_64 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp5 any = A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(f__1, last_i__12, xs__7); var tmp6 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class = fncls__68d; tmp6 = fncls__68d } else { tmp6 = fncls__68 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_65 == nil { arg_63 = ifn_66.Invoke_O__O(arg_67) } else { arg_63 = linked_65.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_64, arg_67) }; if linked_61 == nil { tmp4 = ifn_62.Invoke_O__O(arg_63) } else { tmp4 = linked_61.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_60, arg_63) }; ___13 = lang.RT_Aset_O1_I_O__O_NoInit(tmp2, tmp3, tmp4)
//line :49:1
			var next_i__14 any; var root_69 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_71 lang.IFn




			if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = A_arbace_j2g_model_A_const_24; if linked_70 == nil { next_i__14 = ifn_71.Invoke_O__O(arg_72) } else { next_i__14 = linked_70.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_69, arg_72) }
//line :49:1
			var work__15 any; var tmp7 any = A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__14, xs__7, res__11); var tmp8 *jrt.Class
			var fncls__83 /*line :49:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class





			if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class = fncls__83d; tmp8 = fncls__83d } else { tmp8 = fncls__83 }; work__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :49:1
			var ws__16 any; var root_84 any = A_arbace_j2g_model_A_const_27.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_86 lang.IFn











			if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any; var root_88 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = n__9; var arg_92 any; var tmp9 any = A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(work__15); var tmp10 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class = fncls__98d; tmp10 = fncls__98d } else { tmp10 = fncls__98 }; arg_92 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_89 == nil { arg_87 = ifn_90.Invoke_O_O__O(arg_91, arg_92) } else { arg_87 = linked_89.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_88, arg_91, arg_92) }; if linked_85 == nil { ws__16 = ifn_86.Invoke_O__O(arg_87) } else { ws__16 = linked_85.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_84, arg_87) }
			var root_103 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var arg_107 any = ws__16; if linked_104 == nil { ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { linked_104.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_103, arg_106, arg_107) }
			var root_99 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = res__11; if linked_100 == nil { return ifn_101.Invoke_O__O(arg_102) } else { return linked_100.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_99, arg_102) } } }
//line :53:1
func A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000017_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000017_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_f; t.F_f = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var t__2 any = t.F_xs; t.F_xs = nil; tmp3 = t__2; var tmp4 any = tmp3; var tmp5 any; var t__3 any = t.F_last_i; t.F_last_i = nil; tmp5 = t__3; return tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_O__I_NoInit(tmp5))) }

func A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_j2g_model_par_mapv_work__1479000019_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_work__1479000019_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Invoke_O__O(self any) any { for { L2: for { var k__1 any; var root_73 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_75 lang.IFn
											if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = t.F_next_i; var arg_77 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); if linked_74 == nil { k__1 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { k__1 = linked_74.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }
											var tmp1 bool; var na_78 any = k__1; var na_79 int64 = lang.Numbers_Dec_J__J_NoInit(int64(t.F_cnt)); if jrt.Long_InstanceOf(na_78) { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = na_79; tmp1 = n0_80 < n1_81 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_78, na_79) }; if tmp1 { var tmp2 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(k__1)); var tmp3 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_res); var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any = t.F_xs

		lang.RT_Aset_O1_I_O__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(i__2), tmp4.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(i__2))))
		continue L2 } else {
//line :57:1
			return nil } } }; /*line :55:1*/panic("j2g: unreachable") }





func A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Invoke_O__O(self any) any { var root_93 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any; var tmp1 any = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(t.F_work); var tmp2 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class = fncls__97d; tmp2 = fncls__97d } else { tmp2 = fncls__97 }; arg_96 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_94 == nil { return ifn_95.Invoke_O__O(arg_96) } else { return linked_94.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_93, arg_96) } }
//line :61:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_work; t.F_work = nil; tmp1 = t_; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_j2g_model_has_QMARK__A_New() *A_arbace_j2g_model_has_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Ctor() {}
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_108 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var tmp1 int64; var na_112 any; var or__1927000174__auto____3 any = flags__0; if jrt.J2g_Truth(or__1927000174__auto____3) { na_112 = or__1927000174__auto____3 } else { na_112 = A_arbace_j2g_model_A_const_31 }; var na_113 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_112); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_113) }; tmp2 = tmp3; if tmp2 { var n0_114 int64 = jrt.NN(jrt.Long_Cast(na_112)).LongValue__J(); var n1_115 int64 = jrt.NN(jrt.Long_Cast(na_113)).LongValue__J(); tmp1 = n0_114 & n1_115 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_112, na_113) }; arg_111 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_109 == nil { return ifn_110.Invoke_O__O(arg_111) } else { return linked_109.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_108, arg_111) } }

func A_arbace_j2g_model_T_A_New() *A_arbace_j2g_model_T_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_T_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_j2g_model_T_A) Ctor() {}
//line :69:1
func (t *A_arbace_j2g_model_T_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_32; var x__1 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if lang.IDeref_InstanceOf(x__1) { var root_117 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = x__1; if linked_118 == nil { return ifn_119.Invoke_O__O(arg_120) } else { return linked_118.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_117, arg_120) } } else { return x__1 } }

func A_arbace_j2g_model_translated_QMARK__A_New() *A_arbace_j2g_model_translated_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_121 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var root_126 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, A_arbace_j2g_model_T_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; if linked_127 == nil { arg_124 = ifn_128.Invoke__O() } else { arg_124 = linked_127.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_126) }; var arg_125 any = n__0; if linked_122 == nil { return ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { return linked_122.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } }

func A_arbace_j2g_model_j2g_static_QMARK__A_New() *A_arbace_j2g_model_j2g_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_41); if and__1927000168__auto____3 {





	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(base__1, Lit_42); if and__1927000168__auto____4 {
		var root_129 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = Lit_43; if linked_130 == nil { return ifn_131.Invoke_O__O(arg_132) } else { return linked_130.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_129, arg_132) } } else {
//line :79:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_jrt_class_A_New() *A_arbace_j2g_model_jrt_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Ctor() {}
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
}
func A_arbace_j2g_model_hand_written_QMARK__A_New() *A_arbace_j2g_model_hand_written_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_133 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_135 lang.IFn; if


	linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = n__0; if linked_134 == nil { and__1927000168__auto____2 = ifn_135.Invoke_O__O(arg_136) } else { and__1927000168__auto____2 = linked_134.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_137 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_141 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = n__0; if linked_142 == nil { arg_140 = ifn_143.Invoke_O__O(arg_144) } else { arg_140 = linked_142.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_141, arg_144) }; if linked_138 == nil { return ifn_139.Invoke_O__O(arg_140) } else { return linked_138.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_137, arg_140) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_in_world_QMARK__A_New() *A_arbace_j2g_model_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var root_145 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = n__0; if linked_146 == nil { or__1927000174__auto____3 = ifn_147.Invoke_O__O(arg_148) } else { or__1927000174__auto____3 = linked_146.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_145, arg_148) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_149 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = n__0; if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_149, arg_152) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }

func A_arbace_j2g_model_translatable_QMARK__A_New() *A_arbace_j2g_model_translatable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var root_153 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = n__0; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_153, arg_156) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_reflectable_interface_QMARK__A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_157 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_159 lang.IFn; if




	linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_161 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = n__0; if linked_162 == nil { arg_160 = ifn_163.Invoke_O__O(arg_164) } else { arg_160 = linked_162.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_161, arg_164) }; if linked_158 == nil { and__1927000168__auto____2 = ifn_159.Invoke_O__O(arg_160) } else { and__1927000168__auto____2 = linked_158.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_157, arg_160) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_165 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_167 lang.IFn
		if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = n__0; var arg_169 any = Lit_67; if linked_166 == nil { or__1927000174__auto____3 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { or__1927000174__auto____3 = linked_166.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_170 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = n__0; var arg_174 any = Lit_68; if linked_171 == nil { or__1927000174__auto____4 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { or__1927000174__auto____4 = linked_171.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; if jrt.J2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_175 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = n__0; var arg_179 any = Lit_69; if linked_176 == nil { or__1927000174__auto____5 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { or__1927000174__auto____5 = linked_176.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_180 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = n__0; var arg_184 any = Lit_70; if linked_181 == nil { or__1927000174__auto____6 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { or__1927000174__auto____6 = linked_181.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; if jrt.J2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			var root_185 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = n__0; var arg_189 any = Lit_71; if linked_186 == nil { and__1927000168__auto____3 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { and__1927000168__auto____3 = linked_186.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_185, arg_188, arg_189) } } } } }
//line :105:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_190 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_192 lang.IFn


			if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_194 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = n__0; var arg_198 any = Lit_72; if linked_195 == nil { arg_193 = ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { arg_193 = linked_195.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_194, arg_197, arg_198) }; if linked_191 == nil { and__1927000168__auto____4 = ifn_192.Invoke_O__O(arg_193) } else { and__1927000168__auto____4 = linked_191.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_190, arg_193) }
//line :105:1
			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_199 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_201 lang.IFn



				if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any; var root_203 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = n__0; if linked_204 == nil { arg_202 = ifn_205.Invoke_O__O(arg_206) } else { arg_202 = linked_204.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_203, arg_206) }; if linked_200 == nil { and__1927000168__auto____5 = ifn_201.Invoke_O__O(arg_202) } else { and__1927000168__auto____5 = linked_200.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_199, arg_202) }
//line :105:1
				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_207 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_209 lang.IFn




					if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = n__0; if linked_208 == nil { and__1927000168__auto____6 = ifn_209.Invoke_O__O(arg_210) } else { and__1927000168__auto____6 = linked_208.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_207, arg_210) }
//line :105:1
					if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_211 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_213 lang.IFn






						if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var root_215 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_220 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = n__0; if linked_221 == nil { tmp2 = ifn_222.Invoke_O__O(arg_223) } else { tmp2 = linked_221.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_220, arg_223) }; arg_218 = tmp1.Invoke_O__O(tmp2); var arg_219 any = A_arbace_j2g_model_A_const_47; if linked_216 == nil { arg_214 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { arg_214 = linked_216.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; if linked_212 == nil { and__1927000168__auto____7 = ifn_213.Invoke_O__O(arg_214) } else { and__1927000168__auto____7 = linked_212.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_211, arg_214) }
//line :105:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_224 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_226 lang.IFn









							if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp4 any; var root_228 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = n__0; if linked_229 == nil { tmp4 = ifn_230.Invoke_O__O(arg_231) } else { tmp4 = linked_229.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_228, arg_231) }; arg_227 = tmp3.Invoke_O__O(tmp4); if linked_225 == nil { and__1927000168__auto____8 = ifn_226.Invoke_O__O(arg_227) } else { and__1927000168__auto____8 = linked_225.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_224, arg_227) }
//line :105:1
							if jrt.J2g_Truth(and__1927000168__auto____8) {










								var root_232 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any; var tmp5 any = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New(); var tmp6 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class = fncls__245d; tmp6 = fncls__245d } else { tmp6 = fncls__245 }; arg_235 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_236 any; var tmp7 *lang.Keyword = A_arbace_j2g_model_A_const_53; var tmp8 any; var root_246 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = n__0; if linked_247 == nil { tmp8 = ifn_248.Invoke_O__O(arg_249) } else { tmp8 = linked_247.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_246, arg_249) }; arg_236 = tmp7.Invoke_O__O(tmp8); if linked_233 == nil { return ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { return linked_233.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_232, arg_235, arg_236) } } else {
//line :105:1
									return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Invoke_O_O__O(self, p1__1479000034_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_237 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = p1__1479000034_SHARP___1; if linked_238 == nil { or__1927000174__auto____2 = ifn_239.Invoke_O__O(arg_240) } else { or__1927000174__auto____2 = linked_238.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_237, arg_240) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_241 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = p1__1479000034_SHARP___1; if linked_242 == nil { return ifn_243.Invoke_O__O(arg_244) } else { return linked_242.(*A_arbace_j2g_model_reflectable_interface_QMARK__A).Invoke_O_O__O(root_241, arg_244) } } }

func A_arbace_j2g_model_reflected_QMARK__A_New() *A_arbace_j2g_model_reflected_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_250 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_252 lang.IFn; if


	linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = n__0; if linked_251 == nil { and__1927000168__auto____2 = ifn_252.Invoke_O__O(arg_253) } else { and__1927000168__auto____2 = linked_251.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_254 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_258 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = n__0; if linked_259 == nil { arg_257 = ifn_260.Invoke_O__O(arg_261) } else { arg_257 = linked_259.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_258, arg_261) }; if linked_255 == nil { return ifn_256.Invoke_O__O(arg_257) } else { return linked_255.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_254, arg_257) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_info_A_New() *A_arbace_j2g_model_info_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_info_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_j2g_model_info_A) Ctor() {}
//line :123:1
func (t *A_arbace_j2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { var root_262 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = n__0; if linked_263 == nil { return ifn_264.Invoke_O__O(arg_265) } else { return linked_263.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_262, arg_265) } }
func A_arbace_j2g_model_interface_QMARK__A_New() *A_arbace_j2g_model_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Ctor() {}
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_266 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = n__0; if linked_267 == nil { return ifn_268.Invoke_O__O(arg_269) } else { return linked_267.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_266, arg_269) } }

func A_arbace_j2g_model_desc_classes_A_New() *A_arbace_j2g_model_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(d__0, nil) { return nil } else { var tmp1 any; var root_270 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_272 lang.IFn
		if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = d__0; if linked_271 == nil { tmp1 = ifn_272.Invoke_O__O(arg_273) } else { tmp1 = linked_271.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_270, arg_273) }
//line :129:1
		if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var root_274 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_276 lang.IFn

			if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = d__0; if linked_275 == nil { tmp2 = ifn_276.Invoke_O__O(arg_277) } else { tmp2 = linked_275.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_274, arg_277) }
//line :129:1
			if jrt.J2g_Truth(tmp2) {

				var root_278 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = d__0; var arg_286 any; var root_287 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = d__0; if linked_288 == nil { arg_286 = ifn_289.Invoke_O__O(arg_290) } else { arg_286 = linked_288.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_287, arg_290) }; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if linked_279 == nil { return ifn_280.Invoke_O__O(arg_281) } else { return linked_279.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_278, arg_281) } } else {
//line :129:1
					var tmp3 any; var root_291 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_293 lang.IFn


					if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = d__0; if linked_292 == nil { tmp3 = ifn_293.Invoke_O__O(arg_294) } else { tmp3 = linked_292.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :129:1
					if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_295 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_297 lang.IFn


						if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = d__0; if linked_296 == nil { tmp4 = ifn_297.Invoke_O__O(arg_298) } else { tmp4 = linked_296.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_295, arg_298) }
//line :129:1
						return lang.Tuple_Create_O__IPersistentVector(tmp4) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil
						}
						}
				}
		}
	}
}



func A_arbace_j2g_model_method_desc_classes_A_New() *A_arbace_j2g_model_method_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_299 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_301 lang.IFn; if
											linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = desc__0; if linked_300 == nil { tmp1 = ifn_301.Invoke_O__O(arg_302) } else { tmp1 = linked_300.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_299, arg_302) }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Get_O__O(desc__0) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var vec__1479000042__3 any; var root_303 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_305 lang.IFn
												if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = desc__0; if linked_304 == nil { vec__1479000042__3 = ifn_305.Invoke_O__O(arg_306) } else { vec__1479000042__3 = linked_304.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_303, arg_306) }
//line :140:1
		var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(1), nil); var v__6 any; var root_307 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_309 lang.IFn

		if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var tmp4 any; var root_316 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = r__5; var arg_320 any = ps__4; if linked_317 == nil { tmp4 = ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { tmp4 = linked_317.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_316, arg_319, arg_320) }; arg_310 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_308 == nil { v__6 = ifn_309.Invoke_O__O(arg_310) } else { v__6 = linked_308.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_307, arg_310) }
		var tmp5 any; var root_321 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = desc__0; if linked_322 == nil { tmp5 = ifn_323.Invoke_O__O(arg_324) } else { tmp5 = linked_322.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(tmp5) { jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Put_O_O__O(desc__0, v__6) }
//line :140:1
		return v__6 } }





func A_arbace_j2g_model_erased_desc_QMARK__A_New() *A_arbace_j2g_model_erased_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_325 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_327 lang.IFn; if




	linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = d__0; if linked_326 == nil { and__1927000168__auto____2 = ifn_327.Invoke_O__O(arg_328) } else { and__1927000168__auto____2 = linked_326.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_325, arg_328) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp1 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class
		if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class = fncls__337d; tmp2 = fncls__337d } else { tmp2 = fncls__337 }; e__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :151:1
		var and__1927000168__auto____4 any; var root_338 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_340 lang.IFn

		if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = e__3; if linked_339 == nil { and__1927000168__auto____4 = ifn_340.Invoke_O__O(arg_341) } else { and__1927000168__auto____4 = linked_339.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var n__5 any; var root_342 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_344 lang.IFn
			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = e__3; if linked_343 == nil { n__5 = ifn_344.Invoke_O__O(arg_345) } else { n__5 = linked_343.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_342, arg_345) }
//line :153:1
			var and__1927000168__auto____6 any; var root_346 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_348 lang.IFn

			if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any; var root_350 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = n__5; if linked_351 == nil { arg_349 = ifn_352.Invoke_O__O(arg_353) } else { arg_349 = linked_351.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_350, arg_353) }; if linked_347 == nil { and__1927000168__auto____6 = ifn_348.Invoke_O__O(arg_349) } else { and__1927000168__auto____6 = linked_347.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
				var root_354 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var tmp3 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(n__5); var tmp4 *jrt.Class; var fncls__364 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class; if fncls__364 == nil { var fncls__364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class = fncls__364d; tmp4 = fncls__364d } else { tmp4 = fncls__364 }; arg_357 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_69; var arg_358 any = tmp5.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } } else {
//line :155:1
					return and__1927000168__auto____6 } } else {
//line :153:1
						return and__1927000168__auto____4 } } else {
//line :151:1
							return and__1927000168__auto____2 } }
func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { var tmp1 any; var root_329 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = d__1; if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_329, arg_332) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_333 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = d__1; if linked_334 == nil { tmp2 = ifn_335.Invoke_O__O(arg_336) } else { tmp2 = linked_334.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_333, arg_336) }; d__1 = tmp2; continue L1 } else { return d__1 } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A{}; t.Ctor_O(p0); return t }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Invoke_O_O__O(self, p1__1479000046_SHARP___1 any) any { var root_359 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = t.F_n; var arg_363 any = p1__1479000046_SHARP___1; if linked_360 == nil { return ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { return linked_360.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_359, arg_362, arg_363) } }

func A_arbace_j2g_model_desc_in_world_QMARK__A_New() *A_arbace_j2g_model_desc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var root_365 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_369 any; var root_370 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = d__0; if linked_371 == nil { arg_369 = ifn_372.Invoke_O__O(arg_373) } else { arg_369 = linked_371.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_370, arg_373) }; if linked_366 == nil { return ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { return linked_366.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_365, arg_368, arg_369) } }
func A_arbace_j2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_j2g_model_mdesc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { var root_374 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_378 any; var root_379 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, A_arbace_j2g_model_method_desc_classes_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = desc__0; if linked_380 == nil { arg_378 = ifn_381.Invoke_O__O(arg_382) } else { arg_378 = linked_380.(*A_arbace_j2g_model_method_desc_classes_A).Invoke_O_O__O(root_379, arg_382) }; if linked_375 == nil { return ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { return linked_375.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_374, arg_377, arg_378) } }




func A_arbace_j2g_model_go_name_A_New() *A_arbace_j2g_model_go_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_name_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; if




	jrt.J2g_Truth(A_arbace_j2g_model_A_const_33.Get__O()) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2; var tmp2 any; var root_383 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_385 lang.IFn
			if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = n__0; if linked_384 == nil { tmp2 = ifn_385.Invoke_O__O(arg_386) } else { tmp2 = linked_384.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_383, arg_386) }; if jrt.J2g_Truth(tmp2) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = A_arbace_j2g_model_A_const_71.Invoke_O__O(jc__3) } } else {
//line :170:1
				or__1927000174__auto____2 = nil } } else {
//line :169:1
					or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						var root_387 any = A_arbace_j2g_model_A_const_72.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = n__0; if linked_388 == nil { return ifn_389.Invoke_O__O(arg_390) } else { return linked_388.(*aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_387, arg_390) } } }
func A_arbace_j2g_model_pkg_A_New() *A_arbace_j2g_model_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pkg_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { var root_391 any = A_arbace_j2g_model_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = n__0; if linked_392 == nil { return ifn_393.Invoke_O__O(arg_394) } else { return linked_392.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_391, arg_394) } }

func A_arbace_j2g_model_abstract_QMARK__A_New() *A_arbace_j2g_model_abstract_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Ctor() {}
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_395 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_400 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, A_arbace_j2g_model_info_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = n__0; if linked_401 == nil { tmp2 = ifn_402.Invoke_O__O(arg_403) } else { tmp2 = linked_401.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_400, arg_403) }; arg_398 = tmp1.Invoke_O__O(tmp2); var arg_399 any = A_arbace_j2g_model_A_const_75; if linked_396 == nil { return ifn_397.Invoke_O_O__O(arg_398, arg_399) } else { return linked_396.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_395, arg_398, arg_399) } }
func A_arbace_j2g_model_final_QMARK__A_New() *A_arbace_j2g_model_final_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_404 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_409 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_j2g_model_info_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = n__0; if linked_410 == nil { tmp2 = ifn_411.Invoke_O__O(arg_412) } else { tmp2 = linked_410.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_409, arg_412) }; arg_407 = tmp1.Invoke_O__O(tmp2); var arg_408 any = A_arbace_j2g_model_A_const_76; if linked_405 == nil { return ifn_406.Invoke_O_O__O(arg_407, arg_408) } else { return linked_405.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_404, arg_407, arg_408) } }

func A_arbace_j2g_model_subclasses_A_New() *A_arbace_j2g_model_subclasses_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_subclasses_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Ctor() {}
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_77; return lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())).Invoke__O(), n__0)
}
func A_arbace_j2g_model_make_subclass_index_A_New() *A_arbace_j2g_model_make_subclass_index_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Ctor() {}
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any; var root_413 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_415 lang.IFn; if
											linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any; if linked_414 == nil { cache__2 = ifn_415.Invoke_O__O(arg_416) } else { cache__2 = linked_414.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_413, arg_416) }; var tmp1 any =
											A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(cache__2, w__0); var tmp2 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class = fncls__474d; tmp2 = fncls__474d } else { tmp2 = fncls__474 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :185:1
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_417 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_419 lang.IFn; if
												linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = t.F_cache; if linked_418 == nil { or__1927000174__auto____1 = ifn_419.Invoke_O__O(arg_420) } else { or__1927000174__auto____1 = linked_418.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var root_421 any = A_arbace_j2g_model_A_const_78.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = t.F_cache; var arg_425 any; var root_465 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_467 lang.IFn
													if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_33, t.F_w); if linked_466 == nil { ifn_467.Invoke_O__O(arg_468) } else { linked_466.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_465, arg_468) }; var tmp1 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(t.F_w); var tmp2 *jrt.Class; var fncls__464 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class; if fncls__464 == nil { var fncls__464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class = fncls__464d; tmp2 = fncls__464d } else { tmp2 = fncls__464 }; arg_425 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :187:1
		if linked_422 == nil { return ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { return linked_422.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } } }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(p0 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var root_426 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var tmp2 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New(); var tmp3 *jrt.Class; var fncls__448 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class; if fncls__448 == nil { var fncls__448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class = fncls__448d; tmp3 = fncls__448d } else { tmp3 = fncls__448 }; arg_429 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_430 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_431 any; var root_449 any = A_arbace_j2g_model_A_const_83.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_451 lang.IFn


		if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_454 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, A_arbace_j2g_model_T_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; if linked_455 == nil { arg_452 = ifn_456.Invoke__O() } else { arg_452 = linked_455.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_454) }; var arg_453 any; var root_457 any = A_arbace_j2g_model_A_const_84.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_37; var tmp5 any; var t_ any = t.F_w; t.F_w = nil; tmp5 = t_; arg_460 = tmp4.Invoke_O__O(tmp5); if linked_458 == nil { arg_453 = ifn_459.Invoke_O__O(arg_460) } else { arg_453 = linked_458.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_457, arg_460) }; if linked_450 == nil { arg_431 = ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { arg_431 = linked_450.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) }
//line :189:1
		if linked_427 == nil { tmp1 = ifn_428.Invoke_O_O_O__O(arg_429, arg_430, arg_431) } else { tmp1 = linked_427.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_426, arg_429, arg_430, arg_431) } }
//line :188:1
	return nil }(); var root_461 any = A_arbace_j2g_model_A_const_85.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; if linked_462 == nil { ifn_463.Invoke__O() } else { linked_462.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_461) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New() *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var s__3 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_432 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_j2g_model_info_A_fn_class); var ifn_434 lang.IFn; if
																		linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = c__2; if linked_433 == nil { tmp2 = ifn_434.Invoke_O__O(arg_435) } else { tmp2 = linked_433.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_432, arg_435) }; s__3 = tmp1.Invoke_O__O(tmp2); if
																		jrt.J2g_Truth(s__3) { var root_436 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = m__1; var arg_440 any = s__3; var arg_441 any; var root_443 any = A_arbace_j2g_model_A_const_82.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var arg_447 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_444 == nil { arg_441 = ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { arg_441 = linked_444.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; var arg_442 any = c__2; if linked_437 == nil { return ifn_438.Invoke_O_O_O_O__O(arg_439, arg_440, arg_441, arg_442) } else { return linked_437.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_436, arg_439, arg_440, arg_441, arg_442) } } else { return m__1 } }

















func A_arbace_j2g_model_leaf_QMARK__A_New() *A_arbace_j2g_model_leaf_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_475 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_477 lang.IFn

		if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = n__0; if linked_476 == nil { tmp1 = ifn_477.Invoke_O__O(arg_478) } else { tmp1 = linked_476.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_475, arg_478) }
//line :214:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var root_479 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_481 lang.IFn


			if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = n__0; if linked_480 == nil { tmp2 = ifn_481.Invoke_O__O(arg_482) } else { tmp2 = linked_480.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_479, arg_482) }
//line :214:1
			if jrt.J2g_Truth(tmp2) {


				var root_483 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var root_487 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_90; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_490 any = tmp3.Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_491 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_28); var tmp6 any; var root_492 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, A_arbace_j2g_model_go_name_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = n__0; if linked_493 == nil { tmp6 = ifn_494.Invoke_O__O(arg_495) } else { tmp6 = linked_493.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_492, arg_495) }; arg_491 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_488 == nil { arg_486 = ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { arg_486 = linked_488.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_487, arg_490, arg_491) }; if linked_484 == nil { return ifn_485.Invoke_O__O(arg_486) } else { return linked_484.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_483, arg_486) } } else {
//line :214:1
					if A_arbace_j2g_model_A_const_60 != nil { var and__1927000168__auto____2 any; var root_496 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_498 lang.IFn



						if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any; var root_500 any = A_arbace_j2g_model_A_const_93.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_j2g_model_abstract_QMARK__A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = n__0; if linked_501 == nil { arg_499 = ifn_502.Invoke_O__O(arg_503) } else { arg_499 = linked_501.(*A_arbace_j2g_model_abstract_QMARK__A).Invoke_O_O__O(root_500, arg_503) }; if linked_497 == nil { and__1927000168__auto____2 = ifn_498.Invoke_O__O(arg_499) } else { and__1927000168__auto____2 = linked_497.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_496, arg_499) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_504 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any; var root_508 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, A_arbace_j2g_model_subclasses_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = n__0; if linked_509 == nil { arg_507 = ifn_510.Invoke_O__O(arg_511) } else { arg_507 = linked_509.(*A_arbace_j2g_model_subclasses_A).Invoke_O_O__O(root_508, arg_511) }; if linked_505 == nil { and__1927000168__auto____3 = ifn_506.Invoke_O__O(arg_507) } else { and__1927000168__auto____3 = linked_505.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_504, arg_507) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
							var root_512 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_95.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_516 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var root_520 any = A_arbace_j2g_model_A_const_96.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = n__0; if linked_521 == nil { arg_519 = ifn_522.Invoke_O__O(arg_523) } else { arg_519 = linked_521.(*A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_520, arg_523) }; if linked_517 == nil { arg_515 = ifn_518.Invoke_O__O(arg_519) } else { arg_515 = linked_517.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_516, arg_519) } } else { arg_515 = and__1927000168__auto____4 }; if linked_513 == nil { return ifn_514.Invoke_O__O(arg_515) } else { return linked_513.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_512, arg_515) } } else {
//line :218:1
								return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :214:1
									return nil
								}
				}
		}
	}
}




func A_arbace_j2g_model_qualify_A_New() *A_arbace_j2g_model_qualify_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_qualify_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_j2g_model_qualify_A) Ctor() {}
//line :224:1
func (t *A_arbace_j2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z_NoInit(from__0, nil) }; if tmp1 { var root_524 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = ident__2; if linked_525 == nil { return ifn_526.Invoke_O__O(arg_527) } else { return linked_525.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_524, arg_527) } } else { var root_528 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var root_533 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = of__1; if linked_534 == nil { arg_531 = ifn_535.Invoke_O__O(arg_536) } else { arg_531 = linked_534.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A).Invoke_O_O__O(root_533, arg_536) }; var arg_532 any = ident__2; if linked_529 == nil { return ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { return linked_529.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_528, arg_531, arg_532)
	} } }
func A_arbace_j2g_model_class_sym_A_New() *A_arbace_j2g_model_class_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_sym_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_j2g_model_class_sym_A) Ctor() {}
//line :229:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	var root_537 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_j2g_model_qualify_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = from__0; var arg_541 any; var root_543 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, A_arbace_j2g_model_pkg_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = n__1; if linked_544 == nil { arg_541 = ifn_545.Invoke_O__O(arg_546) } else { arg_541 = linked_544.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_543, arg_546) }; var arg_542 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_547 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, A_arbace_j2g_model_go_name_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = n__1; if linked_548 == nil { tmp2 = ifn_549.Invoke_O__O(arg_550) } else { tmp2 = linked_548.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_547, arg_550) }; arg_542 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, suffix__2)).Ref(); if linked_538 == nil { return ifn_539.Invoke_O_O_O__O(arg_540, arg_541, arg_542) } else { return linked_538.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_537, arg_540, arg_541, arg_542) } }
//line :229:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	var root_551 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = from__0; var arg_555 any = n__1; var arg_556 any = Lit_13; if linked_552 == nil { return ifn_553.Invoke_O_O_O__O(arg_554, arg_555, arg_556) } else { return linked_552.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_551, arg_554, arg_555, arg_556)
	}
}
func A_arbace_j2g_model_jrt_sym_A_New() *A_arbace_j2g_model_jrt_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_j2g_model_jrt_sym_A) Ctor() {}
//line :234:1
func (t *A_arbace_j2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { var root_557 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_j2g_model_qualify_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = from__0; var arg_561 any = A_arbace_j2g_model_A_const_91; var arg_562 any = ident__1; if linked_558 == nil { return ifn_559.Invoke_O_O_O__O(arg_560, arg_561, arg_562) } else { return linked_558.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_557, arg_560, arg_561, arg_562) } }






func A_arbace_j2g_model_array_test_A_New() *A_arbace_j2g_model_array_test_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_array_test_A{}; t.Ctor(); return t }
//line :241:1
func (t *A_arbace_j2g_model_array_test_A) Ctor() {}
//line :241:1
func (t *A_arbace_j2g_model_array_test_A) Invoke_O_O_O_O_O_O__O(self, from__0, kind__1, x__2, d__3, comp__4 any) any { var e__6 any; var root_563 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_565 lang.IFn; if






	linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = d__3; if linked_564 == nil { e__6 = ifn_565.Invoke_O__O(arg_566) } else { e__6 = linked_564.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_563, arg_566) }; var suffix__7 any; if
	lang.Util_Equiv_O_O__Z_NoInit(kind__1, A_arbace_j2g_model_A_const_102) { suffix__7 = Lit_7 } else { suffix__7 = Lit_8 }; var tmp1 any; var root_567 any =
	A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_569 lang.IFn; if
	linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = e__6; if linked_568 == nil { tmp1 = ifn_569.Invoke_O__O(arg_570) } else { tmp1 = linked_568.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_567, arg_570) }; if /*line :250:1*/ jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp3 any; var root_571 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = from__0; var arg_575 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_model_A_const_106.GetRawRoot__O()).Invoke_O__O(e__6), suffix__7)).Ref(); if linked_572 == nil { tmp3 = ifn_573.Invoke_O_O__O(arg_574, arg_575) } else { tmp3 = linked_572.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_571, arg_574, arg_575) }; return tmp2.Invoke_O_O__O(tmp3, x__2) } else {
//line :250:1
			if lang.Util_Equiv_O_O__Z_NoInit(e__6, Lit_9) {

				var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp5 any; var root_576 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = from__0; var arg_580 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_577 == nil { tmp5 = ifn_578.Invoke_O_O__O(arg_579, arg_580) } else { tmp5 = linked_577.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_576, arg_579, arg_580) }; return tmp4.Invoke_O_O__O(tmp5, x__2) } else {
//line :250:1
					if A_arbace_j2g_model_A_const_60 != nil {


						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp7 any; var root_581 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = from__0; var arg_585 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, suffix__7)).Ref(); if linked_582 == nil { tmp7 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { tmp7 = linked_582.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }; return tmp6.Invoke_O_O_O__O(tmp7, x__2, comp__4) } else {
//line :250:1
							return nil } } } }




func A_arbace_j2g_model_go_type_A_New() *A_arbace_j2g_model_go_type_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_type_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_model_go_type_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, A_arbace_j2g_model_A_const_107) { return A_arbace_j2g_model_A_const_108 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_109.GetRawRoot__O()).Invoke_O__O(d__1)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_109.GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :258:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_27) { return nil } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_9) { return A_arbace_j2g_model_A_const_110 } else { var tmp1 any; var root_586 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_588 lang.IFn




				if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = d__1; if linked_587 == nil { tmp1 = ifn_588.Invoke_O__O(arg_589) } else { tmp1 = linked_587.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_586, arg_589) }
//line :258:1
				if jrt.J2g_Truth(tmp1) { var e__3 any; var root_590 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_592 lang.IFn




					if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = d__1; if linked_591 == nil { e__3 = ifn_592.Invoke_O__O(arg_593) } else { e__3 = linked_591.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_590, arg_593) }
					var tmp2 any; var root_594 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = e__3; if linked_595 == nil { tmp2 = ifn_596.Invoke_O__O(arg_597) } else { tmp2 = linked_595.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(tmp2) {
						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_116; var tmp5 any; var root_642 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = from__0; var arg_646 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_106.GetRawRoot__O()).Invoke_O__O(e__3); if linked_643 == nil { tmp5 = ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { tmp5 = linked_643.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_A_const_117; var tmp8 any; var root_647 any = A_arbace_j2g_model_A_const_105.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = from__0; var arg_651 any = Lit_11; if linked_648 == nil { tmp8 = ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { tmp8 = linked_648.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_647, arg_650, arg_651) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } } else {
//line :258:1
								var tmp9 any; var root_598 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_600 lang.IFn








								if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = d__1; if linked_599 == nil { tmp9 = ifn_600.Invoke_O__O(arg_601) } else { tmp9 = linked_599.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_598, arg_601) }
//line :258:1
								if jrt.J2g_Truth(tmp9) { var n__3 any; var root_602 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_604 lang.IFn









									if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = d__1; if linked_603 == nil { n__3 = ifn_604.Invoke_O__O(arg_605) } else { n__3 = linked_603.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_602, arg_605) }
									var tmp10 any; var root_606 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_608 lang.IFn
									if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_610 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = n__3; if linked_611 == nil { arg_609 = ifn_612.Invoke_O__O(arg_613) } else { arg_609 = linked_611.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_610, arg_613) }; if linked_607 == nil { tmp10 = ifn_608.Invoke_O__O(arg_609) } else { tmp10 = linked_607.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_606, arg_609) }
//line :269:1
									if jrt.J2g_Truth(tmp10) { return A_arbace_j2g_model_A_const_111 } else { var tmp11 any; var root_614 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_616 lang.IFn

										if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = n__3; if linked_615 == nil { tmp11 = ifn_616.Invoke_O__O(arg_617) } else { tmp11 = linked_615.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_614, arg_617) }
//line :269:1
										if jrt.J2g_Truth(tmp11) {

											var root_618 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = from__0; var arg_622 any = n__3; if linked_619 == nil { return ifn_620.Invoke_O_O__O(arg_621, arg_622) } else { return linked_619.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_618, arg_621, arg_622) } } else {
//line :269:1
												var tmp12 any; var root_623 any = A_arbace_j2g_model_A_const_112.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_625 lang.IFn


												if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = n__3; if linked_624 == nil { tmp12 = ifn_625.Invoke_O__O(arg_626) } else { tmp12 = linked_624.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_623, arg_626) }
//line :269:1
												if jrt.J2g_Truth(tmp12) {


													var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_model_A_const_118; var tmp15 any; var root_652 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = from__0; var arg_656 any = n__3; if linked_653 == nil { tmp15 = ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { tmp15 = linked_653.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) }; return tmp13.Invoke_O_O__O(tmp14, tmp15) } else {
//line :269:1
														if A_arbace_j2g_model_A_const_60 != nil {



															var root_627 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = from__0; var arg_631 any = n__3; var arg_632 any = Lit_28; if linked_628 == nil { return ifn_629.Invoke_O_O_O__O(arg_630, arg_631, arg_632) } else { return linked_628.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_627, arg_630, arg_631, arg_632) } } else {
//line :269:1
																return nil } } } } } else {
//line :258:1
																	if A_arbace_j2g_model_A_const_60 != nil { var tmp16 any; var root_633 any = A_arbace_j2g_model_A_const_113.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_635 lang.IFn















																		if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_114.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); var arg_637 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_115, d__1)); if linked_634 == nil { tmp16 = ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { tmp16 = linked_634.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_633, arg_636, arg_637) }
//line :258:1
																		panic(jrt.Thrown(jrt.Throwable_Cast(tmp16))) } else { return nil
																		}
																}
							}
			}
			}
		}
	}
}









func A_arbace_j2g_model_pointer_desc_QMARK__A_New() *A_arbace_j2g_model_pointer_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :276:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_657 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = d__0; if linked_658 == nil { tmp1 = ifn_659.Invoke_O__O(arg_660) } else { tmp1 = linked_658.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_657, arg_660) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_661 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_663 lang.IFn
		if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = d__0; if linked_662 == nil { tmp2 = ifn_663.Invoke_O__O(arg_664) } else { tmp2 = linked_662.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_661, arg_664) }
//line :279:1
		if jrt.J2g_Truth(tmp2) { var n__2 any; var root_665 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_667 lang.IFn
			if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = d__0; if linked_666 == nil { n__2 = ifn_667.Invoke_O__O(arg_668) } else { n__2 = linked_666.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_665, arg_668) }
//line :279:1
			var and__1927000168__auto____3 any; var root_669 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_671 lang.IFn

			if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = n__2; if linked_670 == nil { and__1927000168__auto____3 = ifn_671.Invoke_O__O(arg_672) } else { and__1927000168__auto____3 = linked_670.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_669, arg_672) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_673 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any; var root_677 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = n__2; if linked_678 == nil { arg_676 = ifn_679.Invoke_O__O(arg_680) } else { arg_676 = linked_678.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_677, arg_680) }; if linked_674 == nil { and__1927000168__auto____4 = ifn_675.Invoke_O__O(arg_676) } else { and__1927000168__auto____4 = linked_674.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_673, arg_676) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_681 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = n__2; var arg_685 any = Lit_30; if linked_682 == nil { and__1927000168__auto____5 = ifn_683.Invoke_O_O__O(arg_684, arg_685) } else { and__1927000168__auto____5 = linked_682.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_681, arg_684, arg_685) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_686 any = A_arbace_j2g_model_A_const_112.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = n__2; if linked_687 == nil { return ifn_688.Invoke_O__O(arg_689) } else { return linked_687.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_686, arg_689) } } else {
//line :281:1
					return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :279:1
						if A_arbace_j2g_model_A_const_60 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
						}
					}
	}
}

func A_arbace_j2g_model_iface_desc_QMARK__A_New() *A_arbace_j2g_model_iface_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :285:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Ctor() {}
//line :285:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_690 any = A_arbace_j2g_model_A_const_120.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_692 lang.IFn; if


	linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = d__0; if linked_691 == nil { and__1927000168__auto____2 = ifn_692.Invoke_O__O(arg_693) } else { and__1927000168__auto____2 = linked_691.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_690, arg_693) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_694 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = d__0; var arg_698 any = A_arbace_j2g_model_A_const_107; if linked_695 == nil { and__1927000168__auto____3 = ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { and__1927000168__auto____3 = linked_695.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_694, arg_697, arg_698) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_699 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var root_703 any = A_arbace_j2g_model_A_const_121.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = d__0; if linked_704 == nil { arg_702 = ifn_705.Invoke_O__O(arg_706) } else { arg_702 = linked_704.(*A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_703, arg_706) }; if linked_700 == nil { return ifn_701.Invoke_O__O(arg_702) } else { return linked_700.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_699, arg_702) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_model_static_QMARK__A_New() *A_arbace_j2g_model_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :293:1
func (t *A_arbace_j2g_model_static_QMARK__A) Ctor() {}
//line :293:1
func (t *A_arbace_j2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_707 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_711 any = A_arbace_j2g_model_A_const_122; if linked_708 == nil { return ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { return linked_708.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_707, arg_710, arg_711) } }
func A_arbace_j2g_model_private_QMARK__A_New() *A_arbace_j2g_model_private_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_j2g_model_private_QMARK__A) Ctor() {}
//line :294:1
func (t *A_arbace_j2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_712 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_716 any = A_arbace_j2g_model_A_const_123; if linked_713 == nil { return ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { return linked_713.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_712, arg_715, arg_716) } }
func A_arbace_j2g_model_abstract_m_QMARK__A_New() *A_arbace_j2g_model_abstract_m_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Ctor() {}
//line :295:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_717 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_721 any = A_arbace_j2g_model_A_const_75; if linked_718 == nil { return ifn_719.Invoke_O_O__O(arg_720, arg_721) } else { return linked_718.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_717, arg_720, arg_721) } }

func A_arbace_j2g_model_methods_of_A_New() *A_arbace_j2g_model_methods_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_methods_of_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_model_methods_of_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp2 any; var root_722 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, A_arbace_j2g_model_info_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = n__0; if linked_723 == nil { tmp2 = ifn_724.Invoke_O__O(arg_725) } else { tmp2 = linked_723.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_722, arg_725) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_j2g_model_fields_of_A_New() *A_arbace_j2g_model_fields_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fields_of_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_j2g_model_fields_of_A) Ctor() {}
//line :298:1
func (t *A_arbace_j2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_124; var tmp2 any; var root_726 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, A_arbace_j2g_model_info_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = n__0; if linked_727 == nil { tmp2 = ifn_728.Invoke_O__O(arg_729) } else { tmp2 = linked_727.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_726, arg_729) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_find_method_A_New() *A_arbace_j2g_model_find_method_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_j2g_model_find_method_A) Ctor() {}
//line :300:1
func (t *A_arbace_j2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var root_730 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var tmp1 any = A_arbace_j2g_model_find_method_fn__1479000080_A_New_O_O(name__1, desc__2); var tmp2 *jrt.Class; var fncls__735 *jrt.Class = A_arbace_j2g_model_find_method_fn__1479000080_A_fn_class; if fncls__735 == nil { var fncls__735d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_model_find_method_fn__1479000080_A_fn_class = fncls__735d; tmp2 = fncls__735d } else { tmp2 = fncls__735 }; arg_733 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_734 any; var root_736 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_736, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_738 lang.IFn; if linked_737 == nil { ifn_738 = lang.IFn_Cast(root_736) } else { ifn_738 = nil }; var arg_739 any = n__0; if linked_737 == nil { arg_734 = ifn_738.Invoke_O__O(arg_739) } else { arg_734 = linked_737.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_736, arg_739) }; if linked_731 == nil { return ifn_732.Invoke_O_O__O(arg_733, arg_734) } else { return linked_731.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_730, arg_733, arg_734) } }
//line :301:1
func A_arbace_j2g_model_find_method_fn__1479000080_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_find_method_fn__1479000080_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_fn__1479000080_A{}; t.Ctor_O_O(p0, p1); return t }
//line :301:1
func (t *A_arbace_j2g_model_find_method_fn__1479000080_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :301:1
func (t *A_arbace_j2g_model_find_method_fn__1479000080_A) Invoke_O_O__O(self, p1__1479000079_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_model_A_const_125.Invoke_O__O(p1__1479000079_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_model_A_const_115.Invoke_O__O(p1__1479000079_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1479000079_SHARP___1 } else { return nil } }

func A_arbace_j2g_model_virtual_member_QMARK__A_New() *A_arbace_j2g_model_virtual_member_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Ctor() {}
//line :303:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any; var root_740 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_742 lang.IFn; if


	linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var root_744 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = m__0; if linked_745 == nil { arg_743 = ifn_746.Invoke_O__O(arg_747) } else { arg_743 = linked_745.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_744, arg_747) }; if linked_741 == nil { and__1927000168__auto____2 = ifn_742.Invoke_O__O(arg_743) } else { and__1927000168__auto____2 = linked_741.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_740, arg_743) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_748 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any; var root_752 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = m__0; if linked_753 == nil { arg_751 = ifn_754.Invoke_O__O(arg_755) } else { arg_751 = linked_753.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_752, arg_755) }; if linked_749 == nil { and__1927000168__auto____3 = ifn_750.Invoke_O__O(arg_751) } else { and__1927000168__auto____3 = linked_749.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_748, arg_751) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_756 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = Lit_54; var arg_760 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(m__0); if linked_757 == nil { and__1927000168__auto____4 = ifn_758.Invoke_O_O__O(arg_759, arg_760) } else { and__1927000168__auto____4 = linked_757.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_756, arg_759, arg_760) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_761 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = Lit_78; var arg_765 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(m__0); if linked_762 == nil { return ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { return linked_762.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_761, arg_764, arg_765) } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_model_supertypes_A_New() *A_arbace_j2g_model_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_supertypes_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_j2g_model_supertypes_A) Ctor() {}
//line :313:1
func (t *A_arbace_j2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_766 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, A_arbace_j2g_model_info_A_fn_class); var ifn_768 lang.IFn; if
										linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = n__0; if linked_767 == nil { i__2 = ifn_768.Invoke_O__O(arg_769) } else { i__2 = linked_767.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_766, arg_769) }; var root_770 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var arg_774 any; var root_775 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(i__2); var arg_779 any = A_arbace_j2g_model_A_const_53.Invoke_O__O(i__2); if linked_776 == nil { arg_774 = ifn_777.Invoke_O_O__O(arg_778, arg_779) } else { arg_774 = linked_776.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_775, arg_778, arg_779) }; if linked_771 == nil { return ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { return linked_771.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) } }

func A_arbace_j2g_model_world_supertypes_A_New() *A_arbace_j2g_model_world_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_j2g_model_world_supertypes_A) Ctor() {}
//line :316:1
func (t *A_arbace_j2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	var root_780 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_784 any; var root_785 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_j2g_model_supertypes_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = n__0; if linked_786 == nil { arg_784 = ifn_787.Invoke_O__O(arg_788) } else { arg_784 = linked_786.(*A_arbace_j2g_model_supertypes_A).Invoke_O_O__O(root_785, arg_788) }; if linked_781 == nil { return ifn_782.Invoke_O_O__O(arg_783, arg_784) } else { return linked_781.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_780, arg_783, arg_784)
	} }
func A_arbace_j2g_model_all_supertypes_A_New() *A_arbace_j2g_model_all_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :321:1
func (t *A_arbace_j2g_model_all_supertypes_A) Ctor() {}
//line :321:1
func (t *A_arbace_j2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	var root_789 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var root_793 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_797 any; var root_798 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = n__0; if linked_799 == nil { arg_797 = ifn_800.Invoke_O__O(arg_801) } else { arg_797 = linked_799.(*aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_798, arg_801) }; if linked_794 == nil { arg_792 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { arg_792 = linked_794.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }; if linked_790 == nil { return ifn_791.Invoke_O__O(arg_792) } else { return linked_790.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_789, arg_792)
	}
}

func A_arbace_j2g_model_hw_method_exists_QMARK__A_New() *A_arbace_j2g_model_hw_method_exists_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :330:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_91; var scan__3 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var g__4 any; var root_802 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, A_arbace_j2g_model_go_name_A_fn_class); var ifn_804 lang.IFn; if



	linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = n__0; if linked_803 == nil { g__4 = ifn_804.Invoke_O__O(arg_805) } else { g__4 = linked_803.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_802, arg_805) }; var base__5 any; var root_806 any = /*line :330:1*/A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_808 lang.IFn; if




	linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = A_arbace_j2g_model_A_const_125.Invoke_O__O(m__1); var arg_810 any = A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1); if linked_807 == nil { base__5 = ifn_808.Invoke_O_O__O(arg_809, arg_810) } else { base__5 = linked_807.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_806, arg_809, arg_810) }; if
	lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_30) {
		var root_811 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var arg_815 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_125.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1)); if linked_812 == nil { return ifn_813.Invoke_O_O__O(arg_814, arg_815) } else { return linked_812.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_811, arg_814, arg_815) } } else {
//line :336:1
			var tmp2 any; var root_816 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_818 lang.IFn

			if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = n__0; if linked_817 == nil { tmp2 = ifn_818.Invoke_O__O(arg_819) } else { tmp2 = linked_817.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_816, arg_819) }
//line :336:1
			if jrt.J2g_Truth(tmp2) { var or__1927000174__auto____6 any; var root_820 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_822 lang.IFn

				if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var root_825 any = A_arbace_j2g_model_A_const_136.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = scan__3; var arg_829 any = g__4; if linked_826 == nil { arg_823 = ifn_827.Invoke_O_O__O(arg_828, arg_829) } else { arg_823 = linked_826.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_825, arg_828, arg_829) }; var arg_824 any = base__5; if linked_821 == nil { or__1927000174__auto____6 = ifn_822.Invoke_O_O__O(arg_823, arg_824) } else { or__1927000174__auto____6 = linked_821.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_820, arg_823, arg_824) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					var root_830 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_832 lang.IFn; if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = A_arbace_j2g_model_A_const_137.Invoke_O__O(scan__3); var arg_834 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref(); if linked_831 == nil { return ifn_832.Invoke_O_O__O(arg_833, arg_834) } else { return linked_831.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_830, arg_833, arg_834) } } } else {
//line :336:1
						if A_arbace_j2g_model_A_const_60 != nil { var ms__6 any; var root_835 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_837 lang.IFn




							if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = scan__3; var arg_839 any = g__4; if linked_836 == nil { ms__6 = ifn_837.Invoke_O_O__O(arg_838, arg_839) } else { ms__6 = linked_836.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_835, arg_838, arg_839) }
//line :336:1
							var or__1927000174__auto____7 any; var root_840 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_842 lang.IFn





							if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = ms__6; var arg_844 any = base__5; if linked_841 == nil { or__1927000174__auto____7 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { or__1927000174__auto____7 = linked_841.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_840, arg_843, arg_844) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_845 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = ms__6; var arg_849 any; var root_850 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = base__5; if linked_851 == nil { arg_849 = ifn_852.Invoke_O__O(arg_853) } else { arg_849 = linked_851.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_850, arg_853) }; if linked_846 == nil { or__1927000174__auto____8 = ifn_847.Invoke_O_O__O(arg_848, arg_849) } else { or__1927000174__auto____8 = linked_846.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_845, arg_848, arg_849) }; if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								var root_854 any = A_arbace_j2g_model_A_const_140.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, A_arbace_j2g_model_j2g_method_QMARK__A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = n__0; var arg_858 any = base__5; if linked_855 == nil { return ifn_856.Invoke_O_O__O(arg_857, arg_858) } else { return linked_855.(*A_arbace_j2g_model_j2g_method_QMARK__A).Invoke_O_O_O__O(root_854, arg_857, arg_858) } } } } else {
//line :336:1
									return nil } } } }








func A_arbace_j2g_model_j2g_method_QMARK__A_New() *A_arbace_j2g_model_j2g_method_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_method_QMARK__A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Ctor() {}
//line :345:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_38); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_141).Invoke_O__O(base__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_859 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_861 lang.IFn
		if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = Lit_39; if linked_860 == nil { and__1927000168__auto____5 = ifn_861.Invoke_O__O(arg_862) } else { and__1927000168__auto____5 = linked_860.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_859, arg_862) }
//line :352:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_863 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_865 lang.IFn; if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = Lit_40; if linked_864 == nil { return ifn_865.Invoke_O__O(arg_866) } else { return linked_864.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_863, arg_866) } } else {
//line :352:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_member_in_world_QMARK__A_New() *A_arbace_j2g_model_member_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Ctor() {}
//line :355:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any; var root_867 any = A_arbace_j2g_model_A_const_142.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_869 lang.IFn; if



	linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = A_arbace_j2g_model_A_const_115.Invoke_O__O(m__1); if linked_868 == nil { and__1927000168__auto____3 = ifn_869.Invoke_O__O(arg_870) } else { and__1927000168__auto____3 = linked_868.(*A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_867, arg_870) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_871 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_873 lang.IFn
		if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any; var root_875 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = n__0; if linked_876 == nil { arg_874 = ifn_877.Invoke_O__O(arg_878) } else { arg_874 = linked_876.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_875, arg_878) }; if linked_872 == nil { or__1927000174__auto____4 = ifn_873.Invoke_O__O(arg_874) } else { or__1927000174__auto____4 = linked_872.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_871, arg_874) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_879 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = n__0; var arg_883 any = m__1; if linked_880 == nil { return ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { return linked_880.(*A_arbace_j2g_model_hw_method_exists_QMARK__A).Invoke_O_O_O__O(root_879, arg_882, arg_883) } } } else {
//line :359:1
			return and__1927000168__auto____3 } }


func A_arbace_j2g_model_declared_vmethods_A_New() *A_arbace_j2g_model_declared_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Ctor() {}
//line :362:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__980 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_fn_class; if


	fncls__980 == nil { var fncls__980d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_fn_class = fncls__980d; tmp2 = fncls__980d } else { tmp2 = fncls__980 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_981 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = n__0; if linked_982 == nil { tmp4 = ifn_983.Invoke_O__O(arg_984) } else { tmp4 = linked_982.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_981, arg_984) }; return tmp3.Invoke_O__O(tmp4) }
//line :365:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_New_O(p0 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A{}; t.Ctor_O(p0); return t }
//line :365:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :365:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A) Invoke_O_O__O(self, s__1479000091__1 any) any { var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_New_O_O_O(t.F_n, s__1479000091__1, self); var tmp2 *jrt.Class; var fncls__979 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_fn_class; if fncls__979 == nil { var fncls__979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_fn_class = fncls__979d; tmp2 = fncls__979d } else { tmp2 = fncls__979 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :365:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A) Ctor_O_O_O(c__n, c__s__1479000091, c__iter__1479000090 any) { t.F_n = c__n; t.F_s__1479000091 = c__s__1479000091; t.F_iter__1479000090 = c__iter__1479000090 }
//line :365:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A) Invoke_O__O(self any) any { { var s__1479000091__1 any; var t_ any = t.F_s__1479000091; t.F_s__1479000091 = nil; s__1479000091__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_884 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = s__1479000091__1; if linked_885 == nil { temp__1927000414__auto____2 = ifn_886.Invoke_O__O(arg_887) } else { temp__1927000414__auto____2 = linked_885.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_884, arg_887) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000091__3 any = temp__1927000414__auto____2; var tmp1 any; var root_888 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = s__1479000091__3; if linked_889 == nil { tmp1 = ifn_890.Invoke_O__O(arg_891) } else { tmp1 = linked_889.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_888, arg_891) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_892 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = s__1479000091__3; if linked_893 == nil { c__1927001037__auto____4 = ifn_894.Invoke_O__O(arg_895) } else { c__1927001037__auto____4 = linked_893.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_892, arg_895) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000093__6 any; var root_896 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_897 == nil { b__1479000093__6 = ifn_898.Invoke_O__O(arg_899) } else { b__1479000093__6 = linked_897.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_896, arg_899) }; var tmp2 any = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_New_O_O_I_O(t.F_n, b__1479000093__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__920 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_fn_class; if fncls__920 == nil { var fncls__920d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_fn_class = fncls__920d; tmp3 = fncls__920d } else { tmp3 = fncls__920 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_921 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any; var root_926 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = b__1479000093__6; if linked_927 == nil { arg_924 = ifn_928.Invoke_O__O(arg_929) } else { arg_924 = linked_927.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_926, arg_929) }; var arg_925 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000090); var tmp5 any; var root_930 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = s__1479000091__3; if linked_931 == nil { tmp5 = ifn_932.Invoke_O__O(arg_933) } else { tmp5 = linked_931.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_930, arg_933) }; arg_925 = tmp4.Invoke_O__O(tmp5); if linked_922 == nil { return ifn_923.Invoke_O_O__O(arg_924, arg_925) } else { return linked_922.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_921, arg_924, arg_925) } } else { var root_934 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any; var root_939 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = b__1479000093__6; if linked_940 == nil { arg_937 = ifn_941.Invoke_O__O(arg_942) } else { arg_937 = linked_940.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_939, arg_942) }; var arg_938 any; if linked_935 == nil { return ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { return linked_935.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) } } } else { var m__4 any; var root_943 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = s__1479000091__3; if linked_944 == nil { m__4 = ifn_945.Invoke_O__O(arg_946) } else { m__4 = linked_944.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_943, arg_946) }; var tmp6 any; var root_947 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_949 lang.IFn
															if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = m__4; if linked_948 == nil { tmp6 = ifn_949.Invoke_O__O(arg_950) } else { tmp6 = linked_948.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_947, arg_950) }
//line :365:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_951 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_953 lang.IFn

		if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = t.F_n; var arg_955 any = m__4; if linked_952 == nil { tmp7 = ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { tmp7 = linked_952.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_951, arg_954, arg_955) }
//line :365:1
		if jrt.J2g_Truth(tmp7) { var root_956 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any; var root_961 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_963 lang.IFn


			if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = m__4; var arg_965 any = A_arbace_j2g_model_A_const_151; var arg_966 any = t.F_n; if linked_962 == nil { arg_959 = ifn_963.Invoke_O_O_O__O(arg_964, arg_965, arg_966) } else { arg_959 = linked_962.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_961, arg_964, arg_965, arg_966) }
//line :365:1
			var arg_960 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000090); var tmp9 any; var root_967 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = s__1479000091__3; if linked_968 == nil { tmp9 = ifn_969.Invoke_O__O(arg_970) } else { tmp9 = linked_968.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_967, arg_970) }; arg_960 = tmp8.Invoke_O__O(tmp9); if linked_957 == nil { return ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { return linked_957.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) } } else { var tmp10 any; var root_971 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = s__1479000091__3; if linked_972 == nil { tmp10 = ifn_973.Invoke_O__O(arg_974) } else { tmp10 = linked_972.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_971, arg_974) }; s__1479000091__1 = tmp10; continue L1 } } else { var tmp11 any; var root_975 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = s__1479000091__3; if linked_976 == nil { tmp11 = ifn_977.Invoke_O__O(arg_978) } else { tmp11 = linked_976.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_975, arg_978) }; s__1479000091__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :365:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A) Ctor_O_O_I_O(c__n, c__b__1479000093 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1479000093 = c__b__1479000093; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A) Invoke_O__O(self any) any { { var i__1479000092__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000092__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000092__1)); var tmp2 any; var root_900 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_902 lang.IFn
																	if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = m__2; if linked_901 == nil { tmp2 = ifn_902.Invoke_O__O(arg_903) } else { tmp2 = linked_901.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_900, arg_903) }
//line :365:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_904 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_906 lang.IFn

		if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = t.F_n; var arg_908 any = m__2; if linked_905 == nil { tmp3 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { tmp3 = linked_905.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }
//line :365:1
		if jrt.J2g_Truth(tmp3) { var root_909 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = t.F_b__1479000093; var arg_913 any; var root_914 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_916 lang.IFn


			if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = m__2; var arg_918 any = A_arbace_j2g_model_A_const_151; var arg_919 any = t.F_n; if linked_915 == nil { arg_913 = ifn_916.Invoke_O_O_O__O(arg_917, arg_918, arg_919) } else { arg_913 = linked_915.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_914, arg_917, arg_918, arg_919) }
//line :365:1
			if linked_910 == nil { ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { linked_910.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) }; i__1479000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000092__1); continue L1 } else { i__1479000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000092__1); continue L1 } } else { i__1479000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000092__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_model_vmethods_A_New() *A_arbace_j2g_model_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_j2g_model_vmethods_A) Ctor() {}
//line :370:1
func (t *A_arbace_j2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_157; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var or__1927000174__auto____3 any; var tmp2 any; var root_985 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_987 lang.IFn; if




	linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = cache__2; if linked_986 == nil { tmp2 = ifn_987.Invoke_O__O(arg_988) } else { tmp2 = linked_986.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_985, arg_988) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var root_989 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_991 lang.IFn
		if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any; var tmp3 any = A_arbace_j2g_model_vmethods_fn__1479000101_A_New(); var tmp4 *jrt.Class; var fncls__1022 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000101_A_fn_class; if fncls__1022 == nil { var fncls__1022d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_j2g_model_vmethods_fn__1479000101_A_fn_class = fncls__1022d; tmp4 = fncls__1022d } else { tmp4 = fncls__1022 }; arg_992 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_993 any; var root_1023 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_1025 lang.IFn






		if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; if linked_1024 == nil { arg_993 = ifn_1025.Invoke__O() } else { arg_993 = linked_1024.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_1023) }
//line :376:1
		var arg_994 any; var root_1026 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1028 lang.IFn






		if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = n__0; if linked_1027 == nil { arg_994 = ifn_1028.Invoke_O__O(arg_1029) } else { arg_994 = linked_1027.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1026, arg_1029) }
//line :376:1
		if linked_990 == nil { r__4 = ifn_991.Invoke_O_O_O__O(arg_992, arg_993, arg_994) } else { r__4 = linked_990.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_989, arg_992, arg_993, arg_994)
		}






		var root_1030 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = cache__2; var arg_1034 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var arg_1035 any = n__0; var arg_1036 any = r__4; if linked_1031 == nil { ifn_1032.Invoke_O_O_O_O__O(arg_1033, arg_1034, arg_1035, arg_1036) } else { linked_1031.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1030, arg_1033, arg_1034, arg_1035, arg_1036) }
//line :375:1
		return r__4 } }
func A_arbace_j2g_model_vmethods_fn__1479000101_A_New() *A_arbace_j2g_model_vmethods_fn__1479000101_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000101_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_A) Ctor() {}
//line :376:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(c__2, Lit_30) { return acc__1 } else {

		var root_995 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any; var tmp1 any = A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_New(); var tmp2 *jrt.Class; var fncls__1017 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_fn_class; if fncls__1017 == nil { var fncls__1017d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_fn_class = fncls__1017d; tmp2 = fncls__1017d } else { tmp2 = fncls__1017 }; arg_998 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_999 any = acc__1; var arg_1000 any; var root_1018 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_j2g_model_declared_vmethods_A_fn_class); var ifn_1020 lang.IFn


		if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = c__2; if linked_1019 == nil { arg_1000 = ifn_1020.Invoke_O__O(arg_1021) } else { arg_1000 = linked_1019.(*A_arbace_j2g_model_declared_vmethods_A).Invoke_O_O__O(root_1018, arg_1021) }
//line :379:1
		if linked_996 == nil { return ifn_997.Invoke_O_O_O__O(arg_998, arg_999, arg_1000) } else { return linked_996.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_995, arg_998, arg_999, arg_1000) } } }
//line :379:1
func A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_New() *A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A) Ctor() {}
//line :379:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_125.Invoke_O__O(m__2), A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)); var tmp1 any; var or__1927000174__auto____4 any; var root_1001 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1003 lang.IFn; if

	linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = acc__1; var arg_1005 any = k__3; if linked_1002 == nil { or__1927000174__auto____4 = ifn_1003.Invoke_O_O__O(arg_1004, arg_1005) } else { or__1927000174__auto____4 = linked_1002.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1001, arg_1004, arg_1005) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_1006 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var arg_1010 any = k__3; if linked_1007 == nil { tmp1 = ifn_1008.Invoke_O_O__O(arg_1009, arg_1010) } else { tmp1 = linked_1007.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1006, arg_1009, arg_1010) } }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_1011 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = acc__1; var arg_1015 any = k__3; var arg_1016 any = m__2; if linked_1012 == nil { return ifn_1013.Invoke_O_O_O__O(arg_1014, arg_1015, arg_1016) } else { return linked_1012.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1011, arg_1014, arg_1015, arg_1016) } } }





func A_arbace_j2g_model_java_type_name_A_New() *A_arbace_j2g_model_java_type_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_java_type_name_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_j2g_model_java_type_name_A) Ctor() {}
//line :387:1
func (t *A_arbace_j2g_model_java_type_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_1037 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = d__0; if linked_1038 == nil { tmp1 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp1 = linked_1038.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1037, arg_1040) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_44); var tmp3 any; var root_1041 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any; var root_1045 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = d__0; if linked_1046 == nil { arg_1044 = ifn_1047.Invoke_O__O(arg_1048) } else { arg_1044 = linked_1046.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1045, arg_1048) }; if linked_1042 == nil { tmp3 = ifn_1043.Invoke_O__O(arg_1044) } else { tmp3 = linked_1042.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1041, arg_1044) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref() } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(d__0))) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_162).Invoke_O__O(d__0) } else {
//line :390:1
			if A_arbace_j2g_model_A_const_60 != nil {


				var root_1049 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any; var root_1055 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = d__0; if linked_1056 == nil { arg_1052 = ifn_1057.Invoke_O__O(arg_1058) } else { arg_1052 = linked_1056.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1055, arg_1058) }; var arg_1053 any = Lit_1; var arg_1054 any = Lit_2; if linked_1050 == nil { return ifn_1051.Invoke_O_O_O__O(arg_1052, arg_1053, arg_1054) } else { return linked_1050.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1049, arg_1052, arg_1053, arg_1054) } } else {
//line :390:1
					return nil
				}
		}
	}
}
func A_arbace_j2g_model_abstract_method_error_text_A_New() *A_arbace_j2g_model_abstract_method_error_text_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_method_error_text_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Ctor() {}
//line :395:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Invoke_O_O_O_O__O(self, n__0, owner__1, p__1479000107__2 any) any { var vec__1479000108__4 any = p__1479000107__2; var name__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000108__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000108__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1479000111__7 any; var root_1059 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1061 lang.IFn; if



	linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = desc__6; if linked_1060 == nil { vec__1479000111__7 = ifn_1061.Invoke_O__O(arg_1062) } else { vec__1479000111__7 = linked_1060.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1059, arg_1062) }; var ps__8 any = /*line :395:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1479000111__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000111__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,12,s15:Receiver class ns69: does not define or inherit an implementation of the resolved method s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1063 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1065 lang.IFn; if




	linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = n__0; var arg_1067 any = Lit_1; var arg_1068 any = Lit_2; if linked_1064 == nil { tmp2 = ifn_1065.Invoke_O_O_O__O(arg_1066, arg_1067, arg_1068) } else { tmp2 = linked_1064.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1063, arg_1066, arg_1067, arg_1068) }; var tmp3 any = tmp2; var tmp4 any; var root_1069 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1071 lang.IFn; if
	linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = r__9; if linked_1070 == nil { tmp4 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp4 = linked_1070.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1069, arg_1072) }; var tmp5 any = tmp4; var tmp6 any; var root_1073 any = /*line :400:1*/A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1075 lang.IFn; if
	linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = Lit_3; var arg_1077 any; var root_1078 any = A_arbace_j2g_model_A_const_165.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = A_arbace_j2g_model_A_const_161.GetRawRoot__O(); var arg_1082 any = ps__8; if linked_1079 == nil { arg_1077 = ifn_1080.Invoke_O_O__O(arg_1081, arg_1082) } else { arg_1077 = linked_1079.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1078, arg_1081, arg_1082) }; if linked_1074 == nil { tmp6 = ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { tmp6 = linked_1074.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) }; var tmp7 any = tmp6; var tmp8 /*line :400:1*/*jrt.String; if

	jrt.J2g_Truth(owner__1) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil, nil); var tmp10 *jrt.String; var tmp11 any; var root_1083 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = owner__1; if linked_1084 == nil { tmp11 = ifn_1085.Invoke_O__O(arg_1086) } else { tmp11 = linked_1084.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1083, arg_1086) }; if jrt.J2g_Truth(tmp11) { tmp10 = Lit_5 } else { tmp10 = Lit_6 }; var tmp12 any = tmp10.Ref(); var tmp13 any; var root_1087 any = A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = owner__1; var arg_1091 any = Lit_1; var arg_1092 any = Lit_2; if linked_1088 == nil { tmp13 = ifn_1089.Invoke_O_O_O__O(arg_1090, arg_1091, arg_1092) } else { tmp13 = linked_1088.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1087, arg_1090, arg_1091, arg_1092) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13)) } else { tmp8 = nil }; return /*line :400:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, nil, tmp5, nil, name__5, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }



func A_arbace_j2g_model_superclass_chain_A_New() *A_arbace_j2g_model_superclass_chain_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_j2g_model_superclass_chain_A) Ctor() {}
//line :404:1
func (t *A_arbace_j2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1093 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var arg_1097 any; var root_1098 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any; var tmp1 any = A_arbace_j2g_model_superclass_chain_fn__1479000116_A_New(); var tmp2 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_j2g_model_superclass_chain_fn__1479000116_A_fn_class; if fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_j2g_model_superclass_chain_fn__1479000116_A_fn_class = fncls__1107d; tmp2 = fncls__1107d } else { tmp2 = fncls__1107 }; arg_1101 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1102 any = n__0; if linked_1099 == nil { arg_1097 = ifn_1100.Invoke_O_O__O(arg_1101, arg_1102) } else { arg_1097 = linked_1099.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1098, arg_1101, arg_1102) }; if linked_1094 == nil { return ifn_1095.Invoke_O_O__O(arg_1096, arg_1097) } else { return linked_1094.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1093, arg_1096, arg_1097) } }
//line :405:1
func A_arbace_j2g_model_superclass_chain_fn__1479000116_A_New() *A_arbace_j2g_model_superclass_chain_fn__1479000116_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_fn__1479000116_A{}; t.Ctor(); return t }
//line :405:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000116_A) Ctor() {}
//line :405:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000116_A) Invoke_O_O__O(self, p1__1479000115_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_1103 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, A_arbace_j2g_model_info_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = p1__1479000115_SHARP___1; if linked_1104 == nil { tmp2 = ifn_1105.Invoke_O__O(arg_1106) } else { tmp2 = linked_1104.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1103, arg_1106) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_impl_of_A_New() *A_arbace_j2g_model_impl_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_j2g_model_impl_of_A) Ctor() {}
//line :407:1
func (t *A_arbace_j2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1479000120__1 any) any { var vec__1479000121__3 any = p__1479000120__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000121__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000121__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__1479000121__3; var or__1927000174__auto____7 any; var root_1108 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1110 lang.IFn; _ = k__6; if





	linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any; var tmp1 any = A_arbace_j2g_model_impl_of_fn__1479000124_A_New_O_O_O(name__4, desc__5, n__0); var tmp2 *jrt.Class; var fncls__1183 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class; if fncls__1183 == nil { var fncls__1183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class = fncls__1183d; tmp2 = fncls__1183d } else { tmp2 = fncls__1183 }; arg_1111 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1112 any; var root_1184 any = A_arbace_j2g_model_A_const_176.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1186 lang.IFn; if












	linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = n__0; if linked_1185 == nil { arg_1112 = ifn_1186.Invoke_O__O(arg_1187) } else { arg_1112 = linked_1185.(*A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1184, arg_1187) }; if /*line :413:1*/ linked_1109 == nil { or__1927000174__auto____7 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { or__1927000174__auto____7 = linked_1109.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var tmp3 any = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_New_O_O(name__4, desc__5); var tmp4 *jrt.Class
		var fncls__1370 /*line :413:1*/*jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_fn_class














		if fncls__1370 == nil { var fncls__1370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_fn_class = fncls__1370d; tmp4 = fncls__1370d } else { tmp4 = fncls__1370 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp6 any; var root_1397 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = n__0; if linked_1398 == nil { tmp6 = ifn_1399.Invoke_O__O(arg_1400) } else { tmp6 = linked_1398.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1397, arg_1400) }; cands__8 = tmp5.Invoke_O__O(tmp6)
//line :413:1
		var cands__9 any; var root_1371 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1373 lang.IFn





















		if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any; var tmp7 any = A_arbace_j2g_model_impl_of_fn__1479000136_A_New_O(cands__8); var tmp8 *jrt.Class; var fncls__1392 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000136_A_fn_class; if fncls__1392 == nil { var fncls__1392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_model_impl_of_fn__1479000136_A_fn_class = fncls__1392d; tmp8 = fncls__1392d } else { tmp8 = fncls__1392 }; arg_1374 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1375 any = cands__8; if linked_1372 == nil { cands__9 = ifn_1373.Invoke_O_O__O(arg_1374, arg_1375) } else { cands__9 = linked_1372.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1371, arg_1374, arg_1375) }
		var root_1393 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = cands__9; if linked_1394 == nil { return ifn_1395.Invoke_O__O(arg_1396) } else { return linked_1394.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1393, arg_1396) } } }
//line :413:1
func A_arbace_j2g_model_impl_of_fn__1479000124_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_impl_of_fn__1479000124_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000124_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :413:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :413:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000124_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var root_1113 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1115 lang.IFn; if
											linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var root_1117 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = c__1; if linked_1118 == nil { arg_1116 = ifn_1119.Invoke_O__O(arg_1120) } else { arg_1116 = linked_1118.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1117, arg_1120) }; if linked_1114 == nil { and__1927000168__auto____2 = ifn_1115.Invoke_O__O(arg_1116) } else { and__1927000168__auto____2 = linked_1114.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1121 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = c__1; var arg_1125 any = t.F_name; var arg_1126 any = t.F_desc; if linked_1122 == nil { temp__1927000414__auto____2 = ifn_1123.Invoke_O_O_O__O(arg_1124, arg_1125, arg_1126) } else { temp__1927000414__auto____2 = linked_1122.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1121, arg_1124, arg_1125, arg_1126) } } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any; var root_1127 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1129 lang.IFn
												if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any; var root_1131 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = m__3; if linked_1132 == nil { arg_1130 = ifn_1133.Invoke_O__O(arg_1134) } else { arg_1130 = linked_1132.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1131, arg_1134) }; if linked_1128 == nil { and__1927000168__auto____4 = ifn_1129.Invoke_O__O(arg_1130) } else { and__1927000168__auto____4 = linked_1128.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1127, arg_1130) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1135 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any; var root_1139 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = m__3; if linked_1140 == nil { arg_1138 = ifn_1141.Invoke_O__O(arg_1142) } else { arg_1138 = linked_1140.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1139, arg_1142) }; if linked_1136 == nil { and__1927000168__auto____5 = ifn_1137.Invoke_O__O(arg_1138) } else { and__1927000168__auto____5 = linked_1136.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1135, arg_1138) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1143 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1145 lang.IFn
													if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any; var root_1147 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = m__3; if linked_1148 == nil { arg_1146 = ifn_1149.Invoke_O__O(arg_1150) } else { arg_1146 = linked_1148.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1147, arg_1150) }; if linked_1144 == nil { or__1927000174__auto____6 = ifn_1145.Invoke_O__O(arg_1146) } else { or__1927000174__auto____6 = linked_1144.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1143, arg_1146) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__1, t.F_n)).Ref() } } else {
//line :415:1
				tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

					if lang.Util_Equiv_O_O__Z_NoInit(c__1, Lit_30) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_171, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { var tmp2 any; var root_1151 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1153 lang.IFn

						if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = c__1; if linked_1152 == nil { tmp2 = ifn_1153.Invoke_O__O(arg_1154) } else { tmp2 = linked_1152.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1151, arg_1154) }
//line :417:1
						if jrt.J2g_Truth(tmp2) { var base__4 any; var root_1155 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1157 lang.IFn


							if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = t.F_name; var arg_1159 any = t.F_desc; if linked_1156 == nil { base__4 = ifn_1157.Invoke_O_O__O(arg_1158, arg_1159) } else { base__4 = linked_1156.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1155, arg_1158, arg_1159) }
//line :417:1
							var ms__5 any; var root_1160 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1162 lang.IFn



							if linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1163 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var arg_1164 any; var root_1165 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = c__1; if linked_1166 == nil { arg_1164 = ifn_1167.Invoke_O__O(arg_1168) } else { arg_1164 = linked_1166.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1165, arg_1168) }; if linked_1161 == nil { ms__5 = ifn_1162.Invoke_O_O__O(arg_1163, arg_1164) } else { ms__5 = linked_1161.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1160, arg_1163, arg_1164) }
							var tmp4 any; var root_1169 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = ms__5; var arg_1173 any; var root_1174 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = base__4; if linked_1175 == nil { arg_1173 = ifn_1176.Invoke_O__O(arg_1177) } else { arg_1173 = linked_1175.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_1174, arg_1177) }; if linked_1170 == nil { tmp4 = ifn_1171.Invoke_O_O__O(arg_1172, arg_1173) } else { tmp4 = linked_1170.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1169, arg_1172, arg_1173) }; if jrt.J2g_Truth(tmp4) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { var tmp5 any; var root_1178 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1180 lang.IFn
								if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any = ms__5; var arg_1182 any = base__4; if linked_1179 == nil { tmp5 = ifn_1180.Invoke_O_O__O(arg_1181, arg_1182) } else { tmp5 = linked_1179.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1178, arg_1181, arg_1182) }
//line :422:1
								if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_174, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil } } } } else {
//line :417:1
									if A_arbace_j2g_model_A_const_60 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_175, A_arbace_j2g_model_A_const_151, c__1, A_arbace_j2g_model_A_const_172, m__3)) } else { return nil } } } } else {
//line :415:1
										return nil } } else {
//line :414:1
											return nil } }













func A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A{}; t.Ctor_O_O(p0, p1); return t }
//line :428:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :428:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A) Invoke_O_O__O(self, s__1479000127__1 any) any { var tmp1 any = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_New_O_O_O_O(self, t.F_name, t.F_desc, s__1479000127__1); var tmp2 *jrt.Class; var fncls__1369 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_fn_class; if fncls__1369 == nil { var fncls__1369d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_fn_class = fncls__1369d; tmp2 = fncls__1369d } else { tmp2 = fncls__1369 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :428:1
func A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :428:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A) Ctor_O_O_O_O(c__iter__1479000126, c__name, c__desc, c__s__1479000127 any) { t.F_iter__1479000126 = c__iter__1479000126; t.F_name = c__name; t.F_desc = c__desc; t.F_s__1479000127 = c__s__1479000127 }
//line :428:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A) Invoke_O__O(self any) any { { var s__1479000127__1 any; var t_ any = t.F_s__1479000127; t.F_s__1479000127 = nil; s__1479000127__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1188 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = s__1479000127__1; if linked_1189 == nil { temp__1927000414__auto____2 = ifn_1190.Invoke_O__O(arg_1191) } else { temp__1927000414__auto____2 = linked_1189.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1188, arg_1191) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000127__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1192 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = s__1479000127__3; if linked_1193 == nil { tmp1 = ifn_1194.Invoke_O__O(arg_1195) } else { tmp1 = linked_1193.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1192, arg_1195) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1196 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = s__1479000127__3; if linked_1197 == nil { c__1927001037__auto____4 = ifn_1198.Invoke_O__O(arg_1199) } else { c__1927001037__auto____4 = linked_1197.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1196, arg_1199) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000129__6 any; var root_1200 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1201 == nil { b__1479000129__6 = ifn_1202.Invoke_O__O(arg_1203) } else { b__1479000129__6 = linked_1201.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1200, arg_1203) }; var tmp2 any = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_New_O_O_O_I_O(t.F_name, b__1479000129__6, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1265 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_fn_class; if fncls__1265 == nil { var fncls__1265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_fn_class = fncls__1265d; tmp3 = fncls__1265d } else { tmp3 = fncls__1265 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1266 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any; var root_1271 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = b__1479000129__6; if linked_1272 == nil { arg_1269 = ifn_1273.Invoke_O__O(arg_1274) } else { arg_1269 = linked_1272.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1271, arg_1274) }; var arg_1270 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000126); var tmp5 any; var root_1275 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = s__1479000127__3; if linked_1276 == nil { tmp5 = ifn_1277.Invoke_O__O(arg_1278) } else { tmp5 = linked_1276.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1275, arg_1278) }; arg_1270 = tmp4.Invoke_O__O(tmp5); if linked_1267 == nil { return ifn_1268.Invoke_O_O__O(arg_1269, arg_1270) } else { return linked_1267.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1266, arg_1269, arg_1270) } } else { var root_1279 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any; var root_1284 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = b__1479000129__6; if linked_1285 == nil { arg_1282 = ifn_1286.Invoke_O__O(arg_1287) } else { arg_1282 = linked_1285.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1284, arg_1287) }; var arg_1283 any; if linked_1280 == nil { return ifn_1281.Invoke_O_O__O(arg_1282, arg_1283) } else { return linked_1280.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1279, arg_1282, arg_1283) } } } else { var c__4 any; var root_1288 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = s__1479000127__3; if linked_1289 == nil { c__4 = ifn_1290.Invoke_O__O(arg_1291) } else { c__4 = linked_1289.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1288, arg_1291) }; var tmp6 any; var root_1292 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1294 lang.IFn
														if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = c__4; if linked_1293 == nil { tmp6 = ifn_1294.Invoke_O__O(arg_1295) } else { tmp6 = linked_1293.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1292, arg_1295) }
//line :428:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_1296 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1298 lang.IFn

		if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = c__4; var arg_1300 any = t.F_name; var arg_1301 any = t.F_desc; if linked_1297 == nil { m__5 = ifn_1298.Invoke_O_O_O__O(arg_1299, arg_1300, arg_1301) } else { m__5 = linked_1297.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1296, arg_1299, arg_1300, arg_1301) }
//line :428:1
		var tmp7 any
		var and__1927000168__auto____6 any = m__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1302 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1306 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = m__5; if linked_1307 == nil { arg_1305 = ifn_1308.Invoke_O__O(arg_1309) } else { arg_1305 = linked_1307.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1306, arg_1309) }; if linked_1303 == nil { and__1927000168__auto____7 = ifn_1304.Invoke_O__O(arg_1305) } else { and__1927000168__auto____7 = linked_1303.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1302, arg_1305) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1310 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any; var root_1314 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = m__5; if linked_1315 == nil { arg_1313 = ifn_1316.Invoke_O__O(arg_1317) } else { arg_1313 = linked_1315.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1314, arg_1317) }; if linked_1311 == nil { and__1927000168__auto____8 = ifn_1312.Invoke_O__O(arg_1313) } else { and__1927000168__auto____8 = linked_1311.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1310, arg_1313) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1318 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any; var root_1322 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = m__5; if linked_1323 == nil { arg_1321 = ifn_1324.Invoke_O__O(arg_1325) } else { arg_1321 = linked_1323.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1322, arg_1325) }; if linked_1319 == nil { tmp7 = ifn_1320.Invoke_O__O(arg_1321) } else { tmp7 = linked_1319.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1318, arg_1321) } } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 }
//line :428:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____6 any; var root_1326 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1328 lang.IFn



			if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any; var root_1330 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = c__4; if linked_1331 == nil { arg_1329 = ifn_1332.Invoke_O__O(arg_1333) } else { arg_1329 = linked_1331.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1330, arg_1333) }; if linked_1327 == nil { or__1927000174__auto____6 = ifn_1328.Invoke_O__O(arg_1329) } else { or__1927000174__auto____6 = linked_1327.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1326, arg_1329) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp8 = or__1927000174__auto____6 } else {
				var root_1334 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_137; var tmp10 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1337 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1338 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil); var tmp12 any; var root_1339 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = c__4; if linked_1340 == nil { tmp12 = ifn_1341.Invoke_O__O(arg_1342) } else { tmp12 = linked_1340.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1339, arg_1342) }; var tmp13 any = tmp12; var tmp14 any; var root_1343 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = t.F_name; var arg_1347 any = t.F_desc; if linked_1344 == nil { tmp14 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { tmp14 = linked_1344.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }; arg_1338 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, tmp14)).Ref(); if linked_1335 == nil { tmp8 = ifn_1336.Invoke_O_O__O(arg_1337, arg_1338) } else { tmp8 = linked_1335.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1334, arg_1337, arg_1338) } }
//line :428:1
			if jrt.J2g_Truth(tmp8) { var root_1348 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_177, A_arbace_j2g_model_A_const_151, c__4, A_arbace_j2g_model_A_const_172, m__5)); var arg_1352 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1479000126); var tmp16 any; var root_1353 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = s__1479000127__3; if linked_1354 == nil { tmp16 = ifn_1355.Invoke_O__O(arg_1356) } else { tmp16 = linked_1354.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1353, arg_1356) }; arg_1352 = tmp15.Invoke_O__O(tmp16); if linked_1349 == nil { return ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { return linked_1349.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) } } else { var tmp17 any; var root_1357 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = s__1479000127__3; if linked_1358 == nil { tmp17 = ifn_1359.Invoke_O__O(arg_1360) } else { tmp17 = linked_1358.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1357, arg_1360) }; s__1479000127__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1361 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = s__1479000127__3; if linked_1362 == nil { tmp18 = ifn_1363.Invoke_O__O(arg_1364) } else { tmp18 = linked_1362.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1361, arg_1364) }; s__1479000127__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1365 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = s__1479000127__3; if linked_1366 == nil { tmp19 = ifn_1367.Invoke_O__O(arg_1368) } else { tmp19 = linked_1366.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1365, arg_1368) }; s__1479000127__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :428:1
func A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :428:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A) Ctor_O_O_O_I_O(c__name, c__b__1479000129, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__1479000129 = c__b__1479000129; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :428:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A) Invoke_O__O(self any) any { { var i__1479000128__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000128__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000128__1)); var tmp2 any; var root_1204 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1206 lang.IFn
																if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = c__2; if linked_1205 == nil { tmp2 = ifn_1206.Invoke_O__O(arg_1207) } else { tmp2 = linked_1205.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1204, arg_1207) }
//line :428:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_1208 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1210 lang.IFn

		if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = c__2; var arg_1212 any = t.F_name; var arg_1213 any = t.F_desc; if linked_1209 == nil { m__3 = ifn_1210.Invoke_O_O_O__O(arg_1211, arg_1212, arg_1213) } else { m__3 = linked_1209.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1208, arg_1211, arg_1212, arg_1213) }
//line :428:1
		var tmp3 any
		var and__1927000168__auto____4 any = m__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1214 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any; var root_1218 any = A_arbace_j2g_model_A_const_169.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = m__3; if linked_1219 == nil { arg_1217 = ifn_1220.Invoke_O__O(arg_1221) } else { arg_1217 = linked_1219.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1218, arg_1221) }; if linked_1215 == nil { and__1927000168__auto____5 = ifn_1216.Invoke_O__O(arg_1217) } else { and__1927000168__auto____5 = linked_1215.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1214, arg_1217) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1222 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any; var root_1226 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = m__3; if linked_1227 == nil { arg_1225 = ifn_1228.Invoke_O__O(arg_1229) } else { arg_1225 = linked_1227.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1226, arg_1229) }; if linked_1223 == nil { and__1927000168__auto____6 = ifn_1224.Invoke_O__O(arg_1225) } else { and__1927000168__auto____6 = linked_1223.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1222, arg_1225) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1230 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any; var root_1234 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = m__3; if linked_1235 == nil { arg_1233 = ifn_1236.Invoke_O__O(arg_1237) } else { arg_1233 = linked_1235.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1234, arg_1237) }; if linked_1231 == nil { tmp3 = ifn_1232.Invoke_O__O(arg_1233) } else { tmp3 = linked_1231.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1230, arg_1233) } } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :428:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____4 any; var root_1238 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1240 lang.IFn



			if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any; var root_1242 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = c__2; if linked_1243 == nil { arg_1241 = ifn_1244.Invoke_O__O(arg_1245) } else { arg_1241 = linked_1243.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1242, arg_1245) }; if linked_1239 == nil { or__1927000174__auto____4 = ifn_1240.Invoke_O__O(arg_1241) } else { or__1927000174__auto____4 = linked_1239.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1238, arg_1241) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else {
				var root_1246 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_137; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1249 any = tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1250 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_31, nil); var tmp8 any; var root_1251 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = c__2; if linked_1252 == nil { tmp8 = ifn_1253.Invoke_O__O(arg_1254) } else { tmp8 = linked_1252.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1251, arg_1254) }; var tmp9 any = tmp8; var tmp10 any; var root_1255 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = t.F_name; var arg_1259 any = t.F_desc; if linked_1256 == nil { tmp10 = ifn_1257.Invoke_O_O__O(arg_1258, arg_1259) } else { tmp10 = linked_1256.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1255, arg_1258, arg_1259) }; arg_1250 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref(); if linked_1247 == nil { tmp4 = ifn_1248.Invoke_O_O__O(arg_1249, arg_1250) } else { tmp4 = linked_1247.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1246, arg_1249, arg_1250) } }
//line :428:1
			if jrt.J2g_Truth(tmp4) { var root_1260 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = t.F_b__1479000129; var arg_1264 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_177, A_arbace_j2g_model_A_const_151, c__2, A_arbace_j2g_model_A_const_172, m__3)); if linked_1261 == nil { ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { linked_1261.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) }; i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } else { i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } } else { i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } } else { i__1479000128__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000128__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_model_impl_of_fn__1479000136_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000136_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000136_A{}; t.Ctor_O(p0); return t }
//line :435:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :435:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_A) Invoke_O_O__O(self, x__1 any) any { var root_1376 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any; var tmp1 any = A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_New_O(x__1); var tmp2 *jrt.Class; var fncls__1391 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_fn_class; if fncls__1391 == nil { var fncls__1391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_fn_class = fncls__1391d; tmp2 = fncls__1391d } else { tmp2 = fncls__1391 }; arg_1379 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1380 any = t.F_cands; if linked_1377 == nil { return ifn_1378.Invoke_O_O__O(arg_1379, arg_1380) } else { return linked_1377.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1376, arg_1379, arg_1380) } }
//line :435:1
func A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A{}; t.Ctor_O(p0); return t }
//line :435:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :435:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A) Invoke_O_O__O(self, p1__1479000119_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1381 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(p1__1479000119_SHARP___1); var arg_1385 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(t.F_x); if linked_1382 == nil { and__1927000168__auto____2 = ifn_1383.Invoke_O_O__O(arg_1384, arg_1385) } else { and__1927000168__auto____2 = linked_1382.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1381, arg_1384, arg_1385) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1386 any = A_arbace_j2g_model_A_const_178.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(p1__1479000119_SHARP___1); var arg_1390 any = A_arbace_j2g_model_A_const_151.Invoke_O__O(t.F_x); if linked_1387 == nil { return ifn_1388.Invoke_O_O__O(arg_1389, arg_1390) } else { return linked_1387.(*aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1386, arg_1389, arg_1390) } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_code_class_QMARK__A_New() *A_arbace_j2g_model_code_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_class_QMARK__A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Ctor() {}
//line :438:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_179; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_180; var tmp3 any; var root_1401 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = n__0; if linked_1402 == nil { tmp3 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp3 = linked_1402.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1401, arg_1404) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)))).Ref()
}
func A_arbace_j2g_model_code_iface_QMARK__A_New() *A_arbace_j2g_model_code_iface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_iface_QMARK__A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Ctor() {}
//line :448:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1405 any = A_arbace_j2g_model_A_const_181.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = A_arbace_j2g_model_A_const_182; var arg_1409 any = n__0; if linked_1406 == nil { tmp1 = ifn_1407.Invoke_O_O__O(arg_1408, arg_1409) } else { tmp1 = linked_1406.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1405, arg_1408, arg_1409) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_nest_top_A_New() *A_arbace_j2g_model_nest_top_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_nest_top_A{}; t.Ctor(); return t }
//line :454:1
func (t *A_arbace_j2g_model_nest_top_A) Ctor() {}
//line :454:1
func (t *A_arbace_j2g_model_nest_top_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_49); if


	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1410 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = n__0; var arg_1414 any = A_arbace_j2g_model_A_const_31; var arg_1415 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1411 == nil { return ifn_1412.Invoke_O_O_O__O(arg_1413, arg_1414, arg_1415) } else { return linked_1411.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1410, arg_1413, arg_1414, arg_1415) } } }

func A_arbace_j2g_model_trivial_init_QMARK__A_New() *A_arbace_j2g_model_trivial_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :459:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Ctor() {}
//line :459:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_183; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var tmp2 any; var root_1416 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1418 lang.IFn; if





	linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any; var root_1421 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = cache__2; if linked_1422 == nil { arg_1419 = ifn_1423.Invoke_O__O(arg_1424) } else { arg_1419 = linked_1422.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1421, arg_1424) }; var arg_1420 any = n__0; if linked_1417 == nil { tmp2 = ifn_1418.Invoke_O_O__O(arg_1419, arg_1420) } else { tmp2 = linked_1417.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1416, arg_1419, arg_1420) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1425 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = cache__2; if linked_1426 == nil { tmp3 = ifn_1427.Invoke_O__O(arg_1428) } else { tmp3 = linked_1426.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1425, arg_1428) }; return lang.RT_Get_O_O__O_NoInit(tmp3, n__0) } else {
//line :465:1
			var r__3 any; var tmp4 any; var root_1429 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1431 lang.IFn


			if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any; var root_1433 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = n__0; if linked_1434 == nil { arg_1432 = ifn_1435.Invoke_O__O(arg_1436) } else { arg_1432 = linked_1434.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1433, arg_1436) }; if linked_1430 == nil { tmp4 = ifn_1431.Invoke_O__O(arg_1432) } else { tmp4 = linked_1430.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1429, arg_1432) }
//line :467:1
			if jrt.J2g_Truth(tmp4) { r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1437 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1439 lang.IFn

				if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = n__0; if linked_1438 == nil { tmp5 = ifn_1439.Invoke_O__O(arg_1440) } else { tmp5 = linked_1438.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1437, arg_1440) }
//line :467:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__3 = jrt.Boolean_TRUE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__3 any; var root_1441 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1443 lang.IFn


					if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = n__0; if linked_1442 == nil { d__3 = ifn_1443.Invoke_O__O(arg_1444) } else { d__3 = linked_1442.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1441, arg_1444) }
//line :467:1
					var st__4 any; var root_1445 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1447 lang.IFn


					if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(d__3); if linked_1446 == nil { st__4 = ifn_1447.Invoke_O__O(arg_1448) } else { st__4 = linked_1446.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1445, arg_1448) }
//line :467:1
					var and__1927000168__auto____5 any; var root_1449 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1451 lang.IFn




					if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = A_arbace_j2g_model_A_const_185.Invoke_O__O(st__4); if linked_1450 == nil { and__1927000168__auto____5 = ifn_1451.Invoke_O__O(arg_1452) } else { and__1927000168__auto____5 = linked_1450.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1449, arg_1452) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1453 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1455 lang.IFn
						if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = A_arbace_j2g_model_A_const_186.Invoke_O__O(st__4); if linked_1454 == nil { and__1927000168__auto____6 = ifn_1455.Invoke_O__O(arg_1456) } else { and__1927000168__auto____6 = linked_1454.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1453, arg_1456) }
//line :472:1
						if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1457 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1459 lang.IFn

							if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(st__4); if linked_1458 == nil { and__1927000168__auto____7 = ifn_1459.Invoke_O__O(arg_1460) } else { and__1927000168__auto____7 = linked_1458.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1457, arg_1460) }
//line :472:1
							if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1461 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1463 lang.IFn


								if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = A_arbace_j2g_model_A_const_188.Invoke_O__O(st__4); if linked_1462 == nil { and__1927000168__auto____8 = ifn_1463.Invoke_O__O(arg_1464) } else { and__1927000168__auto____8 = linked_1462.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1461, arg_1464) }
//line :472:1
								if jrt.J2g_Truth(and__1927000168__auto____8) { var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3), nil)



									if or__1927000174__auto____9 { r__3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1465 any = A_arbace_j2g_model_A_const_189.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3); if linked_1466 == nil { r__3 = ifn_1467.Invoke_O__O(arg_1468) } else { r__3 = linked_1466.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1465, arg_1468) } } } else {
//line :472:1
										r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :467:1
											r__3 = nil
										}
				}
			}






			var root_1469 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = cache__2; var arg_1473 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var arg_1474 any = n__0; var arg_1475 any = r__3; if linked_1470 == nil { ifn_1471.Invoke_O_O_O_O__O(arg_1472, arg_1473, arg_1474, arg_1475) } else { linked_1470.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1469, arg_1472, arg_1473, arg_1474, arg_1475) }
//line :465:1
			return r__3 } }

















func A_arbace_j2g_model_go_qualified_name_A_New() *A_arbace_j2g_model_go_qualified_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_qualified_name_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Ctor() {}
//line :483:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_1476 any = A_arbace_j2g_model_A_const_190.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any; var root_1480 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, A_arbace_j2g_model_pkg_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = n__0; if linked_1481 == nil { arg_1479 = ifn_1482.Invoke_O__O(arg_1483) } else { arg_1479 = linked_1481.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_1480, arg_1483) }; if linked_1477 == nil { tmp2 = ifn_1478.Invoke_O__O(arg_1479) } else { tmp2 = linked_1477.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A).Invoke_O_O__O(root_1476, arg_1479) }; var tmp3 any = tmp2; var tmp4 any; var root_1484 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = n__0; if linked_1485 == nil { tmp4 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp4 = linked_1485.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1484, arg_1487) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
}




func A_arbace_j2g_model_start_class_QMARK__A_New() *A_arbace_j2g_model_start_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_class_QMARK__A{}; t.Ctor(); return t }
//line :493:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Ctor() {}
//line :493:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_1488 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); if linked_1489 == nil { and__1927000168__auto____2 = ifn_1490.Invoke_O__O(arg_1491) } else { and__1927000168__auto____2 = linked_1489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1488, arg_1491) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1492 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = n__0; if linked_1493 == nil { and__1927000168__auto____3 = ifn_1494.Invoke_O__O(arg_1495) } else { and__1927000168__auto____3 = linked_1493.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1492, arg_1495) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1496 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); var arg_1500 any; var root_1501 any = A_arbace_j2g_model_A_const_192.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = n__0; if linked_1502 == nil { arg_1500 = ifn_1503.Invoke_O__O(arg_1504) } else { arg_1500 = linked_1502.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1501, arg_1504) }; if linked_1497 == nil { and__1927000168__auto____4 = ifn_1498.Invoke_O_O__O(arg_1499, arg_1500) } else { and__1927000168__auto____4 = linked_1497.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1496, arg_1499, arg_1500) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1505 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any; var root_1509 any = A_arbace_j2g_model_A_const_189.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = n__0; if linked_1510 == nil { arg_1508 = ifn_1511.Invoke_O__O(arg_1512) } else { arg_1508 = linked_1510.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1509, arg_1512) }; if linked_1506 == nil { tmp1 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp1 = linked_1506.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1505, arg_1508) } } else {
//line :497:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_j2g_model_start_classes_A_New() *A_arbace_j2g_model_start_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_j2g_model_start_classes_A) Ctor() {}
//line :500:1
func (t *A_arbace_j2g_model_start_classes_A) Invoke_O__O(self any) any { var by_go__1 any; var root_1513 any = A_arbace_j2g_model_A_const_193.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1515 lang.IFn; if


	linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1517 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A_New(); var tmp2 *jrt.Class; var fncls__1596 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A_fn_class; if fncls__1596 == nil { var fncls__1596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A_fn_class = fncls__1596d; tmp2 = fncls__1596d } else { tmp2 = fncls__1596 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp4 any; var root_1597 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, A_arbace_j2g_model_T_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; if linked_1598 == nil { tmp4 = ifn_1599.Invoke__O() } else { tmp4 = linked_1598.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_1597) }; arg_1517 = tmp3.Invoke_O__O(tmp4); if linked_1514 == nil { by_go__1 = ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { by_go__1 = linked_1514.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) }; var root_1600 any =
	A_arbace_j2g_model_A_const_195.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1602 lang.IFn; if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any = by_go__1; var arg_1604 any = A_arbace_j2g_model_A_const_196.GetRawRoot__O(); if linked_1601 == nil { return ifn_1602.Invoke_O_O__O(arg_1603, arg_1604) } else { return linked_1601.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1600, arg_1603, arg_1604) } }
//line :503:1
func A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A_New() *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A{}; t.Ctor(); return t }
//line :503:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A) Ctor() {}
//line :503:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A) Invoke_O_O__O(self, s__1479000148__1 any) any { var tmp1 any = A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A_New_O_O(self, s__1479000148__1); var tmp2 *jrt.Class; var fncls__1595 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A_fn_class; if fncls__1595 == nil { var fncls__1595d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A_fn_class = fncls__1595d; tmp2 = fncls__1595d } else { tmp2 = fncls__1595 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :503:1
func A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A{}; t.Ctor_O_O(p0, p1); return t }
//line :503:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A) Ctor_O_O(c__iter__1479000147, c__s__1479000148 any) { t.F_iter__1479000147 = c__iter__1479000147; t.F_s__1479000148 = c__s__1479000148 }
//line :503:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A) Invoke_O__O(self any) any { { var s__1479000148__1 any; var t_ any = t.F_s__1479000148; t.F_s__1479000148 = nil; s__1479000148__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1518 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = s__1479000148__1; if linked_1519 == nil { temp__1927000414__auto____2 = ifn_1520.Invoke_O__O(arg_1521) } else { temp__1927000414__auto____2 = linked_1519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1518, arg_1521) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000148__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1522 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = s__1479000148__3; if linked_1523 == nil { tmp1 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp1 = linked_1523.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1522, arg_1525) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1526 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = s__1479000148__3; if linked_1527 == nil { c__1927001037__auto____4 = ifn_1528.Invoke_O__O(arg_1529) } else { c__1927001037__auto____4 = linked_1527.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1526, arg_1529) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000150__6 any; var root_1530 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1531 == nil { b__1479000150__6 = ifn_1532.Invoke_O__O(arg_1533) } else { b__1479000150__6 = linked_1531.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1530, arg_1533) }; var tmp2 any = A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A_New_I_O_O(size__1927001038__auto____5, b__1479000150__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1547 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A_fn_class; if fncls__1547 == nil { var fncls__1547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A_fn_class = fncls__1547d; tmp3 = fncls__1547d } else { tmp3 = fncls__1547 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1548 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any; var root_1553 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = b__1479000150__6; if linked_1554 == nil { arg_1551 = ifn_1555.Invoke_O__O(arg_1556) } else { arg_1551 = linked_1554.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1553, arg_1556) }; var arg_1552 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000147); var tmp5 any; var root_1557 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = s__1479000148__3; if linked_1558 == nil { tmp5 = ifn_1559.Invoke_O__O(arg_1560) } else { tmp5 = linked_1558.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1557, arg_1560) }; arg_1552 = tmp4.Invoke_O__O(tmp5); if linked_1549 == nil { return ifn_1550.Invoke_O_O__O(arg_1551, arg_1552) } else { return linked_1549.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1548, arg_1551, arg_1552) } } else { var root_1561 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any; var root_1566 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = b__1479000150__6; if linked_1567 == nil { arg_1564 = ifn_1568.Invoke_O__O(arg_1569) } else { arg_1564 = linked_1567.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1566, arg_1569) }; var arg_1565 any; if linked_1562 == nil { return ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { return linked_1562.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) } } } else { var n__4 any; var root_1570 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = s__1479000148__3; if linked_1571 == nil { n__4 = ifn_1572.Invoke_O__O(arg_1573) } else { n__4 = linked_1571.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1570, arg_1573) }; var tmp6 any; var root_1574 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = n__4; if linked_1575 == nil { tmp6 = ifn_1576.Invoke_O__O(arg_1577) } else { tmp6 = linked_1575.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1574, arg_1577) }; if jrt.J2g_Truth(tmp6) { var root_1578 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any; var tmp7 any; var root_1583 any = A_arbace_j2g_model_A_const_192.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = n__4; if linked_1584 == nil { tmp7 = ifn_1585.Invoke_O__O(arg_1586) } else { tmp7 = linked_1584.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1583, arg_1586) }; arg_1581 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, n__4); var arg_1582 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000147); var tmp9 any; var root_1587 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = s__1479000148__3; if linked_1588 == nil { tmp9 = ifn_1589.Invoke_O__O(arg_1590) } else { tmp9 = linked_1588.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1587, arg_1590) }; arg_1582 = tmp8.Invoke_O__O(tmp9); if linked_1579 == nil { return ifn_1580.Invoke_O_O__O(arg_1581, arg_1582) } else { return linked_1579.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1578, arg_1581, arg_1582) } } else { var tmp10 any; var root_1591 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = s__1479000148__3; if linked_1592 == nil { tmp10 = ifn_1593.Invoke_O__O(arg_1594) } else { tmp10 = linked_1592.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1591, arg_1594) }; s__1479000148__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :503:1
func A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :503:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1479000150, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1479000150 = c__b__1479000150; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :503:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A) Invoke_O__O(self any) any { { var i__1479000149__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000149__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000149__1)); var tmp2 any; var root_1534 any = A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = n__2; if linked_1535 == nil { tmp2 = ifn_1536.Invoke_O__O(arg_1537) } else { tmp2 = linked_1535.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1534, arg_1537) }; if jrt.J2g_Truth(tmp2) { var root_1538 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = t.F_b__1479000150; var arg_1542 any; var tmp3 any; var root_1543 any = A_arbace_j2g_model_A_const_192.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = n__2; if linked_1544 == nil { tmp3 = ifn_1545.Invoke_O__O(arg_1546) } else { tmp3 = linked_1544.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1543, arg_1546) }; arg_1542 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, n__2); if linked_1539 == nil { ifn_1540.Invoke_O_O__O(arg_1541, arg_1542) } else { linked_1539.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1538, arg_1541, arg_1542) }; i__1479000149__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000149__1); continue L1 } else { i__1479000149__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000149__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_model_top_class_A_New() *A_arbace_j2g_model_top_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_top_class_A{}; t.Ctor(); return t }
//line :511:1
func (t *A_arbace_j2g_model_top_class_A) Ctor() {}
//line :511:1
func (t *A_arbace_j2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_49); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1605 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = n__0; var arg_1609 any = A_arbace_j2g_model_A_const_31; var arg_1610 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1606 == nil { return ifn_1607.Invoke_O_O_O__O(arg_1608, arg_1609, arg_1610) } else { return linked_1606.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1605, arg_1608, arg_1609, arg_1610) } } }

func A_arbace_j2g_model_pure_ctor_QMARK__A_New() *A_arbace_j2g_model_pure_ctor_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :513:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any; var root_1611 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1613 lang.IFn; if




	linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = c__1; if linked_1612 == nil { d__5 = ifn_1613.Invoke_O__O(arg_1614) } else { d__5 = linked_1612.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1611, arg_1614) }; var ab__6 any; if
	jrt.J2g_Truth(d__5) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_197; var tmp2 any; var root_1615 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(d__5); if linked_1616 == nil { tmp2 = ifn_1617.Invoke_O__O(arg_1618) } else { tmp2 = linked_1616.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1615, arg_1618) }; ab__6 = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), lang.Tuple_Create_O_O__IPersistentVector(Lit_54, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_1619 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = c__1; if linked_1620 == nil { and__1927000168__auto____9 = ifn_1621.Invoke_O__O(arg_1622) } else { and__1927000168__auto____9 = linked_1620.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1619, arg_1622) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp3 any; var root_1623 any = A_arbace_j2g_model_A_const_198.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1625 lang.IFn
		if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = c__1; if linked_1624 == nil { tmp3 = ifn_1625.Invoke_O__O(arg_1626) } else { tmp3 = linked_1624.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1623, arg_1626) }; var tmp4 any = tmp3; var tmp5 any; var root_1627 any = A_arbace_j2g_model_A_const_198.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any = n__0; if linked_1628 == nil { tmp5 = ifn_1629.Invoke_O__O(arg_1630) } else { tmp5 = linked_1628.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1627, arg_1630) }; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)
//line :520:1
		if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_1631 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1633 lang.IFn

			if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any; var root_1635 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = seen__3; var arg_1639 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)); if linked_1636 == nil { arg_1634 = ifn_1637.Invoke_O_O__O(arg_1638, arg_1639) } else { arg_1634 = linked_1636.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1635, arg_1638, arg_1639) }; if linked_1632 == nil { and__1927000168__auto____11 = ifn_1633.Invoke_O__O(arg_1634) } else { and__1927000168__auto____11 = linked_1632.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1631, arg_1634) }
//line :520:1
			if jrt.J2g_Truth(and__1927000168__auto____11) { var seen__12 any; var root_1640 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1642 lang.IFn


				if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = seen__3; var arg_1644 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_115.Invoke_O__O(m__2)); if linked_1641 == nil { seen__12 = ifn_1642.Invoke_O_O__O(arg_1643, arg_1644) } else { seen__12 = linked_1641.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1640, arg_1643, arg_1644) }
//line :520:1
				var call__13 any = A_arbace_j2g_model_A_const_199.Invoke_O__O(ab__6); var sup__14 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__5); var and__1927000168__auto____15 any; var root_1645 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1647 lang.IFn





				if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = A_arbace_j2g_model_A_const_200.Invoke_O__O(ab__6); if linked_1646 == nil { and__1927000168__auto____15 = ifn_1647.Invoke_O__O(arg_1648) } else { and__1927000168__auto____15 = linked_1646.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1645, arg_1648) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1649 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1651 lang.IFn
					if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = A_arbace_j2g_model_A_const_201.Invoke_O__O(ab__6); if linked_1650 == nil { and__1927000168__auto____16 = ifn_1651.Invoke_O__O(arg_1652) } else { and__1927000168__auto____16 = linked_1650.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1649, arg_1652) }
//line :526:1
					if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z_NoInit(call__13, nil)

						if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var root_1653 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1655 lang.IFn
							if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any; var tmp6 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A_New_O_O(n__0, seen__12); var tmp7 *jrt.Class; var fncls__1664 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A_fn_class; if fncls__1664 == nil { var fncls__1664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A_fn_class = fncls__1664d; tmp7 = fncls__1664d } else { tmp7 = fncls__1664 }; arg_1656 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1657 any = A_arbace_j2g_model_A_const_203.Invoke_O__O(call__13); if linked_1654 == nil { and__1927000168__auto____18 = ifn_1655.Invoke_O_O__O(arg_1656, arg_1657) } else { and__1927000168__auto____18 = linked_1654.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1653, arg_1656, arg_1657) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_175.Invoke_O__O(call__13), nil)
								if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19).Ref() } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_204); var or__1927000174__auto____20 any = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_175.Invoke_O__O(call__13)); if jrt.J2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
									var root_1665 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = n__0; var arg_1669 any = A_arbace_j2g_model_A_const_175.Invoke_O__O(call__13); var arg_1670 any = A_arbace_j2g_model_A_const_206.Invoke_O__O(call__13); var arg_1671 any = seen__12; if linked_1666 == nil { and__1927000168__auto____17 = ifn_1667.Invoke_O_O_O_O__O(arg_1668, arg_1669, arg_1670, arg_1671) } else { and__1927000168__auto____17 = linked_1666.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1665, arg_1668, arg_1669, arg_1670, arg_1671) } } } } else {
//line :529:1
										and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :526:1
						if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any; var root_1672 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1674 lang.IFn





							if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = call__13; if linked_1673 == nil { or__1927000174__auto____18 = ifn_1674.Invoke_O__O(arg_1675) } else { or__1927000174__auto____18 = linked_1673.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1672, arg_1675) }; if jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z_NoInit(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sup__14, Lit_30)).Ref() } }
//line :526:1
							if jrt.J2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var root_1676 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1678 lang.IFn






								if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any; var tmp9 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A_New_O_O(n__0, seen__12); var tmp10 *jrt.Class; var fncls__1687 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A_fn_class; if fncls__1687 == nil { var fncls__1687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A_fn_class = fncls__1687d; tmp10 = fncls__1687d } else { tmp10 = fncls__1687 }; arg_1679 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1680 any; var tmp11 *lang.Keyword = A_arbace_j2g_model_A_const_207; var tmp12 any; var root_1688 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(d__5); if linked_1689 == nil { tmp12 = ifn_1690.Invoke_O__O(arg_1691) } else { tmp12 = linked_1689.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1688, arg_1691) }; arg_1680 = tmp11.Invoke_O__O(tmp12); if linked_1677 == nil { and__1927000168__auto____19 = ifn_1678.Invoke_O_O__O(arg_1679, arg_1680) } else { and__1927000168__auto____19 = linked_1677.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1676, arg_1679, arg_1680) }
//line :526:1
								if jrt.J2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_208.Invoke_O__O(ab__6), nil)







									if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20_2).Ref() } else { var root_1692 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = n__0; var arg_1696 any = A_arbace_j2g_model_A_const_208.Invoke_O__O(ab__6); var arg_1697 any = seen__12; if linked_1693 == nil { return ifn_1694.Invoke_O_O_O__O(arg_1695, arg_1696, arg_1697) } else { return linked_1693.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1692, arg_1695, arg_1696, arg_1697) } } } else {
//line :526:1
										return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :520:1
											return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A{}; t.Ctor_O_O(p0, p1); return t }
//line :529:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :529:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A) Invoke_O_O__O(self, p1__1479000159_SHARP___1 any) any { var root_1658 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = t.F_n; var arg_1662 any = p1__1479000159_SHARP___1; var arg_1663 any = t.F_seen; if linked_1659 == nil { return ifn_1660.Invoke_O_O_O__O(arg_1661, arg_1662, arg_1663) } else { return linked_1659.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1658, arg_1661, arg_1662, arg_1663) } }



func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A{}; t.Ctor_O_O(p0, p1); return t }
//line :533:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :533:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A) Invoke_O_O__O(self, p1__1479000160_SHARP___1 any) any { var root_1681 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = t.F_n; var arg_1685 any = p1__1479000160_SHARP___1; var arg_1686 any = t.F_seen; if linked_1682 == nil { return ifn_1683.Invoke_O_O_O__O(arg_1684, arg_1685, arg_1686) } else { return linked_1682.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1681, arg_1684, arg_1685, arg_1686) } }


func A_arbace_j2g_model_pure_node_QMARK__A_New() *A_arbace_j2g_model_pure_node_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Ctor() {}
//line :536:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1479000172__4_ any = A_arbace_j2g_model_A_const_209.Invoke_O__O(node__1); switch



	lang.Util_Hash_O__I_NoInit(G__1479000172__4_) >> 3 & 63 { case 1: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_210) { var and__1927000168__auto____5 any; var root_1699 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1701 lang.IFn


















		if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = A_arbace_j2g_model_A_const_211.Invoke_O__O(node__1); if linked_1700 == nil { and__1927000168__auto____5 = ifn_1701.Invoke_O__O(arg_1702) } else { and__1927000168__auto____5 = linked_1700.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1699, arg_1702) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1703 any = A_arbace_j2g_model_A_const_103.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = A_arbace_j2g_model_A_const_212.Invoke_O__O(node__1); if linked_1704 == nil { and__1927000168__auto____6 = ifn_1705.Invoke_O__O(arg_1706) } else { and__1927000168__auto____6 = linked_1704.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1703, arg_1706) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1707 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = n__0; var arg_1711 any = A_arbace_j2g_model_A_const_213.Invoke_O__O(node__1); var arg_1712 any = seen__2; if linked_1708 == nil { return ifn_1709.Invoke_O_O_O__O(arg_1710, arg_1711, arg_1712) } else { return linked_1708.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1707, arg_1710, arg_1711, arg_1712) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :540:1
	case 11: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_214) { var tmp1 any = A_arbace_j2g_model_A_const_215; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_209; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_216.Invoke_O__O(node__1)))







		if and__1927000168__auto____5_2 { var and__1927000168__auto____6_2 any; var root_1713 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_217; var arg_1716 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_216.Invoke_O__O(node__1)); if linked_1714 == nil { and__1927000168__auto____6_2 = ifn_1715.Invoke_O__O(arg_1716) } else { and__1927000168__auto____6_2 = linked_1714.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1713, arg_1716) }; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var root_1717 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = n__0; var arg_1721 any = A_arbace_j2g_model_A_const_218.Invoke_O__O(node__1); var arg_1722 any = seen__2; if linked_1718 == nil { return ifn_1719.Invoke_O_O_O__O(arg_1720, arg_1721, arg_1722) } else { return linked_1718.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1717, arg_1720, arg_1721, arg_1722) } } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() } }
//line :540:1
	case 13: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_219) { var tmp4 any = A_arbace_j2g_model_A_const_220; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_j2g_model_A_const_170.Invoke_O__O(node__1))













		if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_57, A_arbace_j2g_model_A_const_151.Invoke_O__O(node__1))
			if and__1927000168__auto____6_4 { or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_58, A_arbace_j2g_model_A_const_125.Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, A_arbace_j2g_model_A_const_151.Invoke_O__O(node__1))

				if and__1927000168__auto____7 { and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_59, A_arbace_j2g_model_A_const_125.Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :554:1
			if and__1927000168__auto____6_3 {



				var root_1723 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any; var tmp5 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A_New_O_O(n__0, seen__2); var tmp6 *jrt.Class; var fncls__1734 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A_fn_class; if fncls__1734 == nil { var fncls__1734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A_fn_class = fncls__1734d; tmp6 = fncls__1734d } else { tmp6 = fncls__1734 }; arg_1726 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1727 any = A_arbace_j2g_model_A_const_203.Invoke_O__O(node__1); if linked_1724 == nil { return ifn_1725.Invoke_O_O__O(arg_1726, arg_1727) } else { return linked_1724.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1723, arg_1726, arg_1727) } } else {
//line :554:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_3).Ref() } }
//line :540:1
	case 14: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_221) { var and__1927000168__auto____5_4 bool; var tmp7 any; var tmp8 *lang.Keyword = A_arbace_j2g_model_A_const_222; var or__1927000174__auto____5 any = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_223.Invoke_O__O(node__1))






		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else { var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_151; tmp7 = tmp9.Invoke_O__O(A_arbace_j2g_model_A_const_223.Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp7); if and__1927000168__auto____5_4 { var root_1735 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = n__0; var arg_1739 any = A_arbace_j2g_model_A_const_218.Invoke_O__O(node__1); var arg_1740 any = seen__2; if linked_1736 == nil { return ifn_1737.Invoke_O_O_O__O(arg_1738, arg_1739, arg_1740) } else { return linked_1736.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1735, arg_1738, arg_1739, arg_1740) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_4).Ref() } }
//line :540:1
	case 15: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_215) { return jrt.Boolean_TRUE.Ref() }; case 19: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_224) { var and__1927000168__auto____5_5 any; var root_1741 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1741, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1743 lang.IFn


		if linked_1742 == nil { ifn_1743 = lang.IFn_Cast(root_1741) } else { ifn_1743 = nil }; var arg_1744 any; var tmp10 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A_New_O_O(n__0, seen__2); var tmp11 *jrt.Class; var fncls__1752 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A_fn_class; if fncls__1752 == nil { var fncls__1752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A_fn_class = fncls__1752d; tmp11 = fncls__1752d } else { tmp11 = fncls__1752 }; arg_1744 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1745 any = A_arbace_j2g_model_A_const_225.Invoke_O__O(node__1); if linked_1742 == nil { and__1927000168__auto____5_5 = ifn_1743.Invoke_O_O__O(arg_1744, arg_1745) } else { and__1927000168__auto____5_5 = linked_1742.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1741, arg_1744, arg_1745) }; if jrt.J2g_Truth(and__1927000168__auto____5_5) { var root_1753 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = n__0; var arg_1757 any = A_arbace_j2g_model_A_const_208.Invoke_O__O(node__1); var arg_1758 any = seen__2; if linked_1754 == nil { return ifn_1755.Invoke_O_O_O__O(arg_1756, arg_1757, arg_1758) } else { return linked_1754.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1753, arg_1756, arg_1757, arg_1758) } } else { return and__1927000168__auto____5_5 } }
//line :540:1
	case 21: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_226) {





		var tmp12 any; var tmp13 *lang.Keyword = A_arbace_j2g_model_A_const_222; var or__1927000174__auto____5_2 any = tmp13.Invoke_O__O(A_arbace_j2g_model_A_const_223.Invoke_O__O(node__1)); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp12 = or__1927000174__auto____5_2 } else { var tmp14 *lang.Keyword = A_arbace_j2g_model_A_const_151; tmp12 = tmp14.Invoke_O__O(A_arbace_j2g_model_A_const_223.Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp12)).Ref() }
//line :540:1
	case 25: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_227) { var and__1927000168__auto____5_6 any; var root_1759 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1761 lang.IFn

		if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any; var tmp15 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A_New_O_O(n__0, seen__2); var tmp16 *jrt.Class; var fncls__1770 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A_fn_class; if fncls__1770 == nil { var fncls__1770d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A_fn_class = fncls__1770d; tmp16 = fncls__1770d } else { tmp16 = fncls__1770 }; arg_1762 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_1763 any = A_arbace_j2g_model_A_const_228.Invoke_O__O(node__1); if linked_1760 == nil { and__1927000168__auto____5_6 = ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { and__1927000168__auto____5_6 = linked_1760.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) }; if jrt.J2g_Truth(and__1927000168__auto____5_6) { var root_1771 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = n__0; var arg_1775 any = A_arbace_j2g_model_A_const_229.Invoke_O__O(node__1); var arg_1776 any = seen__2; if linked_1772 == nil { return ifn_1773.Invoke_O_O_O__O(arg_1774, arg_1775, arg_1776) } else { return linked_1772.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1771, arg_1774, arg_1775, arg_1776) } } else { return and__1927000168__auto____5_6 } }
//line :540:1
	case 29: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_230) { return jrt.Boolean_TRUE.Ref() }; case 30: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_231) { return jrt.Boolean_TRUE.Ref() }; case 34: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_232) {




		var root_1777 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any; var tmp17 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A_New(); var tmp18 *jrt.Class; var fncls__1790 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A_fn_class; if fncls__1790 == nil { var fncls__1790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A_fn_class = fncls__1790d; tmp18 = fncls__1790d } else { tmp18 = fncls__1790 }; arg_1780 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1781 any = A_arbace_j2g_model_A_const_234.Invoke_O__O(node__1); if linked_1778 == nil { return ifn_1779.Invoke_O_O__O(arg_1780, arg_1781) } else { return linked_1778.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1777, arg_1780, arg_1781) } }
//line :540:1
	case 39: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_235) { var and__1927000168__auto____5_7 any; var root_1791 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1793 lang.IFn








		if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any; var tmp19 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A_New_O_O(n__0, seen__2); var tmp20 *jrt.Class; var fncls__1802 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A_fn_class; if fncls__1802 == nil { var fncls__1802d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A_fn_class = fncls__1802d; tmp20 = fncls__1802d } else { tmp20 = fncls__1802 }; arg_1794 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_1795 any = A_arbace_j2g_model_A_const_203.Invoke_O__O(node__1); if linked_1792 == nil { and__1927000168__auto____5_7 = ifn_1793.Invoke_O_O__O(arg_1794, arg_1795) } else { and__1927000168__auto____5_7 = linked_1792.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1791, arg_1794, arg_1795) }; if jrt.J2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_236.Invoke_O__O(node__1), nil); if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_30, A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1))

			if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1), n__0)
				if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_1803 any = A_arbace_j2g_model_A_const_189.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1); if linked_1804 == nil { and__1927000168__auto____8 = ifn_1805.Invoke_O__O(arg_1806) } else { and__1927000168__auto____8 = linked_1804.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1803, arg_1806) } }; if jrt.J2g_Truth(and__1927000168__auto____8) {
					var root_1807 any = A_arbace_j2g_model_A_const_205.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = n__0; var arg_1811 any = A_arbace_j2g_model_A_const_175.Invoke_O__O(node__1); var arg_1812 any = A_arbace_j2g_model_A_const_206.Invoke_O__O(node__1); var arg_1813 any = seen__2; if linked_1808 == nil { return ifn_1809.Invoke_O_O_O_O__O(arg_1810, arg_1811, arg_1812, arg_1813) } else { return linked_1808.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1807, arg_1810, arg_1811, arg_1812, arg_1813) } } else {
//line :552:1
						return and__1927000168__auto____8 } } } else {
//line :549:1
							return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :540:1
	case 43: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_237) { var and__1927000168__auto____5_8 any; var root_1814 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1816 lang.IFn



















		if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_238); var arg_1817 any = tmp21.Invoke_O__O(A_arbace_j2g_model_A_const_239.Invoke_O__O(node__1)); if linked_1815 == nil { and__1927000168__auto____5_8 = ifn_1816.Invoke_O__O(arg_1817) } else { and__1927000168__auto____5_8 = linked_1815.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1814, arg_1817) }; if jrt.J2g_Truth(and__1927000168__auto____5_8) { var and__1927000168__auto____6_6 any; var root_1818 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = A_arbace_j2g_model_A_const_240; var arg_1822 any = A_arbace_j2g_model_A_const_241.Invoke_O__O(node__1); if linked_1819 == nil { and__1927000168__auto____6_6 = ifn_1820.Invoke_O_O__O(arg_1821, arg_1822) } else { and__1927000168__auto____6_6 = linked_1819.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1818, arg_1821, arg_1822) }; if jrt.J2g_Truth(and__1927000168__auto____6_6) { var root_1823 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any; var tmp22 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A_New_O_O(n__0, seen__2); var tmp23 *jrt.Class; var fncls__1834 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A_fn_class; if fncls__1834 == nil { var fncls__1834d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A_fn_class = fncls__1834d; tmp23 = fncls__1834d } else { tmp23 = fncls__1834 }; arg_1826 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_1827 any = A_arbace_j2g_model_A_const_203.Invoke_O__O(node__1); if linked_1824 == nil { return ifn_1825.Invoke_O_O__O(arg_1826, arg_1827) } else { return linked_1824.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1823, arg_1826, arg_1827) } } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :540:1
	case 44: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_242) { return jrt.Boolean_TRUE.Ref() }; case 46: if any(G__1479000172__4_) == any(A_arbace_j2g_model_A_const_243) {



		var root_1835 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1835, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1837 lang.IFn; if linked_1836 == nil { ifn_1837 = lang.IFn_Cast(root_1835) } else { ifn_1837 = nil }; var arg_1838 any; var tmp24 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A_New_O_O(n__0, seen__2); var tmp25 *jrt.Class; var fncls__1846 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A_fn_class; if fncls__1846 == nil { var fncls__1846d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A_fn_class = fncls__1846d; tmp25 = fncls__1846d } else { tmp25 = fncls__1846 }; arg_1838 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var arg_1839 any = A_arbace_j2g_model_A_const_244.Invoke_O__O(node__1); if linked_1836 == nil { return ifn_1837.Invoke_O_O__O(arg_1838, arg_1839) } else { return linked_1836.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1835, arg_1838, arg_1839) } }
//line :540:1
	default:}; return jrt.Boolean_FALSE.Ref() }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A{}; t.Ctor_O_O(p0, p1); return t }
//line :542:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :542:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A) Invoke_O_O__O(self, p1__1479000166_SHARP___1 any) any { var root_1764 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = t.F_n; var arg_1768 any = p1__1479000166_SHARP___1; var arg_1769 any = t.F_seen; if linked_1765 == nil { return ifn_1766.Invoke_O_O_O__O(arg_1767, arg_1768, arg_1769) } else { return linked_1765.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1764, arg_1767, arg_1768, arg_1769) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :543:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :543:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A) Invoke_O_O__O(self, p__1479000175__1 any) any { var vec__1479000177__2 any = p__1479000175__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000177__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000177__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1746 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1748 lang.IFn; _ = ___3; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = t.F_n; var arg_1750 any = init__4; var arg_1751 any = t.F_seen; if linked_1747 == nil { return ifn_1748.Invoke_O_O_O__O(arg_1749, arg_1750, arg_1751) } else { return linked_1747.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1746, arg_1749, arg_1750, arg_1751) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A{}; t.Ctor_O_O(p0, p1); return t }
//line :544:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :544:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A) Invoke_O_O__O(self, p1__1479000167_SHARP___1 any) any { var root_1840 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = t.F_n; var arg_1844 any = p1__1479000167_SHARP___1; var arg_1845 any = t.F_seen; if linked_1841 == nil { return ifn_1842.Invoke_O_O_O__O(arg_1843, arg_1844, arg_1845) } else { return linked_1841.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1840, arg_1843, arg_1844, arg_1845) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A_New() *A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A) Ctor() {}
//line :545:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A) Invoke_O_O__O(self, p1__1479000168_SHARP___1 any) any { var tmp1 any = A_arbace_j2g_model_A_const_230; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_model_A_const_209.Invoke_O__O(p1__1479000168_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_1782 any = A_arbace_j2g_model_A_const_233.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = A_arbace_j2g_model_A_const_218.Invoke_O__O(p1__1479000168_SHARP___1); if linked_1783 == nil { and__1927000168__auto____3 = ifn_1784.Invoke_O__O(arg_1785) } else { and__1927000168__auto____3 = linked_1783.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_1782, arg_1785) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1786 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1788 lang.IFn; if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_j2g_model_A_const_218.Invoke_O__O(p1__1479000168_SHARP___1)))).Ref(); if linked_1787 == nil { return ifn_1788.Invoke_O__O(arg_1789) } else { return linked_1787.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1786, arg_1789) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A{}; t.Ctor_O_O(p0, p1); return t }
//line :549:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :549:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A) Invoke_O_O__O(self, p1__1479000169_SHARP___1 any) any { var root_1796 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = t.F_n; var arg_1800 any = p1__1479000169_SHARP___1; var arg_1801 any = t.F_seen; if linked_1797 == nil { return ifn_1798.Invoke_O_O_O__O(arg_1799, arg_1800, arg_1801) } else { return linked_1797.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1796, arg_1799, arg_1800, arg_1801) } }








func A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A{}; t.Ctor_O_O(p0, p1); return t }
//line :558:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :558:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A) Invoke_O_O__O(self, p1__1479000170_SHARP___1 any) any { var root_1728 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = t.F_n; var arg_1732 any = p1__1479000170_SHARP___1; var arg_1733 any = t.F_seen; if linked_1729 == nil { return ifn_1730.Invoke_O_O_O__O(arg_1731, arg_1732, arg_1733) } else { return linked_1729.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1728, arg_1731, arg_1732, arg_1733) } }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A{}; t.Ctor_O_O(p0, p1); return t }
//line :560:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :560:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A) Invoke_O_O__O(self, p1__1479000171_SHARP___1 any) any { var root_1828 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = t.F_n; var arg_1832 any = p1__1479000171_SHARP___1; var arg_1833 any = t.F_seen; if linked_1829 == nil { return ifn_1830.Invoke_O_O_O__O(arg_1831, arg_1832, arg_1833) } else { return linked_1829.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1828, arg_1831, arg_1832, arg_1833) } }


func A_arbace_j2g_model_benign_init_QMARK__A_New() *A_arbace_j2g_model_benign_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :563:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Ctor() {}
//line :563:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_183; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_246, n__0); var tmp2 any; var root_1847 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1849 lang.IFn; if








	linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any; var root_1852 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = cache__2; if linked_1853 == nil { arg_1850 = ifn_1854.Invoke_O__O(arg_1855) } else { arg_1850 = linked_1853.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1852, arg_1855) }; var arg_1851 any = k__3; if linked_1848 == nil { tmp2 = ifn_1849.Invoke_O_O__O(arg_1850, arg_1851) } else { tmp2 = linked_1848.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1847, arg_1850, arg_1851) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1856 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = cache__2; if linked_1857 == nil { tmp3 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp3 = linked_1857.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1856, arg_1859) }; return lang.RT_Get_O_O__O_NoInit(tmp3, k__3) } else {
//line :572:1
			var r__4 any; var tmp4 any; var root_1860 any = A_arbace_j2g_model_A_const_189.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1862 lang.IFn


			if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = n__0; if linked_1861 == nil { tmp4 = ifn_1862.Invoke_O__O(arg_1863) } else { tmp4 = linked_1861.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1860, arg_1863) }
//line :574:1
			if jrt.J2g_Truth(tmp4) { r__4 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1864 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1866 lang.IFn

				if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = n__0; if linked_1865 == nil { tmp5 = ifn_1866.Invoke_O__O(arg_1867) } else { tmp5 = linked_1865.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1864, arg_1867) }
//line :574:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__4 = jrt.Boolean_FALSE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__4 any; var root_1868 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1868, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1870 lang.IFn


					if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any = n__0; if linked_1869 == nil { d__4 = ifn_1870.Invoke_O__O(arg_1871) } else { d__4 = linked_1869.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1868, arg_1871) }
//line :574:1
					var st__5 any; var root_1872 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1874 lang.IFn


					if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(d__4); if linked_1873 == nil { st__5 = ifn_1874.Invoke_O__O(arg_1875) } else { st__5 = linked_1873.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1872, arg_1875) }
//line :574:1
					var and__1927000168__auto____6 any; var root_1876 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1878 lang.IFn




					if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = A_arbace_j2g_model_A_const_186.Invoke_O__O(st__5); if linked_1877 == nil { and__1927000168__auto____6 = ifn_1878.Invoke_O__O(arg_1879) } else { and__1927000168__auto____6 = linked_1877.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1876, arg_1879) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1880 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1882 lang.IFn
						if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(st__5); if linked_1881 == nil { and__1927000168__auto____7 = ifn_1882.Invoke_O__O(arg_1883) } else { and__1927000168__auto____7 = linked_1881.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1880, arg_1883) }
//line :579:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1884 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1886 lang.IFn

							if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any = A_arbace_j2g_model_A_const_188.Invoke_O__O(st__5); if linked_1885 == nil { and__1927000168__auto____8 = ifn_1886.Invoke_O__O(arg_1887) } else { and__1927000168__auto____8 = linked_1885.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1884, arg_1887) }
//line :579:1
							if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4), nil)


								if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1888 any = A_arbace_j2g_model_A_const_245.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, A_arbace_j2g_model_benign_init_QMARK__A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4); if linked_1889 == nil { and__1927000168__auto____9 = ifn_1890.Invoke_O__O(arg_1891) } else { and__1927000168__auto____9 = linked_1889.(*A_arbace_j2g_model_benign_init_QMARK__A).Invoke_O_O__O(root_1888, arg_1891) } }
//line :579:1
								if jrt.J2g_Truth(and__1927000168__auto____9) {



									var root_1892 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any; var tmp6 any = A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A_New_O(n__0); var tmp7 *jrt.Class; var fncls__1903 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A_fn_class; if fncls__1903 == nil { var fncls__1903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A_fn_class = fncls__1903d; tmp7 = fncls__1903d } else { tmp7 = fncls__1903 }; arg_1895 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1896 any = A_arbace_j2g_model_A_const_185.Invoke_O__O(st__5); if linked_1893 == nil { r__4 = ifn_1894.Invoke_O_O__O(arg_1895, arg_1896) } else { r__4 = linked_1893.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1892, arg_1895, arg_1896) } } else {
//line :579:1
										r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :574:1
											r__4 = nil
										}
				}
			}






			var root_1904 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = cache__2; var arg_1908 any = A_arbace_j2g_model_A_const_150.GetRawRoot__O(); var arg_1909 any = k__3; var arg_1910 any = r__4; if linked_1905 == nil { ifn_1906.Invoke_O_O_O_O__O(arg_1907, arg_1908, arg_1909, arg_1910) } else { linked_1905.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1904, arg_1907, arg_1908, arg_1909, arg_1910) }
//line :572:1
			return r__4 } }










func A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A_New_O(p0 any) *A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A{}; t.Ctor_O(p0); return t }
//line :583:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :583:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A) Invoke_O_O__O(self, p1__1479000192_SHARP___1 any) any { var root_1897 any = A_arbace_j2g_model_A_const_202.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = t.F_n; var arg_1901 any = p1__1479000192_SHARP___1; var arg_1902 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1898 == nil { return ifn_1899.Invoke_O_O_O__O(arg_1900, arg_1901, arg_1902) } else { return linked_1898.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1897, arg_1900, arg_1901, arg_1902) } }



























func A_arbace_j2g_model_fn__1479000200_A_New() *A_arbace_j2g_model_fn__1479000200_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000200_A{}; t.Ctor(); return t }
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_A) Ctor() {}
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A_New(); var tmp2 *jrt.Class; var fncls__1979 *jrt.Class = A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A_fn_class; if fncls__1979 == nil { var fncls__1979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A_fn_class = fncls__1979d; tmp2 = fncls__1979d } else { tmp2 = fncls__1979 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_model_A_const_247.GetRawRoot__O()) }
//line :611:1
func A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A_New() *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A{}; t.Ctor(); return t }
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A) Ctor() {}
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A) Invoke_O_O__O(self, s__1479000197__1 any) any { var tmp1 any = A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A_New_O_O(s__1479000197__1, self); var tmp2 *jrt.Class; var fncls__1978 *jrt.Class = A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A_fn_class; if fncls__1978 == nil { var fncls__1978d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A_fn_class = fncls__1978d; tmp2 = fncls__1978d } else { tmp2 = fncls__1978 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :611:1
func A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A{}; t.Ctor_O_O(p0, p1); return t }
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A) Ctor_O_O(c__s__1479000197, c__iter__1479000196 any) { t.F_s__1479000197 = c__s__1479000197; t.F_iter__1479000196 = c__iter__1479000196 }
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A) Invoke_O__O(self any) any { { var s__1479000197__1 any; var t_ any = t.F_s__1479000197; t.F_s__1479000197 = nil; s__1479000197__1 = t_; for { var temp__1927000414__auto____2 any; var root_1911 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = s__1479000197__1; if linked_1912 == nil { temp__1927000414__auto____2 = ifn_1913.Invoke_O__O(arg_1914) } else { temp__1927000414__auto____2 = linked_1912.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1911, arg_1914) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000197__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1915 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = s__1479000197__3; if linked_1916 == nil { tmp1 = ifn_1917.Invoke_O__O(arg_1918) } else { tmp1 = linked_1916.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1915, arg_1918) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1919 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = s__1479000197__3; if linked_1920 == nil { c__1927001037__auto____4 = ifn_1921.Invoke_O__O(arg_1922) } else { c__1927001037__auto____4 = linked_1920.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1919, arg_1922) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000199__6 any; var root_1923 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1924 == nil { b__1479000199__6 = ifn_1925.Invoke_O__O(arg_1926) } else { b__1479000199__6 = linked_1924.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1923, arg_1926) }; var tmp2 any = A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A_New_O_I_O(b__1479000199__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1937 *jrt.Class = A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A_fn_class; if fncls__1937 == nil { var fncls__1937d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A_fn_class = fncls__1937d; tmp3 = fncls__1937d } else { tmp3 = fncls__1937 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1938 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any; var root_1943 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = b__1479000199__6; if linked_1944 == nil { arg_1941 = ifn_1945.Invoke_O__O(arg_1946) } else { arg_1941 = linked_1944.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1943, arg_1946) }; var arg_1942 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000196); var tmp5 any; var root_1947 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = s__1479000197__3; if linked_1948 == nil { tmp5 = ifn_1949.Invoke_O__O(arg_1950) } else { tmp5 = linked_1948.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1947, arg_1950) }; arg_1942 = tmp4.Invoke_O__O(tmp5); if linked_1939 == nil { return ifn_1940.Invoke_O_O__O(arg_1941, arg_1942) } else { return linked_1939.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1938, arg_1941, arg_1942) } } else { var root_1951 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any; var root_1956 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1958 lang.IFn; if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = b__1479000199__6; if linked_1957 == nil { arg_1954 = ifn_1958.Invoke_O__O(arg_1959) } else { arg_1954 = linked_1957.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1956, arg_1959) }; var arg_1955 any; if linked_1952 == nil { return ifn_1953.Invoke_O_O__O(arg_1954, arg_1955) } else { return linked_1952.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1951, arg_1954, arg_1955) } } } else { var d__4 any; var root_1960 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = s__1479000197__3; if linked_1961 == nil { d__4 = ifn_1962.Invoke_O__O(arg_1963) } else { d__4 = linked_1961.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1960, arg_1963) }; var root_1964 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any; var tmp6 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_23, Lit_24, d__4); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp8 any; var root_1969 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1969, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1971 lang.IFn
															if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = Lit_24; var arg_1973 any = d__4; if linked_1970 == nil { tmp8 = ifn_1971.Invoke_O_O__O(arg_1972, arg_1973) } else { tmp8 = linked_1970.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1969, arg_1972, arg_1973) }
//line :611:1
	arg_1967 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref(), Lit_26)); var arg_1968 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1479000196); var tmp10 any; var root_1974 any = A_arbace_j2g_model_A_const_156.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = s__1479000197__3; if linked_1975 == nil { tmp10 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp10 = linked_1975.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1974, arg_1977) }; arg_1968 = tmp9.Invoke_O__O(tmp10); if linked_1965 == nil { return ifn_1966.Invoke_O_O__O(arg_1967, arg_1968) } else { return linked_1965.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1964, arg_1967, arg_1968) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :611:1
func A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A) Ctor_O_I_O(c__b__1479000199 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000199 = c__b__1479000199; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :611:1
func (t *A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A) Invoke_O__O(self any) any { { var i__1479000198__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000198__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000198__1)); var root_1927 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = t.F_b__1479000199; var arg_1931 any; var tmp2 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_23, Lit_24, d__2); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp4 any; var root_1932 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1934 lang.IFn
																	if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = Lit_24; var arg_1936 any = d__2; if linked_1933 == nil { tmp4 = ifn_1934.Invoke_O_O__O(arg_1935, arg_1936) } else { tmp4 = linked_1933.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1932, arg_1935, arg_1936) }
//line :611:1
	arg_1931 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(), Lit_26)); if linked_1928 == nil { ifn_1929.Invoke_O_O__O(arg_1930, arg_1931) } else { linked_1928.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1927, arg_1930, arg_1931) }; i__1479000198__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000198__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_model_throwable_print_helper_A_New() *A_arbace_j2g_model_throwable_print_helper_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_throwable_print_helper_A{}; t.Ctor(); return t }
//line :614:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Ctor() {}
//line :614:1
func (t *A_arbace_j2g_model_throwable_print_helper_A) Invoke_O_O_O_O__O(self, owner__0, name__1, desc__2 any) any { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_model_A_const_248.GetRawRoot__O(), lang.Tuple_Create_O_O_O__IPersistentVector(owner__0, name__1, desc__2)); if




	jrt.J2g_Truth(temp__1927000414__auto____4) { var vec__1479000208__5 any = temp__1927000414__auto____4; var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000208__5, lang.RT_IntCast_J__I_NoInit(0), nil); var c__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000208__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____8 any; var root_1980 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1982 lang.IFn
		if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = owner__0; if linked_1981 == nil { and__1927000168__auto____8 = ifn_1982.Invoke_O__O(arg_1983) } else { and__1927000168__auto____8 = linked_1981.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1980, arg_1983) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1984 any = A_arbace_j2g_model_A_const_249.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, A_arbace_j2g_model_translatable_QMARK__A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = c__7; if linked_1985 == nil { tmp1 = ifn_1986.Invoke_O__O(arg_1987) } else { tmp1 = linked_1985.(*A_arbace_j2g_model_translatable_QMARK__A).Invoke_O_O__O(root_1984, arg_1987) } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { return f__6 } else { return nil } } else {
//line :619:1
			return nil } }

















































type A_arbace_j2g_model_A struct{ jrt.Object }

var A_arbace_j2g_model_A_const_pool *jrt.RefArray

var A_arbace_j2g_model_A_const_0 *lang.Var

var A_arbace_j2g_model_A_const_1 any

var A_arbace_j2g_model_A_const_2 any

var A_arbace_j2g_model_A_const_3 any

var A_arbace_j2g_model_A_const_4 any

var A_arbace_j2g_model_A_const_5 any

var A_arbace_j2g_model_A_const_6 any

var A_arbace_j2g_model_A_const_7 any

var A_arbace_j2g_model_A_const_8 any

var A_arbace_j2g_model_A_const_9 *lang.Var

var A_arbace_j2g_model_A_const_10 any

var A_arbace_j2g_model_A_const_11 *lang.Var

var A_arbace_j2g_model_A_const_12 *lang.Var

var A_arbace_j2g_model_A_const_13 *lang.Var

var A_arbace_j2g_model_A_const_14 *lang.Var

var A_arbace_j2g_model_A_const_15 any

var A_arbace_j2g_model_A_const_16 *lang.Var

var A_arbace_j2g_model_A_const_17 *lang.Var

var A_arbace_j2g_model_A_const_18 *lang.Var

var A_arbace_j2g_model_A_const_19 *lang.Var

var A_arbace_j2g_model_A_const_20 *lang.Var

var A_arbace_j2g_model_A_const_21 *lang.Var

var A_arbace_j2g_model_A_const_22 *lang.Var

var A_arbace_j2g_model_A_const_23 *lang.Var

var A_arbace_j2g_model_A_const_24 any

var A_arbace_j2g_model_A_const_25 *lang.Var

var A_arbace_j2g_model_A_const_26 *lang.Var

var A_arbace_j2g_model_A_const_27 *lang.Var

var A_arbace_j2g_model_A_const_28 *lang.Var

var A_arbace_j2g_model_A_const_29 *lang.Var

var A_arbace_j2g_model_A_const_30 *lang.Var

var A_arbace_j2g_model_A_const_31 any

var A_arbace_j2g_model_A_const_32 *lang.Keyword

var A_arbace_j2g_model_A_const_33 *lang.Var

var A_arbace_j2g_model_A_const_34 *lang.Var

var A_arbace_j2g_model_A_const_35 *lang.Var

var A_arbace_j2g_model_A_const_36 *lang.Var

var A_arbace_j2g_model_A_const_37 *lang.Keyword

var A_arbace_j2g_model_A_const_38 *lang.Var

var A_arbace_j2g_model_A_const_39 *lang.Var

var A_arbace_j2g_model_A_const_40 *lang.Var

var A_arbace_j2g_model_A_const_41 *lang.Var

var A_arbace_j2g_model_A_const_42 *lang.Var

var A_arbace_j2g_model_A_const_43 *lang.Var

var A_arbace_j2g_model_A_const_44 *lang.Var

var A_arbace_j2g_model_A_const_45 *lang.Var

var A_arbace_j2g_model_A_const_46 *lang.Keyword

var A_arbace_j2g_model_A_const_47 any

var A_arbace_j2g_model_A_const_48 *lang.Var

var A_arbace_j2g_model_A_const_49 *lang.Keyword

var A_arbace_j2g_model_A_const_50 *lang.Var

var A_arbace_j2g_model_A_const_51 *lang.Var

var A_arbace_j2g_model_A_const_52 *lang.Var

var A_arbace_j2g_model_A_const_53 *lang.Keyword

var A_arbace_j2g_model_A_const_54 *lang.Var

var A_arbace_j2g_model_A_const_55 *lang.Var

var A_arbace_j2g_model_A_const_56 *lang.Var

var A_arbace_j2g_model_A_const_57 *lang.Var

var A_arbace_j2g_model_A_const_58 *lang.Var

var A_arbace_j2g_model_A_const_59 *lang.Var

var A_arbace_j2g_model_A_const_60 *lang.Keyword

var A_arbace_j2g_model_A_const_61 *lang.Var

var A_arbace_j2g_model_A_const_62 *lang.Var

var A_arbace_j2g_model_A_const_63 *lang.Var

var A_arbace_j2g_model_A_const_64 *lang.Var

var A_arbace_j2g_model_A_const_65 *lang.Var

var A_arbace_j2g_model_A_const_66 *lang.Var

var A_arbace_j2g_model_A_const_67 *lang.Var

var A_arbace_j2g_model_A_const_68 *lang.Var

var A_arbace_j2g_model_A_const_69 *lang.Keyword

var A_arbace_j2g_model_A_const_70 *lang.Var

var A_arbace_j2g_model_A_const_71 *lang.Keyword

var A_arbace_j2g_model_A_const_72 *lang.Var

var A_arbace_j2g_model_A_const_73 *lang.Var

var A_arbace_j2g_model_A_const_74 *lang.Var

var A_arbace_j2g_model_A_const_75 any

var A_arbace_j2g_model_A_const_76 any

var A_arbace_j2g_model_A_const_77 *lang.Keyword

var A_arbace_j2g_model_A_const_78 *lang.Var

var A_arbace_j2g_model_A_const_79 *lang.Var

var A_arbace_j2g_model_A_const_80 *lang.Keyword

var A_arbace_j2g_model_A_const_81 *lang.Var

var A_arbace_j2g_model_A_const_82 *lang.Var

var A_arbace_j2g_model_A_const_83 *lang.Var

var A_arbace_j2g_model_A_const_84 *lang.Var

var A_arbace_j2g_model_A_const_85 *lang.Var

var A_arbace_j2g_model_A_const_86 *lang.Var

var A_arbace_j2g_model_A_const_87 *lang.Var

var A_arbace_j2g_model_A_const_88 *lang.Var

var A_arbace_j2g_model_A_const_89 *lang.Var

var A_arbace_j2g_model_A_const_90 *lang.Keyword

var A_arbace_j2g_model_A_const_91 *lang.Keyword

var A_arbace_j2g_model_A_const_92 *lang.Var

var A_arbace_j2g_model_A_const_93 *lang.Var

var A_arbace_j2g_model_A_const_94 *lang.Var

var A_arbace_j2g_model_A_const_95 *lang.Var

var A_arbace_j2g_model_A_const_96 *lang.Var

var A_arbace_j2g_model_A_const_97 *lang.Var

var A_arbace_j2g_model_A_const_98 *lang.Var

var A_arbace_j2g_model_A_const_99 *lang.Var

var A_arbace_j2g_model_A_const_100 *lang.Var

var A_arbace_j2g_model_A_const_101 *lang.Var

var A_arbace_j2g_model_A_const_102 *lang.Keyword

var A_arbace_j2g_model_A_const_103 *lang.Var

var A_arbace_j2g_model_A_const_104 *lang.Var

var A_arbace_j2g_model_A_const_105 *lang.Var

var A_arbace_j2g_model_A_const_106 *lang.Var

var A_arbace_j2g_model_A_const_107 *lang.Keyword

var A_arbace_j2g_model_A_const_108 any

var A_arbace_j2g_model_A_const_109 *lang.Var

var A_arbace_j2g_model_A_const_110 any

var A_arbace_j2g_model_A_const_111 any

var A_arbace_j2g_model_A_const_112 *lang.Var

var A_arbace_j2g_model_A_const_113 *lang.Var

var A_arbace_j2g_model_A_const_114 *lang.Var

var A_arbace_j2g_model_A_const_115 *lang.Keyword

var A_arbace_j2g_model_A_const_116 any

var A_arbace_j2g_model_A_const_117 any

var A_arbace_j2g_model_A_const_118 any

var A_arbace_j2g_model_A_const_119 *lang.Var

var A_arbace_j2g_model_A_const_120 *lang.Var

var A_arbace_j2g_model_A_const_121 *lang.Var

var A_arbace_j2g_model_A_const_122 any

var A_arbace_j2g_model_A_const_123 any

var A_arbace_j2g_model_A_const_124 *lang.Keyword

var A_arbace_j2g_model_A_const_125 *lang.Keyword

var A_arbace_j2g_model_A_const_126 *lang.Var

var A_arbace_j2g_model_A_const_127 *lang.Var

var A_arbace_j2g_model_A_const_128 *lang.Var

var A_arbace_j2g_model_A_const_129 *lang.Var

var A_arbace_j2g_model_A_const_130 *lang.Var

var A_arbace_j2g_model_A_const_131 *lang.Var

var A_arbace_j2g_model_A_const_132 *lang.Var

var A_arbace_j2g_model_A_const_133 *lang.Var

var A_arbace_j2g_model_A_const_134 *lang.Var

var A_arbace_j2g_model_A_const_135 *lang.Var

var A_arbace_j2g_model_A_const_136 *lang.Var

var A_arbace_j2g_model_A_const_137 *lang.Keyword

var A_arbace_j2g_model_A_const_138 *lang.Var

var A_arbace_j2g_model_A_const_139 *lang.Var

var A_arbace_j2g_model_A_const_140 *lang.Var

var A_arbace_j2g_model_A_const_141 any

var A_arbace_j2g_model_A_const_142 *lang.Var

var A_arbace_j2g_model_A_const_143 *lang.Var

var A_arbace_j2g_model_A_const_144 *lang.Var

var A_arbace_j2g_model_A_const_145 *lang.Var

var A_arbace_j2g_model_A_const_146 *lang.Var

var A_arbace_j2g_model_A_const_147 *lang.Var

var A_arbace_j2g_model_A_const_148 *lang.Var

var A_arbace_j2g_model_A_const_149 *lang.Var

var A_arbace_j2g_model_A_const_150 *lang.Var

var A_arbace_j2g_model_A_const_151 *lang.Keyword

var A_arbace_j2g_model_A_const_152 *lang.Var

var A_arbace_j2g_model_A_const_153 *lang.Var

var A_arbace_j2g_model_A_const_154 *lang.Var

var A_arbace_j2g_model_A_const_155 *lang.Var

var A_arbace_j2g_model_A_const_156 *lang.Var

var A_arbace_j2g_model_A_const_157 *lang.Keyword

var A_arbace_j2g_model_A_const_158 *lang.Var

var A_arbace_j2g_model_A_const_159 *lang.Var

var A_arbace_j2g_model_A_const_160 *lang.Var

var A_arbace_j2g_model_A_const_161 *lang.Var

var A_arbace_j2g_model_A_const_162 any

var A_arbace_j2g_model_A_const_163 *lang.Var

var A_arbace_j2g_model_A_const_164 *lang.Var

var A_arbace_j2g_model_A_const_165 *lang.Var

var A_arbace_j2g_model_A_const_166 *lang.Var

var A_arbace_j2g_model_A_const_167 *lang.Var

var A_arbace_j2g_model_A_const_168 *lang.Var

var A_arbace_j2g_model_A_const_169 *lang.Var

var A_arbace_j2g_model_A_const_170 *lang.Keyword

var A_arbace_j2g_model_A_const_171 *lang.Keyword

var A_arbace_j2g_model_A_const_172 *lang.Keyword

var A_arbace_j2g_model_A_const_173 *lang.Keyword

var A_arbace_j2g_model_A_const_174 *lang.Keyword

var A_arbace_j2g_model_A_const_175 *lang.Keyword

var A_arbace_j2g_model_A_const_176 *lang.Var

var A_arbace_j2g_model_A_const_177 *lang.Keyword

var A_arbace_j2g_model_A_const_178 *lang.Var

var A_arbace_j2g_model_A_const_179 *lang.Keyword

var A_arbace_j2g_model_A_const_180 *lang.Keyword

var A_arbace_j2g_model_A_const_181 *lang.Var

var A_arbace_j2g_model_A_const_182 any

var A_arbace_j2g_model_A_const_183 *lang.Keyword

var A_arbace_j2g_model_A_const_184 *lang.Keyword

var A_arbace_j2g_model_A_const_185 *lang.Keyword

var A_arbace_j2g_model_A_const_186 *lang.Keyword

var A_arbace_j2g_model_A_const_187 *lang.Keyword

var A_arbace_j2g_model_A_const_188 *lang.Keyword

var A_arbace_j2g_model_A_const_189 *lang.Var

var A_arbace_j2g_model_A_const_190 *lang.Var

var A_arbace_j2g_model_A_const_191 *lang.Var

var A_arbace_j2g_model_A_const_192 *lang.Var

var A_arbace_j2g_model_A_const_193 *lang.Var

var A_arbace_j2g_model_A_const_194 *lang.Var

var A_arbace_j2g_model_A_const_195 *lang.Var

var A_arbace_j2g_model_A_const_196 *lang.Var

var A_arbace_j2g_model_A_const_197 *lang.Keyword

var A_arbace_j2g_model_A_const_198 *lang.Var

var A_arbace_j2g_model_A_const_199 *lang.Keyword

var A_arbace_j2g_model_A_const_200 *lang.Keyword

var A_arbace_j2g_model_A_const_201 *lang.Keyword

var A_arbace_j2g_model_A_const_202 *lang.Var

var A_arbace_j2g_model_A_const_203 *lang.Keyword

var A_arbace_j2g_model_A_const_204 any

var A_arbace_j2g_model_A_const_205 *lang.Var

var A_arbace_j2g_model_A_const_206 *lang.Keyword

var A_arbace_j2g_model_A_const_207 *lang.Keyword

var A_arbace_j2g_model_A_const_208 *lang.Keyword

var A_arbace_j2g_model_A_const_209 *lang.Keyword

var A_arbace_j2g_model_A_const_210 *lang.Keyword

var A_arbace_j2g_model_A_const_211 *lang.Keyword

var A_arbace_j2g_model_A_const_212 *lang.Keyword

var A_arbace_j2g_model_A_const_213 *lang.Keyword

var A_arbace_j2g_model_A_const_214 *lang.Keyword

var A_arbace_j2g_model_A_const_215 *lang.Keyword

var A_arbace_j2g_model_A_const_216 *lang.Keyword

var A_arbace_j2g_model_A_const_217 *lang.Keyword

var A_arbace_j2g_model_A_const_218 *lang.Keyword

var A_arbace_j2g_model_A_const_219 *lang.Keyword

var A_arbace_j2g_model_A_const_220 *lang.Keyword

var A_arbace_j2g_model_A_const_221 *lang.Keyword

var A_arbace_j2g_model_A_const_222 *lang.Keyword

var A_arbace_j2g_model_A_const_223 *lang.Keyword

var A_arbace_j2g_model_A_const_224 *lang.Keyword

var A_arbace_j2g_model_A_const_225 *lang.Keyword

var A_arbace_j2g_model_A_const_226 *lang.Keyword

var A_arbace_j2g_model_A_const_227 *lang.Keyword

var A_arbace_j2g_model_A_const_228 *lang.Keyword

var A_arbace_j2g_model_A_const_229 *lang.Keyword

var A_arbace_j2g_model_A_const_230 *lang.Keyword

var A_arbace_j2g_model_A_const_231 *lang.Keyword

var A_arbace_j2g_model_A_const_232 *lang.Keyword

var A_arbace_j2g_model_A_const_233 *lang.Var

var A_arbace_j2g_model_A_const_234 *lang.Keyword

var A_arbace_j2g_model_A_const_235 *lang.Keyword

var A_arbace_j2g_model_A_const_236 *lang.Keyword

var A_arbace_j2g_model_A_const_237 *lang.Keyword

var A_arbace_j2g_model_A_const_238 any

var A_arbace_j2g_model_A_const_239 *lang.Keyword

var A_arbace_j2g_model_A_const_240 *lang.Keyword

var A_arbace_j2g_model_A_const_241 *lang.Keyword

var A_arbace_j2g_model_A_const_242 *lang.Keyword

var A_arbace_j2g_model_A_const_243 *lang.Keyword

var A_arbace_j2g_model_A_const_244 *lang.Keyword

var A_arbace_j2g_model_A_const_245 *lang.Var

var A_arbace_j2g_model_A_const_246 *lang.Keyword

var A_arbace_j2g_model_A_const_247 *lang.Var

var A_arbace_j2g_model_A_const_248 *lang.Var

var A_arbace_j2g_model_A_const_249 *lang.Var

var A_arbace_j2g_model_A_init jrt.ClassInit

func A_arbace_j2g_model_A_Init() { if !A_arbace_j2g_model_A_init.Done() { A_arbace_j2g_model_A_init.Run(A_arbace_j2g_model_A_clinit) } }

func A_arbace_j2g_model_A_clinit() { A_arbace_j2g_model_A_clinit_p0(); A_arbace_j2g_model_A_clinit_p1(); A_arbace_j2g_model_A_clinit_p2(); A_arbace_j2g_model_A_clinit_p3(); A_arbace_j2g_model_A_clinit_p4(); A_arbace_j2g_model_A_clinit_p5(); A_arbace_j2g_model_A_clinit_p6(); A_arbace_j2g_model_A_clinit_p7(); A_arbace_j2g_model_A_clinit_p8(); A_arbace_j2g_model_A_clinit_p9(); A_arbace_j2g_model_A_clinit_p10(); A_arbace_j2g_model_A_clinit_p11(); A_arbace_j2g_model_A_clinit_p12(); A_arbace_j2g_model_A_clinit_p13(); A_arbace_j2g_model_A_clinit_p14(); A_arbace_j2g_model_A_clinit_p15(); A_arbace_j2g_model_A_clinit_p16(); A_arbace_j2g_model_A_clinit_p17(); A_arbace_j2g_model_A_clinit_p18(); A_arbace_j2g_model_A_clinit_p19(); A_arbace_j2g_model_A_clinit_p20() }

func A_arbace_j2g_model_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 351); A_arbace_j2g_model_A_const_0 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[101]); A_arbace_j2g_model_A_const_1 = A_arbace_j2g_model_A_const_pool.A[102]; A_arbace_j2g_model_A_const_2 = A_arbace_j2g_model_A_const_pool.A[103]; A_arbace_j2g_model_A_const_3 = A_arbace_j2g_model_A_const_pool.A[104]; A_arbace_j2g_model_A_const_4 = A_arbace_j2g_model_A_const_pool.A[105]; A_arbace_j2g_model_A_const_5 = A_arbace_j2g_model_A_const_pool.A[106]; A_arbace_j2g_model_A_const_6 = A_arbace_j2g_model_A_const_pool.A[107]; A_arbace_j2g_model_A_const_7 = A_arbace_j2g_model_A_const_pool.A[108]; A_arbace_j2g_model_A_const_8 = A_arbace_j2g_model_A_const_pool.A[109]; A_arbace_j2g_model_A_const_9 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[110]); A_arbace_j2g_model_A_const_10 = A_arbace_j2g_model_A_const_pool.A[111]; A_arbace_j2g_model_A_const_11 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[112]); A_arbace_j2g_model_A_const_12 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[113]) }

func A_arbace_j2g_model_A_clinit_p1() { A_arbace_j2g_model_A_const_13 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[114]); A_arbace_j2g_model_A_const_14 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[115]); A_arbace_j2g_model_A_const_15 = A_arbace_j2g_model_A_const_pool.A[116]; A_arbace_j2g_model_A_const_16 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[117]); A_arbace_j2g_model_A_const_17 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[118]); A_arbace_j2g_model_A_const_18 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[119]); A_arbace_j2g_model_A_const_19 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[120]); A_arbace_j2g_model_A_const_20 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[121]); A_arbace_j2g_model_A_const_21 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[122]); A_arbace_j2g_model_A_const_22 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[123]); A_arbace_j2g_model_A_const_23 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[124]); A_arbace_j2g_model_A_const_24 = A_arbace_j2g_model_A_const_pool.A[125] }

func A_arbace_j2g_model_A_clinit_p2() { A_arbace_j2g_model_A_const_25 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[126]); A_arbace_j2g_model_A_const_26 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[127]); A_arbace_j2g_model_A_const_27 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[128]); A_arbace_j2g_model_A_const_28 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[129]); A_arbace_j2g_model_A_const_29 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[130]); A_arbace_j2g_model_A_const_30 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[131]); A_arbace_j2g_model_A_const_31 = A_arbace_j2g_model_A_const_pool.A[132]; A_arbace_j2g_model_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[133]); A_arbace_j2g_model_A_const_33 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[134]); A_arbace_j2g_model_A_const_34 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[135]); A_arbace_j2g_model_A_const_35 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[136]); A_arbace_j2g_model_A_const_36 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[137]) }

func A_arbace_j2g_model_A_clinit_p3() { A_arbace_j2g_model_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[138]); A_arbace_j2g_model_A_const_38 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[139]); A_arbace_j2g_model_A_const_39 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[140]); A_arbace_j2g_model_A_const_40 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[141]); A_arbace_j2g_model_A_const_41 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[142]); A_arbace_j2g_model_A_const_42 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[143]); A_arbace_j2g_model_A_const_43 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[144]); A_arbace_j2g_model_A_const_44 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[145]); A_arbace_j2g_model_A_const_45 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[146]); A_arbace_j2g_model_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[147]); A_arbace_j2g_model_A_const_47 = A_arbace_j2g_model_A_const_pool.A[148]; A_arbace_j2g_model_A_const_48 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[149]) }

func A_arbace_j2g_model_A_clinit_p4() { A_arbace_j2g_model_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[150]); A_arbace_j2g_model_A_const_50 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[151]); A_arbace_j2g_model_A_const_51 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[152]); A_arbace_j2g_model_A_const_52 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[153]); A_arbace_j2g_model_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[154]); A_arbace_j2g_model_A_const_54 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[155]); A_arbace_j2g_model_A_const_55 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[156]); A_arbace_j2g_model_A_const_56 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[157]); A_arbace_j2g_model_A_const_57 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[158]); A_arbace_j2g_model_A_const_58 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[159]); A_arbace_j2g_model_A_const_59 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[160]); A_arbace_j2g_model_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[161]) }

func A_arbace_j2g_model_A_clinit_p5() { A_arbace_j2g_model_A_const_61 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[162]); A_arbace_j2g_model_A_const_62 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[163]); A_arbace_j2g_model_A_const_63 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[164]); A_arbace_j2g_model_A_const_64 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[165]); A_arbace_j2g_model_A_const_65 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[166]); A_arbace_j2g_model_A_const_66 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[167]); A_arbace_j2g_model_A_const_67 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[168]); A_arbace_j2g_model_A_const_68 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[169]); A_arbace_j2g_model_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[170]); A_arbace_j2g_model_A_const_70 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[171]); A_arbace_j2g_model_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[172]); A_arbace_j2g_model_A_const_72 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[173]) }

func A_arbace_j2g_model_A_clinit_p6() { A_arbace_j2g_model_A_const_73 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[174]); A_arbace_j2g_model_A_const_74 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[175]); A_arbace_j2g_model_A_const_75 = A_arbace_j2g_model_A_const_pool.A[176]; A_arbace_j2g_model_A_const_76 = A_arbace_j2g_model_A_const_pool.A[177]; A_arbace_j2g_model_A_const_77 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[178]); A_arbace_j2g_model_A_const_78 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[179]); A_arbace_j2g_model_A_const_79 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[180]); A_arbace_j2g_model_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[181]); A_arbace_j2g_model_A_const_81 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[182]); A_arbace_j2g_model_A_const_82 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[183]); A_arbace_j2g_model_A_const_83 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[184]); A_arbace_j2g_model_A_const_84 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[185]) }

func A_arbace_j2g_model_A_clinit_p7() { A_arbace_j2g_model_A_const_85 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[186]); A_arbace_j2g_model_A_const_86 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[187]); A_arbace_j2g_model_A_const_87 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[188]); A_arbace_j2g_model_A_const_88 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[189]); A_arbace_j2g_model_A_const_89 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[190]); A_arbace_j2g_model_A_const_90 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[191]); A_arbace_j2g_model_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[192]); A_arbace_j2g_model_A_const_92 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[193]); A_arbace_j2g_model_A_const_93 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[194]); A_arbace_j2g_model_A_const_94 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[195]); A_arbace_j2g_model_A_const_95 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[196]); A_arbace_j2g_model_A_const_96 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[197]) }

func A_arbace_j2g_model_A_clinit_p8() { A_arbace_j2g_model_A_const_97 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[198]); A_arbace_j2g_model_A_const_98 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[199]); A_arbace_j2g_model_A_const_99 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[200]); A_arbace_j2g_model_A_const_100 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[201]); A_arbace_j2g_model_A_const_101 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[202]); A_arbace_j2g_model_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[203]); A_arbace_j2g_model_A_const_103 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[204]); A_arbace_j2g_model_A_const_104 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[205]); A_arbace_j2g_model_A_const_105 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[206]); A_arbace_j2g_model_A_const_106 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[207]); A_arbace_j2g_model_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[208]); A_arbace_j2g_model_A_const_108 = A_arbace_j2g_model_A_const_pool.A[209] }

func A_arbace_j2g_model_A_clinit_p9() { A_arbace_j2g_model_A_const_109 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[210]); A_arbace_j2g_model_A_const_110 = A_arbace_j2g_model_A_const_pool.A[211]; A_arbace_j2g_model_A_const_111 = A_arbace_j2g_model_A_const_pool.A[212]; A_arbace_j2g_model_A_const_112 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[213]); A_arbace_j2g_model_A_const_113 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[214]); A_arbace_j2g_model_A_const_114 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[215]); A_arbace_j2g_model_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[216]); A_arbace_j2g_model_A_const_116 = A_arbace_j2g_model_A_const_pool.A[217]; A_arbace_j2g_model_A_const_117 = A_arbace_j2g_model_A_const_pool.A[218]; A_arbace_j2g_model_A_const_118 = A_arbace_j2g_model_A_const_pool.A[219]; A_arbace_j2g_model_A_const_119 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[220]); A_arbace_j2g_model_A_const_120 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[221]); A_arbace_j2g_model_A_const_121 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[222]) }

func A_arbace_j2g_model_A_clinit_p10() { A_arbace_j2g_model_A_const_122 = A_arbace_j2g_model_A_const_pool.A[223]; A_arbace_j2g_model_A_const_123 = A_arbace_j2g_model_A_const_pool.A[224]; A_arbace_j2g_model_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[225]); A_arbace_j2g_model_A_const_125 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[226]); A_arbace_j2g_model_A_const_126 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[227]); A_arbace_j2g_model_A_const_127 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[228]); A_arbace_j2g_model_A_const_128 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[229]); A_arbace_j2g_model_A_const_129 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[230]); A_arbace_j2g_model_A_const_130 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[231]); A_arbace_j2g_model_A_const_131 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[232]); A_arbace_j2g_model_A_const_132 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[233]); A_arbace_j2g_model_A_const_133 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[234]) }

func A_arbace_j2g_model_A_clinit_p11() { A_arbace_j2g_model_A_const_134 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[235]); A_arbace_j2g_model_A_const_135 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[236]); A_arbace_j2g_model_A_const_136 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[237]); A_arbace_j2g_model_A_const_137 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[238]); A_arbace_j2g_model_A_const_138 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[239]); A_arbace_j2g_model_A_const_139 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[240]); A_arbace_j2g_model_A_const_140 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[241]); A_arbace_j2g_model_A_const_141 = A_arbace_j2g_model_A_const_pool.A[242]; A_arbace_j2g_model_A_const_142 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[243]); A_arbace_j2g_model_A_const_143 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[244]); A_arbace_j2g_model_A_const_144 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[245]); A_arbace_j2g_model_A_const_145 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[246]) }

func A_arbace_j2g_model_A_clinit_p12() { A_arbace_j2g_model_A_const_146 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[247]); A_arbace_j2g_model_A_const_147 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[248]); A_arbace_j2g_model_A_const_148 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[249]); A_arbace_j2g_model_A_const_149 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[250]); A_arbace_j2g_model_A_const_150 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[251]); A_arbace_j2g_model_A_const_151 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[252]); A_arbace_j2g_model_A_const_152 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[253]); A_arbace_j2g_model_A_const_153 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[254]); A_arbace_j2g_model_A_const_154 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[255]); A_arbace_j2g_model_A_const_155 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[256]); A_arbace_j2g_model_A_const_156 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[257]); A_arbace_j2g_model_A_const_157 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[258]) }

func A_arbace_j2g_model_A_clinit_p13() { A_arbace_j2g_model_A_const_158 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[259]); A_arbace_j2g_model_A_const_159 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[260]); A_arbace_j2g_model_A_const_160 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[261]); A_arbace_j2g_model_A_const_161 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[262]); A_arbace_j2g_model_A_const_162 = A_arbace_j2g_model_A_const_pool.A[263]; A_arbace_j2g_model_A_const_163 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[264]); A_arbace_j2g_model_A_const_164 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[265]); A_arbace_j2g_model_A_const_165 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[266]); A_arbace_j2g_model_A_const_166 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[267]); A_arbace_j2g_model_A_const_167 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[268]); A_arbace_j2g_model_A_const_168 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[269]); A_arbace_j2g_model_A_const_169 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[270]) }

func A_arbace_j2g_model_A_clinit_p14() { A_arbace_j2g_model_A_const_170 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[271]); A_arbace_j2g_model_A_const_171 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[272]); A_arbace_j2g_model_A_const_172 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[273]); A_arbace_j2g_model_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[274]); A_arbace_j2g_model_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[275]); A_arbace_j2g_model_A_const_175 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[276]); A_arbace_j2g_model_A_const_176 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[277]); A_arbace_j2g_model_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[278]); A_arbace_j2g_model_A_const_178 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[279]); A_arbace_j2g_model_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[280]); A_arbace_j2g_model_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[281]); A_arbace_j2g_model_A_const_181 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[282]) }

func A_arbace_j2g_model_A_clinit_p15() { A_arbace_j2g_model_A_const_182 = A_arbace_j2g_model_A_const_pool.A[283]; A_arbace_j2g_model_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[284]); A_arbace_j2g_model_A_const_184 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[285]); A_arbace_j2g_model_A_const_185 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[286]); A_arbace_j2g_model_A_const_186 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[287]); A_arbace_j2g_model_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[288]); A_arbace_j2g_model_A_const_188 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[289]); A_arbace_j2g_model_A_const_189 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[290]); A_arbace_j2g_model_A_const_190 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[291]); A_arbace_j2g_model_A_const_191 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[292]); A_arbace_j2g_model_A_const_192 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[293]); A_arbace_j2g_model_A_const_193 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[294]) }

func A_arbace_j2g_model_A_clinit_p16() { A_arbace_j2g_model_A_const_194 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[295]); A_arbace_j2g_model_A_const_195 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[296]); A_arbace_j2g_model_A_const_196 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[297]); A_arbace_j2g_model_A_const_197 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[298]); A_arbace_j2g_model_A_const_198 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[299]); A_arbace_j2g_model_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[300]); A_arbace_j2g_model_A_const_200 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[301]); A_arbace_j2g_model_A_const_201 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[302]); A_arbace_j2g_model_A_const_202 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[303]); A_arbace_j2g_model_A_const_203 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[304]); A_arbace_j2g_model_A_const_204 = A_arbace_j2g_model_A_const_pool.A[305]; A_arbace_j2g_model_A_const_205 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[306]) }

func A_arbace_j2g_model_A_clinit_p17() { A_arbace_j2g_model_A_const_206 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[307]); A_arbace_j2g_model_A_const_207 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[308]); A_arbace_j2g_model_A_const_208 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[309]); A_arbace_j2g_model_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[310]); A_arbace_j2g_model_A_const_210 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[311]); A_arbace_j2g_model_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[312]); A_arbace_j2g_model_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[313]); A_arbace_j2g_model_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[314]); A_arbace_j2g_model_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[315]); A_arbace_j2g_model_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[316]); A_arbace_j2g_model_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[317]); A_arbace_j2g_model_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[318]) }

func A_arbace_j2g_model_A_clinit_p18() { A_arbace_j2g_model_A_const_218 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[319]); A_arbace_j2g_model_A_const_219 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[320]); A_arbace_j2g_model_A_const_220 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[321]); A_arbace_j2g_model_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[322]); A_arbace_j2g_model_A_const_222 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[323]); A_arbace_j2g_model_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[324]); A_arbace_j2g_model_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[325]); A_arbace_j2g_model_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[326]); A_arbace_j2g_model_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[327]); A_arbace_j2g_model_A_const_227 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[328]); A_arbace_j2g_model_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[329]); A_arbace_j2g_model_A_const_229 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[330]) }

func A_arbace_j2g_model_A_clinit_p19() { A_arbace_j2g_model_A_const_230 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[331]); A_arbace_j2g_model_A_const_231 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[332]); A_arbace_j2g_model_A_const_232 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[333]); A_arbace_j2g_model_A_const_233 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[334]); A_arbace_j2g_model_A_const_234 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[335]); A_arbace_j2g_model_A_const_235 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[336]); A_arbace_j2g_model_A_const_236 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[337]); A_arbace_j2g_model_A_const_237 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[338]); A_arbace_j2g_model_A_const_238 = A_arbace_j2g_model_A_const_pool.A[339]; A_arbace_j2g_model_A_const_239 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[340]); A_arbace_j2g_model_A_const_240 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[341]); A_arbace_j2g_model_A_const_241 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[342]) }

func A_arbace_j2g_model_A_clinit_p20() { A_arbace_j2g_model_A_const_242 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[343]); A_arbace_j2g_model_A_const_243 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[344]); A_arbace_j2g_model_A_const_244 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[345]); A_arbace_j2g_model_A_const_245 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[346]); A_arbace_j2g_model_A_const_246 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[347]); A_arbace_j2g_model_A_const_247 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[348]); A_arbace_j2g_model_A_const_248 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[349]); A_arbace_j2g_model_A_const_249 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[350]) }

func A_arbace_j2g_model_A_New() *A_arbace_j2g_model_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_A) Ctor() {}

func (t *A_arbace_j2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_A_class }

func (t *A_arbace_j2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_A); return ok }

func A_arbace_j2g_model_A_Cast(x any) *A_arbace_j2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_A_class)) }; return v }



type A_arbace_j2g_model_T_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_T_A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_m_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_m_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_method_error_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_method_error_text_A_fn_class *jrt.Class



type A_arbace_j2g_model_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_all_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_array_test_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_array_test_A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_benign_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000193_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_code_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_code_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_declared_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A struct{ j2g_header uint64; F_n, F_s__1479000091, F_iter__1479000090 any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A struct{ j2g_header uint64; F_n, F_b__1479000093 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000090__1479000094_fn__1479000095_fn__1479000096_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_erased_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000004_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000004_A_New() *A_arbace_j2g_model_eval1479000004_A { t := &A_arbace_j2g_model_eval1479000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000004_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000004_A_class }

func (t *A_arbace_j2g_model_eval1479000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000004_A); return ok }

func A_arbace_j2g_model_eval1479000004_A_Cast(x any) *A_arbace_j2g_model_eval1479000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000004_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000008_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000008_A_New() *A_arbace_j2g_model_eval1479000008_A { t := &A_arbace_j2g_model_eval1479000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000008_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000008_A_class }

func (t *A_arbace_j2g_model_eval1479000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000008_A); return ok }

func A_arbace_j2g_model_eval1479000008_A_Cast(x any) *A_arbace_j2g_model_eval1479000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000008_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000008_fn__1479000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class *jrt.Class



type A_arbace_j2g_model_fields_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fields_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_final_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_final_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_find_method_A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_fn__1479000080_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_find_method_fn__1479000080_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000200_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000200_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A struct{ j2g_header uint64; F_s__1479000197, F_iter__1479000196 any }

var A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_A_fn_class *jrt.Class



type A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A struct{ j2g_header uint64; F_b__1479000199 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_fn__1479000200_iter__1479000196__1479000201_fn__1479000202_fn__1479000203_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_qualified_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_qualified_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_model_hand_written_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hand_written_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_hw_method_exists_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_iface_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_iface_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_impl_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000124_A struct{ j2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_j2g_model_impl_of_fn__1479000124_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000136_A struct{ j2g_header uint64; F_cands any }

var A_arbace_j2g_model_impl_of_fn__1479000136_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_model_impl_of_fn__1479000136_fn__1479000137_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A struct{ j2g_header uint64; F_iter__1479000126, F_name, F_desc, F_s__1479000127 any }

var A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A struct{ j2g_header uint64; F_name, F_b__1479000129, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_impl_of_iter__1479000126__1479000130_fn__1479000131_fn__1479000132_A_fn_class *jrt.Class



type A_arbace_j2g_model_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_info_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_info_A_fn_class *jrt.Class



type A_arbace_j2g_model_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_method_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_java_type_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_java_type_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_jobs_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jobs_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_leaf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_leaf_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_A struct{ j2g_header uint64; F_cache, F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A struct{ j2g_header uint64; F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class *jrt.Class



type A_arbace_j2g_model_mdesc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_member_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_member_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_method_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_method_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_methods_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_methods_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_nest_top_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_nest_top_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_par_mapv_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000017_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_work__1479000019_A struct{ j2g_header uint64; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

var A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class *jrt.Class



type A_arbace_j2g_model_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_pointer_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_private_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000161_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000163_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000173_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000176_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000181_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000183_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000185_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000187_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000189_A_fn_class *jrt.Class



type A_arbace_j2g_model_qualify_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_qualify_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflected_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflected_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A struct{ j2g_header uint64; F_iter__1479000147, F_s__1479000148 any }

var A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1479000150, F_c__1927001037__auto__ any }

var A_arbace_j2g_model_start_classes_iter__1479000147__1479000151_fn__1479000152_fn__1479000153_A_fn_class *jrt.Class



type A_arbace_j2g_model_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_subclasses_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_subclasses_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_fn__1479000116_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_fn__1479000116_A_fn_class *jrt.Class



type A_arbace_j2g_model_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_throwable_print_helper_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_throwable_print_helper_A_fn_class *jrt.Class



type A_arbace_j2g_model_top_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_top_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_translatable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translatable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_translated_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translated_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_trivial_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_trivial_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_virtual_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_virtual_member_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000101_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000101_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000101_fn__1479000102_A_fn_class *jrt.Class



type A_arbace_j2g_model_world_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_world_supertypes_A_fn_class *jrt.Class
