//line aot_arbace_j2g_model.ae:1
package aot_arbace_j2g_model

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_env"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_New() *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_model_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_model_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_model_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_model_A_const_1, A_arbace_j2g_model_A_const_2, A_arbace_j2g_model_A_const_3, A_arbace_j2g_model_A_const_4, A_arbace_j2g_model_A_const_5, A_arbace_j2g_model_A_const_6, A_arbace_j2g_model_A_const_7, A_arbace_j2g_model_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_model_eval1479000008_fn__1479000009_A_New() *A_arbace_j2g_model_eval1479000008_fn__1479000009_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_eval1479000008_fn__1479000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_model_eval1479000008_fn__1479000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_11.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_model_A_const_13; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_model_A_const_14.GetRawRoot__O(), A_arbace_j2g_model_A_const_15) }
























func A_arbace_j2g_model_jobs_A_New() *A_arbace_j2g_model_jobs_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jobs_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_model_jobs_A) Invoke_O__O(self any) any { var e__1 any = jrt.System_Getenv_String__String(Lit_35).Ref(); var tmp1 any; var tmp2 any; var root_26 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_28 lang.IFn; if




	linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = e__1; if linked_27 == nil { tmp2 = ifn_28.Invoke_O__O(arg_29) } else { tmp2 = linked_27.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_26, arg_29) }; if jrt.J2g_Truth(tmp2) {
		tmp1 = jrt.Long_ValueOf_J__Long_NoInit(jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(e__1))).Ref() } else {
			tmp1 = lang.Numbers_Min_O_J__O_NoInit(A_arbace_j2g_model_A_const_17.GetRawRoot__O(), int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())) }; return /*line :31:1*/ lang.Numbers_Max_J_O__O_NoInit(1, tmp1) }



func A_arbace_j2g_model_par_mapv_A_New() *A_arbace_j2g_model_par_mapv_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) Ctor() {}
//line :35:1
func (t *A_arbace_j2g_model_par_mapv_A) DoInvoke_O_O_O_O_O__O(self, n__0, f__1, xs__2, p__1479000013__3 any) any { var vec__1479000014__5 any = p__1479000013__3; var order__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000014__5, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__7 any; var root_30 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_32 lang.IFn; if









	linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = xs__2; if linked_31 == nil { xs__7 = ifn_32.Invoke_O__O(arg_33) } else { xs__7 = linked_31.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_30, arg_33) }; var cnt__8 int32 = /*line :35:1*/lang.RT_Count_O__I_NoInit(xs__7); var n__9 any = lang.Numbers_Min_O_J__O_NoInit(n__0, int64(cnt__8)); var order__10 any; if












	jrt.J2g_Truth(order__6) { var root_34 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = order__6; if linked_35 == nil { order__10 = ifn_36.Invoke_O__O(arg_37) } else { order__10 = linked_35.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_34, arg_37) } } else { var root_42 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any; var root_38 any = A_arbace_j2g_model_A_const_19.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref(); if linked_39 == nil { arg_45 = ifn_40.Invoke_O__O(arg_41) } else { arg_45 = linked_39.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_38, arg_41) }; if linked_43 == nil { order__10 = ifn_44.Invoke_O__O(arg_45) } else { order__10 = linked_43.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_42, arg_45) } }; var tmp1 bool; var na_46 any = n__9; var na_47 int64 = 1; if
	jrt.Long_InstanceOf(na_46) { var n0_48 int64 = jrt.NN(jrt.Long_Cast(na_46)).LongValue__J(); var n1_49 int64 = na_47; tmp1 = n0_48 <= n1_49 } else { tmp1 = lang.Numbers_Lte_O_J__Z_NoInit(na_46, na_47) }; if tmp1 {
		var root_51 any = A_arbace_j2g_model_A_const_20.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = f__1; var arg_55 any = xs__7; if linked_52 == nil { return ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { return linked_52.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) } } else {
//line :49:1
			var res__11 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(cnt__8).Ref()).Ref(); var last_i__12 any; var root_56 any = A_arbace_j2g_model_A_const_21.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_58 lang.IFn


			if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = order__10; if linked_57 == nil { last_i__12 = ifn_58.Invoke_O__O(arg_59) } else { last_i__12 = linked_57.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_56, arg_59) }
//line :49:1
			var ___13 any; var tmp2 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](res__11, jrt.Object_class.ArrayClass()); var tmp3 int32 = lang.RT_IntCast_O__I_NoInit(last_i__12); var tmp4 any; var root_65 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_67 lang.IFn; _ = ___13



			if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any; var root_61 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var tmp5 any = A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(f__1, last_i__12, xs__7); var tmp6 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class = fncls__60d; tmp6 = fncls__60d } else { tmp6 = fncls__60 }; arg_64 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_62 == nil { arg_68 = ifn_63.Invoke_O__O(arg_64) } else { arg_68 = linked_62.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_61, arg_64) }; if linked_66 == nil { tmp4 = ifn_67.Invoke_O__O(arg_68) } else { tmp4 = linked_66.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_65, arg_68) }; ___13 = lang.RT_Aset_O1_I_O__O_NoInit(tmp2, tmp3, tmp4)
//line :49:1
			var next_i__14 any; var root_69 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_71 lang.IFn




			if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = A_arbace_j2g_model_A_const_24; if linked_70 == nil { next_i__14 = ifn_71.Invoke_O__O(arg_72) } else { next_i__14 = linked_70.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_69, arg_72) }
//line :49:1
			var work__15 any; var tmp7 any = A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(cnt__8, order__10, f__1, next_i__14, xs__7, res__11); var tmp8 *jrt.Class
			var fncls__83 /*line :49:1*/*jrt.Class = A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class





			if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class = fncls__83d; tmp8 = fncls__83d } else { tmp8 = fncls__83 }; work__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :49:1
			var ws__16 any; var root_95 any = A_arbace_j2g_model_A_const_27.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_97 lang.IFn











			if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_90 any = A_arbace_j2g_model_A_const_28.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_repeatedly_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = n__9; var arg_94 any; var tmp9 any = A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(work__15); var tmp10 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class = fncls__89d; tmp10 = fncls__89d } else { tmp10 = fncls__89 }; arg_94 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); if linked_91 == nil { arg_98 = ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { arg_98 = linked_91.(*aot_arbace_core.A_arbace_core_repeatedly_A).Invoke_O_O_O__O(root_90, arg_93, arg_94) }; if linked_96 == nil { ws__16 = ifn_97.Invoke_O__O(arg_98) } else { ws__16 = linked_96.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_95, arg_98) }
			var root_103 any = A_arbace_j2g_model_A_const_29.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var arg_107 any = ws__16; if linked_104 == nil { ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { linked_104.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_103, arg_106, arg_107) }
			var root_99 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = res__11; if linked_100 == nil { return ifn_101.Invoke_O__O(arg_102) } else { return linked_100.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_99, arg_102) } } }
//line :53:1
func A_arbace_j2g_model_par_mapv_fn__1479000017_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_par_mapv_fn__1479000017_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000017_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Ctor_O_O_O(c__f, c__last_i, c__xs any) { t.F_f = c__f; t.F_last_i = c__last_i; t.F_xs = c__xs }
//line :53:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000017_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_f; t.F_f = nil; tmp1 = t_; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any; var t__2 any = t.F_xs; t.F_xs = nil; tmp3 = t__2; var tmp4 any = tmp3; var tmp5 any; var t__3 any = t.F_last_i; t.F_last_i = nil; tmp5 = t__3; return tmp2.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_O__I_NoInit(tmp5))) }

func A_arbace_j2g_model_par_mapv_work__1479000019_A_New_I_O_O_O_O_O(p0 int32, p1, p2, p3, p4, p5 any) *A_arbace_j2g_model_par_mapv_work__1479000019_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_work__1479000019_A{}; t.Ctor_I_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Ctor_I_O_O_O_O_O(c__cnt int32, c__order, c__f, c__next_i, c__xs, c__res any) { t.F_cnt = c__cnt; t.F_order = c__order; t.F_f = c__f; t.F_next_i = c__next_i; t.F_xs = c__xs; t.F_res = c__res }
//line :55:1
func (t *A_arbace_j2g_model_par_mapv_work__1479000019_A) Invoke_O__O(self any) any { for { L2: for { var k__1 any; var root_73 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_75 lang.IFn
											if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = t.F_next_i; var arg_77 any = A_arbace_j2g_model_A_const_26.GetRawRoot__O(); if linked_74 == nil { k__1 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { k__1 = linked_74.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }
											var tmp1 bool; var na_78 any = k__1; var na_79 int64 = lang.Numbers_Dec_J__J_NoInit(int64(t.F_cnt)); if jrt.Long_InstanceOf(na_78) { var n0_80 int64 = jrt.NN(jrt.Long_Cast(na_78)).LongValue__J(); var n1_81 int64 = na_79; tmp1 = n0_80 < n1_81 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_78, na_79) }; if tmp1 { var tmp2 any = t.F_order; var i__2 any = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(k__1)); var tmp3 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_res, jrt.Object_class.ArrayClass()); var tmp4 lang.IFn = lang.IFn_Cast(t.F_f); var tmp5 any = t.F_xs

		lang.RT_Aset_O1_I_O__O_NoInit(tmp3, lang.RT_IntCast_O__I_NoInit(i__2), tmp4.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp5, lang.RT_IntCast_O__I_NoInit(i__2))))
		continue L2 } else {
//line :57:1
			return nil } } }; /*line :55:1*/panic("j2g: unreachable") }





func A_arbace_j2g_model_par_mapv_fn__1479000021_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_A) Invoke_O__O(self any) any { var root_85 any = A_arbace_j2g_model_A_const_22.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any; var tmp1 any = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(t.F_work); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; arg_88 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_86 == nil { return ifn_87.Invoke_O__O(arg_88) } else { return linked_86.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_85, arg_88) } }
//line :61:1
func A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_New_O(p0 any) *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Ctor_O(c__work any) { t.F_work = c__work }
//line :61:1
func (t *A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A) Invoke_O__O(self any) any { var tmp1 any; var t_ any = t.F_work; t.F_work = nil; tmp1 = t_; return lang.IFn_Cast(tmp1).Invoke__O() }





func A_arbace_j2g_model_has_QMARK__A_New() *A_arbace_j2g_model_has_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_has_QMARK__A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Ctor() {}
//line :67:1
func (t *A_arbace_j2g_model_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_113 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any; var tmp1 int64; var na_108 any; var or__1927000174__auto____3 any = flags__0; if jrt.J2g_Truth(or__1927000174__auto____3) { na_108 = or__1927000174__auto____3 } else { na_108 = A_arbace_j2g_model_A_const_31 }; var na_109 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_108); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_109) }; tmp2 = tmp3; if tmp2 { var n0_110 int64 = jrt.NN(jrt.Long_Cast(na_108)).LongValue__J(); var n1_111 int64 = jrt.NN(jrt.Long_Cast(na_109)).LongValue__J(); tmp1 = n0_110 & n1_111 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_108, na_109) }; arg_116 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_114 == nil { return ifn_115.Invoke_O__O(arg_116) } else { return linked_114.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_113, arg_116) } }

func A_arbace_j2g_model_T_A_New() *A_arbace_j2g_model_T_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_T_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_j2g_model_T_A) Ctor() {}
//line :69:1
func (t *A_arbace_j2g_model_T_A) Invoke_O__O(self any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_32; var x__1 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if lang.IDeref_InstanceOf(x__1) { var root_117 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = x__1; if linked_118 == nil { return ifn_119.Invoke_O__O(arg_120) } else { return linked_118.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_117, arg_120) } } else { return x__1 } }

func A_arbace_j2g_model_translated_QMARK__A_New() *A_arbace_j2g_model_translated_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translated_QMARK__A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_model_translated_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_124 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_121 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_j2g_model_T_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; if linked_122 == nil { arg_127 = ifn_123.Invoke__O() } else { arg_127 = linked_122.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_121) }; var arg_128 any = n__0; if linked_125 == nil { return ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { return linked_125.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } }

func A_arbace_j2g_model_j2g_static_QMARK__A_New() *A_arbace_j2g_model_j2g_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_static_QMARK__A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_model_j2g_static_QMARK__A) Invoke_O_O_O__O(self, cls__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(cls__0, Lit_31); if and__1927000168__auto____3 {





	var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(base__1, Lit_32); if and__1927000168__auto____4 {
		var root_129 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = Lit_33; if linked_130 == nil { return ifn_131.Invoke_O__O(arg_132) } else { return linked_130.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_129, arg_132) } } else {
//line :79:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_jrt_class_A_New() *A_arbace_j2g_model_jrt_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_class_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Ctor() {}
//line :82:1
func (t *A_arbace_j2g_model_jrt_class_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
}
func A_arbace_j2g_model_hand_written_QMARK__A_New() *A_arbace_j2g_model_hand_written_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hand_written_QMARK__A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_model_hand_written_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_133 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_135 lang.IFn; if


	linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = n__0; if linked_134 == nil { and__1927000168__auto____2 = ifn_135.Invoke_O__O(arg_136) } else { and__1927000168__auto____2 = linked_134.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_141 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var root_137 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = n__0; if linked_138 == nil { arg_144 = ifn_139.Invoke_O__O(arg_140) } else { arg_144 = linked_138.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_137, arg_140) }; if linked_142 == nil { return ifn_143.Invoke_O__O(arg_144) } else { return linked_142.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_141, arg_144) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_in_world_QMARK__A_New() *A_arbace_j2g_model_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_in_world_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_j2g_model_in_world_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_20); if or__1927000174__auto____2 {
											return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var root_145 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = n__0; if linked_146 == nil { or__1927000174__auto____3 = ifn_147.Invoke_O__O(arg_148) } else { or__1927000174__auto____3 = linked_146.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_145, arg_148) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 any; var root_149 any = A_arbace_j2g_model_A_const_38.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_j2g_model_jrt_class_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = n__0; if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*A_arbace_j2g_model_jrt_class_A).Invoke_O_O__O(root_149, arg_152) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }

func A_arbace_j2g_model_translatable_QMARK__A_New() *A_arbace_j2g_model_translatable_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_translatable_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_j2g_model_translatable_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var root_153 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = n__0; if linked_154 == nil { tmp1 = ifn_155.Invoke_O__O(arg_156) } else { tmp1 = linked_154.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_153, arg_156) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_reflectable_interface_QMARK__A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_161 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_163 lang.IFn; if




	linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any; var root_157 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = n__0; if linked_158 == nil { arg_164 = ifn_159.Invoke_O__O(arg_160) } else { arg_164 = linked_158.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_157, arg_160) }; if linked_162 == nil { and__1927000168__auto____2 = ifn_163.Invoke_O__O(arg_164) } else { and__1927000168__auto____2 = linked_162.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_161, arg_164) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_165 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_167 lang.IFn
		if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = n__0; var arg_169 any = Lit_57; if linked_166 == nil { or__1927000174__auto____3 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { or__1927000174__auto____3 = linked_166.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var root_170 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = n__0; var arg_174 any = Lit_58; if linked_171 == nil { or__1927000174__auto____4 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { or__1927000174__auto____4 = linked_171.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; if jrt.J2g_Truth(or__1927000174__auto____4) { and__1927000168__auto____3 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var root_175 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = n__0; var arg_179 any = Lit_59; if linked_176 == nil { or__1927000174__auto____5 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { or__1927000174__auto____5 = linked_176.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____3 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_180 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = n__0; var arg_184 any = Lit_60; if linked_181 == nil { or__1927000174__auto____6 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { or__1927000174__auto____6 = linked_181.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; if jrt.J2g_Truth(or__1927000174__auto____6) { and__1927000168__auto____3 = or__1927000174__auto____6 } else {
			var root_185 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = n__0; var arg_189 any = Lit_61; if linked_186 == nil { and__1927000168__auto____3 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { and__1927000168__auto____3 = linked_186.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_185, arg_188, arg_189) } } } } }
//line :105:1
		if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_195 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_197 lang.IFn


			if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_190 any = A_arbace_j2g_model_A_const_41.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = n__0; var arg_194 any = Lit_62; if linked_191 == nil { arg_198 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { arg_198 = linked_191.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; if linked_196 == nil { and__1927000168__auto____4 = ifn_197.Invoke_O__O(arg_198) } else { and__1927000168__auto____4 = linked_196.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_195, arg_198) }
//line :105:1
			if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_203 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_205 lang.IFn



				if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any; var root_199 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = n__0; if linked_200 == nil { arg_206 = ifn_201.Invoke_O__O(arg_202) } else { arg_206 = linked_200.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_199, arg_202) }; if linked_204 == nil { and__1927000168__auto____5 = ifn_205.Invoke_O__O(arg_206) } else { and__1927000168__auto____5 = linked_204.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_203, arg_206) }
//line :105:1
				if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_207 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_209 lang.IFn




					if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = n__0; if linked_208 == nil { and__1927000168__auto____6 = ifn_209.Invoke_O__O(arg_210) } else { and__1927000168__auto____6 = linked_208.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_207, arg_210) }
//line :105:1
					if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_220 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_222 lang.IFn






						if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any; var root_215 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_211 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = n__0; if linked_212 == nil { tmp2 = ifn_213.Invoke_O__O(arg_214) } else { tmp2 = linked_212.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_211, arg_214) }; arg_218 = tmp1.Invoke_O__O(tmp2); var arg_219 any = A_arbace_j2g_model_A_const_47; if linked_216 == nil { arg_223 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { arg_223 = linked_216.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; if linked_221 == nil { and__1927000168__auto____7 = ifn_222.Invoke_O__O(arg_223) } else { and__1927000168__auto____7 = linked_221.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_220, arg_223) }
//line :105:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_228 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_230 lang.IFn









							if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp4 any; var root_224 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = n__0; if linked_225 == nil { tmp4 = ifn_226.Invoke_O__O(arg_227) } else { tmp4 = linked_225.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_224, arg_227) }; arg_231 = tmp3.Invoke_O__O(tmp4); if linked_229 == nil { and__1927000168__auto____8 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____8 = linked_229.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_228, arg_231) }
//line :105:1
							if jrt.J2g_Truth(and__1927000168__auto____8) {










								var root_245 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var tmp5 any = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New(); var tmp6 *jrt.Class; var fncls__240 *jrt.Class = A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class; if fncls__240 == nil { var fncls__240d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class = fncls__240d; tmp6 = fncls__240d } else { tmp6 = fncls__240 }; arg_248 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_249 any; var tmp7 *lang.Keyword = A_arbace_j2g_model_A_const_53; var tmp8 any; var root_241 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = n__0; if linked_242 == nil { tmp8 = ifn_243.Invoke_O__O(arg_244) } else { tmp8 = linked_242.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_241, arg_244) }; arg_249 = tmp7.Invoke_O__O(tmp8); if linked_246 == nil { return ifn_247.Invoke_O_O__O(arg_248, arg_249) } else { return linked_246.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_245, arg_248, arg_249) } } else {
//line :105:1
									return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }










func A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_New() *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A) Invoke_O_O__O(self, p1__1479000034_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_232 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = p1__1479000034_SHARP___1; if linked_233 == nil { or__1927000174__auto____2 = ifn_234.Invoke_O__O(arg_235) } else { or__1927000174__auto____2 = linked_233.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_232, arg_235) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_236 any = A_arbace_j2g_model_A_const_52.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = p1__1479000034_SHARP___1; if linked_237 == nil { return ifn_238.Invoke_O__O(arg_239) } else { return linked_237.(*A_arbace_j2g_model_reflectable_interface_QMARK__A).Invoke_O_O__O(root_236, arg_239) } } }

func A_arbace_j2g_model_reflected_QMARK__A_New() *A_arbace_j2g_model_reflected_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_reflected_QMARK__A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_model_reflected_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var and__1927000168__auto____2 any; var root_250 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_252 lang.IFn; if


	linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = n__0; if linked_251 == nil { and__1927000168__auto____2 = ifn_252.Invoke_O__O(arg_253) } else { and__1927000168__auto____2 = linked_251.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_258 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any; var root_254 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = n__0; if linked_255 == nil { arg_261 = ifn_256.Invoke_O__O(arg_257) } else { arg_261 = linked_255.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_254, arg_257) }; if linked_259 == nil { return ifn_260.Invoke_O__O(arg_261) } else { return linked_259.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_258, arg_261) } } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_model_info_A_New() *A_arbace_j2g_model_info_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_info_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_j2g_model_info_A) Ctor() {}
//line :123:1
func (t *A_arbace_j2g_model_info_A) Invoke_O_O__O(self, n__0 any) any { var root_262 any = A_arbace_j2g_model_A_const_43.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_classes_env.A_arbace_classes_env_info_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = n__0; if linked_263 == nil { return ifn_264.Invoke_O__O(arg_265) } else { return linked_263.(*aot_arbace_classes_env.A_arbace_classes_env_info_A).Invoke_O_O__O(root_262, arg_265) } }
func A_arbace_j2g_model_interface_QMARK__A_New() *A_arbace_j2g_model_interface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_interface_QMARK__A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Ctor() {}
//line :124:1
func (t *A_arbace_j2g_model_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_266 any = A_arbace_j2g_model_A_const_44.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = n__0; if linked_267 == nil { return ifn_268.Invoke_O__O(arg_269) } else { return linked_267.(*aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_266, arg_269) } }

func A_arbace_j2g_model_desc_classes_A_New() *A_arbace_j2g_model_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_classes_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_model_desc_classes_A) Invoke_O_O__O(self, d__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(d__0, nil) { return nil } else { var tmp1 any; var root_270 any = A_arbace_j2g_model_A_const_54.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_272 lang.IFn
		if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = d__0; if linked_271 == nil { tmp1 = ifn_272.Invoke_O__O(arg_273) } else { tmp1 = linked_271.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_270, arg_273) }
//line :129:1
		if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var root_274 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_276 lang.IFn

			if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = d__0; if linked_275 == nil { tmp2 = ifn_276.Invoke_O__O(arg_277) } else { tmp2 = linked_275.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_274, arg_277) }
//line :129:1
			if jrt.J2g_Truth(tmp2) {

				var root_287 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any; var root_282 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = d__0; var arg_286 any; var root_278 any = A_arbace_j2g_model_A_const_58.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_classes_types.A_arbace_classes_types_array_dims_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = d__0; if linked_279 == nil { arg_286 = ifn_280.Invoke_O__O(arg_281) } else { arg_286 = linked_279.(*aot_arbace_classes_types.A_arbace_classes_types_array_dims_A).Invoke_O_O__O(root_278, arg_281) }; if linked_283 == nil { arg_290 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_290 = linked_283.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if linked_288 == nil { return ifn_289.Invoke_O__O(arg_290) } else { return linked_288.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_287, arg_290) } } else {
//line :129:1
					var tmp3 any; var root_291 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_293 lang.IFn


					if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = d__0; if linked_292 == nil { tmp3 = ifn_293.Invoke_O__O(arg_294) } else { tmp3 = linked_292.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_291, arg_294) }
//line :129:1
					if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_295 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_297 lang.IFn


						if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = d__0; if linked_296 == nil { tmp4 = ifn_297.Invoke_O__O(arg_298) } else { tmp4 = linked_296.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_295, arg_298) }
//line :129:1
						return lang.Tuple_Create_O__IPersistentVector(tmp4) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil
						}
						}
				}
		}
	}
}



func A_arbace_j2g_model_method_desc_classes_A_New() *A_arbace_j2g_model_method_desc_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_method_desc_classes_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_model_method_desc_classes_A) Invoke_O_O__O(self, desc__0 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_299 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_301 lang.IFn; if
											linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = desc__0; if linked_300 == nil { tmp1 = ifn_301.Invoke_O__O(arg_302) } else { tmp1 = linked_300.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_299, arg_302) }; if jrt.J2g_Truth(tmp1) { or__1927000174__auto____2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Get_O__O(desc__0) } else { or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var vec__1479000042__3 any; var root_303 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_305 lang.IFn
												if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = desc__0; if linked_304 == nil { vec__1479000042__3 = ifn_305.Invoke_O__O(arg_306) } else { vec__1479000042__3 = linked_304.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_303, arg_306) }
//line :140:1
		var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000042__3, lang.RT_IntCast_J__I_NoInit(1), nil); var v__6 any; var root_317 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_319 lang.IFn

		if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_65.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var tmp4 any; var root_307 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = r__5; var arg_311 any = ps__4; if linked_308 == nil { tmp4 = ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { tmp4 = linked_308.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_307, arg_310, arg_311) }; arg_320 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_318 == nil { v__6 = ifn_319.Invoke_O__O(arg_320) } else { v__6 = linked_318.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_317, arg_320) }
		var tmp5 any; var root_321 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = desc__0; if linked_322 == nil { tmp5 = ifn_323.Invoke_O__O(arg_324) } else { tmp5 = linked_322.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(tmp5) { jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_j2g_model_A_const_63.GetRawRoot__O())).Put_O_O__O(desc__0, v__6) }
//line :140:1
		return v__6 } }





func A_arbace_j2g_model_erased_desc_QMARK__A_New() *A_arbace_j2g_model_erased_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__A{}; t.Ctor(); return t }
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Ctor() {}
//line :146:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_325 any = A_arbace_j2g_model_A_const_62.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_327 lang.IFn; if




	linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = d__0; if linked_326 == nil { and__1927000168__auto____2 = ifn_327.Invoke_O__O(arg_328) } else { and__1927000168__auto____2 = linked_326.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_325, arg_328) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var e__3 any; var tmp1 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class
		if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class = fncls__337d; tmp2 = fncls__337d } else { tmp2 = fncls__337 }; e__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :151:1
		var and__1927000168__auto____4 any; var root_338 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_340 lang.IFn

		if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = e__3; if linked_339 == nil { and__1927000168__auto____4 = ifn_340.Invoke_O__O(arg_341) } else { and__1927000168__auto____4 = linked_339.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var n__5 any; var root_342 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_344 lang.IFn
			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = e__3; if linked_343 == nil { n__5 = ifn_344.Invoke_O__O(arg_345) } else { n__5 = linked_343.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_342, arg_345) }
//line :153:1
			var and__1927000168__auto____6 any; var root_350 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_352 lang.IFn

			if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var root_346 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = n__5; if linked_347 == nil { arg_353 = ifn_348.Invoke_O__O(arg_349) } else { arg_353 = linked_347.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_346, arg_349) }; if linked_351 == nil { and__1927000168__auto____6 = ifn_352.Invoke_O__O(arg_353) } else { and__1927000168__auto____6 = linked_351.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_350, arg_353) }; if jrt.J2g_Truth(and__1927000168__auto____6) {
				var root_360 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any; var tmp3 any = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(n__5); var tmp4 *jrt.Class; var fncls__359 *jrt.Class = A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class; if fncls__359 == nil { var fncls__359d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class = fncls__359d; tmp4 = fncls__359d } else { tmp4 = fncls__359 }; arg_363 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_69; var arg_364 any = tmp5.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); if linked_361 == nil { return ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { return linked_361.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) } } else {
//line :155:1
					return and__1927000168__auto____6 } } else {
//line :153:1
						return and__1927000168__auto____4 } } else {
//line :151:1
							return and__1927000168__auto____2 } }
func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :152:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; L1: for { var tmp1 any; var root_329 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = d__1; if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_329, arg_332) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_333 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = d__1; if linked_334 == nil { tmp2 = ifn_335.Invoke_O__O(arg_336) } else { tmp2 = linked_334.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_333, arg_336) }; d__1 = tmp2; continue L1 } else { return d__1 } } }; panic("j2g: unreachable") }



func A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_New_O(p0 any) *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A{}; t.Ctor_O(p0); return t }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :156:1
func (t *A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A) Invoke_O_O__O(self, p1__1479000046_SHARP___1 any) any { var root_354 any = A_arbace_j2g_model_A_const_40.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = t.F_n; var arg_358 any = p1__1479000046_SHARP___1; if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } }

func A_arbace_j2g_model_desc_in_world_QMARK__A_New() *A_arbace_j2g_model_desc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_desc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_j2g_model_desc_in_world_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var root_369 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_373 any; var root_365 any = A_arbace_j2g_model_A_const_56.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, A_arbace_j2g_model_desc_classes_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = d__0; if linked_366 == nil { arg_373 = ifn_367.Invoke_O__O(arg_368) } else { arg_373 = linked_366.(*A_arbace_j2g_model_desc_classes_A).Invoke_O_O__O(root_365, arg_368) }; if linked_370 == nil { return ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { return linked_370.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_369, arg_372, arg_373) } }
func A_arbace_j2g_model_mdesc_in_world_QMARK__A_New() *A_arbace_j2g_model_mdesc_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_mdesc_in_world_QMARK__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Ctor() {}
//line :159:1
func (t *A_arbace_j2g_model_mdesc_in_world_QMARK__A) Invoke_O_O__O(self, desc__0 any) any { var root_378 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_382 any; var root_374 any = A_arbace_j2g_model_A_const_70.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, A_arbace_j2g_model_method_desc_classes_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = desc__0; if linked_375 == nil { arg_382 = ifn_376.Invoke_O__O(arg_377) } else { arg_382 = linked_375.(*A_arbace_j2g_model_method_desc_classes_A).Invoke_O_O__O(root_374, arg_377) }; if linked_379 == nil { return ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { return linked_379.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_378, arg_381, arg_382) } }




func A_arbace_j2g_model_go_name_A_New() *A_arbace_j2g_model_go_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_name_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Ctor() {}
//line :164:1
func (t *A_arbace_j2g_model_go_name_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; if




	jrt.J2g_Truth(A_arbace_j2g_model_A_const_33.Get__O()) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_37; var temp__1927000414__auto____2 any = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____2) { var jc__3 any = temp__1927000414__auto____2; var tmp2 any; var root_383 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_385 lang.IFn
			if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = n__0; if linked_384 == nil { tmp2 = ifn_385.Invoke_O__O(arg_386) } else { tmp2 = linked_384.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_383, arg_386) }; if jrt.J2g_Truth(tmp2) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = A_arbace_j2g_model_A_const_71.Invoke_O__O(jc__3) } } else {
//line :170:1
				or__1927000174__auto____2 = nil } } else {
//line :169:1
					or__1927000174__auto____2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {


						var root_387 any = A_arbace_j2g_model_A_const_72.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = n__0; if linked_388 == nil { return ifn_389.Invoke_O__O(arg_390) } else { return linked_388.(*aot_arbace_j2g_names.A_arbace_j2g_names_go_class_name_A).Invoke_O_O__O(root_387, arg_390) } } }
func A_arbace_j2g_model_pkg_A_New() *A_arbace_j2g_model_pkg_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pkg_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Ctor() {}
//line :173:1
func (t *A_arbace_j2g_model_pkg_A) Invoke_O_O__O(self, n__0 any) any { var root_391 any = A_arbace_j2g_model_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = n__0; if linked_392 == nil { return ifn_393.Invoke_O__O(arg_394) } else { return linked_392.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_of_A).Invoke_O_O__O(root_391, arg_394) } }

func A_arbace_j2g_model_abstract_QMARK__A_New() *A_arbace_j2g_model_abstract_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_QMARK__A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Ctor() {}
//line :175:1
func (t *A_arbace_j2g_model_abstract_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_399 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_395 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, A_arbace_j2g_model_info_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = n__0; if linked_396 == nil { tmp2 = ifn_397.Invoke_O__O(arg_398) } else { tmp2 = linked_396.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_395, arg_398) }; arg_402 = tmp1.Invoke_O__O(tmp2); var arg_403 any = A_arbace_j2g_model_A_const_75; if linked_400 == nil { return ifn_401.Invoke_O_O__O(arg_402, arg_403) } else { return linked_400.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_399, arg_402, arg_403) } }
func A_arbace_j2g_model_final_QMARK__A_New() *A_arbace_j2g_model_final_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_final_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_j2g_model_final_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_408 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_46; var tmp2 any; var root_404 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_j2g_model_info_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = n__0; if linked_405 == nil { tmp2 = ifn_406.Invoke_O__O(arg_407) } else { tmp2 = linked_405.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_404, arg_407) }; arg_411 = tmp1.Invoke_O__O(tmp2); var arg_412 any = A_arbace_j2g_model_A_const_76; if linked_409 == nil { return ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { return linked_409.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_408, arg_411, arg_412) } }

func A_arbace_j2g_model_subclasses_A_New() *A_arbace_j2g_model_subclasses_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_subclasses_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Ctor() {}
//line :178:1
func (t *A_arbace_j2g_model_subclasses_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_77; return lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())).Invoke__O(), n__0)
}
func A_arbace_j2g_model_make_subclass_index_A_New() *A_arbace_j2g_model_make_subclass_index_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_A{}; t.Ctor(); return t }
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Ctor() {}
//line :183:1
func (t *A_arbace_j2g_model_make_subclass_index_A) Invoke_O_O__O(self, w__0 any) any { var cache__2 any; var root_413 any = A_arbace_j2g_model_A_const_23.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_415 lang.IFn; if
											linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any; if linked_414 == nil { cache__2 = ifn_415.Invoke_O__O(arg_416) } else { cache__2 = linked_414.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_413, arg_416) }; var tmp1 any =
											A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(cache__2, w__0); var tmp2 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class = fncls__474d; tmp2 = fncls__474d } else { tmp2 = fncls__474 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :185:1
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Ctor_O_O(c__cache, c__w any) { t.F_cache = c__cache; t.F_w = c__w }
//line :185:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_A) Invoke_O__O(self any) any { var or__1927000174__auto____1 any; var root_417 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_419 lang.IFn; if
												linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = t.F_cache; if linked_418 == nil { or__1927000174__auto____1 = ifn_419.Invoke_O__O(arg_420) } else { or__1927000174__auto____1 = linked_418.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else {
													var root_469 any = A_arbace_j2g_model_A_const_78.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = t.F_cache; var arg_473 any; var root_465 any = A_arbace_j2g_model_A_const_86.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_467 lang.IFn
													if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_87.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_model_A_const_33, t.F_w); if linked_466 == nil { ifn_467.Invoke_O__O(arg_468) } else { linked_466.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_465, arg_468) }; var tmp1 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(t.F_w); var tmp2 *jrt.Class; var fncls__459 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class; if fncls__459 == nil { var fncls__459d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class = fncls__459d; tmp2 = fncls__459d } else { tmp2 = fncls__459 }; arg_473 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :187:1
		if linked_470 == nil { return ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { return linked_470.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_469, arg_472, arg_473) } } }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_New_O(p0 any) *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Ctor_O(c__w any) { t.F_w = c__w }
//line :188:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
														{ var root_450 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var tmp2 any = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New(); var tmp3 *jrt.Class; var fncls__437 *jrt.Class = A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class; if fncls__437 == nil { var fncls__437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class = fncls__437d; tmp3 = fncls__437d } else { tmp3 = fncls__437 }; arg_453 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_454 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_455 any; var root_445 any = A_arbace_j2g_model_A_const_83.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_447 lang.IFn


		if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var root_438 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_j2g_model_T_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; if linked_439 == nil { arg_448 = ifn_440.Invoke__O() } else { arg_448 = linked_439.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_438) }; var arg_449 any; var root_441 any = A_arbace_j2g_model_A_const_84.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_37; var tmp5 any; var t_ any = t.F_w; t.F_w = nil; tmp5 = t_; arg_444 = tmp4.Invoke_O__O(tmp5); if linked_442 == nil { arg_449 = ifn_443.Invoke_O__O(arg_444) } else { arg_449 = linked_442.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_441, arg_444) }; if linked_446 == nil { arg_455 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { arg_455 = linked_446.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }
//line :189:1
		if linked_451 == nil { tmp1 = ifn_452.Invoke_O_O_O__O(arg_453, arg_454, arg_455) } else { tmp1 = linked_451.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_450, arg_453, arg_454, arg_455) } }
//line :188:1
	return nil }(); var root_456 any = A_arbace_j2g_model_A_const_85.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; if linked_457 == nil { ifn_458.Invoke__O() } else { linked_457.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_456) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
func A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_New() *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A) Invoke_O_O_O__O(self, m__1, c__2 any) any { var s__3 any; var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_421 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_j2g_model_info_A_fn_class); var ifn_423 lang.IFn; if
																		linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = c__2; if linked_422 == nil { tmp2 = ifn_423.Invoke_O__O(arg_424) } else { tmp2 = linked_422.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_421, arg_424) }; s__3 = tmp1.Invoke_O__O(tmp2); if
																		jrt.J2g_Truth(s__3) { var root_430 any = A_arbace_j2g_model_A_const_81.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = m__1; var arg_434 any = s__3; var arg_435 any; var root_425 any = A_arbace_j2g_model_A_const_82.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var arg_429 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_426 == nil { arg_435 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { arg_435 = linked_426.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; var arg_436 any = c__2; if linked_431 == nil { return ifn_432.Invoke_O_O_O_O__O(arg_433, arg_434, arg_435, arg_436) } else { return linked_431.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_430, arg_433, arg_434, arg_435, arg_436) } } else { return m__1 } }















func A_arbace_j2g_model_leaf_QMARK__A_New() *A_arbace_j2g_model_leaf_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_leaf_QMARK__A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Ctor() {}
//line :207:1
func (t *A_arbace_j2g_model_leaf_QMARK__A) Invoke_O_O__O(self, n__0 any) any {




	if lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_20) { return jrt.Boolean_FALSE.Ref() } else { var tmp1 any; var root_475 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_477 lang.IFn

		if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = n__0; if linked_476 == nil { tmp1 = ifn_477.Invoke_O__O(arg_478) } else { tmp1 = linked_476.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_475, arg_478) }
//line :212:1
		if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { var tmp2 any; var root_479 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_481 lang.IFn


			if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = n__0; if linked_480 == nil { tmp2 = ifn_481.Invoke_O__O(arg_482) } else { tmp2 = linked_480.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_479, arg_482) }
//line :212:1
			if jrt.J2g_Truth(tmp2) {


				var root_492 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any; var root_487 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_90; var tmp4 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_490 any = tmp3.Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_491 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_18); var tmp6 any; var root_483 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, A_arbace_j2g_model_go_name_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = n__0; if linked_484 == nil { tmp6 = ifn_485.Invoke_O__O(arg_486) } else { tmp6 = linked_484.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_483, arg_486) }; arg_491 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_488 == nil { arg_495 = ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { arg_495 = linked_488.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_487, arg_490, arg_491) }; if linked_493 == nil { return ifn_494.Invoke_O__O(arg_495) } else { return linked_493.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_492, arg_495) } } else {
//line :212:1
					if A_arbace_j2g_model_A_const_60 != nil { var and__1927000168__auto____2 any; var root_500 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_502 lang.IFn



						if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any; var root_496 any = A_arbace_j2g_model_A_const_93.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, A_arbace_j2g_model_abstract_QMARK__A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = n__0; if linked_497 == nil { arg_503 = ifn_498.Invoke_O__O(arg_499) } else { arg_503 = linked_497.(*A_arbace_j2g_model_abstract_QMARK__A).Invoke_O_O__O(root_496, arg_499) }; if linked_501 == nil { and__1927000168__auto____2 = ifn_502.Invoke_O__O(arg_503) } else { and__1927000168__auto____2 = linked_501.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_500, arg_503) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_508 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any; var root_504 any = A_arbace_j2g_model_A_const_94.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, A_arbace_j2g_model_subclasses_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = n__0; if linked_505 == nil { arg_511 = ifn_506.Invoke_O__O(arg_507) } else { arg_511 = linked_505.(*A_arbace_j2g_model_subclasses_A).Invoke_O_O__O(root_504, arg_507) }; if linked_509 == nil { and__1927000168__auto____3 = ifn_510.Invoke_O__O(arg_511) } else { and__1927000168__auto____3 = linked_509.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_508, arg_511) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
							var root_520 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_95.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.J2g_Truth(and__1927000168__auto____4) { var root_516 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var root_512 any = A_arbace_j2g_model_A_const_96.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = n__0; if linked_513 == nil { arg_519 = ifn_514.Invoke_O__O(arg_515) } else { arg_519 = linked_513.(*A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_512, arg_515) }; if linked_517 == nil { arg_523 = ifn_518.Invoke_O__O(arg_519) } else { arg_523 = linked_517.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_516, arg_519) } } else { arg_523 = and__1927000168__auto____4 }; if linked_521 == nil { return ifn_522.Invoke_O__O(arg_523) } else { return linked_521.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_520, arg_523) } } else {
//line :216:1
								return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } else {
//line :212:1
									return nil
								}
				}
		}
	}
}




func A_arbace_j2g_model_qualify_A_New() *A_arbace_j2g_model_qualify_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_qualify_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_j2g_model_qualify_A) Ctor() {}
//line :222:1
func (t *A_arbace_j2g_model_qualify_A) Invoke_O_O_O_O__O(self, from__0, of__1, ident__2 any) any {


	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(from__0, of__1); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Identical_O_O__Z_NoInit(from__0, nil) }; if tmp1 { var root_524 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = ident__2; if linked_525 == nil { return ifn_526.Invoke_O__O(arg_527) } else { return linked_525.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_524, arg_527) } } else { var root_532 any = A_arbace_j2g_model_A_const_97.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any; var root_528 any = A_arbace_j2g_model_A_const_98.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = of__1; if linked_529 == nil { arg_535 = ifn_530.Invoke_O__O(arg_531) } else { arg_535 = linked_529.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_name_A).Invoke_O_O__O(root_528, arg_531) }; var arg_536 any = ident__2; if linked_533 == nil { return ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { return linked_533.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_532, arg_535, arg_536)
	} } }
func A_arbace_j2g_model_class_sym_A_New() *A_arbace_j2g_model_class_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_class_sym_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_j2g_model_class_sym_A) Ctor() {}
//line :227:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O_O__O(self, from__0, n__1, suffix__2 any) any {


	var root_545 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, A_arbace_j2g_model_qualify_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = from__0; var arg_549 any; var root_537 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_j2g_model_pkg_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = n__1; if linked_538 == nil { arg_549 = ifn_539.Invoke_O__O(arg_540) } else { arg_549 = linked_538.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_537, arg_540) }; var arg_550 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_541 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, A_arbace_j2g_model_go_name_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = n__1; if linked_542 == nil { tmp2 = ifn_543.Invoke_O__O(arg_544) } else { tmp2 = linked_542.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_541, arg_544) }; arg_550 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, suffix__2)).Ref(); if linked_546 == nil { return ifn_547.Invoke_O_O_O__O(arg_548, arg_549, arg_550) } else { return linked_546.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_545, arg_548, arg_549, arg_550) } }
//line :227:1
func (t *A_arbace_j2g_model_class_sym_A) Invoke_O_O_O__O(self, from__0, n__1 any) any {

	var root_551 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = from__0; var arg_555 any = n__1; var arg_556 any = Lit_8; if linked_552 == nil { return ifn_553.Invoke_O_O_O__O(arg_554, arg_555, arg_556) } else { return linked_552.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_551, arg_554, arg_555, arg_556)
	}
}
func A_arbace_j2g_model_jrt_sym_A_New() *A_arbace_j2g_model_jrt_sym_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_jrt_sym_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_j2g_model_jrt_sym_A) Ctor() {}
//line :232:1
func (t *A_arbace_j2g_model_jrt_sym_A) Invoke_O_O_O__O(self, from__0, ident__1 any) any { var root_557 any = A_arbace_j2g_model_A_const_99.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, A_arbace_j2g_model_qualify_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = from__0; var arg_561 any = A_arbace_j2g_model_A_const_91; var arg_562 any = ident__1; if linked_558 == nil { return ifn_559.Invoke_O_O_O__O(arg_560, arg_561, arg_562) } else { return linked_558.(*A_arbace_j2g_model_qualify_A).Invoke_O_O_O_O__O(root_557, arg_560, arg_561, arg_562) } }






func A_arbace_j2g_model_go_type_A_New() *A_arbace_j2g_model_go_type_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_type_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_j2g_model_go_type_A) Ctor() {}
//line :239:1
func (t *A_arbace_j2g_model_go_type_A) Invoke_O_O_O__O(self, from__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, A_arbace_j2g_model_A_const_102) { return A_arbace_j2g_model_A_const_103 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()).Invoke_O__O(d__1)) {

		return lang.IFn_Cast(A_arbace_j2g_model_A_const_104.GetRawRoot__O()).Invoke_O__O(d__1) } else {
//line :242:1
			if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_15) { return nil } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_16) { return A_arbace_j2g_model_A_const_105 } else { var tmp1 any; var root_563 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_565 lang.IFn




				if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = d__1; if linked_564 == nil { tmp1 = ifn_565.Invoke_O__O(arg_566) } else { tmp1 = linked_564.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_563, arg_566) }
//line :242:1
				if jrt.J2g_Truth(tmp1) { var e__3 any; var root_567 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_569 lang.IFn




					if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = d__1; if linked_568 == nil { e__3 = ifn_569.Invoke_O__O(arg_570) } else { e__3 = linked_568.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_567, arg_570) }
					var tmp2 any; var root_571 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = e__3; if linked_572 == nil { tmp2 = ifn_573.Invoke_O__O(arg_574) } else { tmp2 = linked_572.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_571, arg_574) }; if jrt.J2g_Truth(tmp2) {
						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_model_A_const_113; var tmp5 any; var root_619 any = A_arbace_j2g_model_A_const_114.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = from__0; var arg_623 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_115.GetRawRoot__O()).Invoke_O__O(e__3); if linked_620 == nil { tmp5 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { tmp5 = linked_620.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_model_A_const_116; var tmp8 any; var root_624 any = A_arbace_j2g_model_A_const_114.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, A_arbace_j2g_model_jrt_sym_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = from__0; var arg_628 any = Lit_17; if linked_625 == nil { tmp8 = ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { tmp8 = linked_625.(*A_arbace_j2g_model_jrt_sym_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }; return tmp6.Invoke_O_O__O(tmp7, tmp8) } } else {
//line :242:1
								var tmp9 any; var root_575 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_577 lang.IFn








								if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = d__1; if linked_576 == nil { tmp9 = ifn_577.Invoke_O__O(arg_578) } else { tmp9 = linked_576.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_575, arg_578) }
//line :242:1
								if jrt.J2g_Truth(tmp9) { var n__3 any; var root_579 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_581 lang.IFn









									if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = d__1; if linked_580 == nil { n__3 = ifn_581.Invoke_O__O(arg_582) } else { n__3 = linked_580.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_579, arg_582) }
									var tmp10 any; var root_587 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_589 lang.IFn
									if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any; var root_583 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = n__3; if linked_584 == nil { arg_590 = ifn_585.Invoke_O__O(arg_586) } else { arg_590 = linked_584.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_583, arg_586) }; if linked_588 == nil { tmp10 = ifn_589.Invoke_O__O(arg_590) } else { tmp10 = linked_588.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_587, arg_590) }
//line :253:1
									if jrt.J2g_Truth(tmp10) { return A_arbace_j2g_model_A_const_108 } else { var tmp11 any; var root_591 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_593 lang.IFn

										if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = n__3; if linked_592 == nil { tmp11 = ifn_593.Invoke_O__O(arg_594) } else { tmp11 = linked_592.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_591, arg_594) }
//line :253:1
										if jrt.J2g_Truth(tmp11) {

											var root_595 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = from__0; var arg_599 any = n__3; if linked_596 == nil { return ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { return linked_596.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_595, arg_598, arg_599) } } else {
//line :253:1
												var tmp12 any; var root_600 any = A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_602 lang.IFn


												if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = n__3; if linked_601 == nil { tmp12 = ifn_602.Invoke_O__O(arg_603) } else { tmp12 = linked_601.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_600, arg_603) }
//line :253:1
												if jrt.J2g_Truth(tmp12) {


													var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_107.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_model_A_const_117; var tmp15 any; var root_629 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = from__0; var arg_633 any = n__3; if linked_630 == nil { tmp15 = ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { tmp15 = linked_630.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_629, arg_632, arg_633) }; return tmp13.Invoke_O_O__O(tmp14, tmp15) } else {
//line :253:1
														if A_arbace_j2g_model_A_const_60 != nil {



															var root_604 any = A_arbace_j2g_model_A_const_101.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, A_arbace_j2g_model_class_sym_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = from__0; var arg_608 any = n__3; var arg_609 any = Lit_18; if linked_605 == nil { return ifn_606.Invoke_O_O_O__O(arg_607, arg_608, arg_609) } else { return linked_605.(*A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_604, arg_607, arg_608, arg_609) } } else {
//line :253:1
																return nil } } } } } else {
//line :242:1
																	if A_arbace_j2g_model_A_const_60 != nil { var tmp16 any; var root_614 any = A_arbace_j2g_model_A_const_110.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_616 lang.IFn















																		if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_model_A_const_111.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); var arg_618 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_112, d__1)); if linked_615 == nil { tmp16 = ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { tmp16 = linked_615.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }
//line :242:1
																		panic(jrt.Thrown(jrt.Throwable_Cast(tmp16))) } else { return nil
																		}
																}
							}
			}
			}
		}
	}
}









func A_arbace_j2g_model_pointer_desc_QMARK__A_New() *A_arbace_j2g_model_pointer_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pointer_desc_QMARK__A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Ctor() {}
//line :260:1
func (t *A_arbace_j2g_model_pointer_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_634 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = d__0; if linked_635 == nil { tmp1 = ifn_636.Invoke_O__O(arg_637) } else { tmp1 = linked_635.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_634, arg_637) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_638 any = A_arbace_j2g_model_A_const_59.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_640 lang.IFn
		if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = d__0; if linked_639 == nil { tmp2 = ifn_640.Invoke_O__O(arg_641) } else { tmp2 = linked_639.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_638, arg_641) }
//line :263:1
		if jrt.J2g_Truth(tmp2) { var n__2 any; var root_642 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_644 lang.IFn
			if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = d__0; if linked_643 == nil { n__2 = ifn_644.Invoke_O__O(arg_645) } else { n__2 = linked_643.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_642, arg_645) }
//line :263:1
			var and__1927000168__auto____3 any; var root_646 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_648 lang.IFn

			if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = n__2; if linked_647 == nil { and__1927000168__auto____3 = ifn_648.Invoke_O__O(arg_649) } else { and__1927000168__auto____3 = linked_647.(*A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_654 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any; var root_650 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = n__2; if linked_651 == nil { arg_657 = ifn_652.Invoke_O__O(arg_653) } else { arg_657 = linked_651.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_650, arg_653) }; if linked_655 == nil { and__1927000168__auto____4 = ifn_656.Invoke_O__O(arg_657) } else { and__1927000168__auto____4 = linked_655.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_654, arg_657) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_658 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = n__2; var arg_662 any = Lit_20; if linked_659 == nil { and__1927000168__auto____5 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { and__1927000168__auto____5 = linked_659.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_663 any = A_arbace_j2g_model_A_const_109.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = n__2; if linked_664 == nil { return ifn_665.Invoke_O__O(arg_666) } else { return linked_664.(*A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_663, arg_666) } } else {
//line :265:1
					return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else {
//line :263:1
						if A_arbace_j2g_model_A_const_60 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
						}
					}
	}
}

func A_arbace_j2g_model_iface_desc_QMARK__A_New() *A_arbace_j2g_model_iface_desc_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_iface_desc_QMARK__A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_model_iface_desc_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var and__1927000168__auto____2 any; var root_667 any = A_arbace_j2g_model_A_const_119.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_669 lang.IFn; if


	linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = d__0; if linked_668 == nil { and__1927000168__auto____2 = ifn_669.Invoke_O__O(arg_670) } else { and__1927000168__auto____2 = linked_668.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_671 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = d__0; var arg_675 any = A_arbace_j2g_model_A_const_102; if linked_672 == nil { and__1927000168__auto____3 = ifn_673.Invoke_O_O__O(arg_674, arg_675) } else { and__1927000168__auto____3 = linked_672.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_671, arg_674, arg_675) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_680 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var root_676 any = A_arbace_j2g_model_A_const_120.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = d__0; if linked_677 == nil { arg_683 = ifn_678.Invoke_O__O(arg_679) } else { arg_683 = linked_677.(*A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_676, arg_679) }; if linked_681 == nil { return ifn_682.Invoke_O__O(arg_683) } else { return linked_681.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_680, arg_683) } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_j2g_model_static_QMARK__A_New() *A_arbace_j2g_model_static_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_static_QMARK__A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_j2g_model_static_QMARK__A) Ctor() {}
//line :277:1
func (t *A_arbace_j2g_model_static_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_684 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_688 any = A_arbace_j2g_model_A_const_121; if linked_685 == nil { return ifn_686.Invoke_O_O__O(arg_687, arg_688) } else { return linked_685.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_684, arg_687, arg_688) } }
func A_arbace_j2g_model_private_QMARK__A_New() *A_arbace_j2g_model_private_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_private_QMARK__A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_j2g_model_private_QMARK__A) Ctor() {}
//line :278:1
func (t *A_arbace_j2g_model_private_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_689 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_693 any = A_arbace_j2g_model_A_const_122; if linked_690 == nil { return ifn_691.Invoke_O_O__O(arg_692, arg_693) } else { return linked_690.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_689, arg_692, arg_693) } }
func A_arbace_j2g_model_abstract_m_QMARK__A_New() *A_arbace_j2g_model_abstract_m_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_m_QMARK__A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_model_abstract_m_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var root_694 any = A_arbace_j2g_model_A_const_45.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, A_arbace_j2g_model_has_QMARK__A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = A_arbace_j2g_model_A_const_46.Invoke_O__O(m__0); var arg_698 any = A_arbace_j2g_model_A_const_75; if linked_695 == nil { return ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { return linked_695.(*A_arbace_j2g_model_has_QMARK__A).Invoke_O_O_O__O(root_694, arg_697, arg_698) } }

func A_arbace_j2g_model_methods_of_A_New() *A_arbace_j2g_model_methods_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_methods_of_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_j2g_model_methods_of_A) Ctor() {}
//line :281:1
func (t *A_arbace_j2g_model_methods_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_49; var tmp2 any; var root_699 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, A_arbace_j2g_model_info_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = n__0; if linked_700 == nil { tmp2 = ifn_701.Invoke_O__O(arg_702) } else { tmp2 = linked_700.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_699, arg_702) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_j2g_model_fields_of_A_New() *A_arbace_j2g_model_fields_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_fields_of_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_j2g_model_fields_of_A) Ctor() {}
//line :282:1
func (t *A_arbace_j2g_model_fields_of_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_123; var tmp2 any; var root_703 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, A_arbace_j2g_model_info_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = n__0; if linked_704 == nil { tmp2 = ifn_705.Invoke_O__O(arg_706) } else { tmp2 = linked_704.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_703, arg_706) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_find_method_A_New() *A_arbace_j2g_model_find_method_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_j2g_model_find_method_A) Ctor() {}
//line :284:1
func (t *A_arbace_j2g_model_find_method_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any {
	var root_712 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any; var tmp1 any = A_arbace_j2g_model_find_method_fn__1479000079_A_New_O_O(name__1, desc__2); var tmp2 *jrt.Class; var fncls__707 *jrt.Class = A_arbace_j2g_model_find_method_fn__1479000079_A_fn_class; if fncls__707 == nil { var fncls__707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_model_find_method_fn__1479000079_A_fn_class = fncls__707d; tmp2 = fncls__707d } else { tmp2 = fncls__707 }; arg_715 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_716 any; var root_708 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = n__0; if linked_709 == nil { arg_716 = ifn_710.Invoke_O__O(arg_711) } else { arg_716 = linked_709.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_708, arg_711) }; if linked_713 == nil { return ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { return linked_713.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_712, arg_715, arg_716) } }
//line :285:1
func A_arbace_j2g_model_find_method_fn__1479000079_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_find_method_fn__1479000079_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_find_method_fn__1479000079_A{}; t.Ctor_O_O(p0, p1); return t }
//line :285:1
func (t *A_arbace_j2g_model_find_method_fn__1479000079_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :285:1
func (t *A_arbace_j2g_model_find_method_fn__1479000079_A) Invoke_O_O__O(self, p1__1479000078_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_model_A_const_124.Invoke_O__O(p1__1479000078_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_model_A_const_112.Invoke_O__O(p1__1479000078_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__1479000078_SHARP___1 } else { return nil } }

func A_arbace_j2g_model_virtual_member_QMARK__A_New() *A_arbace_j2g_model_virtual_member_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_virtual_member_QMARK__A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Ctor() {}
//line :287:1
func (t *A_arbace_j2g_model_virtual_member_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var and__1927000168__auto____2 any; var root_721 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_723 lang.IFn; if


	linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any; var root_717 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = m__0; if linked_718 == nil { arg_724 = ifn_719.Invoke_O__O(arg_720) } else { arg_724 = linked_718.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_717, arg_720) }; if linked_722 == nil { and__1927000168__auto____2 = ifn_723.Invoke_O__O(arg_724) } else { and__1927000168__auto____2 = linked_722.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_721, arg_724) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_729 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any; var root_725 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = m__0; if linked_726 == nil { arg_732 = ifn_727.Invoke_O__O(arg_728) } else { arg_732 = linked_726.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_725, arg_728) }; if linked_730 == nil { and__1927000168__auto____3 = ifn_731.Invoke_O__O(arg_732) } else { and__1927000168__auto____3 = linked_730.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_729, arg_732) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_733 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = Lit_44; var arg_737 any = A_arbace_j2g_model_A_const_124.Invoke_O__O(m__0); if linked_734 == nil { and__1927000168__auto____4 = ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { and__1927000168__auto____4 = linked_734.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_733, arg_736, arg_737) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_738 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = Lit_68; var arg_742 any = A_arbace_j2g_model_A_const_124.Invoke_O__O(m__0); if linked_739 == nil { return ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { return linked_739.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_738, arg_741, arg_742) } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_model_supertypes_A_New() *A_arbace_j2g_model_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_supertypes_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_j2g_model_supertypes_A) Ctor() {}
//line :297:1
func (t *A_arbace_j2g_model_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_743 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, A_arbace_j2g_model_info_A_fn_class); var ifn_745 lang.IFn; if
										linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = n__0; if linked_744 == nil { i__2 = ifn_745.Invoke_O__O(arg_746) } else { i__2 = linked_744.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_743, arg_746) }; var root_752 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = A_arbace_j2g_model_A_const_129.GetRawRoot__O(); var arg_756 any; var root_747 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(i__2); var arg_751 any = A_arbace_j2g_model_A_const_53.Invoke_O__O(i__2); if linked_748 == nil { arg_756 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { arg_756 = linked_748.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; if linked_753 == nil { return ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { return linked_753.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) } }

func A_arbace_j2g_model_world_supertypes_A_New() *A_arbace_j2g_model_world_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_world_supertypes_A{}; t.Ctor(); return t }
//line :300:1
func (t *A_arbace_j2g_model_world_supertypes_A) Ctor() {}
//line :300:1
func (t *A_arbace_j2g_model_world_supertypes_A) Invoke_O_O__O(self, n__0 any) any {


	var root_761 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_765 any; var root_757 any = A_arbace_j2g_model_A_const_131.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, A_arbace_j2g_model_supertypes_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = n__0; if linked_758 == nil { arg_765 = ifn_759.Invoke_O__O(arg_760) } else { arg_765 = linked_758.(*A_arbace_j2g_model_supertypes_A).Invoke_O_O__O(root_757, arg_760) }; if linked_762 == nil { return ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { return linked_762.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_761, arg_764, arg_765)
	} }
func A_arbace_j2g_model_all_supertypes_A_New() *A_arbace_j2g_model_all_supertypes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_all_supertypes_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_j2g_model_all_supertypes_A) Ctor() {}
//line :305:1
func (t *A_arbace_j2g_model_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any {




	var root_775 any = A_arbace_j2g_model_A_const_18.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var root_770 any = A_arbace_j2g_model_A_const_130.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = A_arbace_j2g_model_A_const_51.GetRawRoot__O(); var arg_774 any; var root_766 any = A_arbace_j2g_model_A_const_132.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = n__0; if linked_767 == nil { arg_774 = ifn_768.Invoke_O__O(arg_769) } else { arg_774 = linked_767.(*aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_766, arg_769) }; if linked_771 == nil { arg_778 = ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { arg_778 = linked_771.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) }; if linked_776 == nil { return ifn_777.Invoke_O__O(arg_778) } else { return linked_776.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_775, arg_778)
	}
}

func A_arbace_j2g_model_hw_method_exists_QMARK__A_New() *A_arbace_j2g_model_hw_method_exists_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_hw_method_exists_QMARK__A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Ctor() {}
//line :314:1
func (t *A_arbace_j2g_model_hw_method_exists_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_91; var scan__3 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var g__4 any; var root_779 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, A_arbace_j2g_model_go_name_A_fn_class); var ifn_781 lang.IFn; if



	linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = n__0; if linked_780 == nil { g__4 = ifn_781.Invoke_O__O(arg_782) } else { g__4 = linked_780.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_779, arg_782) }; var base__5 any; var root_783 any = /*line :314:1*/A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_785 lang.IFn; if




	linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = A_arbace_j2g_model_A_const_124.Invoke_O__O(m__1); var arg_787 any = A_arbace_j2g_model_A_const_112.Invoke_O__O(m__1); if linked_784 == nil { base__5 = ifn_785.Invoke_O_O__O(arg_786, arg_787) } else { base__5 = linked_784.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_783, arg_786, arg_787) }; if
	lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_20) {
		var root_788 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var arg_792 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_124.Invoke_O__O(m__1), A_arbace_j2g_model_A_const_112.Invoke_O__O(m__1)); if linked_789 == nil { return ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { return linked_789.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_788, arg_791, arg_792) } } else {
//line :320:1
			var tmp2 any; var root_793 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_795 lang.IFn

			if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = n__0; if linked_794 == nil { tmp2 = ifn_795.Invoke_O__O(arg_796) } else { tmp2 = linked_794.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_793, arg_796) }
//line :320:1
			if jrt.J2g_Truth(tmp2) { var or__1927000174__auto____6 any; var root_802 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_804 lang.IFn

				if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any; var root_797 any = A_arbace_j2g_model_A_const_135.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = scan__3; var arg_801 any = g__4; if linked_798 == nil { arg_805 = ifn_799.Invoke_O_O__O(arg_800, arg_801) } else { arg_805 = linked_798.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_iface_methods_A).Invoke_O_O_O__O(root_797, arg_800, arg_801) }; var arg_806 any = base__5; if linked_803 == nil { or__1927000174__auto____6 = ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { or__1927000174__auto____6 = linked_803.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

					var root_807 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = A_arbace_j2g_model_A_const_136.Invoke_O__O(scan__3); var arg_811 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref(); if linked_808 == nil { return ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { return linked_808.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_807, arg_810, arg_811) } } } else {
//line :320:1
						if A_arbace_j2g_model_A_const_60 != nil { var ms__6 any; var root_812 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_814 lang.IFn




							if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = scan__3; var arg_816 any = g__4; if linked_813 == nil { ms__6 = ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { ms__6 = linked_813.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_812, arg_815, arg_816) }
//line :320:1
							var or__1927000174__auto____7 any; var root_817 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_819 lang.IFn





							if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = ms__6; var arg_821 any = base__5; if linked_818 == nil { or__1927000174__auto____7 = ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { or__1927000174__auto____7 = linked_818.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_817, arg_820, arg_821) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 any; var root_826 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = ms__6; var arg_830 any; var root_822 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = base__5; if linked_823 == nil { arg_830 = ifn_824.Invoke_O__O(arg_825) } else { arg_830 = linked_823.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_822, arg_825) }; if linked_827 == nil { or__1927000174__auto____8 = ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { or__1927000174__auto____8 = linked_827.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_826, arg_829, arg_830) }; if jrt.J2g_Truth(or__1927000174__auto____8) { return or__1927000174__auto____8 } else {
								var root_831 any = A_arbace_j2g_model_A_const_139.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_j2g_model_j2g_method_QMARK__A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = n__0; var arg_835 any = base__5; if linked_832 == nil { return ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { return linked_832.(*A_arbace_j2g_model_j2g_method_QMARK__A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } } } } else {
//line :320:1
									return nil } } } }








func A_arbace_j2g_model_j2g_method_QMARK__A_New() *A_arbace_j2g_model_j2g_method_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_j2g_method_QMARK__A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Ctor() {}
//line :329:1
func (t *A_arbace_j2g_model_j2g_method_QMARK__A) Invoke_O_O_O__O(self, n__0, base__1 any) any { var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, Lit_28); if and__1927000168__auto____3 {






	var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_model_A_const_140).Invoke_O__O(base__1); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_836 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_838 lang.IFn
		if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = Lit_29; if linked_837 == nil { and__1927000168__auto____5 = ifn_838.Invoke_O__O(arg_839) } else { and__1927000168__auto____5 = linked_837.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_836, arg_839) }
//line :336:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_840 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = Lit_30; if linked_841 == nil { return ifn_842.Invoke_O__O(arg_843) } else { return linked_841.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_840, arg_843) } } else {
//line :336:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }


func A_arbace_j2g_model_member_in_world_QMARK__A_New() *A_arbace_j2g_model_member_in_world_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_member_in_world_QMARK__A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Ctor() {}
//line :339:1
func (t *A_arbace_j2g_model_member_in_world_QMARK__A) Invoke_O_O_O__O(self, n__0, m__1 any) any { var and__1927000168__auto____3 any; var root_844 any = A_arbace_j2g_model_A_const_141.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_846 lang.IFn; if



	linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = A_arbace_j2g_model_A_const_112.Invoke_O__O(m__1); if linked_845 == nil { and__1927000168__auto____3 = ifn_846.Invoke_O__O(arg_847) } else { and__1927000168__auto____3 = linked_845.(*A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_844, arg_847) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any; var root_852 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_854 lang.IFn
		if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var root_848 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = n__0; if linked_849 == nil { arg_855 = ifn_850.Invoke_O__O(arg_851) } else { arg_855 = linked_849.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_848, arg_851) }; if linked_853 == nil { or__1927000174__auto____4 = ifn_854.Invoke_O__O(arg_855) } else { or__1927000174__auto____4 = linked_853.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_852, arg_855) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var root_856 any = A_arbace_j2g_model_A_const_142.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = n__0; var arg_860 any = m__1; if linked_857 == nil { return ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { return linked_857.(*A_arbace_j2g_model_hw_method_exists_QMARK__A).Invoke_O_O_O__O(root_856, arg_859, arg_860) } } } else {
//line :343:1
			return and__1927000168__auto____3 } }


func A_arbace_j2g_model_declared_vmethods_A_New() *A_arbace_j2g_model_declared_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Ctor() {}
//line :346:1
func (t *A_arbace_j2g_model_declared_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__957 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_fn_class; if


	fncls__957 == nil { var fncls__957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_fn_class = fncls__957d; tmp2 = fncls__957d } else { tmp2 = fncls__957 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_958 any = A_arbace_j2g_model_A_const_125.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, A_arbace_j2g_model_methods_of_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = n__0; if linked_959 == nil { tmp4 = ifn_960.Invoke_O__O(arg_961) } else { tmp4 = linked_959.(*A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_958, arg_961) }; return tmp3.Invoke_O__O(tmp4) }
//line :349:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_New_O(p0 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A{}; t.Ctor_O(p0); return t }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A) Invoke_O_O__O(self, s__1479000090__1 any) any { var tmp1 any = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_New_O_O_O(t.F_n, s__1479000090__1, self); var tmp2 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_fn_class = fncls__956d; tmp2 = fncls__956d } else { tmp2 = fncls__956 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :349:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A) Ctor_O_O_O(c__n, c__s__1479000090, c__iter__1479000089 any) { t.F_n = c__n; t.F_s__1479000090 = c__s__1479000090; t.F_iter__1479000089 = c__iter__1479000089 }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A) Invoke_O__O(self any) any { { var s__1479000090__1 any; var t_ any = t.F_s__1479000090; t.F_s__1479000090 = nil; s__1479000090__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_861 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__1479000090__1; if linked_862 == nil { temp__1927000414__auto____2 = ifn_863.Invoke_O__O(arg_864) } else { temp__1927000414__auto____2 = linked_862.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_861, arg_864) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000090__3 any = temp__1927000414__auto____2; var tmp1 any; var root_865 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = s__1479000090__3; if linked_866 == nil { tmp1 = ifn_867.Invoke_O__O(arg_868) } else { tmp1 = linked_866.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_869 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = s__1479000090__3; if linked_870 == nil { c__1927001037__auto____4 = ifn_871.Invoke_O__O(arg_872) } else { c__1927001037__auto____4 = linked_870.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_869, arg_872) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000092__6 any; var root_873 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_874 == nil { b__1479000092__6 = ifn_875.Invoke_O__O(arg_876) } else { b__1479000092__6 = linked_874.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_873, arg_876) }; var tmp2 any = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_New_O_O_I_O(t.F_n, b__1479000092__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__897 *jrt.Class = A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_fn_class; if fncls__897 == nil { var fncls__897d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_fn_class = fncls__897d; tmp3 = fncls__897d } else { tmp3 = fncls__897 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_906 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any; var root_898 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = b__1479000092__6; if linked_899 == nil { arg_909 = ifn_900.Invoke_O__O(arg_901) } else { arg_909 = linked_899.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_898, arg_901) }; var arg_910 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000089); var tmp5 any; var root_902 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = s__1479000090__3; if linked_903 == nil { tmp5 = ifn_904.Invoke_O__O(arg_905) } else { tmp5 = linked_903.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_902, arg_905) }; arg_910 = tmp4.Invoke_O__O(tmp5); if linked_907 == nil { return ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { return linked_907.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_906, arg_909, arg_910) } } else { var root_915 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var root_911 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = b__1479000092__6; if linked_912 == nil { arg_918 = ifn_913.Invoke_O__O(arg_914) } else { arg_918 = linked_912.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_911, arg_914) }; var arg_919 any; if linked_916 == nil { return ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { return linked_916.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_915, arg_918, arg_919) } } } else { var m__4 any; var root_920 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = s__1479000090__3; if linked_921 == nil { m__4 = ifn_922.Invoke_O__O(arg_923) } else { m__4 = linked_921.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_920, arg_923) }; var tmp6 any; var root_924 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_926 lang.IFn
															if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = m__4; if linked_925 == nil { tmp6 = ifn_926.Invoke_O__O(arg_927) } else { tmp6 = linked_925.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_924, arg_927) }
//line :349:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_928 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_930 lang.IFn

		if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = t.F_n; var arg_932 any = m__4; if linked_929 == nil { tmp7 = ifn_930.Invoke_O_O__O(arg_931, arg_932) } else { tmp7 = linked_929.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_928, arg_931, arg_932) }
//line :349:1
		if jrt.J2g_Truth(tmp7) { var root_943 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any; var root_933 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_935 lang.IFn


			if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = m__4; var arg_937 any = A_arbace_j2g_model_A_const_150; var arg_938 any = t.F_n; if linked_934 == nil { arg_946 = ifn_935.Invoke_O_O_O__O(arg_936, arg_937, arg_938) } else { arg_946 = linked_934.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_933, arg_936, arg_937, arg_938) }
//line :349:1
			var arg_947 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000089); var tmp9 any; var root_939 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = s__1479000090__3; if linked_940 == nil { tmp9 = ifn_941.Invoke_O__O(arg_942) } else { tmp9 = linked_940.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_939, arg_942) }; arg_947 = tmp8.Invoke_O__O(tmp9); if linked_944 == nil { return ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { return linked_944.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_943, arg_946, arg_947) } } else { var tmp10 any; var root_948 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__1479000090__3; if linked_949 == nil { tmp10 = ifn_950.Invoke_O__O(arg_951) } else { tmp10 = linked_949.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_948, arg_951) }; s__1479000090__1 = tmp10; continue L1 } } else { var tmp11 any; var root_952 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = s__1479000090__3; if linked_953 == nil { tmp11 = ifn_954.Invoke_O__O(arg_955) } else { tmp11 = linked_953.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_952, arg_955) }; s__1479000090__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A) Ctor_O_O_I_O(c__n, c__b__1479000092 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1479000092 = c__b__1479000092; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :349:1
func (t *A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A) Invoke_O__O(self any) any { { var i__1479000091__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000091__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000091__1)); var tmp2 any; var root_877 any = A_arbace_j2g_model_A_const_146.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, A_arbace_j2g_model_virtual_member_QMARK__A_fn_class); var ifn_879 lang.IFn
																	if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = m__2; if linked_878 == nil { tmp2 = ifn_879.Invoke_O__O(arg_880) } else { tmp2 = linked_878.(*A_arbace_j2g_model_virtual_member_QMARK__A).Invoke_O_O__O(root_877, arg_880) }
//line :349:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_881 any = A_arbace_j2g_model_A_const_147.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, A_arbace_j2g_model_member_in_world_QMARK__A_fn_class); var ifn_883 lang.IFn

		if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = t.F_n; var arg_885 any = m__2; if linked_882 == nil { tmp3 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { tmp3 = linked_882.(*A_arbace_j2g_model_member_in_world_QMARK__A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }
//line :349:1
		if jrt.J2g_Truth(tmp3) { var root_892 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = t.F_b__1479000092; var arg_896 any; var root_886 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_888 lang.IFn


			if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = m__2; var arg_890 any = A_arbace_j2g_model_A_const_150; var arg_891 any = t.F_n; if linked_887 == nil { arg_896 = ifn_888.Invoke_O_O_O__O(arg_889, arg_890, arg_891) } else { arg_896 = linked_887.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_886, arg_889, arg_890, arg_891) }
//line :349:1
			if linked_893 == nil { ifn_894.Invoke_O_O__O(arg_895, arg_896) } else { linked_893.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_892, arg_895, arg_896) }; i__1479000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000091__1); continue L1 } else { i__1479000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000091__1); continue L1 } } else { i__1479000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000091__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_model_vmethods_A_New() *A_arbace_j2g_model_vmethods_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_j2g_model_vmethods_A) Ctor() {}
//line :354:1
func (t *A_arbace_j2g_model_vmethods_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_156; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var or__1927000174__auto____3 any; var tmp2 any; var root_962 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_964 lang.IFn; if




	linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = cache__2; if linked_963 == nil { tmp2 = ifn_964.Invoke_O__O(arg_965) } else { tmp2 = linked_963.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_962, arg_965) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp2, n__0); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var r__4 any; var root_1001 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1003 lang.IFn
		if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any; var tmp3 any = A_arbace_j2g_model_vmethods_fn__1479000100_A_New(); var tmp4 *jrt.Class; var fncls__993 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000100_A_fn_class; if fncls__993 == nil { var fncls__993d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_j2g_model_vmethods_fn__1479000100_A_fn_class = fncls__993d; tmp4 = fncls__993d } else { tmp4 = fncls__993 }; arg_1004 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1005 any; var root_994 any = A_arbace_j2g_model_A_const_158.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_array_map_A_fn_class); var ifn_996 lang.IFn






		if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; if linked_995 == nil { arg_1005 = ifn_996.Invoke__O() } else { arg_1005 = linked_995.(*aot_arbace_core.A_arbace_core_array_map_A).Invoke_O__O(root_994) }
//line :360:1
		var arg_1006 any; var root_997 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_999 lang.IFn






		if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = n__0; if linked_998 == nil { arg_1006 = ifn_999.Invoke_O__O(arg_1000) } else { arg_1006 = linked_998.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_997, arg_1000) }
//line :360:1
		if linked_1002 == nil { r__4 = ifn_1003.Invoke_O_O_O__O(arg_1004, arg_1005, arg_1006) } else { r__4 = linked_1002.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1001, arg_1004, arg_1005, arg_1006)
		}






		var root_1007 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = cache__2; var arg_1011 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var arg_1012 any = n__0; var arg_1013 any = r__4; if linked_1008 == nil { ifn_1009.Invoke_O_O_O_O__O(arg_1010, arg_1011, arg_1012, arg_1013) } else { linked_1008.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1007, arg_1010, arg_1011, arg_1012, arg_1013) }
//line :359:1
		return r__4 } }
func A_arbace_j2g_model_vmethods_fn__1479000100_A_New() *A_arbace_j2g_model_vmethods_fn__1479000100_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000100_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_A) Ctor() {}
//line :360:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_A) Invoke_O_O_O__O(self, acc__1, c__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(c__2, Lit_20) { return acc__1 } else {

		var root_987 any = A_arbace_j2g_model_A_const_79.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any; var tmp1 any = A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_New(); var tmp2 *jrt.Class; var fncls__982 *jrt.Class = A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_fn_class; if fncls__982 == nil { var fncls__982d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_fn_class = fncls__982d; tmp2 = fncls__982d } else { tmp2 = fncls__982 }; arg_990 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_991 any = acc__1; var arg_992 any; var root_983 any = A_arbace_j2g_model_A_const_157.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, A_arbace_j2g_model_declared_vmethods_A_fn_class); var ifn_985 lang.IFn


		if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = c__2; if linked_984 == nil { arg_992 = ifn_985.Invoke_O__O(arg_986) } else { arg_992 = linked_984.(*A_arbace_j2g_model_declared_vmethods_A).Invoke_O_O__O(root_983, arg_986) }
//line :363:1
		if linked_988 == nil { return ifn_989.Invoke_O_O_O__O(arg_990, arg_991, arg_992) } else { return linked_988.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_987, arg_990, arg_991, arg_992) } } }
//line :363:1
func A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_New() *A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A) Ctor() {}
//line :363:1
func (t *A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A) Invoke_O_O_O__O(self, acc__1, m__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_124.Invoke_O__O(m__2), A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2)); var tmp1 any; var or__1927000174__auto____4 any; var root_966 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_968 lang.IFn; if

	linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = acc__1; var arg_970 any = k__3; if linked_967 == nil { or__1927000174__auto____4 = ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { or__1927000174__auto____4 = linked_967.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var root_971 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = A_arbace_j2g_model_A_const_134.GetRawRoot__O(); var arg_975 any = k__3; if linked_972 == nil { tmp1 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { tmp1 = linked_972.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } }; if jrt.J2g_Truth(tmp1) { return acc__1 } else { var root_976 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = acc__1; var arg_980 any = k__3; var arg_981 any = m__2; if linked_977 == nil { return ifn_978.Invoke_O_O_O__O(arg_979, arg_980, arg_981) } else { return linked_977.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_976, arg_979, arg_980, arg_981) } } }





func A_arbace_j2g_model_java_type_name_A_New() *A_arbace_j2g_model_java_type_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_java_type_name_A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_j2g_model_java_type_name_A) Ctor() {}
//line :371:1
func (t *A_arbace_j2g_model_java_type_name_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 any; var root_1014 any = A_arbace_j2g_model_A_const_55.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = d__0; if linked_1015 == nil { tmp1 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp1 = linked_1015.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1014, arg_1017) }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34); var tmp3 any; var root_1022 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any; var root_1018 any = A_arbace_j2g_model_A_const_67.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = d__0; if linked_1019 == nil { arg_1025 = ifn_1020.Invoke_O__O(arg_1021) } else { arg_1025 = linked_1019.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1018, arg_1021) }; if linked_1023 == nil { tmp3 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp3 = linked_1023.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1022, arg_1025) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref() } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(d__0))) {
		return lang.IFn_Cast(A_arbace_j2g_model_A_const_161).Invoke_O__O(d__0) } else {
//line :374:1
			if A_arbace_j2g_model_A_const_60 != nil {


				var root_1030 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any; var root_1026 any = A_arbace_j2g_model_A_const_61.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = d__0; if linked_1027 == nil { arg_1033 = ifn_1028.Invoke_O__O(arg_1029) } else { arg_1033 = linked_1027.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1026, arg_1029) }; var arg_1034 any = Lit_1; var arg_1035 any = Lit_2; if linked_1031 == nil { return ifn_1032.Invoke_O_O_O__O(arg_1033, arg_1034, arg_1035) } else { return linked_1031.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1030, arg_1033, arg_1034, arg_1035) } } else {
//line :374:1
					return nil
				}
		}
	}
}
func A_arbace_j2g_model_abstract_method_error_text_A_New() *A_arbace_j2g_model_abstract_method_error_text_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_abstract_method_error_text_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Ctor() {}
//line :379:1
func (t *A_arbace_j2g_model_abstract_method_error_text_A) Invoke_O_O_O_O__O(self, n__0, owner__1, p__1479000106__2 any) any { var vec__1479000107__4 any = p__1479000106__2; var name__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000107__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000107__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1479000110__7 any; var root_1036 any = A_arbace_j2g_model_A_const_64.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1038 lang.IFn; if



	linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = desc__6; if linked_1037 == nil { vec__1479000110__7 = ifn_1038.Invoke_O__O(arg_1039) } else { vec__1479000110__7 = linked_1037.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1036, arg_1039) }; var ps__8 any = /*line :379:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1479000110__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000110__7, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.ConstRefArray("[0,12,s15:Receiver class ns69: does not define or inherit an implementation of the resolved method s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1040 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1042 lang.IFn; if




	linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = n__0; var arg_1044 any = Lit_1; var arg_1045 any = Lit_2; if linked_1041 == nil { tmp2 = ifn_1042.Invoke_O_O_O__O(arg_1043, arg_1044, arg_1045) } else { tmp2 = linked_1041.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1040, arg_1043, arg_1044, arg_1045) }; var tmp3 any = tmp2; var tmp4 any; var root_1046 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1048 lang.IFn; if
	linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = r__9; if linked_1047 == nil { tmp4 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp4 = linked_1047.(*A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1046, arg_1049) }; var tmp5 any = tmp4; var tmp6 any; var root_1055 any = /*line :384:1*/A_arbace_j2g_model_A_const_163.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1057 lang.IFn; if
	linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = Lit_3; var arg_1059 any; var root_1050 any = A_arbace_j2g_model_A_const_164.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = A_arbace_j2g_model_A_const_160.GetRawRoot__O(); var arg_1054 any = ps__8; if linked_1051 == nil { arg_1059 = ifn_1052.Invoke_O_O__O(arg_1053, arg_1054) } else { arg_1059 = linked_1051.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1050, arg_1053, arg_1054) }; if linked_1056 == nil { tmp6 = ifn_1057.Invoke_O_O__O(arg_1058, arg_1059) } else { tmp6 = linked_1056.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1055, arg_1058, arg_1059) }; var tmp7 any = tmp6; var tmp8 /*line :384:1*/*jrt.String; if

	jrt.J2g_Truth(owner__1) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil, nil); var tmp10 *jrt.String; var tmp11 any; var root_1060 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = owner__1; if linked_1061 == nil { tmp11 = ifn_1062.Invoke_O__O(arg_1063) } else { tmp11 = linked_1061.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1060, arg_1063) }; if jrt.J2g_Truth(tmp11) { tmp10 = Lit_5 } else { tmp10 = Lit_6 }; var tmp12 any = tmp10.Ref(); var tmp13 any; var root_1064 any = A_arbace_j2g_model_A_const_162.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = owner__1; var arg_1068 any = Lit_1; var arg_1069 any = Lit_2; if linked_1065 == nil { tmp13 = ifn_1066.Invoke_O_O_O__O(arg_1067, arg_1068, arg_1069) } else { tmp13 = linked_1065.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1064, arg_1067, arg_1068, arg_1069) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, tmp13)) } else { tmp8 = nil }; return /*line :384:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, nil, tmp5, nil, name__5, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }



func A_arbace_j2g_model_superclass_chain_A_New() *A_arbace_j2g_model_superclass_chain_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_A{}; t.Ctor(); return t }
//line :388:1
func (t *A_arbace_j2g_model_superclass_chain_A) Ctor() {}
//line :388:1
func (t *A_arbace_j2g_model_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1080 any = A_arbace_j2g_model_A_const_165.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var arg_1084 any; var root_1075 any = A_arbace_j2g_model_A_const_166.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any; var tmp1 any = A_arbace_j2g_model_superclass_chain_fn__1479000115_A_New(); var tmp2 *jrt.Class; var fncls__1074 *jrt.Class = A_arbace_j2g_model_superclass_chain_fn__1479000115_A_fn_class; if fncls__1074 == nil { var fncls__1074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_model_superclass_chain_fn__1479000115_A_fn_class = fncls__1074d; tmp2 = fncls__1074d } else { tmp2 = fncls__1074 }; arg_1078 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1079 any = n__0; if linked_1076 == nil { arg_1084 = ifn_1077.Invoke_O_O__O(arg_1078, arg_1079) } else { arg_1084 = linked_1076.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1075, arg_1078, arg_1079) }; if linked_1081 == nil { return ifn_1082.Invoke_O_O__O(arg_1083, arg_1084) } else { return linked_1081.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1080, arg_1083, arg_1084) } }
//line :389:1
func A_arbace_j2g_model_superclass_chain_fn__1479000115_A_New() *A_arbace_j2g_model_superclass_chain_fn__1479000115_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_superclass_chain_fn__1479000115_A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000115_A) Ctor() {}
//line :389:1
func (t *A_arbace_j2g_model_superclass_chain_fn__1479000115_A) Invoke_O_O__O(self, p1__1479000114_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_80; var tmp2 any; var root_1070 any = A_arbace_j2g_model_A_const_74.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, A_arbace_j2g_model_info_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = p1__1479000114_SHARP___1; if linked_1071 == nil { tmp2 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp2 = linked_1071.(*A_arbace_j2g_model_info_A).Invoke_O_O__O(root_1070, arg_1073) }; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_j2g_model_impl_of_A_New() *A_arbace_j2g_model_impl_of_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_j2g_model_impl_of_A) Ctor() {}
//line :391:1
func (t *A_arbace_j2g_model_impl_of_A) Invoke_O_O_O__O(self, n__0, p__1479000119__1 any) any { var vec__1479000120__3 any = p__1479000119__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000120__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000120__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__1479000120__3; var or__1927000174__auto____7 any; var root_1160 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1162 lang.IFn; _ = k__6; if





	linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any; var tmp1 any = A_arbace_j2g_model_impl_of_fn__1479000123_A_New_O_O_O(name__4, desc__5, n__0); var tmp2 *jrt.Class; var fncls__1155 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000123_A_fn_class; if fncls__1155 == nil { var fncls__1155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_model_impl_of_fn__1479000123_A_fn_class = fncls__1155d; tmp2 = fncls__1155d } else { tmp2 = fncls__1155 }; arg_1163 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1164 any; var root_1156 any = A_arbace_j2g_model_A_const_175.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1158 lang.IFn; if












	linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = n__0; if linked_1157 == nil { arg_1164 = ifn_1158.Invoke_O__O(arg_1159) } else { arg_1164 = linked_1157.(*A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1156, arg_1159) }; if /*line :397:1*/ linked_1161 == nil { or__1927000174__auto____7 = ifn_1162.Invoke_O_O__O(arg_1163, arg_1164) } else { or__1927000174__auto____7 = linked_1161.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1160, arg_1163, arg_1164) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var cands__8 any; var iter__1927001039__auto____8 any; var tmp3 any = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_New_O_O(name__4, desc__5); var tmp4 *jrt.Class
		var fncls__1347 /*line :397:1*/*jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_fn_class














		if fncls__1347 == nil { var fncls__1347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_fn_class = fncls__1347d; tmp4 = fncls__1347d } else { tmp4 = fncls__1347 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____8); var tmp6 any; var root_1374 any = A_arbace_j2g_model_A_const_159.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = n__0; if linked_1375 == nil { tmp6 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp6 = linked_1375.(*A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_1374, arg_1377) }; cands__8 = tmp5.Invoke_O__O(tmp6)
//line :397:1
		var cands__9 any; var root_1365 any = A_arbace_j2g_model_A_const_128.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1367 lang.IFn





















		if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any; var tmp7 any = A_arbace_j2g_model_impl_of_fn__1479000135_A_New_O(cands__8); var tmp8 *jrt.Class; var fncls__1364 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000135_A_fn_class; if fncls__1364 == nil { var fncls__1364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_model_impl_of_fn__1479000135_A_fn_class = fncls__1364d; tmp8 = fncls__1364d } else { tmp8 = fncls__1364 }; arg_1368 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1369 any = cands__8; if linked_1366 == nil { cands__9 = ifn_1367.Invoke_O_O__O(arg_1368, arg_1369) } else { cands__9 = linked_1366.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1365, arg_1368, arg_1369) }
		var root_1370 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = cands__9; if linked_1371 == nil { return ifn_1372.Invoke_O__O(arg_1373) } else { return linked_1371.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1370, arg_1373) } } }
//line :397:1
func A_arbace_j2g_model_impl_of_fn__1479000123_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_model_impl_of_fn__1479000123_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000123_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :397:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000123_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :397:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000123_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var root_1089 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1091 lang.IFn; if
											linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any; var root_1085 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = c__1; if linked_1086 == nil { arg_1092 = ifn_1087.Invoke_O__O(arg_1088) } else { arg_1092 = linked_1086.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1085, arg_1088) }; if linked_1090 == nil { and__1927000168__auto____2 = ifn_1091.Invoke_O__O(arg_1092) } else { and__1927000168__auto____2 = linked_1090.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1089, arg_1092) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1093 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = c__1; var arg_1097 any = t.F_name; var arg_1098 any = t.F_desc; if linked_1094 == nil { temp__1927000414__auto____2 = ifn_1095.Invoke_O_O_O__O(arg_1096, arg_1097, arg_1098) } else { temp__1927000414__auto____2 = linked_1094.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1093, arg_1096, arg_1097, arg_1098) } } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var m__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any; var root_1103 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1105 lang.IFn
												if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any; var root_1099 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = m__3; if linked_1100 == nil { arg_1106 = ifn_1101.Invoke_O__O(arg_1102) } else { arg_1106 = linked_1100.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1099, arg_1102) }; if linked_1104 == nil { and__1927000168__auto____4 = ifn_1105.Invoke_O__O(arg_1106) } else { and__1927000168__auto____4 = linked_1104.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1103, arg_1106) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1111 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any; var root_1107 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = m__3; if linked_1108 == nil { arg_1114 = ifn_1109.Invoke_O__O(arg_1110) } else { arg_1114 = linked_1108.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1107, arg_1110) }; if linked_1112 == nil { and__1927000168__auto____5 = ifn_1113.Invoke_O__O(arg_1114) } else { and__1927000168__auto____5 = linked_1112.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1111, arg_1114) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var root_1119 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1121 lang.IFn
													if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any; var root_1115 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = m__3; if linked_1116 == nil { arg_1122 = ifn_1117.Invoke_O__O(arg_1118) } else { arg_1122 = linked_1116.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1115, arg_1118) }; if linked_1120 == nil { or__1927000174__auto____6 = ifn_1121.Invoke_O__O(arg_1122) } else { or__1927000174__auto____6 = linked_1120.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1119, arg_1122) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(c__1, t.F_n)).Ref() } } else {
//line :399:1
				tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

					if lang.Util_Equiv_O_O__Z_NoInit(c__1, Lit_20) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_170, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { var tmp2 any; var root_1123 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1125 lang.IFn

						if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = c__1; if linked_1124 == nil { tmp2 = ifn_1125.Invoke_O__O(arg_1126) } else { tmp2 = linked_1124.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1123, arg_1126) }
//line :401:1
						if jrt.J2g_Truth(tmp2) { var base__4 any; var root_1127 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1129 lang.IFn


							if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = t.F_name; var arg_1131 any = t.F_desc; if linked_1128 == nil { base__4 = ifn_1129.Invoke_O_O__O(arg_1130, arg_1131) } else { base__4 = linked_1128.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1127, arg_1130, arg_1131) }
//line :401:1
							var ms__5 any; var root_1136 any = A_arbace_j2g_model_A_const_137.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1138 lang.IFn



							if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1139 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var arg_1140 any; var root_1132 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = c__1; if linked_1133 == nil { arg_1140 = ifn_1134.Invoke_O__O(arg_1135) } else { arg_1140 = linked_1133.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1132, arg_1135) }; if linked_1137 == nil { ms__5 = ifn_1138.Invoke_O_O__O(arg_1139, arg_1140) } else { ms__5 = linked_1137.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1136, arg_1139, arg_1140) }
							var tmp4 any; var root_1145 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = ms__5; var arg_1149 any; var root_1141 any = A_arbace_j2g_model_A_const_138.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A_fn_class); var ifn_1143 lang.IFn; if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = base__4; if linked_1142 == nil { arg_1149 = ifn_1143.Invoke_O__O(arg_1144) } else { arg_1149 = linked_1142.(*aot_arbace_j2g_names.A_arbace_j2g_names_impl_name_A).Invoke_O_O__O(root_1141, arg_1144) }; if linked_1146 == nil { tmp4 = ifn_1147.Invoke_O_O__O(arg_1148, arg_1149) } else { tmp4 = linked_1146.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1145, arg_1148, arg_1149) }; if jrt.J2g_Truth(tmp4) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_172, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { var tmp5 any; var root_1150 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1152 lang.IFn
								if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = ms__5; var arg_1154 any = base__4; if linked_1151 == nil { tmp5 = ifn_1152.Invoke_O_O__O(arg_1153, arg_1154) } else { tmp5 = linked_1151.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1150, arg_1153, arg_1154) }
//line :406:1
								if jrt.J2g_Truth(tmp5) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_173, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { if A_arbace_j2g_model_A_const_60 != nil { return nil } else { return nil } } } } else {
//line :401:1
									if A_arbace_j2g_model_A_const_60 != nil { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_174, A_arbace_j2g_model_A_const_150, c__1, A_arbace_j2g_model_A_const_171, m__3)) } else { return nil } } } } else {
//line :399:1
										return nil } } else {
//line :398:1
											return nil } }













func A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A{}; t.Ctor_O_O(p0, p1); return t }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A) Invoke_O_O__O(self, s__1479000126__1 any) any { var tmp1 any = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_New_O_O_O_O(self, t.F_name, t.F_desc, s__1479000126__1); var tmp2 *jrt.Class; var fncls__1346 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_fn_class; if fncls__1346 == nil { var fncls__1346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_fn_class = fncls__1346d; tmp2 = fncls__1346d } else { tmp2 = fncls__1346 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :412:1
func A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A) Ctor_O_O_O_O(c__iter__1479000125, c__name, c__desc, c__s__1479000126 any) { t.F_iter__1479000125 = c__iter__1479000125; t.F_name = c__name; t.F_desc = c__desc; t.F_s__1479000126 = c__s__1479000126 }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A) Invoke_O__O(self any) any { { var s__1479000126__1 any; var t_ any = t.F_s__1479000126; t.F_s__1479000126 = nil; s__1479000126__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1165 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = s__1479000126__1; if linked_1166 == nil { temp__1927000414__auto____2 = ifn_1167.Invoke_O__O(arg_1168) } else { temp__1927000414__auto____2 = linked_1166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1165, arg_1168) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000126__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1169 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = s__1479000126__3; if linked_1170 == nil { tmp1 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp1 = linked_1170.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1169, arg_1172) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1173 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = s__1479000126__3; if linked_1174 == nil { c__1927001037__auto____4 = ifn_1175.Invoke_O__O(arg_1176) } else { c__1927001037__auto____4 = linked_1174.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1173, arg_1176) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000128__6 any; var root_1177 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1178 == nil { b__1479000128__6 = ifn_1179.Invoke_O__O(arg_1180) } else { b__1479000128__6 = linked_1178.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1177, arg_1180) }; var tmp2 any = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_New_O_O_O_I_O(t.F_name, b__1479000128__6, t.F_desc, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1242 *jrt.Class = A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_fn_class; if fncls__1242 == nil { var fncls__1242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_fn_class = fncls__1242d; tmp3 = fncls__1242d } else { tmp3 = fncls__1242 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1251 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any; var root_1243 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1245 lang.IFn; if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = b__1479000128__6; if linked_1244 == nil { arg_1254 = ifn_1245.Invoke_O__O(arg_1246) } else { arg_1254 = linked_1244.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1243, arg_1246) }; var arg_1255 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000125); var tmp5 any; var root_1247 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = s__1479000126__3; if linked_1248 == nil { tmp5 = ifn_1249.Invoke_O__O(arg_1250) } else { tmp5 = linked_1248.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1247, arg_1250) }; arg_1255 = tmp4.Invoke_O__O(tmp5); if linked_1252 == nil { return ifn_1253.Invoke_O_O__O(arg_1254, arg_1255) } else { return linked_1252.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1251, arg_1254, arg_1255) } } else { var root_1260 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any; var root_1256 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = b__1479000128__6; if linked_1257 == nil { arg_1263 = ifn_1258.Invoke_O__O(arg_1259) } else { arg_1263 = linked_1257.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1256, arg_1259) }; var arg_1264 any; if linked_1261 == nil { return ifn_1262.Invoke_O_O__O(arg_1263, arg_1264) } else { return linked_1261.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1260, arg_1263, arg_1264) } } } else { var c__4 any; var root_1265 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = s__1479000126__3; if linked_1266 == nil { c__4 = ifn_1267.Invoke_O__O(arg_1268) } else { c__4 = linked_1266.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1265, arg_1268) }; var tmp6 any; var root_1269 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1271 lang.IFn
														if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = c__4; if linked_1270 == nil { tmp6 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp6 = linked_1270.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1269, arg_1272) }
//line :412:1
	if jrt.J2g_Truth(tmp6) { var m__5 any; var root_1273 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1275 lang.IFn

		if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = c__4; var arg_1277 any = t.F_name; var arg_1278 any = t.F_desc; if linked_1274 == nil { m__5 = ifn_1275.Invoke_O_O_O__O(arg_1276, arg_1277, arg_1278) } else { m__5 = linked_1274.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1273, arg_1276, arg_1277, arg_1278) }
//line :412:1
		var tmp7 any
		var and__1927000168__auto____6 any = m__5

		if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1283 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any; var root_1279 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = m__5; if linked_1280 == nil { arg_1286 = ifn_1281.Invoke_O__O(arg_1282) } else { arg_1286 = linked_1280.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1279, arg_1282) }; if linked_1284 == nil { and__1927000168__auto____7 = ifn_1285.Invoke_O__O(arg_1286) } else { and__1927000168__auto____7 = linked_1284.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1283, arg_1286) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1291 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any; var root_1287 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = m__5; if linked_1288 == nil { arg_1294 = ifn_1289.Invoke_O__O(arg_1290) } else { arg_1294 = linked_1288.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1287, arg_1290) }; if linked_1292 == nil { and__1927000168__auto____8 = ifn_1293.Invoke_O__O(arg_1294) } else { and__1927000168__auto____8 = linked_1292.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1291, arg_1294) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1299 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any; var root_1295 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = m__5; if linked_1296 == nil { arg_1302 = ifn_1297.Invoke_O__O(arg_1298) } else { arg_1302 = linked_1296.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1295, arg_1298) }; if linked_1300 == nil { tmp7 = ifn_1301.Invoke_O__O(arg_1302) } else { tmp7 = linked_1300.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1299, arg_1302) } } else { tmp7 = and__1927000168__auto____8 } } else { tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 }
//line :412:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____6 any; var root_1307 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1309 lang.IFn



			if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var root_1303 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = c__4; if linked_1304 == nil { arg_1310 = ifn_1305.Invoke_O__O(arg_1306) } else { arg_1310 = linked_1304.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1303, arg_1306) }; if linked_1308 == nil { or__1927000174__auto____6 = ifn_1309.Invoke_O__O(arg_1310) } else { or__1927000174__auto____6 = linked_1308.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1307, arg_1310) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp8 = or__1927000174__auto____6 } else {
				var root_1320 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_136; var tmp10 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1323 any = tmp9.Invoke_O__O(tmp10.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1324 any; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil); var tmp12 any; var root_1311 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = c__4; if linked_1312 == nil { tmp12 = ifn_1313.Invoke_O__O(arg_1314) } else { tmp12 = linked_1312.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1311, arg_1314) }; var tmp13 any = tmp12; var tmp14 any; var root_1315 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = t.F_name; var arg_1319 any = t.F_desc; if linked_1316 == nil { tmp14 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { tmp14 = linked_1316.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) }; arg_1324 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13, nil, tmp14)).Ref(); if linked_1321 == nil { tmp8 = ifn_1322.Invoke_O_O__O(arg_1323, arg_1324) } else { tmp8 = linked_1321.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1320, arg_1323, arg_1324) } }
//line :412:1
			if jrt.J2g_Truth(tmp8) { var root_1329 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_150, c__4, A_arbace_j2g_model_A_const_171, m__5)); var arg_1333 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1479000125); var tmp16 any; var root_1325 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = s__1479000126__3; if linked_1326 == nil { tmp16 = ifn_1327.Invoke_O__O(arg_1328) } else { tmp16 = linked_1326.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1325, arg_1328) }; arg_1333 = tmp15.Invoke_O__O(tmp16); if linked_1330 == nil { return ifn_1331.Invoke_O_O__O(arg_1332, arg_1333) } else { return linked_1330.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1329, arg_1332, arg_1333) } } else { var tmp17 any; var root_1334 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = s__1479000126__3; if linked_1335 == nil { tmp17 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp17 = linked_1335.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1334, arg_1337) }; s__1479000126__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1338 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = s__1479000126__3; if linked_1339 == nil { tmp18 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp18 = linked_1339.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1338, arg_1341) }; s__1479000126__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1342 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = s__1479000126__3; if linked_1343 == nil { tmp19 = ifn_1344.Invoke_O__O(arg_1345) } else { tmp19 = linked_1343.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1342, arg_1345) }; s__1479000126__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :412:1
func A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A) Ctor_O_O_O_I_O(c__name, c__b__1479000128, c__desc any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__1479000128 = c__b__1479000128; t.F_desc = c__desc; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :412:1
func (t *A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A) Invoke_O__O(self any) any { { var i__1479000127__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000127__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000127__1)); var tmp2 any; var root_1181 any = A_arbace_j2g_model_A_const_88.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1183 lang.IFn
																if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = c__2; if linked_1182 == nil { tmp2 = ifn_1183.Invoke_O__O(arg_1184) } else { tmp2 = linked_1182.(*A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1181, arg_1184) }
//line :412:1
	if jrt.J2g_Truth(tmp2) { var m__3 any; var root_1185 any = A_arbace_j2g_model_A_const_167.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, A_arbace_j2g_model_find_method_A_fn_class); var ifn_1187 lang.IFn

		if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = c__2; var arg_1189 any = t.F_name; var arg_1190 any = t.F_desc; if linked_1186 == nil { m__3 = ifn_1187.Invoke_O_O_O__O(arg_1188, arg_1189, arg_1190) } else { m__3 = linked_1186.(*A_arbace_j2g_model_find_method_A).Invoke_O_O_O_O__O(root_1185, arg_1188, arg_1189, arg_1190) }
//line :412:1
		var tmp3 any
		var and__1927000168__auto____4 any = m__3

		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1195 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any; var root_1191 any = A_arbace_j2g_model_A_const_168.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, A_arbace_j2g_model_abstract_m_QMARK__A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = m__3; if linked_1192 == nil { arg_1198 = ifn_1193.Invoke_O__O(arg_1194) } else { arg_1198 = linked_1192.(*A_arbace_j2g_model_abstract_m_QMARK__A).Invoke_O_O__O(root_1191, arg_1194) }; if linked_1196 == nil { and__1927000168__auto____5 = ifn_1197.Invoke_O__O(arg_1198) } else { and__1927000168__auto____5 = linked_1196.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1195, arg_1198) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1203 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any; var root_1199 any = A_arbace_j2g_model_A_const_126.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = m__3; if linked_1200 == nil { arg_1206 = ifn_1201.Invoke_O__O(arg_1202) } else { arg_1206 = linked_1200.(*A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1199, arg_1202) }; if linked_1204 == nil { and__1927000168__auto____6 = ifn_1205.Invoke_O__O(arg_1206) } else { and__1927000168__auto____6 = linked_1204.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1203, arg_1206) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1211 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any; var root_1207 any = A_arbace_j2g_model_A_const_127.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = m__3; if linked_1208 == nil { arg_1214 = ifn_1209.Invoke_O__O(arg_1210) } else { arg_1214 = linked_1208.(*A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1207, arg_1210) }; if linked_1212 == nil { tmp3 = ifn_1213.Invoke_O__O(arg_1214) } else { tmp3 = linked_1212.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1211, arg_1214) } } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :412:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____4 any; var root_1219 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1221 lang.IFn



			if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any; var root_1215 any = A_arbace_j2g_model_A_const_89.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = c__2; if linked_1216 == nil { arg_1222 = ifn_1217.Invoke_O__O(arg_1218) } else { arg_1222 = linked_1216.(*A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1215, arg_1218) }; if linked_1220 == nil { or__1927000174__auto____4 = ifn_1221.Invoke_O__O(arg_1222) } else { or__1927000174__auto____4 = linked_1220.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1219, arg_1222) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else {
				var root_1232 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_model_A_const_136; var tmp6 *lang.Keyword = A_arbace_j2g_model_A_const_91; var arg_1235 any = tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O())); var arg_1236 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_21, nil); var tmp8 any; var root_1223 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any = c__2; if linked_1224 == nil { tmp8 = ifn_1225.Invoke_O__O(arg_1226) } else { tmp8 = linked_1224.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1223, arg_1226) }; var tmp9 any = tmp8; var tmp10 any; var root_1227 any = A_arbace_j2g_model_A_const_133.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = t.F_name; var arg_1231 any = t.F_desc; if linked_1228 == nil { tmp10 = ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { tmp10 = linked_1228.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) }; arg_1236 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref(); if linked_1233 == nil { tmp4 = ifn_1234.Invoke_O_O__O(arg_1235, arg_1236) } else { tmp4 = linked_1233.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1232, arg_1235, arg_1236) } }
//line :412:1
			if jrt.J2g_Truth(tmp4) { var root_1237 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = t.F_b__1479000128; var arg_1241 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_model_A_const_169, A_arbace_j2g_model_A_const_176, A_arbace_j2g_model_A_const_150, c__2, A_arbace_j2g_model_A_const_171, m__3)); if linked_1238 == nil { ifn_1239.Invoke_O_O__O(arg_1240, arg_1241) } else { linked_1238.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1237, arg_1240, arg_1241) }; i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } else { i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } } else { i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } } else { i__1479000127__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000127__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_model_impl_of_fn__1479000135_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000135_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000135_A{}; t.Ctor_O(p0); return t }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_A) Invoke_O_O__O(self, x__1 any) any { var root_1359 any = A_arbace_j2g_model_A_const_68.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var tmp1 any = A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_New_O(x__1); var tmp2 *jrt.Class; var fncls__1358 *jrt.Class = A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_fn_class; if fncls__1358 == nil { var fncls__1358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_fn_class = fncls__1358d; tmp2 = fncls__1358d } else { tmp2 = fncls__1358 }; arg_1362 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1363 any = t.F_cands; if linked_1360 == nil { return ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { return linked_1360.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) } }
//line :419:1
func A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_New_O(p0 any) *A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A{}; t.Ctor_O(p0); return t }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :419:1
func (t *A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A) Invoke_O_O__O(self, p1__1479000118_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1348 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(p1__1479000118_SHARP___1); var arg_1352 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(t.F_x); if linked_1349 == nil { and__1927000168__auto____2 = ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { and__1927000168__auto____2 = linked_1349.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1353 any = A_arbace_j2g_model_A_const_177.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(p1__1479000118_SHARP___1); var arg_1357 any = A_arbace_j2g_model_A_const_150.Invoke_O__O(t.F_x); if linked_1354 == nil { return ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { return linked_1354.(*aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) } } else { return and__1927000168__auto____2 } }


func A_arbace_j2g_model_code_class_QMARK__A_New() *A_arbace_j2g_model_code_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_class_QMARK__A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Ctor() {}
//line :422:1
func (t *A_arbace_j2g_model_code_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {







	var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_178; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_179; var tmp3 any; var root_1378 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = n__0; if linked_1379 == nil { tmp3 = ifn_1380.Invoke_O__O(arg_1381) } else { tmp3 = linked_1379.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1378, arg_1381) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)))).Ref()
}
func A_arbace_j2g_model_code_iface_QMARK__A_New() *A_arbace_j2g_model_code_iface_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_code_iface_QMARK__A{}; t.Ctor(); return t }
//line :432:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Ctor() {}
//line :432:1
func (t *A_arbace_j2g_model_code_iface_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var root_1382 any = A_arbace_j2g_model_A_const_180.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_re_matches_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = A_arbace_j2g_model_A_const_181; var arg_1386 any = n__0; if linked_1383 == nil { tmp1 = ifn_1384.Invoke_O_O__O(arg_1385, arg_1386) } else { tmp1 = linked_1383.(*aot_arbace_core.A_arbace_core_re_matches_A).Invoke_O_O_O__O(root_1382, arg_1385, arg_1386) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}
func A_arbace_j2g_model_nest_top_A_New() *A_arbace_j2g_model_nest_top_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_nest_top_A{}; t.Ctor(); return t }
//line :438:1
func (t *A_arbace_j2g_model_nest_top_A) Ctor() {}
//line :438:1
func (t *A_arbace_j2g_model_nest_top_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_39); if


	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1387 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = n__0; var arg_1391 any = A_arbace_j2g_model_A_const_31; var arg_1392 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1388 == nil { return ifn_1389.Invoke_O_O_O__O(arg_1390, arg_1391, arg_1392) } else { return linked_1388.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1387, arg_1390, arg_1391, arg_1392) } } }

func A_arbace_j2g_model_trivial_init_QMARK__A_New() *A_arbace_j2g_model_trivial_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_trivial_init_QMARK__A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Ctor() {}
//line :443:1
func (t *A_arbace_j2g_model_trivial_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_182; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var tmp2 any; var root_1397 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1399 lang.IFn; if





	linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any; var root_1393 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = cache__2; if linked_1394 == nil { arg_1400 = ifn_1395.Invoke_O__O(arg_1396) } else { arg_1400 = linked_1394.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1393, arg_1396) }; var arg_1401 any = n__0; if linked_1398 == nil { tmp2 = ifn_1399.Invoke_O_O__O(arg_1400, arg_1401) } else { tmp2 = linked_1398.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1397, arg_1400, arg_1401) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1402 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = cache__2; if linked_1403 == nil { tmp3 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp3 = linked_1403.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1402, arg_1405) }; return lang.RT_Get_O_O__O_NoInit(tmp3, n__0) } else {
//line :449:1
			var r__3 any; var tmp4 any; var root_1410 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1412 lang.IFn


			if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any; var root_1406 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = n__0; if linked_1407 == nil { arg_1413 = ifn_1408.Invoke_O__O(arg_1409) } else { arg_1413 = linked_1407.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1406, arg_1409) }; if linked_1411 == nil { tmp4 = ifn_1412.Invoke_O__O(arg_1413) } else { tmp4 = linked_1411.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1410, arg_1413) }
//line :451:1
			if jrt.J2g_Truth(tmp4) { r__3 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1414 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1416 lang.IFn

				if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = n__0; if linked_1415 == nil { tmp5 = ifn_1416.Invoke_O__O(arg_1417) } else { tmp5 = linked_1415.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1414, arg_1417) }
//line :451:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__3 = jrt.Boolean_TRUE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__3 any; var root_1418 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1420 lang.IFn


					if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = n__0; if linked_1419 == nil { d__3 = ifn_1420.Invoke_O__O(arg_1421) } else { d__3 = linked_1419.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1418, arg_1421) }
//line :451:1
					var st__4 any; var root_1422 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1424 lang.IFn


					if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__3); if linked_1423 == nil { st__4 = ifn_1424.Invoke_O__O(arg_1425) } else { st__4 = linked_1423.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1422, arg_1425) }
//line :451:1
					var and__1927000168__auto____5 any; var root_1426 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1428 lang.IFn




					if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(st__4); if linked_1427 == nil { and__1927000168__auto____5 = ifn_1428.Invoke_O__O(arg_1429) } else { and__1927000168__auto____5 = linked_1427.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1426, arg_1429) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1430 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1432 lang.IFn
						if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any = A_arbace_j2g_model_A_const_185.Invoke_O__O(st__4); if linked_1431 == nil { and__1927000168__auto____6 = ifn_1432.Invoke_O__O(arg_1433) } else { and__1927000168__auto____6 = linked_1431.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1430, arg_1433) }
//line :456:1
						if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1434 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1436 lang.IFn

							if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = A_arbace_j2g_model_A_const_186.Invoke_O__O(st__4); if linked_1435 == nil { and__1927000168__auto____7 = ifn_1436.Invoke_O__O(arg_1437) } else { and__1927000168__auto____7 = linked_1435.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1434, arg_1437) }
//line :456:1
							if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1438 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1440 lang.IFn


								if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(st__4); if linked_1439 == nil { and__1927000168__auto____8 = ifn_1440.Invoke_O__O(arg_1441) } else { and__1927000168__auto____8 = linked_1439.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1438, arg_1441) }
//line :456:1
								if jrt.J2g_Truth(and__1927000168__auto____8) { var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3), nil)



									if or__1927000174__auto____9 { r__3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1442 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__3); if linked_1443 == nil { r__3 = ifn_1444.Invoke_O__O(arg_1445) } else { r__3 = linked_1443.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1442, arg_1445) } } } else {
//line :456:1
										r__3 = and__1927000168__auto____8 } } else { r__3 = and__1927000168__auto____7 } } else { r__3 = and__1927000168__auto____6 } } else { r__3 = and__1927000168__auto____5 } } else {
//line :451:1
											r__3 = nil
										}
				}
			}






			var root_1446 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = cache__2; var arg_1450 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var arg_1451 any = n__0; var arg_1452 any = r__3; if linked_1447 == nil { ifn_1448.Invoke_O_O_O_O__O(arg_1449, arg_1450, arg_1451, arg_1452) } else { linked_1447.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1446, arg_1449, arg_1450, arg_1451, arg_1452) }
//line :449:1
			return r__3 } }

















func A_arbace_j2g_model_go_qualified_name_A_New() *A_arbace_j2g_model_go_qualified_name_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_go_qualified_name_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Ctor() {}
//line :467:1
func (t *A_arbace_j2g_model_go_qualified_name_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_1457 any = A_arbace_j2g_model_A_const_189.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any; var root_1453 any = A_arbace_j2g_model_A_const_100.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, A_arbace_j2g_model_pkg_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = n__0; if linked_1454 == nil { arg_1460 = ifn_1455.Invoke_O__O(arg_1456) } else { arg_1460 = linked_1454.(*A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_1453, arg_1456) }; if linked_1458 == nil { tmp2 = ifn_1459.Invoke_O__O(arg_1460) } else { tmp2 = linked_1458.(*aot_arbace_j2g_names.A_arbace_j2g_names_pkg_path_A).Invoke_O_O__O(root_1457, arg_1460) }; var tmp3 any = tmp2; var tmp4 any; var root_1461 any = A_arbace_j2g_model_A_const_92.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, A_arbace_j2g_model_go_name_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = n__0; if linked_1462 == nil { tmp4 = ifn_1463.Invoke_O__O(arg_1464) } else { tmp4 = linked_1462.(*A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1461, arg_1464) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()
}




func A_arbace_j2g_model_start_class_QMARK__A_New() *A_arbace_j2g_model_start_class_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_class_QMARK__A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Ctor() {}
//line :477:1
func (t *A_arbace_j2g_model_start_class_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var and__1927000168__auto____2 any; var root_1465 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = A_arbace_j2g_model_A_const_190.GetRawRoot__O(); if linked_1466 == nil { and__1927000168__auto____2 = ifn_1467.Invoke_O__O(arg_1468) } else { and__1927000168__auto____2 = linked_1466.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1465, arg_1468) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1469 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = n__0; if linked_1470 == nil { and__1927000168__auto____3 = ifn_1471.Invoke_O__O(arg_1472) } else { and__1927000168__auto____3 = linked_1470.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1469, arg_1472) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1477 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = A_arbace_j2g_model_A_const_190.GetRawRoot__O(); var arg_1481 any; var root_1473 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = n__0; if linked_1474 == nil { arg_1481 = ifn_1475.Invoke_O__O(arg_1476) } else { arg_1481 = linked_1474.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1473, arg_1476) }; if linked_1478 == nil { and__1927000168__auto____4 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { and__1927000168__auto____4 = linked_1478.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) }; if jrt.J2g_Truth(and__1927000168__auto____4) {
		var root_1486 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any; var root_1482 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = n__0; if linked_1483 == nil { arg_1489 = ifn_1484.Invoke_O__O(arg_1485) } else { arg_1489 = linked_1483.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1482, arg_1485) }; if linked_1487 == nil { tmp1 = ifn_1488.Invoke_O__O(arg_1489) } else { tmp1 = linked_1487.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1486, arg_1489) } } else {
//line :481:1
			tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_j2g_model_start_classes_A_New() *A_arbace_j2g_model_start_classes_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_A{}; t.Ctor(); return t }
//line :484:1
func (t *A_arbace_j2g_model_start_classes_A) Ctor() {}
//line :484:1
func (t *A_arbace_j2g_model_start_classes_A) Invoke_O__O(self any) any { var by_go__1 any; var root_1572 any = A_arbace_j2g_model_A_const_192.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1574 lang.IFn; if


	linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1576 any; var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_New(); var tmp2 *jrt.Class; var fncls__1568 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_fn_class; if fncls__1568 == nil { var fncls__1568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_fn_class = fncls__1568d; tmp2 = fncls__1568d } else { tmp2 = fncls__1568 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp4 any; var root_1569 any = A_arbace_j2g_model_A_const_35.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, A_arbace_j2g_model_T_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; if linked_1570 == nil { tmp4 = ifn_1571.Invoke__O() } else { tmp4 = linked_1570.(*A_arbace_j2g_model_T_A).Invoke_O__O(root_1569) }; arg_1576 = tmp3.Invoke_O__O(tmp4); if linked_1573 == nil { by_go__1 = ifn_1574.Invoke_O_O__O(arg_1575, arg_1576) } else { by_go__1 = linked_1573.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1572, arg_1575, arg_1576) }; var root_1577 any =
	A_arbace_j2g_model_A_const_194.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = by_go__1; var arg_1581 any = A_arbace_j2g_model_A_const_195.GetRawRoot__O(); if linked_1578 == nil { return ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { return linked_1578.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) } }
//line :487:1
func A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_New() *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A{}; t.Ctor(); return t }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A) Ctor() {}
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A) Invoke_O_O__O(self, s__1479000147__1 any) any { var tmp1 any = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_New_O_O(self, s__1479000147__1); var tmp2 *jrt.Class; var fncls__1567 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_fn_class; if fncls__1567 == nil { var fncls__1567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_fn_class = fncls__1567d; tmp2 = fncls__1567d } else { tmp2 = fncls__1567 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :487:1
func A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A{}; t.Ctor_O_O(p0, p1); return t }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A) Ctor_O_O(c__iter__1479000146, c__s__1479000147 any) { t.F_iter__1479000146 = c__iter__1479000146; t.F_s__1479000147 = c__s__1479000147 }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A) Invoke_O__O(self any) any { { var s__1479000147__1 any; var t_ any = t.F_s__1479000147; t.F_s__1479000147 = nil; s__1479000147__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1490 any = A_arbace_j2g_model_A_const_16.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = s__1479000147__1; if linked_1491 == nil { temp__1927000414__auto____2 = ifn_1492.Invoke_O__O(arg_1493) } else { temp__1927000414__auto____2 = linked_1491.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1490, arg_1493) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1479000147__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1494 any = A_arbace_j2g_model_A_const_143.GetRawRoot__O(); var linked_1495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1494, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1496 lang.IFn; if linked_1495 == nil { ifn_1496 = lang.IFn_Cast(root_1494) } else { ifn_1496 = nil }; var arg_1497 any = s__1479000147__3; if linked_1495 == nil { tmp1 = ifn_1496.Invoke_O__O(arg_1497) } else { tmp1 = linked_1495.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1494, arg_1497) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1498 any = A_arbace_j2g_model_A_const_144.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = s__1479000147__3; if linked_1499 == nil { c__1927001037__auto____4 = ifn_1500.Invoke_O__O(arg_1501) } else { c__1927001037__auto____4 = linked_1499.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1498, arg_1501) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1479000149__6 any; var root_1502 any = A_arbace_j2g_model_A_const_145.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1503 == nil { b__1479000149__6 = ifn_1504.Invoke_O__O(arg_1505) } else { b__1479000149__6 = linked_1503.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1502, arg_1505) }; var tmp2 any = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_New_O_I_O(b__1479000149__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1519 *jrt.Class = A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_fn_class; if fncls__1519 == nil { var fncls__1519d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_fn_class = fncls__1519d; tmp3 = fncls__1519d } else { tmp3 = fncls__1519 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1528 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any; var root_1520 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = b__1479000149__6; if linked_1521 == nil { arg_1531 = ifn_1522.Invoke_O__O(arg_1523) } else { arg_1531 = linked_1521.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1520, arg_1523) }; var arg_1532 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1479000146); var tmp5 any; var root_1524 any = A_arbace_j2g_model_A_const_153.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = s__1479000147__3; if linked_1525 == nil { tmp5 = ifn_1526.Invoke_O__O(arg_1527) } else { tmp5 = linked_1525.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1524, arg_1527) }; arg_1532 = tmp4.Invoke_O__O(tmp5); if linked_1529 == nil { return ifn_1530.Invoke_O_O__O(arg_1531, arg_1532) } else { return linked_1529.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1528, arg_1531, arg_1532) } } else { var root_1537 any = A_arbace_j2g_model_A_const_151.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any; var root_1533 any = A_arbace_j2g_model_A_const_152.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = b__1479000149__6; if linked_1534 == nil { arg_1540 = ifn_1535.Invoke_O__O(arg_1536) } else { arg_1540 = linked_1534.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1533, arg_1536) }; var arg_1541 any; if linked_1538 == nil { return ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { return linked_1538.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) } } } else { var n__4 any; var root_1542 any = A_arbace_j2g_model_A_const_154.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = s__1479000147__3; if linked_1543 == nil { n__4 = ifn_1544.Invoke_O__O(arg_1545) } else { n__4 = linked_1543.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1542, arg_1545) }; var tmp6 any; var root_1546 any = A_arbace_j2g_model_A_const_193.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = n__4; if linked_1547 == nil { tmp6 = ifn_1548.Invoke_O__O(arg_1549) } else { tmp6 = linked_1547.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1546, arg_1549) }; if jrt.J2g_Truth(tmp6) { var root_1558 any = A_arbace_j2g_model_A_const_66.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any; var tmp7 any; var root_1550 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = n__4; if linked_1551 == nil { tmp7 = ifn_1552.Invoke_O__O(arg_1553) } else { tmp7 = linked_1551.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1550, arg_1553) }; arg_1561 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, n__4); var arg_1562 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1479000146); var tmp9 any; var root_1554 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = s__1479000147__3; if linked_1555 == nil { tmp9 = ifn_1556.Invoke_O__O(arg_1557) } else { tmp9 = linked_1555.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1554, arg_1557) }; arg_1562 = tmp8.Invoke_O__O(tmp9); if linked_1559 == nil { return ifn_1560.Invoke_O_O__O(arg_1561, arg_1562) } else { return linked_1559.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1558, arg_1561, arg_1562) } } else { var tmp10 any; var root_1563 any = A_arbace_j2g_model_A_const_155.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = s__1479000147__3; if linked_1564 == nil { tmp10 = ifn_1565.Invoke_O__O(arg_1566) } else { tmp10 = linked_1564.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1563, arg_1566) }; s__1479000147__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :487:1
func A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A) Ctor_O_I_O(c__b__1479000149 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1479000149 = c__b__1479000149; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :487:1
func (t *A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A) Invoke_O__O(self any) any { { var i__1479000148__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1479000148__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1479000148__1)); var tmp2 any; var root_1506 any = A_arbace_j2g_model_A_const_193.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, A_arbace_j2g_model_start_class_QMARK__A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = n__2; if linked_1507 == nil { tmp2 = ifn_1508.Invoke_O__O(arg_1509) } else { tmp2 = linked_1507.(*A_arbace_j2g_model_start_class_QMARK__A).Invoke_O_O__O(root_1506, arg_1509) }; if jrt.J2g_Truth(tmp2) { var root_1514 any = A_arbace_j2g_model_A_const_148.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = t.F_b__1479000149; var arg_1518 any; var tmp3 any; var root_1510 any = A_arbace_j2g_model_A_const_191.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, A_arbace_j2g_model_go_qualified_name_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = n__2; if linked_1511 == nil { tmp3 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp3 = linked_1511.(*A_arbace_j2g_model_go_qualified_name_A).Invoke_O_O__O(root_1510, arg_1513) }; arg_1518 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, n__2); if linked_1515 == nil { ifn_1516.Invoke_O_O__O(arg_1517, arg_1518) } else { linked_1515.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1514, arg_1517, arg_1518) }; i__1479000148__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000148__1); continue L1 } else { i__1479000148__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1479000148__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_model_top_class_A_New() *A_arbace_j2g_model_top_class_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_top_class_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_j2g_model_top_class_A) Ctor() {}
//line :495:1
func (t *A_arbace_j2g_model_top_class_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_39); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var root_1582 any = A_arbace_j2g_model_A_const_57.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1584 lang.IFn; if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = n__0; var arg_1586 any = A_arbace_j2g_model_A_const_31; var arg_1587 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1583 == nil { return ifn_1584.Invoke_O_O_O__O(arg_1585, arg_1586, arg_1587) } else { return linked_1583.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1582, arg_1585, arg_1586, arg_1587) } } }

func A_arbace_j2g_model_pure_ctor_QMARK__A_New() *A_arbace_j2g_model_pure_ctor_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Ctor() {}
//line :497:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__A) Invoke_O_O_O_O_O__O(self, n__0, c__1, m__2, seen__3 any) any { var d__5 any; var root_1588 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1590 lang.IFn; if




	linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = c__1; if linked_1589 == nil { d__5 = ifn_1590.Invoke_O__O(arg_1591) } else { d__5 = linked_1589.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1588, arg_1591) }; var ab__6 any; if
	jrt.J2g_Truth(d__5) { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_196; var tmp2 any; var root_1592 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__5); if linked_1593 == nil { tmp2 = ifn_1594.Invoke_O__O(arg_1595) } else { tmp2 = linked_1593.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1592, arg_1595) }; ab__6 = lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), lang.Tuple_Create_O_O__IPersistentVector(Lit_44, A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2))) } else { ab__6 = nil }; var and__1927000168__auto____7 any = d__5; if
	jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = ab__6; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_1596 any = A_arbace_j2g_model_A_const_36.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = c__1; if linked_1597 == nil { and__1927000168__auto____9 = ifn_1598.Invoke_O__O(arg_1599) } else { and__1927000168__auto____9 = linked_1597.(*A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_1596, arg_1599) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 bool; var tmp3 any; var root_1600 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1602 lang.IFn
		if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any = c__1; if linked_1601 == nil { tmp3 = ifn_1602.Invoke_O__O(arg_1603) } else { tmp3 = linked_1601.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1600, arg_1603) }; var tmp4 any = tmp3; var tmp5 any; var root_1604 any = A_arbace_j2g_model_A_const_197.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, A_arbace_j2g_model_top_class_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = n__0; if linked_1605 == nil { tmp5 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp5 = linked_1605.(*A_arbace_j2g_model_top_class_A).Invoke_O_O__O(root_1604, arg_1607) }; and__1927000168__auto____10 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)
//line :504:1
		if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_1613 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1615 lang.IFn

			if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any; var root_1608 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = seen__3; var arg_1612 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2)); if linked_1609 == nil { arg_1616 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { arg_1616 = linked_1609.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }; if linked_1614 == nil { and__1927000168__auto____11 = ifn_1615.Invoke_O__O(arg_1616) } else { and__1927000168__auto____11 = linked_1614.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1613, arg_1616) }
//line :504:1
			if jrt.J2g_Truth(and__1927000168__auto____11) { var seen__12 any; var root_1617 any = A_arbace_j2g_model_A_const_14.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1619 lang.IFn


				if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = seen__3; var arg_1621 any = lang.Tuple_Create_O_O__IPersistentVector(c__1, A_arbace_j2g_model_A_const_112.Invoke_O__O(m__2)); if linked_1618 == nil { seen__12 = ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { seen__12 = linked_1618.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1617, arg_1620, arg_1621) }
//line :504:1
				var call__13 any = A_arbace_j2g_model_A_const_198.Invoke_O__O(ab__6); var sup__14 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__5); var and__1927000168__auto____15 any; var root_1622 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1624 lang.IFn





				if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = A_arbace_j2g_model_A_const_199.Invoke_O__O(ab__6); if linked_1623 == nil { and__1927000168__auto____15 = ifn_1624.Invoke_O__O(arg_1625) } else { and__1927000168__auto____15 = linked_1623.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1622, arg_1625) }; if jrt.J2g_Truth(and__1927000168__auto____15) { var and__1927000168__auto____16 any; var root_1626 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1628 lang.IFn
					if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = A_arbace_j2g_model_A_const_200.Invoke_O__O(ab__6); if linked_1627 == nil { and__1927000168__auto____16 = ifn_1628.Invoke_O__O(arg_1629) } else { and__1927000168__auto____16 = linked_1627.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1626, arg_1629) }
//line :510:1
					if jrt.J2g_Truth(and__1927000168__auto____16) { var and__1927000168__auto____17 any; var or__1927000174__auto____17 bool = lang.Util_Identical_O_O__Z_NoInit(call__13, nil)

						if or__1927000174__auto____17 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____17).Ref() } else { var and__1927000168__auto____18 any; var root_1637 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1639 lang.IFn
							if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any; var tmp6 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_New_O_O(n__0, seen__12); var tmp7 *jrt.Class; var fncls__1636 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_fn_class; if fncls__1636 == nil { var fncls__1636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_fn_class = fncls__1636d; tmp7 = fncls__1636d } else { tmp7 = fncls__1636 }; arg_1640 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1641 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(call__13); if linked_1638 == nil { and__1927000168__auto____18 = ifn_1639.Invoke_O_O__O(arg_1640, arg_1641) } else { and__1927000168__auto____18 = linked_1638.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1637, arg_1640, arg_1641) }; if jrt.J2g_Truth(and__1927000168__auto____18) { var or__1927000174__auto____19 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_174.Invoke_O__O(call__13), nil)
								if or__1927000174__auto____19 { and__1927000168__auto____17 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19).Ref() } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_203); var or__1927000174__auto____20 any = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_174.Invoke_O__O(call__13)); if jrt.J2g_Truth(or__1927000174__auto____20) { and__1927000168__auto____17 = or__1927000174__auto____20 } else {
									var root_1642 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = n__0; var arg_1646 any = A_arbace_j2g_model_A_const_174.Invoke_O__O(call__13); var arg_1647 any = A_arbace_j2g_model_A_const_205.Invoke_O__O(call__13); var arg_1648 any = seen__12; if linked_1643 == nil { and__1927000168__auto____17 = ifn_1644.Invoke_O_O_O_O__O(arg_1645, arg_1646, arg_1647, arg_1648) } else { and__1927000168__auto____17 = linked_1643.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1642, arg_1645, arg_1646, arg_1647, arg_1648) } } } } else {
//line :513:1
										and__1927000168__auto____17 = and__1927000168__auto____18 } }
//line :510:1
						if jrt.J2g_Truth(and__1927000168__auto____17) { var and__1927000168__auto____18_2 any; var or__1927000174__auto____18 any; var root_1649 any = A_arbace_j2g_model_A_const_42.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1651 lang.IFn





							if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = call__13; if linked_1650 == nil { or__1927000174__auto____18 = ifn_1651.Invoke_O__O(arg_1652) } else { or__1927000174__auto____18 = linked_1650.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1649, arg_1652) }; if jrt.J2g_Truth(or__1927000174__auto____18) { and__1927000168__auto____18_2 = or__1927000174__auto____18 } else { var or__1927000174__auto____19_2 bool = lang.Util_Identical_O_O__Z_NoInit(sup__14, nil); if or__1927000174__auto____19_2 { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____19_2).Ref() } else { and__1927000168__auto____18_2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sup__14, Lit_20)).Ref() } }
//line :510:1
							if jrt.J2g_Truth(and__1927000168__auto____18_2) { var and__1927000168__auto____19 any; var root_1664 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1666 lang.IFn






								if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any; var tmp9 any = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_New_O_O(n__0, seen__12); var tmp10 *jrt.Class; var fncls__1659 *jrt.Class = A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_fn_class; if fncls__1659 == nil { var fncls__1659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_fn_class = fncls__1659d; tmp10 = fncls__1659d } else { tmp10 = fncls__1659 }; arg_1667 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1668 any; var tmp11 *lang.Keyword = A_arbace_j2g_model_A_const_206; var tmp12 any; var root_1660 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__5); if linked_1661 == nil { tmp12 = ifn_1662.Invoke_O__O(arg_1663) } else { tmp12 = linked_1661.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1660, arg_1663) }; arg_1668 = tmp11.Invoke_O__O(tmp12); if linked_1665 == nil { and__1927000168__auto____19 = ifn_1666.Invoke_O_O__O(arg_1667, arg_1668) } else { and__1927000168__auto____19 = linked_1665.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1664, arg_1667, arg_1668) }
//line :510:1
								if jrt.J2g_Truth(and__1927000168__auto____19) { var or__1927000174__auto____20_2 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_207.Invoke_O__O(ab__6), nil)







									if or__1927000174__auto____20_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20_2).Ref() } else { var root_1669 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = n__0; var arg_1673 any = A_arbace_j2g_model_A_const_207.Invoke_O__O(ab__6); var arg_1674 any = seen__12; if linked_1670 == nil { return ifn_1671.Invoke_O_O_O__O(arg_1672, arg_1673, arg_1674) } else { return linked_1670.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1669, arg_1672, arg_1673, arg_1674) } } } else {
//line :510:1
										return and__1927000168__auto____19 } } else { return and__1927000168__auto____18_2 } } else { return and__1927000168__auto____17 } } else { return and__1927000168__auto____16 } } else { return and__1927000168__auto____15 } } else {
//line :504:1
											return and__1927000168__auto____11 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9 } } else { return and__1927000168__auto____8 } } else { return and__1927000168__auto____7 } }








func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A{}; t.Ctor_O_O(p0, p1); return t }
//line :513:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :513:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A) Invoke_O_O__O(self, p1__1479000158_SHARP___1 any) any { var root_1630 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = t.F_n; var arg_1634 any = p1__1479000158_SHARP___1; var arg_1635 any = t.F_seen; if linked_1631 == nil { return ifn_1632.Invoke_O_O_O__O(arg_1633, arg_1634, arg_1635) } else { return linked_1631.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1630, arg_1633, arg_1634, arg_1635) } }



func A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A{}; t.Ctor_O_O(p0, p1); return t }
//line :517:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :517:1
func (t *A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A) Invoke_O_O__O(self, p1__1479000159_SHARP___1 any) any { var root_1653 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = t.F_n; var arg_1657 any = p1__1479000159_SHARP___1; var arg_1658 any = t.F_seen; if linked_1654 == nil { return ifn_1655.Invoke_O_O_O__O(arg_1656, arg_1657, arg_1658) } else { return linked_1654.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1653, arg_1656, arg_1657, arg_1658) } }


func A_arbace_j2g_model_pure_node_QMARK__A_New() *A_arbace_j2g_model_pure_node_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Ctor() {}
//line :520:1
func (t *A_arbace_j2g_model_pure_node_QMARK__A) Invoke_O_O_O_O__O(self, n__0, node__1, seen__2 any) any { var G__1479000171__4_ any = A_arbace_j2g_model_A_const_208.Invoke_O__O(node__1); switch



	lang.Util_Hash_O__I_NoInit(G__1479000171__4_) >> 3 & 63 { case 1: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_209) { var and__1927000168__auto____5 any; var root_1676 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1678 lang.IFn


















		if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = A_arbace_j2g_model_A_const_210.Invoke_O__O(node__1); if linked_1677 == nil { and__1927000168__auto____5 = ifn_1678.Invoke_O__O(arg_1679) } else { and__1927000168__auto____5 = linked_1677.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1676, arg_1679) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1680 any = A_arbace_j2g_model_A_const_106.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = A_arbace_j2g_model_A_const_211.Invoke_O__O(node__1); if linked_1681 == nil { and__1927000168__auto____6 = ifn_1682.Invoke_O__O(arg_1683) } else { and__1927000168__auto____6 = linked_1681.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1680, arg_1683) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1684 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = n__0; var arg_1688 any = A_arbace_j2g_model_A_const_212.Invoke_O__O(node__1); var arg_1689 any = seen__2; if linked_1685 == nil { return ifn_1686.Invoke_O_O_O__O(arg_1687, arg_1688, arg_1689) } else { return linked_1685.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1684, arg_1687, arg_1688, arg_1689) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } }
//line :524:1
	case 11: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_213) { var tmp1 any = A_arbace_j2g_model_A_const_214; var tmp2 *lang.Keyword = A_arbace_j2g_model_A_const_208; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(A_arbace_j2g_model_A_const_215.Invoke_O__O(node__1)))







		if and__1927000168__auto____5_2 { var and__1927000168__auto____6_2 any; var root_1690 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_model_A_const_216; var arg_1693 any = tmp3.Invoke_O__O(A_arbace_j2g_model_A_const_215.Invoke_O__O(node__1)); if linked_1691 == nil { and__1927000168__auto____6_2 = ifn_1692.Invoke_O__O(arg_1693) } else { and__1927000168__auto____6_2 = linked_1691.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1690, arg_1693) }; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var root_1694 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1694, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1696 lang.IFn; if linked_1695 == nil { ifn_1696 = lang.IFn_Cast(root_1694) } else { ifn_1696 = nil }; var arg_1697 any = n__0; var arg_1698 any = A_arbace_j2g_model_A_const_217.Invoke_O__O(node__1); var arg_1699 any = seen__2; if linked_1695 == nil { return ifn_1696.Invoke_O_O_O__O(arg_1697, arg_1698, arg_1699) } else { return linked_1695.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1694, arg_1697, arg_1698, arg_1699) } } else { return and__1927000168__auto____6_2 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_2).Ref() } }
//line :524:1
	case 13: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_218) { var tmp4 any = A_arbace_j2g_model_A_const_219; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_j2g_model_A_const_169.Invoke_O__O(node__1))













		if and__1927000168__auto____5_3 { var and__1927000168__auto____6_3 bool; var or__1927000174__auto____6 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_47, A_arbace_j2g_model_A_const_150.Invoke_O__O(node__1))
			if and__1927000168__auto____6_4 { or__1927000174__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_48, A_arbace_j2g_model_A_const_124.Invoke_O__O(node__1)) } else { or__1927000174__auto____6 = and__1927000168__auto____6_4 }; if or__1927000174__auto____6 { and__1927000168__auto____6_3 = or__1927000174__auto____6 } else { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(n__0, A_arbace_j2g_model_A_const_150.Invoke_O__O(node__1))

				if and__1927000168__auto____7 { and__1927000168__auto____6_3 = lang.Util_Equiv_O_O__Z_NoInit(Lit_49, A_arbace_j2g_model_A_const_124.Invoke_O__O(node__1)) } else { and__1927000168__auto____6_3 = and__1927000168__auto____7 } }
//line :538:1
			if and__1927000168__auto____6_3 {



				var root_1707 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any; var tmp5 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_New_O_O(n__0, seen__2); var tmp6 *jrt.Class; var fncls__1706 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_fn_class; if fncls__1706 == nil { var fncls__1706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_fn_class = fncls__1706d; tmp6 = fncls__1706d } else { tmp6 = fncls__1706 }; arg_1710 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1711 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(node__1); if linked_1708 == nil { return ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { return linked_1708.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) } } else {
//line :538:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_3).Ref() } }
//line :524:1
	case 14: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_220) { var and__1927000168__auto____5_4 bool; var tmp7 any; var tmp8 *lang.Keyword = A_arbace_j2g_model_A_const_221; var or__1927000174__auto____5 any = tmp8.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1))






		if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else { var tmp9 *lang.Keyword = A_arbace_j2g_model_A_const_150; tmp7 = tmp9.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)) }; and__1927000168__auto____5_4 = lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp7); if and__1927000168__auto____5_4 { var root_1712 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = n__0; var arg_1716 any = A_arbace_j2g_model_A_const_217.Invoke_O__O(node__1); var arg_1717 any = seen__2; if linked_1713 == nil { return ifn_1714.Invoke_O_O_O__O(arg_1715, arg_1716, arg_1717) } else { return linked_1713.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1712, arg_1715, arg_1716, arg_1717) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5_4).Ref() } }
//line :524:1
	case 15: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_214) { return jrt.Boolean_TRUE.Ref() }; case 19: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_223) { var and__1927000168__auto____5_5 any; var root_1725 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1727 lang.IFn


		if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any; var tmp10 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_New_O_O(n__0, seen__2); var tmp11 *jrt.Class; var fncls__1724 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_fn_class; if fncls__1724 == nil { var fncls__1724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_fn_class = fncls__1724d; tmp11 = fncls__1724d } else { tmp11 = fncls__1724 }; arg_1728 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1729 any = A_arbace_j2g_model_A_const_224.Invoke_O__O(node__1); if linked_1726 == nil { and__1927000168__auto____5_5 = ifn_1727.Invoke_O_O__O(arg_1728, arg_1729) } else { and__1927000168__auto____5_5 = linked_1726.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1725, arg_1728, arg_1729) }; if jrt.J2g_Truth(and__1927000168__auto____5_5) { var root_1730 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = n__0; var arg_1734 any = A_arbace_j2g_model_A_const_207.Invoke_O__O(node__1); var arg_1735 any = seen__2; if linked_1731 == nil { return ifn_1732.Invoke_O_O_O__O(arg_1733, arg_1734, arg_1735) } else { return linked_1731.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1730, arg_1733, arg_1734, arg_1735) } } else { return and__1927000168__auto____5_5 } }
//line :524:1
	case 21: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_225) {





		var tmp12 any; var tmp13 *lang.Keyword = A_arbace_j2g_model_A_const_221; var or__1927000174__auto____5_2 any = tmp13.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp12 = or__1927000174__auto____5_2 } else { var tmp14 *lang.Keyword = A_arbace_j2g_model_A_const_150; tmp12 = tmp14.Invoke_O__O(A_arbace_j2g_model_A_const_222.Invoke_O__O(node__1)) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(n__0, tmp12)).Ref() }
//line :524:1
	case 25: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_226) { var and__1927000168__auto____5_6 any; var root_1743 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1743, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1745 lang.IFn

		if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any; var tmp15 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_New_O_O(n__0, seen__2); var tmp16 *jrt.Class; var fncls__1742 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_fn_class; if fncls__1742 == nil { var fncls__1742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_fn_class = fncls__1742d; tmp16 = fncls__1742d } else { tmp16 = fncls__1742 }; arg_1746 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_1747 any = A_arbace_j2g_model_A_const_227.Invoke_O__O(node__1); if linked_1744 == nil { and__1927000168__auto____5_6 = ifn_1745.Invoke_O_O__O(arg_1746, arg_1747) } else { and__1927000168__auto____5_6 = linked_1744.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1743, arg_1746, arg_1747) }; if jrt.J2g_Truth(and__1927000168__auto____5_6) { var root_1748 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = n__0; var arg_1752 any = A_arbace_j2g_model_A_const_228.Invoke_O__O(node__1); var arg_1753 any = seen__2; if linked_1749 == nil { return ifn_1750.Invoke_O_O_O__O(arg_1751, arg_1752, arg_1753) } else { return linked_1749.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1748, arg_1751, arg_1752, arg_1753) } } else { return and__1927000168__auto____5_6 } }
//line :524:1
	case 29: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_229) { return jrt.Boolean_TRUE.Ref() }; case 30: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_230) { return jrt.Boolean_TRUE.Ref() }; case 34: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_231) {




		var root_1763 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any; var tmp17 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_New(); var tmp18 *jrt.Class; var fncls__1762 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_fn_class; if fncls__1762 == nil { var fncls__1762d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_fn_class = fncls__1762d; tmp18 = fncls__1762d } else { tmp18 = fncls__1762 }; arg_1766 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1767 any = A_arbace_j2g_model_A_const_233.Invoke_O__O(node__1); if linked_1764 == nil { return ifn_1765.Invoke_O_O__O(arg_1766, arg_1767) } else { return linked_1764.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1763, arg_1766, arg_1767) } }
//line :524:1
	case 39: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_234) { var and__1927000168__auto____5_7 any; var root_1775 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1777 lang.IFn








		if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any; var tmp19 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_New_O_O(n__0, seen__2); var tmp20 *jrt.Class; var fncls__1774 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_fn_class; if fncls__1774 == nil { var fncls__1774d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_fn_class = fncls__1774d; tmp20 = fncls__1774d } else { tmp20 = fncls__1774 }; arg_1778 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_1779 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(node__1); if linked_1776 == nil { and__1927000168__auto____5_7 = ifn_1777.Invoke_O_O__O(arg_1778, arg_1779) } else { and__1927000168__auto____5_7 = linked_1776.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1775, arg_1778, arg_1779) }; if jrt.J2g_Truth(and__1927000168__auto____5_7) { var and__1927000168__auto____6_5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_235.Invoke_O__O(node__1), nil); if and__1927000168__auto____6_5 { var or__1927000174__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_20, A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1))

			if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var and__1927000168__auto____8 any; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1), n__0)
				if or__1927000174__auto____8 { and__1927000168__auto____8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var root_1780 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1782 lang.IFn; if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1); if linked_1781 == nil { and__1927000168__auto____8 = ifn_1782.Invoke_O__O(arg_1783) } else { and__1927000168__auto____8 = linked_1781.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1780, arg_1783) } }; if jrt.J2g_Truth(and__1927000168__auto____8) {
					var root_1784 any = A_arbace_j2g_model_A_const_204.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = n__0; var arg_1788 any = A_arbace_j2g_model_A_const_174.Invoke_O__O(node__1); var arg_1789 any = A_arbace_j2g_model_A_const_205.Invoke_O__O(node__1); var arg_1790 any = seen__2; if linked_1785 == nil { return ifn_1786.Invoke_O_O_O_O__O(arg_1787, arg_1788, arg_1789, arg_1790) } else { return linked_1785.(*A_arbace_j2g_model_pure_ctor_QMARK__A).Invoke_O_O_O_O_O__O(root_1784, arg_1787, arg_1788, arg_1789, arg_1790) } } else {
//line :536:1
						return and__1927000168__auto____8 } } } else {
//line :533:1
							return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6_5).Ref() } } else { return and__1927000168__auto____5_7 } }
//line :524:1
	case 43: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_236) { var and__1927000168__auto____5_8 any; var root_1791 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1793 lang.IFn



















		if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_model_A_const_237); var arg_1794 any = tmp21.Invoke_O__O(A_arbace_j2g_model_A_const_238.Invoke_O__O(node__1)); if linked_1792 == nil { and__1927000168__auto____5_8 = ifn_1793.Invoke_O__O(arg_1794) } else { and__1927000168__auto____5_8 = linked_1792.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1791, arg_1794) }; if jrt.J2g_Truth(and__1927000168__auto____5_8) { var and__1927000168__auto____6_6 any; var root_1795 any = A_arbace_j2g_model_A_const_118.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = A_arbace_j2g_model_A_const_239; var arg_1799 any = A_arbace_j2g_model_A_const_240.Invoke_O__O(node__1); if linked_1796 == nil { and__1927000168__auto____6_6 = ifn_1797.Invoke_O_O__O(arg_1798, arg_1799) } else { and__1927000168__auto____6_6 = linked_1796.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1795, arg_1798, arg_1799) }; if jrt.J2g_Truth(and__1927000168__auto____6_6) { var root_1807 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any; var tmp22 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_New_O_O(n__0, seen__2); var tmp23 *jrt.Class; var fncls__1806 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_fn_class; if fncls__1806 == nil { var fncls__1806d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_fn_class = fncls__1806d; tmp23 = fncls__1806d } else { tmp23 = fncls__1806 }; arg_1810 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_1811 any = A_arbace_j2g_model_A_const_202.Invoke_O__O(node__1); if linked_1808 == nil { return ifn_1809.Invoke_O_O__O(arg_1810, arg_1811) } else { return linked_1808.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1807, arg_1810, arg_1811) } } else { return and__1927000168__auto____6_6 } } else { return and__1927000168__auto____5_8 } }
//line :524:1
	case 44: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_241) { return jrt.Boolean_TRUE.Ref() }; case 46: if any(G__1479000171__4_) == any(A_arbace_j2g_model_A_const_242) {



		var root_1819 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any; var tmp24 any = A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_New_O_O(n__0, seen__2); var tmp25 *jrt.Class; var fncls__1818 *jrt.Class = A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_fn_class; if fncls__1818 == nil { var fncls__1818d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_fn_class = fncls__1818d; tmp25 = fncls__1818d } else { tmp25 = fncls__1818 }; arg_1822 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var arg_1823 any = A_arbace_j2g_model_A_const_243.Invoke_O__O(node__1); if linked_1820 == nil { return ifn_1821.Invoke_O_O__O(arg_1822, arg_1823) } else { return linked_1820.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1819, arg_1822, arg_1823) } }
//line :524:1
	default:}; return jrt.Boolean_FALSE.Ref() }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A{}; t.Ctor_O_O(p0, p1); return t }
//line :526:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :526:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A) Invoke_O_O__O(self, p1__1479000165_SHARP___1 any) any { var root_1736 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = t.F_n; var arg_1740 any = p1__1479000165_SHARP___1; var arg_1741 any = t.F_seen; if linked_1737 == nil { return ifn_1738.Invoke_O_O_O__O(arg_1739, arg_1740, arg_1741) } else { return linked_1737.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1736, arg_1739, arg_1740, arg_1741) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A{}; t.Ctor_O_O(p0, p1); return t }
//line :527:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :527:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A) Invoke_O_O__O(self, p__1479000174__1 any) any { var vec__1479000176__2 any = p__1479000174__1; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1479000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1718 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1720 lang.IFn; _ = ___3; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = t.F_n; var arg_1722 any = init__4; var arg_1723 any = t.F_seen; if linked_1719 == nil { return ifn_1720.Invoke_O_O_O__O(arg_1721, arg_1722, arg_1723) } else { return linked_1719.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1718, arg_1721, arg_1722, arg_1723) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A{}; t.Ctor_O_O(p0, p1); return t }
//line :528:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :528:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A) Invoke_O_O__O(self, p1__1479000166_SHARP___1 any) any { var root_1812 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1814 lang.IFn; if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = t.F_n; var arg_1816 any = p1__1479000166_SHARP___1; var arg_1817 any = t.F_seen; if linked_1813 == nil { return ifn_1814.Invoke_O_O_O__O(arg_1815, arg_1816, arg_1817) } else { return linked_1813.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1812, arg_1815, arg_1816, arg_1817) } }
func A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_New() *A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A{}; t.Ctor(); return t }
//line :529:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A) Ctor() {}
//line :529:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A) Invoke_O_O__O(self, p1__1479000167_SHARP___1 any) any { var tmp1 any = A_arbace_j2g_model_A_const_229; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_model_A_const_208.Invoke_O__O(p1__1479000167_SHARP___1)); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_1754 any = A_arbace_j2g_model_A_const_232.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = A_arbace_j2g_model_A_const_217.Invoke_O__O(p1__1479000167_SHARP___1); if linked_1755 == nil { and__1927000168__auto____3 = ifn_1756.Invoke_O__O(arg_1757) } else { and__1927000168__auto____3 = linked_1755.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_1754, arg_1757) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1758 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(A_arbace_j2g_model_A_const_217.Invoke_O__O(p1__1479000167_SHARP___1)))).Ref(); if linked_1759 == nil { return ifn_1760.Invoke_O__O(arg_1761) } else { return linked_1759.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1758, arg_1761) } } else { return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }



func A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A{}; t.Ctor_O_O(p0, p1); return t }
//line :533:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :533:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A) Invoke_O_O__O(self, p1__1479000168_SHARP___1 any) any { var root_1768 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = t.F_n; var arg_1772 any = p1__1479000168_SHARP___1; var arg_1773 any = t.F_seen; if linked_1769 == nil { return ifn_1770.Invoke_O_O_O__O(arg_1771, arg_1772, arg_1773) } else { return linked_1769.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1768, arg_1771, arg_1772, arg_1773) } }








func A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A{}; t.Ctor_O_O(p0, p1); return t }
//line :542:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :542:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A) Invoke_O_O__O(self, p1__1479000169_SHARP___1 any) any { var root_1700 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = t.F_n; var arg_1704 any = p1__1479000169_SHARP___1; var arg_1705 any = t.F_seen; if linked_1701 == nil { return ifn_1702.Invoke_O_O_O__O(arg_1703, arg_1704, arg_1705) } else { return linked_1701.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1700, arg_1703, arg_1704, arg_1705) } }

func A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_New_O_O(p0, p1 any) *A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A{}; t.Ctor_O_O(p0, p1); return t }
//line :544:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A) Ctor_O_O(c__n, c__seen any) { t.F_n = c__n; t.F_seen = c__seen }
//line :544:1
func (t *A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A) Invoke_O_O__O(self, p1__1479000170_SHARP___1 any) any { var root_1800 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = t.F_n; var arg_1804 any = p1__1479000170_SHARP___1; var arg_1805 any = t.F_seen; if linked_1801 == nil { return ifn_1802.Invoke_O_O_O__O(arg_1803, arg_1804, arg_1805) } else { return linked_1801.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1800, arg_1803, arg_1804, arg_1805) } }


func A_arbace_j2g_model_benign_init_QMARK__A_New() *A_arbace_j2g_model_benign_init_QMARK__A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__A{}; t.Ctor(); return t }
//line :547:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Ctor() {}
//line :547:1
func (t *A_arbace_j2g_model_benign_init_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_model_A_const_182; var cache__2 any = tmp1.Invoke_O__O(A_arbace_j2g_model_A_const_33.Get__O()); var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_model_A_const_245, n__0); var tmp2 any; var root_1828 any = A_arbace_j2g_model_A_const_34.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1830 lang.IFn; if








	linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any; var root_1824 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = cache__2; if linked_1825 == nil { arg_1831 = ifn_1826.Invoke_O__O(arg_1827) } else { arg_1831 = linked_1825.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1824, arg_1827) }; var arg_1832 any = k__3; if linked_1829 == nil { tmp2 = ifn_1830.Invoke_O_O__O(arg_1831, arg_1832) } else { tmp2 = linked_1829.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1828, arg_1831, arg_1832) }; if jrt.J2g_Truth(tmp2) {
		var tmp3 any; var root_1833 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = cache__2; if linked_1834 == nil { tmp3 = ifn_1835.Invoke_O__O(arg_1836) } else { tmp3 = linked_1834.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1833, arg_1836) }; return lang.RT_Get_O_O__O_NoInit(tmp3, k__3) } else {
//line :556:1
			var r__4 any; var tmp4 any; var root_1837 any = A_arbace_j2g_model_A_const_188.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1839 lang.IFn


			if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = n__0; if linked_1838 == nil { tmp4 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp4 = linked_1838.(*A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1837, arg_1840) }
//line :558:1
			if jrt.J2g_Truth(tmp4) { r__4 = jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var root_1841 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1843 lang.IFn

				if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = n__0; if linked_1842 == nil { tmp5 = ifn_1843.Invoke_O__O(arg_1844) } else { tmp5 = linked_1842.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1841, arg_1844) }
//line :558:1
				if lang.Util_Identical_O_O__Z_NoInit(tmp5, nil) { r__4 = jrt.Boolean_FALSE.Ref() } else { if A_arbace_j2g_model_A_const_60 != nil { var d__4 any; var root_1845 any = A_arbace_j2g_model_A_const_39.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1847 lang.IFn


					if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = n__0; if linked_1846 == nil { d__4 = ifn_1847.Invoke_O__O(arg_1848) } else { d__4 = linked_1846.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1845, arg_1848) }
//line :558:1
					var st__5 any; var root_1849 any = A_arbace_j2g_model_A_const_12.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1851 lang.IFn


					if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = A_arbace_j2g_model_A_const_183.Invoke_O__O(d__4); if linked_1850 == nil { st__5 = ifn_1851.Invoke_O__O(arg_1852) } else { st__5 = linked_1850.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1849, arg_1852) }
//line :558:1
					var and__1927000168__auto____6 any; var root_1853 any = A_arbace_j2g_model_A_const_48.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1855 lang.IFn




					if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = A_arbace_j2g_model_A_const_185.Invoke_O__O(st__5); if linked_1854 == nil { and__1927000168__auto____6 = ifn_1855.Invoke_O__O(arg_1856) } else { and__1927000168__auto____6 = linked_1854.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1853, arg_1856) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var root_1857 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1859 lang.IFn
						if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = A_arbace_j2g_model_A_const_186.Invoke_O__O(st__5); if linked_1858 == nil { and__1927000168__auto____7 = ifn_1859.Invoke_O__O(arg_1860) } else { and__1927000168__auto____7 = linked_1858.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1857, arg_1860) }
//line :563:1
						if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_1861 any = A_arbace_j2g_model_A_const_30.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1863 lang.IFn

							if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = A_arbace_j2g_model_A_const_187.Invoke_O__O(st__5); if linked_1862 == nil { and__1927000168__auto____8 = ifn_1863.Invoke_O__O(arg_1864) } else { and__1927000168__auto____8 = linked_1862.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1861, arg_1864) }
//line :563:1
							if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var or__1927000174__auto____9 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4), nil)


								if or__1927000174__auto____9 { and__1927000168__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else { var root_1865 any = A_arbace_j2g_model_A_const_244.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, A_arbace_j2g_model_benign_init_QMARK__A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = A_arbace_j2g_model_A_const_80.Invoke_O__O(d__4); if linked_1866 == nil { and__1927000168__auto____9 = ifn_1867.Invoke_O__O(arg_1868) } else { and__1927000168__auto____9 = linked_1866.(*A_arbace_j2g_model_benign_init_QMARK__A).Invoke_O_O__O(root_1865, arg_1868) } }
//line :563:1
								if jrt.J2g_Truth(and__1927000168__auto____9) {



									var root_1876 any = A_arbace_j2g_model_A_const_50.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any; var tmp6 any = A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_New_O(n__0); var tmp7 *jrt.Class; var fncls__1875 *jrt.Class = A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_fn_class; if fncls__1875 == nil { var fncls__1875d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_fn_class = fncls__1875d; tmp7 = fncls__1875d } else { tmp7 = fncls__1875 }; arg_1879 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1880 any = A_arbace_j2g_model_A_const_184.Invoke_O__O(st__5); if linked_1877 == nil { r__4 = ifn_1878.Invoke_O_O__O(arg_1879, arg_1880) } else { r__4 = linked_1877.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1876, arg_1879, arg_1880) } } else {
//line :563:1
										r__4 = and__1927000168__auto____9 } } else { r__4 = and__1927000168__auto____8 } } else { r__4 = and__1927000168__auto____7 } } else { r__4 = and__1927000168__auto____6 } } else {
//line :558:1
											r__4 = nil
										}
				}
			}






			var root_1881 any = A_arbace_j2g_model_A_const_25.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = cache__2; var arg_1885 any = A_arbace_j2g_model_A_const_149.GetRawRoot__O(); var arg_1886 any = k__3; var arg_1887 any = r__4; if linked_1882 == nil { ifn_1883.Invoke_O_O_O_O__O(arg_1884, arg_1885, arg_1886, arg_1887) } else { linked_1882.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1881, arg_1884, arg_1885, arg_1886, arg_1887) }
//line :556:1
			return r__4 } }










func A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_New_O(p0 any) *A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A{}; t.Ctor_O(p0); return t }
//line :567:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :567:1
func (t *A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A) Invoke_O_O__O(self, p1__1479000191_SHARP___1 any) any { var root_1869 any = A_arbace_j2g_model_A_const_201.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, A_arbace_j2g_model_pure_node_QMARK__A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = t.F_n; var arg_1873 any = p1__1479000191_SHARP___1; var arg_1874 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1870 == nil { return ifn_1871.Invoke_O_O_O__O(arg_1872, arg_1873, arg_1874) } else { return linked_1870.(*A_arbace_j2g_model_pure_node_QMARK__A).Invoke_O_O_O_O__O(root_1869, arg_1872, arg_1873, arg_1874) } }

































































type A_arbace_j2g_model_A struct{ jrt.Object }

var A_arbace_j2g_model_A_const_pool *jrt.RefArray

var A_arbace_j2g_model_A_const_0 *lang.Var

var A_arbace_j2g_model_A_const_1 any

var A_arbace_j2g_model_A_const_2 any

var A_arbace_j2g_model_A_const_3 any

var A_arbace_j2g_model_A_const_4 any

var A_arbace_j2g_model_A_const_5 any

var A_arbace_j2g_model_A_const_6 any

var A_arbace_j2g_model_A_const_7 any

var A_arbace_j2g_model_A_const_8 any

var A_arbace_j2g_model_A_const_9 *lang.Var

var A_arbace_j2g_model_A_const_10 any

var A_arbace_j2g_model_A_const_11 *lang.Var

var A_arbace_j2g_model_A_const_12 *lang.Var

var A_arbace_j2g_model_A_const_13 *lang.Var

var A_arbace_j2g_model_A_const_14 *lang.Var

var A_arbace_j2g_model_A_const_15 any

var A_arbace_j2g_model_A_const_16 *lang.Var

var A_arbace_j2g_model_A_const_17 *lang.Var

var A_arbace_j2g_model_A_const_18 *lang.Var

var A_arbace_j2g_model_A_const_19 *lang.Var

var A_arbace_j2g_model_A_const_20 *lang.Var

var A_arbace_j2g_model_A_const_21 *lang.Var

var A_arbace_j2g_model_A_const_22 *lang.Var

var A_arbace_j2g_model_A_const_23 *lang.Var

var A_arbace_j2g_model_A_const_24 any

var A_arbace_j2g_model_A_const_25 *lang.Var

var A_arbace_j2g_model_A_const_26 *lang.Var

var A_arbace_j2g_model_A_const_27 *lang.Var

var A_arbace_j2g_model_A_const_28 *lang.Var

var A_arbace_j2g_model_A_const_29 *lang.Var

var A_arbace_j2g_model_A_const_30 *lang.Var

var A_arbace_j2g_model_A_const_31 any

var A_arbace_j2g_model_A_const_32 *lang.Keyword

var A_arbace_j2g_model_A_const_33 *lang.Var

var A_arbace_j2g_model_A_const_34 *lang.Var

var A_arbace_j2g_model_A_const_35 *lang.Var

var A_arbace_j2g_model_A_const_36 *lang.Var

var A_arbace_j2g_model_A_const_37 *lang.Keyword

var A_arbace_j2g_model_A_const_38 *lang.Var

var A_arbace_j2g_model_A_const_39 *lang.Var

var A_arbace_j2g_model_A_const_40 *lang.Var

var A_arbace_j2g_model_A_const_41 *lang.Var

var A_arbace_j2g_model_A_const_42 *lang.Var

var A_arbace_j2g_model_A_const_43 *lang.Var

var A_arbace_j2g_model_A_const_44 *lang.Var

var A_arbace_j2g_model_A_const_45 *lang.Var

var A_arbace_j2g_model_A_const_46 *lang.Keyword

var A_arbace_j2g_model_A_const_47 any

var A_arbace_j2g_model_A_const_48 *lang.Var

var A_arbace_j2g_model_A_const_49 *lang.Keyword

var A_arbace_j2g_model_A_const_50 *lang.Var

var A_arbace_j2g_model_A_const_51 *lang.Var

var A_arbace_j2g_model_A_const_52 *lang.Var

var A_arbace_j2g_model_A_const_53 *lang.Keyword

var A_arbace_j2g_model_A_const_54 *lang.Var

var A_arbace_j2g_model_A_const_55 *lang.Var

var A_arbace_j2g_model_A_const_56 *lang.Var

var A_arbace_j2g_model_A_const_57 *lang.Var

var A_arbace_j2g_model_A_const_58 *lang.Var

var A_arbace_j2g_model_A_const_59 *lang.Var

var A_arbace_j2g_model_A_const_60 *lang.Keyword

var A_arbace_j2g_model_A_const_61 *lang.Var

var A_arbace_j2g_model_A_const_62 *lang.Var

var A_arbace_j2g_model_A_const_63 *lang.Var

var A_arbace_j2g_model_A_const_64 *lang.Var

var A_arbace_j2g_model_A_const_65 *lang.Var

var A_arbace_j2g_model_A_const_66 *lang.Var

var A_arbace_j2g_model_A_const_67 *lang.Var

var A_arbace_j2g_model_A_const_68 *lang.Var

var A_arbace_j2g_model_A_const_69 *lang.Keyword

var A_arbace_j2g_model_A_const_70 *lang.Var

var A_arbace_j2g_model_A_const_71 *lang.Keyword

var A_arbace_j2g_model_A_const_72 *lang.Var

var A_arbace_j2g_model_A_const_73 *lang.Var

var A_arbace_j2g_model_A_const_74 *lang.Var

var A_arbace_j2g_model_A_const_75 any

var A_arbace_j2g_model_A_const_76 any

var A_arbace_j2g_model_A_const_77 *lang.Keyword

var A_arbace_j2g_model_A_const_78 *lang.Var

var A_arbace_j2g_model_A_const_79 *lang.Var

var A_arbace_j2g_model_A_const_80 *lang.Keyword

var A_arbace_j2g_model_A_const_81 *lang.Var

var A_arbace_j2g_model_A_const_82 *lang.Var

var A_arbace_j2g_model_A_const_83 *lang.Var

var A_arbace_j2g_model_A_const_84 *lang.Var

var A_arbace_j2g_model_A_const_85 *lang.Var

var A_arbace_j2g_model_A_const_86 *lang.Var

var A_arbace_j2g_model_A_const_87 *lang.Var

var A_arbace_j2g_model_A_const_88 *lang.Var

var A_arbace_j2g_model_A_const_89 *lang.Var

var A_arbace_j2g_model_A_const_90 *lang.Keyword

var A_arbace_j2g_model_A_const_91 *lang.Keyword

var A_arbace_j2g_model_A_const_92 *lang.Var

var A_arbace_j2g_model_A_const_93 *lang.Var

var A_arbace_j2g_model_A_const_94 *lang.Var

var A_arbace_j2g_model_A_const_95 *lang.Var

var A_arbace_j2g_model_A_const_96 *lang.Var

var A_arbace_j2g_model_A_const_97 *lang.Var

var A_arbace_j2g_model_A_const_98 *lang.Var

var A_arbace_j2g_model_A_const_99 *lang.Var

var A_arbace_j2g_model_A_const_100 *lang.Var

var A_arbace_j2g_model_A_const_101 *lang.Var

var A_arbace_j2g_model_A_const_102 *lang.Keyword

var A_arbace_j2g_model_A_const_103 any

var A_arbace_j2g_model_A_const_104 *lang.Var

var A_arbace_j2g_model_A_const_105 any

var A_arbace_j2g_model_A_const_106 *lang.Var

var A_arbace_j2g_model_A_const_107 *lang.Var

var A_arbace_j2g_model_A_const_108 any

var A_arbace_j2g_model_A_const_109 *lang.Var

var A_arbace_j2g_model_A_const_110 *lang.Var

var A_arbace_j2g_model_A_const_111 *lang.Var

var A_arbace_j2g_model_A_const_112 *lang.Keyword

var A_arbace_j2g_model_A_const_113 any

var A_arbace_j2g_model_A_const_114 *lang.Var

var A_arbace_j2g_model_A_const_115 *lang.Var

var A_arbace_j2g_model_A_const_116 any

var A_arbace_j2g_model_A_const_117 any

var A_arbace_j2g_model_A_const_118 *lang.Var

var A_arbace_j2g_model_A_const_119 *lang.Var

var A_arbace_j2g_model_A_const_120 *lang.Var

var A_arbace_j2g_model_A_const_121 any

var A_arbace_j2g_model_A_const_122 any

var A_arbace_j2g_model_A_const_123 *lang.Keyword

var A_arbace_j2g_model_A_const_124 *lang.Keyword

var A_arbace_j2g_model_A_const_125 *lang.Var

var A_arbace_j2g_model_A_const_126 *lang.Var

var A_arbace_j2g_model_A_const_127 *lang.Var

var A_arbace_j2g_model_A_const_128 *lang.Var

var A_arbace_j2g_model_A_const_129 *lang.Var

var A_arbace_j2g_model_A_const_130 *lang.Var

var A_arbace_j2g_model_A_const_131 *lang.Var

var A_arbace_j2g_model_A_const_132 *lang.Var

var A_arbace_j2g_model_A_const_133 *lang.Var

var A_arbace_j2g_model_A_const_134 *lang.Var

var A_arbace_j2g_model_A_const_135 *lang.Var

var A_arbace_j2g_model_A_const_136 *lang.Keyword

var A_arbace_j2g_model_A_const_137 *lang.Var

var A_arbace_j2g_model_A_const_138 *lang.Var

var A_arbace_j2g_model_A_const_139 *lang.Var

var A_arbace_j2g_model_A_const_140 any

var A_arbace_j2g_model_A_const_141 *lang.Var

var A_arbace_j2g_model_A_const_142 *lang.Var

var A_arbace_j2g_model_A_const_143 *lang.Var

var A_arbace_j2g_model_A_const_144 *lang.Var

var A_arbace_j2g_model_A_const_145 *lang.Var

var A_arbace_j2g_model_A_const_146 *lang.Var

var A_arbace_j2g_model_A_const_147 *lang.Var

var A_arbace_j2g_model_A_const_148 *lang.Var

var A_arbace_j2g_model_A_const_149 *lang.Var

var A_arbace_j2g_model_A_const_150 *lang.Keyword

var A_arbace_j2g_model_A_const_151 *lang.Var

var A_arbace_j2g_model_A_const_152 *lang.Var

var A_arbace_j2g_model_A_const_153 *lang.Var

var A_arbace_j2g_model_A_const_154 *lang.Var

var A_arbace_j2g_model_A_const_155 *lang.Var

var A_arbace_j2g_model_A_const_156 *lang.Keyword

var A_arbace_j2g_model_A_const_157 *lang.Var

var A_arbace_j2g_model_A_const_158 *lang.Var

var A_arbace_j2g_model_A_const_159 *lang.Var

var A_arbace_j2g_model_A_const_160 *lang.Var

var A_arbace_j2g_model_A_const_161 any

var A_arbace_j2g_model_A_const_162 *lang.Var

var A_arbace_j2g_model_A_const_163 *lang.Var

var A_arbace_j2g_model_A_const_164 *lang.Var

var A_arbace_j2g_model_A_const_165 *lang.Var

var A_arbace_j2g_model_A_const_166 *lang.Var

var A_arbace_j2g_model_A_const_167 *lang.Var

var A_arbace_j2g_model_A_const_168 *lang.Var

var A_arbace_j2g_model_A_const_169 *lang.Keyword

var A_arbace_j2g_model_A_const_170 *lang.Keyword

var A_arbace_j2g_model_A_const_171 *lang.Keyword

var A_arbace_j2g_model_A_const_172 *lang.Keyword

var A_arbace_j2g_model_A_const_173 *lang.Keyword

var A_arbace_j2g_model_A_const_174 *lang.Keyword

var A_arbace_j2g_model_A_const_175 *lang.Var

var A_arbace_j2g_model_A_const_176 *lang.Keyword

var A_arbace_j2g_model_A_const_177 *lang.Var

var A_arbace_j2g_model_A_const_178 *lang.Keyword

var A_arbace_j2g_model_A_const_179 *lang.Keyword

var A_arbace_j2g_model_A_const_180 *lang.Var

var A_arbace_j2g_model_A_const_181 any

var A_arbace_j2g_model_A_const_182 *lang.Keyword

var A_arbace_j2g_model_A_const_183 *lang.Keyword

var A_arbace_j2g_model_A_const_184 *lang.Keyword

var A_arbace_j2g_model_A_const_185 *lang.Keyword

var A_arbace_j2g_model_A_const_186 *lang.Keyword

var A_arbace_j2g_model_A_const_187 *lang.Keyword

var A_arbace_j2g_model_A_const_188 *lang.Var

var A_arbace_j2g_model_A_const_189 *lang.Var

var A_arbace_j2g_model_A_const_190 *lang.Var

var A_arbace_j2g_model_A_const_191 *lang.Var

var A_arbace_j2g_model_A_const_192 *lang.Var

var A_arbace_j2g_model_A_const_193 *lang.Var

var A_arbace_j2g_model_A_const_194 *lang.Var

var A_arbace_j2g_model_A_const_195 *lang.Var

var A_arbace_j2g_model_A_const_196 *lang.Keyword

var A_arbace_j2g_model_A_const_197 *lang.Var

var A_arbace_j2g_model_A_const_198 *lang.Keyword

var A_arbace_j2g_model_A_const_199 *lang.Keyword

var A_arbace_j2g_model_A_const_200 *lang.Keyword

var A_arbace_j2g_model_A_const_201 *lang.Var

var A_arbace_j2g_model_A_const_202 *lang.Keyword

var A_arbace_j2g_model_A_const_203 any

var A_arbace_j2g_model_A_const_204 *lang.Var

var A_arbace_j2g_model_A_const_205 *lang.Keyword

var A_arbace_j2g_model_A_const_206 *lang.Keyword

var A_arbace_j2g_model_A_const_207 *lang.Keyword

var A_arbace_j2g_model_A_const_208 *lang.Keyword

var A_arbace_j2g_model_A_const_209 *lang.Keyword

var A_arbace_j2g_model_A_const_210 *lang.Keyword

var A_arbace_j2g_model_A_const_211 *lang.Keyword

var A_arbace_j2g_model_A_const_212 *lang.Keyword

var A_arbace_j2g_model_A_const_213 *lang.Keyword

var A_arbace_j2g_model_A_const_214 *lang.Keyword

var A_arbace_j2g_model_A_const_215 *lang.Keyword

var A_arbace_j2g_model_A_const_216 *lang.Keyword

var A_arbace_j2g_model_A_const_217 *lang.Keyword

var A_arbace_j2g_model_A_const_218 *lang.Keyword

var A_arbace_j2g_model_A_const_219 *lang.Keyword

var A_arbace_j2g_model_A_const_220 *lang.Keyword

var A_arbace_j2g_model_A_const_221 *lang.Keyword

var A_arbace_j2g_model_A_const_222 *lang.Keyword

var A_arbace_j2g_model_A_const_223 *lang.Keyword

var A_arbace_j2g_model_A_const_224 *lang.Keyword

var A_arbace_j2g_model_A_const_225 *lang.Keyword

var A_arbace_j2g_model_A_const_226 *lang.Keyword

var A_arbace_j2g_model_A_const_227 *lang.Keyword

var A_arbace_j2g_model_A_const_228 *lang.Keyword

var A_arbace_j2g_model_A_const_229 *lang.Keyword

var A_arbace_j2g_model_A_const_230 *lang.Keyword

var A_arbace_j2g_model_A_const_231 *lang.Keyword

var A_arbace_j2g_model_A_const_232 *lang.Var

var A_arbace_j2g_model_A_const_233 *lang.Keyword

var A_arbace_j2g_model_A_const_234 *lang.Keyword

var A_arbace_j2g_model_A_const_235 *lang.Keyword

var A_arbace_j2g_model_A_const_236 *lang.Keyword

var A_arbace_j2g_model_A_const_237 any

var A_arbace_j2g_model_A_const_238 *lang.Keyword

var A_arbace_j2g_model_A_const_239 *lang.Keyword

var A_arbace_j2g_model_A_const_240 *lang.Keyword

var A_arbace_j2g_model_A_const_241 *lang.Keyword

var A_arbace_j2g_model_A_const_242 *lang.Keyword

var A_arbace_j2g_model_A_const_243 *lang.Keyword

var A_arbace_j2g_model_A_const_244 *lang.Var

var A_arbace_j2g_model_A_const_245 *lang.Keyword

var A_arbace_j2g_model_A_init jrt.ClassInit

func A_arbace_j2g_model_A_Init() { if !A_arbace_j2g_model_A_init.Done() { A_arbace_j2g_model_A_init.Run(A_arbace_j2g_model_A_clinit) } }

func A_arbace_j2g_model_A_clinit() { A_arbace_j2g_model_A_clinit_p0(); A_arbace_j2g_model_A_clinit_p1(); A_arbace_j2g_model_A_clinit_p2(); A_arbace_j2g_model_A_clinit_p3(); A_arbace_j2g_model_A_clinit_p4(); A_arbace_j2g_model_A_clinit_p5(); A_arbace_j2g_model_A_clinit_p6(); A_arbace_j2g_model_A_clinit_p7(); A_arbace_j2g_model_A_clinit_p8(); A_arbace_j2g_model_A_clinit_p9(); A_arbace_j2g_model_A_clinit_p10(); A_arbace_j2g_model_A_clinit_p11(); A_arbace_j2g_model_A_clinit_p12(); A_arbace_j2g_model_A_clinit_p13(); A_arbace_j2g_model_A_clinit_p14(); A_arbace_j2g_model_A_clinit_p15(); A_arbace_j2g_model_A_clinit_p16(); A_arbace_j2g_model_A_clinit_p17(); A_arbace_j2g_model_A_clinit_p18(); A_arbace_j2g_model_A_clinit_p19(); A_arbace_j2g_model_A_clinit_p20() }

func A_arbace_j2g_model_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_model_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 346); A_arbace_j2g_model_A_const_0 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[100]); A_arbace_j2g_model_A_const_1 = A_arbace_j2g_model_A_const_pool.A[101]; A_arbace_j2g_model_A_const_2 = A_arbace_j2g_model_A_const_pool.A[102]; A_arbace_j2g_model_A_const_3 = A_arbace_j2g_model_A_const_pool.A[103]; A_arbace_j2g_model_A_const_4 = A_arbace_j2g_model_A_const_pool.A[104]; A_arbace_j2g_model_A_const_5 = A_arbace_j2g_model_A_const_pool.A[105]; A_arbace_j2g_model_A_const_6 = A_arbace_j2g_model_A_const_pool.A[106]; A_arbace_j2g_model_A_const_7 = A_arbace_j2g_model_A_const_pool.A[107]; A_arbace_j2g_model_A_const_8 = A_arbace_j2g_model_A_const_pool.A[108]; A_arbace_j2g_model_A_const_9 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[109]); A_arbace_j2g_model_A_const_10 = A_arbace_j2g_model_A_const_pool.A[110]; A_arbace_j2g_model_A_const_11 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[111]); A_arbace_j2g_model_A_const_12 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[112]) }

func A_arbace_j2g_model_A_clinit_p1() { A_arbace_j2g_model_A_const_13 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[113]); A_arbace_j2g_model_A_const_14 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[114]); A_arbace_j2g_model_A_const_15 = A_arbace_j2g_model_A_const_pool.A[115]; A_arbace_j2g_model_A_const_16 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[116]); A_arbace_j2g_model_A_const_17 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[117]); A_arbace_j2g_model_A_const_18 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[118]); A_arbace_j2g_model_A_const_19 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[119]); A_arbace_j2g_model_A_const_20 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[120]); A_arbace_j2g_model_A_const_21 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[121]); A_arbace_j2g_model_A_const_22 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[122]); A_arbace_j2g_model_A_const_23 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[123]); A_arbace_j2g_model_A_const_24 = A_arbace_j2g_model_A_const_pool.A[124] }

func A_arbace_j2g_model_A_clinit_p2() { A_arbace_j2g_model_A_const_25 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[125]); A_arbace_j2g_model_A_const_26 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[126]); A_arbace_j2g_model_A_const_27 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[127]); A_arbace_j2g_model_A_const_28 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[128]); A_arbace_j2g_model_A_const_29 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[129]); A_arbace_j2g_model_A_const_30 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[130]); A_arbace_j2g_model_A_const_31 = A_arbace_j2g_model_A_const_pool.A[131]; A_arbace_j2g_model_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[132]); A_arbace_j2g_model_A_const_33 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[133]); A_arbace_j2g_model_A_const_34 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[134]); A_arbace_j2g_model_A_const_35 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[135]); A_arbace_j2g_model_A_const_36 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[136]) }

func A_arbace_j2g_model_A_clinit_p3() { A_arbace_j2g_model_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[137]); A_arbace_j2g_model_A_const_38 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[138]); A_arbace_j2g_model_A_const_39 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[139]); A_arbace_j2g_model_A_const_40 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[140]); A_arbace_j2g_model_A_const_41 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[141]); A_arbace_j2g_model_A_const_42 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[142]); A_arbace_j2g_model_A_const_43 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[143]); A_arbace_j2g_model_A_const_44 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[144]); A_arbace_j2g_model_A_const_45 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[145]); A_arbace_j2g_model_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[146]); A_arbace_j2g_model_A_const_47 = A_arbace_j2g_model_A_const_pool.A[147]; A_arbace_j2g_model_A_const_48 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[148]) }

func A_arbace_j2g_model_A_clinit_p4() { A_arbace_j2g_model_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[149]); A_arbace_j2g_model_A_const_50 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[150]); A_arbace_j2g_model_A_const_51 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[151]); A_arbace_j2g_model_A_const_52 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[152]); A_arbace_j2g_model_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[153]); A_arbace_j2g_model_A_const_54 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[154]); A_arbace_j2g_model_A_const_55 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[155]); A_arbace_j2g_model_A_const_56 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[156]); A_arbace_j2g_model_A_const_57 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[157]); A_arbace_j2g_model_A_const_58 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[158]); A_arbace_j2g_model_A_const_59 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[159]); A_arbace_j2g_model_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[160]) }

func A_arbace_j2g_model_A_clinit_p5() { A_arbace_j2g_model_A_const_61 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[161]); A_arbace_j2g_model_A_const_62 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[162]); A_arbace_j2g_model_A_const_63 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[163]); A_arbace_j2g_model_A_const_64 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[164]); A_arbace_j2g_model_A_const_65 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[165]); A_arbace_j2g_model_A_const_66 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[166]); A_arbace_j2g_model_A_const_67 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[167]); A_arbace_j2g_model_A_const_68 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[168]); A_arbace_j2g_model_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[169]); A_arbace_j2g_model_A_const_70 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[170]); A_arbace_j2g_model_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[171]); A_arbace_j2g_model_A_const_72 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[172]) }

func A_arbace_j2g_model_A_clinit_p6() { A_arbace_j2g_model_A_const_73 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[173]); A_arbace_j2g_model_A_const_74 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[174]); A_arbace_j2g_model_A_const_75 = A_arbace_j2g_model_A_const_pool.A[175]; A_arbace_j2g_model_A_const_76 = A_arbace_j2g_model_A_const_pool.A[176]; A_arbace_j2g_model_A_const_77 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[177]); A_arbace_j2g_model_A_const_78 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[178]); A_arbace_j2g_model_A_const_79 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[179]); A_arbace_j2g_model_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[180]); A_arbace_j2g_model_A_const_81 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[181]); A_arbace_j2g_model_A_const_82 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[182]); A_arbace_j2g_model_A_const_83 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[183]); A_arbace_j2g_model_A_const_84 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[184]) }

func A_arbace_j2g_model_A_clinit_p7() { A_arbace_j2g_model_A_const_85 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[185]); A_arbace_j2g_model_A_const_86 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[186]); A_arbace_j2g_model_A_const_87 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[187]); A_arbace_j2g_model_A_const_88 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[188]); A_arbace_j2g_model_A_const_89 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[189]); A_arbace_j2g_model_A_const_90 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[190]); A_arbace_j2g_model_A_const_91 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[191]); A_arbace_j2g_model_A_const_92 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[192]); A_arbace_j2g_model_A_const_93 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[193]); A_arbace_j2g_model_A_const_94 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[194]); A_arbace_j2g_model_A_const_95 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[195]); A_arbace_j2g_model_A_const_96 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[196]) }

func A_arbace_j2g_model_A_clinit_p8() { A_arbace_j2g_model_A_const_97 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[197]); A_arbace_j2g_model_A_const_98 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[198]); A_arbace_j2g_model_A_const_99 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[199]); A_arbace_j2g_model_A_const_100 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[200]); A_arbace_j2g_model_A_const_101 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[201]); A_arbace_j2g_model_A_const_102 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[202]); A_arbace_j2g_model_A_const_103 = A_arbace_j2g_model_A_const_pool.A[203]; A_arbace_j2g_model_A_const_104 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[204]); A_arbace_j2g_model_A_const_105 = A_arbace_j2g_model_A_const_pool.A[205]; A_arbace_j2g_model_A_const_106 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[206]); A_arbace_j2g_model_A_const_107 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[207]); A_arbace_j2g_model_A_const_108 = A_arbace_j2g_model_A_const_pool.A[208] }

func A_arbace_j2g_model_A_clinit_p9() { A_arbace_j2g_model_A_const_109 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[209]); A_arbace_j2g_model_A_const_110 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[210]); A_arbace_j2g_model_A_const_111 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[211]); A_arbace_j2g_model_A_const_112 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[212]); A_arbace_j2g_model_A_const_113 = A_arbace_j2g_model_A_const_pool.A[213]; A_arbace_j2g_model_A_const_114 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[214]); A_arbace_j2g_model_A_const_115 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[215]); A_arbace_j2g_model_A_const_116 = A_arbace_j2g_model_A_const_pool.A[216]; A_arbace_j2g_model_A_const_117 = A_arbace_j2g_model_A_const_pool.A[217]; A_arbace_j2g_model_A_const_118 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[218]); A_arbace_j2g_model_A_const_119 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[219]); A_arbace_j2g_model_A_const_120 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[220]); A_arbace_j2g_model_A_const_121 = A_arbace_j2g_model_A_const_pool.A[221] }

func A_arbace_j2g_model_A_clinit_p10() { A_arbace_j2g_model_A_const_122 = A_arbace_j2g_model_A_const_pool.A[222]; A_arbace_j2g_model_A_const_123 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[223]); A_arbace_j2g_model_A_const_124 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[224]); A_arbace_j2g_model_A_const_125 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[225]); A_arbace_j2g_model_A_const_126 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[226]); A_arbace_j2g_model_A_const_127 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[227]); A_arbace_j2g_model_A_const_128 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[228]); A_arbace_j2g_model_A_const_129 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[229]); A_arbace_j2g_model_A_const_130 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[230]); A_arbace_j2g_model_A_const_131 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[231]); A_arbace_j2g_model_A_const_132 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[232]); A_arbace_j2g_model_A_const_133 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[233]) }

func A_arbace_j2g_model_A_clinit_p11() { A_arbace_j2g_model_A_const_134 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[234]); A_arbace_j2g_model_A_const_135 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[235]); A_arbace_j2g_model_A_const_136 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[236]); A_arbace_j2g_model_A_const_137 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[237]); A_arbace_j2g_model_A_const_138 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[238]); A_arbace_j2g_model_A_const_139 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[239]); A_arbace_j2g_model_A_const_140 = A_arbace_j2g_model_A_const_pool.A[240]; A_arbace_j2g_model_A_const_141 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[241]); A_arbace_j2g_model_A_const_142 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[242]); A_arbace_j2g_model_A_const_143 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[243]); A_arbace_j2g_model_A_const_144 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[244]); A_arbace_j2g_model_A_const_145 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[245]) }

func A_arbace_j2g_model_A_clinit_p12() { A_arbace_j2g_model_A_const_146 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[246]); A_arbace_j2g_model_A_const_147 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[247]); A_arbace_j2g_model_A_const_148 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[248]); A_arbace_j2g_model_A_const_149 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[249]); A_arbace_j2g_model_A_const_150 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[250]); A_arbace_j2g_model_A_const_151 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[251]); A_arbace_j2g_model_A_const_152 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[252]); A_arbace_j2g_model_A_const_153 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[253]); A_arbace_j2g_model_A_const_154 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[254]); A_arbace_j2g_model_A_const_155 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[255]); A_arbace_j2g_model_A_const_156 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[256]); A_arbace_j2g_model_A_const_157 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[257]) }

func A_arbace_j2g_model_A_clinit_p13() { A_arbace_j2g_model_A_const_158 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[258]); A_arbace_j2g_model_A_const_159 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[259]); A_arbace_j2g_model_A_const_160 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[260]); A_arbace_j2g_model_A_const_161 = A_arbace_j2g_model_A_const_pool.A[261]; A_arbace_j2g_model_A_const_162 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[262]); A_arbace_j2g_model_A_const_163 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[263]); A_arbace_j2g_model_A_const_164 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[264]); A_arbace_j2g_model_A_const_165 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[265]); A_arbace_j2g_model_A_const_166 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[266]); A_arbace_j2g_model_A_const_167 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[267]); A_arbace_j2g_model_A_const_168 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[268]); A_arbace_j2g_model_A_const_169 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[269]) }

func A_arbace_j2g_model_A_clinit_p14() { A_arbace_j2g_model_A_const_170 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[270]); A_arbace_j2g_model_A_const_171 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[271]); A_arbace_j2g_model_A_const_172 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[272]); A_arbace_j2g_model_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[273]); A_arbace_j2g_model_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[274]); A_arbace_j2g_model_A_const_175 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[275]); A_arbace_j2g_model_A_const_176 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[276]); A_arbace_j2g_model_A_const_177 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[277]); A_arbace_j2g_model_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[278]); A_arbace_j2g_model_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[279]); A_arbace_j2g_model_A_const_180 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[280]); A_arbace_j2g_model_A_const_181 = A_arbace_j2g_model_A_const_pool.A[281] }

func A_arbace_j2g_model_A_clinit_p15() { A_arbace_j2g_model_A_const_182 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[282]); A_arbace_j2g_model_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[283]); A_arbace_j2g_model_A_const_184 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[284]); A_arbace_j2g_model_A_const_185 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[285]); A_arbace_j2g_model_A_const_186 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[286]); A_arbace_j2g_model_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[287]); A_arbace_j2g_model_A_const_188 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[288]); A_arbace_j2g_model_A_const_189 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[289]); A_arbace_j2g_model_A_const_190 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[290]); A_arbace_j2g_model_A_const_191 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[291]); A_arbace_j2g_model_A_const_192 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[292]); A_arbace_j2g_model_A_const_193 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[293]) }

func A_arbace_j2g_model_A_clinit_p16() { A_arbace_j2g_model_A_const_194 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[294]); A_arbace_j2g_model_A_const_195 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[295]); A_arbace_j2g_model_A_const_196 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[296]); A_arbace_j2g_model_A_const_197 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[297]); A_arbace_j2g_model_A_const_198 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[298]); A_arbace_j2g_model_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[299]); A_arbace_j2g_model_A_const_200 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[300]); A_arbace_j2g_model_A_const_201 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[301]); A_arbace_j2g_model_A_const_202 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[302]); A_arbace_j2g_model_A_const_203 = A_arbace_j2g_model_A_const_pool.A[303]; A_arbace_j2g_model_A_const_204 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[304]); A_arbace_j2g_model_A_const_205 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[305]) }

func A_arbace_j2g_model_A_clinit_p17() { A_arbace_j2g_model_A_const_206 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[306]); A_arbace_j2g_model_A_const_207 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[307]); A_arbace_j2g_model_A_const_208 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[308]); A_arbace_j2g_model_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[309]); A_arbace_j2g_model_A_const_210 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[310]); A_arbace_j2g_model_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[311]); A_arbace_j2g_model_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[312]); A_arbace_j2g_model_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[313]); A_arbace_j2g_model_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[314]); A_arbace_j2g_model_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[315]); A_arbace_j2g_model_A_const_216 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[316]); A_arbace_j2g_model_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[317]) }

func A_arbace_j2g_model_A_clinit_p18() { A_arbace_j2g_model_A_const_218 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[318]); A_arbace_j2g_model_A_const_219 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[319]); A_arbace_j2g_model_A_const_220 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[320]); A_arbace_j2g_model_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[321]); A_arbace_j2g_model_A_const_222 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[322]); A_arbace_j2g_model_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[323]); A_arbace_j2g_model_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[324]); A_arbace_j2g_model_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[325]); A_arbace_j2g_model_A_const_226 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[326]); A_arbace_j2g_model_A_const_227 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[327]); A_arbace_j2g_model_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[328]); A_arbace_j2g_model_A_const_229 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[329]) }

func A_arbace_j2g_model_A_clinit_p19() { A_arbace_j2g_model_A_const_230 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[330]); A_arbace_j2g_model_A_const_231 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[331]); A_arbace_j2g_model_A_const_232 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[332]); A_arbace_j2g_model_A_const_233 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[333]); A_arbace_j2g_model_A_const_234 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[334]); A_arbace_j2g_model_A_const_235 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[335]); A_arbace_j2g_model_A_const_236 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[336]); A_arbace_j2g_model_A_const_237 = A_arbace_j2g_model_A_const_pool.A[337]; A_arbace_j2g_model_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[338]); A_arbace_j2g_model_A_const_239 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[339]); A_arbace_j2g_model_A_const_240 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[340]); A_arbace_j2g_model_A_const_241 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[341]) }

func A_arbace_j2g_model_A_clinit_p20() { A_arbace_j2g_model_A_const_242 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[342]); A_arbace_j2g_model_A_const_243 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[343]); A_arbace_j2g_model_A_const_244 = lang.Var_Cast(A_arbace_j2g_model_A_const_pool.A[344]); A_arbace_j2g_model_A_const_245 = lang.Keyword_Cast(A_arbace_j2g_model_A_const_pool.A[345]) }

func A_arbace_j2g_model_A_New() *A_arbace_j2g_model_A { A_arbace_j2g_model_A_Init(); t := &A_arbace_j2g_model_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_A) Ctor() {}

func (t *A_arbace_j2g_model_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_A_class }

func (t *A_arbace_j2g_model_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_A); return ok }

func A_arbace_j2g_model_A_Cast(x any) *A_arbace_j2g_model_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_A_class)) }; return v }



type A_arbace_j2g_model_T_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_T_A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_m_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_m_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_abstract_method_error_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_abstract_method_error_text_A_fn_class *jrt.Class



type A_arbace_j2g_model_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_all_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_benign_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_benign_init_QMARK__fn__1479000192_A_fn_class *jrt.Class



type A_arbace_j2g_model_class_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_class_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_code_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_code_iface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_code_iface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_declared_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A struct{ j2g_header uint64; F_n, F_s__1479000090, F_iter__1479000089 any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_A_fn_class *jrt.Class



type A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A struct{ j2g_header uint64; F_n, F_b__1479000092 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_declared_vmethods_iter__1479000089__1479000093_fn__1479000094_fn__1479000095_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_desc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_desc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_erased_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000047_A_fn_class *jrt.Class



type A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_model_erased_desc_QMARK__fn__1479000049_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000004_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000004_A_New() *A_arbace_j2g_model_eval1479000004_A { t := &A_arbace_j2g_model_eval1479000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000004_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000004_A_class }

func (t *A_arbace_j2g_model_eval1479000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000004_A); return ok }

func A_arbace_j2g_model_eval1479000004_A_Cast(x any) *A_arbace_j2g_model_eval1479000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000004_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000004_loading__1927001464__auto____1479000005_A_fn_class *jrt.Class



type A_arbace_j2g_model_eval1479000008_A struct{ jrt.Object }

func A_arbace_j2g_model_eval1479000008_A_New() *A_arbace_j2g_model_eval1479000008_A { t := &A_arbace_j2g_model_eval1479000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_model_eval1479000008_A) Ctor() {}

func (t *A_arbace_j2g_model_eval1479000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_model_eval1479000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_model_eval1479000008_A_class }

func (t *A_arbace_j2g_model_eval1479000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_model_eval1479000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_model_eval1479000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_model_eval1479000008_A); return ok }

func A_arbace_j2g_model_eval1479000008_A_Cast(x any) *A_arbace_j2g_model_eval1479000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_model_eval1479000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_model_eval1479000008_A_class)) }; return v }



type A_arbace_j2g_model_eval1479000008_fn__1479000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_eval1479000008_fn__1479000009_A_fn_class *jrt.Class



type A_arbace_j2g_model_fields_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_fields_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_final_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_final_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_find_method_A_fn_class *jrt.Class



type A_arbace_j2g_model_find_method_fn__1479000079_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_find_method_fn__1479000079_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_qualified_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_qualified_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_model_hand_written_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hand_written_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_hw_method_exists_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_hw_method_exists_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_iface_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_iface_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_impl_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000123_A struct{ j2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_j2g_model_impl_of_fn__1479000123_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000135_A struct{ j2g_header uint64; F_cands any }

var A_arbace_j2g_model_impl_of_fn__1479000135_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A struct{ j2g_header uint64; F_x any }

var A_arbace_j2g_model_impl_of_fn__1479000135_fn__1479000136_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A struct{ j2g_header uint64; F_iter__1479000125, F_name, F_desc, F_s__1479000126 any }

var A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_A_fn_class *jrt.Class



type A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A struct{ j2g_header uint64; F_name, F_b__1479000128, F_desc any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_impl_of_iter__1479000125__1479000129_fn__1479000130_fn__1479000131_A_fn_class *jrt.Class



type A_arbace_j2g_model_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_info_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_info_A_fn_class *jrt.Class



type A_arbace_j2g_model_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_method_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_method_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_j2g_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_j2g_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_java_type_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_java_type_name_A_fn_class *jrt.Class



type A_arbace_j2g_model_jobs_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jobs_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_jrt_sym_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_jrt_sym_A_fn_class *jrt.Class



type A_arbace_j2g_model_leaf_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_leaf_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_A struct{ j2g_header uint64; F_cache, F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A struct{ j2g_header uint64; F_w any }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_A_fn_class *jrt.Class



type A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_make_subclass_index_fn__1479000059_fn__1479000060_fn__1479000061_A_fn_class *jrt.Class



type A_arbace_j2g_model_mdesc_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_member_in_world_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_member_in_world_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_method_desc_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_method_desc_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_methods_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_methods_of_A_fn_class *jrt.Class



type A_arbace_j2g_model_nest_top_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_nest_top_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_par_mapv_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000017_A struct{ j2g_header uint64; F_f, F_last_i, F_xs any }

var A_arbace_j2g_model_par_mapv_fn__1479000017_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A struct{ j2g_header uint64; F_work any }

var A_arbace_j2g_model_par_mapv_fn__1479000021_fn__1479000022_A_fn_class *jrt.Class



type A_arbace_j2g_model_par_mapv_work__1479000019_A struct{ j2g_header uint64; F_cnt int32; F_order, F_f, F_next_i, F_xs, F_res any }

var A_arbace_j2g_model_par_mapv_work__1479000019_A_fn_class *jrt.Class



type A_arbace_j2g_model_pkg_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pkg_A_fn_class *jrt.Class



type A_arbace_j2g_model_pointer_desc_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_private_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_ctor_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000160_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_ctor_QMARK__fn__1479000162_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000172_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000175_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000180_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000182_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000184_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000186_A_fn_class *jrt.Class



type A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A struct{ j2g_header uint64; F_n, F_seen any }

var A_arbace_j2g_model_pure_node_QMARK__fn__1479000188_A_fn_class *jrt.Class



type A_arbace_j2g_model_qualify_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_qualify_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflectable_interface_QMARK__fn__1479000035_A_fn_class *jrt.Class



type A_arbace_j2g_model_reflected_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_reflected_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_class_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A struct{ j2g_header uint64; F_iter__1479000146, F_s__1479000147 any }

var A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_A_fn_class *jrt.Class



type A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A struct{ j2g_header uint64; F_b__1479000149 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_model_start_classes_iter__1479000146__1479000150_fn__1479000151_fn__1479000152_A_fn_class *jrt.Class



type A_arbace_j2g_model_static_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_static_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_subclasses_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_subclasses_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_A_fn_class *jrt.Class



type A_arbace_j2g_model_superclass_chain_fn__1479000115_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_superclass_chain_fn__1479000115_A_fn_class *jrt.Class



type A_arbace_j2g_model_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_supertypes_A_fn_class *jrt.Class



type A_arbace_j2g_model_top_class_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_top_class_A_fn_class *jrt.Class



type A_arbace_j2g_model_translatable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translatable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_translated_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_translated_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_trivial_init_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_trivial_init_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_virtual_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_model_virtual_member_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000100_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000100_A_fn_class *jrt.Class



type A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_vmethods_fn__1479000100_fn__1479000101_A_fn_class *jrt.Class



type A_arbace_j2g_model_world_supertypes_A struct{ j2g_header uint64 }

var A_arbace_j2g_model_world_supertypes_A_fn_class *jrt.Class
